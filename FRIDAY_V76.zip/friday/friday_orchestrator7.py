"""FRIDAY 7.0 Unified Agent Orchestrator  (roadmap #1).

The central controller that connects the engines.  It interprets a request, selects tools, tracks progress, handles time-outs and
cancellation, and coordinates the results.

* intent classification   chat | question | command | mission ... plus how many separate actions the request contains
* task state machine      queued -> planning -> running <-> waiting_approval -> verifying -> done | partial | failed | cancelled | paused
* tool registry           one registry for every tool: risk, description, fallback, default postconditions, time-out, owning agent
* dependency tracking     steps run in topological layers; independent steps in a layer run in parallel (bounded), dependants wait / are skipped
* cancellation            per-job cancel events reach the running tool call; the 6.0 emergency stop is honoured
* error recovery          every call goes through the verification engine (receipts, safe retries); failures are classified and the planner
                          revises the plan (alternative tool, fallback, prerequisite step, another branch) instead of marching on
* shared blackboard       agents and steps publish results to one board; later steps and the final reconciliation read from it
* durable jobs            plans, results and checkpoints are stored, so an interrupted job resumes from its last verified step
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait
from typing import Any, Callable, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K
import friday_verify7 as V
import friday_planner7 as P
import friday_policy7 as POL

C.register_schema("""
CREATE TABLE IF NOT EXISTS jobs7(id INTEGER PRIMARY KEY, jid TEXT UNIQUE, created REAL, updated REAL, goal TEXT, state TEXT, intent TEXT, source TEXT, priority INTEGER,
    plan TEXT, plan_meta TEXT, results TEXT, board TEXT, error TEXT, report TEXT, revisions INTEGER DEFAULT 0, auto INTEGER DEFAULT 0, budget_s REAL,
    started REAL, ended REAL, session TEXT, path TEXT, speak INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS job_events7(id INTEGER PRIMARY KEY, jid TEXT, ts REAL, kind TEXT, note TEXT);
CREATE INDEX IF NOT EXISTS ix_job_events7_jid ON job_events7(jid);
""")

STATES = ("queued", "planning", "running", "waiting_approval", "verifying", "paused", "done", "partial", "failed", "cancelled")
TERMINAL = ("done", "partial", "failed", "cancelled")
APPROVAL_WAIT = 120.0
DEFAULT_BUDGET = 240.0


# ------------------------------------------------------------------ tool registry
class Registry:
    def __init__(self):
        self._t: Dict[str, Dict] = {}
        self._lock = threading.RLock()

    def register(self, name: str, fn: Callable[[Dict], Any], risk: str = "safe", desc: str = "", fallback: str = "", post: Optional[Dict] = None,
                 idempotent: bool = True, timeout: float = 60.0, agent: str = "", permission: Optional[str] = None, needs: Optional[List[str]] = None):
        with self._lock:
            self._t[name] = {"name": name, "fn": fn, "risk": risk, "desc": desc, "fallback": fallback, "post": post or {}, "idempotent": idempotent,
                             "timeout": float(timeout), "agent": agent, "permission": permission, "needs": needs or []}
        K.emit("tool.registered", {"name": name})

    def has(self, name: str) -> bool:
        return name in self._t

    def get(self, name: str) -> Dict:
        return self._t[name]

    def names(self) -> List[str]:
        return sorted(self._t)

    def describe(self) -> List[Dict]:
        return [{k: v for k, v in e.items() if k != "fn"} for _, e in sorted(self._t.items())]

    def sync_from_tasks(self) -> int:
        """Bring the 6.0 task-engine tools into the registry (they keep working in both engines)."""
        n = 0
        try:
            import friday_tasks6 as TASK
            for name, e in dict(TASK._tools).items():
                if name in self._t or name.startswith("_b_"):
                    continue
                default_post = {"nonempty": True} if name in ("think", "web_research", "code_review", "code_map", "system_info", "analyze_folder") else {}
                if name == "write_file":
                    default_post = {"file_exists": True}
                self.register(name, e["fn"], risk=e.get("risk", "safe"), desc=e.get("desc", ""), fallback=e.get("fallback", ""), post=default_post,
                              idempotent=e.get("risk", "safe") == "safe", timeout=90.0 if name in ("web_research", "run_tests", "verify_build") else 45.0, agent="core6")
                n += 1
        except Exception as exc:
            C.log(f"registry sync failed safely: {exc}", "recovery")
        return n


registry = Registry()


# ------------------------------------------------------------------ intent classification
_ACTIONS = {
    "research": r"\b(research|investigate|look up|find out|search|compare|sources?|fact[- ]check|dig into)\b",
    "cost": r"\b(cost|price|prices|how much|estimate|costing|calculate|work out)\b",
    "compare": r"\b(compare|versus|vs\.?|alternatives?|cheaper|cheapest|better than|which is best)\b",
    "save": r"\b(save|write|store|export|put (?:it|them|the)|keep (?:it|them))\b.*\b(file|report|summary|findings|notes|document|it|them|down)\b|\bsave (?:the |my |these |those )?(?:findings|results|summary|report)\b",
    "verify": r"\b(verify|double[- ]check|check (?:the )?(?:calculations?|numbers|maths?|sums?)|make sure|validate|confirm)\b",
    "summarise": r"\b(summari[sz]e|summary|explain|report|write up|recommend(?:ation)?s?)\b",
    "analyse": r"\b(analy[sz]e|review|audit|inspect|diagnos\w*|examine)\b",
    "organise": r"\b(organi[sz]e|clean up|sort|tidy|rename)\b",
    "plan": r"\b(plan|schedule|roadmap|steps?)\b",
    "build": r"\b(create|build|make|generate|draft|prepare|design)\b",
    "fix": r"\b(fix|repair|debug|patch)\b",
}
_ACTION_RX = {k: re.compile(v, re.I) for k, v in _ACTIONS.items()}
_SEQUENCE = re.compile(r"\b(?:and then|then|after that|afterwards|next|finally|once (?:that'?s|you(?:'ve| have)) done|followed by)\b|,\s*(?:and\s+)?(?=(?:then\s+)?(?:research|cost|price|compare|save|verify|check|summari[sz]e|write|find|calculate|analy[sz]e|review|organi[sz]e|create|make|build)\b)", re.I)
_QUESTION = re.compile(r"^(?:what|why|how|who|when|where|which|is|are|can|could|do|does|did|will|would|should|tell me|explain)\b", re.I)
_CHATTY = re.compile(r"^(?:hi|hello|hey|thanks|thank you|ok|okay|yes|no|good (?:morning|evening|night)|how are you|nice|cool|great|bye|goodbye)\b", re.I)
_MISSION_WORDS = re.compile(r"\b(mission|as a job|step by step and verify|end to end|run (?:this|it) as a task|plan and do|do all of (?:this|it))\b", re.I)


def classify_intent(text: str) -> Dict:
    t = (text or "").strip()
    low = t.lower()
    cats = [k for k, rx in _ACTION_RX.items() if rx.search(low)]
    seq = len(_SEQUENCE.findall(low))
    words = len(low.split())
    explicit = bool(_MISSION_WORDS.search(low))
    multi = (len(cats) >= 3 and (seq >= 1 or words >= 14)) or explicit
    intent = "chat" if _CHATTY.match(low) and words <= 6 else "question" if _QUESTION.match(low) and not multi else "mission" if multi else "command" if cats else "chat"
    domain = "money" if re.search(r"\b(cheap|budget|cost|price|save money|grocer|recipe|ingredient|meal|spend)\w*\b", low) else "code" if re.search(r"\b(code|bug|script|project|repo|function)\b", low) \
        else "research" if "research" in cats else "general"
    try:
        import friday_router7 as R
        route = R.classify(t).get("route", "general")
    except Exception:
        route = "general"
    return {"intent": intent, "multi_step": bool(multi), "actions": cats, "steps_hint": max(1, len(cats) + (1 if seq else 0)) if cats else 1, "explicit": explicit,
            "complexity": round(min(1.0, 0.18 * len(cats) + 0.12 * seq + 0.01 * words), 2), "domain": domain, "route": route}


# ------------------------------------------------------------------ job storage
def _save(jid: str, **cols):
    if not cols:
        return
    cols["updated"] = C.now()
    for k in ("plan", "plan_meta", "results", "board"):
        if k in cols and not isinstance(cols[k], str):
            cols[k] = K.jd(cols[k])
    sets = ", ".join(f"{k}=?" for k in cols)
    C.x(f"UPDATE jobs7 SET {sets} WHERE jid=?", (*cols.values(), jid))


def _event(jid: str, kind: str, note: str = ""):
    try:
        C.x("INSERT INTO job_events7(jid,ts,kind,note) VALUES(?,?,?,?)", (jid, C.now(), kind, K.clip(note, 300)))
    except Exception:
        pass


def _row(r) -> Dict:
    d = dict(r)
    for k in ("plan", "plan_meta", "results", "board"):
        d[k] = K.jl(d.get(k), {} if k != "plan" else [])
    return d


def get(jid: str) -> Optional[Dict]:
    r = C.q("SELECT * FROM jobs7 WHERE jid=?", (jid,))
    return _row(r[0]) if r else None


def jobs(n: int = 12, states: Optional[Tuple[str, ...]] = None) -> List[Dict]:
    rows = C.q("SELECT * FROM jobs7 ORDER BY id DESC LIMIT ?", (n * 3 if states else n,))
    out = [_row(r) for r in rows]
    if states:
        out = [j for j in out if j["state"] in states][:n]
    return out


def events(jid: str, n: int = 30) -> List[Dict]:
    return [{"when": C.iso(r["ts"]), "kind": r["kind"], "note": r["note"]} for r in C.q("SELECT * FROM job_events7 WHERE jid=? ORDER BY id DESC LIMIT ?", (jid, n))]


def _set_state(jid: str, state: str, note: str = ""):
    _save(jid, state=state)
    _event(jid, "state", f"{state}" + (f": {note}" if note else ""))
    K.emit("job.state", {"jid": jid, "state": state, "note": note})
    K.emit_ui("job_state", {"jid": jid, "state": state, "note": note})


# ------------------------------------------------------------------ runtime state
_cancel: Dict[str, threading.Event] = {}
_pending: Dict[str, Any] = {"approval": None}
_pending_lock = threading.Lock()
_queue: List[str] = []
_queue_lock = threading.Lock()
_worker = {"thread": None}
_running: Dict[str, float] = {}
_cfg: Dict[str, Callable] = {"speak_report": None}


def _speak(text: str):
    K.say(text)


def _speak_report(text: str, rep: Optional[Dict] = None):
    fn = _cfg.get("speak_report")
    if callable(fn):
        try:
            if fn(text, rep) is not False:
                return
        except Exception:
            pass
    K.say(text)


def _max_parallel() -> int:
    try:
        import friday_health7 as H
        if H.light_mode():
            return 1
    except Exception:
        pass
    try:
        return max(1, min(3, (os.cpu_count() or 2)))
    except Exception:
        return 2


# ------------------------------------------------------------------ approvals
def _ask_approval(jid: str, step: Dict, decision: Dict, args: Dict) -> bool:
    ev = threading.Event()
    rec = {"jid": jid, "step": step["id"], "tool": step["tool"], "desc": step["desc"], "event": ev, "granted": None, "spoken": decision.get("spoken", ""), "ts": time.time(), "args": args}
    with _pending_lock:
        if _pending["approval"] is not None:
            # one question at a time: wait for the earlier one to be answered
            pass
    while True:
        with _pending_lock:
            if _pending["approval"] is None:
                _pending["approval"] = rec
                break
        if _cancel.get(jid) and _cancel[jid].is_set():
            return False
        time.sleep(0.2)
    _set_state(jid, "waiting_approval", f"step {step['id'] + 1}: {step['desc']}")
    question = f"Step {step['id'] + 1}: {step['desc']}. " + (decision.get("spoken") or "Shall I go ahead?")
    K.emit_ui("approval", {"jid": jid, "step": step["id"], "tool": step["tool"], "question": question, "risk": decision.get("risk")})
    _speak(question)
    end = time.time() + APPROVAL_WAIT
    while time.time() < end and not ev.is_set():
        if _cancel.get(jid) and _cancel[jid].is_set():
            break
        ev.wait(0.25)
    with _pending_lock:
        if _pending["approval"] is rec:
            _pending["approval"] = None
    granted = bool(rec["granted"])
    _event(jid, "approval", f"step {step['id']} {'granted' if granted else 'declined or timed out'}")
    if not granted and rec["granted"] is None and not (_cancel.get(jid) and _cancel[jid].is_set()):
        _speak("I didn't get an answer, so I skipped that step.")
    if granted:
        _set_state(jid, "running")
    return granted


def awaiting() -> Optional[Dict]:
    a = _pending["approval"]
    return None if a is None else {"jid": a["jid"], "step": a["step"], "tool": a["tool"], "desc": a["desc"], "question": a["spoken"]}


def approve(granted: bool = True) -> bool:
    with _pending_lock:
        a = _pending["approval"]
    if a is None:
        return False
    a["granted"] = bool(granted)
    a["event"].set()
    try:
        import friday_security6 as SEC
        SEC.audit("user", "approval", f"{a['tool']} {'granted' if granted else 'declined'}")
    except Exception:
        pass
    return True


# ------------------------------------------------------------------ the job runner
def submit(goal: str, *, plan: Optional[Dict] = None, source: str = "user", auto: bool = False, priority: int = 5, intent: Optional[str] = None,
           budget_s: float = DEFAULT_BUDGET, path: str = ".", speak: bool = True, start: bool = True) -> str:
    goal = (goal or "").strip()
    jid = K.new_id("J")
    C.x("INSERT INTO jobs7(jid,created,updated,goal,state,intent,source,priority,plan,plan_meta,results,board,budget_s,auto,session,path,speak) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (jid, C.now(), C.now(), goal, "queued", intent or "", source, priority, K.jd((plan or {}).get("steps", [])), K.jd({k: v for k, v in (plan or {}).items() if k != "steps"}), "{}", "{}",
         budget_s, int(auto), K.SESSION_ID, path, int(speak)))
    _event(jid, "submitted", f"{'auto ' if auto else ''}goal: {goal[:120]}")
    _cancel[jid] = threading.Event()
    with _queue_lock:
        _queue.append(jid)
    K.emit("job.submitted", {"jid": jid, "goal": goal})
    if start:
        _kick()
    return jid


def _kick():
    with _queue_lock:
        t = _worker["thread"]
        if t is not None and t.is_alive():
            return
        t = threading.Thread(target=_worker_loop, name="Friday7Jobs", daemon=True)
        _worker["thread"] = t
        t.start()


def _worker_loop():
    while True:
        with _queue_lock:
            jid = _queue.pop(0) if _queue else None
        if jid is None:
            return
        try:
            run_job(jid)
        except Exception as exc:
            C.log(f"job {jid} crashed safely: {exc}", "recovery")
            _save(jid, error=f"{type(exc).__name__}: {exc}"[:300], ended=C.now())
            _set_state(jid, "failed", "internal error")
            try:
                import friday_health7 as H
                H.incident("orchestrator", f"job {jid} crashed: {exc}", "error")
            except Exception:
                pass


def _stopped(jid: str) -> bool:
    ev = _cancel.get(jid)
    if ev is not None and ev.is_set():
        return True
    try:
        import friday_tasks6 as TASK
        return TASK.STOP.is_set()
    except Exception:
        return False


def _ctx_for(job: Dict, plan: List[Dict], results: Dict[str, Any]) -> Dict[str, Any]:
    ctx = {"goal": job["goal"], "path": job.get("path") or ".", "prev": ""}
    for s in plan:
        if s["status"] == "done":
            out = results.get(str(s["id"]), {}).get("output", "")
            ctx["s%d" % s["id"]] = out
            ctx["prev"] = out
    return ctx


def _run_step(jid: str, job: Dict, step: Dict, ctx: Dict, deadline: float, plan_info: Dict, results: Dict, board: Dict) -> Dict:
    """Execute one step. Returns {"ok", "receipt", "failure": {...}|None, "skipped": bool}."""
    name = step["tool"]
    if not registry.has(name):
        return {"ok": False, "receipt": None, "failure": {"class": "dependency", "error": f"tool {name} is not available"}, "skipped": False}
    entry = registry.get(name)
    args = P.fill(step.get("args", {}), ctx)
    # policy: allow / ask / deny (instructions from webpages or documents never trigger an action)
    dec = POL.decide(name, args, source=job.get("source", "user"), job=jid)
    if dec["decision"] == "deny":
        _event(jid, "policy", f"step {step['id']} {name}: denied - {dec['reason']}")
        return {"ok": False, "receipt": None, "failure": {"class": "permission", "error": dec["reason"]}, "skipped": step.get("optional", False), "denied": True}
    if dec["decision"] == "ask":
        if job.get("source") != "user" and job.get("auto") and not job.get("speak"):
            granted = False
        else:
            granted = _ask_approval(jid, step, dec, args)
        if not granted:
            return {"ok": False, "receipt": None, "failure": {"class": "permission", "error": "you did not approve this step"}, "skipped": True}
    post = P.fill(step.get("post") or entry.get("post") or {}, ctx)
    remaining = max(5.0, deadline - time.time())
    base_timeout = entry.get("timeout", 60.0)
    try:                                                    # an approved self-improvement may have raised this tool's time limit (bounded to 5 minutes)
        ov = K.cfg_get("tool_timeout:" + name, "")
        if ov:
            base_timeout = max(base_timeout, min(300.0, float(ov)))
    except Exception:
        pass
    rec = V.execute(entry["fn"], args, tool=name, post=post or None, job=jid, step=step["id"], idempotent=entry.get("idempotent", True),
                    timeout=min(base_timeout, remaining), cancel=_cancel.get(jid))
    if not rec["ok"]:
        return {"ok": False, "receipt": rec, "failure": {"class": rec.get("failure_class") or "unknown", "error": rec.get("error", "")}, "skipped": False}
    chk = P.check_intermediate(step, {"output": rec.get("output", ""), **(rec.get("result") or {})})
    if not chk["ok"]:
        return {"ok": False, "receipt": rec, "failure": {"class": "verification", "error": "; ".join(chk["issues"]), "issues": chk["issues"]}, "skipped": False}
    return {"ok": True, "receipt": rec, "failure": None, "skipped": False}


def run_job(jid: str) -> Dict:
    job = get(jid)
    if not job:
        return {"ok": False, "status": "missing"}
    if job["state"] in TERMINAL:
        return {"ok": job["state"] == "done", "status": job["state"], "report": job.get("report", "")}
    cancel = _cancel.setdefault(jid, threading.Event())
    t0 = time.time()
    _running[jid] = t0
    _save(jid, started=job.get("started") or t0)
    try:
        # ---------------- planning (or resuming a stored plan)
        _set_state(jid, "planning")
        plan_info = {"steps": job["plan"], **(job["plan_meta"] or {})} if job["plan"] else None
        resumed = bool(plan_info and any(s.get("status") == "done" for s in plan_info["steps"]))
        if not plan_info:
            hints = []
            try:
                import friday_learning7 as LRN
                h = LRN.hint_for(job["goal"])
                hints = [h] if h else []
            except Exception:
                pass
            plan_info = P.make_plan(job["goal"], job.get("intent"), registry, hints=hints)
            try:
                import friday_learning7 as LRN
                plan_info = LRN.adjust_plan(plan_info, job["goal"])
            except Exception:
                pass
            _event(jid, "plan", plan_info.get("rationale", ""))
            _save(jid, plan=plan_info["steps"], plan_meta={k: v for k, v in plan_info.items() if k != "steps"})
        plan: List[Dict] = plan_info["steps"]
        results: Dict[str, Any] = job["results"] or {}
        board: Dict[str, Any] = job["board"] or {}
        if resumed:
            for s in plan:
                if s["status"] in ("running", "retry"):
                    s["status"] = "pending"
            _event(jid, "resume", f"{sum(1 for s in plan if s['status'] == 'done')} step(s) already done and verified")
        if job.get("speak") and len(plan) > 1 and not resumed:
            _speak(f"Right. {len(plan)} steps, each one checked: " + "; ".join(s["desc"] for s in plan[:4]) + ("..." if len(plan) > 4 else "."))
        # ---------------- execution
        _set_state(jid, "running")
        deadline = t0 + float(job.get("budget_s") or DEFAULT_BUDGET)
        revisions = int(job.get("revisions") or 0)
        tried: set = set()
        receipts: List[Dict] = []
        guard = 0
        while True:
            guard += 1
            if guard > 60:
                _event(jid, "guard", "too many scheduling rounds")
                break
            if _stopped(jid):
                break
            if time.time() > deadline:
                _event(jid, "timeout", "time budget exhausted")
                break
            pending = [s for s in plan if s["status"] == "pending"]
            if not pending:
                break
            for s in pending:   # dependants of a failed/skipped step cannot run
                if any(next((x for x in plan if x["id"] == d), {"status": "done"})["status"] in ("failed", "skipped", "cancelled") for d in s["depends"]):
                    s["status"] = "skipped"
                    s["error"] = "a step it depends on did not complete"
            ready = [s for s in plan if s["status"] == "pending" and all(next((x for x in plan if x["id"] == d), {"status": "done"})["status"] == "done" for d in s["depends"])]
            if not ready:
                break
            batch = ready[:_max_parallel()]
            ctx = _ctx_for(job, plan, results)
            for s in batch:
                s["status"] = "running"
                s["attempts"] = int(s.get("attempts", 0)) + 1
            _save(jid, plan=plan)
            if len(batch) == 1:
                outs = [(batch[0], _run_step(jid, job, batch[0], dict(ctx), deadline, plan_info, results, board))]
            else:
                with ThreadPoolExecutor(max_workers=len(batch), thread_name_prefix="F7step") as ex:
                    futs = {ex.submit(_run_step, jid, job, s, dict(ctx), deadline, plan_info, results, board): s for s in batch}
                    wait(list(futs))
                    outs = [(futs[f], f.result()) for f in futs]
            revised = False
            for s, out in outs:
                rec = out.get("receipt")
                if rec:
                    receipts.append(rec)
                if out["ok"]:
                    s["status"] = "done"
                    flagged = bool((rec.get("result") or {}).get("flagged"))
                    claim = rec.get("output", "") if s["tool"] == "critic_review" else rec.get("claim", "")
                    results[str(s["id"])] = {"output": rec.get("output", ""), "path": rec.get("path", ""), "claim": claim, "status": rec.get("status"), "tool": s["tool"], "flagged": flagged}
                    board["s%d" % s["id"]] = K.clip(rec.get("output", ""), 3000)
                    cid = V.save_checkpoint(jid, f"step{s['id']}:{s['tool']}", {"results": results, "board": board}, verified=(rec.get("status") == "verified"))
                    _event(jid, "step", f"{s['id'] + 1}. {s['desc']} -> {rec.get('claim', 'ok')}")
                    K.emit("step.done", {"jid": jid, "step": s["id"], "tool": s["tool"], "status": rec.get("status")})
                    K.emit_ui("step", {"jid": jid, "step": s["id"], "desc": s["desc"], "status": rec.get("status"), "claim": rec.get("claim", "")})
                    continue
                fail = out.get("failure") or {"class": "unknown", "error": "failed"}
                s["error"] = fail.get("error", "")
                _event(jid, "failure", f"step {s['id'] + 1} {s['tool']}: [{fail['class']}] {fail.get('error', '')[:160]}")
                if out.get("skipped"):
                    s["status"] = "skipped"
                    continue
                if revisions < P.MAX_REVISIONS and fail["class"] not in ("cancelled",) and not _stopped(jid) and not out.get("denied"):
                    rv = P.revise({"steps": plan, "branches": plan_info.get("branches", [])}, s["id"], fail, registry, tried)
                    if rv:
                        revisions += 1
                        plan_info["steps"] = plan = rv["steps"]
                        for c in rv["changes"]:
                            _event(jid, "revise", c)
                        _save(jid, plan=plan, revisions=revisions)
                        revised = True
                        K.emit("job.revised", {"jid": jid, "changes": rv["changes"], "strategy": rv["strategy"]})
                        continue
                s["status"] = "failed"
            if revised:
                _set_state(jid, "running", "plan revised")
            _save(jid, plan=plan, results=results, board=board)
        # ---------------- verification summary + finish
        _set_state(jid, "verifying")
        for s in plan:
            if s["status"] in ("pending", "running"):
                s["status"] = "cancelled" if _stopped(jid) else "skipped"
        done = [s for s in plan if s["status"] == "done"]
        needed = [s for s in plan if not s.get("optional")]
        needed_done = [s for s in needed if s["status"] == "done"]
        if _stopped(jid):
            state = "cancelled"
        elif len(needed_done) == len(needed) and needed:
            state = "done"
        elif done:
            state = "partial"
        else:
            state = "failed"
        rep = build_report(job, plan, results, state, time.time() - t0, receipts)
        _save(jid, plan=plan, results=results, board=board, state=state, report=rep["text"], ended=C.now(), revisions=revisions)
        _event(jid, "finished", f"{state}: {rep['summary']}")
        K.emit("job.state", {"jid": jid, "state": state, "note": rep["summary"]})
        K.emit("job.done", {"jid": jid, "goal": job["goal"], "state": state, "plan": plan, "plan_meta": plan_info, "verified_ratio": rep["verified_ratio"],
                            "failures": rep["failures"], "seconds": round(time.time() - t0, 1), "revisions": revisions, "auto": bool(job.get("auto")), "report": rep["text"]})
        K.emit_ui("job_done", {"jid": jid, "state": state, "summary": rep["summary"]})
        if job.get("speak"):
            _speak_report(rep["spoken"], rep)
        return {"ok": state == "done", "status": state, "report": rep["text"], "jid": jid}
    finally:
        _running.pop(jid, None)


def build_report(job: Dict, plan: List[Dict], results: Dict, state: str, seconds: float, receipts: List[Dict]) -> Dict:
    """Honest reporting: only what the receipts confirm."""
    done = [s for s in plan if s["status"] == "done"]
    bad = [s for s in plan if s["status"] in ("failed", "skipped", "cancelled") and not (s.get("optional") and s["status"] == "skipped")]
    ver = sum(1 for s in done if results.get(str(s["id"]), {}).get("status") == "verified")
    head = {"done": "Completed", "partial": "Partly completed", "failed": "Could not complete", "cancelled": "Cancelled"}.get(state, state)
    lines = [f"{head}: {job['goal']}", f"{len(done)} of {len(plan)} step(s) succeeded, {ver} independently verified, in {seconds:.0f}s."]
    for s in plan:
        r = results.get(str(s["id"]), {})
        mark = {"done": "✓" if r.get("status") == "verified" else "~", "failed": "✗", "skipped": "-", "cancelled": "-"}.get(s["status"], "?")
        lines.append(f"  {mark} {s['id'] + 1}. {s['desc']}" + (f" - {r.get('claim')}" if r.get("claim") else f" - {s.get('error', s['status'])}"))
    # the answer: the last content-bearing step output
    answer = ""
    for s in reversed(done):
        out = results.get(str(s["id"]), {}).get("output", "")
        if s["tool"] in ("synthesize", "think", "compare_costs", "cost_recipe", "investigate", "budget_check", "finance_snapshot") and len(out.strip()) > 20:
            answer = out.strip()
            break
    if not answer and done:
        answer = results.get(str(done[-1]["id"]), {}).get("output", "").strip()
    saved = [results[str(s["id"])]["path"] for s in done if results.get(str(s["id"]), {}).get("path")]
    warn = [results[str(s["id"])]["output"] for s in done if results.get(str(s["id"]), {}).get("flagged")]
    text = "\n".join(lines) + (("\n\n" + answer) if answer else "")
    if warn:
        text += "\n\n⚠ The independent check found a problem: " + " ".join(warn)
    if saved:
        text += "\n\nSaved: " + ", ".join(saved)
    if bad:
        text += "\n\nNot completed: " + "; ".join(f"{s['desc']} ({s.get('error', s['status'])[:80]})" for s in bad[:3])
    spoken = f"{head}. {len(done)} of {len(plan)} steps worked and {ver} were independently verified."
    if warn:
        spoken += " Careful, sir: my independent check found a problem. " + K.clip(warn[0], 220)
    spoken_head = spoken
    if answer:
        spoken += " " + K.clip(re.sub(r"\s+", " ", answer.replace("#", "").replace("*", "")), 520)
    spoken_tail = ""
    if saved:
        spoken_tail += " I saved it as " + os.path.basename(saved[-1]) + "."
    if bad:
        spoken_tail += f" I could not finish: {bad[0]['desc']}."
    spoken += spoken_tail
    return {"text": text, "spoken": spoken, "spoken_head": spoken_head, "answer": answer, "spoken_tail": spoken_tail.strip(), "summary": f"{len(done)}/{len(plan)} steps, {ver} verified", "verified_ratio": (ver / len(done)) if done else 0.0,
            "failures": [{"step": s["id"], "tool": s["tool"], "error": s.get("error", "")} for s in bad], "warnings": warn}


# ------------------------------------------------------------------ control
def cancel(jid: Optional[str] = None) -> int:
    """Cancel one job (or the newest unfinished one). Returns how many were cancelled."""
    targets = [jid] if jid else [j["jid"] for j in jobs(5, ("queued", "planning", "running", "waiting_approval", "paused"))][:1]
    n = 0
    for j in targets:
        ev = _cancel.setdefault(j, threading.Event())
        ev.set()
        a = _pending["approval"]
        if a is not None and a["jid"] == j:
            a["granted"] = False
            a["event"].set()
        with _queue_lock:
            if j in _queue:
                _queue.remove(j)
                _save(j, state="cancelled", ended=C.now())
                _event(j, "cancelled", "before it started")
        row = get(j)
        if row and row["state"] in ("paused",):
            _save(j, state="cancelled", ended=C.now())
        n += 1
    return n


def cancel_all() -> int:
    n = 0
    for j in jobs(30, ("queued", "planning", "running", "waiting_approval", "paused")):
        n += cancel(j["jid"])
    return n


def resume(jid: Optional[str] = None) -> Optional[str]:
    """Resume a paused/interrupted job from its last verified step."""
    if jid is None:
        c = jobs(5, ("paused", "failed", "partial"))
        jid = c[0]["jid"] if c else None
    if not jid:
        return None
    job = get(jid)
    if not job or job["state"] == "running":
        return None
    _cancel[jid] = threading.Event()
    plan = job["plan"]
    for s in plan:
        if s["status"] in ("failed", "skipped", "cancelled", "running"):
            s["status"], s["attempts"], s["error"] = "pending", 0, ""
    _save(jid, plan=plan, state="queued", ended=None)
    _event(jid, "resume", "requested")
    with _queue_lock:
        _queue.append(jid)
    _kick()
    return jid


def recover() -> List[str]:
    """After a restart: anything that was mid-flight is marked paused (nothing is silently lost or silently re-run)."""
    out = []
    for j in jobs(30, ("planning", "running", "waiting_approval", "verifying", "queued")):
        _save(j["jid"], state="paused")
        _event(j["jid"], "interrupted", "FRIDAY restarted; say 'resume the mission' to continue from the last verified step")
        out.append(j["jid"])
    return out


def status() -> Dict:
    return {"running": list(_running), "queued": list(_queue), "awaiting": awaiting(), "tools": len(registry.names()), "recent": [{"jid": j["jid"], "goal": j["goal"][:80], "state": j["state"]} for j in jobs(6)]}


def configure(**kw):
    _cfg.update({k: v for k, v in kw.items() if v is not None})


# ------------------------------------------------------------------ auto-orchestration (narrow, late trigger)
def maybe_auto(command: str) -> Optional[str]:
    """If a request clearly contains several separate actions (research, then cost, then save ...) run it as one verified job.
    Returns the job id, or None to let the normal route answer."""
    if not K.cfg_flag("auto_orchestrate"):
        return None
    t = K.strip_wake(command)
    ci = classify_intent(t)
    if ci["intent"] != "mission" or not ci["multi_step"] or ci["steps_hint"] < 3 and not ci["explicit"]:
        return None
    if re.search(r"\b(?:you|your|yourself|friday)\b.*\b(?:work|do|handle)\b", t.lower()) and len(ci["actions"]) < 3:
        return None
    return submit(t, auto=True, intent=ci["domain"], source="user")


# ------------------------------------------------------------------ chat commands
_YES = re.compile(r"^(?:yes|yeah|yep|yup|sure|ok|okay|go ahead|do it|approve|approved|proceed|please do|go on|confirm|affirmative)\b[ ,.!]*(?:please|sir)?[ .!]*$", re.I)
_NO = re.compile(r"^(?:no|nope|nah|don'?t|do not|stop|cancel that|decline|deny|negative|skip it|skip that)\b[ ,.!]*(?:sir|please)?[ .!]*$", re.I)


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if not t:
        return None
    if _pending["approval"] is not None:
        if _YES.match(t):
            approve(True)
            return "Going ahead."
        if _NO.match(t):
            approve(False)
            return "Understood, I won't do that."
    m = re.match(r"^(?:run|do|start|handle)\s+(?:this|that|it)\s+as\s+(?:a\s+)?(?:mission|job|verified task)[:,]?\s*(.+)$", t) or re.match(r"^(?:mission|verified mission|run a mission|start a mission)[:,]?\s+(.+)$", t) \
        or re.match(r"^plan and do[:,]?\s+(.+)$", t)
    if m:
        goal = re.sub(r"^(?:to\s+)?", "", m.group(1)).strip()
        raw = K.strip_wake(command)
        mm = re.search(r"(?:mission|job|verified task|plan and do)[:,]?\s*(.+)$", raw, re.I)
        jid = submit(mm.group(1).strip() if mm else goal, intent=classify_intent(goal)["domain"])
        return f"On it. That's mission {jid.split('-')[-1]}; I'll check every step and report what is actually confirmed."
    m = re.match(r"^(?:how would you|what(?:'s| is) your plan(?: for| to)?|plan (?:out )?(?:how to)?|show (?:me )?(?:your|the) plan(?: for)?)\s+(.+)$", t)
    if m and re.search(r"\b(?:how would you|your plan|show)\b", t):
        info = P.make_plan(m.group(1).strip(), None, registry)
        return P.explain(info) + f" ({info['rationale']})"
    if re.match(r"^(?:what missions(?: are (?:you )?(?:running|working on|in progress|active))?|show (?:me )?(?:my )?missions|mission status|what are you working on|what(?:'s| is) running|list (?:my )?missions)\??$", t):
        js = jobs(5)
        if not js:
            return "No missions yet."
        return "Recent missions: " + "; ".join(f"{j['goal'][:48]} is {j['state'].replace('_', ' ')}" for j in js[:4]) + "."
    if re.match(r"^(?:cancel|stop|abort)\s+(?:the\s+|that\s+|this\s+|my\s+)?(?:current\s+)?(?:mission|job)s?$", t):
        n = cancel()
        return "Cancelled the current mission." if n else "There's no mission running."
    if re.match(r"^(?:cancel|stop) all (?:missions|jobs)$", t):
        return f"Cancelled {cancel_all()} mission(s)."
    if re.match(r"^(?:resume|continue|carry on with)\s+(?:the\s+|that\s+|my\s+)?(?:last\s+|interrupted\s+|paused\s+)?(?:mission|job)$", t):
        j = resume()
        return "Resuming from the last verified step." if j else "There's no interrupted mission to resume."
    if re.match(r"^(?:show|what were|read)\s+(?:me\s+)?(?:the\s+|my\s+|your\s+)?(?:last\s+|latest\s+|recent\s+)?(?:receipts?|what you did|what you(?:'ve| have) done)\??$", t) or t in ("what did you do", "what did you just do"):
        rs = V.receipts(n=4)
        if not rs:
            return "I haven't run anything that needs a receipt yet."
        return " ".join(V.spoken(r) for r in rs[:3])
    return None


def ui_snapshot() -> Dict:
    return {"status": status(), "jobs": [{"jid": j["jid"], "goal": j["goal"], "state": j["state"], "created": C.iso(j["created"]), "revisions": j["revisions"], "auto": bool(j["auto"]),
                                         "steps": [{"id": s["id"], "desc": s["desc"], "tool": s["tool"], "status": s["status"]} for s in j["plan"]], "report": j.get("report", "")} for j in jobs(10)],
            "tools": registry.describe(), "receipts": V.receipts(n=10), "stats": V.stats()}


def install_default_tools():
    registry.sync_from_tasks()
