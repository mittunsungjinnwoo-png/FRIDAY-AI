/* FRIDAY 7.0 Command Centre - one page, thirteen tabs, all driven by the Python backend over the FRIDAY_V6:: channel.
   Shows real state only (queue, memory, permissions, audit chain, resources). Nothing here animates for show. */
(function () {
  'use strict';
  var B = window.fridayBridge || null;
  var TABS = ['Overview', 'Tasks', 'Memory', 'Agents', 'Emotion', 'Security', 'Performance', 'Research', 'Study', 'Productivity', 'Engineering', 'Integrations', 'Evaluation'];
  var S = { tab: 'Overview', data: {}, arg: '', progress: null, timer: null };
  var CARDS = JSON.parse(localStorage.getItem('f6cards') || 'null') || { briefing: true, emotion: true, tasks: true, hardware: true };

  function h(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function dec(b) { return decodeURIComponent(escape(atob(b))); }
  function send(o) { if (B && B.v6) B.v6(o); }
  function ask(tab, arg) { send({ op: 'snapshot', tab: tab.toLowerCase(), arg: arg || '' }); }
  function act(a, extra, tab) { var o = { op: 'action', action: a, tab: (tab || S.tab).toLowerCase() }; for (var k in (extra || {})) o[k] = extra[k]; send(o); }
  function toastx(t) { if (typeof toast === 'function') toast(t); }
  function bar(label, v, warn) { v = Math.max(0, Math.min(1, Number(v) || 0)); return '<div class="mr6"><span>' + h(label) + '</span><div class="m6" role="meter" aria-label="' + h(label) + '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(v * 100) + '"><i style="width:' + Math.round(v * 100) + '%;' + (warn && v > 0.85 ? 'background:var(--bad)' : '') + '"></i></div><b>' + Math.round(v * 100) + '%</b></div>'; }
  function tbl(head, rows) { return '<table><tr>' + head.map(function (x) { return '<th>' + h(x) + '</th>'; }).join('') + '</tr>' + (rows.length ? rows.join('') : '<tr><td colspan="' + head.length + '" class="note">Nothing yet.</td></tr>') + '</table>'; }
  function row(cells) { return '<tr>' + cells.map(function (c) { return '<td>' + c + '</td>'; }).join('') + '</tr>'; }
  function grp(title, body, note) { return '<div class="sg"><h4>' + h(title) + '</h4>' + (note ? '<p class="note">' + h(note) + '</p>' : '') + body + '</div>'; }
  function btn(label, a, extra, cls) { return '<button class="btn ' + (cls || '') + '" data-a="' + h(a) + '" data-x="' + h(JSON.stringify(extra || {})) + '">' + h(label) + '</button>'; }

  /* ------------------------------------------------------------ tab renderers */
  var R = {};
  R.Overview = function (d) {
    var st = (d.status || {}), hud = st.hud || {}, em = (d.emotion || {}).state || {}, tk = d.tasks || {};
    var out = '<div class="grid6">';
    out += '<div class="sg"><h4>FRIDAY ' + h(st.version || '7.0') + '</h4><p class="note">Hardware profile: ' + h(st.hardware || '-') + ' · Task engine: ' + (hud.stopped ? '<span class="bad">stopped</span>' : '<span class="ok">ready</span>') + ' · ' + (hud.tasks || 0) + ' queued/running</p>' + btn('Emergency stop', 'emergency_stop', {}, 'bad6') + ' ' + btn('Resume tasks', 'resume_engine', {}, 'g') + ' ' + btn('Run evaluation', 'run_eval', {}, 'g') + '</div>';
    if (CARDS.briefing) out += grp('Today', '<p>' + h(d.briefing || '') + '</p>');
    if (CARDS.emotion) out += grp('Simulated state', Object.keys(em).map(function (k) { return bar(k, em[k], k === 'frustration' || k === 'concern'); }).join(''), 'A behavioural simulation that shapes wording, length and memory recall - not a claim of feelings.');
    if (CARDS.tasks) out += grp('Live tasks', (tk.queue || []).length ? (tk.queue || []).map(function (t) { return '<div class="li"><span>#' + t.id + ' ' + h(t.goal) + '</span><span class="note">' + h(t.status) + ' · ' + t.steps.filter(function (s) { return s.status === 'done'; }).length + '/' + t.steps.length + '</span></div>'; }).join('') : '<p class="note">No tasks running.</p>');
    out += '</div>';
    out += grp('Customise this dashboard', Object.keys(CARDS).map(function (k) { return '<label class="tgl"><input type="checkbox" data-card="' + k + '" ' + (CARDS[k] ? 'checked' : '') + '> ' + h(k) + '</label>'; }).join(''));
    return out;
  };
  R.Tasks = function (d) {
    var out = grp('Give FRIDAY a task', '<div class="row"><input id="f6goal" placeholder="e.g. research the best budget laptops, then write a short report" aria-label="Task goal"><button class="btn" id="f6go">Queue task</button></div>' + btn('Emergency stop', 'emergency_stop', {}, 'bad6') + ' ' + btn('Resume engine', 'resume_engine', {}, 'g'),
      'FRIDAY plans, runs approved tools, verifies each step, retries with a different strategy, and reports honestly what was completed, failed or only partly done.');
    if (d.awaiting) out += '<div class="tip"><b>Approval needed</b> - task #' + d.awaiting.task + ' ' + h(d.awaiting.desc) + '<div class="row">' + btn('Approve', 'approve', { value: true }) + btn('Deny', 'approve', { value: false }, 'g') + '</div></div>';
    if (S.progress) out += '<div class="mr6"><span>Progress</span><div class="m6"><i style="width:' + Math.round(100 * S.progress.done / Math.max(1, S.progress.total)) + '%"></i></div><b>' + S.progress.done + '/' + S.progress.total + '</b></div>';
    out += grp('Queue', (d.queue || []).length ? (d.queue || []).map(function (t) {
      return '<div class="sg"><b>#' + t.id + '</b> ' + h(t.goal) + ' <span class="note">(' + h(t.status) + ', priority ' + t.priority + ')</span> ' + btn('Cancel', 'cancel_task', { id: t.id }, 'g') +
        '<div class="steps6">' + t.steps.map(function (s) { return '<div class="' + (s.status === 'done' ? 'ok' : (s.status === 'failed' || s.status === 'skipped' ? 'bad' : '')) + '">' + (s.status === 'done' ? '✔' : s.status === 'failed' ? '✖' : s.status === 'running' ? '…' : '○') + ' ' + h(s.desc) + ' <small class="note">[' + h(s.tool) + ']' + (s.error ? ' ' + h(s.error) : '') + '</small></div>'; }).join('') + '</div></div>';
    }).join('') : '<p class="note">The queue is empty.</p>');
    out += grp('History', tbl(['#', 'Goal', 'Status', 'Report'], (d.history || []).map(function (t) { return row(['#' + t.id, h(t.goal), '<span class="' + (t.status === 'done' ? 'ok' : 'bad') + '">' + h(t.status) + '</span>', '<small>' + h(t.report) + '</small>']); })));
    out += grp('Available tools', '<pre class="term6">' + h((d.tools || []).join('\n')) + '</pre>');
    return out;
  };
  R.Memory = function (d) {
    var out = grp('Memory browser', '<div class="row"><input id="f6mq" value="' + h(S.arg) + '" placeholder="Search by meaning, e.g. what theme do I like" aria-label="Search memory"><button class="btn" id="f6ms">Search</button></div>' +
      tbl(['Date', 'Kind', 'Memory', 'Status', 'Imp.', ''], (d.memories || []).map(function (m) { return row([h(m.date), h(m.kind), h(m.text), '<span class="' + (m.status === 'confirmed' ? 'ok' : 'note') + '">' + h(m.status) + '</span>', m.importance, '<button class="btn g" data-a="delete_memory" data-x="' + h(JSON.stringify({ id: m.id, arg: S.arg })) + '" aria-label="Delete memory">✕</button>']); })),
      'Every memory has a date and a status. Newer confirmed facts supersede older ones; nothing is invented.');
    out += grp('Reminders & follow-ups', tbl(['Reminder', 'Due', 'Repeat'], (d.reminders || []).map(function (r) { return row([h(r.text), h(r.due), h(r.repeat || '-')]); })));
    var g = d.graph || { edges: [] };
    out += grp('Knowledge graph', (g.edges || []).length ? '<ul>' + g.edges.map(function (e) { return '<li>' + h(e.a) + ' <i>' + h(e.rel) + '</i> ' + h(e.b) + '</li>'; }).join('') + '</ul>' : '<p class="note">No connections learned yet.</p>');
    out += grp('Daily summaries', (d.summaries || []).map(function (s) { return '<p><b>' + h(s.day) + '</b> ' + h(s.text) + '</p>'; }).join('') || '<p class="note">None yet.</p>');
    out += grp('Control', '<p class="note">Retention: ' + h(d.retention_days) + ' · Encrypted export ' + (d.encryption ? 'available' : 'needs the cryptography package') + '. Say "retention 90 days" to change it.</p>' + btn('Export memory', 'export_memory', { encrypt: false }, 'g') + ' ' + btn('Export encrypted', 'export_memory', { encrypt: true }, 'g'));
    return out;
  };
  R.Agents = function (d) {
    return grp('Specialist agents', tbl(['Agent', 'Role', 'Tools', 'Model'], (d.roster || []).map(function (a) { return row([h(a.agent), h(a.role), h((a.tools || []).join(', ')), h(a.model)]); })), 'FRIDAY coordinates; only the specialists a request needs are used.') +
      grp('What coordination costs (measured)', tbl(['Agents used', 'Runs', 'Avg ms', 'Conflict rate', 'Confidence', 'Escalations'], ((d.stats || {}).by_agent_count || []).map(function (r) { return row([r.agents, r.runs, r.avg_ms, r.conflict_rate, r.avg_confidence, r.escalation_rate]); })), 'More agents do not automatically mean more intelligence - so this is measured.');
  };
  R.Emotion = function (d) {
    var em = d.state || {}, s = d.settings || {}, r = d.relationship || {};
    return grp('Emotional state (simulated)', Object.keys(em).map(function (k) { return bar(k, em[k]); }).join(''), 'Perception → Memory → Emotional state → Reasoning → Action → Reflection. These variables decay toward calm and genuinely change tone, reply length and recall.') +
      grp('Personality', '<label class="tgl"><input type="checkbox" id="f6hum" ' + (s.humour ? 'checked' : '') + '> Light humour</label><div class="rng"><span>Sarcasm</span><input type="range" id="f6sar" min="0" max="2" value="' + (s.sarcasm || 0) + '" aria-label="Sarcasm level"><output>' + (s.sarcasm || 0) + '</output></div>') +
      grp('What I have learned about how you work', '<p>Prefers <b>' + h(r.depth_pref) + '</b> answers · technical level ' + h(r.technical) + ' · ' + (r.interactions || 0) + ' interactions</p><p class="note">Projects: ' + h((r.projects || []).join(', ') || '-') + ' · Delegates: ' + h((r.delegates || []).join(', ') || '-') + ' · Repeated slips: ' + h((r.mistakes || []).join('; ') || '-') + '</p>') +
      grp('Emotional memory', tbl(['When', 'Feeling', 'About', 'Outcome'], (d.events || []).map(function (e) { return row([h(e.when), h(e.feeling), h(e.topic), h(e.outcome)]); })));
  };
  R.Security = function (d) {
    var ch = d.chain || {}, se = d.sensors || {};
    return grp('Sensors', ['microphone', 'camera', 'screen'].map(function (k) { return '<span class="chip ' + (se[k] ? 'bad' : 'ok') + '">' + k + ': ' + (se[k] ? 'ON' : 'off') + '</span>'; }).join(' '), 'Camera and screen use is always explicit and shows an indicator.') +
      grp('Tool permissions (least privilege)', (d.permissions || []).map(function (p) { return '<label class="tgl"><input type="checkbox" data-perm="' + h(p.tool) + '" ' + (p.allowed ? 'checked' : '') + '> ' + h(p.tool.replace(/_/g, ' ')) + ' <small class="note">(' + h(p.risk) + ')</small></label>'; }).join('')) +
      grp('Audit log', '<p class="' + (ch.ok ? 'ok' : 'bad') + '">' + (ch.ok ? 'Tamper-evident chain intact (' + ch.checked + ' entries)' : 'Chain broken at entry ' + ch.broken_at) + '</p>' + tbl(['When', 'Who', 'Action', 'Detail', 'Result'], (d.audit || []).map(function (a) { return row([h(a.when), h(a.actor), h(a.action), h(a.detail), h(a.result)]); }))) +
      grp('Backups & scans', btn('Back up now', 'backup', {}, 'g') + ' ' + btn('Scan dependencies', 'dependency_scan', {}, 'g') + '<p class="note">' + h((d.backups || []).join(' · ') || 'No backups yet.') + '</p>');
  };
  R.Performance = function (d) {
    var r = d.resources || {}, hp = d.hardware || {}, m = d.models || {};
    return grp('System monitor', bar('CPU', (r.cpu || 0) / 100, true) + bar('Memory', (r.ram || 0) / 100, true) + bar('Disk', (r.disk || 0) / 100, true) + (r.battery != null ? bar('Battery', r.battery / 100) : '') + '<p class="note">FRIDAY process: ' + h(r.process_mb) + ' MB · hardware profile <b>' + h(hp.level) + '</b>' + (hp.stressed ? ' · <span class="bad">under load</span>' : '') + '</p>') +
      grp('Model routing', '<select id="f6route" aria-label="Model routing"><option value="auto">Automatic (best provider per task)</option><option value="cloud">Cloud only</option><option value="local">Local only (Ollama)</option></select><p class="note">Providers: ' + (m.providers || []).map(function (p) { return h(p.name) + ' (' + h(p.kind) + (p.healthy ? '' : ', cooling down') + ')'; }).join(', ') + ' · cache entries ' + h(m.cache_entries) + '</p>' +
        tbl(['Provider', 'Tier', 'Calls', 'Avg ms', 'Reliability'], (m.routes || []).map(function (x) { return row([h(x.provider), h(x.tier), x.calls, x.avg_ms, Math.round(x.reliability * 100) + '%']); })));
  };
  R.Research = function (d) {
    return grp('Research notebook', (d.topics || []).length ? (d.topics || []).map(function (t) {
      return '<div class="sg"><b>' + h(t.topic) + '</b>' + tbl(['Source', 'Grade', 'Reliability', 'Published'], (t.sources || []).map(function (s) { return row(['<small>' + h(s.title || s.url) + '</small>', h(s.grade), Math.round(s.score * 100) + '%', h(s.pub || '-')]); })) +
        (t.claims || []).map(function (c) { return '<div class="li"><span>' + h(c.text) + '</span><span class="note">' + h(c.kind) + '</span></div>'; }).join('') + ((t.questions || []).length ? '<p class="note">Open questions: ' + h(t.questions.join('; ')) + '</p>' : '') + '</div>';
    }).join('') : '<p class="note">Say "research <topic>" - sources are graded, claims labelled fact / estimate / speculation, and conflicts compared.</p>');
  };
  R.Study = function (d) {
    var a = d.analytics || {};
    return grp('Subjects', '<p>' + h((d.subjects || []).join(', ') || 'None yet. Say: add syllabus for physics: followed by the topics.') + '</p>') +
      grp('Mastery', tbl(['Topic', 'Accuracy', 'Attempts', 'Trend', 'Cards'], ((a.mastery) || []).map(function (m) { return row([h(m.topic), m.accuracy == null ? 'not attempted' : Math.round(m.accuracy * 100) + '%', m.attempts, m.trend, m.cards]); }))) +
      grp('Revision plan', tbl(['Topic', 'Minutes', 'Why'], (d.plan || []).map(function (p) { return row([h(p.topic), p.minutes, h(p.why)]); })), 'Prioritised from your real results, not guesses. Marking uses only mark schemes you supply.') +
      grp('Question bank', '<pre class="term6">' + h(JSON.stringify(d.bank || {}, null, 1)) + '</pre>');
  };
  R.Productivity = function (d) {
    return grp('Daily briefing', '<p>' + h(d.briefing) + '</p>') + grp('Upcoming', tbl(['Event', 'When'], (d.events || []).map(function (e) { return row([h(e.title), h(e.when)]); }))) +
      grp('Time this week', tbl(['Label', 'Hours'], Object.keys(d.time || {}).map(function (k) { return row([h(k), d.time[k]]); }))) + grp('Contacts & routines', '<p>' + h((d.contacts || []).join(', ') || 'No contacts.') + '</p><p class="note">Routines: ' + h((d.macros || []).join(', ') || 'none') + '</p>');
  };
  R.Engineering = function (d) {
    return grp('Codebase', '<p>' + h(d.map) + '</p>') + grp('Version control', '<pre class="term6">' + h(d.git) + '</pre>') +
      grp('Terminal view', '<div class="row"><input id="f6cmd" placeholder="Say or type: review the code · verify the build · run tests · git status" aria-label="Engineering command"><button class="btn" id="f6run">Run</button></div><p class="note">Results are spoken and appear in the chat.</p>');
  };
  R.Integrations = function (d) {
    var v = d.voice || {};
    return grp('Connected services & scopes', tbl(['Service', 'Scope', 'What it can access', 'Last error'], (d.integrations || []).map(function (i) { return row([h(i.name), '<small>' + h(i.scopes) + '</small>', '<small>' + h(i.access) + '</small>', h(i.last_error || '-')]); }))) +
      grp('Plugins (off until you enable them)', tbl(['Plugin', 'Enabled', 'Risky calls'], (d.plugins || []).map(function (p) { return row([h(p.name), p.enabled ? 'yes' : 'no', h((p.risky_calls || []).join(', ') || '-')]); })), 'Say "enable plugin <name>". A plugin that changes after you enable it switches itself off.') +
      grp('Voice', '<p>Voice ' + h(v.voice) + ' · speed ' + h(v.rate) + ' · language ' + h(v.language) + ' · style ' + h(v.style) + '</p><p class="note">Microphones: ' + h((v.mics || []).map(function (m) { return m.index + ': ' + m.name + (m.default ? ' (default)' : ''); }).join(' | ') || 'not listed') + '. Say "use microphone 2", "speak faster", "speak in Spanish".</p>');
  };
  R.Evaluation = function (d) {
    return grp('Continuous evaluation', btn('Run evaluation', 'run_eval', {}) + tbl(['When', 'Version', 'Score', 'Passed', 'ms'], (d.history || []).map(function (x) { return row([h(x.when), h(x.version), x.score + '%', x.passed + '/' + x.total, x.ms]); })), 'FRIDAY improves through measured, reviewed changes - never by silently rewriting her own code.') +
      grp('Suggestions from real failures', '<ul>' + (d.suggestions || []).map(function (s) { return '<li>' + h(s) + '</li>'; }).join('') + '</ul>') +
      grp('Patch proposals', tbl(['#', 'Title', 'Status'], (d.patches || []).map(function (p) { return row([p.id, h(p.title), h(p.status)]); })), 'Proposed → tested on a copy → applied only with your approval → rolled back if the check fails.') +
      grp('Regression tests from past mistakes', tbl(['Prompt', 'Expected', 'Fails'], (d.regressions || []).map(function (r) { return row([h(r.prompt), h(r.expect), r.fails]); })));
  };

  /* ------------------------------------------------------------ page */
  window.centre6V = function (e) {
    var d = S.data[S.tab.toLowerCase()];
    e.innerHTML = '<h2>FRIDAY 7.0 Command Centre</h2><div class="tabs6" role="tablist">' + TABS.map(function (t) { return '<button role="tab" aria-selected="' + (t === S.tab) + '" class="' + (t === S.tab ? 'on' : '') + '" data-tab="' + t + '">' + t + '</button>'; }).join('') + '</div>' +
      '<div id="f6body">' + (d ? (R[S.tab] ? R[S.tab](d) : '') : '<p class="note">' + (B && B.v6 ? 'Loading…' : 'Open the desktop app to see live data.') + '</p>') + '</div>';
    e.querySelectorAll('[data-tab]').forEach(function (b) { b.onclick = function () { S.tab = b.dataset.tab; S.arg = ''; window.centre6V(e); ask(S.tab); }; });
    wire(e);
    if (!d) ask(S.tab);
    clearInterval(S.timer);
    if (S.tab === 'Performance' || S.tab === 'Overview' || S.tab === 'Tasks') S.timer = setInterval(function () { if (typeof V !== 'undefined' && V === 'Centre') ask(S.tab); else clearInterval(S.timer); }, 5000);
  };
  function wire(e) {
    e.querySelectorAll('[data-a]').forEach(function (b) { b.onclick = function () { var x = {}; try { x = JSON.parse(b.dataset.x || '{}'); } catch (er) {} if (x.arg != null) S.arg = x.arg; act(b.dataset.a, x); }; });
    e.querySelectorAll('[data-perm]').forEach(function (c) { c.onchange = function () { act('set_permission', { tool: c.dataset.perm, value: c.checked }); }; });
    e.querySelectorAll('[data-card]').forEach(function (c) { c.onchange = function () { CARDS[c.dataset.card] = c.checked; localStorage.setItem('f6cards', JSON.stringify(CARDS)); window.centre6V($('#view')); }; });
    var q = function (id) { return e.querySelector(id); };
    if (q('#f6go')) q('#f6go').onclick = function () { var g = q('#f6goal').value.trim(); if (g) { act('submit_task', { goal: g }); q('#f6goal').value = ''; } };
    if (q('#f6ms')) q('#f6ms').onclick = function () { S.arg = q('#f6mq').value; ask('Memory', S.arg); };
    if (q('#f6mq')) q('#f6mq').onkeydown = function (ev) { if (ev.key === 'Enter') q('#f6ms').click(); };
    if (q('#f6hum')) q('#f6hum').onchange = function () { act('emotion_setting', { name: 'humour', value: this.checked }); };
    if (q('#f6sar')) q('#f6sar').onchange = function () { act('emotion_setting', { name: 'sarcasm', value: Number(this.value) }); };
    if (q('#f6route')) { var cur = (((S.data.performance || {}).models || {}).routing) || 'auto'; q('#f6route').value = cur; q('#f6route').onchange = function () { act('routing', { value: this.value }); }; }
    if (q('#f6run')) q('#f6run').onclick = function () { var c = q('#f6cmd').value.trim(); if (c && B && B.sendCommand) { B.sendCommand(c, []); toastx('Sent: ' + c); } };
  }

  /* ------------------------------------------------------------ channel */
  function onLine(l) {
    if (typeof l !== 'string' || l.indexOf('FRIDAY_V6::') !== 0) return;
    var m; try { m = JSON.parse(dec(l.slice(11))); } catch (e) { return; }
    var k = m.kind || '';
    if (k.indexOf('snapshot:') === 0) { S.data[k.slice(9)] = m.data; if (typeof V !== 'undefined' && V === 'Centre' && k.slice(9) === S.tab.toLowerCase()) { var ae = document.activeElement; if (!(ae && $('#view').contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName))) window.centre6V($('#view')); }   /* V6.0.1: do not rebuild the page while the user is typing in it */ }
    else if (k === 'toast') toastx(m.data.text);
    else if (k === 'task_progress') { S.progress = m.data; if (typeof V !== 'undefined' && V === 'Centre' && S.tab === 'Tasks') ask('Tasks'); }
    else if (k === 'reminder') toastx('Reminder: ' + m.data.text);
    else if (k === 'resources') { var r = m.data || {}; var el = document.getElementById('f6res'); if (el) el.textContent = 'CPU ' + Math.round(r.cpu || 0) + '% · RAM ' + Math.round(r.ram || 0) + '%'; }
  }
  function header() {
    var hd = document.querySelector('header'); if (!hd || document.getElementById('f6bar')) return;
    var d = document.createElement('div'); d.id = 'f6bar'; d.setAttribute('role', 'toolbar'); d.setAttribute('aria-label', 'FRIDAY 7.0 quick controls');
    d.innerHTML = '<span id="f6mic" class="chip" title="Microphone state follows the listening pill" aria-live="polite">mic</span><span id="f6res" class="note" aria-label="Resource usage"></span><button class="hb" id="f6chat" title="Hide or show the conversation panel" aria-label="Toggle conversation panel">☰</button><button class="hb" id="f6stop" title="Emergency stop: halt all running tasks" aria-label="Emergency stop" style="color:var(--bad)">■</button>';
    var after = document.getElementById('srch'); if (after && after.parentNode) after.parentNode.insertBefore(d, after.nextSibling); else hd.appendChild(d);
    document.getElementById('f6stop').onclick = function () { act('emergency_stop', {}, 'Overview'); };
    document.getElementById('f6chat').onclick = function () { var c = document.getElementById('chat'); if (c) c.style.display = (c.style.display === 'none' ? '' : 'none'); };
    var st = document.getElementById('st'), mic = document.getElementById('f6mic');
    if (st && mic && window.MutationObserver) {
      var upd = function () { var on = /listen/i.test(st.textContent || ''); mic.textContent = on ? '● mic on' : '○ mic idle'; mic.style.color = on ? 'var(--bad)' : 'var(--m)'; };
      new MutationObserver(upd).observe(st, { childList: true, characterData: true, subtree: true }); upd();
    }
  }
  function init() {
    if (B && B.onLine) B.onLine(onLine);
    header();
    if (B && B.onBackendReady) B.onBackendReady(function () { setTimeout(function () { ask('Overview'); }, 2500); });
    var css = document.createElement('style');
    css.textContent = '.tabs6{display:flex;gap:6px;flex-wrap:wrap;margin:8px 0 14px}.tabs6 button{padding:6px 12px;border-radius:var(--r4);border:1px solid var(--k3);background:var(--p2);color:var(--t)}.tabs6 button.on{border-color:var(--a);box-shadow:0 0 10px var(--a55)}' +
      '.grid6{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}.mr6{display:flex;align-items:center;gap:10px;margin:5px 0}.mr6 span{width:110px;color:var(--m);font-size:13px;text-transform:capitalize}.mr6 b{width:44px;font-size:12px;text-align:right}' +
      '.m6{flex:1;height:8px;background:var(--k3);border-radius:4px;overflow:hidden}.m6 i{display:block;height:100%;background:var(--a);border-radius:4px;transition:width .4s}.btn.bad6{border-color:var(--bad);color:var(--bad)}' +
      '.term6{font:12px Consolas,monospace;background:var(--p);border:1px solid var(--k3);padding:10px;border-radius:var(--r3);max-height:220px;overflow:auto;white-space:pre-wrap}.steps6{margin:6px 0 0 8px;font-size:13px}#f6bar{display:flex;gap:10px;align-items:center;margin:0 8px}@media(max-width:820px){#f6res{display:none}.mr6 span{width:80px}}';
    document.head.appendChild(css);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
