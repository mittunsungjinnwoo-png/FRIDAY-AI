"""Dependency-free regression tests for v2013 intelligence helpers."""
from pathlib import Path
import ast,re
ROOT=Path(__file__).resolve().parent
src=(ROOT/'friday_backend.py').read_text(encoding='utf8')
tree=ast.parse(src)
needed={'_normalize_spoken_symbols','_prepare_for_natural_speech','make_math_speakable'}
ns={'re':re}
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name in needed:
        exec(compile(ast.Module(body=[node],type_ignores=[]),str(ROOT/'friday_backend.py'),'exec'),ns)
normalize=ns['_normalize_spoken_symbols']; speech=ns['_prepare_for_natural_speech']

cases=[
    ("input slash output", "input or output"),
    ("1 slash 2", "1/2"),
    ("one slash two", "one/two"),
    ("john at example dot com", "john@example.com"),
    ("file underscore name", "file_name"),
    ("version 2 dash 3", "version 2-3"),
    ("cats ampersand dogs", "cats and dogs"),
]
for raw,expected in cases:
    got=normalize(raw); assert got==expected,(raw,got,expected)

speech_cases=[
    ("input/output", "input or output"),
    ("1/2", "1/2"),
    ("https://example.com/a/b", "https://example.com/a/b"),
    (r"C:/Users/test/file.txt", r"C:/Users/test/file.txt"),
    ("and/or", "and or"),
]
for raw,expected in speech_cases:
    got=speech(raw).rstrip('.')
    assert got==expected,(raw,got,expected)

# Static truth-boundary assertions.
for path in ('friday_desktop_agent.py','friday_gemini_computer_use.py','friday_v96_runtime.py','friday_omni_engine.py','friday_advanced_agent.py'):
    text=(ROOT/path).read_text(encoding='utf8')
    assert ('friday_truth_verifier' in text or 'from friday_desktop_agent import computer' in text or path=='friday_advanced_agent.py'), path
assert 'action_executed_but_post_state_not_verified' in (ROOT/'friday_gemini_computer_use.py').read_text(encoding='utf8')
assert 'chrome_navigation_not_verified' in (ROOT/'friday_desktop_agent.py').read_text(encoding='utf8')
assert 'Low-confidence action suppressed' in (ROOT/'friday_backend.py').read_text(encoding='utf8')
print('V2013 voice/computer intelligence regression tests: PASS')
