"""FRIDAY V2033 Peak Orchestrator.

Additive, dependency-free performance layer. It does not replace any existing
feature implementation. It provides a small runtime governor for safe fast
paths, health telemetry, and graceful degradation when optional subsystems are
slow or unavailable.
"""
from __future__ import annotations
import time
import threading
from collections import deque

_lock = threading.RLock()
_events = deque(maxlen=128)

def record(stage: str, elapsed_ms: float, ok: bool = True) -> None:
    with _lock:
        _events.append({"stage": str(stage), "ms": round(float(elapsed_ms), 1), "ok": bool(ok), "at": time.time()})

def snapshot() -> dict:
    with _lock:
        rows = list(_events)
    if not rows:
        return {"events": 0, "avg_ms": 0.0, "success": None}
    return {
        "events": len(rows),
        "avg_ms": round(sum(x["ms"] for x in rows) / len(rows), 1),
        "success": round(sum(1 for x in rows if x["ok"]) / len(rows), 3),
    }

class Timer:
    def __init__(self, stage: str):
        self.stage = stage
        self.started = time.perf_counter()
    def done(self, ok: bool = True) -> float:
        elapsed = (time.perf_counter() - self.started) * 1000.0
        record(self.stage, elapsed, ok)
        return elapsed
