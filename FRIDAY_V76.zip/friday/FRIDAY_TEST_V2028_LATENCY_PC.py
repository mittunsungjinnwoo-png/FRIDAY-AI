from pathlib import Path

ROOT = Path(__file__).resolve().parent
backend = (ROOT / 'friday_backend.py').read_text(encoding='utf-8')
advanced = (ROOT / 'friday_advanced_agent.py').read_text(encoding='utf-8')
desktop = (ROOT / 'friday_desktop_agent.py').read_text(encoding='utf-8')

assert 'VAD_PAUSE_THRESHOLD = float(os.getenv("FRIDAY_VAD_PAUSE", "1.15"))' in backend
assert 'min(2.50, float(os.getenv("FRIDAY_VAD_PAUSE", "1.15")))' in backend
assert 'FRIDAY_FAST_AUDIO' in backend
assert 'direct_patterns = (' in advanced
for phrase in ('click', 'double[- ]click', 'scroll', 'new tab', 'volume (?:up|down)'):
    assert phrase in advanced
assert 'time.sleep(min(0.60, max(0.0, float(settle))))' in desktop
print('V2028 latency/PC routing hardening: PASS')
