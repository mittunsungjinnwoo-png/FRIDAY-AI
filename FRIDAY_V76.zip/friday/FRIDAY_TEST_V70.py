"""FRIDAY 7.0 self-test.  Run:  python FRIDAY_TEST_V70.py     (no microphone, no internet, no API key and no real windows needed)

Everything runs against a throw-away data folder and a throw-away "home" folder, so it never touches your real FRIDAY data or files.
Part 1  the four fixes asked for after 6.3: opening files by name (never a website), maximising windows, closing FRIDAY without closing your apps,
        playing a song on YouTube (instead of pressing Play/Pause)
Part 2  the 7.0 layer: routing (and that it does NOT steal existing commands), missions with verification, objectives, memory, evidence, savings,
        security centre, health / light mode, context graph, proactive suggestions, UI data
The voice, listening and speech files are checked to be byte-identical to 6.3 by `python friday_ci7.py gate`.
"""
import importlib.abc, importlib.machinery, json, os, pathlib, re, shutil, sys, tempfile, threading, time, types, unittest
from unittest import mock

HERE = pathlib.Path(__file__).resolve().parent
TMP = pathlib.Path(tempfile.mkdtemp(prefix="friday70_"))
HOME = TMP / "home"
for d in ("Documents", "Desktop", "Downloads", "Documents/My Project", "Documents/node_modules/pkg", "Documents/.git"):
    (HOME / d).mkdir(parents=True, exist_ok=True)
for f in ("Documents/Physics Notes.txt", "Documents/Resume Final.pdf", "Documents/Budget Report 2024.xlsx", "Downloads/invoice_march.pdf", "Documents/node_modules/pkg/budget report 2024 copy.txt",
          "Documents/.git/budget report 2024 config.txt"):
    (HOME / f).write_text("x", encoding="utf-8")
os.environ.update(FRIDAY_TESTING="1", FRIDAY_DATA=str(TMP / "data"), FRIDAY_DATA_DIR=str(TMP / "data"), FRIDAY_V6_DB=str(TMP / "t.db"), HOME=str(HOME), USERPROFILE=str(HOME))
sys.path.insert(0, str(HERE))


class _Fallback(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """Audio / Windows-only packages that are missing on a test machine are replaced by mocks (real ones always win)."""
    MISSING = ("speech_recognition", "pyaudio", "sounddevice", "webrtcvad", "pygame", "pyttsx3", "edge_tts", "pyautogui", "keyboard", "pynput", "win32gui", "win32con", "win32api", "win32com",
               "pythoncom", "comtypes", "pywinauto", "screen_brightness_control", "pycaw", "wmi", "google", "faster_whisper", "vosk", "numpy_audio")

    def find_spec(self, name, path, target=None):
        if name.split(".")[0] in self.MISSING:
            return importlib.machinery.ModuleSpec(name, self, is_package=True)

    def create_module(self, spec):
        m = mock.MagicMock(); m.__path__ = []; m.__spec__ = spec; m.__name__ = spec.name
        return m

    def exec_module(self, module):
        pass


sys.meta_path.append(_Fallback())
import friday_common6 as C
C.reset_for_tests(TMP / "t.db")
import friday_common7 as K

_B = {}


def backend():
    """The big backend module, imported once (the first import takes a few seconds)."""
    if "b" not in _B:
        cwd = os.getcwd()
        try:
            os.chdir(HERE)
            import friday_backend as B
        finally:
            os.chdir(cwd)
        _B["b"] = B
    return _B["b"]


# =========================================================================================== PART 1: the four fixes
class FilesAndApps(unittest.TestCase):
    """"open <file name>" opens the FILE (never a website); an app that is not installed still opens its website, exactly as before."""

    @classmethod
    def setUpClass(cls):
        cls.B = backend()
        import friday_filesearch7 as F
        cls.F = F
        F.reset_for_tests()
        F.rebuild(force=True, background=False)

    def setUp(self):
        self.said, self.opened, self.sites = [], [], []
        B = self.B
        self._saved = (B.speak, getattr(os, "startfile", None), B.open_website, B.friday_app_launcher)
        B.speak = lambda t, *a, **k: self.said.append(t)
        os.startfile = lambda p: self.opened.append(p)
        B.open_website = lambda n, u: (self.sites.append((n, u)), True)[1]

        class R:
            entry = None; score = 0.0
        B.friday_app_launcher = types.SimpleNamespace(resolve=lambda t: R(), ACCEPT_SCORE=0.6, launch_entry=lambda e: {})
        B._wa_session = None

    def tearDown(self):
        B = self.B
        B.speak, st, B.open_website, B.friday_app_launcher = self._saved
        if st is None:
            try:
                del os.startfile
            except Exception:
                pass
        else:
            os.startfile = st

    def run_cmd(self, cmd):
        self.said.clear(); self.opened.clear(); self.sites.clear()
        r = self.B.handle_command(cmd)
        return r, [os.path.basename(p) for p in self.opened]

    def test_files_open_by_name(self):
        for cmd, want in (("open physics notes", "Physics Notes.txt"), ("open my resume", "Resume Final.pdf"), ("open resume pdf", "Resume Final.pdf"), ("open the budget report", "Budget Report 2024.xlsx"),
                          ("open invoice march", "invoice_march.pdf")):
            r, op = self.run_cmd(cmd)
            self.assertTrue(r, cmd)
            self.assertEqual(op, [want], cmd)
            self.assertEqual(self.sites, [], cmd + " must not open a website")

    def test_typos_still_find_the_file(self):
        r, op = self.run_cmd("open budgt reprot")
        self.assertEqual(op, ["Budget Report 2024.xlsx"])
        self.assertEqual(self.sites, [])

    def test_folder_opens(self):
        r, op = self.run_cmd("open my project folder")
        self.assertEqual(op, ["My Project"])

    def test_uninstalled_app_keeps_opening_its_website(self):
        r, op = self.run_cmd("open discord")
        self.assertEqual(op, [])
        self.assertEqual([u for n, u in self.sites], ["https://discord.com/app"])
        self.assertTrue(any("isn't installed" in s for s in self.said))
        r, op = self.run_cmd("open someunknownapp")
        self.assertEqual(op, [])
        self.assertEqual(len(self.sites), 1)
        self.assertIn("someunknownapp", self.sites[0][1])

    def test_search_skips_junk_folders(self):
        hits = self.F.find_paths("budget report 2024", limit=20)
        self.assertTrue(any(h.endswith("Budget Report 2024.xlsx") for h in hits))
        self.assertFalse(any("node_modules" in h or os.sep + ".git" + os.sep in h for h in hits), hits)

    def test_extra_search_folders_file(self):
        extra = TMP / "extra"; extra.mkdir(exist_ok=True)
        (extra / "zebra quarterly forecast.docx").write_text("x", encoding="utf-8")
        F = self.F
        old = F.ROOTS_FILE.read_text(encoding="utf-8") if F.ROOTS_FILE.exists() else None
        try:
            F.ROOTS_FILE.parent.mkdir(parents=True, exist_ok=True)
            F.ROOTS_FILE.write_text(str(extra) + "\n", encoding="utf-8")
            F.reset_for_tests(); F.rebuild(force=True, background=False)
            h = F.best("zebra quarterly forecast")
            self.assertIsNotNone(h)
            self.assertTrue(h["path"].endswith("zebra quarterly forecast.docx"))
        finally:
            if old is None:
                F.ROOTS_FILE.unlink()
            else:
                F.ROOTS_FILE.write_text(old, encoding="utf-8")
            F.reset_for_tests(); F.rebuild(force=True, background=False)

    def test_spoken_extension_words(self):
        req = self.F.parse_request("open the file resume dot pdf")
        self.assertIn(".pdf", req["ext"])
        self.assertIn("resume", req["tokens"])


class MaximiseRouting(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.B = backend()

    def test_phrases_reach_the_window_engine(self):
        B = self.B
        calls, said = [], []
        ok = {"ok": True, "found": True, "maximized": ["x"], "already": [], "failed": [], "not_maximizable": []}

        class FakeSC:
            def maximize_application(self, name=""): calls.append(("max", name)); return dict(ok)
            def maximize_all_windows(self): calls.append(("maxall",)); return dict(ok)
            def restore_down_application(self, name=""): calls.append(("restore_down", name)); return {"ok": True, "restored": [name], "failed": []}
            def focus_application(self, name, matcher=None): calls.append(("focus", name)); return {"ok": True, "found": True}
            def minimize_application(self, name=""): calls.append(("min", name)); return {"ok": True}
            def minimize_all_windows(self): calls.append(("minall",)); return {"ok": True}
            def focus_previous_window(self): calls.append(("prev",)); return {"ok": True}
        saved = (B.friday_system_control, B.speak)
        B.friday_system_control = FakeSC(); B.speak = lambda t, *a, **k: said.append(t)
        try:
            for cmd in ("maximize whatsapp", "make whatsapp full screen", "make whatsapp maximized"):
                calls.clear(); B._wa_session = None
                self.assertTrue(B.handle_command(cmd))
                self.assertEqual(calls, [("max", "whatsapp")], cmd)
            calls.clear(); B._wa_session = None
            self.assertTrue(B.handle_command("make whatsapp smaller"))
            self.assertEqual(calls, [("restore_down", "whatsapp")])
        finally:
            B.friday_system_control, B.speak = saved


class MaximiseStateMachine(unittest.TestCase):
    """The Windows window logic, run against fake windows: minimised, minimised-from-maximised, already maximised, cannot-be-maximised, restore, all windows."""

    def test_states(self):
        import friday_system_control as SC

        class W:
            def __init__(s, h, maxi=False, icon=False, can=True, obeys=True):
                s.h, s.maxi, s.icon, s.can, s.obeys = h, maxi, icon, can, obeys
        wins = {1: W(1), 2: W(2, maxi=True), 3: W(3, maxi=True, icon=True), 4: W(4, can=False, obeys=False), 5: W(5, icon=True)}

        class U:
            def IsZoomed(s, h): return wins[h].maxi
            def IsIconic(s, h): return wins[h].icon
            def ShowWindow(s, h, how):
                w = wins[h]
                if not w.obeys:
                    return True
                if how == SC.SW_MAXIMIZE:
                    w.maxi, w.icon = True, False
                elif how == SC.SW_RESTORE:
                    if w.icon:
                        w.icon = False
                    else:
                        w.maxi = False
                return True

            def PostMessageW(s, h, msg, wp, lp):
                w = wins[h]
                if not w.obeys:
                    return True
                if wp == SC.SC_MAXIMIZE:
                    w.maxi = True
                if wp == SC.SC_RESTORE:
                    w.maxi, w.icon = False, False
                return True

            def GetWindowLongW(s, h, i): return 0x10000 if wins[h].can else 0
        names = {1: "chrome", 2: "notepad", 3: "code", 4: "calc", 5: "spotify"}
        lw = lambda include_self=False: [{"hwnd": h, "title": f"Win{h}", "pid": h, "proc": names[h], "iconic": wins[h].icon} for h in wins]
        with mock.patch.object(SC, "_IS_WINDOWS", True), mock.patch.object(SC, "_wc", lambda: U()), mock.patch.object(SC, "_force_foreground", lambda h, t=1.0: True), \
                mock.patch.object(SC, "list_app_windows", lw), mock.patch.object(SC, "_front_app_window", lambda ws: ws[0]), mock.patch.object(SC, "_foreground_root", lambda: 1):
            SC.APP_ALIASES.setdefault("chrome", {"proc_names": ["chrome.exe"]})
            r = SC.maximize_application("chrome");   self.assertTrue(r["ok"]); self.assertEqual(r["maximized"], ["Win1"]); self.assertTrue(wins[1].maxi)
            r = SC.maximize_application("notepad");  self.assertTrue(r["ok"]); self.assertEqual(r["already"], ["Win2"])
            r = SC.maximize_application("code");     self.assertTrue(r["ok"]); self.assertTrue(wins[3].maxi and not wins[3].icon)
            r = SC.maximize_application("spotify");  self.assertTrue(r["ok"]); self.assertTrue(wins[5].maxi and not wins[5].icon)
            r = SC.maximize_application("calc");     self.assertFalse(r["ok"]); self.assertEqual(r["not_maximizable"], ["Win4"])
            r = SC.restore_down_application("chrome"); self.assertTrue(r["ok"]); self.assertFalse(wins[1].maxi)
            r = SC.maximize_application("");         self.assertTrue(r["ok"])
            r = SC.maximize_all_windows();           self.assertTrue(r["ok"]); self.assertEqual(r["not_maximizable"], ["Win4"])

    def test_not_windows_is_a_clean_answer(self):
        import friday_system_control as SC
        with mock.patch.object(SC, "_IS_WINDOWS", False):
            self.assertEqual(SC.maximize_application("chrome")["error"], "not_windows")


class CloseKeepsApps(unittest.TestCase):
    def test_main_js_ends_only_fridays_own_processes(self):
        js = (HERE / "main.js").read_text(encoding="utf-8")
        self.assertIn("endFridayHelpers", js)
        self.assertNotRegex(js, r'\["/PID"\s*,\s*String\(pid\)\s*,\s*"/T"')        # no /T = no killing of everything the engine started
        self.assertRegex(js, r'"/PID",String\(pid\),"/F"')

    def test_node_syntax(self):
        import subprocess
        node = shutil.which("node")
        if not node:
            self.skipTest("node not installed")
        for f in ("main.js", "preload.js", "friday_v6_ui.js", "friday_v7_ui.js", "friday_chat5.js", "friday_settings.js"):
            r = subprocess.run([node, "--check", str(HERE / f)], capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, f + ": " + r.stderr[:200])


class YouTubePlay(unittest.TestCase):
    """"play <song> on YouTube" plays the song; only bare transport words press Play/Pause."""

    @classmethod
    def setUpClass(cls):
        cls.B = backend()

    def setUp(self):
        import friday_desktop_agent as D, friday_youtube_research as Y
        self.D, self.Y = D, Y
        self.keys, self.opened, self.said = [], [], []
        outer = self

        class P:
            def press(self, k, **kw): outer.keys.append(("press", k))
            def hotkey(self, *k, **kw): outer.keys.append(("hotkey", k))
            def write(self, t, **kw): outer.keys.append(("write", t))
            def click(self, *a, **kw): outer.keys.append(("click", a))
        self.patches = [mock.patch.object(D, "_pyautogui", lambda: P()),
                        mock.patch.object(D, "chrome_open", lambda url, new_tab=True, **kw: (self.opened.append(url), {"ok": True, "url": url})[1]),
                        mock.patch.object(Y, "_search_youtube", lambda q, max_results=8: [{"video_id": "VID_" + q.replace(" ", "_")[:12], "title": q.title(), "channel": "X", "length": "3:30"}]),
                        mock.patch.object(self.B, "speak", lambda t, *a, **k: self.said.append(t))]
        for p in self.patches:
            p.start()

    def tearDown(self):
        for p in self.patches:
            p.stop()

    def pipeline(self, low):
        B = self.B
        steps = (lambda: B.friday_unified_gateway.try_handle(low, ask_user=None),
                 lambda: (lambda r: r if isinstance(r, dict) and r.get("handled") else None)(B.friday_v96_runtime.gateway(low, topic=None)),
                 lambda: B.friday_omni_engine.handle(low),
                 lambda: B.friday_advanced_agent.try_handle(low))
        for fn in steps:
            try:
                r = fn()
            except Exception:
                r = None
            if r is not None:
                return r
        return B.handle_command(low)

    def test_song_requests_play_a_video_not_the_media_key(self):
        for c in ("play despacito on youtube", "play shape of you", "friday play kesariya song in youtube", "play despacito from youtube", "play believer by imagine dragons on youtube"):
            self.keys.clear(); self.opened.clear()
            self.pipeline(c.lower())
            self.assertNotIn(("press", "playpause"), self.keys, c)
            self.assertTrue(any("youtube.com/watch?v=" in u for u in self.opened), (c, self.opened))

    def test_missing_song_name_asks(self):
        for c in ("play a song in youtube", "play some music on youtube"):
            self.said.clear(); self.keys.clear(); self.opened.clear()
            self.pipeline(c)
            self.assertEqual(self.opened, [], c)
            self.assertTrue(any("Which song" in s for s in self.said), (c, self.said))

    def test_bare_transport_words_still_press_the_key(self):
        for c, key in (("pause", "playpause"), ("play", "playpause"), ("play the music", "playpause"), ("play/pause", "playpause"), ("next song", "nexttrack"), ("skip", "nexttrack"),
                       ("play the next song", "nexttrack"), ("volume up", "volumeup"), ("mute", "volumemute")):
            self.keys.clear(); self.opened.clear()
            self.pipeline(c)
            self.assertIn(("press", key), self.keys, c)
            self.assertEqual(self.opened, [], c)

    def test_lookup_failure_falls_back_to_search_results(self):
        with mock.patch.object(self.Y, "_search_youtube", lambda q, max_results=8: []):
            self.opened.clear()
            self.pipeline("play tum hi ho on youtube")
            self.assertTrue(any("results?search_query=" in u for u in self.opened), self.opened)

    def test_is_play_request_truth_table(self):
        D = self.D
        for yes in ("play despacito", "play shape of you on youtube", "play something on spotify", "play stranger things on netflix", "youtube play lofi"):
            self.assertTrue(D.is_play_request(yes), yes)
        for no in ("play", "pause", "play pause", "play/pause", "play the music", "play the next song", "next song", "play it", "resume playing"):
            self.assertFalse(D.is_play_request(no), no)

    def test_query_extraction(self):
        q = self.B._youtube_play_query
        self.assertEqual(q("play shape of you on youtube").lower().strip(), "shape of you")
        self.assertEqual(q("play despacito from youtube").lower().strip(), "despacito")
        self.assertIn("kesariya", q("friday play kesariya song in youtube").lower())
        self.assertFalse(q("play a song in youtube").strip())




# =========================================================================================== PART 2: the 7.0 layer
import friday_orchestrator7 as O
import friday_planner7 as PL
import friday_verify7 as V
import friday_policy7 as POL
import friday_critic7 as CR
import friday_goals7 as G
import friday_memory7 as M
import friday_savings7 as SAV
import friday_stream7 as ST
import friday_health7 as H
import friday_runtime7 as RT
import friday_graph7 as GR
import friday_proactive7 as PRO
import friday_continuity7 as CT
import friday_router7 as RO
import friday_learning7 as LRN
import friday_evidence7, friday_synthesis7, friday_tasks6, friday_productivity6, friday_seccenter7, friday_memory6 as M6, friday_ci7 as CI


def wait_job(jid, timeout=20.0, states=O.TERMINAL):
    t = time.time()
    while time.time() - t < timeout:
        j = O.get(jid)
        if j and j["state"] in states:
            return j
        time.sleep(0.05)
    return O.get(jid)


class Missions(unittest.TestCase):
    """A mission is planned, every step is checked independently, failed steps are revised, and the report claims only what was confirmed."""

    @classmethod
    def setUpClass(cls):
        cls._saved = dict(O.registry._t)
        V.BACKOFF_SCALE = 0
        K.cfg_set("critic_budget", "never")
        cls.said = []
        K.configure(speak=lambda t: cls.said.append(t))
        cls._saved_cfg = dict(O._cfg)
        O.configure(speak_report=lambda t, rep=None: cls.said.append(t))
        reg = O.registry
        reg.register("think", lambda a: {"ok": True, "output": "think:" + a.get("prompt", "")[:30] + " lots of words to pass the minimum length requirement"}, post={"nonempty": True})
        cls.calls = {"n": 0}

        def inv(a):
            cls.calls["n"] += 1
            if cls.calls["n"] == 1:
                return {"ok": False, "error": "timed out talking to server"}
            return {"ok": True, "output": "Investigated: cheaper rice recipe uses lentils and costs less. " * 3}
        reg.register("investigate", inv)
        reg.register("web_research", lambda a: {"ok": True, "output": "web: " + "abc " * 30})
        reg.register("cost_recipe", lambda a: {"ok": True, "output": "Total cost: 3 x 4 = 12 and 2 x 5 = 10"})
        reg.register("compare_costs", lambda a: {"ok": True, "output": "compare ok " * 5})
        reg.register("synthesize", lambda a: {"ok": True, "output": "Synthesis: lentils are cheaper. " * 5})

        def save(a):
            p = TMP / "out.md"; p.write_text(a.get("content", "x"), encoding="utf-8"); return {"ok": True, "output": "saved", "path": str(p)}
        reg.register("save_report", save, risk="routine", post={"file_exists": True})
        CR.install(reg)
        cls._saved_risk = dict(POL.TOOL_RISK)
        POL.TOOL_RISK.update({"liar": ("routine", None), "slow": ("safe", None), "danger": ("irreversible", None)})

    @classmethod
    def tearDownClass(cls):
        O.registry._t.clear(); O.registry._t.update(cls._saved)
        O._cfg.clear(); O._cfg.update(cls._saved_cfg)
        POL.TOOL_RISK.clear(); POL.TOOL_RISK.update(cls._saved_risk)

    def test_multi_step_mission_verified(self):
        goal = "research cheaper rice recipes to save money, cost them, compare alternatives, save the findings and verify the calculations"
        self.assertEqual(O.classify_intent(goal)["intent"], "mission")
        jid = O.submit(goal)
        j = wait_job(jid)
        self.assertEqual(j["state"], "done", j.get("report"))
        self.assertIn("6 of 6 step(s) succeeded", j["report"])
        self.assertIn("independently verified", j["report"])
        self.assertTrue((TMP / "out.md").exists())
        self.assertGreaterEqual(len(V.receipts(job=jid)), 6)
        self.assertTrue(any("independently verified" in s for s in self.said[-3:]))

    def test_transient_failure_is_retried_not_hidden(self):
        self.calls["n"] = 0
        j = wait_job(O.submit("research cheaper rice recipes, cost them, compare alternatives and save the findings"))
        self.assertEqual(j["state"], "done")
        self.assertGreaterEqual(self.calls["n"], 2)

    def test_a_claimed_success_without_the_file_is_not_believed(self):
        O.registry.register("liar", lambda a: {"ok": True, "output": "saved", "path": str(TMP / "does_not_exist.md")}, risk="routine", post={"file_exists": True})
        plan = {"steps": [PL._step(0, "Save the file", "liar", {}, [], post={"file_exists": True})], "template": "test"}
        j = wait_job(O.submit("save a file", plan=plan, speak=False))
        self.assertIn(j["state"], ("failed", "partial"))
        self.assertNotIn("1 of 1 step(s) succeeded", j["report"])

    def test_irreversible_step_waits_for_approval(self):
        ran = []
        O.registry.register("danger", lambda a: (ran.append(1), {"ok": True, "output": "did the dangerous thing " * 3})[1], risk="irreversible", post={"nonempty": True})
        plan = {"steps": [PL._step(0, "Do the dangerous thing", "danger", {}, [], post={"nonempty": True}, risk="irreversible")], "template": "test"}
        jid = O.submit("do the dangerous thing", plan=plan, speak=False)
        j = wait_job(jid, 10, ("waiting_approval",) + O.TERMINAL)
        self.assertEqual(j["state"], "waiting_approval")
        self.assertEqual(ran, [])
        O.approve(False)
        j = wait_job(jid)
        self.assertNotEqual(j["state"], "done")
        self.assertEqual(ran, [], "a declined action must never run")
        jid = O.submit("do the dangerous thing", plan={"steps": [PL._step(0, "Do the dangerous thing", "danger", {}, [], post={"nonempty": True}, risk="irreversible")], "template": "test"}, speak=False)
        wait_job(jid, 10, ("waiting_approval",))
        O.approve(True)
        j = wait_job(jid)
        self.assertEqual(j["state"], "done")
        self.assertEqual(ran, [1])

    def test_cancel(self):
        O.registry.register("slow", lambda a: (time.sleep(3), {"ok": True, "output": "slow output " * 5})[1], post={"nonempty": True}, timeout=10)
        jid = O.submit("slow thing", plan={"steps": [PL._step(0, "Slow", "slow", {}, [], post={"nonempty": True})], "template": "test"}, speak=False)
        wait_job(jid, 5, ("running",))
        self.assertGreaterEqual(O.cancel(jid), 1)
        self.assertEqual(wait_job(jid, 10)["state"], "cancelled")

    def test_restart_pauses_interrupted_missions(self):
        jid = O.submit("pretend", plan={"steps": [PL._step(0, "Never", "think", {"prompt": "x"}, [])], "template": "test"}, speak=False, start=False)
        C.x("UPDATE jobs7 SET state='running' WHERE jid=?", (jid,))
        self.assertIn(jid, O.recover())
        self.assertEqual(O.get(jid)["state"], "paused")

    def test_plan_templates(self):
        self.assertEqual(PL.make_plan("research cheaper rice recipes and cost them", None, O.registry)["template"], "savings_research")


class Verification(unittest.TestCase):
    def test_file_postcondition(self):
        f = TMP / "v.txt"; f.write_text("hello", encoding="utf-8")
        self.assertTrue(V.verify_file(str(f), min_bytes=3)[0])
        self.assertFalse(V.verify_file(str(TMP / "missing.txt"))[0])
        self.assertFalse(V.verify_file(str(f), contains="goodbye")[0])
        self.assertFalse(V.verify_file(str(f), min_bytes=50)[0])
        self.assertTrue(V.verify_file(str(f), contains="HELLO")[0])

    def test_failure_classes(self):
        self.assertEqual(V.classify_failure("connection reset by peer"), "transient")
        self.assertEqual(V.classify_failure("timed out talking to server"), "timeout")
        self.assertEqual(V.classify_failure("no such file or directory"), "not_found")
        self.assertEqual(V.classify_failure("access is denied"), "permission")
        self.assertEqual(V.classify_failure("", {"cancelled": True}), "cancelled")
        self.assertEqual(V.classify_failure("weird", post_failed=True), "verification")


class Critic(unittest.TestCase):
    def test_arithmetic_is_checked_by_recomputing(self):
        r = CR.review("The total is 2 + 2 = 5 apples.", allow_model=False)
        self.assertFalse(r["ok"])
        self.assertIn("4", r["verdict"])
        self.assertTrue(CR.review("2 x 3 = 6 and 10 / 2 = 5", allow_model=False)["ok"])

    def test_nothing_checkable_is_said_plainly(self):
        self.assertIn("unreviewed", CR.review("Just some friendly words.", allow_model=False)["verdict"])


class Policy(unittest.TestCase):
    def test_decisions(self):
        self.assertEqual(POL.decide("think", {}, source="user")["decision"], "allow")
        self.assertEqual(POL.decide("delete_file", {}, source="user")["decision"], "ask")
        self.assertEqual(POL.decide("delete_file", {}, source="document")["decision"], "deny")          # instructions found inside a document are never obeyed

    def test_autonomy_never_unlocks_irreversible(self):
        old = POL.autonomy()
        try:
            POL.set_autonomy("independent")
            self.assertEqual(POL.decide("delete_file", {}, source="user")["decision"], "ask")
        finally:
            POL.set_autonomy(old)

    def test_user_rules(self):
        POL.set_rule("write_file", "never", "test")
        try:
            self.assertEqual(POL.decide("write_file", {}, source="user")["decision"], "deny")
        finally:
            POL.clear_rule("write_file")
        self.assertNotEqual(POL.decide("write_file", {}, source="user")["decision"], "deny")


class Objectives(unittest.TestCase):
    def test_lifecycle_and_honest_progress(self):
        o = G.create("Launch the Atlas website", ["Write copy", "Deploy"], time.time() + 3 * 86400)
        self.assertEqual(G.get(o["oid"])["progress"], 0)
        r = G.complete(o["oid"], 1, evidence="copy.md saved")
        self.assertTrue(r["ok"])
        self.assertEqual(G.get(o["oid"])["progress"], 50)
        G.block(o["oid"], 2, "waiting for hosting account")
        self.assertIn("hosting", G.handle("what is blocking the atlas website"))
        self.assertGreaterEqual(G.unblock(o["oid"]), 1)
        self.assertIn("Atlas", G.handle("how is the atlas website"))
        self.assertTrue(G.due_soon(96))

    def test_chat_commands(self):
        self.assertIn("Objective created", G.handle("create an objective to learn guitar scales with milestones practise c major; practise g major"))
        self.assertIn("guitar", G.handle("list objectives"))
        self.assertIsNone(G.handle("open chrome"))


class MemoryAndLearning(unittest.TestCase):
    def test_newer_fact_supersedes_older_and_history_is_kept(self):
        a = M.remember("semantic", "My favourite colour is blue")
        b = M.remember("semantic", "My favourite colour is green")
        self.assertEqual(b["action"], "superseded")
        hit = M.recall("favourite colour", k=3)
        self.assertEqual([h["text"] for h in hit], ["My favourite colour is green"])
        self.assertTrue(M.history(b["id"]))

    def test_secrets_are_never_stored(self):
        self.assertEqual(M.remember("semantic", "my api key is sk-abcdefghijklmnopqrstuvwxyz0123456789")["action"], "refused")

    def test_correct_and_forget(self):
        M.remember("preference", "I like dark mode in the evenings")
        self.assertTrue(M.correct("dark mode", "I like light mode in the evenings")["ok"])
        self.assertGreaterEqual(M.forget("light mode in the evenings"), 1)
        self.assertEqual([h for h in M.recall("light mode evenings", k=2) if "mode" in h["text"]], [])

    def test_sessions_are_summarised_without_inventing(self):
        M.log_turn("hello there", "hi")
        M.log_turn("what about the weather", "sunny")
        mid = M.end_session(["wrote a report"])
        self.assertTrue(mid)
        self.assertIn("wrote a report", M.get(mid)["text"])

    def test_lessons_are_proposals_until_applied(self):
        lid = LRN.observe("failure", "cost the recipe", "tool cost_recipe is not available", tool="cost_recipe")
        self.assertIsNotNone(lid)
        self.assertTrue(all(l["status"] != "applied" for l in LRN.lessons()))


class Savings(unittest.TestCase):
    def test_prices_history_and_costing_use_only_recorded_data(self):
        self.assertTrue(SAV.record_price("rice", "60", "1", "kg", "Keells", "LKR")["ok"])
        SAV.record_price("rice", "55", "1", "kg", "Cargills", "LKR")
        h = SAV.history("rice")
        self.assertEqual(h["count"], 2)
        self.assertEqual(float(h["change_pct"]), -8.3)
        r = SAV.tool_cost_recipe({"text": "2 kg rice\n1 kg dhal", "name": "x"})
        self.assertTrue(r["ok"])
        self.assertIn("2 kg rice: Rs 110.00", r["output"])
        self.assertIn("NOT PRICED", r["output"])                         # dhal has no recorded price: never invented
        self.assertIn("Recorded total: Rs 110.00", r["output"])

    def test_chat_only_claims_the_users_own_price_book(self):
        SAV.record_price("tea", "900", "1", "kg", "Keells", "LKR")
        self.assertIn("Tea", SAV.handle("what is the price of tea") or "")
        for q in ("what is the price of bitcoin", "how much is the iphone 16", "price of gold today"):
            self.assertIsNone(SAV.handle(q), q)                         # live-price lanes keep those

    def test_bad_input_is_refused(self):
        self.assertFalse(SAV.record_price("rice", "abc", "1", "kg")["ok"])
        self.assertFalse(SAV.record_price("rice", "10", "1", "parsecs")["ok"])


class StreamingSpeech(unittest.TestCase):
    def test_segments_are_independent_of_chunking(self):
        text = "Hello there. This is the second sentence! Is this third? Final one."
        want = ST.segments(text)
        self.assertEqual(want, ["Hello there. This is the second sentence!", "Is this third?", "Final one."])
        import random
        rnd = random.Random(7)
        for _ in range(25):
            cuts = sorted(rnd.sample(range(1, len(text)), 6))
            parts = [text[a:b] for a, b in zip([0] + cuts, cuts + [len(text)])]
            sp = ST.SegmentSplitter() if hasattr(ST, "SegmentSplitter") else None
            if sp is None:
                break
            out = []
            for p in parts:
                out.extend(sp.feed(p))
            out.extend(sp.flush())
            self.assertEqual(out, want)

    def test_code_and_headings_are_not_read_out(self):
        segs = ST.spoken_summary("# Title\n\nFirst point is important. Second point too.\n\n```py\nprint(1)\n```\n")["segments"]
        self.assertEqual(segs[:2], ["First point is important.", "Second point too."])
        self.assertNotIn("print(1)", " ".join(segs))


class HealthAndRuntime(unittest.TestCase):
    def test_light_mode_toggles_and_notifies(self):
        seen = []
        H.on_light_change(lambda on, why: seen.append(on))
        H.set_light(True, "test pressure")
        self.assertTrue(H.light_mode())
        self.assertFalse(RT.should_use_model("critic"))         # optional extras are skipped while the laptop is struggling
        self.assertTrue(RT.should_use_model("reasoning"))       # but the answer itself is never degraded
        H.set_light(False)
        self.assertFalse(H.light_mode())
        self.assertEqual(seen[-2:], [True, False])

    def test_conversation_state_is_always_one_of_the_known_states(self):
        st = RT.conversation_state()
        self.assertIn(st["state"], ("listening", "thinking", "speaking", "idle", "interrupted", "recovering", "degraded"))
        self.assertTrue(st["why"])

    def test_unloaders_free_idle_components(self):
        freed = []
        RT.register_unloader("test_thing", lambda: freed.append(1) or 1.5, idle_s=0, idle_of=lambda: 999.0)
        r = RT.unload_idle(force=True)
        self.assertTrue(any(x.startswith("test_thing") for x in r["released"]), r)
        self.assertTrue(freed)

    def test_speculation_never_changes_results(self):
        self.assertIn(RT.speculate("what is the weather"), (True, False))


class ContextGraph(unittest.TestCase):
    def test_graph_is_derived_dated_and_sourced(self):
        now = time.time()
        M6.project_note("Orion", "Call Priya about the budget")
        C.x("INSERT INTO pr_contacts(name,email,phone,note,ts) VALUES('Priya','','','',?)", (now,))
        o = G.create("Finish Orion prototype", ["Sketch", "Build"], now + 2 * 86400)
        c = GR.rebuild(force=True)
        self.assertGreaterEqual(c["objective"], 1)
        self.assertGreaterEqual(c["deadline"], 1)
        txt = GR.about("orion")
        self.assertIn("orion", txt.lower())
        self.assertIn("source", txt)
        self.assertTrue(any("orion" in d["label"].lower() for d in GR.upcoming(7)))
        self.assertIn("nothing connected", GR.about("zebra unicorn").lower())
        self.assertIsNone(GR.handle("open chrome"))

    def test_trace_explains_why_something_exists(self):
        o = G.create("Write the Hermes report", ["Collect data"], None)
        GR.rebuild(force=True)
        n = GR.find("Collect data", ("milestone",))
        path = GR.trace(n["nid"])
        self.assertEqual([p["kind"] for p in path][:2], ["milestone", "objective"])


class Suggestions(unittest.TestCase):
    def test_suggestions_are_only_shown_never_run(self):
        ran = []
        PRO.configure(run=lambda c: ran.append(c) or "ran")
        o = G.create("Renew the licence", ["Fill the form"], time.time() + 86400)
        items = PRO.refresh()
        self.assertTrue(any("Renew the licence" in s["text"] for s in items))
        self.assertEqual(ran, [], "nothing may run until the user says so")
        listing = PRO.handle("any suggestions")
        self.assertIn("Renew the licence", listing)
        sid = next(s["id"] for s in PRO.open_items() if "Renew the licence" in s["text"])
        self.assertTrue(PRO.dismiss(sid))
        self.assertFalse(any("Renew the licence" in s["text"] for s in PRO.refresh()), "a dismissed suggestion stays away")

    def test_limits_and_switch(self):
        K.cfg_set("proactive_enabled", "0")
        self.assertIsNone(PRO.surface())
        self.assertIn("back on", PRO.handle("turn on suggestions"))
        self.assertTrue(PRO.in_quiet_hours(time.mktime(time.strptime("2026-10-14 23:30", "%Y-%m-%d %H:%M"))))
        self.assertFalse(PRO.in_quiet_hours(time.mktime(time.strptime("2026-10-14 12:00", "%Y-%m-%d %H:%M"))))

    def test_general_questions_are_not_stolen(self):
        for q in ("any suggestions for dinner", "do you have any ideas", "open chrome"):
            self.assertIsNone(PRO.handle(q), q)


class SecurityCentre(unittest.TestCase):
    def test_secret_scan_finds_a_planted_key_and_never_prints_it(self):
        d = TMP / "scan"; d.mkdir(exist_ok=True)
        (d / "config.txt").write_text("api_key = sk-abcdefghijklmnopqrstuvwxyz0123456789\n", encoding="utf-8")
        r = friday_seccenter7.scan_secrets(str(d)) if "root" in friday_seccenter7.scan_secrets.__code__.co_varnames or True else None
        self.assertTrue(r["found"] if isinstance(r, dict) and "found" in r else r)
        self.assertNotIn("abcdefghijklmnopqrstuvwxyz0123456789", json.dumps(r, default=str))

    def test_boot_check_and_clean_marker(self):
        r = friday_seccenter7.boot_check()
        self.assertIn("unclean", r)
        friday_seccenter7.clean_shutdown()
        self.assertFalse(friday_seccenter7.boot_check()["unclean"])


class ReleaseGate(unittest.TestCase):
    def test_voice_listening_speech_files_identical_and_nothing_removed(self):
        res = CI.gate(HERE)
        self.assertTrue(res["pass"], CI.describe(res))
        self.assertFalse([p for p in res["problems"] if "friday_voice5" in p or "friday_speech5" in p])


class Core7Routing(unittest.TestCase):
    """7.0 commands are handled by 7.0; every existing command still flows on to the code that handled it in 6.3."""

    @classmethod
    def setUpClass(cls):
        import friday_core6 as C6, friday_core7 as C7
        cls.C7 = C7
        cls.spoken, cls.lines = [], []
        C6.configure(speak=lambda t: cls.spoken.append(t), emit=lambda l: cls.lines.append(l), busy=lambda: False)
        C7.configure(speak=lambda t: cls.spoken.append(t), emit=lambda l: cls.lines.append(l), busy=lambda: False, restart_listener=lambda: None)
        C7.boot()

    NOT_MINE = """open chrome|open notepad|open whatsapp|close whatsapp|open the file budget 2024|open resume.pdf|maximise chrome|minimize chrome|play despacito on youtube|play shape of you|play|pause|next song|volume up|set volume to 40|mute
what time is it|what's the weather in colombo|tell me a joke|who is the prime minister of sri lanka|how are you|hello friday|good morning|thank you|what is the price of bitcoin|price of gold today|how much is a dollar in rupees
how much is the iphone 16|convert 10 km to miles|what is 25 times 4|remind me to call dad at 5pm|schedule dentist tomorrow at 4pm|add milk to my shopping list|what's on my calendar|call mom on whatsapp|send a whatsapp message to Sarah saying hi
search google for best laptops|search youtube for cooking videos|open youtube|open facebook|take a screenshot|what do you see|read my screen|analyse my screen|write a poem about the sea|explain quantum computing|translate hello to french
what is the capital of france|how do i make pasta|recipe for chicken curry|how many calories in an apple|what should i eat for dinner|track my expenses|how much did i spend this month|set a timer for 10 minutes|set an alarm for 6 am|shut down the computer
lock the computer|turn off wifi|what's my battery level|how much ram do i have|latest news about ai|create a presentation about solar energy|teach me kinematics for physics|solve 3x+1=10|open settings|open task manager|go to sleep|speak faster
who are you|what can you do|remember that my favourite colour is blue|forget my favourite colour|what do you remember about me|my goal is to prepare for my exams by 2026-11-30|write a python function to reverse a string
open vs code|open spotify and play some music|play my liked songs on spotify|what is the price of rice|how much is milk|what is related to python|compare the screen and the monitor""".replace("\n", "|").split("|")

    def test_existing_commands_are_not_claimed(self):
        subm = []
        with mock.patch.object(O, "submit", lambda goal, **kw: (subm.append(goal), "J-0-x")[1]):
            for c in self.NOT_MINE:
                handled, _ = self.C7.route(c.strip())
                self.assertFalse(handled, f"7.0 stole an existing command: {c!r} -> {self.spoken[-1:]}")
        self.assertEqual(subm, [])

    def test_seven_oh_commands_are_handled(self):
        for c in ("create an objective to ship the site with milestones write copy; deploy", "list objectives", "any suggestions", "show the context graph", "show all my deadlines",
                  "what missions are running", "show my missions", "security status", "what is your autonomy level", "test your tools", "show me the improvements", "free up memory",
                  "are you listening", "resume the mission"):
            self.spoken.clear()
            handled, _ = self.C7.route(c)
            self.assertTrue(handled, c)
            self.assertTrue(self.spoken, c)

    def test_version(self):
        self.spoken.clear()
        self.assertTrue(self.C7.route("what version are you")[0])
        self.assertIn("7.0", self.spoken[-1])

    def test_long_pasted_text_is_never_pattern_matched(self):
        self.assertEqual(self.C7.route("open chrome " * 400), (False, "open chrome " * 400))

    def test_a_failing_module_is_skipped_not_fatal(self):
        def boom(c): raise RuntimeError("boom")
        mods = self.C7.modules()
        mods.insert(0, ("boom", boom))
        try:
            self.assertEqual(self.C7.route("open chrome")[0], False)
            self.assertTrue(self.C7.route("list objectives")[0])
        finally:
            mods.pop(0)

    def test_prompt_block_is_bounded(self):
        self.assertLessEqual(len(self.C7.prompt_block("tell me about everything " * 20)), 1100)

    def test_ui_snapshots_and_actions(self):
        import base64
        C7 = self.C7

        def run(req):
            self.lines.clear(); C7.handle_ui(req)
            return [json.loads(base64.b64decode(l.split("::", 1)[1]).decode()) for l in self.lines if l.startswith("FRIDAY_V7::")]
        for tab in ("overview", "missions", "goals", "memory", "evidence", "security", "health", "quality", "savings", "suggestions", "settings"):
            out = run({"op": "snapshot", "tab": tab})
            self.assertEqual(out[-1]["kind"], "snapshot:" + tab)
            d = out[-1]["data"]
            self.assertFalse([k for k, v in d.items() if isinstance(v, dict) and list(v) == ["error"]], (tab, d))
        toast = lambda out: [o["data"]["text"] for o in out if o["kind"] == "toast"]
        self.assertIn("proactive_speak set to 1.", toast(run({"op": "action", "action": "setting_set", "key": "proactive_speak", "value": "1", "tab": "settings"})))
        K.cfg_set("proactive_speak", "0")
        self.assertEqual(toast(run({"op": "action", "action": "setting_set", "key": "nonsense", "value": "1", "tab": "settings"})), ["Unknown setting."])
        self.assertTrue(toast(run({"op": "action", "action": "objective_create", "title": "UI made", "milestones": "a\nb", "tab": "goals"})))
        self.assertTrue(any(o["title"] == "UI made" for o in G.objectives()))
        self.assertEqual(toast(run({"op": "action", "action": "bogus", "tab": "goals"})), ["I don't know that action."])
        out = run({"op": "action", "action": "price_add", "item": "sugar", "price": "200", "qty": "1", "unit": "kg", "store": "", "tab": "savings"})
        self.assertTrue(SAV.latest_per_store("sugar"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
