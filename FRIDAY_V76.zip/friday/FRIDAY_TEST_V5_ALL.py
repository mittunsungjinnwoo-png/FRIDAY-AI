"""Runs every FRIDAY 5.0 test + the benchmark.  python FRIDAY_TEST_V5_ALL.py"""
import subprocess, sys, os
here = os.path.dirname(os.path.abspath(__file__)); bad = 0
for t in ("FRIDAY_TEST_V5_VOICE.py", "FRIDAY_TEST_V5_SPEECH.py", "FRIDAY_TEST_V5_KNOWLEDGE.py", "FRIDAY_TEST_V5_ATTACH.py"):
    r = subprocess.run([sys.executable, os.path.join(here, t)], cwd=here, capture_output=True, text=True)
    print(("PASS " if r.returncode == 0 else "FAIL ") + t); bad += r.returncode != 0
    if r.returncode: print(r.stdout[-800:], r.stderr[-400:])
sys.path.insert(0, here)
import friday_benchmark5 as bm
res = bm.run_all(); print("Benchmark score:", res["score"], "/ 100"); bad += res["score"] < 90
sys.exit(1 if bad else 0)
