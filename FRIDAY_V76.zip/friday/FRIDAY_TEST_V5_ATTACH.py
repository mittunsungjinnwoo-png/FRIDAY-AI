import sys, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import friday_attach5 as a
fails=[]
def check(n,c):
    print(("PASS " if c else "FAIL ")+n); (not c) and fails.append(n)
F=a.FileBlockFilter
def run(chunks):
    f=F(); spoken="".join(a.filter_stream(chunks,f)); return spoken,f.files
s,fl=run(["I fixed it. <<<FILE:fix.py>>>\nprint(1)\n<<<END>>> Done."])
check("single chunk", s=="I fixed it.  Done." and fl==[("fix.py","print(1)\n")])
text="Here you go. <<<FILE:report.md>>>\n# Title\nbody\n<<<END>>> That is the report."
for step in (1,2,3,5,7):
    s,fl=run([text[i:i+step] for i in range(0,len(text),step)])
    check(f"chunks of {step}", s=="Here you go.  That is the report." and fl==[("report.md","# Title\nbody\n")])
s,fl=run(["a <<<FILE:x.txt>>>\n```python\nprint(2)\n```\n<<<END>>>"])
check("code fence stripped", fl==[("x.txt","print(2)\n")])
s,fl=run(["no files here, 3 < 4 and <<< not a block"])
check("plain text untouched", s=="no files here, 3 < 4 and <<< not a block" and fl==[])
s,fl=run(["x <<<FILE:u.txt>>>\nunterminated body"])
check("missing END keeps file", fl==[("u.txt","unterminated body\n")] and s=="x ")
s,fl=run(["<<<FILE:a.txt>>>\n1\n<<<END>>><<<FILE:b.txt>>>\n2\n<<<END>>>"])
check("two files", [x[0] for x in fl]==["a.txt","b.txt"])
d=tempfile.mkdtemp(); p=os.path.join(d,"t.py"); open(p,"w").write("print('hi')\n"); q=os.path.join(d,"n.ipynb"); open(q,"w").write("{}")
it=a.inspect_all([p,q,"/nonexistent"])
check("inspect text+extra", len(it)==2 and it[0]["kind"]=="text/code" and "print('hi')" in it[0]["content"] and it[1]["kind"]=="text/code")
check("prompt block", "FILE: t.py" in a.prompt_block(it) and "print('hi')" in a.task_prompt("fix", it))
sys.exit(1 if fails else 0)
