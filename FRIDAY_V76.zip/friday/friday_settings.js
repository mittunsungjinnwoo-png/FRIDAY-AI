/* FRIDAY Settings - full UI customisation.
   Loaded by index.html after the main script. It wraps the original Settings page
   (currency, permissions, erase data) as the "General" tab and adds the rest. */
(function () {
  'use strict';
  const T = Theme;
  const baseSettings = settings;
  let TAB = 'Appearance';
  let REDRAW = null;
  const TABS = ['Appearance', 'Reactor', 'Effects', 'Home', 'Widget', 'Layout', 'Profile', 'Assistant', 'Sounds', 'Voice', 'AI', 'Vision', 'General'];
  const E = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  const chips = (path, opts, cur) => `<div>${opts.map(([v, l, st]) => `<button class="chip ${String(v) === String(cur) ? 'on' : ''}" data-set="${path}" data-v="${E(v)}" ${st ? `style="${st}"` : ''}>${l}</button>`).join('')}</div>`;
  const sg = (title, note, body) => `<div class="sg"><h4>${title}</h4>${note ? `<p class="note">${note}</p>` : ''}${body}</div>`;
  const lbl = t => `<span class="lbl">${t}</span>`;
  const range = (path, label, min, max, step, unit) => { const v = T.get(path); return `<div class="rng"><span>${label}</span><input type="range" data-range="${path}" min="${min}" max="${max}" step="${step}" value="${v}"><output>${v}${unit || ''}</output></div>`; };
  const toggle = (path, label) => `<label class="tgl"><input type="checkbox" data-check="${path}" ${T.get(path) ? 'checked' : ''}> ${label}</label>`;
  const swatches = (path, list, cur) => `<div class="sw">${list.map(c => `<button title="${c}" data-set="${path}" data-v="${c}" class="${c.toLowerCase() === String(cur).toLowerCase() ? 'on' : ''}" style="background:${c}"></button>`).join('')}<input type="color" data-color="${path}" value="${/^#[0-9a-f]{6}$/i.test(cur) ? cur : '#2b9bff'}" title="Pick any colour"></div>`;
  const parse = v => v === 'true' ? true : v === 'false' ? false : /^-?\d+(\.\d+)?$/.test(v) ? Number(v) : v;

  /* ---------------------------------------------------------------- tabs */
  const A2 = ['#a66bff', '#ff4fd8', '#19e0ff', '#ffc94a', '#27e0a1', '#ff7a1a', '#ff4a3d', '#ffffff'];
  const colorIn = (path, val) => `<div class="sw" style="margin-top:8px"><input type="color" data-color="${path}" value="${/^#[0-9a-f]{6}$/i.test(val) ? val : '#2b9bff'}" title="Pick any colour"></div>`;
  const textIn = (path, val, ph, max, w) => `<div class="row"><input data-text="${path}" value="${E(val == null ? '' : val)}" placeholder="${E(ph || '')}" ${max ? `maxlength="${max}"` : ''} style="max-width:${w || 420}px"></div>`;

  function tabAppearance() {
    const c = T.cfg;
    const presets = Object.entries(T.PRESETS).map(([k, p]) => { const a = p.p.accent || T.DEF.accent, a2 = (p.p.accent2 && p.p.accent2 !== 'auto') ? p.p.accent2 : a, b = p.p.bg || T.DEF.bg; return `<button class="pst" data-preset="${k}"><i style="background:linear-gradient(135deg,${p.p.mode === 'light' ? '#eaf2fc' : b} 28%,${a} 64%,${a2})"></i>${p.label}</button>`; }).join('');
    return sg('Quick looks', 'One tap sets colours, background, reactor and effects together. Your name, address, widget and Home choices stay as they are.', `<div class="opts" style="grid-template-columns:repeat(auto-fill,minmax(170px,1fr))">${presets}</div>`)
      + sg('Colours', '', lbl('Theme') + chips('mode', [['dark', 'Dark'], ['light', 'Light'], ['auto', 'Match Windows']], c.mode)
        + lbl('Main accent (frames, buttons, reactor)') + swatches('accent', T.ACCENTS, c.accent)
        + lbl('Second accent (violet parts of the HUD, orbit rings)') + chips('accent2', [['auto', 'Auto (from main accent)']], c.accent2) + swatches('accent2', A2, c.accent2)
        + lbl('Background colour' + (c.mode === 'light' ? ' (used in dark theme)' : '')) + swatches('bg', T.BGS, c.bg))
      + sg('Background and panels', '', lbl('Background style') + chips('bgStyle', [['glow', 'Soft glow'], ['nebula', 'Nebula'], ['aurora', 'Aurora'], ['grid', 'Tech grid'], ['stars', 'Starfield'], ['scan', 'Scanlines'], ['flat', 'Flat']], c.bgStyle)
        + lbl('Panels') + chips('surface', [['solid', 'Solid'], ['glass', 'Frosted glass']], c.surface)
        + range('glow', 'Panel glow', 0, 200, 10, '%'))
      + sg('Type', '', lbl('Font') + chips('font', Object.entries(T.FONTS).map(([k, f]) => [k, f[0], `font-family:${f[1]}`]), c.font));
  }

  /* Reactor Lab: live preview that has its own state buttons, so every control can be tried without leaving this page. */
  let LAB = 'idle';
  const LABBOOST = { idle: 1, listening: 1.5, recognizing: 1.9, speaking: 2.4, thinking: 1.35 };
  function tabReactor() {
    const c = T.cfg.reactor, core = c.type === 'core';
    const cards = T.TYPES.map(([k, n, d]) => `<button class="opt ${c.type === k ? 'on' : ''}" data-set="reactor.type" data-v="${k}"><canvas data-rt="${k}" width="192" height="192"></canvas><b>${n}</b><small>${d}</small></button>`).join('');
    const pv = `<div class="labpv"><div class="hud labfr"><canvas id="labC"></canvas></div><div class="labst">${['idle', 'listening', 'recognizing', 'speaking', 'thinking'].map(s => `<button class="chip ${LAB === s ? 'on' : ''}" data-act="lab" data-v="${s}">${s[0].toUpperCase() + s.slice(1)}</button>`).join('')}</div><p class="note">Pick a state to see how the reactor reacts. Changes apply to Home, the footer and the widget at once.</p></div>`;
    const body = sg('Reactor design', 'Shown on Home and in the widget (unless you pick a different one for the widget).', `<div class="opts">${cards}</div>`)
      + sg('Colour, size and motion', '', lbl('Main colour') + chips('reactor.color', [['accent', 'Match accent'], ['custom', 'Custom colour']], c.color) + (c.color === 'custom' ? colorIn('reactor.custom', c.custom) : '')
        + lbl('Second colour (orbits, ripples, violet glow)') + chips('reactor.second', [['auto', 'Auto'], ['custom', 'Custom colour']], c.second) + (c.second === 'custom' ? colorIn('reactor.secondCustom', c.secondCustom) : '')
        + range('reactor.size', 'Size on Home', 60, 140, 5, '%') + range('reactor.speed', 'Rotation speed', 20, 250, 10, '%') + range('reactor.glow', 'Glow', 0, 220, 10, '%') + range('reactor.react', 'Reaction strength (listening / speaking)', 0, 200, 10, '%')
        + toggle('reactor.show', 'Show the reactor on Home'))
      + (core ? sg('Core structure', 'Options for the FRIDAY core design.', lbl('Number of rings') + range('reactor.rings', 'Rings', 3, 8, 1, '')
        + lbl('Ring style') + chips('reactor.ringStyle', [['mixed', 'Mixed'], ['ticks', 'Ticks'], ['dash', 'Dashed'], ['solid', 'Solid'], ['dots', 'Dots']], c.ringStyle)
        + lbl('Ring rotation') + chips('reactor.dir', [['alt', 'Alternating'], ['cw', 'Clockwise'], ['ccw', 'Counter-clockwise']], c.dir)
        + lbl('Centre emblem') + chips('reactor.emblem', [['logo', 'FRIDAY logo'], ['orb', 'Glowing orb'], ['triangle', 'Triangle'], ['none', 'None']], c.emblem))
        + sg('Scene', '', toggle('reactor.network', 'Network sphere') + toggle('reactor.orbits', 'Tilted orbits with satellites') + toggle('reactor.particles', 'Floating sparkles') + toggle('reactor.beam', 'Vertical energy beam (Home)') + toggle('reactor.platform', 'Hologram platform (Home)'))
        : sg('Scene', 'These options are for the FRIDAY core design.', toggle('reactor.beam', 'Vertical energy beam (Home)') + toggle('reactor.platform', 'Hologram platform (Home)') + toggle('reactor.particles', 'Floating sparkles')));
    return `<div class="lab">${pv}<div class="labo">${body}</div></div>`;
  }

  function tabEffects() {
    const c = T.cfg;
    return sg('Neon and glass', '', range('fx.neon', 'Neon glow strength', 0, 200, 10, '%') + range('fx.chamfer', 'Panel corner cut', 0, 16, 1, '') + toggle('fx.glass', 'Frosted glass panels') + toggle('fx.flow', 'Light flowing along panel edges'))
      + sg('Atmosphere', '', toggle('fx.scan', 'CRT scanlines') + toggle('fx.grid', 'Neon floor grid in the background') + toggle('fx.parallax', 'Parallax depth (the reactor and glass card drift with your mouse)') + toggle('fx.boot', 'Boot animation when FRIDAY starts') + toggle('anim', 'Animations (turn off to freeze motion everywhere)'))
      + sg('Icon style', 'Line weight of the icons across the interface.', lbl('Line style') + chips('icons.style', [['thin', 'Thin'], ['regular', 'Regular'], ['bold', 'Bold'], ['glow', 'Glow'], ['neon', 'Neon']], c.icons.style));
  }

  function tabHome() {
    const c = T.cfg, L = c.layout;
    return sg('Home screen sections', 'Show or hide parts of the Home dashboard.', [['tasks', 'Today’s Tasks'], ['schedule', 'Upcoming Schedule'], ['tiles', 'Feature tiles (AI, Vision, Memory, Automation)'], ['chips', 'Quick chips (Plan my day, Open Camera ...)'], ['quote', 'Glass card under the reactor'], ['plate', 'FRIDAY name plate'], ['decor', 'Decorative frames around the reactor']].map(([k, n]) => toggle('home.' + k, n)).join(''))
      + sg('Right column', 'The status column on the right side of Home.', toggle('layout.right', 'Show the right column') + [['status', 'System Status'], ['actions', 'Quick Actions'], ['activity', 'Live Activity']].map(([k, n]) => toggle('layout.panels.' + k, n)).join(''))
      + sg('Conversation', 'Where replies appear.', chips('home.chat', [['auto', 'Slide open automatically'], ['manual', 'Only when I press Conversation']], c.home.chat))
      + sg('Texts', 'Leave a box empty to hide that text.', lbl('Header quote, line 1') + textIn('home.head1', c.home.head1, '', 40, 360) + lbl('Header quote, line 2') + textIn('home.head2', c.home.head2, '', 40, 360) + lbl('Glass card text') + textIn('home.card', c.home.card, '', 60, 360));
  }

  const WK = {
    panel: '<svg class="wk" viewBox="0 0 92 56"><circle cx="22" cy="28" r="17" fill="none" stroke="var(--a)" stroke-width="3"/><circle cx="22" cy="28" r="7" fill="var(--a2)"/><rect x="46" y="8" width="42" height="40" rx="5" fill="none" stroke="var(--a)"/><rect x="50" y="13" width="34" height="7" rx="3" fill="var(--k3)"/><rect x="50" y="26" width="7" height="7" rx="2" fill="var(--a2)"/><rect x="60" y="26" width="7" height="7" rx="2" fill="var(--a2)"/><rect x="70" y="26" width="7" height="7" rx="2" fill="var(--a2)"/></svg>',
    orb: '<svg class="wk" viewBox="0 0 92 56"><circle cx="46" cy="28" r="24" fill="none" stroke="var(--a)" stroke-width="3"/><circle cx="46" cy="28" r="14" fill="none" stroke="var(--a2)" stroke-width="2"/><circle cx="46" cy="28" r="6" fill="var(--a2)"/></svg>',
    mini: '<svg class="wk" viewBox="0 0 92 56"><circle cx="46" cy="28" r="12" fill="none" stroke="var(--a)" stroke-width="2.5"/><circle cx="46" cy="28" r="4" fill="var(--a2)"/></svg>',
    bar: '<svg class="wk" viewBox="0 0 92 56"><circle cx="16" cy="28" r="12" fill="none" stroke="var(--a)" stroke-width="2.5"/><circle cx="16" cy="28" r="4" fill="var(--a2)"/><rect x="34" y="14" width="54" height="28" rx="6" fill="none" stroke="var(--a)"/><rect x="38" y="19" width="46" height="7" rx="3" fill="var(--k3)"/><rect x="38" y="30" width="30" height="6" rx="3" fill="var(--k3)"/></svg>'
  };
  function tabWidget() {
    const c = T.cfg.widget;
    const types = [['panel', 'Reactor + panel', 'Reactor with a command panel that slides out on hover'], ['orb', 'Reactor only', 'Just the reactor. Click it to open FRIDAY'], ['mini', 'Mini orb', 'A small floating reactor'], ['bar', 'Command bar', 'Reactor with an always-visible command box']];
    return sg('Desktop widget type', 'This is the floating widget you get from the top-bar widget button. Changes apply to it live.', `<div class="opts" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr))">${types.map(([k, n, d]) => `<button class="opt ${c.type === k ? 'on' : ''}" data-set="widget.type" data-v="${k}">${WK[k]}<b>${n}</b><small>${d}</small></button>`).join('')}</div><div style="margin-top:12px"><button class="btn" data-act="widgetnow">Show widget now</button></div>`)
      + sg('Widget behaviour', '', range('widget.opacity', 'Opacity', 40, 100, 5, '%') 
        + lbl('Widget reactor') + chips('widget.reactor', [['same', 'Same as dashboard']].concat(T.TYPES.map(t => [t[0], t[1]])), c.reactor));
  }

  function tabLayout() {
    const L = T.cfg.layout, cards = (window.F8 && window.F8.hub && window.F8.hub.cardList) ? window.F8.hub.cardList() : [];
    return sg('Sidebar', 'The navigation on the left. You can also collapse it with the small arrow beside the logo.', chips('layout.sidebar', [['full', 'Icons and names'], ['icons', 'Icons only'], ['hidden', 'Hidden']], L.sidebar))
      + sg('Settings &amp; Features cards', 'Untick a card to remove it from the Settings &amp; Features page. Hidden features can still be found with search (Ctrl + K).', `<div>${cards.map(n => `<label class="tgl" style="display:inline-flex;margin-right:16px"><input type="checkbox" data-nav="${E(n[0])}" ${L.hiddenNav.includes(n[0]) ? '' : 'checked'}> ${E(n[1])}</label>`).join('')}</div>`)
      + sg('Interface size', '', range('zoom', 'Interface size', 80, 130, 5, '%') + `<p class="note">Interface size works in the desktop app. The layout also scales with the window.</p>`);
  }

  function tabAssistant() {
    const a = T.cfg.addr, s = T.cfg.assistant;
    const modes = Object.entries(T.ADDR).map(([k, v]) => [k, v.label]);
    return sg('How should FRIDAY address you?', 'Used in the greeting, on-screen replies and spoken replies.',
      chips('addr.mode', modes, a.mode)
      + (a.mode === 'name' ? `<div class="row" style="margin-top:10px"><input data-text="addr.name" placeholder="Your name" value="${E(a.name)}" style="max-width:260px"></div>` : '')
      + (a.mode === 'custom' ? `<div class="row" style="margin-top:10px"><input data-text="addr.custom" placeholder="e.g. Chief, Doctor, Miss Stark" value="${E(a.custom)}" style="max-width:260px"></div>` : '')
      + `<div class="tip" id="addrpv"></div>`)
      + sg('Greeting', '', lbl('Greeting style') + chips('assistant.greet', [['time', 'Good morning'], ['welcome', 'Welcome back'], ['hello', 'Hello'], ['service', 'At your service']], s.greet)
        + lbl('Line under the greeting') + `<div class="row"><input data-text="assistant.sub" value="${E(s.sub)}" style="max-width:520px"></div>`)
      + sg('Name on screen', 'Changes the name shown in the sidebar, greeting and chat. The wake word stays "Friday".', `<div class="row"><input data-text="assistant.name" value="${E(s.name)}" style="max-width:200px" maxlength="20"><input data-text="assistant.tagline" value="${E(s.tagline)}" style="max-width:260px" maxlength="40"></div>`);
  }


  function tabProfile() {
    const p = T.profile();
    return sg('Your profile', 'Shown in the greeting on Home.', lbl('Name') + textIn('profile.name', T.cfg.profile.name, 'Your name', 24, 280) + lbl('Badge (any emoji)') + textIn('profile.badge', T.cfg.profile.badge, '', 4, 120) + lbl('Line under your name') + textIn('profile.ask', T.cfg.profile.ask, 'What shall we do today?', 50, 380))
      + `<div class="tip"><b>${E(T.greeting().lead)},</b> ${E(p.name || '')} ${E(p.badge || '')}<br><span class="note">${E(p.ask || '')}</span></div>`;
  }

  function tabSounds() {
    const ok = typeof micOk === 'undefined' || micOk !== false, sb = typeof vmode !== 'undefined' && vmode === 'standby';
    return sg('Interface sounds', 'Soft clicks when you press buttons and a chime when something is done. Off by default.', toggle('fx.sound', 'Play interface sounds') + `<div style="margin-top:10px"><button class="btn g s" data-act="snd">Play test sound</button></div>`)
      + sg('Microphone', 'The voice options (sensitivity, wake word, conversation window) are in the Voice tab.', `<div class="li"><span>Microphone</span><span class="${ok ? 'ok' : 'bad'}">${ok ? (sb ? 'Standby' : 'Available') : 'Unavailable'}</span></div><div class="li"><span>Speech</span><span>${window.fridayBridge ? 'Desktop app voice' : 'Preview (no voice)'}</span></div>`);
  }

  /* ---------------------------------------------------------------- Voice (V6.0.1) */
  const VKEY = 'friday_voice_cfg';
  const VDEF = { sensitivity: 'normal', active_window_s: 60, wake_anywhere: false, barge_in: true };
  function vcfg() { try { return Object.assign({}, VDEF, JSON.parse(localStorage.getItem(VKEY) || '{}')); } catch (x) { return Object.assign({}, VDEF); } }
  function vsave(c) { try { localStorage.setItem(VKEY, JSON.stringify(c)); } catch (x) { } }
  window.fridaySendVoiceCfg = function () { const B = window.fridayBridge; if (B && B.voiceConfig) { try { B.voiceConfig(vcfg()); } catch (x) { } } };
  function tabVoice() {
    const c = vcfg();
    const vchip = (k, v, l, cur) => `<button class="chip ${String(v) === String(cur) ? 'on' : ''}" data-voice="${k}" data-v="${E(v)}">${l}</button>`;
    return sg('Microphone', 'FRIDAY opens the microphone by herself when the app starts. You never have to click it. The status line says "Listening..." only while the microphone really is open.',
      lbl('Sensitivity') + `<div>${[['relaxed', 'Relaxed (quiet voice or far from the mic)'], ['normal', 'Normal'], ['strict', 'Strict (noisy room, fan, TV)']].map(([v, l]) => vchip('sensitivity', v, l, c.sensitivity)).join('')}</div>`
      + `<p class="note">If FRIDAY ever answers when nobody spoke, choose Strict. If she misses you, choose Relaxed.</p>`)
      + sg('Conversation window', 'After you say "Friday" she keeps listening for follow-ups for this long, then goes quiet until you say "Friday" again.',
        `<div>${[[30, '30 seconds'], [60, '1 minute'], [300, '5 minutes'], [0, 'Always listening']].map(([v, l]) => vchip('active_window_s', v, l, c.active_window_s)).join('')}</div>`)
      + sg('Wake word and interrupting', '',
        lbl('Wake word rule') + `<div>${[['false', 'Only at the start of a sentence (safest)'], ['true', 'Anywhere in a sentence']].map(([v, l]) => vchip('wake_anywhere', v, l, String(c.wake_anywhere))).join('')}</div>`
        + `<label class="tgl" style="margin-top:10px"><input type="checkbox" data-voice-check="barge_in" ${c.barge_in ? 'checked' : ''}> Let me talk over her to interrupt (turn off if the speakers make her stop herself)</label>`);
  }

  function tabAI() {
    return sg('AI connection', 'Enter your own Gemini API key here. FRIDAY stores it using the operating system secure storage; it is not written into the application source.',
      `<div class="row" style="align-items:center"><input id="fridayApiKey" type="password" placeholder="Paste your Gemini API key" autocomplete="off" spellcheck="false" style="min-width:360px;max-width:560px"><button class="btn g s" id="toggleApi">Show</button><button class="btn s" id="saveApi">Save &amp; Test</button><button class="btn g s" id="testApi">Test connection</button></div>
       <p class="note" id="apiStatus">Checking secure API-key storage...</p>
       <div class="row" style="align-items:center;margin-top:10px"><input id="fridayGeminiModel" type="text" placeholder="Gemini model ID, e.g. gemini-3.1-flash-lite" autocomplete="off" spellcheck="false" style="min-width:360px;max-width:560px"><button class="btn s" id="saveModel">Use Model</button></div>
       <p class="note" id="modelStatus">Loading Gemini model...</p>
       <p class="note">Enter the exact Gemini model ID supported by your API key. FRIDAY sends this value to the backend for normal AI, research, and multimodal generation.</p>
       <div class="row"><button class="btn g s" id="clearApi">Remove key</button></div>
       <p class="note">FRIDAY checks the connection in the background and reconnects by itself if the internet or Google drops out.</p>
       <p class="note">Your key is used only to connect FRIDAY to the provider you selected. Never paste someone else's secret key into a shared computer.</p>
       <div class="row" style="margin-top:14px"><button class="btn g s" id="uninstallApp">Uninstall FRIDAY...</button></div>
       <p class="note">Opens the Windows uninstaller. You can also remove FRIDAY any time from Windows Settings &gt; Apps.</p>`);
  }

  function tabGeneral(box) {
    const wrap = document.createElement('div');
    baseSettings(wrap);
    const h = wrap.querySelector('h2'); if (h) h.remove();
    box.appendChild(wrap);
    if (typeof window.fridaySettingsGeneralExtra === 'function') { try { box.insertAdjacentHTML('beforeend', window.fridaySettingsGeneralExtra()); } catch (x) { } }
    box.insertAdjacentHTML('beforeend', sg('Back up or reset your look', 'Copy your customisation to move it to another PC, or paste one in.', `<textarea id="uibk" spellcheck="false" placeholder="Paste a saved look here and press Import"></textarea><div class="row" style="margin-top:8px"><button class="btn g s" data-act="exp">Export</button><button class="btn g s" data-act="imp">Import</button><button class="btn g s" data-act="rst">Reset to default look</button></div>`));
  }

  /* ---------------------------------------------------------------- render */
  function addrPreview() {
    const el = document.getElementById('addrpv'); if (!el) return;
    const g = T.greeting();
    el.innerHTML = `<b>${g.html}</b><br><span class="note">Spoken: &ldquo;${E(T.addr('Task complete, Sir. The report is ready.'))}&rdquo;</span>`;
  }

  settings = function (e, o) {
    o = o || {}; if (o.tab && TABS.indexOf(o.tab) >= 0) TAB = o.tab;
    e.innerHTML = (o.bare ? '' : `<h2>Settings</h2><div class="tabs" id="stt">${TABS.map(t => `<button class="tb ${t === TAB ? 'on' : ''}" data-tab="${t}">${t}</button>`).join('')}</div>`) + `<div id="stg"></div>`;
    const box = e.querySelector('#stg');
    const draw = () => {
      e.querySelectorAll('#stt .tb').forEach(b => b.classList.toggle('on', b.dataset.tab === TAB));
      if (TAB === 'General') { box.innerHTML = ''; tabGeneral(box); return; }
      box.innerHTML = ({ Appearance: tabAppearance, Reactor: tabReactor, Effects: tabEffects, Home: tabHome, Widget: tabWidget, Layout: tabLayout, Profile: tabProfile, Assistant: tabAssistant, Sounds: tabSounds, Voice: tabVoice, AI: tabAI, Vision: () => (window.FridayVisionSettings ? window.FridayVisionSettings.html() : '') }[TAB])();
      if (TAB === 'Vision' && window.FridayVisionSettings) window.FridayVisionSettings.wire(box);
      box.querySelectorAll('canvas[data-rt]').forEach(c => T.reactor(c, { type: c.dataset.rt, scale: 440, mini: true }));
      const lc = box.querySelector('#labC');
      if (lc) T.reactor(lc, { type: T.cfg.reactor.type, getState: () => LAB, getBoost: () => LABBOOST[LAB] || 1 });
      if (TAB === 'Assistant') addrPreview();
    };
    draw();
    REDRAW = () => { if (document.body.contains(box)) { draw(); wireAI(); } };
    const wireAI = async () => {
      if (TAB !== 'AI') return;
      const st = document.getElementById('apiStatus');
      const input = document.getElementById('fridayApiKey');
      const toggle = document.getElementById('toggleApi');
      const saveBtn = document.getElementById('saveApi');
      const clearBtn = document.getElementById('clearApi');
      const modelInput = document.getElementById('fridayGeminiModel');
      const modelBtn = document.getElementById('saveModel');
      const modelStatus = document.getElementById('modelStatus');
      if (!st || !window.fridayBridge) return;
      try {
        const r = await window.fridayBridge.getApiStatus();
        const show = (x) => { if (!x) return; const ok = x.state === 'ready'; const bad = ['key','model','network','busy','quota','config','other','no_key'].includes(x.state); st.textContent = (ok ? '✓ ' : bad ? '⚠ ' : '… ') + (x.message || ''); if (ok && modelInput && x.model) { modelInput.value = x.model; if (modelStatus) modelStatus.textContent = '✓ Backend model: ' + x.model; } };
        st.textContent = r.configured ? '✓ API key configured in secure local storage.' : 'No API key configured yet.';
        if (r.status) show(r.status);
        if (!window.__fridayApiStatusWired) { window.__fridayApiStatusWired = true; window.fridayBridge.onApiStatus((x) => { window.__fridayApiLast = x; const el = document.getElementById('apiStatus'); if (el && document.getElementById('fridayApiKey')) { const okk = x.state === 'ready'; el.textContent = (okk ? '✓ ' : x.state === 'pending' ? '… ' : '⚠ ') + (x.message || ''); } }); }
        document.getElementById('testApi')?.addEventListener('click', async () => { const b = document.getElementById('testApi'); b.disabled = true; st.textContent = 'Testing connection...'; try { show(await window.fridayBridge.testApi()); } catch (err) { st.textContent = '✕ ' + err.message; } b.disabled = false; });
        document.getElementById('uninstallApp')?.addEventListener('click', async () => { try { const u = await window.fridayBridge.uninstallApp(); if (u && u.error) st.textContent = '✕ ' + u.error; } catch (err) { st.textContent = '✕ ' + err.message; } });
        if (modelInput) modelInput.value = r.model || 'gemini-3.1-flash-lite';
        if (modelStatus) modelStatus.textContent = '✓ Backend model: ' + (r.model || 'gemini-3.1-flash-lite');
        toggle?.addEventListener('click',()=>{input.type=input.type==='password'?'text':'password';toggle.textContent=input.type==='password'?'Show':'Hide'});
        saveBtn?.addEventListener('click',async()=>{const key=input.value.trim();if(!key){st.textContent='Paste an API key first.';return} saveBtn.disabled=true;st.textContent='Testing connection...';const r=await window.fridayBridge.setApiKey(key);saveBtn.disabled=false;if(r.ok&&r.status){show(r.status);if(r.status.state==='ready'||r.status.state==='pending'||r.status.state==='timeout')input.value='';if(r.status.state==='ready'||r.status.state==='timeout')st.textContent=(r.status.state==='ready'?'✓ Key saved and connection tested. ':'… Key saved. ')+(r.status.message||'')}else{st.textContent=r.ok?'✓ Key saved. FRIDAY will use it immediately.':'✕ '+(r.error||'Could not save the key.');if(r.ok)input.value=''}});
        modelBtn?.addEventListener('click',async()=>{const model=(modelInput?.value||'').trim();if(!model){modelStatus.textContent='Enter a Gemini model ID first.';return}modelBtn.disabled=true;modelStatus.textContent='Applying model...';try{const r=await window.fridayBridge.setGeminiModel(model);modelBtn.disabled=false;modelStatus.textContent=r.ok?'✓ Backend model: '+r.model:'✕ '+(r.error||'Could not set model.')}catch(err){modelBtn.disabled=false;modelStatus.textContent='✕ '+err.message}});
        clearBtn?.addEventListener('click',async()=>{const r=await window.fridayBridge.setApiKey('');st.textContent=r.ok?'API key removed.':'✕ '+(r.error||'Could not remove the key.')});
      } catch(err){st.textContent='API settings unavailable in preview mode.'}
    };
    wireAI();

    e.onclick = ev => {
      const t = ev.target.closest('[data-tab],[data-set],[data-preset],[data-act],[data-voice]'); if (!t) return;
      if (t.dataset.voice) { const c = vcfg(); const k = t.dataset.voice; c[k] = (k === 'wake_anywhere') ? (t.dataset.v === 'true') : (k === 'active_window_s') ? Number(t.dataset.v) : t.dataset.v; vsave(c); window.fridaySendVoiceCfg(); toast('Voice setting saved'); return draw(); }
      if (t.dataset.tab) { TAB = t.dataset.tab; draw(); wireAI(); return; }
      if (t.dataset.preset) { T.preset(t.dataset.preset); toast(T.PRESETS[t.dataset.preset].label + ' applied'); return draw(); }
      if (t.dataset.set) { T.set(t.dataset.set, parse(t.dataset.v)); return draw(); }
      const a = t.dataset.act;
      if (a === 'lab') { LAB = t.dataset.v; draw(); }
      else if (a === 'snd') { if (window.F8 && window.F8.snd) window.F8.snd('ok', true); }
      else if (a === 'widgetnow') { if (window.fridayBridge) window.fridayBridge.enterWidget(); else toast('The widget is available in the desktop app'); }
      else if (a === 'exp') { const b = box.querySelector('#uibk'); b.value = T.exportJSON(); b.select(); try { navigator.clipboard.writeText(b.value); toast('Look copied'); } catch (x) { } }
      else if (a === 'imp') { try { T.importJSON(box.querySelector('#uibk').value); toast('Look imported'); draw(); } catch (x) { toast('That is not a valid look'); } }
      else if (a === 'rst') { if (confirm('Reset colours, icons, reactor, widget and layout to the default look?')) { T.reset(); toast('Default look restored'); draw(); } }
    };
    e.oninput = ev => {
      const t = ev.target;
      if (t.dataset.range) { T.set(t.dataset.range, Number(t.value)); t.nextElementSibling.textContent = t.value + (t.nextElementSibling.textContent.replace(/[\d.\-]/g, '')); }
      else if (t.dataset.color) T.set(t.dataset.color, t.value);
      else if (t.dataset.text) { T.set(t.dataset.text, t.value); if (t.dataset.text.indexOf('addr') === 0) addrPreview(); }
    };
    e.onchange = ev => {
      const t = ev.target;
      if (t.dataset.voiceCheck) { const c = vcfg(); c[t.dataset.voiceCheck] = !!t.checked; vsave(c); window.fridaySendVoiceCfg(); toast('Voice setting saved'); return; }
      if (t.dataset.check) { T.set(t.dataset.check, t.checked); if (/^layout\.right/.test(t.dataset.check)) draw(); }
      else if (t.dataset.nav) { const h = T.cfg.layout.hiddenNav.filter(x => x !== t.dataset.nav); if (!t.checked) h.push(t.dataset.nav); T.set('layout.hiddenNav', h); }
      else if (t.dataset.color) draw();
    };
  };

  /* V6.0.1: when the engine finishes starting, push the saved voice settings and refresh the tabs that talk to it. */
  if (window.fridayBridge && window.fridayBridge.onBackendReady) {
    window.fridayBridge.onBackendReady(() => {
      setTimeout(() => {
        window.fridaySendVoiceCfg();
        try { if (typeof V !== 'undefined' && V === 'Settings' && REDRAW && (TAB === 'Vision' || TAB === 'AI' || TAB === 'General')) REDRAW(); } catch (x) { }
      }, 800);
    });
  }
  /* new HUD: the Settings & Features hub renders one tab at a time without the old tab bar */
  window.FridaySet = {
    TABS,
    render: (e, tab) => settings(e, { bare: true, tab }),
    redraw: () => { try { if (REDRAW) REDRAW(); } catch (x) { } },
    ui: { chips, sg, lbl, range, toggle, swatches }
  };
})();
