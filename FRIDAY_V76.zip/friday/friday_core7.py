"""FRIDAY 7.0 core - the single front door for everything new in 7.0 (sits beside friday_core6, never replaces it).

    route(command)         called after the 6.0 core for every typed or spoken command.  Returns (handled, command).  Only claims what a 7.0 module can answer
                           itself (missions, objectives, evidence, savings, security centre ...); everything else flows on to the normal route unchanged.
    prompt_block(q)        a few dated, source-labelled memories and related earlier work for the model prompt (bounded length).
    after_exchange(...)    session log + learning signal, off the critical path.
    speculate(cmd)         optional pre-warm of the routing decision for a command that has just arrived (never changes the answer).
    handle_ui(req)         data + actions for the 7.0 Intelligence pages (replies on `FRIDAY_V7::`).
    boot()                 installs tools and event hooks, recovers interrupted missions, starts the ~10 s housekeeping loop.

Nothing in here touches the microphone, recognition or speech code.  Every module call is wrapped: a failing module is logged and skipped, never fatal.
"""
from __future__ import annotations

import atexit
import re
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

VERSION = K.VERSION
_cfg: Dict[str, Optional[Callable]] = {"speak": lambda t: None, "emit": lambda l: print(l, flush=True), "run_command": None, "busy": lambda: False}
_booted = False
_boot_info: Dict = {}
MAX_ROUTED_CHARS = 1500          # pasted documents / attachments are never pattern-matched against chat commands


def _mod(name: str):
    """Import a 7.0 module lazily and tolerate its absence (the rest of 7.0 keeps working)."""
    try:
        return __import__(name)
    except Exception as exc:
        C.log(f"7.0 module {name} unavailable: {exc}", "recovery")
        return None


def _modules() -> List[Tuple[str, Callable]]:
    """Order matters: approvals and the pending 'which one?' question first, then control, then personal data, then skills."""
    out: List[Tuple[str, Callable]] = []
    for label, modname in (
        ("missions", "friday_orchestrator7"), ("continuity", "friday_continuity7"), ("suggestions", "friday_proactive7"), ("objectives", "friday_goals7"),
        ("policy", "friday_policy7"), ("security", "friday_seccenter7"), ("capabilities", "friday_capabilities7"), ("release", "friday_ci7"),
        ("benchmark", "friday_bench7"), ("improvement", "friday_selfimprove7"), ("repair", "friday_repair7"), ("team", "friday_team7"),
        ("computer", "friday_computer7"), ("memory", "friday_memory7"), ("learning", "friday_learning7"), ("evidence", "friday_evidence7"),
        ("synthesis", "friday_synthesis7"), ("multimodal", "friday_multimodal7"), ("savings", "friday_savings7"), ("graph", "friday_graph7"),
        ("runtime", "friday_runtime7"), ("router", "friday_router7"), ("strategy", "friday_strategy73"), ("freshness", "friday_memory73"), ("performance", "friday_mission73"),
    ):
        m = _mod(modname)
        if m is not None and hasattr(m, "handle"):
            out.append((label, m.handle))
    return out


_MODULES: List[Tuple[str, Callable]] = []


def modules() -> List[Tuple[str, Callable]]:
    if not _MODULES:
        _MODULES.extend(_modules())
    return _MODULES


def configure(**kw):
    """Same keyword arguments the backend already passes to friday_core6.configure (speak, emit, log, busy, run_command, restart_listener, ...)."""
    _cfg.update({k: v for k, v in kw.items() if v is not None and k in ("speak", "emit", "run_command", "busy")})
    K.configure(**{k: kw[k] for k in ("speak", "emit", "run_command", "busy") if kw.get(k) is not None})
    try:
        import friday_orchestrator7 as O
        import friday_stream7 as ST
        O.configure(speak_report=ST.speak_report)
    except Exception as exc:
        C.log(f"core7 configure (speak_report) skipped: {exc}", "recovery")
    try:
        import friday_runtime7 as RT
        RT.configure(**{k: kw[k] for k in ("restart_listener",) if kw.get(k) is not None})
    except Exception:
        pass
    try:
        import friday_proactive7 as PR
        PR.configure(run=_route_text)
    except Exception:
        pass


# ------------------------------------------------------------------ routing
def _route_text(command: str) -> Optional[str]:
    for name, fn in modules():
        try:
            r = fn(command)
        except Exception as exc:
            C.log(f"7.0 {name} handler failed safely: {exc}", "recovery")
            try:
                import friday_security6 as SEC
                SEC.note_failure("module7:" + name)
            except Exception:
                pass
            r = None
        if r:
            return r if isinstance(r, str) else str(r)
    return None


def _say(text: str):
    try:
        _cfg["speak"](text)
    except Exception as exc:
        C.log(f"core7 say failed: {exc}", "recovery")


def route(command: str) -> Tuple[bool, str]:
    """(handled, command). When handled the reply was already spoken."""
    t = (command or "").strip()
    if not t or len(t) > MAX_ROUTED_CHARS:
        return False, command
    low = t.lower().strip(" .!?")
    if low in ("what version are you", "which version are you", "what's your version", "what is your version", "version") or re.match(r"^(?:what(?:'s| is) )?(?:your|the) (?:version|build)$", low):
        _say(f"I'm FRIDAY version {VERSION}.")
        return True, command
    t0 = time.perf_counter()
    r = _route_text(t)
    if r is None:
        try:
            import friday_orchestrator7 as O
            jid = O.maybe_auto(t)          # narrow, late trigger: only a clear several-step goal becomes one verified mission
            if jid:
                _say(f"On it. That's mission {jid.split('-')[-1]}; I'll check every step and report what is actually confirmed.")
                return True, command
        except Exception as exc:
            C.log(f"auto-orchestration skipped: {exc}", "recovery")
        return False, command
    _say(r)
    try:
        import friday_health7 as H
        H.note_response((time.perf_counter() - t0) * 1000, "core7")
    except Exception:
        pass
    return True, command


def speculate(command: str) -> bool:
    try:
        import friday_runtime7 as RT
        return RT.speculate(command)
    except Exception:
        return False


# ------------------------------------------------------------------ prompt and reflection
def prompt_block(question: str, limit: int = 1100) -> str:
    out = ""
    try:
        import friday_memory7 as M
        out += M.prompt_block(question)
    except Exception:
        pass
    try:
        import friday_memory73 as M73
        import friday_memory7 as M7
        note = M73.prompt_note(M7.recall(question, k=3, touch=False, include_legacy=False))
        if note:
            out += "\n" + note
    except Exception:
        pass
    try:
        import friday_continuity7 as CT
        out += CT.context_for(question)
    except Exception:
        pass
    return out[:limit]


def after_exchange(question: str, answer: str, route: str = "fast", ok: bool = True):
    def w():
        try:
            import friday_memory7 as M
            M.log_turn(question, answer)
        except Exception:
            pass
        try:
            import friday_learning7 as L
            L.note_exchange(route, question, answer)
        except Exception:
            pass
    threading.Thread(target=w, name="Friday7Learn", daemon=True).start()


# ------------------------------------------------------------------ boot and housekeeping
def _install_tools():
    import friday_orchestrator7 as O
    O.install_default_tools()
    if "think" not in O.registry.names():           # the 6.0 task tools are normally registered by core6.boot(); make sure missions never lack them
        try:
            import friday_core6 as C6
            C6._register_tools()
            O.registry.sync_from_tasks()
        except Exception as exc:
            C.log(f"6.0 tool sync skipped: {exc}", "recovery")
    for name in ("friday_savings7", "friday_computer7", "friday_evidence7", "friday_multimodal7", "friday_synthesis7", "friday_repair7", "friday_team7", "friday_critic7"):
        m = _mod(name)
        if m is not None and hasattr(m, "install"):
            try:
                m.install(O.registry)
            except Exception as exc:
                C.log(f"install {name} failed safely: {exc}", "recovery")


def _install_events():
    for name in ("friday_memory7", "friday_learning7", "friday_goals7", "friday_seccenter7", "friday_stream7", "friday_graph7", "friday_proactive7"):
        m = _mod(name)
        if m is not None and hasattr(m, "install_events"):
            try:
                m.install_events()
            except Exception as exc:
                C.log(f"events {name} failed safely: {exc}", "recovery")
    # forward a compact set of bus events to the Intelligence pages
    for ev in ("job.state", "job.done", "light_mode", "incident", "lesson.proposed", "improvement.found", "improvement.applied", "repair.proposed", "report.saved",
               "benchmark.done", "investigation.done", "runtime.unloaded", "runtime.recovered", "price.recorded", "objective.created", "objective.done", "objective.blocked"):
        K.on(ev, lambda p, n=ev: K.emit_ui("event", {"name": n, "data": _compact(p)}))


def _compact(p) -> Dict:
    if not isinstance(p, dict):
        return {"value": str(p)[:120]}
    out = {}
    for k, v in p.items():
        if isinstance(v, (int, float, bool)) or v is None:
            out[k] = v
        elif isinstance(v, str):
            out[k] = v[:160]
        elif isinstance(v, (list, tuple)) and len(v) <= 5 and all(isinstance(x, str) for x in v):
            out[k] = [x[:80] for x in v]
    return out


def boot():
    global _booted
    if _booted:
        return
    _booted = True
    try:
        _install_tools()
        _install_events()
        try:
            import friday_runtime7 as RT
            RT.install_default_unloaders()
        except Exception as exc:
            C.log(f"unloaders skipped: {exc}", "recovery")
        try:
            import friday_health7 as H
            H.install_default_checks()
        except Exception as exc:
            C.log(f"health checks skipped: {exc}", "recovery")
        info: Dict = {}
        try:
            import friday_seccenter7 as S7
            info = S7.boot_check()                    # unclean shutdown? pauses interrupted missions, writes a fresh run marker
        except Exception as exc:
            C.log(f"boot check skipped: {exc}", "recovery")
        try:
            import friday_orchestrator7 as O
            paused = O.recover()                      # anything still marked mid-flight cannot be running: pause it, never silently re-run it
            info["paused_jobs"] = list(set((info.get("paused_jobs") or []) + paused))
        except Exception as exc:
            C.log(f"mission recovery skipped: {exc}", "recovery")
        _boot_info.update(info)
        try:
            import friday_memory7 as M
            M.begin_session()
            atexit.register(_end_session)
        except Exception:
            pass
        threading.Thread(target=_loop, name="Friday7Loop", daemon=True).start()
        threading.Thread(target=_late_probe, name="Friday7Probe", daemon=True).start()
        K.emit_ui("ready", {"version": VERSION, "paused": len(_boot_info.get("paused_jobs") or []), "unclean": bool(_boot_info.get("unclean"))})
        if _boot_info.get("paused_jobs") and not _cfg["busy"]():
            n = len(_boot_info["paused_jobs"])
            _say(f"I was interrupted last time. {n} mission{'s' if n != 1 else ''} {'is' if n == 1 else 'are'} paused; say 'resume the mission' to continue from the last verified step.")
    except Exception as exc:
        C.log(f"core7 boot problem: {exc}", "recovery")


def _end_session():
    try:
        import friday_memory7 as M
        import friday_orchestrator7 as O
        done = [j["goal"][:60] for j in O.jobs(8, ("done",)) if time.time() - (j.get("ended") or 0) < 6 * 3600]
        M.end_session(done)
    except Exception:
        pass


def _late_probe():
    """Once per session, a while after start-up and only when idle: check which tools actually work (bounded, read-only self-tests)."""
    try:
        time.sleep(120)
        if _cfg["busy"]():
            time.sleep(60)
        import friday_health7 as H
        if H.light_mode():
            return
        import friday_capabilities7 as CAP
        CAP.probe_tools()
    except Exception as exc:
        C.log(f"late probe skipped: {exc}", "recovery")


def _loop():
    n = 0
    while True:
        time.sleep(10)
        n += 1
        for label, fn in (
            ("objectives", lambda: __import__("friday_goals7").tick()),
            ("runtime", lambda: __import__("friday_runtime7").tick()),
            ("heartbeat", lambda: __import__("friday_seccenter7").heartbeat() if n % 3 == 0 else None),
            ("health", lambda: __import__("friday_health7").sample() if n % 3 == 0 else None),
            ("suggestions", lambda: __import__("friday_proactive7").tick() if n % 6 == 0 else None),
            ("improvement", lambda: __import__("friday_selfimprove7").tick() if n % 6 == 0 else None),
        ):
            try:
                fn()
            except Exception as exc:
                C.log(f"7.0 loop {label} failed safely: {exc}", "recovery")


# ------------------------------------------------------------------ UI channel
def _sec(fn: Callable, *a):
    try:
        return fn(*a)
    except Exception as exc:
        return {"error": f"{type(exc).__name__}: {exc}"[:160]}


def snapshot(tab: str, arg: str = "") -> Dict:
    t = (tab or "overview").lower()
    out: Dict = {"version": VERSION, "tab": t}

    def add(modname: str, fn: str = "ui_snapshot", *a, key: Optional[str] = None):
        m = _mod(modname)
        if m is None or not hasattr(m, fn):
            return
        r = _sec(getattr(m, fn), *a)
        if key and isinstance(r, dict) and list(r.keys()) == [key]:
            r = r[key]                                  # {"graph": {...}} stored under "graph" -> unwrap one level
        if isinstance(r, dict) and not key:
            out.update(r)
        else:
            out[key or modname.replace("friday_", "").replace("7", "")] = r

    if t == "overview":
        add("friday_orchestrator7", "status", key="status")
        add("friday_health7", "snapshot", key="health")
        add("friday_runtime7")
        add("friday_proactive7")
        add("friday_goals7", key="goals")
        add("friday_graph7", key="graph")
        add("friday_policy7", "summary", key="policy")
        out["boot"] = {k: v for k, v in _boot_info.items() if k != "paused_jobs"} | {"paused": len(_boot_info.get("paused_jobs") or [])}
    elif t == "missions":
        add("friday_orchestrator7")
        add("friday_team7", key="team")
        add("friday_repair7")
    elif t == "goals":
        add("friday_goals7")
        add("friday_graph7", key="graph")
        add("friday_continuity7", key="continuity")
        add("friday_proactive7")
    elif t == "memory":
        add("friday_memory7", "ui_snapshot", arg, key="memory")
        add("friday_learning7", key="learning")
    elif t == "evidence":
        add("friday_evidence7", key="evidence")
        add("friday_synthesis7", key="synthesis")
        add("friday_multimodal7", key="multimodal")
    elif t == "security":
        add("friday_seccenter7", key="security")
        add("friday_policy7", "summary", key="policy")
        add("friday_policy7", "rules", key="rules")
        add("friday_policy7", "log", 15, key="decisions")
    elif t == "health":
        add("friday_health7", "snapshot", key="health")
        add("friday_capabilities7", key="capabilities")
        add("friday_runtime7")
        add("friday_stream7", key="stream")
    elif t == "quality":
        add("friday_ci7", key="release")
        add("friday_bench7", key="benchmark")
        add("friday_selfimprove7", key="improvement")
        add("friday_router7", "stats", key="router")
    elif t == "savings":
        add("friday_savings7")
    elif t == "suggestions":
        add("friday_proactive7")
    elif t == "settings":
        out["settings"] = K.cfg_all()
        add("friday_policy7", "summary", key="policy")
    return out


def _command_action(text: str) -> Dict:
    r = _route_text(text)
    return {"text": r or "I can't do that from here."}


def handle_ui(req: dict):
    """req: {"op": "snapshot"|"action", "tab":..., "action":...}. Replies with FRIDAY_V7:: lines; never raises."""
    try:
        op = (req or {}).get("op")
        tab = str((req or {}).get("tab", "overview"))
        if op == "snapshot":
            K.emit_ui("snapshot:" + tab, snapshot(tab, str(req.get("arg", ""))))
            return
        a = str(req.get("action", ""))
        res: Optional[Dict] = None
        if a == "mission_submit":
            import friday_orchestrator7 as O
            jid = O.submit(str(req["goal"])[:600], source="ui")
            res = {"ok": True, "text": f"Mission {jid.split('-')[-1]} started."}
        elif a == "mission_cancel":
            import friday_orchestrator7 as O
            res = {"ok": True, "text": f"Cancelled {O.cancel(req.get('jid') or None)} mission(s)."}
        elif a == "mission_resume":
            import friday_orchestrator7 as O
            j = O.resume(req.get("jid") or None)
            res = {"ok": bool(j), "text": "Resuming from the last verified step." if j else "Nothing to resume."}
        elif a == "mission_approve":
            import friday_orchestrator7 as O
            O.approve(bool(req.get("value", True)))
            res = {"ok": True, "text": "Approved." if req.get("value", True) else "Declined."}
        elif a.startswith("suggestion_"):
            import friday_proactive7 as PR
            res = PR.handle_ui({**req, "action": a[len("suggestion_"):]})
        elif a == "memory_forget":
            import friday_memory7 as M
            M.forget_id(int(req["id"]))
            res = {"ok": True, "text": "Forgotten."}
        elif a == "preference_add":
            import friday_memory7 as M
            r = M.preference_set(str(req["text"])[:300])
            res = {"ok": True, "text": "Saved that preference." if r else "Couldn't save it."}
        elif a == "autonomy_set":
            import friday_policy7 as POL
            lv = POL.set_autonomy(str(req["level"]))
            res = {"ok": bool(lv), "text": f"Autonomy set to {lv.replace('_', ' ')}." if lv else "Choose ask more, balanced or independent."}
        elif a == "rule_set":
            import friday_policy7 as POL
            POL.set_rule(str(req["tool"]), str(req["mode"]), "set in the UI")
            res = {"ok": True, "text": "Rule saved."}
        elif a == "rule_clear":
            import friday_policy7 as POL
            POL.clear_rule(str(req["tool"]))
            res = {"ok": True, "text": "Rule cleared."}
        elif a == "setting_set":
            key = str(req["key"])
            if key not in K.SETTINGS:
                res = {"ok": False, "text": "Unknown setting."}
            else:
                K.cfg_set(key, req.get("value"))
                res = {"ok": True, "text": f"{key} set to {K.cfg_get(key)}."}
        elif a == "command":
            res = {"ok": True, **_command_action(str(req.get("text", ""))[:300])}
        else:
            for modname in ("friday_goals7", "friday_learning7", "friday_savings7", "friday_repair7"):
                m = _mod(modname)
                if m is not None and hasattr(m, "handle_ui"):
                    res = m.handle_ui(req)
                    if res is not None:
                        break
        if res is not None and res.get("output"):
            K.emit_ui("result", {"action": a, "output": str(res["output"])[:8000]})
            res = {**res, "text": "Done - the result is on the page."}
        if res is None:
            res = {"ok": False, "text": "I don't know that action."}
        elif not (res.get("text") or res.get("error")) and a not in ("suggestion_refresh",):
            res = {**res, "text": "Done." if res.get("ok", True) else "That didn't work."}
        if res.get("text") or res.get("error"):
            K.emit_ui("toast", {"text": str(res.get("text") or res.get("error"))[:200]})
        K.emit_ui("snapshot:" + tab, snapshot(tab, str(req.get("arg", ""))))
    except Exception as exc:
        C.log(f"7.0 UI request failed safely: {exc}", "recovery")
        K.emit_ui("toast", {"text": "That didn't work: " + str(exc)[:80]})
