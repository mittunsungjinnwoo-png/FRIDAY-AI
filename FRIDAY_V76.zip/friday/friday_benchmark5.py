"""FRIDAY 5.0 self-benchmark: engineers FRIDAY instead of guessing ("FRIDAY 4.0 -> 88/100").

Offline and deterministic: it measures the parts of FRIDAY that run locally (routing, exact maths, memory, goals, tools,
sandbox, voice endpointing, attachments, speed, error recovery) and records every run so each upgrade has a score.
Categories that need the cloud model (open research, deep reasoning quality) are reported as "needs key" and are not
counted - the score never pretends to measure what it didn't.

    run benchmark   (voice, chat, or Tools page)
"""
from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from typing import Callable, Dict, List, Tuple

HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("FRIDAY_DATA") or (HERE / "friday_data"))
HISTORY = DATA_DIR / "benchmark5.json"
VERSION = "6.0"


def _t(fn: Callable[[], bool]) -> Tuple[bool, float, str]:
    t0 = time.perf_counter()
    try:
        ok = bool(fn())
        err = ""
    except Exception as exc:
        ok, err = False, str(exc)[:80]
    return ok, (time.perf_counter() - t0) * 1000, err


def _reasoning() -> List[Tuple[str, bool]]:
    import friday_router5 as r
    cases = [("what's 25 times 37", "instant"), ("why is my laptop getting hot", "agent"), ("what's the latest news about AI", "research"),
             ("prove that the square root of two is irrational", "deep"), ("tell me a joke", "fast"), ("what time is it", "instant"),
             ("write a python function to merge two sorted lists", "deep"), ("who is the current prime minister of Japan", "research")]
    return [(f"route '{q}' -> {e}", r.classify(q)["route"] == e) for q, e in cases]


def _maths() -> List[Tuple[str, bool]]:
    import friday_router5 as r
    cases = [("what is 25 * 37", "925."), ("15 percent of 240", "36."), ("square root of 144", "12."), ("2 to the power of 10", "1024."),
             ("convert 10 km to miles", "6.2137 miles."), ("100 fahrenheit in celsius", "37.78 degrees Celsius."), ("(12+8)/4", "5."),
             ("twenty five times thirty seven", "925.")]
    return [(f"{q}", r.instant_answer(q) == a) for q, a in cases]


def _coding() -> List[Tuple[str, bool]]:
    import friday_tools5 as t
    out = []
    r = t.run_python("print(sum(range(101)))")
    out.append(("sandbox runs code", r["ok"] and r["stdout"].strip() == "5050"))
    r = t.run_python("raise ValueError('x')")
    out.append(("sandbox reports errors", (not r["ok"]) and "ValueError" in r["stderr"]))
    out.append(("syntax checker finds bug", t.check_python_syntax("def f(:\n  pass") is not None))
    out.append(("syntax checker accepts good code", t.check_python_syntax("x = 1\n") is None))
    return out


def _memory() -> List[Tuple[str, bool]]:
    import friday_knowledge5 as k
    old = k.DB_PATH
    k.reset_for_tests(Path(tempfile.mkdtemp()) / "bench.db")
    try:
        k.remember("The FRIDAY competition submission is due on October 20", kind="fact")
        k.remember("We decided to use SQLite for memory", kind="decision")
        k.ingest_text("spec.txt", "The verifier layer checks every answer before FRIDAY speaks it. " * 15)
        res = [("recall a stored fact", "October 20" in (k.search("when is the competition due") or [{"text": ""}])[0]["text"]),
               ("recall a decision", "SQLite" in (k.handle("what did we decide about memory") or "")),
               ("search the knowledge base", bool(k.search_kb("what does the verifier check"))),
               ("refuse to store secrets", k.remember("my password is hunter2") is None)]
        gid = k.goal_add("Benchmark goal", ["one", "two"])
        k.step_done(gid, 0)
        res.append(("goal progress tracking", k.goals()[0]["progress"] == 50))
        return res
    finally:
        k.reset_for_tests(old)


def _tools() -> List[Tuple[str, bool]]:
    import friday_tools5 as t
    out = [("system diagnosis returns facts", "CPU" in t.diagnose("why is my laptop hot")),
           ("permission revoke/allow", t.handle_permission_command("revoke code running") is not None and not t.perms()["run_code"])]
    t.set_perm("run_code", True)
    out.append(("confirmation gate", "Shall I go ahead" in t.request_confirmation("test", lambda: "ok") and t.answer_confirmation("yes") == "ok"))
    out.append(("secrets redacted in log", "AIza" not in t.redact("key AIzaSyA1234567890123456789012345")))
    return out


def _voice() -> List[Tuple[str, bool]]:
    import numpy as np
    import friday_voice5 as v
    rng = np.random.default_rng(3)

    def noise(ms): return rng.normal(0, 30, int(16000 * ms / 1000)).astype(np.int16)

    def speech(ms):
        n = int(16000 * ms / 1000)
        tt = np.arange(n) / 16000
        return (4000 * (np.sin(2 * np.pi * 180 * tt) + 0.6 * np.sin(2 * np.pi * 720 * tt)) / 1.6 + rng.normal(0, 40, n)).astype(np.int16)
    sig = np.concatenate([noise(500), speech(1000), noise(1500)]).tobytes()
    seg = v.Segmenter()
    n_speech = int(1500 / v.FRAME_MS)
    lat = None
    for i in range(0, len(sig) - v.FRAME_BYTES + 1, v.FRAME_BYTES):
        for e in seg.feed(sig[i:i + v.FRAME_BYTES]):
            if e.kind == "final":
                lat = (i // v.FRAME_BYTES - n_speech) * v.FRAME_MS
    return [("endpoint detected within 650 ms of silence", lat is not None and lat <= 650),
            ("wake word variants", v.find_wake("hey fryday open chrome") == (True, "open chrome")),
            ("hallucination filter", v.looks_like_hallucination("Thank you.", 0.4, 150))]


def _attachments() -> List[Tuple[str, bool]]:
    import friday_attach5 as a
    d = tempfile.mkdtemp()
    p = os.path.join(d, "x.py")
    Path(p).write_text("print('bench')\n")
    items = a.inspect_all([p])
    f = a.FileBlockFilter()
    spoken = "".join(a.filter_stream(["ok <<<FILE:a.txt>>>\nhi\n<<<END>>> done"], f))
    return [("reads attached code", bool(items) and "bench" in items[0].get("content", "")),
            ("file blocks removed from speech", spoken == "ok  done" and f.files == [("a.txt", "hi\n")])]


def _speed() -> List[Tuple[str, bool]]:
    import friday_router5 as r
    import friday_knowledge5 as k
    old = k.DB_PATH
    k.reset_for_tests(Path(tempfile.mkdtemp()) / "speed.db")
    try:
        for i in range(300):
            k.remember(f"fact number {i} about topic{i % 20} and widget{i}")
        ok1, ms1, _ = _t(lambda: r.instant_answer("what is 12 times 12") == "144.")
        ok2, ms2, _ = _t(lambda: len(k.search("topic7 widget")) > 0)
        ok3, ms3, _ = _t(lambda: r.classify("tell me about the planets")["route"] == "fast")
        return [(f"instant answer {ms1:.1f} ms (<50)", ok1 and ms1 < 50), (f"memory search over 300 facts {ms2:.1f} ms (<50)", ok2 and ms2 < 50),
                (f"routing {ms3:.2f} ms (<5)", ok3 and ms3 < 5)]
    finally:
        k.reset_for_tests(old)


def _reliability() -> List[Tuple[str, bool]]:
    import friday_tools5 as t
    r = t.run_python("while True: pass", timeout=1.0)
    return [("runaway code is stopped by timeout", (not r["ok"]) and "timeout" in r["stderr"].lower()),
            ("bad input handled", __import__("friday_router5").instant_answer("what is 1/0") is None)]


CATEGORIES: Dict[str, Tuple[Callable, int]] = {
    "Reasoning & routing": (_reasoning, 15), "Mathematics": (_maths, 15), "Coding & sandbox": (_coding, 12), "Memory & goals": (_memory, 14),
    "Tool use": (_tools, 10), "Voice pipeline": (_voice, 10), "Attachments": (_attachments, 8), "Speed": (_speed, 8), "Error recovery": (_reliability, 8),
}


def run_all() -> dict:
    cats = {}
    total = 0.0
    weight = 0
    for name, (fn, w) in CATEGORIES.items():
        try:
            rows = fn()
        except Exception as exc:
            rows = [(f"category crashed: {exc}", False)]
        passed = sum(1 for _, ok in rows if ok)
        score = passed / max(1, len(rows))
        cats[name] = {"score": round(score * 100), "passed": passed, "total": len(rows), "weight": w,
                      "failed": [n for n, ok in rows if not ok]}
        total += score * w
        weight += w
    res = {"version": VERSION, "score": round(total / weight * 100), "categories": cats, "at": time.strftime("%Y-%m-%d %H:%M"),
           "not_measured": ["Live research quality", "Deep reasoning quality (needs the Gemini key)", "Camera / screen vision accuracy (needs hardware)"]}
    try:
        hist = json.loads(HISTORY.read_text()) if HISTORY.exists() else []
        hist.append({"version": VERSION, "score": res["score"], "at": res["at"]})
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        HISTORY.write_text(json.dumps(hist[-50:], indent=1))
        res["history"] = hist[-5:]
    except Exception:
        pass
    return res


def spoken_summary(res: dict) -> str:
    weak = [f"{n} {c['score']}" for n, c in res["categories"].items() if c["score"] < 100]
    s = f"FRIDAY {res['version']} scores {res['score']} out of 100."
    s += (" Weak spots: " + ", ".join(weak) + ".") if weak else " Every local test passed."
    hist = res.get("history") or []
    if len(hist) >= 2:
        d = hist[-1]["score"] - hist[-2]["score"]
        s += f" That is {'up' if d > 0 else 'down' if d < 0 else 'level'} {abs(d)} from the last run." if d else " Same as the last run."
    return s


if __name__ == "__main__":
    r = run_all()
    print(json.dumps(r, indent=1))
