"""FRIDAY reliability layer.

Bounded retries, exponential backoff+jitter, circuit breaking, atomic JSON writes,
input normalization and lightweight health metrics. This module is dependency-free
and intentionally safe to import during startup.
"""
from __future__ import annotations
import json, os, random, tempfile, threading, time
from collections import defaultdict, deque
from pathlib import Path
from typing import Callable, TypeVar

T = TypeVar("T")

class CircuitOpen(RuntimeError):
    pass

class CircuitBreaker:
    def __init__(self, name: str, failure_threshold: int = 3, reset_after: float = 20.0):
        self.name=name; self.failure_threshold=max(1,failure_threshold); self.reset_after=max(1.0,reset_after)
        self.failures=0; self.opened_at=0.0; self._lock=threading.Lock()
    def before_call(self):
        with self._lock:
            if not self.opened_at: return
            if time.monotonic()-self.opened_at < self.reset_after:
                raise CircuitOpen(f"circuit open: {self.name}")
            self.opened_at=0.0
    def success(self):
        with self._lock: self.failures=0; self.opened_at=0.0
    def failure(self):
        with self._lock:
            self.failures += 1
            if self.failures >= self.failure_threshold: self.opened_at=time.monotonic()

_BREAKERS = {}
_LOCK=threading.Lock()
_METRICS=defaultdict(lambda: {"calls":0,"success":0,"failure":0,"last_error":"","latency_ms":0.0})
_LATENCIES=defaultdict(lambda: deque(maxlen=100))

def breaker(name, failure_threshold: int | None = None, reset_after: float | None = None):
    with _LOCK:
        b = _BREAKERS.get(name)
        if b is None:
            b = CircuitBreaker(name, failure_threshold=failure_threshold or 3, reset_after=reset_after or 20.0)
            _BREAKERS[name] = b
        return b

def run_resilient(name: str, fn: Callable[[], T], attempts: int = 3, base_delay: float = .35,
                  max_delay: float = 4.0, retry_if: Callable[[Exception], bool] | None = None,
                  failure_threshold: int | None = None, reset_after: float | None = None) -> T:
    # V2045: failure_threshold/reset_after let a call site configure a more
    # tolerant breaker for one-off, USER-INITIATED work (e.g. "research
    # this for me now") where each call is a distinct request that
    # deserves its own honest attempt, as opposed to rapid automated
    # polling where a strict, fast-tripping breaker is exactly what you
    # want. Defaults are unchanged for every existing caller that doesn't
    # pass these.
    attempts=max(1,int(attempts)); b=breaker(name, failure_threshold, reset_after); last=None
    for n in range(attempts):
        b.before_call(); started=time.perf_counter(); _METRICS[name]["calls"]+=1
        try:
            result=fn(); elapsed=(time.perf_counter()-started)*1000
            _METRICS[name]["success"]+=1; _LATENCIES[name].append(elapsed); _METRICS[name]["latency_ms"]=round(sum(_LATENCIES[name])/len(_LATENCIES[name]),1)
            b.success(); return result
        except Exception as exc:
            last=exc; _METRICS[name]["failure"]+=1; _METRICS[name]["last_error"]=str(exc)[:300]; b.failure()
            if n+1>=attempts or (retry_if and not retry_if(exc)): break
            delay=min(max_delay, base_delay*(2**n))*(0.75+random.random()*0.5)
            time.sleep(delay)
    raise last

def atomic_json_save(path, data):
    """Crash-safe JSON persistence: write temp file, flush, atomically replace."""
    target=Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd,"w",encoding="utf-8") as f:
            json.dump(data,f,indent=4,ensure_ascii=False); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,target)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def load_json_recover(path, default):
    try:
        with open(path,"r",encoding="utf-8") as f: return json.load(f)
    except Exception:
        # Preserve a corrupt file for diagnosis instead of destroying it.
        try:
            p=Path(path)
            if p.exists(): p.rename(p.with_suffix(p.suffix+f".corrupt-{int(time.time())}"))
        except Exception: pass
        return default

def health_snapshot():
    out={}
    for name,m in _METRICS.items():
        calls=m["calls"]; out[name]={**m,"success_rate":round(m["success"]/calls,3) if calls else None,
                                     "circuit_open": bool(_BREAKERS.get(name) and _BREAKERS[name].opened_at)}
    return out
