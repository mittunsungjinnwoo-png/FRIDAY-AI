# FRIDAY V7.2 - Fast human replies, visible Thinking/Speaking status, widget button back

Same mechanism as JARVIS V2339, adapted to FRIDAY. Wake word, listening, speech recognition, voice, finance/food features, vision,
Settings and every other feature are untouched.

## 1. Replies within seconds, like a person (friday_backend.py)
Measured with a simulated 0.8 s Gemini call (before -> after, time to first word):
| Command | Before | After |
|---|---|---|
| "thanks" / "how are you" | ~1.3-1.7 s | ~0.03 s (local) |
| plain questions ("what is...", "explain...", chat) | ~1.3 s | ~0.55 s (first streamed token) |
| maths ("solve the integral...") | ~2.5 s (3 high-thinking calls) | ~0.55 s |

What was slow: every chat message first waited on a blocking "which intent is this?" Gemini call, and anything the router tagged
"deep" ran three sequential high-thinking calls before speaking.
- Instant local small talk: greetings, thanks, how are you, good morning/night, are you there, nice, I'm back. Varied natural
  replies, recorded in the conversation, skipped while any question/flow is pending (WhatsApp, calls, downloads, permission, study).
  `FRIDAY_INSTANT_SMALLTALK=0` turns it off.
- The intent classifier only runs when the message contains a cue word, and is time-boxed (`FRIDAY_INTENT_TIMEOUT`, 1.6 s). The AI
  action router is time-boxed too (`FRIDAY_ROUTER_TIMEOUT`, 3.0 s).
- The deep multi-call route runs only when you ask for careful reasoning ("prove", "step by step", "think carefully",
  "double-check", "verify this") or set `FRIDAY_DEEP_VERIFY=1`. The stronger model is used for hard or long (24+ words) questions only.
- Human voice prompt: friend-like spoken English, contractions, reacts to your mood, 1-2 sentences for chat, no markdown read aloud,
  no "Certainly/Absolutely", "sir" only occasionally.
- `FRIDAY_LATENCY:: first_text_ms=...` is printed for every reply so you can see the real time to first word.

## 2. Visible status: Thinking / Speaking / Listening (index.html, friday_ui8.js, friday_hud.css, widget.html)
- The old status text sat in a screen-reader-only element, so it was never visible. A status chip now sits in the header:
  Thinking (amber, pulsing), Speaking (green, pulsing), Hearing you, Listening, Say "Friday" (standby wake), Standby, Mic off.
- The desktop widget's status pill now shows LISTENING / HEARING YOU / THINKING / SPEAKING instead of always ONLINE.

## 3. Widget mode button
The button was stuck in a hidden legacy block. It is now in the title bar next to Minimize (also Ctrl+Shift+W and the logo in the
footer, as before).

## Test
`python FRIDAY_TEST_V72_FAST_HUMAN.py` (FRIDAY_TEST_V70 and the other existing tests still pass).
Real timings depend on Gemini, network and the TTS engine; check the FRIDAY_LATENCY:: lines on your laptop.
