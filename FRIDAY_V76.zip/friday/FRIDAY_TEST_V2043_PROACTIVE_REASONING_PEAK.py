import hashlib
import friday_proactive_reasoning as p

r = p.analyze(
    'research the latest information, compare reliable sources, and create a PDF report',
    task_steps=['web_research', 'document_creation'],
)
assert r['version'] == '2043.0'
assert r['signals']['research'] is True and r['signals']['creation'] is True
assert any(x['step'] == 'source_quality_check' for x in r['inferred_prerequisites'])
assert any(x['step'] == 'uncertainty_boundary_check' for x in r['inferred_prerequisites'])
assert any(x['step'] == 'output_integrity_check' for x in r['inferred_prerequisites'])
assert any(x['action'] == 'verify_generated_artifact' for x in r['anticipated_followups'])
assert r['dependency_graph']['acyclic'] is True
assert r['reasoning_contract']['counterfactual_analysis'] is True
assert r['reasoning_contract']['lookahead_depth'] == 3
assert r['autonomy_boundary'].startswith('anticipate_and_prepare_only')

c = p.analyze('send a message', task_steps=['communication'])
assert c['risk_model']['level'] in {'moderate', 'high', 'critical'}
assert any(x['field'] == 'recipient' for x in c['missing_constraints'])
assert c['recommended_behavior'] == 'clarify before consequential action'
assert c['clarification_required'] is True
assert c['risk_model']['consequential_action_allowed'] is False

p.record_outcome('research and create report', 'success')
h = p.health()
assert h['version'] == '2043.0'
assert h['autonomous_consequential_actions'] is False
assert h['network_dependency'] is False
assert h['background_worker'] is False
assert h['lookahead_depth'] == 3
print('V2043_PROACTIVE_REASONING_PEAK=PASS')
