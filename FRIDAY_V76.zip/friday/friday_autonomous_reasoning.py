"""FRIDAY Autonomous Initiative Engine v4010.

Asynchronous, additive autonomy. It never replaces the normal command path and
never performs consequential actions without the existing supervisor gates.
"""
from __future__ import annotations
import re, threading, time
from typing import Any
import friday_state_engine as state
import friday_supervisor as supervisor
_VERSION="4010-autonomy-1"; _LOCK=threading.RLock(); _LAST={}; _STARTED=False
_RULES=(
 ("whatsapp",(r"\bwhatsapp\b",r"\bmessage\b",r"\bcontact\b",r"\bcall\b")),
 ("browser",(r"\bresearch\b",r"\bsearch\b",r"\blook up\b",r"\bwebsite\b",r"\burl\b",r"\blatest\b",r"\bcurrent\b",r"\byoutube\b")),
 ("word",(r"\bword\b",r"\bdocx?\b",r"\bdocument\b",r"\breport\b",r"\bessay\b")),
 ("excel",(r"\bexcel\b",r"\bxlsx?\b",r"\bspreadsheet\b")),
 ("powerpoint",(r"\bpowerpoint\b",r"\bpptx?\b",r"\bpresentation\b",r"\bslides\b")),)
def _n(x): return re.sub(r"\s+"," ",str(x or "").strip().lower())
def _cool(k,sec=45):
 now=time.time()
 with _LOCK:
  if now-_LAST.get(k,0)<sec:return False
  _LAST[k]=now;return True
def _active():
 e=state.get("environment") or {};return _n(e.get("active_window") or e.get("active_application"))
def _already(a,l):
 aliases={"browser":("chrome","edge","firefox","brave","opera","browser"),"whatsapp":("whatsapp",),"word":("word","winword"),"excel":("excel",),"powerpoint":("powerpoint",)}.get(l,(l,))
 return any(x in a for x in aliases)
def _goal(l):
 return {"browser":"open a web browser so the current research or web task can continue","whatsapp":"open WhatsApp so the current communication task is ready","word":"open Microsoft Word so the current document task can continue","excel":"open Microsoft Excel so the current spreadsheet task can continue","powerpoint":"open Microsoft PowerPoint so the current presentation task can continue"}[l]
def _run(l,c):
 if not _cool(l+":"+_n(c)[:160]):return
 try:
  import friday_unified_gateway as gateway; gateway.register_default_agents()
 except Exception: pass
 try:
  r=supervisor.run_goal(_goal(l),priority=.35,proactive=True)
  ok=isinstance(r,dict) and str(r.get("status","")).upper() in {"COMPLETED","SUCCESS"}
  state.update("autonomy",last_action=l,last_result="success" if ok else "partial",last_ts=time.time(),version=_VERSION)
 except Exception as e:
  state.update("autonomy",last_action=l,last_result="error",last_error=str(e)[:500],last_ts=time.time(),version=_VERSION)
def on_command_completed(command:str)->None:
 if command: threading.Thread(target=_check,args=(str(command),),daemon=True,name="Friday-Autonomy-PostTurn").start()
def _check(command):
    time.sleep(.08)
    try:
        low=_n(command); active=_active()
        matches=[(l,p) for l,p in _RULES if any(re.search(x,low) for x in p)]
        if not matches:return
        l,_=matches[0]
        # Only prepare when the user's explicit turn clearly establishes a goal.
        if not re.search(r"\b(research|search|look up|find|create|make|write|draft|report|document|spreadsheet|presentation|message|contact|call|open|launch|start|work on)\b",low):return
        # Never auto-send/call. Communication is preparation only.
        if l=="whatsapp" and re.search(r"\b(send|message|call|contact)\b",low):
            # Existing confirmation/state machine remains authoritative.
            try: state.update("autonomy",prepared="whatsapp",reason="communication task detected",last_ts=time.time())
            except Exception: pass
            return
        if _already(active,l):return
        # Use the existing supervisor and launcher so autonomy cannot bypass policy.
        _run(l,command)
    except Exception: pass

def start():
 global _STARTED
 with _LOCK:
  if _STARTED:return
  _STARTED=True
 state.update("autonomy",enabled=True,version=_VERSION,policy="high-confidence low-impact preparatory actions; consequential actions remain gated")
def health()->dict[str,Any]:
 with _LOCK:return {"version":_VERSION,"started":_STARTED,"tracked_actions":len(_LAST),"mode":"asynchronous preparatory autonomy"}
