"""Download the Whisper speech model ONCE, before you ever talk to FRIDAY.

Run this after installing requirements, or any time you change
FRIDAY_WHISPER_MODEL:

    python predownload_speech_model.py
    python predownload_speech_model.py tiny.en

Doing this means the model is already on disk at startup, so your very first
command uses the fast local engine instead of falling back to Google STT
while the download finishes.
"""
import sys
import time

import friday_voice_engine as engine


def main():
    if not engine.faster_whisper_available():
        print("faster-whisper and/or numpy are not installed.")
        print("Install them with:  pip install faster-whisper numpy")
        return 1

    name = sys.argv[1].strip() if len(sys.argv) > 1 else engine.resolve_model_name()
    print(f"Model: {name}")
    if engine.is_model_cached(name):
        print("Already downloaded. Nothing to do.")
    else:
        print("Not cached - downloading now (this is the slow part, one time only)...")

    import os
    os.environ["FRIDAY_WHISPER_MODEL"] = name
    started = time.time()
    engine.preload(blocking=True)

    if engine.is_ready():
        print(f"Ready in {time.time() - started:.1f}s.")
        print(f"Set FRIDAY_WHISPER_MODEL={name} so FRIDAY always uses this one.")
        return 0
    print("Failed to load:", engine.load_error())
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
