# FRIDAY V2.2.4 - reliable Gemini connection + clean uninstall

Nothing was removed or redesigned. Voice, listening, UI, finance, notes and every other feature are untouched.

## Why "I'm having trouble reaching Gemini" appeared even with a key saved
- "Save & Test" never actually tested anything - it only said "saved".
- Every different failure (bad key, unknown model, no internet, quota) produced the same sentence, and the promised "retry automatically" never happened.
- A half-installed private Python runtime was trusted forever; pip output was never read, so setup could hang or fail silently.

## Connection fixes
- **Save & Test is real**: sends a live request and shows the true result in Settings > AI (key rejected / quota / model unavailable / no internet / connected). New **Test connection** button.
- **Truthful errors**: FRIDAY now says the actual reason, both on screen and spoken.
- **Really retries**: network/busy errors retry the same model with back-off, then once more for the whole question. A per-model quota limit moves on to the next model.
- **Self-healing**: if no listed model works, FRIDAY asks Google which models the key can use and switches (and remembers it). A background check reconnects automatically when the internet or Google comes back.
- **Tolerant key paste**: quotes, spaces, line breaks, `key=` or `Bearer ` are stripped. "Remove key" now truly removes it.
- **Missing SDK**: if `google-genai` is missing from the Python in use, FRIDAY installs it once automatically.
- **Engine crash recovery**: if the Python engine dies unexpectedly it restarts and re-sends your saved key (max 5 times in 2 minutes; a normal "goodbye" is not restarted).
- A broken/partial private Python runtime is detected and rebuilt; setup output goes to `runtime\setup.log`.
- Only one FRIDAY can run at once (a second launch brings the existing window forward instead of starting a second engine/microphone user).

## Uninstall
- Settings > AI > **Uninstall FRIDAY...** (with confirmation) opens the Windows uninstaller. Also: Windows Settings > Apps.
- Uninstaller force-stops FRIDAY and its Python engine first, so it is never blocked.
- Uninstaller asks whether to also delete saved data (default: keep).

## Files changed
`friday_backend.py`, `main.js`, `preload.js`, `friday_settings.js`, `package.json` (2.2.4, NSIS include), new `installer.nsh`.
