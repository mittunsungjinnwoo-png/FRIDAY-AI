"""
FRIDAY VISION CONFIG
--------------------
One small, dependency-free settings store shared by every OpenCV-5 vision module
(engine, agent, safety, metrics, cloud, hub).  Values are edited from
FRIDAY > Settings > Vision and persisted as JSON in friday_data/vision_config.json.

Secrets (the optional cloud access token) are NEVER written here: the Electron app keeps
them in Windows secure storage and hands them to the backend at start-up; they live only
in this process's memory (see set_secret / secret).
"""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any

DATA_DIR = Path(os.environ.get("FRIDAY_VISION_DATA") or os.environ.get("FRIDAY_DATA") or (Path(__file__).parent / "friday_data"))
CONFIG_FILE = DATA_DIR / "vision_config.json"

DEFAULTS: dict[str, Any] = {
    # --- sources / privacy -------------------------------------------------
    "camera_index": 0,                 # which camera (0 = first)
    "camera_auto_off_minutes": 15,     # the camera switches itself off after this long (0 = never)
    "camera_allow_cloud": False,       # may camera frames be sent to Gemini / your cloud endpoint?
    "chat_camera_describe": True,      # when you ask FRIDAY (chat or voice) what she sees, may that ONE camera picture go to Gemini for a human-style description?
    "screen_allow_cloud": True,        # may screenshots be sent to Gemini when you ask a visual question?
    "monitor_index": 1,                # which monitor to look at (0 = all monitors together)
    # --- OpenCV vision engine ---------------------------------------------
    "detector": "auto",                # auto | onnx | builtin | contours
    "onnx_model_path": "",             # optional detector model (.onnx) run on OpenCV 5's DNN engine
    "onnx_labels_path": "",            # optional labels file (one label per line); COCO is built in
    "onnx_input_size": 640,
    "onnx_output_format": "auto",      # auto | yolov8 | yolov5 | end2end
    "dnn_engine": "auto",              # auto | new | classic   (OpenCV 5 DNN engines)
    "conf_threshold": 0.35,
    "nms_threshold": 0.45,
    "analysis_max_side": 960,          # frames are shrunk to this before analysis (speed)
    "motion_sensitivity": 50,          # 1 (calm) .. 100 (very sensitive)
    "motion_min_area": 500,
    "change_threshold": 0.012,         # fraction of changed pixels that counts as "changed"
    "ocr_language": "eng",
    "tesseract_path": "",              # leave empty to auto-detect
    "preview_fps": 4,
    # --- agent --------------------------------------------------------------
    "agent_enabled": True,
    "agent_auto_claim": False,         # let the agent also take "open my ... notes/file" style requests
    "agent_max_steps": 8,
    "agent_max_replans": 2,
    "agent_use_gemini_planner": True,
    "agent_use_gemini_verifier": True,
    # --- agentic problem solver (V7.5): observe -> detect -> propose -> approve -> act -> verify ----------------------------
    "agentic_enabled": True,
    "agentic_max_attempts": 3,         # most different fixes she will try for one problem (each one asks you first)
    "agentic_settle_seconds": 4.0,     # how long she keeps looking after a fix before deciding whether it worked
    "agentic_use_gemini": True,        # second opinion on borderline detections / reading text when OCR is missing (only if screen_allow_cloud is on)
    "agentic_watch_interval": 6,       # seconds between checks while "watch for errors" is on
    # --- safety -------------------------------------------------------------
    "safety_confirm_yellow": True,     # ask before yellow (confirm-level) actions
    "safety_restricted_policy": "block",   # block | typed_confirm  (what happens to red actions)
    "safety_confirm_timeout": 60,
    # --- cloud (optional) ---------------------------------------------------
    "cloud_enabled": False,
    "cloud_url": "",                   # e.g. https://your-graviton-host:8443
    "cloud_timeout": 20,
    "cloud_fallback_local": True,
}

_LOCK = threading.RLock()
_VALUES: dict[str, Any] = dict(DEFAULTS)
_SECRETS: dict[str, str] = {}
_LOADED = False


def _coerce(key: str, value: Any) -> Any:
    default = DEFAULTS.get(key)
    try:
        if isinstance(default, bool):
            if isinstance(value, str):
                return value.strip().lower() in {"1", "true", "yes", "on"}
            return bool(value)
        if isinstance(default, int):
            return int(float(value))
        if isinstance(default, float):
            return float(value)
        if isinstance(default, str):
            return str(value if value is not None else "").strip()[:600]
    except Exception:
        return default
    return value


def _load() -> None:
    global _LOADED
    if _LOADED:
        return
    _LOADED = True
    try:
        if CONFIG_FILE.exists():
            raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                for k, v in raw.items():
                    if k in DEFAULTS:
                        _VALUES[k] = _coerce(k, v)
    except Exception:
        pass


def _save() -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        tmp = CONFIG_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_VALUES, indent=2), encoding="utf-8")
        os.replace(tmp, CONFIG_FILE)
    except Exception:
        pass


def get(key: str, default: Any = None) -> Any:
    with _LOCK:
        _load()
        return _VALUES.get(key, DEFAULTS.get(key, default))


def all_values() -> dict[str, Any]:
    with _LOCK:
        _load()
        return dict(_VALUES)


def update(changes: dict[str, Any]) -> dict[str, Any]:
    """Apply a dict of setting changes (unknown keys are ignored) and persist."""
    with _LOCK:
        _load()
        for k, v in (changes or {}).items():
            if k in DEFAULTS:
                _VALUES[k] = _coerce(k, v)
        _save()
        return dict(_VALUES)


def reset() -> dict[str, Any]:
    with _LOCK:
        _VALUES.clear()
        _VALUES.update(DEFAULTS)
        _save()
        return dict(_VALUES)


# ---- in-memory secrets ------------------------------------------------------
def set_secret(name: str, value: str) -> None:
    with _LOCK:
        if value:
            _SECRETS[str(name)] = str(value)
        else:
            _SECRETS.pop(str(name), None)


def secret(name: str) -> str:
    with _LOCK:
        return _SECRETS.get(str(name), "") or os.environ.get("FRIDAY_" + str(name).upper(), "")


def has_secret(name: str) -> bool:
    return bool(secret(name))
