"""FRIDAY 7.0 capability registry (roadmap #26): an accurate inventory of what actually works.

For every tool the orchestrator can use it records
    dependencies   Python modules / operating system it needs (checked, not assumed)
    permission     the FRIDAY permission that must be on, and whether it is on
    test status    a safe self-test result (read-only tools only) with timing
    performance    calls, success rate, average time, last error  (from the execution receipts)
    limitations    plain-language limits
and turns that into one verdict - works / untested / degraded / unavailable - with the reason.

`tool_usable(tool)` gives the planner a True / False / None ("can't tell") so it never builds a plan on a tool that cannot run here.
Nothing here uses the microphone, recognition or speech code.
"""
from __future__ import annotations

import importlib.util
import os
import re
import shutil
import sys
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS caps7(tool TEXT PRIMARY KEY, ts REAL, status TEXT, detail TEXT, ms REAL, ok INTEGER);
""")

_WIN = sys.platform.startswith("win")
CACHE_S = 60.0
_cache: Dict[str, Tuple[float, Dict]] = {}
_lock = threading.Lock()

# tool -> hard requirements / soft requirements / limits.  Anything not listed has no special dependency.
KNOWN: Dict[str, Dict[str, Any]] = {
    "investigate": {"py": ["requests", "bs4"], "net": True, "limits": "needs the internet; pages behind sign-in or paywalls cannot be read; dates are only as good as the page shows them"},
    "web_research": {"py": ["requests"], "net": True, "limits": "needs the internet"},
    "multimodal_understand": {"py": ["PIL"], "soft": ["pytesseract", "pypdf"], "limits": "reads text from images only if OCR (Tesseract) is installed; describes pictures only with a vision model"},
    "capture_verify": {"soft": ["PIL", "cv2"], "limits": "screen capture needs a display; camera capture needs OpenCV and a camera"},
    "window_control": {"os": "windows", "limits": "Windows only: maximise / restore / minimise / focus are done with Win32 window calls and read back"},
    "open_app": {"limits": "launches installed apps; apps that are not installed open their website instead"},
    "open_file": {"limits": "opens files found by the file index; never opens a website for a file name"},
    "file_op": {"limits": "delete moves to a recoverable trash folder; nothing is erased"},
    "find_file": {"limits": "searches the indexed folders (Documents, Desktop, Downloads, plus any in friday_data/file_roots.txt)"},
    "computer_act": {"limits": "routes one command to the tools above; it does not click through arbitrary screens"},
    "cost_recipe": {"limits": "uses prices YOU recorded; unrecorded items are listed as unpriced, never guessed"},
    "compare_costs": {"limits": "compares only recorded prices"},
    "budget_check": {"limits": "uses the income / expense figures stored in the finance engine"},
    "finance_snapshot": {"limits": "exact stored figures only"},
    "synthesize": {"limits": "cites only evidence it was given; researched, calculated and estimated evidence are kept apart"},
    "save_report": {"limits": "writes into FRIDAY's outputs folder and never overwrites"},
    "critic_review": {"limits": "deterministic checks first; a model review only when the importance justifies it"},
    "repair_inspect": {"limits": "read-only"},
    "repair_propose": {"limits": "proposals are tested in a copy; nothing is changed without your approval"},
    "run_tests": {"limits": "runs the project's own tests with a time limit"},
    "team_run": {"limits": "specialists run in a bounded pool (2 at a time)"},
}

# safe, read-only self-tests: tool -> args
SELF_TESTS: Dict[str, Dict] = {
    "finance_snapshot": {},
    "cost_recipe": {"text": "2 eggs, 1 cup rice"},
    "find_file": {"query": "readme"},
    "capture_verify": {"kind": "file", "path": __file__},
    "synthesize": {"topic": "self test", "material": "[calculated] Check\nTotal: Rs 10.00 for 2 items.", "use_model": False},
    "system_info": {},
}


# tools whose honest answer to the self-test may be "nothing found / nothing recorded": that still proves the tool ran and answered correctly
TOLERATE_NOT_OK = {"cost_recipe", "find_file"}


def _module_ok(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        return False


def _dep_check(tool: str) -> Dict:
    spec = KNOWN.get(tool, {})
    missing = [m for m in spec.get("py", []) if not _module_ok(m)]
    soft_missing = [m for m in spec.get("soft", []) if not _module_ok(m)]
    os_bad = bool(spec.get("os") == "windows" and not _WIN)
    if "pytesseract" in spec.get("soft", []) and _module_ok("pytesseract") and not shutil.which("tesseract") and not _WIN:
        soft_missing.append("tesseract program")
    return {"missing": missing, "soft_missing": soft_missing, "os_ok": not os_bad, "needs_net": bool(spec.get("net"))}


def _permission(tool: str, entry: Dict) -> Dict:
    perm = entry.get("permission")
    if not perm:
        return {"needed": "", "granted": True}
    try:
        import friday_tools5 as T5
        return {"needed": perm, "granted": bool(T5.perms().get(perm, True))}
    except Exception:
        return {"needed": perm, "granted": True}


def _usage(tool: str, since_s: float = 86400) -> Dict:
    try:
        rows = C.q("SELECT COUNT(*) n, SUM(ok) g, AVG(ms) ms FROM receipts7 WHERE tool=? AND ts>=?", (tool, time.time() - since_s))
        n, g, ms = (rows[0]["n"], rows[0]["g"] or 0, rows[0]["ms"] or 0) if rows else (0, 0, 0)
        last = C.q("SELECT ok, error, ts FROM receipts7 WHERE tool=? ORDER BY id DESC LIMIT 3", (tool,))
        last_fail = next((r for r in last if not r["ok"]), None)
        return {"calls": n, "ok": g, "rate": round(g / n, 3) if n else None, "avg_ms": int(ms), "last_error": (last_fail["error"] if last_fail else "")[:120],
                "recent_fail_streak": len(last) >= 3 and all(not r["ok"] for r in last)}
    except Exception:
        return {"calls": 0, "ok": 0, "rate": None, "avg_ms": 0, "last_error": "", "recent_fail_streak": False}


def _registry():
    try:
        import friday_orchestrator7 as O
        return O.registry
    except Exception:
        return None


def assess(tool: str) -> Dict:
    """Verdict for one tool: {tool, status, reason, ...}."""
    with _lock:
        hit = _cache.get(tool)
        if hit and time.time() - hit[0] < CACHE_S:
            return hit[1]
    reg = _registry()
    if reg is None or not reg.has(tool):
        out = {"tool": tool, "status": "unknown", "reason": "not registered", "registered": False}
    else:
        entry = reg.get(tool)
        dep, perm, use = _dep_check(tool), _permission(tool, entry), _usage(tool)
        t = C.q("SELECT * FROM caps7 WHERE tool=?", (tool,))
        test = dict(t[0]) if t else None
        if dep["missing"]:
            status, reason = "unavailable", "missing Python package(s): " + ", ".join(dep["missing"])
        elif not dep["os_ok"]:
            status, reason = "unavailable", f"needs {KNOWN[tool]['os'].title()} (this computer: {sys.platform})"
        elif not perm["granted"]:
            status, reason = "unavailable", f"the '{perm['needed']}' permission is switched off"
        elif use["recent_fail_streak"] and (use["rate"] or 0) < 0.4:
            status, reason = "degraded", f"failing lately: {use['last_error'] or 'repeated errors'}"
        elif test and not test["ok"]:
            status, reason = "degraded", f"self-test failed: {test['detail'][:100]}"
        elif use["calls"] >= 3 and (use["rate"] or 0) >= 0.7:
            status, reason = "works", f"{int(use['rate'] * 100)}% success over {use['calls']} run(s) in the last day"
        elif test and test["ok"]:
            status, reason = "works", f"self-test passed ({int(test['ms'])} ms)"
        else:
            status, reason = "untested", "no recent runs and no self-test yet"
        if status in ("works", "untested") and dep["soft_missing"]:
            reason += "; limited without " + ", ".join(dep["soft_missing"])
        out = {"tool": tool, "status": status, "reason": reason, "registered": True, "risk": entry.get("risk", "safe"), "agent": entry.get("agent", ""), "permission": perm["needed"],
               "permission_granted": perm["granted"], "needs_internet": dep["needs_net"], "missing": dep["missing"], "soft_missing": dep["soft_missing"], "calls_24h": use["calls"],
               "success_rate": use["rate"], "avg_ms": use["avg_ms"], "last_error": use["last_error"], "tested": bool(test), "tested_at": C.iso(test["ts"]) if test else "",
               "limits": KNOWN.get(tool, {}).get("limits", ""), "desc": entry.get("desc", "")}
    with _lock:
        _cache[tool] = (time.time(), out)
    return out


def tool_usable(tool: str) -> Optional[bool]:
    """True: fine. False: cannot work here right now (missing dependency, wrong OS, permission off, failing repeatedly). None: can't tell."""
    try:
        a = assess(tool)
    except Exception:
        return None
    if a["status"] == "unknown":
        return None
    if a["status"] in ("unavailable", "degraded"):
        if a["status"] == "degraded" and not a.get("calls_24h"):
            return True                      # a failed self-test alone does not forbid a real attempt
        return False if a["status"] == "unavailable" or (a.get("success_rate") or 0) < 0.4 else True
    return True


def probe_tools(names: Optional[List[str]] = None, timeout: float = 8.0) -> Dict:
    """Run the safe self-tests. Read-only tools only; each runs in a thread with a time limit."""
    reg = _registry()
    if reg is None:
        return {"ran": 0, "results": []}
    results = []
    for name in (names or sorted(SELF_TESTS)):
        if not reg.has(name) or name not in SELF_TESTS:
            continue
        entry = reg.get(name)
        if entry.get("risk", "safe") != "safe":
            continue
        box: Dict[str, Any] = {}

        def run(fn=entry["fn"], args=dict(SELF_TESTS[name])):
            try:
                box["r"] = fn(args)
            except Exception as exc:
                box["e"] = f"{type(exc).__name__}: {exc}"
        t0 = time.time()
        th = threading.Thread(target=run, daemon=True)
        th.start()
        th.join(timeout)
        ms = (time.time() - t0) * 1000
        if th.is_alive():
            ok, detail = 0, f"timed out after {timeout:.0f}s"
        elif "e" in box:
            ok, detail = 0, box["e"][:140]
        else:
            r = box.get("r")
            if isinstance(r, dict) and name in TOLERATE_NOT_OK and not r.get("ok", True) and (r.get("error") or r.get("output")):
                ok, detail = 1, "ran and answered correctly (nothing to report yet: " + str(r.get("error") or r.get("output"))[:80] + ")"
            else:
                ok = int(bool(r.get("ok", True)) if isinstance(r, dict) else bool(r))
                detail = "passed" if ok else (str((r or {}).get("error", "returned failure"))[:140] if isinstance(r, dict) else "returned a false value")
        C.x("INSERT OR REPLACE INTO caps7(tool,ts,status,detail,ms,ok) VALUES(?,?,?,?,?,?)", (name, C.now(), "passed" if ok else "failed", detail, ms, ok))
        results.append({"tool": name, "ok": bool(ok), "ms": int(ms), "detail": detail})
    with _lock:
        _cache.clear()
    return {"ran": len(results), "results": results}


def inventory() -> List[Dict]:
    reg = _registry()
    if reg is None:
        return []
    return [assess(n) for n in reg.names()]


def report(only_problems: bool = False) -> str:
    inv = inventory()
    if not inv:
        return "I have no tools registered yet."
    order = {"works": 0, "untested": 1, "degraded": 2, "unavailable": 3, "unknown": 4}
    inv.sort(key=lambda a: (order.get(a["status"], 9), a["tool"]))
    counts: Dict[str, int] = {}
    for a in inv:
        counts[a["status"]] = counts.get(a["status"], 0) + 1
    head = "Capabilities: " + ", ".join(f"{v} {k}" for k, v in sorted(counts.items(), key=lambda kv: order.get(kv[0], 9))) + "."
    lines = [head]
    for a in inv:
        if only_problems and a["status"] in ("works", "untested"):
            continue
        extra = f" [{a['limits']}]" if a.get("limits") and a["status"] != "works" else ""
        lines.append(f"- {a['tool']}: {a['status']} - {a['reason']}{extra}")
    return "\n".join(lines[:60])


def spoken_summary() -> str:
    inv = inventory()
    if not inv:
        return "I have no tools registered yet."
    bad = [a for a in inv if a["status"] in ("unavailable", "degraded")]
    ok = sum(1 for a in inv if a["status"] == "works")
    unt = sum(1 for a in inv if a["status"] == "untested")
    s = f"{len(inv)} tools: {ok} confirmed working, {unt} not tested yet"
    if bad:
        s += f", {len(bad)} with a problem. " + "; ".join(f"{a['tool']} - {a['reason']}" for a in bad[:3]) + "."
    else:
        s += ", none broken."
    return s


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if re.match(r"^(?:test|check|probe) (?:your |all |the )?(?:tools|capabilities)(?: (?:now|again))?$|^run (?:the )?(?:tool|capability) self[- ]?tests?$", t):
        r = probe_tools()
        if not r["ran"]:
            return "There were no safe self-tests to run."
        bad = [x for x in r["results"] if not x["ok"]]
        return f"Self-tested {r['ran']} read-only tools: {r['ran'] - len(bad)} passed" + (", failed: " + "; ".join(f"{x['tool']} ({x['detail']})" for x in bad) if bad else ".") + " Tools that change things are never tested this way."
    if re.match(r"^(?:which|what) (?:tools|capabilities|skills) (?:are|is) (?:broken|failing|unavailable|not working|degraded)$|^what(?:'s| is) (?:broken|not working)$", t):
        txt = report(only_problems=True)
        return txt if "\n" in txt else "Nothing is reported as broken or unavailable."
    if re.match(r"^(?:capabilit(?:y|ies) (?:report|registry|inventory)|(?:which|what) (?:tools|capabilities) (?:work|do you have|are working)|show (?:me )?(?:your )?(?:capabilit(?:y|ies)|tool inventory))$", t):
        return report()
    return None


def ui_snapshot() -> Dict:
    inv = inventory()
    return {"capabilities": [{k: a.get(k) for k in ("tool", "status", "reason", "risk", "permission", "calls_24h", "success_rate", "avg_ms", "tested_at", "limits")} for a in inv]}
