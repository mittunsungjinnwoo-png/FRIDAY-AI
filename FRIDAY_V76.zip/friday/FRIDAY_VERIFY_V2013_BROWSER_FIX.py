from pathlib import Path
import compileall
import re
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

print("FRIDAY v2013 browser/symbol verification")
print("=" * 48)

ok = compileall.compile_dir(str(ROOT), quiet=1)
print("Python compilation:", "PASS" if ok else "FAIL")

import friday_desktop_agent as d
import friday_advanced_agent as a

chrome = d._chrome_executable()
print("Chrome executable:", chrome or "NOT FOUND")

tests = [
    ("slash speech", "input/output", "input or output"),
    ("and/or speech", "and/or", "and or"),
    ("fraction preserved", "1/2", "1/2"),
    ("URL preserved", "https://example.com/a/b", "https://example.com/a/b"),
    ("path preserved", r"C:/Users/test/file.txt", r"C:/Users/test/file.txt"),
]

# Use the backend's function without starting the full backend runtime.
import ast
backend_text = (ROOT / "friday_backend.py").read_text(encoding="utf-8")
tree = ast.parse(backend_text)
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
            and n.name == "normalize_human_command")
ns = {"re": re}
exec(compile(ast.fix_missing_locations(ast.Module(
    body=[ast.Import(names=[ast.alias(name="re")]), node],
    type_ignores=[]
)), "<normalizer>", "exec"), ns)
normalize = ns["normalize_human_command"]

for label, source, expected in tests:
    actual = normalize(source)
    passed = expected in actual
    print(f"{label:20}:", "PASS" if passed else f"FAIL ({actual!r})")

command = "open a new tab in Google and type hi in the search bar"
target = a._extract_open_target(command)
typed = a._extract_browser_typing(command)
search = a._extract_browser_search(command)

print("compound target      :", target)
print("compound typed text  :", typed)
print("compound search      :", search)

compound_ok = target == "Google Chrome" and typed == "hi" and search is None
print("compound parsing     :", "PASS" if compound_ok else "FAIL")

if not ok or not compound_ok:
    raise SystemExit(1)

print("=" * 48)
print("Static verification complete.")
print("A live browser test must be run on the Windows PC that has Chrome installed.")
