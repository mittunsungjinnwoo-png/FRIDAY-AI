@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Uninstall FRIDAY
echo ============================================
echo  Uninstall FRIDAY
echo ============================================
echo.
echo This closes FRIDAY, removes its shortcuts and (optionally) its saved data.
echo.
choice /C YN /M "Continue"
if errorlevel 2 exit /b 0

echo.
echo Closing FRIDAY and its Python engine...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$f='%~dp0'; Get-CimInstance Win32_Process | Where-Object { ($_.ExecutablePath -and $_.ExecutablePath -like ($f+'*')) -or ($_.CommandLine -and $_.CommandLine -like ('*'+$f+'*') -and $_.Name -match 'electron|python|node') } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force } catch {} }" >nul 2>&1
taskkill /F /T /IM "FRIDAY.exe" >nul 2>&1

echo Removing shortcuts...
del /q "%USERPROFILE%\Desktop\FRIDAY.lnk" >nul 2>&1
del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\FRIDAY.lnk" >nul 2>&1
del /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Uninstall FRIDAY.lnk" >nul 2>&1

set "UN1=%LOCALAPPDATA%\Programs\FRIDAY\Uninstall FRIDAY.exe"
set "UN2=%LOCALAPPDATA%\Programs\friday-ui\Uninstall FRIDAY.exe"
if exist "!UN1!" (
  echo Found the installed copy. Opening its uninstaller...
  start "" /wait "!UN1!"
) else if exist "!UN2!" (
  echo Found the installed copy. Opening its uninstaller...
  start "" /wait "!UN2!"
) else (
  echo No installed copy found - FRIDAY was running from this folder only.
)

echo.
choice /C YN /M "Also delete FRIDAY's saved data (memory, finance data, API key, private Python runtime)"
if not errorlevel 2 (
  rmdir /s /q "%APPDATA%\friday-ui" >nul 2>&1
  rmdir /s /q "%APPDATA%\FRIDAY" >nul 2>&1
  echo Saved data deleted.
) else (
  echo Saved data kept.
)

echo.
echo FRIDAY has been removed from Windows (shortcuts, installed copy).
echo To also delete this program folder, type YES below. Anything else keeps it.
echo   Folder: %~dp0
set "DIR=%~dp0"
if "!DIR:~-1!"=="\" set "DIR=!DIR:~0,-1!"
set /p CONFIRM=Delete this folder? 
if /I "!CONFIRM!"=="YES" (
  start "" cmd /c "timeout /t 3 /nobreak >nul & rmdir /s /q "!DIR!""
  echo This folder will be deleted in a few seconds.
) else (
  echo Folder kept. You can delete it yourself any time.
)
echo.
pause
