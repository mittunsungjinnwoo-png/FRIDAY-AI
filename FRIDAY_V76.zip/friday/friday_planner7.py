"""FRIDAY 7.0 Planning and Reasoning Engine  (roadmap #5).

Breaks a complex request into VERIFIABLE steps, finds their dependencies, selects tools, checks intermediate results against what the plan
expected, and REVISES the plan when reality differs - instead of marching on with a plan that no longer fits.

    ReAct (one thought, one action)  ->  Graph-of-Thoughts (several candidate plans, scored, kept as fallback branches)

* make_plan()        domain templates (money saving first) + optional model-written plan + a minimal safe plan -> scored -> best one wins,
                     the others stay as branches the reviser can switch to
* validate()         unique ids, dependencies only on earlier steps (so no cycles), only tools that exist, at most 10 steps
* check_intermediate()  compares a step's result with its `expect` block (non-empty, enough items, number range, must mention ...)
* revise()           alternative strategy -> fallback tool -> prerequisite step -> another branch -> drop optional work, with a recorded reason
"""
from __future__ import annotations

import copy
import json
import re
from typing import Any, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

MAX_STEPS = 10
MAX_REVISIONS = 2


def _step(i: int, desc: str, tool: str, args: Optional[Dict] = None, depends: Optional[List[int]] = None, post: Optional[Dict] = None, expect: Optional[Dict] = None,
          optional: bool = False, alternatives: Optional[List[Dict]] = None, risk: str = "safe") -> Dict:
    return {"id": i, "desc": desc, "tool": tool, "args": args or {}, "depends": depends or [], "post": post or {}, "expect": expect or {}, "optional": optional,
            "alternatives": alternatives or [], "risk": risk, "status": "pending", "attempts": 0}


# ------------------------------------------------------------------ registry access (duck typed so this module never imports the orchestrator at load time)
def _reg(registry=None):
    if registry is not None:
        return registry
    try:
        import friday_orchestrator7 as O
        return O.registry
    except Exception:
        return None


def _has(reg, tool: str) -> bool:
    try:
        return bool(reg and reg.has(tool))
    except Exception:
        return False


def _cap_ok(tool: str) -> Optional[bool]:
    try:
        import friday_capabilities7 as CAP
        return CAP.tool_usable(tool)
    except Exception:
        return None


# ------------------------------------------------------------------ templates
_RX_SAVE = re.compile(r"\b(cheap(?:er|est)?|save money|saving|budget|cost|price|prices|afford|grocer(?:y|ies)|recipe|recipes|ingredient|ingredients|meal|meals|spend(?:ing)?)\b", re.I)
_RX_RESEARCH = re.compile(r"\b(research|investigate|find out|look up|look for|compare|search|sources?|evidence|fact[- ]check)\b", re.I)
_RX_SAVE_FILE = re.compile(r"\b(save|write|store|export|put)\b.*\b(file|report|summary|findings|notes|document|it|them)\b|\bsave (?:the |my )?(?:findings|results|summary|report)\b", re.I)
_RX_VERIFY = re.compile(r"\b(verify|double[- ]check|check (?:the )?(?:calculations?|numbers|maths?)|make sure (?:it'?s|they'?re) right|validate)\b", re.I)
_RX_CODE = re.compile(r"\b(review|audit|inspect|test|check|fix|repair)\b.*\b(code|project|codebase|repo|repository|script|program|app)\b", re.I)
_RX_SYS = re.compile(r"\b(diagnos|why is my (?:laptop|pc|computer)|slow|hot|battery|performance)\b", re.I)
_RX_FOLDER = re.compile(r"\b(organi[sz]e|clean up|sort|tidy)\b.*\b(folder|downloads|desktop|files)\b", re.I)
_RX_DOC = re.compile(r"\b(write|draft|create|make|prepare)\b.*\b(report|document|notes|summary|essay|plan|brief)\b", re.I)
_RX_SCREEN = re.compile(r"\b(screen|screenshot|camera|image|photo|picture|diagram)\b", re.I)
_RX_BUDGET = re.compile(r"\b(budget|expenses?|income|spending|surplus|afford|savings? rate)\b", re.I)
_RX_COSTING = re.compile(r"\b(cost|price|how much)\b.*\b(recipe|meal|meals|ingredients?|week|plan|food)\b|\b(recipe|meal|ingredients?)\b.*\b(cost|price)\b", re.I)


def _t_savings_research(goal: str) -> List[Dict]:
    s = [
        _step(0, "Research cheaper options with sources", "investigate", {"question": "{goal}"}, [], post={"nonempty": True}, expect={"min_len": 40}, alternatives=[{"tool": "web_research", "args": {"query": "{goal}"}, "desc": "Plain web research"}]),
        _step(1, "Cost the ingredients from recorded prices", "cost_recipe", {"text": "{goal}", "research": "{s0}"}, [0], post={"nonempty": True}, expect={"min_len": 10}, optional=False),
        _step(2, "Compare the alternatives on cost", "compare_costs", {"text": "{goal}", "research": "{s0}"}, [0, 1], post={"nonempty": True}),
        _step(3, "Combine everything into a cited recommendation", "synthesize", {"topic": "{goal}", "material": "[researched] Research findings\n{s0}\n=====\n[calculated] Recipe costing\n{s1}\n=====\n[comparison] Cost comparison\n{s2}"}, [0, 1, 2], post={"nonempty": True}, expect={"min_len": 60}),
    ]
    if _RX_SAVE_FILE.search(goal) or True:
        s.append(_step(4, "Save the findings as a file", "save_report", {"name": "savings_findings.md", "content": "{s3}"}, [3], post={"file_exists": True}, risk="sensitive"))
    s.append(_step(5, "Independently verify the calculations", "critic_review", {"content": "{s3}", "importance": "high"}, [3], post={"nonempty": True}, optional=True))
    return s


def _t_research(goal: str) -> List[Dict]:
    s = [_step(0, "Investigate with graded, cross-checked sources", "investigate", {"question": "{goal}"}, [], post={"nonempty": True}, expect={"min_len": 40},
               alternatives=[{"tool": "web_research", "args": {"query": "{goal}"}, "desc": "Plain web research"}]),
         _step(1, "Synthesise findings with citations", "synthesize", {"topic": "{goal}", "material": "[researched] Research findings\n{s0}"}, [0], post={"nonempty": True}, expect={"min_len": 60})]
    if _RX_SAVE_FILE.search(goal):
        s.append(_step(2, "Save the findings as a file", "save_report", {"name": "research_findings.md", "content": "{s1}"}, [1], post={"file_exists": True}, risk="sensitive"))
    s.append(_step(len(s), "Independent check of the claims", "critic_review", {"content": "{s1}", "importance": "high"}, [1], post={"nonempty": True}, optional=True))
    return s


def _t_costing(goal: str) -> List[Dict]:
    return [
        _step(0, "Cost the ingredients from recorded prices", "cost_recipe", {"text": "{goal}"}, [], post={"nonempty": True}, expect={"min_len": 10}),
        _step(1, "Check the result against the grocery budget", "budget_check", {"text": "{s0}"}, [0], post={"nonempty": True}, optional=True),
        _step(2, "Verify the arithmetic independently", "critic_review", {"content": "{s0}", "importance": "high"}, [0], post={"nonempty": True}, optional=True),
    ]


def _t_budget(goal: str) -> List[Dict]:
    return [
        _step(0, "Read your recorded income, expenses and plans", "finance_snapshot", {}, [], post={"nonempty": True}),
        _step(1, "Check grocery spending against the budget", "budget_check", {"text": "{goal}"}, [0], post={"nonempty": True}, optional=True),
        _step(2, "Explain what to change first", "think", {"prompt": "Using only these exact figures, say what to change first and why. Do not recalculate.\n{s0}\n{s1}\nQuestion: {goal}"}, [0], post={"nonempty": True}),
    ]


def _t_code(goal: str) -> List[Dict]:
    return [
        _step(0, "Inspect the code (syntax, review, structure)", "repair_inspect", {"path": "{path}"}, [], post={"nonempty": True}, alternatives=[{"tool": "code_review", "args": {"path": "{path}"}, "desc": "Review for bugs"}]),
        _step(1, "Run the tests in isolation", "run_tests", {"path": "{path}"}, [0], post={"nonempty": True}, optional=True),
        _step(2, "Summarise findings and safest next step", "think", {"prompt": "Summarise these code findings and name the safest next step:\n{s0}\n{s1}"}, [0], post={"nonempty": True}),
    ]


def _t_system(goal: str) -> List[Dict]:
    return [_step(0, "Read CPU, memory, disk and battery", "system_info", {}, [], post={"nonempty": True}),
            _step(1, "Diagnose the likely cause and best fix", "think", {"prompt": "Using the system readings, explain the likely cause and best fix: {goal}\n{s0}"}, [0], post={"nonempty": True})]


def _t_folder(goal: str) -> List[Dict]:
    return [_step(0, "Survey the folder", "analyze_folder", {"folder": "{path}"}, [], post={"nonempty": True}),
            _step(1, "Preview how it would be organised (nothing is moved)", "organise_preview", {"folder": "{path}"}, [0], post={"nonempty": True}, optional=True)]


def _t_doc(goal: str) -> List[Dict]:
    return [_step(0, "Draft the content", "think", {"prompt": "Outline then write: {goal}"}, [], post={"nonempty": True}, expect={"min_len": 60}),
            _step(1, "Save it as a file", "save_report", {"name": "task_output.md", "content": "{s0}"}, [0], post={"file_exists": True}, risk="sensitive"),
            _step(2, "Check the draft for errors", "critic_review", {"content": "{s0}", "importance": "normal"}, [0], post={"nonempty": True}, optional=True)]


def _t_screen(goal: str) -> List[Dict]:
    return [_step(0, "Capture the screen and verify what was captured", "capture_verify", {"kind": "screen"}, [], post={"nonempty": True}),
            _step(1, "Reason over everything captured", "multimodal_understand", {"question": "{goal}"}, [0], post={"nonempty": True})]


TEMPLATES = [
    ("savings_research", lambda g: bool(_RX_SAVE.search(g) and _RX_RESEARCH.search(g)), _t_savings_research),
    ("recipe_costing", lambda g: bool(_RX_COSTING.search(g)), _t_costing),
    ("budget_review", lambda g: bool(_RX_BUDGET.search(g)), _t_budget),
    ("code_review", lambda g: bool(_RX_CODE.search(g)), _t_code),
    ("system_diagnosis", lambda g: bool(_RX_SYS.search(g)), _t_system),
    ("folder_survey", lambda g: bool(_RX_FOLDER.search(g)), _t_folder),
    ("document", lambda g: bool(_RX_DOC.search(g)), _t_doc),
    ("screen_help", lambda g: bool(_RX_SCREEN.search(g) and re.search(r"\b(what|look|see|read|check|analy[sz]e|explain)\b", g, re.I)), _t_screen),
    ("research", lambda g: bool(_RX_RESEARCH.search(g)), _t_research),
]


def minimal_plan(goal: str) -> List[Dict]:
    return [_step(0, "Work it out", "think", {"prompt": "{goal}"}, [], post={"nonempty": True}, expect={"min_len": 5})]


# ------------------------------------------------------------------ validation
def validate(plan: List[Dict], registry=None) -> Tuple[List[Dict], List[str]]:
    """Return (clean plan, problems). Steps whose tool does not exist are replaced by an alternative or dropped, dependencies are rewired."""
    reg = _reg(registry)
    problems: List[str] = []
    raw = [copy.deepcopy(s) for s in (plan or [])][:MAX_STEPS]
    if len(plan or []) > MAX_STEPS:
        problems.append(f"plan trimmed to {MAX_STEPS} steps")
    kept: List[Dict] = []
    idmap: Dict[int, Optional[int]] = {}
    for s in raw:
        old = s.get("id", len(kept))
        tool = s.get("tool", "")
        if reg is not None and not _has(reg, tool):
            alt = next((a for a in s.get("alternatives", []) if _has(reg, a.get("tool", ""))), None)
            if alt:
                problems.append(f"step '{s.get('desc', tool)}': tool {tool} is not available, using {alt['tool']}")
                s["tool"], s["args"] = alt["tool"], alt.get("args", s.get("args", {}))
                tool = s["tool"]
            else:
                problems.append(f"step '{s.get('desc', tool)}': tool {tool} is not available, dropped")
                idmap[old] = None
                continue
        new_id = len(kept)
        idmap[old] = new_id
        s["id"] = new_id
        s.setdefault("args", {})
        s.setdefault("post", {})
        s.setdefault("expect", {})
        s.setdefault("alternatives", [])
        s.setdefault("optional", False)
        s.setdefault("risk", "safe")
        s["status"], s["attempts"] = "pending", 0
        s["depends"] = [d for d in (s.get("depends") or []) if isinstance(d, int)]
        kept.append(s)
    for s in kept:  # remap dependencies, keep only earlier steps (so the graph is acyclic by construction)
        deps = []
        for d in s["depends"]:
            nd = idmap.get(d)
            if nd is None:
                if d in idmap:
                    continue          # the dependency was dropped
                continue
            if nd < s["id"]:
                deps.append(nd)
            else:
                problems.append(f"step {s['id']}: dependency on a later step removed")
        s["depends"] = sorted(set(deps))
    return kept, problems


def has_cycle(plan: List[Dict]) -> bool:
    indeg = {s["id"]: len(s["depends"]) for s in plan}
    out: Dict[int, List[int]] = {}
    for s in plan:
        for d in s["depends"]:
            out.setdefault(d, []).append(s["id"])
    q = [i for i, n in indeg.items() if n == 0]
    seen = 0
    while q:
        i = q.pop()
        seen += 1
        for j in out.get(i, []):
            indeg[j] -= 1
            if indeg[j] == 0:
                q.append(j)
    return seen != len(plan)


def layers(plan: List[Dict]) -> List[List[int]]:
    """Topological layers: every step in a layer depends only on earlier layers, so each layer can run in parallel."""
    done: set = set()
    left = {s["id"]: s for s in plan}
    out = []
    while left:
        ready = [i for i, s in left.items() if all(d in done for d in s["depends"])]
        if not ready:
            out.append(sorted(left))      # cycle guard: should be impossible after validate()
            break
        out.append(sorted(ready))
        done.update(ready)
        for i in ready:
            left.pop(i)
    return out


# ------------------------------------------------------------------ scoring (Graph-of-Thoughts: pick the best branch)
def score_plan(plan: List[Dict], goal: str, registry=None) -> Dict:
    reg = _reg(registry)
    if not plan:
        return {"score": 0.0, "parts": {}}
    n = len(plan)
    verifiable = sum(1 for s in plan if s.get("post") or s.get("expect")) / n
    avail = []
    for s in plan:
        ok = _has(reg, s["tool"]) if reg is not None else True
        cap = _cap_ok(s["tool"])
        avail.append(1.0 if ok and cap is not False else (0.4 if ok else 0.0))
    availability = sum(avail) / n
    need = set()
    low = goal.lower()
    for kw, tools in (("research", {"investigate", "web_research"}), ("cost", {"cost_recipe", "compare_costs"}), ("price", {"cost_recipe"}), ("save", {"save_report", "write_file"}),
                      ("compare", {"compare_costs", "investigate", "synthesize"}), ("verify", {"critic_review"}), ("budget", {"budget_check", "finance_snapshot"}), ("review", {"repair_inspect", "code_review"})):
        if kw in low:
            need.add(frozenset(tools))
    have = {s["tool"] for s in plan}
    coverage = (sum(1 for grp in need if grp & have) / len(need)) if need else (1.0 if n else 0.0)
    simplicity = 1.0 / (1.0 + max(0, n - 3) * 0.15)
    safety = 1.0 - 0.12 * sum(1 for s in plan if s.get("risk") == "sensitive") / max(1, n) * n / max(1, n)
    parts = {"coverage": round(coverage, 3), "verifiable": round(verifiable, 3), "availability": round(availability, 3), "simplicity": round(simplicity, 3), "safety": round(max(0.0, safety), 3)}
    score = 0.40 * coverage + 0.20 * verifiable + 0.18 * availability + 0.10 * simplicity + 0.12 * max(0.0, safety)
    return {"score": round(score, 4), "parts": parts}


def _llm_plan(goal: str, reg) -> List[Dict]:
    if not C._cfg.get("llm") or reg is None:
        return []
    try:
        names = ", ".join(f"{n} ({reg.get(n)['desc'][:48]})" for n in reg.names())
    except Exception:
        return []
    raw = C.llm("Plan this task as a JSON array of at most 7 steps. Each step: {\"tool\": one of the tools, \"args\": {...}, \"desc\": short text, \"depends\": [indexes of earlier steps], "
                "\"post\": {\"nonempty\": true}}. Use {goal} and {s0},{s1}.. placeholders for earlier results. Use only these tools: " + names + ". Reply with JSON only.\n\nTask: " + goal)
    m = re.search(r"\[.*\]", raw or "", re.S)
    j = C.jload(m.group(0)) if m else None
    out: List[Dict] = []
    if isinstance(j, list):
        for i, s in enumerate(j[:7]):
            if isinstance(s, dict) and isinstance(s.get("tool"), str):
                out.append(_step(i, str(s.get("desc") or s["tool"])[:80], s["tool"], s.get("args") if isinstance(s.get("args"), dict) else {}, [d for d in (s.get("depends") or []) if isinstance(d, int) and d < i],
                                 post=s.get("post") if isinstance(s.get("post"), dict) else {"nonempty": True}))
    return out


def make_plan(goal: str, intent: Optional[str] = None, registry=None, hints: Optional[List[Dict]] = None) -> Dict:
    """Graph-of-Thoughts planning. Returns {steps, score, parts, branches, rationale, template}."""
    reg = _reg(registry)
    goal = (goal or "").strip()
    cands: List[Tuple[str, List[Dict]]] = []
    for name, pred, fn in TEMPLATES:
        try:
            if pred(goal):
                cands.append((name, fn(goal)))
        except Exception:
            continue
    for h in (hints or [])[:1]:             # an approved plan from a similar earlier success (learning7)
        if h.get("plan"):
            cands.append(("approved_example", copy.deepcopy(h["plan"])))
    lp = _llm_plan(goal, reg)
    if lp:
        cands.append(("model_plan", lp))
    cands.append(("minimal", minimal_plan(goal)))
    scored = []
    for name, steps in cands:
        clean, problems = validate(steps, reg)
        if not clean or has_cycle(clean):
            continue
        sc = score_plan(clean, goal, reg)
        scored.append({"name": name, "steps": clean, "problems": problems, **sc})
    if not scored:
        clean, _ = validate(minimal_plan(goal), reg)
        scored = [{"name": "minimal", "steps": clean or minimal_plan(goal), "problems": [], "score": 0.1, "parts": {}}]
    # templates keep a small edge when scores are close: they are verified by tests, model plans are not
    pref = {"savings_research": 0.04, "recipe_costing": 0.04, "budget_review": 0.03, "code_review": 0.03, "approved_example": 0.05, "model_plan": 0.0, "minimal": -0.05}
    scored.sort(key=lambda d: -(d["score"] + pref.get(d["name"], 0.02)))
    best, rest = scored[0], scored[1:]
    rationale = f"chose the '{best['name']}' plan (score {best['score']:.2f}: " + ", ".join(f"{k} {v:.2f}" for k, v in best["parts"].items()) + ")"
    if rest:
        rationale += f"; kept {len(rest)} alternative branch(es): " + ", ".join(r["name"] for r in rest)
    if best["problems"]:
        rationale += "; adjusted: " + "; ".join(best["problems"])
    return {"steps": best["steps"], "score": best["score"], "parts": best["parts"], "template": best["name"], "branches": [{"name": r["name"], "score": r["score"], "steps": r["steps"]} for r in rest], "rationale": rationale}


# ------------------------------------------------------------------ placeholders
def fill(v: Any, ctx: Dict[str, Any]) -> Any:
    """Replace {goal}, {path}, {prev}, {s0}.. in strings (recursively). Unknown placeholders are left alone."""
    if isinstance(v, str):
        for k, val in ctx.items():
            tok = "{" + k + "}"
            if tok in v:
                v = v.replace(tok, str(val))
        return v
    if isinstance(v, dict):
        return {k: fill(x, ctx) for k, x in v.items()}
    if isinstance(v, list):
        return [fill(x, ctx) for x in v]
    return v


# ------------------------------------------------------------------ intermediate checks
def check_intermediate(step: Dict, result: Dict) -> Dict:
    """Does the result look like what the plan expected? {ok, issues}. A mismatch triggers a revision, not a blind continuation."""
    exp = step.get("expect") or {}
    out = str(result.get("output", ""))
    issues: List[str] = []
    if "min_len" in exp and len(out.strip()) < int(exp["min_len"]):
        issues.append(f"result is only {len(out.strip())} characters, expected at least {exp['min_len']}")
    if "min_items" in exp:
        items = result.get("items")
        n = len(items) if isinstance(items, list) else len([ln for ln in out.splitlines() if ln.strip()])
        if n < int(exp["min_items"]):
            issues.append(f"expected at least {exp['min_items']} items, got {n}")
    if "number_between" in exp:
        lo, hi = exp["number_between"]
        m = re.search(r"-?\d[\d,]*\.?\d*", out)
        v = float(m.group(0).replace(",", "")) if m else None
        if v is None or not (lo <= v <= hi):
            issues.append(f"expected a number between {lo} and {hi}, got {v}")
    for w in exp.get("must_mention", []) or []:
        if str(w).lower() not in out.lower():
            issues.append(f"result does not mention {w!r}")
    if exp.get("no_apology") and re.search(r"\b(i can'?t|unable to|i am unable|sorry, i)\b", out, re.I):
        issues.append("the tool answered with a refusal instead of a result")
    if re.search(r"^\W*(?:no sources|nothing found|could not (?:reach|find)|unavailable)\b", out, re.I) and not exp.get("allow_empty"):
        issues.append("the step reported that nothing usable was found")
    return {"ok": not issues, "issues": issues}


# ------------------------------------------------------------------ revision
def revise(plan_info: Dict, failed_id: int, failure: Dict, registry=None, tried: Optional[set] = None) -> Optional[Dict]:
    """Return {steps, changes, strategy, reason} describing a revised plan, or None when nothing sensible is left to try.
    `failure`: {"class": failure class, "error": text, "issues": [...]}."""
    reg = _reg(registry)
    steps = copy.deepcopy(plan_info["steps"])
    tried = tried if tried is not None else set()
    st = next((s for s in steps if s["id"] == failed_id), None)
    if st is None:
        return None
    fclass = failure.get("class", "unknown")
    why = failure.get("error") or "; ".join(failure.get("issues", [])) or fclass
    changes: List[str] = []
    # 1) the step's own alternative strategies
    for alt in st.get("alternatives", []):
        key = (failed_id, alt.get("tool"), json.dumps(alt.get("args", {}), sort_keys=True))
        if key in tried or not _has(reg, alt.get("tool", "")) or _cap_ok(alt.get("tool", "")) is False:
            continue
        tried.add(key)
        changes.append(f"step {failed_id}: switched from {st['tool']} to {alt['tool']} because {why}")
        st["tool"], st["args"] = alt["tool"], alt.get("args", st["args"])
        st["desc"] = alt.get("desc") or st["desc"]
        st["status"], st["attempts"] = "pending", 0
        return {"steps": steps, "changes": changes, "strategy": "alternative_tool", "reason": why}
    # 2) the registry's fallback tool
    try:
        fb = reg.get(st["tool"]).get("fallback") if reg and _has(reg, st["tool"]) else ""
    except Exception:
        fb = ""
    if fb and _has(reg, fb) and (failed_id, fb, "") not in tried:
        tried.add((failed_id, fb, ""))
        changes.append(f"step {failed_id}: fell back from {st['tool']} to {fb}")
        st["tool"], st["status"], st["attempts"] = fb, "pending", 0
        return {"steps": steps, "changes": changes, "strategy": "fallback_tool", "reason": why}
    # 3) a prerequisite step when the target was not found / arguments were invalid
    if fclass in ("not_found", "invalid_args") and (failed_id, "prereq") not in tried and _has(reg, "think"):
        tried.add((failed_id, "prereq"))
        new_id = len(steps)
        fix = _step(new_id, f"Work out corrected inputs for '{st['desc']}'", "think",
                    {"prompt": f"A step failed ({why}). Step: {st['desc']}; inputs: {json.dumps(st['args'], default=str)[:300]}. Reply with only the corrected main input text."}, [], post={"nonempty": True}, optional=False)
        steps.append(fix)
        st["depends"] = sorted(set(st["depends"] + [new_id]))
        key = next((k for k, v in st["args"].items() if isinstance(v, str) and k not in ("name", "kind")), None)
        if key:
            st["args"][key] = "{s%d}" % new_id
        st["status"], st["attempts"] = "pending", 0
        # a dependency on a later id would break the 'earlier steps only' rule: reorder by moving the new step before the failed one
        steps = _reindex_prepend(steps, new_id, failed_id)
        changes.append(f"step {failed_id}: added a step to work out better inputs because {why}")
        return {"steps": steps, "changes": changes, "strategy": "prerequisite", "reason": why}
    # 4) another branch of the thought graph that avoids the failing tool
    for br in plan_info.get("branches", []):
        if br["name"] in tried:
            continue
        tools = {s["tool"] for s in br["steps"]}
        if st["tool"] in tools and len(br["steps"]) > 1:
            continue
        tried.add(br["name"])
        clean, _ = validate(br["steps"], reg)
        if clean:
            changes.append(f"switched to the '{br['name']}' plan because step {failed_id} ({st['tool']}) failed: {why}")
            return {"steps": clean, "changes": changes, "strategy": "alternative_branch", "reason": why, "branch": br["name"]}
    # 5) give up on optional work only
    if st.get("optional"):
        st["status"] = "skipped"
        changes.append(f"step {failed_id} was optional and is skipped")
        return {"steps": steps, "changes": changes, "strategy": "skip_optional", "reason": why}
    return None


def _reindex_prepend(steps: List[Dict], new_id: int, before_id: int) -> List[Dict]:
    """Move step `new_id` to sit just before step `before_id` and renumber everything (dependencies and {sN} placeholders follow)."""
    order = [s["id"] for s in steps if s["id"] != new_id]
    pos = order.index(before_id)
    order.insert(pos, new_id)
    remap = {old: i for i, old in enumerate(order)}
    by_id = {s["id"]: s for s in steps}
    out = []
    for old in order:
        s = by_id[old]
        s["depends"] = sorted(remap[d] for d in s["depends"] if d in remap)
        s["args"] = _remap_placeholders(s["args"], remap)
        for a in s.get("alternatives", []):
            a["args"] = _remap_placeholders(a.get("args", {}), remap)
        s["id"] = remap[old]
        out.append(s)
    return out


def _remap_placeholders(v: Any, remap: Dict[int, int]) -> Any:
    if isinstance(v, str):
        return re.sub(r"\{s(\d+)\}", lambda m: "{s%d}" % remap.get(int(m.group(1)), int(m.group(1))), v)
    if isinstance(v, dict):
        return {k: _remap_placeholders(x, remap) for k, x in v.items()}
    if isinstance(v, list):
        return [_remap_placeholders(x, remap) for x in v]
    return v


def explain(plan_info: Dict) -> str:
    st = plan_info["steps"]
    lines = [f"{i + 1}. {s['desc']}" + (" (after " + ", ".join(str(d + 1) for d in s["depends"]) + ")" if s["depends"] else "") for i, s in enumerate(st)]
    return "My plan: " + "; ".join(lines) + "."
