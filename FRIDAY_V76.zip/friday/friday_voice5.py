"""FRIDAY 5.0 voice engine - listening, endpoint detection and recognition.

Replaces the old "open microphone -> calibrate -> wait 1.05 s of silence -> Google/Whisper hybrid -> deep verify"
loop with a continuous, full-duplex pipeline:

    always-open mic stream (16 kHz mono, 20 ms frames, never reopened)
        -> adaptive noise floor + WebRTC VAD (energy fallback when webrtcvad is missing)
        -> pre-roll buffer (the first syllable is never clipped)
        -> SPECULATIVE endpointing: recognition starts after ~0.30 s of silence while the segmenter keeps
           listening; if the user carries on, the speculative result is thrown away, otherwise the
           reply starts immediately (commit at ~0.50 s instead of 1.05 s + a serial recognition)
        -> recognition race: local faster-whisper vs Google, first good answer wins
        -> wake-word / standby gating, echo rejection, hallucination filter
        -> command queue consumed by listen()

The mic keeps running while FRIDAY speaks, so speaking over her (barge-in) and "stop" work.
Everything hardware specific is behind small classes so the logic is unit-testable without a microphone.
"""
from __future__ import annotations

import base64
import collections
import difflib
import os
import queue
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, FIRST_COMPLETED, wait as _fwait
from dataclasses import dataclass, field
from typing import Callable, Deque, List, Optional

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

try:
    import webrtcvad as _webrtcvad
except Exception:  # pragma: no cover
    _webrtcvad = None

SAMPLE_RATE = 16000
FRAME_MS = 20
FRAME_SAMPLES = SAMPLE_RATE * FRAME_MS // 1000          # 320
FRAME_BYTES = FRAME_SAMPLES * 2                          # 640


def _env_float(name, default):
    try:
        return float(os.getenv(name, "").strip() or default)
    except Exception:
        return float(default)


def _env_bool(name, default=True):
    v = os.getenv(name, "").strip().lower()
    if not v:
        return default
    return v in {"1", "true", "yes", "on"}


PREROLL_MS = int(_env_float("FRIDAY_V5_PREROLL_MS", 400))
SPEC_SILENCE_MS = int(_env_float("FRIDAY_V5_SPEC_MS", 300))       # start recognising after this much silence
COMMIT_SILENCE_MS = int(_env_float("FRIDAY_V5_COMMIT_MS", 520))   # finalise after this much silence
LONG_COMMIT_SILENCE_MS = int(_env_float("FRIDAY_V5_LONG_COMMIT_MS", 760))  # long dictation gets a little more grace
MIN_SPEECH_MS = int(_env_float("FRIDAY_V5_MIN_SPEECH_MS", 220))
MAX_UTTERANCE_S = _env_float("FRIDAY_V5_MAX_UTTERANCE_S", 28)
BARGE_IN = _env_bool("FRIDAY_BARGE_IN", True)

# V6.0.1 - "FRIDAY talks / answers when I said nothing" fixes.  Every value can be changed at run time from
# Settings > Voice (see configure()) or with the environment variable shown.
#   * a segment must now contain real, clearly-voiced speech (not a click, a cough, a fan or room noise)
#   * her own voice (and its room echo) can no longer be taken for a command or a wake word
#   * the "no wake word needed" conversation window closes by itself after ACTIVE_WINDOW_S of quiet
MIN_VOICED_MARGIN = _env_float("FRIDAY_V5_MIN_MARGIN", 1.30)    # mean voiced loudness must beat the noise gate by this factor
MIN_VOICED_RATIO = _env_float("FRIDAY_V5_MIN_RATIO", 0.30)      # share of the utterance that must be voiced (clicks / typing fail this)
SPEAK_TAIL_S = _env_float("FRIDAY_V5_SPEAK_TAIL_S", 0.90)       # her voice still rings in the room this long after she stops
_SENSITIVITY = {"relaxed": 0.85, "normal": 1.0, "strict": 1.35}
CFG = {
    "sensitivity": (os.getenv("FRIDAY_MIC_SENSITIVITY", "normal").strip().lower() or "normal"),
    "active_window_s": _env_float("FRIDAY_ACTIVE_WINDOW_S", 60),     # 0 = stay in conversation until "standby"
    "wake_anywhere": _env_bool("FRIDAY_WAKE_ANYWHERE", False),       # True = "Friday" anywhere in a sentence wakes her (old behaviour)
    "barge_in": BARGE_IN,                                            # may you talk over her?
}
if CFG["sensitivity"] not in _SENSITIVITY:
    CFG["sensitivity"] = "normal"


def configure(**kw):
    """Change voice behaviour while FRIDAY is running (Settings > Voice).  Unknown / invalid values are ignored."""
    s = str(kw.get("sensitivity", "") or "").strip().lower()
    if s in _SENSITIVITY:
        CFG["sensitivity"] = s
    if kw.get("active_window_s") is not None:
        try:
            CFG["active_window_s"] = max(0.0, min(3600.0, float(kw["active_window_s"])))
        except Exception:
            pass
    if kw.get("wake_anywhere") is not None:
        CFG["wake_anywhere"] = bool(kw["wake_anywhere"])
    if kw.get("barge_in") is not None:
        CFG["barge_in"] = bool(kw["barge_in"])
    return dict(CFG)


def _sens() -> float:
    return _SENSITIVITY.get(CFG.get("sensitivity", "normal"), 1.0)


# --------------------------------------------------------------------------------------
# signal helpers
# --------------------------------------------------------------------------------------
def frame_rms(frame: bytes) -> float:
    if np is None or not frame:
        return 0.0
    a = np.frombuffer(frame, dtype=np.int16).astype(np.float32)
    if a.size == 0:
        return 0.0
    return float(np.sqrt(np.mean(a * a)))


def resample_to_16k(raw: bytes, rate: int) -> bytes:
    """Mono int16 at `rate` -> mono int16 at 16 kHz (numpy only; good enough for speech)."""
    if rate == SAMPLE_RATE or np is None:
        return raw
    a = np.frombuffer(raw, dtype=np.int16).astype(np.float32)
    if a.size == 0:
        return raw
    try:
        from scipy.signal import resample_poly  # type: ignore
        from math import gcd
        g = gcd(SAMPLE_RATE, rate)
        out = resample_poly(a, SAMPLE_RATE // g, rate // g)
    except Exception:
        n_out = int(a.size * SAMPLE_RATE / rate)
        x_old = np.linspace(0.0, 1.0, a.size, endpoint=False)
        x_new = np.linspace(0.0, 1.0, n_out, endpoint=False)
        out = np.interp(x_new, x_old, a)
    return np.clip(out, -32768, 32767).astype(np.int16).tobytes()


def normalise_pcm(pcm: bytes, target_peak: float = 0.80) -> bytes:
    """Light, fast gain normalisation (replaces the old multi-stage denoise/enhance chain)."""
    if np is None or not pcm:
        return pcm
    a = np.frombuffer(pcm, dtype=np.int16).astype(np.float32)
    if a.size == 0:
        return pcm
    # remove DC offset
    a = a - float(np.mean(a))
    peak = float(np.max(np.abs(a))) or 1.0
    gain = min(8.0, (target_peak * 32767.0) / peak)
    if gain > 1.15:
        a = a * gain
    return np.clip(a, -32768, 32767).astype(np.int16).tobytes()


class NoiseTracker:
    """Adaptive noise floor in int16-RMS units: drops fast, rises slowly, ignores speech frames."""

    def __init__(self, initial: float = 120.0):
        self.floor = float(initial)

    def update(self, rms: float, is_speech: bool):
        if is_speech:
            return
        if rms < self.floor:
            self.floor += (rms - self.floor) * 0.20
        else:
            self.floor += (rms - self.floor) * 0.01
        self.floor = max(25.0, min(self.floor, 1800.0))

    @property
    def threshold(self) -> float:
        return max(260.0, self.floor * 3.0)


class FrameVAD:
    """WebRTC VAD gated by an adaptive energy threshold. Works (energy only) without webrtcvad."""

    def __init__(self, aggressiveness: int = 2):
        self.noise = NoiseTracker()
        self._vad = None
        if _webrtcvad is not None:
            try:
                self._vad = _webrtcvad.Vad(aggressiveness)
            except Exception:
                self._vad = None

    last_rms = 0.0
    last_thr = 0.0

    def is_speech(self, frame: bytes, strict: float = 1.0) -> bool:
        rms = frame_rms(frame)
        thr = self.noise.threshold * strict
        self.last_rms = rms
        self.last_thr = thr
        if self._vad is not None:
            try:
                web = self._vad.is_speech(frame, SAMPLE_RATE)
            except Exception:
                web = rms > thr
            speech = (web and rms > thr * 0.85) or rms > thr * 2.4
        else:
            speech = rms > thr
        self.noise.update(rms, speech)
        return speech


# --------------------------------------------------------------------------------------
# segmenter  (pure logic, no threads, no clocks -> deterministic tests)
# --------------------------------------------------------------------------------------
@dataclass
class SegEvent:
    kind: str                      # "start" | "spec" | "resume" | "final" | "drop"
    pcm: bytes = b""
    seq: int = 0
    speaking: bool = False         # FRIDAY was speaking (or her voice was still ringing) when this utterance began
    duration: float = 0.0
    rms: float = 0.0               # mean loudness of the voiced frames (int16 RMS)
    margin: float = 0.0            # that loudness divided by the noise gate (>= MIN_VOICED_MARGIN for real speech)
    ratio: float = 0.0             # share of the utterance that was voiced
    voiced_ms: int = 0


class Segmenter:
    IDLE, SPEECH = 0, 1

    def __init__(self, vad: Optional[FrameVAD] = None):
        self.vad = vad or FrameVAD()
        self.preroll: Deque[bytes] = collections.deque(maxlen=max(1, PREROLL_MS // FRAME_MS))
        self.state = self.IDLE
        self.buf: List[bytes] = []
        self.recent: Deque[bool] = collections.deque(maxlen=8)
        self.recent_rms: Deque[float] = collections.deque(maxlen=8)
        self.silence = 0
        self.speech_frames = 0
        self.voiced_rms = 0.0
        self.gate = 0.0
        self.spec_issued = False
        self.seq = 0
        self.began_while_speaking = False
        self.warmup_frames = 12            # ignore the very first 240 ms (stream start-up pops)

    # frames, not seconds
    @staticmethod
    def _f(ms: int) -> int:
        return max(1, ms // FRAME_MS)

    def _commit_frames(self) -> int:
        n = len(self.buf)
        if n * FRAME_MS > 6000:
            return self._f(LONG_COMMIT_SILENCE_MS)
        return self._f(COMMIT_SILENCE_MS)

    def _trimmed(self) -> bytes:
        """Audio up to the last speech frame plus 160 ms of tail (silence beyond that only slows recognition)."""
        tail = self._f(160)
        end = len(self.buf) - max(0, self.silence - tail)
        return b"".join(self.buf[:max(1, end)])

    def reset(self):
        self.state = self.IDLE
        self.buf = []
        self.silence = 0
        self.speech_frames = 0
        self.voiced_rms = 0.0
        self.spec_issued = False
        self.recent.clear()
        self.recent_rms.clear()

    def quality(self):
        """(mean voiced RMS, margin over the noise gate, voiced share of the utterance) - real speech is loud AND mostly voiced."""
        n = max(1, self.speech_frames)
        mean = self.voiced_rms / n
        margin = mean / max(1.0, self.gate)
        body = max(1, len(self.buf) - max(0, self.silence - self._f(160)))
        return mean, margin, min(1.0, self.speech_frames / body)

    def _quality_ok(self) -> bool:
        _mean, margin, ratio = self.quality()
        s = _sens()
        return margin >= MIN_VOICED_MARGIN * s and ratio >= MIN_VOICED_RATIO

    def _evt(self, kind: str, **kw) -> "SegEvent":
        mean, margin, ratio = self.quality()
        return SegEvent(kind, rms=mean, margin=margin, ratio=ratio, voiced_ms=self.speech_frames * FRAME_MS, **kw)

    def feed(self, frame: bytes, tts_active: bool = False) -> List[SegEvent]:
        ev: List[SegEvent] = []
        if len(frame) != FRAME_BYTES:
            return ev
        if self.warmup_frames > 0:
            self.warmup_frames -= 1
            self.vad.noise.update(frame_rms(frame), False)
            self.preroll.append(frame)
            return ev
        # While FRIDAY talks, her own voice reaches the mic: demand clearly louder speech to start a segment.
        strict = (2.2 if tts_active else 1.0) * _sens()
        sp = self.vad.is_speech(frame, strict=strict)
        self.recent.append(sp)
        self.recent_rms.append(self.vad.last_rms)

        if self.state == self.IDLE:
            self.preroll.append(frame)
            # V6.0.1: 5 voiced frames out of the last 8 (100 ms of real voice), 7 of 8 while she is talking.
            # (Was 3 of 4 = 60 ms, which a click, a chair or a breath can satisfy.)
            need = 7 if tts_active else 5
            if sum(self.recent) >= need and len(self.recent) >= need:
                self.state = self.SPEECH
                self.buf = list(self.preroll)
                self.silence = 0
                self.speech_frames = sum(self.recent)
                self.voiced_rms = float(sum(r for r, v in zip(self.recent_rms, self.recent) if v))
                self.gate = self.vad.last_thr / max(0.01, strict)   # the plain noise gate, without the "she is talking" / sensitivity factors
                self.spec_issued = False
                self.began_while_speaking = bool(tts_active)
                self.seq += 1
                ev.append(SegEvent("start", seq=self.seq, speaking=self.began_while_speaking))
            return ev

        # SPEECH
        self.buf.append(frame)
        if sp:
            self.silence = 0
            self.speech_frames += 1
            self.voiced_rms += self.vad.last_rms
            if self.spec_issued:
                self.spec_issued = False
                ev.append(SegEvent("resume", seq=self.seq))
        else:
            self.silence += 1

        dur = len(self.buf) * FRAME_MS / 1000.0
        enough = self.speech_frames * FRAME_MS >= MIN_SPEECH_MS
        if self.silence >= self._f(SPEC_SILENCE_MS) and not self.spec_issued and enough and self._quality_ok():
            self.spec_issued = True
            ev.append(self._evt("spec", pcm=self._trimmed(), seq=self.seq, speaking=self.began_while_speaking, duration=dur))
        if self.silence >= self._commit_frames() or dur >= MAX_UTTERANCE_S:
            if enough and self._quality_ok():
                ev.append(self._evt("final", pcm=self._trimmed(), seq=self.seq, speaking=self.began_while_speaking, duration=dur))
            else:
                ev.append(SegEvent("drop", seq=self.seq))
            self.preroll.clear()
            self.reset()
        return ev


# --------------------------------------------------------------------------------------
# microphone stream
# --------------------------------------------------------------------------------------
class MicStream:
    """One persistent PyAudio input stream (callback mode, so no audio is ever dropped while we recognise)."""

    def __init__(self, device_index: Optional[int] = None):
        self.q: "queue.Queue[bytes]" = queue.Queue(maxsize=600)
        self._pa = None
        self._stream = None
        self._rate = SAMPLE_RATE
        self._carry = b""
        self.device_index = device_index
        self.opened_at = 0.0
        self.error: Optional[str] = None
        self._closing = False

    def open(self):
        import pyaudio  # type: ignore
        self._pa = pyaudio.PyAudio()
        idx = self.device_index
        if idx is None:
            env = os.getenv("FRIDAY_MIC_INDEX", "").strip()
            if env.isdigit():
                idx = int(env)
        last_err = None
        for rate in (16000, 48000, 44100, 32000, 24000, 22050, 8000):
            try:
                kwargs = dict(format=pyaudio.paInt16, channels=1, rate=rate, input=True,
                              frames_per_buffer=int(rate * FRAME_MS / 1000),
                              stream_callback=self._callback)
                if idx is not None:
                    kwargs["input_device_index"] = idx
                self._stream = self._pa.open(**kwargs)
                self._rate = rate
                break
            except Exception as exc:
                last_err = exc
                self._stream = None
        if self._stream is None:
            raise RuntimeError(f"No microphone could be opened: {last_err}")
        self._stream.start_stream()
        self.opened_at = time.time()
        self.error = None

    def _callback(self, in_data, frame_count, time_info, status):
        try:
            data = resample_to_16k(in_data, self._rate) if self._rate != SAMPLE_RATE else in_data
            buf = self._carry + data
            n = len(buf) // FRAME_BYTES
            for i in range(n):
                try:
                    self.q.put_nowait(buf[i * FRAME_BYTES:(i + 1) * FRAME_BYTES])
                except queue.Full:
                    try:
                        self.q.get_nowait()
                    except Exception:
                        pass
            self._carry = buf[n * FRAME_BYTES:]
        except Exception:
            pass
        import pyaudio  # type: ignore
        return (None, pyaudio.paContinue)

    def read(self, timeout: float = 0.5) -> Optional[bytes]:
        try:
            return self.q.get(timeout=timeout)
        except queue.Empty:
            return None

    def alive(self) -> bool:
        try:
            return bool(self._stream is not None and self._stream.is_active())
        except Exception:
            return False

    def close(self):
        self._closing = True
        try:
            if self._stream is not None:
                self._stream.stop_stream()
                self._stream.close()
        except Exception:
            pass
        try:
            if self._pa is not None:
                self._pa.terminate()
        except Exception:
            pass
        self._stream = None
        self._pa = None


# --------------------------------------------------------------------------------------
# recognition
# --------------------------------------------------------------------------------------
@dataclass
class Recognition:
    text: str = ""
    confidence: float = 0.0
    source: str = ""
    alternatives: List[str] = field(default_factory=list)
    ms: float = 0.0


_HALLUCINATIONS = {
    "you", "thank you", "thanks", "thanks for watching", "thank you for watching", "bye", "okay", "ok", "so",
    "uh", "um", "hmm", "mm", "the", "i", "yeah", "oh", "ah", "huh", "subtitles by the amara.org community",
}
# Phrases speech models invent out of silence / room noise / music.  Dropped whatever the length or loudness.
_ALWAYS_HALLUCINATION = (
    "thanks for watching", "thank you for watching", "thank you so much for watching", "please subscribe", "like and subscribe",
    "see you in the next video", "see you next time", "see you in the next one", "subtitles by", "subtitles made by",
    "translated by", "transcribed by", "captions by", "amara.org", "www.", ".com", "blank audio", "blank_audio",
    "music playing", "background music", "[music]", "(music)", "[applause]", "(applause)", "[laughter]", "(laughter)",
    "thank you very much", "thank you thank you", "bye bye", "you you you",
)
# The local recogniser is primed with this vocabulary list; on noise it sometimes repeats the list back.  Never a command.
_PROMPT_TEXT = os.getenv("FRIDAY_WHISPER_PROMPT", "").strip() or (
    "Friday, open, close, search, play, remind me, send a message, WhatsApp, calendar, goals, memory, attach, file, code, "
    "research, screen, camera, system, income, expense, budget.")
_PROMPT_TOKENS = re.sub(r"[^a-z' ]", " ", _PROMPT_TEXT.lower()).split()


def _longest_prompt_run(tokens: List[str]) -> int:
    """Length of the longest run of tokens that appears, in order and unbroken, inside the recogniser's priming text."""
    best = 0
    n, m = len(tokens), len(_PROMPT_TOKENS)
    for i in range(n):
        for j in range(m):
            k = 0
            while i + k < n and j + k < m and tokens[i + k] == _PROMPT_TOKENS[j + k]:
                k += 1
            if k > best:
                best = k
    return best


def looks_like_hallucination(text: str, duration: float, rms: float) -> bool:
    raw = (text or "").strip()
    if not raw:
        return True
    low = raw.lower()
    # "[Music]", "(applause)", "*sigh*" - sound descriptions, not speech
    if re.fullmatch(r"[\[(*♪♫\s].*[\])*♪♫\s]", low) and re.search(r"[\[(*♪♫]", low):
        return True
    letters = [c for c in raw if c.isalpha()]
    if letters and sum(1 for c in letters if ord(c) < 0x250) / len(letters) < 0.7:
        return True                                     # Chinese / Korean / Cyrillic ... invented out of noise by an English recogniser
    t = re.sub(r"[^a-z' ]", "", low).strip()
    if not t:
        return True
    if any(p in low for p in _ALWAYS_HALLUCINATION):
        return True
    if t in _HALLUCINATIONS and (duration < 1.2 or rms < 450):
        return True
    words = t.split()
    if len(words) >= 6 and len(set(words)) <= 2:      # "the the the the ..." loops
        return True
    if len(words) >= 4:
        half = len(words) // 2                          # "thank you thank you thank you" style repeats
        if len(words) % 2 == 0 and words[:half] == words[half:] and len(set(words)) <= half:
            return True
        if _longest_prompt_run(words) >= 4 and _longest_prompt_run(words) >= 0.8 * len(words):
            return True                                 # the priming word list read back
    return False


class Recognizer:
    """Race a local and a cloud recogniser; the first usable answer wins (best of both when waking)."""

    def __init__(self, local_fn: Optional[Callable[[bytes], Recognition]] = None,
                 cloud_fn: Optional[Callable[[bytes], Recognition]] = None,
                 local_ready: Optional[Callable[[], bool]] = None):
        self.local_fn = local_fn
        self.cloud_fn = cloud_fn
        self.local_ready = local_ready or (lambda: True)
        self._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="Friday5STT")
        self._cloud_fail = 0
        self._cloud_off_until = 0.0
        self.last_ms = 0.0

    def _cloud_usable(self) -> bool:
        return self.cloud_fn is not None and time.time() >= self._cloud_off_until

    def _wrap_cloud(self, pcm):
        try:
            r = self.cloud_fn(pcm)
            self._cloud_fail = 0
            return r
        except Exception:
            self._cloud_fail += 1
            if self._cloud_fail >= 2:                       # offline / blocked: stop paying the timeout
                self._cloud_off_until = time.time() + 45.0
            raise

    def transcribe(self, pcm: bytes, wake_check: Optional[Callable[[str], bool]] = None,
                   timeout: float = 12.0) -> Recognition:
        t0 = time.time()
        futs = {}
        if self.local_fn is not None and self.local_ready():
            futs[self._pool.submit(self.local_fn, pcm)] = "local"
        if self._cloud_usable():
            futs[self._pool.submit(self._wrap_cloud, pcm)] = "cloud"
        if not futs and self.local_fn is not None:                     # model still loading and cloud unavailable
            futs[self._pool.submit(self.local_fn, pcm)] = "local"
        if not futs:
            return Recognition()
        pending = set(futs)
        results: List[Recognition] = []
        deadline = t0 + timeout
        while pending and time.time() < deadline:
            done, pending = _fwait(pending, timeout=max(0.05, deadline - time.time()), return_when=FIRST_COMPLETED)
            for f in done:
                try:
                    r = f.result()
                except Exception:
                    continue
                if r and r.text.strip():
                    r.source = r.source or futs[f]
                    results.append(r)
            if results:
                first = results[0]
                # when gated by the wake word give the other engine a short chance if the first one missed it
                if wake_check is not None and not wake_check(first.text) and pending:
                    other_deadline = time.time() + 0.6
                    while pending and time.time() < other_deadline:
                        d2, pending = _fwait(pending, timeout=0.1, return_when=FIRST_COMPLETED)
                        for f in d2:
                            try:
                                r = f.result()
                                if r and r.text.strip():
                                    r.source = r.source or futs[f]
                                    results.append(r)
                            except Exception:
                                pass
                    for r in results:
                        if wake_check(r.text):
                            first = r
                            break
                for p in pending:
                    p.cancel()
                first.alternatives = [x.text for x in results if x is not first]
                first.ms = (time.time() - t0) * 1000
                self.last_ms = first.ms
                return first
        for p in pending:
            p.cancel()
        self.last_ms = (time.time() - t0) * 1000
        return Recognition()


def make_default_recognizer(voice_engine=None, language: str = "en-US") -> Recognizer:
    """Wire the Recognizer to faster-whisper (friday_voice_engine) and Google (SpeechRecognition) if present."""
    local_fn = cloud_fn = None
    local_ready = None
    ve = voice_engine
    if ve is not None:
        try:
            if ve.faster_whisper_available():
                def local_fn(pcm, _ve=ve):
                    t0 = time.time()
                    text = _ve.transcribe_pcm(pcm, sample_rate=SAMPLE_RATE, channels=1, wait_for_model=False) or ""
                    try:
                        conf = float(_ve.last_transcription_confidence())
                    except Exception:
                        conf = 0.75
                    return Recognition(text=text.strip(), confidence=conf, source="local", ms=(time.time() - t0) * 1000)
                local_ready = ve.is_ready
        except Exception:
            local_fn = None
    if _env_bool("FRIDAY_V5_CLOUD_STT", True):
        try:
            import speech_recognition as sr  # type: ignore
            _rec = sr.Recognizer()

            def cloud_fn(pcm, _sr=sr, _rec=_rec):
                t0 = time.time()
                audio = _sr.AudioData(pcm, SAMPLE_RATE, 2)
                text = _rec.recognize_google(audio, language=language, show_all=False)
                return Recognition(text=str(text or "").strip(), confidence=0.82, source="cloud", ms=(time.time() - t0) * 1000)
        except Exception:
            cloud_fn = None
    return Recognizer(local_fn, cloud_fn, local_ready)


# --------------------------------------------------------------------------------------
# wake word
# --------------------------------------------------------------------------------------
_WAKE_ALIASES = {"friday", "fryday", "fri day", "fridays", "frieday", "freeday", "fride", "fridy", "frydaye"}


def _wake_token(tok: str) -> bool:
    tok = re.sub(r"[^a-z]", "", tok.lower())
    if not tok:
        return False
    if tok in _WAKE_ALIASES:
        return True
    return difflib.SequenceMatcher(None, tok, "friday").ratio() >= 0.8


def find_wake(text: str, anywhere: bool = False):
    """Return (found, remainder).  The wake word counts when it opens the sentence ('hey friday ...', 'ok friday ...').
    In standby (anywhere=True) it also counts mid-sentence or at the end ('open chrome friday'), as before."""
    words = (text or "").strip().split()
    limit = len(words) if anywhere else min(2, len(words))
    for i, w in enumerate(words[:limit]):
        if _wake_token(w):
            if i <= 1:
                rest = " ".join(words[i + 1:]).lstrip(" ,.:;!-")
            else:
                rest = " ".join(words[:i] + words[i + 1:]).strip(" ,.:;!-")
            return True, rest
    for i in range(min(2 if not anywhere else len(words) - 1, len(words) - 1)):
        if _wake_token(words[i] + words[i + 1]) and not _wake_token(words[i]) and not _wake_token(words[i + 1]):   # "fri day" (not "on friday")
            return True, " ".join(words[i + 2:] if i <= 1 else words[:i] + words[i + 2:]).lstrip(" ,.:;!-")
    return False, (text or "").strip()


_WAKE_FILLERS = {"hey", "hi", "hello", "ok", "okay", "yo", "so", "alright", "right", "well", "there", "um", "uh", "oh", "please"}


def find_wake_strict(text: str):
    """The wake word counts only when it OPENS the sentence ("Friday ...", "Hey Friday ...", "OK there Friday, ...").
    A "Friday" in the middle or at the end ("see you on Friday", a TV, other people talking) is just a word."""
    words = (text or "").strip().split()
    for i, w in enumerate(words[:4]):
        if _wake_token(w):
            rest = " ".join(words[i + 1:]).lstrip(" ,.:;!-")
            return True, rest
        if re.sub(r"[^a-z]", "", w.lower()) not in _WAKE_FILLERS:
            break
    for i in range(min(3, max(0, len(words) - 1))):          # "fri day"
        if (all(re.sub(r"[^a-z]", "", x.lower()) in _WAKE_FILLERS for x in words[:i]) and _wake_token(words[i] + words[i + 1])
                and not _wake_token(words[i]) and not _wake_token(words[i + 1])):
            return True, " ".join(words[i + 2:]).lstrip(" ,.:;!-")
    return False, (text or "").strip()


def find_wake_standby(text: str):
    """Wake rule while on standby.  Default = sentence-opening only; Settings > Voice can restore the old "anywhere" rule."""
    if CFG.get("wake_anywhere"):
        return find_wake(text, anywhere=True)
    return find_wake_strict(text)


def _norm_tokens(t: str) -> List[str]:
    return re.sub(r"[^a-z0-9' ]", " ", (t or "").lower()).split()


def echo_like(text: str, spoken: List[str], threshold: float = 0.7) -> bool:
    """True when `text` is (mostly) made of words FRIDAY herself said in the last moments - her voice coming back in through the mic."""
    tt = _norm_tokens(text)
    if not tt:
        return False
    tset = set(tt)
    for sp in spoken or []:
        sset = set(_norm_tokens(sp))
        if not sset:
            continue
        if len(tset & sset) / len(tset) >= threshold:
            return True
    return False


MIN_BARGE_WORDS = int(_env_float("FRIDAY_V5_MIN_BARGE_WORDS", 4))
STOP_WORDS = re.compile(r"^(?:friday[, ]*)?(?:stop|stop talking|be quiet|quiet|enough|shut up|cancel|never ?mind|that'?s enough|hold on|wait)[.!]*$", re.I)


# --------------------------------------------------------------------------------------
# engine
# --------------------------------------------------------------------------------------
@dataclass
class Hooks:
    """Backend callbacks. Anything left as None gets a safe default."""
    is_active: Callable[[], bool] = lambda: True            # conversation (no wake word needed) vs standby
    set_active: Callable[[bool, str], None] = lambda a, r="": None
    is_standby_command: Callable[[str], bool] = lambda t: bool(re.match(r"^(?:stand ?by|go to standby|sleep)\b", t.strip(), re.I))
    correct: Callable[[str], str] = lambda t: t
    is_echo: Callable[[str], bool] = lambda t: False
    speak: Callable[[str], None] = lambda t: None
    is_speaking: Callable[[], bool] = lambda: False
    interrupt: Callable[[], None] = lambda: None
    duck: Callable[[bool], None] = lambda on: None
    log: Callable[[str, str], None] = lambda m, k="voice": None
    emit: Callable[[str], None] = lambda line: print(line, flush=True)
    wake_ack: str = "Yes, sir."
    recent_spoken: Callable[[], List[str]] = lambda: []      # what FRIDAY said in the last minute (newest first), for echo rejection


class VoiceEngine:
    def __init__(self, hooks: Hooks, recognizer: Recognizer, mic=None):
        self.hooks = hooks
        self.rec = recognizer
        self.mic = mic
        self.seg = Segmenter()
        self.commands: "queue.Queue[str]" = queue.Queue()
        self._stop = threading.Event()
        self._threads: List[threading.Thread] = []
        self._spec_future = None
        self._spec_seq = -1
        self._pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix="Friday5Seg")
        self._utter_q: "queue.Queue[tuple]" = queue.Queue()
        self.last_timing = {}
        self.started = False
        self._ducked = False
        self._last_activity = time.time()      # last time the conversation was "alive" (a command was heard or she was speaking)
        self._last_speaking_t = 0.0            # last time she was audibly speaking (for the room-echo tail)
        self._last_tick = 0.0
        self._was_active = False

    # ---- lifecycle
    def start(self):
        if self.started:
            return
        self.started = True
        if self.mic is None:
            self.mic = MicStream()
            self.mic.open()
        for target, name in ((self._capture_loop, "Friday5-Capture"), (self._utterance_loop, "Friday5-Utterance")):
            t = threading.Thread(target=target, name=name, daemon=True)
            t.start()
            self._threads.append(t)

    def stop(self):
        self._stop.set()
        try:
            if self.mic is not None:
                self.mic.close()
        except Exception:
            pass

    # ---- capture thread: frames -> segmenter -> recognition jobs
    def _capture_loop(self):
        last_ok = time.time()
        while not self._stop.is_set():
            frame = self.mic.read(0.5)
            if frame is None:
                if time.time() - last_ok > 4.0 and hasattr(self.mic, "alive") and not self.mic.alive():
                    self._reopen_mic()
                    last_ok = time.time()
                continue
            last_ok = time.time()
            try:
                now = time.time()
                speaking_raw = bool(self.hooks.is_speaking())
                if speaking_raw:
                    self._last_speaking_t = now
                # her voice keeps ringing in the room for a moment after she stops: treat that tail as "still speaking"
                speaking = speaking_raw or (now - self._last_speaking_t) < SPEAK_TAIL_S
                self._tick(now, speaking_raw)
                if speaking and not CFG.get("barge_in", True):
                    self.seg.reset()
                    continue
                for e in self.seg.feed(frame, tts_active=speaking):
                    self._on_event(e)
            except Exception as exc:
                self.hooks.log(f"V5 capture error (continuing): {exc}", "recovery")

    def _tick(self, now: float, speaking_raw: bool):
        """Once a second: close the "no wake word needed" conversation window after a quiet spell."""
        if now - self._last_tick < 1.0:
            return
        self._last_tick = now
        h = self.hooks
        active = bool(h.is_active())
        if speaking_raw or (active and not self._was_active):
            self._last_activity = now                  # she is talking, or the conversation has just opened
        self._was_active = active
        win = float(CFG.get("active_window_s", 0) or 0)
        if active and win > 0 and not speaking_raw and not self._utter_q.qsize() and now - self._last_activity > win:
            self._was_active = False
            h.log("Conversation idle: back to standby", "voice")
            h.set_active(False, "conversation idle - say 'Friday' to wake me")

    def _reopen_mic(self):
        try:
            self.mic.close()
        except Exception:
            pass
        for attempt in range(5):
            if self._stop.is_set():
                return
            try:
                self.mic = MicStream()
                self.mic.open()
                self.hooks.log("Microphone re-opened", "recovery")
                return
            except Exception as exc:
                self.hooks.log(f"Microphone re-open failed ({attempt + 1}/5): {exc}", "recovery")
                time.sleep(1.5)

    def _wake_check(self, text):
        return find_wake_standby(text)[0]

    def _submit(self, pcm):
        pcm = normalise_pcm(pcm)
        gate = not self.hooks.is_active()
        return self._pool.submit(self.rec.transcribe, pcm, self._wake_check if gate else None)

    def _on_event(self, e: SegEvent):
        if e.kind == "start":
            if e.speaking and CFG.get("barge_in", True) and not self._ducked:
                self._ducked = True
                try:
                    self.hooks.duck(True)           # lower her volume at once; decided for real after recognition
                except Exception:
                    pass
        elif e.kind == "spec":
            self._spec_seq = e.seq
            self._spec_future = self._submit(e.pcm)
        elif e.kind == "resume":
            self._spec_future = None
            self._spec_seq = -1
        elif e.kind == "final":
            fut = self._spec_future if (self._spec_future is not None and self._spec_seq == e.seq) else self._submit(e.pcm)
            self._spec_future = None
            self._spec_seq = -1
            self._utter_q.put((fut, e))
            self.hooks.emit("ACTION::LISTEN_END")
            self.hooks.emit("ACTION::RECOGNIZE_START")
        elif e.kind == "drop":
            if self._ducked:
                self._ducked = False
                self.hooks.duck(False)

    # ---- utterance thread: recognition result -> gating -> command queue
    def _utterance_loop(self):
        while not self._stop.is_set():
            try:
                fut, e = self._utter_q.get(timeout=0.5)
            except queue.Empty:
                continue
            t_in = time.time()
            try:
                r = fut.result(timeout=15)
            except Exception:
                r = Recognition()
            finally:
                if self._ducked:
                    self._ducked = False
                    try:
                        self.hooks.duck(False)
                    except Exception:
                        pass
            self.hooks.emit("ACTION::RECOGNIZE_END")
            try:
                self._handle_result(r, e, t_in)
            except Exception as exc:
                self.hooks.log(f"V5 utterance error (continuing): {exc}", "recovery")

    def _handle_result(self, r: Recognition, e: SegEvent, t_in: float):
        h = self.hooks
        text = (r.text or "").strip()
        if not text:
            return
        rms = e.rms or (frame_rms(e.pcm[:FRAME_BYTES * 50]) if e.pcm else 0.0)
        if looks_like_hallucination(text, e.duration, rms):
            return
        try:
            text = h.correct(text) or text
        except Exception:
            pass
        text = text.strip()
        if not text:
            return
        speaking = e.speaking or h.is_speaking()
        if h.is_echo(text) and len(text.split()) >= 2:
            h.log("Ignored (sounds like FRIDAY's own voice)", "voice")
            return
        if speaking:
            # The utterance began while she was talking (or her voice was still ringing): if it is made of her own words
            # it is her voice coming back through the microphone, never a command - and never a wake word.
            try:
                spoken = list(h.recent_spoken() or [])
            except Exception:
                spoken = []
            if echo_like(text, spoken):
                h.log("Ignored (echo of FRIDAY's own voice)", "voice")
                return

        sens = _sens()
        active = h.is_active()
        found, rest = find_wake_strict(text) if active else find_wake_standby(text)
        if not active:
            if not found:
                return                                     # standby: only "Friday ..." counts
            if not rest:
                # a bare "Friday" must be clearly spoken: a click or a murmur the recogniser turned into her name is not a wake-up
                if speaking or e.margin < 1.6 * sens or e.voiced_ms < 260:
                    h.log("Ignored a weak 'Friday' (probably not speech)", "voice")
                    return
            h.set_active(True, "wake word detected")
            self._last_activity = time.time()
            if not rest:
                if speaking:
                    h.interrupt()
                h.speak(h.wake_ack)
                return
            text = rest
        elif found:
            if not rest:
                return
            text = rest
        text = text.strip()
        low = text.lower().strip(" .!?")
        deliberate = bool(found) or bool(STOP_WORDS.match(low))
        if STOP_WORDS.match(low):
            h.interrupt()
            h.emit("ACTION::LISTEN_START")
            return
        if h.is_standby_command(low):
            h.set_active(False, "standby command")
            h.speak("Standing by.")
            return
        words = low.split()
        if speaking and not deliberate and len(words) < MIN_BARGE_WORDS:
            # a short fragment over her voice is far more likely echo or noise than a real interruption;
            # to interrupt her say "Friday, ..." or "stop", or speak a full sentence
            h.log(f"Ignored a short fragment while she was speaking: {low!r}", "voice")
            return
        if len(words) == 1 and (e.margin < 2.0 * sens or e.voiced_ms < 240) and low not in ("yes", "no", "stop", "yeah", "yep", "nope"):
            h.log(f"Ignored a faint single word: {low!r}", "voice")
            return
        if speaking:
            h.interrupt()                                   # she stops mid-sentence; the new command is handled next
        self._last_activity = time.time()
        self.last_timing = {"stt_ms": round(r.ms), "source": r.source,
                            "after_speech_ms": round((time.time() - t_in) * 1000 + r.ms)}
        self.commands.put(text)
        h.log(f"V5 heard ({r.source}, {r.ms:.0f} ms): {text}", "recognition")

    # ---- consumer API
    def get_command(self, timeout: float = 0.5) -> Optional[str]:
        try:
            return self.commands.get(timeout=timeout)
        except queue.Empty:
            return None


# --------------------------------------------------------------------------------------
# module level API used by friday_backend.listen()
# --------------------------------------------------------------------------------------
_ENGINE: Optional[VoiceEngine] = None
_ENGINE_LOCK = threading.Lock()
_DISABLED_REASON = ""


def available() -> bool:
    if np is None:
        return False
    try:
        import pyaudio  # noqa: F401
    except Exception:
        return False
    return not _DISABLED_REASON and _env_bool("FRIDAY_V5_VOICE", True)


def get_engine(hooks: Hooks, voice_engine=None, language="en-US") -> VoiceEngine:
    global _ENGINE, _DISABLED_REASON
    with _ENGINE_LOCK:
        if _ENGINE is None:
            try:
                eng = VoiceEngine(hooks, make_default_recognizer(voice_engine, language))
                eng.start()
                _ENGINE = eng
            except Exception as exc:
                _DISABLED_REASON = str(exc)
                raise
        else:
            _ENGINE.hooks = hooks
        return _ENGINE


def listen(hooks: Hooks, voice_engine=None, language="en-US") -> str:
    """Blocking: returns the next accepted command ('' when the engine is stopping)."""
    eng = get_engine(hooks, voice_engine, language)
    hooks.emit("ACTION::LISTEN_START")
    label = "ACTIVE" if hooks.is_active() else "STANDBY"
    hooks.emit(f"\n🎤 Listening... [{label}]")
    while not eng._stop.is_set():
        cmd = eng.get_command(0.4)
        if cmd:
            hooks.emit("ACTION::HEARD::" + base64.b64encode(cmd.encode("utf-8")).decode("ascii"))
            hooks.emit(f"You: {cmd}")
            return cmd
    return ""


def shutdown():
    global _ENGINE
    with _ENGINE_LOCK:
        if _ENGINE is not None:
            _ENGINE.stop()
            _ENGINE = None


def health() -> dict:
    eng = _ENGINE
    return {
        "engine": "friday_voice5",
        "running": bool(eng and eng.started and not eng._stop.is_set()),
        "webrtcvad": _webrtcvad is not None,
        "noise_floor": round(eng.seg.vad.noise.floor, 1) if eng else None,
        "last": dict(eng.last_timing) if eng else {},
        "disabled_reason": _DISABLED_REASON,
        "barge_in": CFG.get("barge_in", BARGE_IN),
        "config": dict(CFG),
    }
