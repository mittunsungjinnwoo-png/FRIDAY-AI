"""FRIDAY 6.0 autonomous task engine: Understand -> Plan -> Execute (approved tools) -> Verify -> Recover or report.

Features (blueprint section 6): multi-step planning, tool selection and chaining, persistent task state with checkpoints
and crash recovery, dependency and deadline tracking, a priority queue, parallel execution of independent steps,
automatic result validation, human approval gates for sensitive actions, task history/logs/reproducible plans,
cancellation and emergency stop, time and step limits, loop and repeated-failure detection, adaptive retries (a different
strategy instead of repeating the same mistake) and honest reporting of completed / failed / partial work.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, wait
from pathlib import Path
from typing import Callable, Dict, List, Optional

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS tasks6(id INTEGER PRIMARY KEY, goal TEXT, status TEXT, priority INTEGER DEFAULT 5, deadline REAL, plan TEXT, state TEXT,
    created REAL, started REAL, ended REAL, budget_s REAL DEFAULT 300, depends TEXT DEFAULT '[]', report TEXT DEFAULT '', attempts INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS task_log6(id INTEGER PRIMARY KEY, task INTEGER, ts REAL, level TEXT, text TEXT);
""")

MAX_STEPS = 8
MAX_PARALLEL = 3
STOP = threading.Event()                          # emergency stop
_tools: Dict[str, Dict] = {}
_approvals: Dict[int, Dict] = {}                  # task id -> {"event", "granted", "step", "desc"}
_cancelled: set = set()
_cfg: Dict[str, Callable] = {"say": lambda t: None, "progress": lambda d: None}
_runner = {"thread": None, "lock": threading.Lock()}


def configure(**kw):
    _cfg.update({k: v for k, v in kw.items() if v is not None})


def register_tool(name: str, fn: Callable[[Dict], Dict], risk: str = "safe", desc: str = "", fallback: str = ""):
    """fn(args) -> {"ok": bool, "output": str, ...}.  risk: 'safe' runs at once, 'sensitive' needs the user's approval."""
    _tools[name] = {"fn": fn, "risk": risk, "desc": desc, "fallback": fallback}


def tool_names() -> List[str]:
    return sorted(_tools)


# ------------------------------------------------------------------ logging / persistence
def _log(tid: int, text: str, level: str = "info"):
    try:
        C.x("INSERT INTO task_log6(task,ts,level,text) VALUES(?,?,?,?)", (tid, C.now(), level, C.clip(C.redact(text), 400)))
    except Exception:
        pass


def _save(tid: int, plan=None, state=None, **cols):
    sets, args = [], []
    if plan is not None:
        sets.append("plan=?"); args.append(C.jdump(plan))
    if state is not None:
        sets.append("state=?"); args.append(C.jdump(state))
    for k, v in cols.items():
        sets.append(f"{k}=?"); args.append(v)
    if sets:
        C.x(f"UPDATE tasks6 SET {', '.join(sets)} WHERE id=?", args + [tid])


def get(tid: int) -> Optional[Dict]:
    r = C.q("SELECT * FROM tasks6 WHERE id=?", (tid,))
    if not r:
        return None
    d = dict(r[0])
    d["plan"] = C.jload(d["plan"], []) or []
    d["state"] = C.jload(d["state"], {}) or {}
    d["depends"] = C.jload(d["depends"], []) or []
    return d


# ------------------------------------------------------------------ planning
_TEMPLATES = [
    (re.compile(r"\b(diagnos|why is my (?:laptop|pc|computer)|slow|hot|battery)\b", re.I),
     [("system_info", {}, "Read CPU, memory, disk and battery", {"nonempty": True}), ("think", {"prompt": "Using the system readings, explain the likely cause and best fix: {goal}"}, "Diagnose", {"nonempty": True})]),
    (re.compile(r"\b(organi[sz]e|clean up|sort)\b.*\b(folder|downloads|desktop|files)\b", re.I),
     [("analyze_folder", {"folder": "{path}"}, "Survey the folder", {"nonempty": True}), ("think", {"prompt": "Propose an organisation plan (no changes yet): {goal}"}, "Propose a plan", {"nonempty": True})]),
    (re.compile(r"\b(research|find out|look up|compare)\b", re.I),
     [("web_research", {"query": "{goal}"}, "Research with sources", {"nonempty": True}), ("think", {"prompt": "Write a short cited summary and say what is uncertain: {goal}\n\nFindings:\n{prev}"}, "Summarise and flag uncertainty", {"nonempty": True})]),
    (re.compile(r"\b(test|review|audit|scan)\b.*\b(code|project|codebase|repo)\b", re.I),
     [("code_map", {"path": "{path}"}, "Map the codebase", {"nonempty": True}), ("code_review", {"path": "{path}"}, "Review for bugs and security", {"nonempty": True}), ("run_tests", {"path": "{path}"}, "Run the tests", {})]),
    (re.compile(r"\b(write|create|draft|make)\b.*\b(report|document|notes|summary|essay|plan)\b", re.I),
     [("think", {"prompt": "Outline then write: {goal}"}, "Draft the content", {"nonempty": True}), ("write_file", {"name": "task_output.md", "content": "{prev}"}, "Save it as a file", {"file_exists": True})]),
]


def _fill(v, ctx: Dict):
    if isinstance(v, str):
        for k, val in ctx.items():
            v = v.replace("{" + k + "}", str(val))
        return v
    if isinstance(v, dict):
        return {k: _fill(x, ctx) for k, x in v.items()}
    return v


def make_plan(goal: str) -> List[Dict]:
    """Understand the goal and split it into steps with dependencies, tools and success checks."""
    steps: List[Dict] = []
    raw = ""
    if C._cfg.get("llm"):
        names = ", ".join(f"{n} ({_tools[n]['desc'][:50]})" for n in sorted(_tools))
        raw = C.llm("Plan this task as a JSON array of at most 6 steps. Each step: {\"tool\": one of the tools, \"args\": {...}, \"desc\": short text, \"depends\": [indexes of earlier steps], "
                    "\"verify\": {\"nonempty\": true} or {\"file_exists\": true}}. Use only these tools: " + names + ". Reply with JSON only.\n\nTask: " + goal)
    j = None
    if raw:
        m = re.search(r"\[.*\]", raw, re.S)
        if m:
            j = C.jload(m.group(0))
    if isinstance(j, list):
        for i, s in enumerate(j[:MAX_STEPS]):
            if isinstance(s, dict) and s.get("tool") in _tools:
                steps.append({"id": i, "tool": s["tool"], "args": s.get("args") or {}, "desc": str(s.get("desc") or s["tool"])[:80],
                              "depends": [d for d in (s.get("depends") or []) if isinstance(d, int) and d < i], "verify": s.get("verify") or {}, "status": "pending", "attempts": 0})
    if not steps:
        for pat, tpl in _TEMPLATES:
            if pat.search(goal):
                for tool, args, desc, ver in tpl:
                    if tool in _tools:
                        n = len(steps)
                        steps.append({"id": n, "tool": tool, "args": args, "desc": desc, "depends": [n - 1] if n else [], "verify": ver, "status": "pending", "attempts": 0})
                break
    if not steps:
        steps = [{"id": 0, "tool": "think", "args": {"prompt": "{goal}"}, "desc": "Work it out", "depends": [], "verify": {"nonempty": True}, "status": "pending", "attempts": 0}]
    return steps


def create(goal: str, priority: int = 5, deadline: Optional[float] = None, budget_s: float = 300, depends: Optional[List[int]] = None, plan: Optional[List[Dict]] = None) -> int:
    goal = C.clip(goal, 400)
    p = plan if plan is not None else make_plan(goal)
    tid = C.x("INSERT INTO tasks6(goal,status,priority,deadline,plan,state,created,budget_s,depends) VALUES(?,?,?,?,?,?,?,?,?)",
              (goal, "queued", int(priority), deadline, C.jdump(p), C.jdump({}), C.now(), budget_s, C.jdump(depends or [])))
    _log(tid, f"created with {len(p)} step(s): " + " -> ".join(s["tool"] for s in p))
    return tid


# ------------------------------------------------------------------ execution
def _verify(step: Dict, res: Dict) -> Optional[str]:
    """Return None when the result passes its check, otherwise the reason it failed."""
    v = step.get("verify") or {}
    out = str(res.get("output", ""))
    if not res.get("ok"):
        return res.get("error") or "tool reported failure"
    if v.get("nonempty") and not out.strip():
        return "empty result"
    if v.get("contains") and v["contains"].lower() not in out.lower():
        return f"result does not contain {v['contains']!r}"
    if v.get("file_exists"):
        p = res.get("path") or ""
        if not p or not Path(p).exists():
            return "the expected file was not created"
    return None


def _await_approval(tid: int, step: Dict, desc: str) -> bool:
    ev = threading.Event()
    _approvals[tid] = {"event": ev, "granted": False, "step": step["id"], "desc": desc}
    _save(tid, status="awaiting_approval")
    _log(tid, f"waiting for approval: {desc}")
    _cfg["say"](f"Task {tid} needs your approval before it {desc}. Shall I go ahead?")
    ok = ev.wait(timeout=600)
    g = bool(_approvals.pop(tid, {}).get("granted")) if ok else False
    _save(tid, status="running")
    return g and not STOP.is_set()


def _run_step(tid: int, step: Dict, ctx: Dict, deadline_at: float) -> Dict:
    tool = _tools.get(step["tool"])
    if tool is None:
        return {"ok": False, "error": f"unknown tool {step['tool']}"}
    if tool["risk"] == "sensitive" and not step.get("approved"):
        if not _await_approval(tid, step, f"runs '{step['tool']}': {step['desc']}"):
            return {"ok": False, "error": "not approved", "denied": True}
        step["approved"] = True
    args = _fill(step["args"], ctx)
    t0 = time.time()
    holder: Dict = {}

    def target():
        try:
            holder["r"] = tool["fn"](args) or {}
        except Exception as exc:
            holder["r"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    th = threading.Thread(target=target, daemon=True)
    th.start()
    th.join(timeout=max(1.0, min(120.0, deadline_at - time.time())))
    if th.is_alive():
        return {"ok": False, "error": "timed out", "timeout": True}
    r = holder.get("r", {"ok": False, "error": "no result"})
    r["ms"] = int((time.time() - t0) * 1000)
    return r


def _execute_step_with_recovery(tid: int, step: Dict, ctx: Dict, deadline_at: float, seen: set) -> bool:
    """Run -> verify -> on failure change strategy (fallback tool or model-suggested fix) instead of repeating the same attempt."""
    for attempt in range(3):
        if STOP.is_set() or tid in _cancelled:
            step["status"] = "cancelled"
            return False
        step["attempts"] = attempt + 1
        res = _run_step(tid, step, ctx, deadline_at)
        why = _verify(step, res)
        if why is None:
            step["status"], step["result"] = "done", C.clip(str(res.get("output", "")), 1500)
            step["path"] = res.get("path", "")
            step["ms"] = res.get("ms", 0)
            return True
        sig = (step["tool"], json.dumps(step["args"], sort_keys=True, default=str), why)
        _log(tid, f"step {step['id']} ({step['tool']}) failed: {why}", "warn")
        if res.get("denied"):
            step["status"], step["error"] = "skipped", "not approved by the user"
            return False
        if sig in seen:                              # the very same failure again -> loop detected, stop retrying
            step["status"], step["error"] = "failed", f"repeated failure ({why}); stopped retrying"
            _log(tid, "loop detected: same failure twice, giving up on this step", "error")
            return False
        seen.add(sig)
        fb = _tools[step["tool"]].get("fallback")
        if fb and fb in _tools and step["tool"] != fb:
            _log(tid, f"switching strategy: {step['tool']} -> {fb}")
            step["tool"] = fb
            continue
        if res.get("timeout"):
            step["status"], step["error"] = "failed", "timed out"
            return False
        alt = ""
        if C._cfg.get("llm"):
            alt = C.llm(f"A tool step failed. Tool {step['tool']} args {C.jdump(step['args'])[:300]} error: {why}. Reply with a JSON object of corrected args only, or NONE.")
            m = re.search(r"\{.*\}", alt, re.S)
            j = C.jload(m.group(0)) if m else None
            if isinstance(j, dict) and j and j != step["args"]:
                step["args"] = j
                _log(tid, "retrying with corrected arguments")
                continue
        step["status"], step["error"] = "failed", why
        return False
    step["status"], step["error"] = "failed", "retries exhausted"
    return False


def run_task(tid: int) -> Dict:
    """Execute one task to completion (blocking). Safe to call from a worker thread."""
    t = get(tid)
    if not t:
        return {"ok": False, "status": "missing"}
    plan, state = t["plan"], t["state"]
    budget = float(t["budget_s"] or 300)
    t0 = time.time()
    deadline_at = t0 + budget
    _save(tid, status="running", started=t["started"] or C.now(), attempts=int(t["attempts"] or 0) + 1)
    _log(tid, "started")
    ctx = {"goal": t["goal"], "path": state.get("path", "."), "prev": state.get("prev", "")}
    for s in plan:                                   # resume: finished steps feed the context again
        if s.get("status") == "done":
            ctx["prev"] = s.get("result", "")
    seen: set = set()
    ex = ThreadPoolExecutor(max_workers=MAX_PARALLEL)
    try:
        while True:
            if STOP.is_set() or tid in _cancelled:
                break
            pending = [s for s in plan if s["status"] in ("pending", "retry")]
            if not pending:
                break
            if time.time() > deadline_at:
                _log(tid, "time budget exhausted", "error")
                break
            ready = [s for s in pending if all(plan[d]["status"] == "done" for d in s["depends"] if d < len(plan))]
            blocked = [s for s in pending if any(plan[d]["status"] in ("failed", "skipped", "cancelled") for d in s["depends"] if d < len(plan))]
            for s in blocked:
                s["status"], s["error"] = "skipped", "a step it depends on did not complete"
            if not ready:
                if blocked:
                    continue
                break
            futs = []
            for s in ready[:MAX_PARALLEL]:
                s["status"] = "running"
                futs.append(ex.submit(_execute_step_with_recovery, tid, s, dict(ctx), deadline_at, seen))
            wait(futs)
            for s in ready[:MAX_PARALLEL]:
                if s["status"] == "done":
                    ctx["prev"] = s.get("result", "")
            _save(tid, plan=plan, state={"path": ctx["path"], "prev": ctx["prev"]})          # checkpoint after every wave
            _cfg["progress"]({"task": tid, "done": sum(1 for s in plan if s["status"] == "done"), "total": len(plan)})
    finally:
        ex.shutdown(wait=False)
    done = [s for s in plan if s["status"] == "done"]
    failed = [s for s in plan if s["status"] in ("failed", "skipped")]
    if STOP.is_set() or tid in _cancelled:
        status = "cancelled"
    elif len(done) == len(plan):
        status = "done"
    elif done:
        status = "partial"
    else:
        status = "failed"
    for s in plan:
        if s["status"] in ("pending", "running", "retry"):
            s["status"] = "cancelled" if status == "cancelled" else "skipped"
    report = build_report(t["goal"], plan, status)
    _save(tid, plan=plan, state={"path": ctx["path"], "prev": ctx["prev"]}, status=status, ended=C.now(), report=report)
    _log(tid, f"finished: {status}", "info" if status == "done" else "warn")
    try:
        import friday_knowledge5 as kb5
        kb5.record_outcome(t["goal"], status == "done", report[:160])
    except Exception:
        pass
    return {"ok": status == "done", "status": status, "report": report}


def build_report(goal: str, plan: List[Dict], status: str) -> str:
    """Honest reporting: say exactly what was completed, what failed and what was not attempted."""
    done = [s for s in plan if s["status"] == "done"]
    bad = [s for s in plan if s["status"] in ("failed", "skipped", "cancelled")]
    head = {"done": "Completed", "partial": "Partly completed", "failed": "Could not complete", "cancelled": "Cancelled"}.get(status, status)
    out = f"{head}: {goal}. {len(done)} of {len(plan)} step(s) succeeded."
    for s in bad[:3]:
        out += f" Not done: {s['desc']} ({s.get('error', s['status'])})."
    last = next((s for s in reversed(done) if s.get("result")), None)
    if last and status in ("done", "partial"):
        out += " Result: " + C.clip(last["result"], 300)
    return out


# ------------------------------------------------------------------ queue + worker
def queue() -> List[Dict]:
    rows = C.q("SELECT id,goal,status,priority,deadline,created FROM tasks6 WHERE status IN ('queued','running','awaiting_approval','interrupted') ORDER BY priority ASC, COALESCE(deadline, 9e12) ASC, created ASC")
    return [dict(r) for r in rows]


def _next_runnable() -> Optional[int]:
    for r in C.q("SELECT id,depends FROM tasks6 WHERE status='queued' ORDER BY priority ASC, COALESCE(deadline, 9e12) ASC, created ASC"):
        deps = C.jload(r["depends"], []) or []
        if all((get(d) or {}).get("status") == "done" for d in deps):
            return r["id"]
    return None


def _worker():
    while not STOP.is_set():
        tid = _next_runnable()
        if tid is None:
            break
        try:
            res = run_task(tid)
            _cfg["say"](res.get("report", "Task finished.") if res.get("status") != "cancelled" else f"Task {tid} was cancelled.")
        except Exception as exc:
            _log(tid, f"engine error: {exc}\n{traceback.format_exc()[-300:]}", "error")
            _save(tid, status="failed", ended=C.now(), report=f"Engine error: {exc}")
            _cfg["say"](f"Task {tid} hit an internal error: {exc}")
    with _runner["lock"]:
        _runner["thread"] = None


def kick():
    """Start the worker if it is idle."""
    with _runner["lock"]:
        th = _runner["thread"]
        if th is not None and th.is_alive():
            return
        th = threading.Thread(target=_worker, name="Friday6Tasks", daemon=True)
        _runner["thread"] = th
        th.start()


def submit(goal: str, **kw) -> int:
    tid = create(goal, **kw)
    kick()
    return tid


def cancel(tid: int) -> bool:
    t = get(tid)
    if not t or t["status"] in ("done", "failed", "cancelled", "partial"):
        return False
    _cancelled.add(tid)
    ap = _approvals.get(tid)
    if ap:
        ap["event"].set()
    if t["status"] == "queued":
        _save(tid, status="cancelled", ended=C.now())
    _log(tid, "cancel requested", "warn")
    return True


def emergency_stop() -> int:
    """Stops every running task immediately and refuses to start new ones until `resume_engine()`."""
    STOP.set()
    n = 0
    for r in C.q("SELECT id FROM tasks6 WHERE status IN ('queued','running','awaiting_approval')"):
        _cancelled.add(r["id"])
        ap = _approvals.get(r["id"])
        if ap:
            ap["event"].set()
        if get(r["id"])["status"] == "queued":
            _save(r["id"], status="cancelled", ended=C.now())
        n += 1
    return n


def resume_engine():
    STOP.clear()


def approve(granted: bool) -> bool:
    for tid, ap in list(_approvals.items()):
        ap["granted"] = bool(granted)
        ap["event"].set()
        return True
    return False


def awaiting() -> Optional[Dict]:
    for tid, ap in _approvals.items():
        return {"task": tid, "desc": ap["desc"]}
    return None


def recover() -> List[int]:
    """After a crash/restart: anything that was running is marked 'interrupted' (its checkpoint is kept) and can be resumed."""
    ids = [r["id"] for r in C.q("SELECT id FROM tasks6 WHERE status IN ('running','awaiting_approval')")]
    for i in ids:
        t = get(i)
        for s in t["plan"]:
            if s["status"] in ("running", "retry"):
                s["status"] = "pending"
        _save(i, plan=t["plan"], status="interrupted")
        _log(i, "interrupted by shutdown; checkpoint kept", "warn")
    return ids


def resume(tid: int) -> bool:
    t = get(tid)
    if not t or t["status"] not in ("interrupted", "partial", "failed"):
        return False
    for s in t["plan"]:
        if s["status"] in ("failed", "skipped", "cancelled", "running"):
            s["status"], s["attempts"] = "pending", 0
            s.pop("error", None)
    _cancelled.discard(tid)
    _save(tid, plan=t["plan"], status="queued")
    kick()
    return True


def history(n: int = 15) -> List[Dict]:
    return [dict(r) for r in C.q("SELECT id,goal,status,priority,created,ended,report FROM tasks6 ORDER BY id DESC LIMIT ?", (n,))]


def logs(tid: int, n: int = 50) -> List[Dict]:
    return [dict(r) for r in C.q("SELECT ts,level,text FROM task_log6 WHERE task=? ORDER BY id DESC LIMIT ?", (tid, n))][::-1]


def reproduce(tid: int) -> str:
    t = get(tid)
    return C.jdump({"goal": t["goal"], "plan": [{k: s[k] for k in ("tool", "args", "desc", "depends", "verify")} for s in t["plan"]]}) if t else ""


def deadlines_due(within_h: float = 24) -> List[Dict]:
    lim = C.now() + within_h * 3600
    return [dict(r) for r in C.q("SELECT id,goal,deadline FROM tasks6 WHERE deadline IS NOT NULL AND deadline<=? AND status IN ('queued','running','interrupted','partial') ORDER BY deadline", (lim,))]


# ------------------------------------------------------------------ chat / voice commands
def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if re.match(r"^(?:emergency stop|stop everything|halt all tasks|kill (?:all )?tasks|abort everything)$", low):
        n = emergency_stop()
        return f"Emergency stop. {n} task{'s' if n != 1 else ''} halted. Say 'resume tasks' when you want me to carry on."
    if re.match(r"^(?:resume (?:the )?(?:task )?(?:engine|tasks|queue)|restart (?:the )?task queue)$", low):
        resume_engine(); kick()
        return "Task engine resumed."
    aw = awaiting()
    if aw and re.match(r"^(?:yes|yeah|yep|approve|approved|go ahead|do it|proceed|confirm|sure)\b", low):
        approve(True)
        return "Approved. Continuing the task."
    if aw and re.match(r"^(?:no|nope|deny|denied|don'?t|cancel that|stop that|reject)\b", low):
        approve(False)
        return "Understood. I'll skip that step."
    m = re.match(r"^(?:cancel|stop|abort) task (\d+)$", low)
    if m:
        return f"Task {m.group(1)} cancelled." if cancel(int(m.group(1))) else "That task isn't running or queued."
    m = re.match(r"^resume task (\d+)$", low)
    if m:
        return f"Resuming task {m.group(1)}." if resume(int(m.group(1))) else "That task can't be resumed."
    m = re.match(r"^(?:task|status of task) (\d+)(?: status)?$|^how(?:'s| is) task (\d+)(?: going)?$", low)
    if m:
        tt = get(int(m.group(1) or m.group(2)))
        if not tt:
            return "I don't have that task."
        done = sum(1 for s in tt["plan"] if s["status"] == "done")
        return f"Task {tt['id']} is {tt['status']}: {done} of {len(tt['plan'])} steps done. " + (tt["report"] or "")
    if re.match(r"^(?:task status|(?:show |list )?(?:my )?tasks?(?: queue| list)?|what(?:'s| is) in the (?:task )?queue|what are you working on)$", low):
        q = queue()
        if not q:
            return "The task queue is empty."
        return "In the queue: " + "; ".join(f"{r['id']}. {C.clip(r['goal'], 50)} ({r['status']})" for r in q[:6]) + "."
    if re.match(r"^(?:task history|show task history|what have you (?:done|completed))$", low):
        h = history(5)
        return "No tasks yet." if not h else "Recent tasks: " + "; ".join(f"{r['id']}. {C.clip(r['goal'], 45)} — {r['status']}" for r in h) + "."
    m = re.match(r"^(?:plan|show (?:me )?(?:a |the )?plan (?:for|to)) (.+)$", t, re.I) if re.match(r"^(?:show (?:me )?(?:a |the )?plan|plan the steps)", low) else None
    if m:
        p = make_plan(m.group(1))
        return "Here's my plan: " + "; ".join(f"{i + 1}. {s['desc']}" for i, s in enumerate(p)) + "."
    m = re.match(r"^(?:run|start|queue|add|create|do) (?:a |the )?(?:background )?task(?: to| for|:)?\s+(.+)$", t, re.I)
    if m:
        goal = m.group(1)
        pri = 2 if re.search(r"\b(urgent|high priority|asap)\b", goal, re.I) else (8 if re.search(r"\blow priority\b", goal, re.I) else 5)
        dl = C.parse_when(goal) if re.search(r"\b(by|before|due|deadline)\b", goal, re.I) else None
        goal = re.sub(r"\b(?:urgent|high priority|low priority|asap)\b", "", goal, flags=re.I).strip(" ,.")
        tid = submit(goal, priority=pri, deadline=dl)
        n = len(get(tid)["plan"])
        return f"Task {tid} queued with {n} step{'s' if n != 1 else ''}. I'll report when it's finished" + (f", deadline {C.iso(dl)}" if dl else "") + "."
    return None


def ui_snapshot() -> Dict:
    q = queue()
    cur = []
    for r in q:
        t = get(r["id"])
        cur.append({"id": t["id"], "goal": t["goal"], "status": t["status"], "priority": t["priority"],
                    "steps": [{"desc": s["desc"], "tool": s["tool"], "status": s["status"], "error": s.get("error", "")} for s in t["plan"]]})
    return {"queue": cur, "history": [{"id": h["id"], "goal": h["goal"], "status": h["status"], "report": h["report"], "when": C.iso(h["created"])} for h in history(12)],
            "awaiting": awaiting(), "stopped": STOP.is_set(), "tools": tool_names()}
