# FRIDAY V2.3.1 - chat access + clean shutdown (everything else unchanged)

## 1. Chat now has access to every page in the left menu
Before: the chat's AI (Gemini) was never told what FRIDAY can do, so it answered "I have no access to the camera / features".
Now:
- **Truthful capability briefing** is added to every chat prompt (`friday_chat_access.capability_block`). It states the live camera /
  screen-vision state, what she last saw, and (when the question is about them) the live contents of Calendar, Memory, Tasks & Agents,
  Files / Multimedia and Tools, so she can answer "what's on my calendar", "what do you remember about me", "what files have I added".
- **Camera described like a person.** "What do you see?", "can you see me?", "what am I holding?", "describe the room", "look through the camera ..."
  now look through the camera and describe it in natural spoken sentences, the same style she uses for the screen. If the camera is already on
  she uses its newest picture; if it is off she opens it for one picture and closes it again. The Vision page "What I see" panel is updated too.
  While the camera is on, the newest picture is also attached to any other visual question typed in chat.
- **Privacy:** the one camera picture goes to Gemini only when you ask in chat/voice, and only while
  *Settings > Vision > "When I ask FRIDAY what she sees, send that one camera picture to Gemini"* is ticked (default on).
  Untick it and she falls back to the built-in OpenCV description. The older "Allow camera pictures to be sent to Gemini" box is unchanged.
- **Open any page from chat:** "open the calendar page", "go to the finance tab", "show my tasks" ...
- **Calendar from chat:** "add dentist to my calendar tomorrow at 3pm", "schedule a meeting with Ravi on Friday at 10:30am in my calendar".
- **Vision switches in chat:** "turn on / off screen vision", "show / hide the live preview" (camera on/off and the rest already worked).
- "Remember that ...", "forget ...", finance, research tasks, files and everything else keep working exactly as before.

## 2. Microphone / camera are released when FRIDAY closes
Cause: on Windows the app asked `taskkill` to end the Python engine's process tree but killed the parent in the very next line, so
taskkill could not find the tree and the engine (which owns the microphone) could survive. The app's "QUIT" message was also being read by
the engine as a chat message.
Fix:
- `main.js`: taskkill now runs to completion first, then the direct kill; a last-resort kill also runs on Electron exit; the app sends a proper
  `__FRIDAY_QUIT__` message.
- `friday_backend.py`: on `__FRIDAY_QUIT__`, or if the app's pipe disappears (app closed, crashed or killed), the engine stops the camera,
  closes the microphone stream and audio output, then exits. Also registered with `atexit`.

## Files
New: `friday_chat_access.py`, `friday_chat_bridge.js`, `FRIDAY_V231_CHANGES.md`.
Edited (small, additive): `friday_backend.py` (1 lazy-module line, 1 guarded call at the top of process_command, 2 guarded lines in ask_ai,
quit/app-state/EOF handling in the stdin listener), `main.js`, `preload.js` (one `appState` bridge function), `index.html` (one script tag),
`friday_vision_config.py` (one default), `friday_vision_ui.js` (one checkbox), `package.json` (version).
