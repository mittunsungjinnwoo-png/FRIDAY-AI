# FRIDAY 3.1 - fixes on top of 3.0 (nothing else changed)

1. **"Turn off the camera" now really turns it off.**
   - The camera session now waits until the camera is actually released (and releases the handle itself if the worker is stuck) before
     FRIDAY says "Camera off". If it could not release, she says so instead of claiming success.
   - It also closes the Windows Camera app if that is what is holding the camera.
   - More phrasings work: "turn the camera off", "close/stop/shut off/kill the camera", "stop using the webcam"...
   - The chat AI is told it must never claim it switched something on/off by itself.
2. **App not installed -> its website opens in Chrome.** "open claud" (or any app that is not found) opens the site in Chrome
   (spelling-tolerant: claud -> claude.ai, discrod -> discord, chat gpt -> chatgpt.com ...). Unknown names open a Google search for
   "<name> official website".
3. **Python no longer keeps the microphone after the app closes.** The app calls taskkill by full path and sweeps any leftover
   friday_launcher.py engine on exit; the engine also watches its parent app process and releases mic + camera and exits within ~2 s if the
   app disappears for any reason (closed, crashed, killed).
4. **Chat (typed or spoken) reaches the whole left menu.** Open any page ("open memory", "show finance", "open settings in friday");
   read Calendar / Memory / Tasks / Files / Tools ("what's on my calendar today", "what do you remember about me", "what files have I added",
   "what tasks are running", "how are your tools performing"); act: "remember that ...", "forget ...", "mark X as done", "delete X from my calendar",
   "add X to my calendar tomorrow at 3pm" (3.0), "switch to light mode". Vision on/off and finance commands keep working as before.
5. **Speech starts with the reply.** A reply now appears in the chat at the moment its voice is ready to play (not while speech is still
   queued or being generated), so text and speech start together.
6. Renamed to **FRIDAY 3.1** (window title, sidebar, widget, installer, shortcuts, package). Saved data stays in the same folder, nothing is lost.

Not run on real Windows with a microphone/camera: logic and routing were tested headlessly (see chat summary).
