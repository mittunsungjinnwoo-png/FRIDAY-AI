"""Regression checks for the adaptive explicit speech-end VAD."""
from pathlib import Path

p = Path(__file__).with_name("friday_backend.py")
s = p.read_text(encoding="utf-8")

checks = {
    "custom capture exists": "def _capture_until_silence(source):" in s,
    "adaptive live noise floor exists": "global _VAD_NOISE_FLOOR" in s and "baseline_window" in s,
    "waits indefinitely for first speech": "if not speech_started:" in s and "continue" in s[s.index("def _capture_until_silence"):s.index("def listen():")],
    "pre-roll protects first syllable": "pre_roll_chunks" in s and "captured.extend(ring)" in s,
    "speech must persist for five chunks": "loud_streak >= 5" in s,
    "post-speech silence controls completion": "quiet_count >= silence_chunks" in s,
    "maximum length starts after speech": "if speech_chunks >= max_speech_chunks:" in s,
    "no idle max-chunk cutoff": "if chunks_read >= max_chunks:" not in s[s.index("def _capture_until_silence"):s.index("def listen():")],
    "1.25-second default remains": 'silence_seconds = max(0.35, float(os.getenv("FRIDAY_VAD_PAUSE", "1.25")))' in s,
    "existing STT path receives AudioData": 'return sr.AudioData(b"".join(captured), sample_rate, width)' in s,
    "main listen path uses custom capture": "audio = _capture_until_silence(source)" in s,
}

for name, passed in checks.items():
    print(("PASS" if passed else "FAIL") + " - " + name)

if not all(checks.values()):
    raise SystemExit(1)
print("Adaptive VAD static regression: PASS")
