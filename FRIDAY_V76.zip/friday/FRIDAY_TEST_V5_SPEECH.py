import sys, time, threading, os, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import friday_speech5 as sp
sp.CACHE_DIR = __import__("pathlib").Path(tempfile.mkdtemp())
fails=[]
def check(n,c):
    print(("PASS " if c else "FAIL ")+n); (not c) and fails.append(n)
calls=[]; played=[]
def synth(t,v,r): calls.append(t); time.sleep(0.15); return b"ID3"+t.encode()*400
def player(mp3, aborted, gain):
    for _ in range(10):
        if aborted(): played.append("cut"); return
        time.sleep(0.02)
    played.append("full")
sp.synth_override=synth; sp.player_override=player
check("usable", sp.usable())
# parallel prefetch: 3 sentences synth concurrently (~0.15s total, not 0.45)
t0=time.time()
for s in ["One.","Two.","Three."]: sp.prefetch(s,"v","+0%")
for s in ["One.","Two.","Three."]: sp.say(s,"v","+0%")
check("3 sentences ready in < 0.6s incl. playback", time.time()-t0 < 0.9 and played==["full"]*3)
# cache: second time no synth
n=len(calls); sp.say("One.","v","+0%")
check("cache hit avoids synthesis", len(calls)==n)
# interrupt mid-play
th=threading.Thread(target=lambda: sp.say("A long sentence here.","v","+0%")); th.start(); time.sleep(0.25); sp.interrupt(); th.join()
check("interrupt cuts playback", played[-1]=="cut")
before=len(played); sp.say("Ignored after interrupt","v","+0%")
check("further speech skipped until begin_turn", len(played)==before and sp.is_aborted())
sp.begin_turn(); sp.say("Back again.","v","+0%")
check("begin_turn re-enables", played[-1]=="full")
# failures disable then recover
def bad(t,v,r): raise RuntimeError("x")
sp.synth_override=bad
for _ in range(3):
    try: sp.say("zzz "+str(_),"v","+0%")
    except Exception: pass
check("3 failures pause fast path (caller falls back)", not sp.usable())
sys.exit(1 if fails else 0)
