"""V6.0.1 - FRIDAY must never hear or answer something nobody said.  No microphone needed:  python FRIDAY_TEST_V601_NO_PHANTOM_VOICE.py"""
import sys, time, queue, threading
import numpy as np
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
import friday_voice5 as v5

rng = np.random.default_rng(7)
def noise(ms, amp=30): return rng.normal(0, amp, int(16000 * ms / 1000)).astype(np.int16)
def speech(ms, amp=4000):
    n = int(16000 * ms / 1000); t = np.arange(n) / 16000
    s = amp * (np.sin(2*np.pi*180*t) + 0.6*np.sin(2*np.pi*720*t) + 0.3*np.sin(2*np.pi*2400*t)) * (0.6 + 0.4*np.sin(2*np.pi*4*t))
    return (s / 1.9 + rng.normal(0, 40, n)).astype(np.int16)
def frames(sig):
    b = sig.tobytes(); return [b[i:i + v5.FRAME_BYTES] for i in range(0, len(b) - v5.FRAME_BYTES + 1, v5.FRAME_BYTES)]
def run_seg(sig, tts=False):
    seg = v5.Segmenter(); out = []
    for f in frames(sig): out += seg.feed(f, tts_active=tts)
    return out
fails = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: fails.append(name)

# ---- 1. things that are not speech must never become an utterance
def bursts(n, ms=90, gap=700, amp=3500):                       # keyboard / chair / door knocks
    parts = [noise(500)]
    for _ in range(n): parts += [(rng.normal(0, amp, int(16 * ms))).astype(np.int16), noise(gap)]
    return np.concatenate(parts)
check("keyboard / knock bursts -> no utterance", not any(e.kind in ("spec", "final") for e in run_seg(bursts(8))))
hum = (np.sin(2*np.pi*120*np.arange(16000*4)/16000) * 900 + rng.normal(0, 120, 16000*4)).astype(np.int16)
check("steady fan / hum -> no utterance", not any(e.kind == "final" for e in run_seg(hum)))
check("a 100 ms cough / click -> no utterance", not any(e.kind == "final" for e in run_seg(np.concatenate([noise(500), speech(100), noise(900)]))))
check("normal speech is still heard", any(e.kind == "final" for e in run_seg(np.concatenate([noise(500), speech(1100), noise(900)]))))
check("quiet but real speech is still heard", any(e.kind == "final" for e in run_seg(np.concatenate([noise(500), speech(1000, amp=1500), noise(900)]))))

# ---- 2. what the recogniser makes up out of silence
H = v5.looks_like_hallucination
check("'Thanks for watching!' is dropped even when long and loud", H("Thanks for watching!", 3.0, 3000))
check("sound descriptions '[Music]' are dropped", H("[Music]", 2, 900) and H("(applause)", 2, 900))
check("foreign-script text invented from noise is dropped", H("ご視聴ありがとうございました", 2, 900))
check("the priming word list read back is dropped", H("Friday, open, close, search, play, remind me, send a message", 2, 900))
check("repeated phrases are dropped", H("thank you thank you thank you thank you", 2, 900))
check("real commands survive", not any(H(t, 2, 900) for t in ["open chrome", "what's the weather in Colombo", "send a message to mom", "remind me to call dad at five", "open the calendar"]))

# ---- 3. wake word: only when it opens the sentence
check("'see you on Friday' does not wake her", v5.find_wake_standby("see you on Friday")[0] is False)
check("'on Friday we are going out' does not wake her", v5.find_wake_standby("on Friday we are going out")[0] is False)
check("'I love Freddy' does not wake her", v5.find_wake_standby("I love Freddy")[0] is False)
check("'Friday, what time is it' wakes her", v5.find_wake_standby("Friday, what time is it") == (True, "what time is it"))
check("'Hey there Friday open chrome' wakes her", v5.find_wake_standby("Hey there Friday open chrome") == (True, "open chrome"))
check("active: 'what is on my calendar for Friday' keeps the day", v5.find_wake_strict("what is on my calendar for friday") == (False, "what is on my calendar for friday"))
check("active: 'on Friday what is on my calendar' keeps the day", v5.find_wake_strict("on friday what is on my calendar")[0] is False)
v5.configure(wake_anywhere=True)
check("old 'anywhere' rule can be switched back on", v5.find_wake_standby("open chrome friday") == (True, "open chrome"))
v5.configure(wake_anywhere=False)

# ---- 4. echo of her own voice
spoken = ["good evening sir friday 6 0 is online how can i help", "the weather in colombo is 28 degrees"]
check("echo: her own sentence coming back is recognised", v5.echo_like("friday 6.0 is online how can i help", spoken))
check("echo: partial / mis-heard echo is recognised", v5.echo_like("good evening sir friday is online", spoken))
check("echo: a different request is not echo", not v5.echo_like("open the calendar and add a meeting", spoken))

class FakeMic:
    def __init__(s, sig): s.q = queue.Queue(); [s.q.put(f) for f in frames(sig)]
    def read(s, timeout=0.5):
        try: return s.q.get(timeout=0.005)
        except queue.Empty: time.sleep(0.005); return None
    def alive(s): return True
    def close(s): pass

def engine(script, active, speaking_flag, spoken_hist, utter=1000, gap=900, n=None):
    state = {"active": active, "spoken": [], "interrupts": 0, "log": []}
    h = v5.Hooks(is_active=lambda: state["active"], set_active=lambda a, r="": state.update(active=a),
                 speak=lambda t: state["spoken"].append(t), is_speaking=lambda: speaking_flag["v"],
                 interrupt=lambda: state.update(interrupts=state["interrupts"] + 1), emit=lambda l: None,
                 log=lambda m, k="voice": state["log"].append(m), recent_spoken=lambda: spoken_hist)
    it = iter(script)
    def stt(p): time.sleep(0.02); return v5.Recognition(next(it), 0.9, "local")
    n = n or len(script)
    sig = np.concatenate([noise(500)] + [np.concatenate([speech(utter), noise(gap)]) for _ in range(n)])
    eng = v5.VoiceEngine(h, v5.Recognizer(stt, None), mic=FakeMic(sig)); eng.start()
    got = []; t0 = time.time()
    while time.time() - t0 < 2 + n * 1.6 and eng.mic.q.qsize() > 0: time.sleep(0.05)
    time.sleep(1.2)
    while True:
        c = eng.get_command(0.1)
        if not c: break
        got.append(c)
    eng.stop()
    return got, state

# standby: chatter that merely contains the word, then a real wake-up
got, st = engine(["see you on friday then", "friday what time is it"], False, {"v": False}, [], n=2)
check("standby: 'see you on Friday' ignored, 'Friday what time is it' accepted", got == ["what time is it"] and st["active"])

# she is speaking; her own words come back in
sp = {"v": True}
got, st = engine(["friday 6.0 is online how can i help you today"], True, sp, ["good evening sir friday 6 0 is online how can i help you today"], n=1)
check("her own greeting heard back through the mic is NOT a command", got == [])

# she is speaking; the user talks over her
sp = {"v": True}
got, st = engine(["yes sir", "open the calendar page please now", "friday stop"], True, sp, ["here is the long report you asked for about spending"], n=3)
check("talking over her: short fragment ignored, full sentence accepted", got == ["open the calendar page please now"])
check("talking over her: 'Friday stop' interrupts without becoming a command", st["interrupts"] >= 2)

# a lone, weak 'friday' (noise the recogniser mis-heard) must not make her say 'Yes, sir.'
got, st = engine(["friday"], False, {"v": False}, [], utter=140, n=1)
check("a 140 ms blip read as 'Friday' does not wake her", st["spoken"] == [] and st["active"] is False)
got, st = engine(["friday"], False, {"v": False}, [], utter=700, n=1)
check("a clearly spoken 'Friday' wakes her ('Yes, sir.')", st["spoken"] == ["Yes, sir."] and st["active"])

# ---- 5. the conversation window closes by itself
state = {"active": True, "off": []}
h = v5.Hooks(is_active=lambda: state["active"], set_active=lambda a, r="": (state.update(active=a), state["off"].append(r)), is_speaking=lambda: False, emit=lambda l: None)
eng = v5.VoiceEngine(h, v5.Recognizer(None, None), mic=FakeMic(noise(100)))
v5.configure(active_window_s=45)
t = 1000.0; eng._last_activity = t; eng._last_tick = 0.0
eng._tick(t + 1, False)
eng._tick(t + 30, False); still = state["active"]
eng._tick(t + 47, False)
check("conversation stays open inside the window, closes after it", still and not state["active"] and "idle" in state["off"][-1])
state["active"] = True; eng._was_active = False; eng._last_activity = t
v5.configure(active_window_s=0)
eng._tick(t + 5000, False)
check("window 0 = always listening (never closes)", state["active"])
v5.configure(active_window_s=45)
state["active"] = True; eng._last_activity = t; eng._tick(t + 100, True)
check("she is still talking -> window does not close", state["active"])

# ---- 6. settings plumbing
c = v5.configure(sensitivity="strict", active_window_s=90, barge_in=False)
check("configure() applies and clamps", c["sensitivity"] == "strict" and c["active_window_s"] == 90 and c["barge_in"] is False)
v5.configure(sensitivity="bogus"); check("invalid sensitivity ignored", v5.CFG["sensitivity"] == "strict")
v5.configure(sensitivity="normal", barge_in=True)
print("\n%d failure(s)" % len(fails)); sys.exit(1 if fails else 0)
