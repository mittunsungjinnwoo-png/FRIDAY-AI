"""FRIDAY 9.5+ QUALITY GOVERNOR
================================
Additive quality controls for complex requests.

This module deliberately contains NO microphone, VAD, ASR, recognition, or TTS
code. It operates only on structured task plans/results and therefore cannot
change the existing speaking/listening/recognising mechanisms or their timing.

Goals:
- make verification explicit for every compound task;
- preserve source evidence across research -> creation;
- strengthen retry policy without adding network calls;
- keep the fast path fast by doing only small deterministic checks.
"""
from __future__ import annotations

import re
from typing import Any


def _kind(action: str) -> str:
    a = str(action or '').lower()
    if any(x in a for x in ('research', 'collect_reliable_sources', 'verify_important_claims')):
        return 'knowledge'
    if any(x in a for x in ('document', 'generate_document', 'build_document', 'organize_information')):
        return 'artifact'
    if any(x in a for x in ('open', 'launch', 'click', 'type', 'search', 'browser')):
        return 'action'
    if any(x in a for x in ('study', 'quiz', 'questions', 'weak_areas')):
        return 'study'
    return 'general'


def harden_plan(command: str, plan: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return a shallowly copied plan with stronger deterministic contracts."""
    out: list[dict[str, Any]] = []
    for raw in plan or []:
        step = dict(raw)
        inputs = dict(step.get('inputs') or {})
        step['inputs'] = inputs
        step.setdefault('retry_policy', {'max_attempts': 3, 'strategy': 'alternate_then_stop'})
        kind = _kind(step.get('name') or step.get('action'))
        if kind == 'knowledge':
            step.setdefault('verification_level', 'knowledge')
            criteria = dict(step.get('verification_criteria') or {})
            criteria.setdefault('claim', inputs.get('query') or inputs.get('goal_text') or command)
            step['verification_criteria'] = criteria
            inputs.setdefault('evidence_required', True)
            inputs.setdefault('min_independent_sources', 2)
        elif kind == 'artifact':
            step.setdefault('verification_level', 'mechanical_file')
            inputs.setdefault('validate_all_outputs', True)
            inputs.setdefault('source_grounded', bool(re.search(r'\b(research|sources?|according to|investigate)\b', command, re.I)))
        elif kind == 'action':
            step.setdefault('verification_level', 'mechanical_action')
            inputs.setdefault('postcondition_required', True)
        elif kind == 'study':
            step.setdefault('verification_level', 'semantic')
            criteria = dict(step.get('verification_criteria') or {})
            criteria.setdefault('requested', command)
            step['verification_criteria'] = criteria
        out.append(step)
    return out


def score_evidence(result: dict[str, Any]) -> float:
    """Cheap evidence-quality score for telemetry/UI; never claims truth by itself."""
    v = result.get('verification') or result.get('evidence') or {}
    if not isinstance(v, dict):
        return 0.0
    quality = str(v.get('evidence_quality', '')).lower()
    if quality == 'strong':
        return 0.95
    if quality == 'moderate':
        return 0.80
    if quality == 'limited':
        return 0.55
    if result.get('verified') is True:
        return 0.75
    return 0.0


def health() -> dict[str, Any]:
    return {
        'version': '3095.95+',
        'voice_path_touched': False,
        'recognition_path_touched': False,
        'listening_path_touched': False,
        'mode': 'deterministic_additive',
    }
