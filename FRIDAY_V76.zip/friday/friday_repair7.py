"""FRIDAY 7.0 sandboxed coding and repair agent (roadmap #12).

    inspect(path)             syntax check + review findings + test run (read-only; tests run in a subprocess)
    propose(path, old, new)   a minimal, exact-match edit stored as a proposal; nothing on disk changes
    suggest(path, issue)      the model drafts the edit (exact old/new text) - still only a proposal
    test(rid)                 applies the proposal to a throw-away COPY, builds/tests before and after, compares the two
    apply(rid, approved)      needs a passing sandbox test AND your approval; backs the file up first; rolls back by itself if the check fails afterwards
    rollback(rid)             restores the backed-up original

Changes to FRIDAY's own production code always need approval and the `self_update` permission, whatever the autonomy level.
"""
from __future__ import annotations

import difflib
import os
import re
import shutil
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS repairs7(rid INTEGER PRIMARY KEY, ts REAL, path TEXT, title TEXT, old TEXT, new TEXT, diff TEXT, status TEXT, result TEXT, backup TEXT, applied_ts REAL, production INTEGER DEFAULT 0);
""")

_IGNORE = shutil.ignore_patterns("friday_data", "__pycache__", "node_modules", "*.pyc", "dist", ".git", "*.friday.bak", "captures", "trash")
MAX_COPY_MB = 120


def _enter():
    import friday_engineer6 as ENG
    return ENG


def _is_production(path: str) -> bool:
    try:
        Path(path).expanduser().resolve().relative_to(Path(C.HERE).resolve())
        return True
    except Exception:
        return False


def _tree_mb(root: Path) -> float:
    total = 0
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in ("friday_data", "__pycache__", "node_modules", ".git", "dist")]
        for f in fn:
            try:
                total += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
        if total > MAX_COPY_MB * 1024 * 1024:
            break
    return total / 1048576


# ------------------------------------------------------------------ inspect
def inspect(path: str = ".", run_tests: bool = True) -> Dict:
    ENG = _enter()
    root = Path(os.path.expanduser(path or "."))
    if not root.exists():
        return {"ok": False, "output": "", "error": f"{root} does not exist"}
    base = root if root.is_dir() else root.parent
    vb = ENG.verify_build(str(base)) if run_tests else {"ok": None, "compiled": 0, "syntax_errors": [], "tests": "not run"}
    rv = ENG.review(str(base))
    cm = ENG.summarize_map(ENG.code_map(str(base)))
    findings = rv.get("findings", [])[:8]
    lines = [cm, f"Syntax: {vb['compiled']} file(s) compile" + (f"; {len(vb['syntax_errors'])} error(s): " + "; ".join(vb["syntax_errors"][:3]) if vb["syntax_errors"] else "; no syntax errors") + ".", f"Tests: {vb['tests']}."]
    if findings:
        lines.append("Review findings: " + "; ".join(f"{f.get('file', '')}:{f.get('line', '')} {f.get('issue') or f.get('text') or f}" for f in findings[:5]) + ".")
    else:
        lines.append("Review: nothing concerning found by the automatic checks.")
    return {"ok": True, "output": "\n".join(lines), "syntax_errors": vb["syntax_errors"], "tests": vb["tests"], "findings": findings, "production": _is_production(str(base))}


# ------------------------------------------------------------------ proposals
def propose(path: str, old: str, new: str, title: str = "") -> Dict:
    ENG = _enter()
    f = Path(os.path.expanduser(path))
    if not f.is_file():
        return {"ok": False, "error": f"{f} is not a file"}
    r = ENG.propose_edit(str(f), old, new)
    if "diff" not in r:
        return {"ok": False, "error": r.get("error", "could not prepare the edit")}
    rid = C.x("INSERT INTO repairs7(ts,path,title,old,new,diff,status,production) VALUES(?,?,?,?,?,?,?,?)",
              (C.now(), str(f), C.clip(title or f"edit {f.name}", 120), old, new, r["diff"], "proposed" if r["ok"] else "breaks-syntax", int(_is_production(str(f)))))
    K.emit("repair.proposed", {"rid": rid, "path": str(f)})
    return {"ok": r["ok"], "rid": rid, "diff": r["diff"], "error": "" if r["ok"] else "the edit would break the file's syntax"}


def suggest(path: str, issue: str) -> Dict:
    f = Path(os.path.expanduser(path))
    if not f.is_file():
        return {"ok": False, "error": f"{f} is not a file"}
    if not C._cfg.get("llm"):
        return {"ok": False, "error": "no language model is available to draft a fix; give me the exact text to change instead"}
    src = f.read_text("utf-8", "ignore")[:9000]
    out = C.llm("You are fixing one file. Reply with ONLY JSON {\"old\": <exact text copied from the file, unique, as short as possible>, \"new\": <replacement>}.\n"
                f"Problem: {issue}\nFile {f.name}:\n{src}")
    m = re.search(r"\{.*\}", out or "", re.S)
    try:
        import json
        d = json.loads(m.group(0)) if m else {}
        if not d.get("old") or "new" not in d:
            raise ValueError("no edit in the reply")
    except Exception:
        return {"ok": False, "error": "the model did not return a usable edit"}
    return propose(str(f), str(d["old"]), str(d["new"]), title=issue)


def get(rid: int) -> Optional[Dict]:
    r = C.q("SELECT * FROM repairs7 WHERE rid=?", (rid,))
    if not r:
        return None
    d = dict(r[0])
    d["result"] = K.jl(d.get("result"), {})
    return d


def repairs(n: int = 10) -> List[Dict]:
    return [{"rid": r["rid"], "title": r["title"], "path": r["path"], "status": r["status"], "production": bool(r["production"]), "when": C.iso(r["ts"])} for r in C.q("SELECT * FROM repairs7 ORDER BY rid DESC LIMIT ?", (n,))]


def _project_root(f: Path) -> Path:
    """The folder that holds the project (a marker file in the file's folder or up to three parents); otherwise just the file's own folder. Never climbs blindly."""
    cur = f.parent
    for _ in range(4):
        if any((cur / m).exists() for m in (".git", "package.json", "pyproject.toml", "setup.py", "requirements.txt")) or cur == Path(C.HERE):
            return cur if _tree_mb(cur) <= MAX_COPY_MB else f.parent
        if cur.parent == cur:
            break
        cur = cur.parent
    return f.parent


# ------------------------------------------------------------------ sandbox test
def test(rid: int) -> Dict:
    ENG = _enter()
    row = get(rid)
    if not row:
        return {"ok": False, "error": "no such proposal"}
    f = Path(row["path"])
    if not f.is_file():
        return {"ok": False, "error": f"{f} no longer exists"}
    root = _project_root(f)
    src = f.read_text("utf-8", "ignore")
    if src.count(row["old"]) != 1:
        C.x("UPDATE repairs7 SET status='stale' WHERE rid=?", (rid,))
        return {"ok": False, "error": "the file has changed since the proposal, so the exact text no longer matches once"}
    with tempfile.TemporaryDirectory(prefix="friday_repair_") as tmp:
        copy = Path(tmp) / "work"
        shutil.copytree(root, copy, ignore=_IGNORE)
        before = ENG.verify_build(str(copy))
        target = copy / f.relative_to(root)
        target.write_text(src.replace(row["old"], row["new"]), "utf-8")
        for pc in list(copy.rglob("__pycache__")):          # a stale .pyc (same size, same second) would make the "after" run test the OLD code
            shutil.rmtree(pc, ignore_errors=True)
        after = ENG.verify_build(str(copy))
    b_err, a_err = len(before["syntax_errors"]), len(after["syntax_errors"])
    tb, ta = _count_passed(before["tests"]), _count_passed(after["tests"])
    better_or_same = a_err <= b_err and (ta >= tb)
    verdict = ("improves things: " if a_err < b_err or ta > tb else "does not make anything worse: ") if better_or_same else "makes things worse: "
    res = {"ok": better_or_same, "before": {"syntax_errors": b_err, "tests": before["tests"]}, "after": {"syntax_errors": a_err, "tests": after["tests"]}, "new_errors": after["syntax_errors"][:3],
           "summary": f"On a copy, the change {verdict}syntax errors {b_err} to {a_err}; tests '{before['tests']}' to '{after['tests']}'."}
    C.x("UPDATE repairs7 SET status=?, result=? WHERE rid=?", ("tested-ok" if better_or_same else "tested-failed", K.jd(res), rid))
    return res


def _count_passed(text: str) -> int:
    m = re.search(r"(\d+) of (\d+) test", str(text))
    return int(m.group(1)) if m else 0


# ------------------------------------------------------------------ apply / rollback
def _backup_dir() -> Path:
    d = C.DATA_DIR / "repair_backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def apply(rid: int, approved: bool = False) -> Dict:
    ENG = _enter()
    row = get(rid)
    if not row:
        return {"ok": False, "error": "no such proposal"}
    if not approved:
        return {"ok": False, "error": "not approved", "needs_approval": True}
    if row["status"] != "tested-ok":
        return {"ok": False, "error": "a change must pass the sandbox test before it can be applied"}
    f = Path(row["path"])
    if row["production"]:
        try:
            import friday_security6 as SEC
            blocked = SEC.require("self_update", "change FRIDAY's own code")
            if blocked:
                return {"ok": False, "error": blocked}
        except Exception:
            return {"ok": False, "error": "the self_update permission could not be checked, so I won't change my own code"}
    src = f.read_text("utf-8", "ignore")
    if src.count(row["old"]) != 1:
        C.x("UPDATE repairs7 SET status='stale' WHERE rid=?", (rid,))
        return {"ok": False, "error": "the file has changed since the test"}
    bk = _backup_dir() / f"{rid}-{f.name}"
    shutil.copy2(f, bk)
    f.write_text(src.replace(row["old"], row["new"]), "utf-8")
    ok = True
    if f.suffix == ".py":
        try:
            compile(f.read_text("utf-8", "ignore"), str(f), "exec")
        except SyntaxError:
            ok = False
    if ok and row["production"]:
        ok = bool(ENG.verify_build(str(C.HERE))["ok"])
    if not ok:
        shutil.copy2(bk, f)
        C.x("UPDATE repairs7 SET status='rolled-back', backup=? WHERE rid=?", (str(bk), rid))
        _audit("repair-rolled-back", row["title"], "failed")
        return {"ok": False, "error": "the check after the change failed, so I restored the original file", "rolled_back": True}
    C.x("UPDATE repairs7 SET status='applied', backup=?, applied_ts=? WHERE rid=?", (str(bk), C.now(), rid))
    _audit("repair-applied", f"{row['title']} ({f.name})", "ok")
    return {"ok": True, "backup": str(bk), "path": str(f), "output": f"Applied. The original is saved at {bk} - say 'roll back repair {rid}' to restore it."}


def rollback(rid: int) -> Dict:
    row = get(rid)
    if not row or not row.get("backup") or not Path(row["backup"]).exists():
        return {"ok": False, "error": "there is no backup for that change"}
    shutil.copy2(row["backup"], row["path"])
    C.x("UPDATE repairs7 SET status='rolled-back' WHERE rid=?", (rid,))
    _audit("repair-rolled-back", row["title"], "user")
    return {"ok": True, "output": f"Restored {Path(row['path']).name} from the backup."}


def _audit(action: str, detail: str, outcome: str):
    try:
        import friday_security6 as SEC
        SEC.audit("repair", action, detail, outcome)
    except Exception:
        pass


# ------------------------------------------------------------------ registry tools
def install(registry):
    def t_inspect(a):
        return inspect(str(a.get("path", ".")), run_tests=bool(a.get("run_tests", True)))

    def t_propose(a):
        if a.get("issue") and not a.get("old"):
            r = suggest(str(a.get("path", "")), str(a["issue"]))
        else:
            r = propose(str(a.get("path", "")), str(a.get("old", "")), str(a.get("new", "")), str(a.get("title", "")))
        return {"ok": bool(r.get("ok")), "output": (f"Proposal {r['rid']} saved. Nothing has changed.\n{r.get('diff', '')[:1200]}" if r.get("rid") else ""), "error": r.get("error", ""), "rid": r.get("rid")}

    def t_test(a):
        r = test(int(a.get("rid", 0)))
        return {"ok": bool(r.get("ok")) or bool(r.get("summary")), "output": r.get("summary", ""), "error": r.get("error", "") if not r.get("summary") else "", "passed": r.get("ok")}

    def t_apply(a):
        r = apply(int(a.get("rid", 0)), approved=bool(a.get("approved")))
        return {"ok": bool(r.get("ok")), "output": r.get("output", ""), "error": r.get("error", ""), "path": r.get("path", "")}

    def t_rollback(a):
        r = rollback(int(a.get("rid", 0)))
        return {"ok": bool(r.get("ok")), "output": r.get("output", ""), "error": r.get("error", "")}

    registry.register("repair_inspect", t_inspect, risk="safe", desc="inspect code: syntax, review findings, tests (read-only)", post={"nonempty": True}, timeout=150.0, agent="coding")
    registry.register("repair_propose", t_propose, risk="routine", desc="store a minimal exact-match code edit as a proposal (nothing changes)", timeout=60.0, agent="coding")
    registry.register("repair_test", t_test, risk="sensitive", desc="apply a proposal to a throw-away copy, build and test before/after", post={"nonempty": True}, timeout=240.0, agent="coding")
    registry.register("apply_patch", t_apply, risk="irreversible", desc="apply a tested proposal (needs your approval; backs up; auto rollback)", idempotent=False, timeout=240.0, agent="coding")
    registry.register("repair_rollback", t_rollback, risk="routine", desc="restore the backed-up original of an applied repair", idempotent=False, timeout=30.0, agent="coding")


# ------------------------------------------------------------------ chat
_pending: Dict = {}


def handle(command: str) -> Optional[str]:
    raw = K.strip_wake(command).strip()
    t = raw.lower().strip(" .!?")
    m = re.match(r"^(?:inspect|check|examine)\s+(?:my\s+|the\s+)?(?:code|project|codebase|repo)(?:\s+(?:in|at|for|of)\s+(.+))?$", t)
    if m:
        r = inspect(m.group(1) or ".")
        return r["output"].replace("\n", " ") if r["ok"] else r["error"].capitalize() + "."
    m = re.match(r"^(?:propose|draft|suggest)\s+(?:a\s+)?(?:fix|repair)\s+(?:in|for)\s+(\S+?)\s*[:,-]\s*(.+)$", raw, re.I)
    if m:
        r = suggest(m.group(1), m.group(2))
        return f"Repair {r['rid']} is drafted. Nothing has changed. Say 'test repair {r['rid']}' and I'll try it on a copy." if r.get("rid") else (r.get("error", "I couldn't draft that").capitalize() + ".")
    m = re.match(r"^replace\s+[\"“'](.+?)[\"”']\s+with\s+[\"“'](.*?)[\"”']\s+in\s+(\S+)$", raw, re.I)
    if m:
        r = propose(m.group(3), m.group(1), m.group(2))
        return f"Repair {r['rid']} is drafted. Nothing has changed. Say 'test repair {r['rid']}' to try it on a copy." if r.get("rid") else (r.get("error", "").capitalize() + ".")
    m = re.match(r"^test repair (\d+)$", t)
    if m:
        r = test(int(m.group(1)))
        return (r.get("summary") or r.get("error", "").capitalize() + ".") + (" I haven't touched the real files." if r.get("summary") else "")
    m = re.match(r"^(?:apply|do) repair (\d+)$", t)
    if m:
        row = get(int(m.group(1)))
        if not row:
            return "I don't have that repair."
        if row["status"] != "tested-ok":
            return "That repair hasn't passed the sandbox test yet. Say 'test repair " + m.group(1) + "' first."
        _pending["rid"] = int(m.group(1))
        return ("That changes FRIDAY's own code. " if row["production"] else "") + f"I'll back up {Path(row['path']).name} first and restore it automatically if the check fails. Say 'confirm repair' to go ahead."
    if t == "confirm repair" and "rid" in _pending:
        r = apply(_pending.pop("rid"), approved=True)
        return r.get("output") if r.get("ok") else r.get("error", "").capitalize() + "."
    m = re.match(r"^(?:roll ?back|undo|revert) repair (\d+)$", t)
    if m:
        r = rollback(int(m.group(1)))
        return r.get("output") if r.get("ok") else r.get("error", "").capitalize() + "."
    if re.match(r"^(?:list|show) (?:my )?repairs$", t):
        rs = repairs(5)
        return ("Repairs: " + "; ".join(f"{r['rid']} {r['title'][:40]} ({r['status']})" for r in rs) + ".") if rs else "No repairs on record."
    return None


def ui_snapshot() -> Dict:
    return {"repairs": repairs(10)}


def handle_ui(req: Dict) -> Optional[Dict]:
    a = req.get("action")
    if a == "repair_test":
        return test(int(req.get("rid", 0)))
    if a == "repair_apply":
        return apply(int(req.get("rid", 0)), approved=bool(req.get("approved")))
    if a == "repair_rollback":
        return rollback(int(req.get("rid", 0)))
    return None
