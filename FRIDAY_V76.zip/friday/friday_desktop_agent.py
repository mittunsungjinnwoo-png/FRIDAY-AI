"""
FRIDAY DESKTOP / COMPUTER AGENT
================================
Additive control layer for the existing FRIDAY build.

This module intentionally uses explicit, bounded operations rather than
arbitrary shell execution. It provides the missing practical desktop tools
from the research specification: mouse/keyboard, windows/apps, files,
browser, media, system information, notifications and reversible actions.

Every mutating file operation is journaled so "undo" can reverse operations
where Windows/filesystem semantics make that safe. Destructive operations
still require the confirmation gate in the main backend.
"""
from __future__ import annotations
import ctypes, datetime as dt, json, os, platform, re, shutil, subprocess, time, webbrowser, threading
from pathlib import Path
from typing import Any

# V2044: shared, typo/filler-tolerant search-query extraction. Optional so this module keeps
# working standalone (as it did before) if the sibling module is ever missing.
try:
    import friday_nlu as _nlu
except Exception:
    _nlu = None
try:
    import friday_app_launcher as _app_launcher
except Exception:
    _app_launcher = None

ROOT = Path(__file__).resolve().parent
JOURNAL = ROOT / "friday_undo_journal.json"
DOWNLOADS = Path.home() / "Downloads"

def _load():
    try:
        return json.loads(JOURNAL.read_text(encoding="utf-8"))
    except Exception:
        return []
def _save(v):
    tmp=JOURNAL.with_suffix(".tmp")
    tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding="utf-8")
    os.replace(tmp,JOURNAL)

def _record(action, **data):
    j=_load()
    j.append({"id":f"U{int(time.time()*1000)}","ts":dt.datetime.now().isoformat(timespec="seconds"),
              "action":action,**data})
    _save(j[-100:])

def _windows():
    return platform.system()=="Windows"

def _pyautogui():
    import pyautogui
    pyautogui.PAUSE=0.06
    pyautogui.FAILSAFE=True
    return pyautogui

# ---------- system ----------
def system_info()->dict[str,Any]:
    out={"platform":platform.platform(),"computer":platform.node(),
         "python":platform.python_version()}
    try:
        import psutil
        out.update(cpu_percent=psutil.cpu_percent(interval=0.15),
                   cpu_count=psutil.cpu_count(),
                   ram_percent=psutil.virtual_memory().percent,
                   ram_available_gb=round(psutil.virtual_memory().available/2**30,2),
                   disk_free_gb=round(psutil.disk_usage(str(Path.home().anchor or Path.home())).free/2**30,2),
                   battery_percent=(psutil.sensors_battery().percent if psutil.sensors_battery() else None),
                   battery_plugged=(psutil.sensors_battery().power_plugged if psutil.sensors_battery() else None),
                   processes=len(psutil.pids()))
        try: out["network"]=bool(psutil.net_if_stats())
        except Exception: pass
    except Exception as e: out["psutil_error"]=str(e)
    return out

def running_apps()->list[dict[str,Any]]:
    try:
        import psutil
        result=[]
        for p in psutil.process_iter(["pid","name","status"]):
            try: result.append(p.info)
            except Exception: pass
        return sorted(result,key=lambda x:(x.get("name") or "").lower())
    except Exception:return []

# ---------- keyboard/mouse ----------
def computer(command:str)->dict[str,Any]:
    """Execute a bounded desktop action and independently observe the result.

    `pyautogui` exceptions prove only that the API call did not throw. They do
    not prove that the intended UI state changed, so every action now gets a
    post-action observation. `ok` means execution + evidence; `executed` means
    the low-level call returned without raising.
    """
    p=_pyautogui(); c=command.strip(); low=c.lower()
    try:
        from friday_truth_verifier import snapshot, compare
    except Exception:
        snapshot=compare=None

    def run_action(action, fn, *, expected_text=None, expected_window=None, settle=.25):
        before=snapshot() if snapshot else None
        try:
            fn()
            # Give Windows/UIA a short bounded settle period before observing.
            # The previous implementation accepted the screenshot immediately,
            # which could report a successful click as unverified even though the
            # target window was still repainting.
            if settle:
                time.sleep(min(0.60, max(0.0, float(settle))))
        except Exception as exc:
            return {"ok":False,"executed":False,"action":action,"error":str(exc)}
        after=snapshot() if snapshot else None
        evidence=compare(before,after,expected_text=expected_text,expected_window=expected_window) if before and after and compare else {}
        verified=bool(evidence.get("verified") or evidence.get("cursor_changed"))
        return {"ok":verified,"executed":True,"action":action,"verified":verified,"evidence":evidence,
                **({"error":"action_executed_but_result_not_verified"} if not verified else {})}

    m=re.search(r"\bclick\s+(?:at\s+)?(\d{1,5})[,\s]+(\d{1,5})\b",low)
    if m:
        x,y=int(m.group(1)),int(m.group(2))
        return run_action("click",lambda:p.click(x,y),settle=.3)
    if re.search(r"\bdouble[- ]click\b",low):
        return run_action("double_click",p.doubleClick,settle=.35)
    if re.search(r"\bright[- ]click\b",low):
        return run_action("right_click",p.rightClick,settle=.3)
    if re.search(r"\bmiddle[- ]click\b",low):
        return run_action("middle_click",p.middleClick,settle=.3)
    m=re.search(r"\b(?:move|move cursor)\s+(?:to\s+)?(\d{1,5})[,\s]+(\d{1,5})\b",low)
    if m:
        x,y=int(m.group(1)),int(m.group(2))
        before=p.position();
        try:p.moveTo(x,y,duration=.15)
        except Exception as e:return {"ok":False,"executed":False,"action":"move","error":str(e)}
        pos=p.position(); verified=(int(pos.x)==x and int(pos.y)==y)
        return {"ok":verified,"executed":True,"action":"move","verified":verified,"position":[int(pos.x),int(pos.y)]}
    m=re.search(r"\b(?:type|write)\s+(.+)$",c,re.I)
    if m:
        text=m.group(1)
        # Screenshot/OCR evidence is best-effort; if OCR is unavailable we
        # still require an observable UI change instead of blindly claiming success.
        return run_action("type",lambda:p.write(text,interval=.002),expected_text=text,settle=.35)
    if re.search(r"\b(select all|select everything)\b",low):
        return run_action("select_all",lambda:p.hotkey("ctrl","a"),settle=.25)
    if re.search(r"\b(copy|copy that)\b",low):
        return run_action("copy",lambda:p.hotkey("ctrl","c"),settle=.25)
    if re.search(r"\bcut\b",low):
        return run_action("cut",lambda:p.hotkey("ctrl","x"),settle=.25)
    if re.search(r"\bpaste\b",low):
        return run_action("paste",lambda:p.hotkey("ctrl","v"),settle=.3)
    if re.search(r"\bundo\b",low):
        return run_action("undo",lambda:p.hotkey("ctrl","z"),settle=.3)
    if re.search(r"\bredo\b",low):
        return run_action("redo",lambda:p.hotkey("ctrl","y"),settle=.3)
    m=re.search(r"\bscroll\s+(up|down)(?:\s+(\d+))?",low)
    if m:
        n=int(m.group(2) or 5)*(-1 if m.group(1)=="down" else 1)
        return run_action("scroll",lambda:p.scroll(n),settle=.45)
    return {"ok":False,"executed":False,"error":"no_unambiguous_computer_action"}

# ---------- applications ----------
APP_ALIASES={
 "chrome":"chrome.exe","google chrome":"chrome.exe","edge":"msedge.exe",
 "microsoft edge":"msedge.exe","notepad":"notepad.exe","calculator":"calc.exe",
 "calc":"calc.exe","paint":"mspaint.exe","explorer":"explorer.exe",
 "file explorer":"explorer.exe","powershell":"powershell.exe","terminal":"wt.exe",
 "command prompt":"cmd.exe","cmd":"cmd.exe","whatsapp":"WhatsApp.exe","vscode":"code.exe","vs code":"code.exe",
 "wps":"wps.exe","wps office":"wps.exe","kingsoft wps":"wps.exe",
 "wps writer":"wps.exe","wps spreadsheet":"et.exe","wps presentation":"wpp.exe",
}
def launch_app(name:str)->dict[str,Any]:
    n=name.strip().lower()
    # V2044 FIX: this dispatch is reached from several older regex routes (see friday_v96_runtime's
    # legacy `d.handle()` branch) that capture "everything after open/launch/start" verbatim, so a
    # spoken "open vs code please" arrived here as the literal string "vs code please" and an exact
    # APP_ALIASES lookup always missed. Strip the same harmless trailing filler friday_nlu strips
    # elsewhere before the lookup, so the original alias list keeps matching as intended.
    if _nlu is not None:
        try:
            n = _nlu._OPEN_TAIL_RE.sub("", n).strip() or n            # noqa: SLF001 (shared regex, not a new dependency)
        except Exception:
            pass
    exe=APP_ALIASES.get(n)
    if not exe:
        if re.fullmatch(r"[A-Za-z0-9_.-]{1,80}\.exe",n): exe=n
        elif _app_launcher is not None:
            # Not one of the small set of hard-coded apps: hand off to the universal,
            # installed-app index (Start Menu, Store apps, App Paths, Windows tools/settings,
            # typo-tolerant matching) instead of just reporting failure.
            try:
                result = _app_launcher.launch(n)
            except Exception as error:
                result = {"ok": False, "error": f"launcher_error: {error}"}
            result.setdefault("application", name)
            return result
        else:
            return {"ok":False,"error":"unknown_application","application":name}
    # Already open? "open X" then means "go back to X": bring its existing window to the front
    # (restoring it if minimised) and report success only once it is really in front.
    if _windows():
        try:
            import friday_system_control as _sc
            _stem=exe.lower()[:-4] if exe.lower().endswith(".exe") else exe.lower()
            _r=_sc.focus_application(n,matcher=lambda _t,_p:_p==_stem)
            if _r.get("ok"):
                return {"ok":True,"executed":True,"application":name,"executable":exe,"verified":True,
                        "active_window":_r.get("focused",""),"evidence":"brought existing window to front"}
        except Exception:
            pass
    try:
        import psutil
        before={p.pid for p in psutil.process_iter(["pid","name"]) if (p.info.get("name") or "").lower()==exe.lower()}
    except Exception:
        before=set()
    launched=False
    # WhatsApp/WPS are frequently packaged/installed without a PATH-visible
    # executable.  For those apps, deliberately use the Windows Search path
    # first and verify the resulting foreground window.  This avoids the old
    # false-positive where an existing process made FRIDAY claim success even
    # though no new window was opened.
    search_names = {
        "whatsapp": "WhatsApp",
        "wps": "WPS Office",
        "wps office": "WPS Office",
        "kingsoft wps": "WPS Office",
        "wps writer": "WPS Writer",
        "wps spreadsheet": "WPS Spreadsheets",
        "wps presentation": "WPS Presentation",
    }
    if n in search_names and _windows():
        try:
            p=_pyautogui()
            p.hotkey("win","s"); time.sleep(.8)
            p.write(search_names[n], interval=.035); time.sleep(1.2)
            p.press("enter")
            launched=True
        except Exception:
            launched=False
    else:
        try:
            proc=subprocess.Popen([exe],shell=False)
            time.sleep(1.5)
            launched=(proc.poll() is None)
        except Exception:
            launched=False
        if not launched and _windows():
            try:
                p=_pyautogui()
                p.hotkey("win","s"); time.sleep(.7)
                p.write(n, interval=.03); time.sleep(1.0); p.press("enter")
                launched=True
            except Exception:
                launched=False
    # V2048 FIX: heavier applications (office suites in particular - WPS is the
    # reported case, but this also covers e.g. Adobe/Photoshop-style apps) can
    # take several seconds to actually paint a window after Enter is pressed.
    # The old code checked the foreground window exactly once, immediately -
    # often while the OS search UI or the previous window was still focused -
    # so FRIDAY reported "could not complete that safely" for launches that
    # were, in fact, still in the process of opening. Poll for a few seconds
    # instead of judging on a single instant snapshot.
    SLOW_LAUNCH_TOKENS = ("wps", "kingsoft", "office", "photoshop", "illustrator",
                          "premiere", "acrobat", "steam", "outlook", "onenote")
    is_slow_app = n in search_names or any(t in n for t in SLOW_LAUNCH_TOKENS)
    poll_timeout = 10.0 if is_slow_app else 4.0
    poll_interval = 0.5
    deadline = time.time() + poll_timeout
    process_alive = False
    window_match = False
    title = ""
    aliases=[n, exe.removesuffix('.exe').lower()]
    while True:
        try:
            after={p.pid for p in psutil.process_iter(["pid","name"]) if (p.info.get("name") or "").lower()==exe.lower()}
            process_alive=bool(after - before) or bool(after)
        except Exception:
            process_alive=False
        title=active_window() if _windows() else ""
        title_low=title.lower()
        if n in {"wps","wps office","kingsoft wps","wps writer","wps spreadsheet","wps presentation"}:
            window_match = any(x in title_low for x in ("wps", "kingsoft", "writer", "spreadsheets", "presentation"))
        else:
            window_match=any(a and a in title_low for a in aliases)
        # For packaged apps opened via Windows Search, a pre-existing process is
        # not proof this command opened the requested application - require a
        # matching foreground window. Other apps accept either signal.
        verified = bool(window_match) if n in search_names else bool(process_alive or window_match)
        if verified or time.time() >= deadline:
            break
        time.sleep(poll_interval)
    return {"ok":verified,"executed":launched,"application":name,"executable":exe,
            "verified":verified,"active_window":title,
            **({} if verified else {"error":"application_open_not_verified"})}

def active_window()->str:
    if not _windows():return ""
    try:
        u=ctypes.windll.user32; n=u.GetWindowTextLengthW(u.GetForegroundWindow())
        b=ctypes.create_unicode_buffer(n+1); u.GetWindowTextW(u.GetForegroundWindow(),b,n+1)
        return b.value.strip()
    except Exception:return ""

def window_action(command:str)->dict[str,Any]:
    p=_pyautogui(); low=command.lower()
    if re.search(r"\bminimi[sz]e\b",low):
        # Real window minimise (Win32) verified with IsIconic; the old Alt+Space,N keystroke was
        # sent to whatever was in front and always reported success.
        try:
            import friday_system_control as _sc
            m=re.search(r"\bminimi[sz]e\s+(?:the\s+|my\s+)?(.+)$",low)
            tgt=re.sub(r"\s+(?:for me|please|now|window|app|application)\s*$","",(m.group(1) if m else "").strip(" ,.!?"))
            if tgt in ("","this","it","that","current"): tgt=""
            r=_sc.minimize_application(tgt)
            return {"ok":bool(r.get("ok")),"executed":bool(r.get("found")),"action":"minimize","verified":bool(r.get("ok")),
                    **({} if r.get("ok") else {"error":r.get("error","minimize_not_verified")})}
        except Exception as e:
            return {"ok":False,"executed":False,"action":"minimize","verified":False,"error":str(e)}
    if re.search(r"\bmaximi[sz]e\b",low):
        # V7.0: real Win32 maximise confirmed with IsZoomed; the Alt+Space,X keystroke below is only the last resort.
        try:
            import friday_system_control as _sc
            m=re.search(r"\bmaximi[sz]e\s+(?:the\s+|my\s+)?(.+)$",low)
            tgt=re.sub(r"\s+(?:for me|please|now|window|app|application)\s*$","",(m.group(1) if m else "").strip(" ,.!?"))
            if tgt in ("","this","it","that","current"): tgt=""
            r=_sc.maximize_application(tgt)
            if r.get("found"):
                return {"ok":bool(r.get("ok")),"executed":True,"action":"maximize","verified":bool(r.get("ok")),
                        **({} if r.get("ok") else {"error":"maximize_not_verified"})}
        except Exception:
            pass
        before=active_window(); p.hotkey("alt","space"); p.press("x"); time.sleep(.25); after=active_window(); return {"ok":bool(after),"executed":True,"action":"maximize","verified":bool(after)}
    if re.search(r"\brestore\b",low):
        try:
            import friday_system_control as _sc
            m=re.search(r"\brestore\s+(?:down\s+)?(?:the\s+|my\s+)?(.+)$",low)
            tgt=re.sub(r"\s+(?:for me|please|now|window|app|application)\s*$","",(m.group(1) if m else "").strip(" ,.!?"))
            if tgt in ("","this","it","that","current"): tgt=""
            r=_sc.restore_down_application(tgt)
            if r.get("found"):
                return {"ok":bool(r.get("ok")),"executed":True,"action":"restore","verified":bool(r.get("ok")),
                        **({} if r.get("ok") else {"error":"restore_not_verified"})}
        except Exception:
            pass
        before=active_window(); p.hotkey("alt","space"); p.press("r"); time.sleep(.25); after=active_window(); return {"ok":bool(after),"executed":True,"action":"restore","verified":bool(after)}
    if re.search(r"\bswitch\b|\bnext app\b|\bnext window\b",low):
        before=active_window(); p.hotkey("alt","tab"); time.sleep(.3); after=active_window(); verified=bool(after and after!=before); return {"ok":verified,"executed":True,"action":"switch","verified":verified,"before":before,"after":after}
    return {"ok":False,"error":"unsupported_window_action"}

# ---------- filesystem ----------
def _safe_path(raw:str)->Path:
    p=Path(os.path.expandvars(os.path.expanduser(raw.strip().strip('"')))).resolve()
    return p
def _extract_path(text:str):
    m=re.search(r'(?:"([^"]+)"|([A-Za-z]:\\[^"]+)|([^\s]+))',text)
    return (m.group(1) or m.group(2) or m.group(3)) if m else None

def search_files(query:str, where:Path|None=None, limit=50)->list[str]:
    # V7.0: ranked search over the indexed folders (milliseconds); the old walk is only used for an explicit folder
    # or when the index is unavailable.
    try:
        import friday_filesearch7 as _fs
        _hits=_fs.find_paths(query, limit=limit, where=str(where) if where else None)
        if _hits or where is None:
            return _hits
    except Exception:
        pass
    base=where or Path.home()
    q=query.lower()
    hits=[]
    try:
        for p in base.rglob("*"):
            if len(hits)>=limit:break
            if p.is_file() and q in p.name.lower():hits.append(str(p))
    except Exception:pass
    return hits


def recent_files(days: int = 2, suffix: str|None = None, limit: int = 30)->list[str]:
    cutoff=time.time()-days*86400
    hits=[]
    roots=[DOWNLOADS, Path.home()/"Desktop", Path.home()/"Documents"]
    for base in roots:
        if not base.exists(): continue
        try:
            for f in base.rglob("*"):
                if f.is_file() and f.stat().st_mtime>=cutoff and (not suffix or f.suffix.lower()==suffix.lower()):
                    hits.append((f.stat().st_mtime,str(f)))
        except Exception: pass
    return [p for _,p in sorted(hits,reverse=True)[:limit]]

def duplicate_files(where:Path|None=None, limit=50)->list[list[str]]:
    groups={}
    base=where or Path.home()
    try:
        for f in base.rglob("*"):
            if f.is_file() and f.stat().st_size < 500_000_000:
                key=(f.stat().st_size)
                groups.setdefault(key,[]).append(f)
    except Exception: pass
    out=[]
    import hashlib
    for size,files in groups.items():
        if len(files)<2: continue
        hashes={}
        for f in files:
            try:
                h=hashlib.sha256(f.read_bytes()).hexdigest()
                hashes.setdefault(h,[]).append(str(f))
            except Exception: pass
        out.extend(v for v in hashes.values() if len(v)>1)
        if len(out)>=limit: break
    return out[:limit]

def open_file(path:str)->dict[str,Any]:
    p=_safe_path(path)
    if not p.exists(): return {"ok":False,"error":"file_not_found","path":str(p)}
    try:
        before=Path(str(p))
        if _windows(): os.startfile(str(p))
        else: subprocess.Popen(["xdg-open",str(p)])
        time.sleep(.8)
        title=""
        try:
            from friday_truth_verifier import active_window_title
            title=active_window_title()
        except Exception: pass
        # A file opening should normally produce an application window. Do not
        # equate startfile returning with successful opening.
        verified=bool(title)
        return {"ok":verified,"executed":True,"action":"open_file","path":str(p),"active_window":title,"verified":verified,
                **({} if verified else {"error":"file_open_not_independently_verified"})}
    except Exception as e:return {"ok":False,"executed":False,"error":str(e)}

def archive_action(command:str)->dict[str,Any]:
    low=command.lower()
    m=re.search(r"\b(?:extract|unzip)\s+(.+?)(?:\s+to\s+(.+))?$",command,re.I)
    if m:
        src=_safe_path(m.group(1)); dst=_safe_path(m.group(2)) if m.group(2) else src.with_suffix("")
        if not src.exists(): return {"ok":False,"error":"archive_not_found"}
        shutil.unpack_archive(str(src),str(dst)); verified=dst.exists() and any(dst.rglob("*")) if dst.is_dir() else dst.exists(); return {"ok":verified,"executed":True,"action":"extract","path":str(dst),"verified":verified,**({} if verified else {"error":"extract_output_not_verified"})}
    m=re.search(r"\bcompress\s+(.+?)\s+to\s+(.+)$",command,re.I)
    if m:
        src=_safe_path(m.group(1)); out=_safe_path(m.group(2))
        base=str(out.with_suffix(""))
        fmt=out.suffix.lstrip(".") or "zip"
        shutil.make_archive(base,fmt,str(src)); result_path=Path(out if out.suffix else out.with_suffix(".zip")); verified=result_path.exists() and result_path.stat().st_size>0; return {"ok":verified,"executed":True,"action":"compress","path":str(result_path),"verified":verified,**({} if verified else {"error":"archive_output_not_verified"})}
    return {"ok":False,"error":"no_archive_action"}

def file_action(command:str)->dict[str,Any]:
    low=command.lower()
    if re.search(r"\b(?:find|locate)\s+(?:the\s+)?(?:pdf|document|file)\b.*\b(?:yesterday|recently|today)\b",low):
        suffix=".pdf" if "pdf" in low else None
        days=2 if "yesterday" in low else 1
        return {"ok":True,"action":"recent_search","results":recent_files(days,suffix)}
    if re.search(r"\b(?:find|locate)\s+(?:duplicate|duplicates)\b",low):
        return {"ok":True,"action":"duplicate_search","results":duplicate_files()}
    if re.search(r"\bopen\s+(?:file|document)\b",low):
        m=re.search(r"\bopen\s+(?:file|document)\s+(.+)$",command,re.I)
        if m:
            _target=m.group(1)
            try:
                if not _safe_path(_target).exists():
                    import friday_filesearch7 as _fs
                    _hit=_fs.best(_target)
                    if _hit: _target=_hit["path"]
            except Exception:
                pass
            return {"handled":True,"result":open_file(_target)}
        return {"ok":False,"error":"path_missing"}
    if re.search(r"\b(?:extract|unzip|compress)\b",low):
        return archive_action(command)
    # Search is read-only.
    m=re.search(r"\b(?:find|search for|locate)\s+(?:the\s+)?(?:file|files?)\s+(.+?)(?:\s+in\s+(.+))?$",command,re.I)
    if m:
        q=m.group(1).strip(" ."); where=_safe_path(m.group(2)) if m.group(2) else None
        return {"ok":True,"action":"search","results":search_files(q,where)}
    m=re.search(r"\bcreate\s+(?:a\s+)?folder\s+(?:called\s+)?(.+)$",command,re.I)
    if m:
        p=_safe_path(m.group(1)); p.mkdir(parents=True,exist_ok=False); _record("create_dir",path=str(p))
        return {"ok":True,"action":"create_folder","path":str(p)}
    m=re.search(r"\brename\s+(?:file\s+)?(.+?)\s+to\s+(.+)$",command,re.I)
    if m:
        a,b=_safe_path(m.group(1)),_safe_path(m.group(2))
        if not a.exists():return {"ok":False,"error":"source_not_found"}
        if b.exists():return {"ok":False,"error":"destination_exists"}
        a.rename(b); _record("rename",src=str(a),dst=str(b)); return {"ok":True,"action":"rename","verified":b.exists()}
    m=re.search(r"\bcopy\s+(.+?)\s+to\s+(.+)$",command,re.I)
    if m:
        a,b=_safe_path(m.group(1)),_safe_path(m.group(2))
        if not a.exists():return {"ok":False,"error":"source_not_found"}
        shutil.copy2(a,b); _record("copy",src=str(a),dst=str(b)); return {"ok":True,"action":"copy","verified":b.exists()}
    m=re.search(r"\bmove\s+(.+?)\s+to\s+(.+)$",command,re.I)
    if m:
        a,b=_safe_path(m.group(1)),_safe_path(m.group(2))
        if not a.exists():return {"ok":False,"error":"source_not_found"}
        shutil.move(str(a),str(b)); _record("move",src=str(a),dst=str(b)); return {"ok":True,"action":"move","verified":Path(b).exists()}
    return {"ok":False,"error":"no_unambiguous_file_action"}

def undo_last()->dict[str,Any]:
    j=_load()
    if not j:return {"ok":False,"error":"nothing_to_undo"}
    item=j.pop()
    a=item["action"]
    try:
        if a=="rename": Path(item["dst"]).rename(item["src"])
        elif a=="move": shutil.move(item["dst"],item["src"])
        elif a=="copy": Path(item["dst"]).unlink()
        elif a=="create_dir": Path(item["path"]).rmdir()
        else:return {"ok":False,"error":"action_not_reversible","action":a}
        _save(j); return {"ok":True,"undid":a}
    except Exception as e:return {"ok":False,"error":str(e)}

# ---------- Windows UI Automation (primary desktop layer) ----------
def uia_available():
    try:
        import friday_uia
        return friday_uia.available()
    except Exception:
        return False

def uia_action(command: str):
    try:
        import friday_uia
        return friday_uia.action(command)
    except Exception as e:
        return {"ok":False,"error":str(e)}

def uia_inspect():
    try:
        import friday_uia
        return friday_uia.inspect()
    except Exception as e:
        return {"ok":False,"error":str(e)}


# ---------- Explicit Google Chrome controller ----------
# Do not rely on Windows' default-browser association for FRIDAY actions.
# That association may point to Edge even when the user is asking for Chrome.
# We resolve Chrome.exe explicitly and drive it through its normal visible UI.
_CHROME_EXE_CACHE: str | None = None

def _chrome_executable() -> str | None:
    global _CHROME_EXE_CACHE
    if _CHROME_EXE_CACHE and Path(_CHROME_EXE_CACHE).exists():
        return _CHROME_EXE_CACHE
    if not _windows():
        return None
    candidates = [
        os.environ.get("FRIDAY_CHROME_PATH", ""),
        os.environ.get("PROGRAMFILES", "") + r"\Google\Chrome\Application\chrome.exe",
        os.environ.get("PROGRAMFILES(X86)", "") + r"\Google\Chrome\Application\chrome.exe",
        os.environ.get("LOCALAPPDATA", "") + r"\Google\Chrome\Application\chrome.exe",
        os.environ.get("ProgramW6432", "") + r"\Google\Chrome\Application\chrome.exe",
    ]
    for raw in candidates:
        if raw:
            p = Path(os.path.expandvars(raw))
            if p.exists():
                _CHROME_EXE_CACHE = str(p)
                return _CHROME_EXE_CACHE
    return None

def _focus_chrome_window(timeout: float = 3.0) -> bool:
    if not _windows():
        return False
    deadline = time.time() + max(0.2, timeout)
    try:
        user32 = ctypes.windll.user32
        while time.time() < deadline:
            found = []

            @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
            def callback(hwnd, _lparam):
                try:
                    if not user32.IsWindowVisible(hwnd):
                        return True
                    n = user32.GetWindowTextLengthW(hwnd)
                    if n <= 0:
                        return True
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(hwnd, buf, n + 1)
                    title = buf.value.lower()
                    if "google chrome" in title:
                        found.append(hwnd)
                        return False
                except Exception:
                    pass
                return True

            user32.EnumWindows(callback, 0)
            if found:
                hwnd = found[0]
                try:
                    user32.ShowWindow(hwnd, 9)  # SW_RESTORE
                    user32.SetForegroundWindow(hwnd)
                    return True
                except Exception:
                    return False
            time.sleep(0.12)
    except Exception:
        return False
    return False

def _chrome_current_url() -> str:
    """Read Chrome's actual omnibox value without relying on process state.
    Ctrl+L/C copies the visible URL to the clipboard; Escape restores the page.
    """
    if not _focus_chrome_window(timeout=2.0):
        return ""
    try:
        p=_pyautogui(); import pyperclip
        p.hotkey("ctrl","l"); time.sleep(.08); p.hotkey("ctrl","c"); time.sleep(.08)
        value=str(pyperclip.paste() or "").strip(); p.press("esc"); return value
    except Exception:
        try:_pyautogui().press("esc")
        except Exception:pass
        return ""

def _urls_equivalent(actual: str, expected: str) -> bool:
    from urllib.parse import urlsplit, parse_qs
    try:
        a,e=urlsplit(actual),urlsplit(expected)
        if a.scheme.lower()!=e.scheme.lower() or a.netloc.lower()!=e.netloc.lower(): return False
        if a.path.rstrip('/') != e.path.rstrip('/'): return False
        aq,eq=parse_qs(a.query),parse_qs(e.query)
        for k,vals in eq.items():
            if aq.get(k)!=vals: return False
        return True
    except Exception:
        return actual.rstrip('/')==expected.rstrip('/')

def chrome_open(url: str = "https://www.google.com", new_tab: bool = True) -> dict[str, Any]:
    """Open a URL in the user's installed Google Chrome, never Edge."""
    exe = _chrome_executable()
    if not exe:
        return {"ok": False, "error": "google_chrome_not_found"}
    u = str(url).strip()
    if not re.match(r"^https?://", u, re.I):
        u = "https://" + u
    try:
        args = [exe]
        if new_tab:
            args.append("--new-tab")
        args.append(u)
        subprocess.Popen(args, shell=False)
        focused = _focus_chrome_window(timeout=4.0)
        time.sleep(0.55)
        actual=_chrome_current_url() if focused else ""
        verified=bool(focused and actual and _urls_equivalent(actual,u))
        return {
            "ok": verified, "executed": True, "browser": "Google Chrome", "url": u,
            "actual_url": actual, "focused": focused, "verified": verified,
            **({} if verified else {"error": "chrome_navigation_not_verified"})
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}

def chrome_new_tab() -> dict[str, Any]:
    exe = _chrome_executable()
    if not exe:
        return {"ok": False, "error": "google_chrome_not_found"}
    try:
        subprocess.Popen([exe, "--new-tab"], shell=False)
        focused = _focus_chrome_window(timeout=4.0)
        time.sleep(0.35)
        actual=_chrome_current_url() if focused else ""
        verified=bool(focused and actual)
        return {"ok":verified,"executed":True,"browser":"Google Chrome","action":"new_tab","actual_url":actual,"verified":verified,
                **({} if verified else {"error":"google_chrome_new_tab_not_verified"})}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def _google_challenge_detected() -> bool | None:
    """Return True when Google's visible page is asking for human verification.

    None means OCR is unavailable; callers should then rely on normal window
    verification rather than treating missing OCR as a failure.
    """
    try:
        import mss
        from PIL import Image
        import pytesseract
        with mss.mss() as sct:
            monitor = sct.monitors[0]
            shot = sct.grab(monitor)
            image = Image.frombytes("RGB", shot.size, shot.rgb)
        text = pytesseract.image_to_string(image, config="--psm 6").lower()
        return any(marker in text for marker in (
            "unusual traffic",
            "i'm not a robot",
            "im not a robot",
            "recaptcha",
            "automated queries",
        ))
    except Exception:
        return None

def chrome_search(query: str, new_tab: bool = True) -> dict[str, Any]:
    """Perform a Google search visibly through Chrome's normal address/search UI."""
    q = str(query or "").strip()
    if not q:
        return {"ok": False, "error": "empty_search_query"}
    if new_tab:
        result = chrome_new_tab()
    else:
        result = {"ok": _focus_chrome_window()}
        if not result.get("ok"):
            result = chrome_open("https://www.google.com", new_tab=True)
    if not result.get("ok"):
        return result
    try:
        p = _pyautogui()
        import pyperclip
        p.hotkey("ctrl", "l")
        pyperclip.copy(q)
        p.hotkey("ctrl", "v")
        p.press("enter")
        time.sleep(1.0)
        challenge = _google_challenge_detected()
        if challenge is True:
            return {
                "ok": False,
                "browser": "Google Chrome",
                "action": "google_search",
                "query": q,
                "error": "human_verification_required",
                "verified": False,
            }
        focused = _focus_chrome_window(timeout=1.5)
        actual=_chrome_current_url() if focused else ""
        from urllib.parse import urlsplit, parse_qs, unquote_plus
        try: observed=(parse_qs(urlsplit(actual).query).get("q") or [""])[0]
        except Exception: observed=""
        verified=bool(focused and observed.strip().casefold()==q.strip().casefold())
        return {"ok":verified,"executed":True,"browser":"Google Chrome","action":"google_search","query":q,"actual_url":actual,"observed_query":observed,"verified":verified,
                **({} if verified else {"error":"google_search_not_verified"})}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def chrome_type_in_search_bar(text: str, open_google: bool = False) -> dict[str, Any]:
    """Open/focus Chrome and enter text in its normal omnibox/search UI."""
    value = str(text or "").strip()
    if not value:
        return {"ok": False, "error": "empty_text"}
    if open_google:
        opened = chrome_open("https://www.google.com", new_tab=True)
        if not opened.get("ok"):
            return opened
        time.sleep(0.9)
    elif not _focus_chrome_window(timeout=3.0):
        opened = chrome_open("https://www.google.com", new_tab=True)
        if not opened.get("ok"):
            return opened
    try:
        p = _pyautogui()
        import pyperclip
        p.hotkey("ctrl", "l")
        pyperclip.copy(value)
        p.hotkey("ctrl", "v")
        p.press("enter")
        time.sleep(0.9)
        challenge = _google_challenge_detected()
        if challenge is True:
            return {
                "ok": False,
                "browser": "Google Chrome",
                "action": "type_search",
                "text": value,
                "error": "human_verification_required",
                "verified": False,
            }
        focused = _focus_chrome_window(timeout=1.5)
        actual=_chrome_current_url() if focused else ""
        from urllib.parse import urlsplit, parse_qs
        try: observed=(parse_qs(urlsplit(actual).query).get("q") or [""])[0]
        except Exception: observed=""
        verified=bool(focused and observed.strip().casefold()==value.strip().casefold())
        return {"ok":verified,"executed":True,"browser":"Google Chrome","action":"type_search","text":value,"actual_url":actual,"observed_query":observed,"verified":verified,
                **({} if verified else {"error":"chrome_search_text_not_verified"})}
    except Exception as e:
        return {"ok": False, "error": str(e)}

# ---------- Playwright browser layer ----------
_pw_lock=threading.RLock(); _pw=None; _pw_browser=None; _pw_context=None; _pw_page=None

# V6.4: a Chrome that belongs to the user, not to FRIDAY's process tree. It is started on its own debugging port with its own
# profile folder; Playwright only attaches to it. Closing FRIDAY therefore never closes this browser or its tabs.
_CDP_PORT = 9333

def _cdp_url() -> str:
    return f"http://127.0.0.1:{_CDP_PORT}"

def _cdp_port_open(timeout: float = 0.4) -> bool:
    import socket
    try:
        with socket.create_connection(("127.0.0.1", _CDP_PORT), timeout=timeout):
            return True
    except OSError:
        return False

def _launch_persistent_chrome(wait: float = 9.0) -> bool:
    exe = _chrome_executable()
    if not exe:
        return False
    try:
        prof = Path(__file__).resolve().parent / "friday_data" / "chrome_cdp_profile"
        prof.mkdir(parents=True, exist_ok=True)
        args = [exe, f"--remote-debugging-port={_CDP_PORT}", f"--user-data-dir={prof}", "--no-first-run", "--no-default-browser-check", "about:blank"]
        kw: dict = {"shell": False}
        if os.name == "nt":
            kw["creationflags"] = 0x00000008 | 0x00000200      # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        subprocess.Popen(args, **kw)
        end = time.time() + wait
        while time.time() < end:
            if _cdp_port_open():
                return True
            time.sleep(0.25)
    except Exception:
        pass
    return False

def _playwright_page():
    global _pw,_pw_browser,_pw_context,_pw_page
    with _pw_lock:
        if _pw_page is not None:
            try:
                _=_pw_page.url
                return _pw_page
            except Exception:
                _pw_page=None
        try:
            from playwright.sync_api import sync_playwright
            _pw=sync_playwright().start()
            # V6.4: first try an INDEPENDENT Chrome (own debugging port) so the pages FRIDAY opens stay open when FRIDAY is
            # closed. If that is not possible, fall back to the original launch below (unchanged behaviour).
            try:
                if _cdp_port_open() or _launch_persistent_chrome():
                    _pw_browser=_pw.chromium.connect_over_cdp(_cdp_url())
                    _pw_context=_pw_browser.contexts[0] if _pw_browser.contexts else _pw_browser.new_context()
                    _blank=[p for p in list(_pw_context.pages) if (p.url or "") in ("about:blank","chrome://newtab/","chrome://new-tab-page/")]
                    _pw_page=_blank[0] if _blank else _pw_context.new_page()
                    return _pw_page
            except Exception:
                _pw_browser=None; _pw_context=None; _pw_page=None
            # Prefer the user's installed Google Chrome. Edge is never selected
            # for a FRIDAY "Chrome/Google" request.
            # Never silently switch to Playwright's bundled Chromium. For a
            # user-facing Chrome request, the visible installed Chrome instance
            # is the only acceptable browser.
            _pw_browser=_pw.chromium.launch(channel="chrome", headless=False)
            _pw_context=_pw_browser.new_context(accept_downloads=True)
            _pw_page=_pw_context.new_page()
            return _pw_page
        except Exception as e:
            return None

def playwright_available():
    try:
        import playwright
        return True
    except Exception: return False

def playwright_browser(command: str):
    page=_playwright_page()
    if page is None: return {"ok":False,"error":"playwright_unavailable_or_browser_failed"}
    c=command.strip(); low=c.lower()
    try:
        m=re.search(r"\b(?:search|google)\s+(?:for\s+)?(.+)$",c,re.I)
        if m:
            q=m.group(1).strip(); expected="https://www.google.com/search?q="+urllib_quote(q); page.goto(expected,wait_until="domcontentloaded",timeout=20000)
            from urllib.parse import urlsplit,parse_qs
            observed=(parse_qs(urlsplit(page.url).query).get("q") or [""])[0]
            verified=observed.strip().casefold()==q.strip().casefold()
            return {"ok":verified,"executed":True,"backend":"playwright","action":"search","query":q,"url":page.url,"title":page.title(),"verified":verified,**({} if verified else {"error":"playwright_search_not_verified"})}
        m=re.search(r"\b(?:open|go to|navigate to)\s+(https?://\S+|www\.\S+|\S+\.\S+)$",c,re.I)
        if m:
            u=m.group(1); u=u if u.startswith("http") else "https://"+u
            page.goto(u,wait_until="domcontentloaded",timeout=20000)
            verified=page.url.split("#",1)[0].rstrip("/")==u.split("#",1)[0].rstrip("/")
            return {"ok":verified,"executed":True,"backend":"playwright","action":"navigate","url":page.url,"title":page.title(),"verified":verified,**({} if verified else {"error":"playwright_navigation_not_verified"})}
        if re.search(r"\bnew tab\b",low):
            p=_pw_context.new_page(); p.bring_to_front(); globals()['_pw_page']=p
            verified=p in _pw_context.pages
            return {"ok":verified,"executed":True,"backend":"playwright","action":"new_tab","verified":verified}
        if re.search(r"\bclose (?:the )?tab\b",low):
            old_count=len(_pw_context.pages); page.close(); globals()['_pw_page']=_pw_context.pages[-1] if _pw_context.pages else _pw_context.new_page(); verified=len(_pw_context.pages)<old_count or bool(_pw_context.pages); return {"ok":verified,"executed":True,"action":"close_tab","verified":verified}
        if re.search(r"\b(?:next|switch) tab\b",low):
            pages=_pw_context.pages
            if len(pages)>1:
                idx=pages.index(page); np=pages[(idx+1)%len(pages)]; np.bring_to_front(); globals()['_pw_page']=np
            return {"ok":True,"action":"switch_tab"}
        m=re.search(r"\bfind (?:text|word|phrase)\s+(.+)$",c,re.I)
        if m:
            target=m.group(1).strip(" \'\"")
            loc=page.get_by_text(target,exact=False).first
            loc.wait_for(state="visible",timeout=5000)
            return {"ok":True,"action":"find_text","text":target,"visible":loc.is_visible()}
        m=re.search(r"\b(?:click|press)\s+(?:the\s+)?(?:link|button)\s+[\"']?(.+?)[\"']?$",c,re.I)
        if m:
            target=m.group(1).strip(" .\"'")
            loc=page.get_by_role("button",name=re.compile(re.escape(target),re.I)).first
            if not loc.count(): loc=page.get_by_role("link",name=re.compile(re.escape(target),re.I)).first
            if not loc.count(): loc=page.get_by_text(target,exact=False).first
            loc.click(timeout=8000)
            return {"ok":True,"backend":"playwright","action":"click","target":target}
        if re.search(r"\b(?:read|extract)\s+(?:this\s+)?(?:page|webpage|website)\b",low):
            return {"ok":True,"backend":"playwright","action":"read_page","url":page.url,"title":page.title(),"text":page.locator("body").inner_text(timeout=8000)[:20000]}
        return {"ok":False,"error":"no_unambiguous_playwright_action"}
    except Exception as e:
        return {"ok":False,"backend":"playwright","error":str(e)}

# ---------- browser ----------
def browser(command:str)->dict[str,Any]:
    """Control the user's visible Google Chrome first, then use Playwright only
    for DOM-level operations that cannot be done reliably from normal keyboard
    controls. This keeps FRIDAY out of Edge for Chrome/Google requests.
    """
    c = command.strip()
    low = c.lower()

    # V2035 SEMANTIC COMPOUND INTENT: natural speech such as
    # "open Google and type hi in the search bar" is resolved as ONE
    # intentional action. This is checked before generic rules so "type"
    # is treated as an action verb, not accidentally duplicated into the
    # search text. Existing verified Chrome execution is reused.
    try:
        from friday_intent_engine import parse_browser_intent
        semantic = parse_browser_intent(c)
        if semantic is not None:
            if semantic.kind == "google_type_search":
                return chrome_type_in_search_bar(semantic.payload, open_google=True)
            if semantic.kind == "google_search":
                return chrome_search(semantic.payload, new_tab=False)
            if semantic.kind == "site_search":
                # Use the existing visible browser/Playwright path. The site
                # name and query remain separate so the agent can resolve
                # site-specific search controls when supported.
                return playwright_browser(f"open {semantic.target} and search for {semantic.payload}")
    except Exception:
        pass

    # Compound browser action: "open a new tab in Google and type hi in the
    # search bar". This must be checked before the generic "new tab" rule.
    m = re.search(
        r"\b(?:open|launch|start)\s+(?:a\s+)?new\s+tab\s+(?:in|on|using)\s+"
        r"(?:google(?:\s+chrome)?|chrome)\s+and\s+(?:type|enter|write)\s+"
        r"(.+?)\s+in\s+(?:the\s+)?(?:search|address|omnibox)\s*(?:bar)?\b",
        c, re.I
    )
    if m:
        return chrome_type_in_search_bar(m.group(1).strip(" .!?"), open_google=True)

    m = re.search(
        r"\b(?:type|enter|write)\s+(.+?)\s+in\s+(?:the\s+)?"
        r"(?:search|address|omnibox)\s*(?:bar)?\b", c, re.I
    )
    if m:
        return chrome_type_in_search_bar(m.group(1).strip(" .!?"), open_google=False)

    # Search/navigation use the user's installed Chrome explicitly.
    # V2044 FIX: this used to grab everything after the bare word "search"/"google", so
    # "show me search results for orbitals in google" produced the query "results for orbitals
    # in google" instead of "orbitals". friday_nlu understands the actual request (verb,
    # "results for", trailing "in google", filler) and returns just the words to search.
    if _nlu is not None:
        try:
            si = _nlu.extract_search(c)
        except Exception:
            si = None
        if si is not None:
            if si.engine != "google":
                return chrome_open(_nlu.search_url(si), new_tab=False)
            return chrome_search(si.query, new_tab=False)
    m = re.search(r"\b(?:search|google)\s+(?:for\s+)?(.+)$", c, re.I)
    if m:
        q = m.group(1).strip()
        q = re.sub(r"^(?:google\s+)?(?:search\s+)?(?:for\s+)?", "", q, flags=re.I).strip()
        return chrome_search(q, new_tab=False)

    m = re.search(
        r"\b(?:open|go to|navigate to)\s+(https?://\S+|www\.\S+|\S+\.\S+)$",
        c, re.I
    )
    if m:
        u = m.group(1)
        u = u if u.startswith("http") else "https://" + u
        return chrome_open(u, new_tab=True)

    if re.search(r"\bnew tab\b", low):
        return chrome_new_tab()

    if re.search(r"\bclose (?:the )?tab\b", low):
        focused = _focus_chrome_window(timeout=2.0)
        if not focused:
            return {"ok": False, "error": "google_chrome_not_focused"}
        p = _pyautogui()
        before=_chrome_current_url(); p.hotkey("ctrl", "w"); time.sleep(.35); after=_chrome_current_url(); verified=bool(after and after!=before); return {"ok":verified,"executed":True,"browser":"Google Chrome","action":"close_tab","verified":verified,"before_url":before,"after_url":after}

    if re.search(r"\b(?:next|switch) tab\b", low):
        focused = _focus_chrome_window(timeout=2.0)
        if not focused:
            return {"ok": False, "error": "google_chrome_not_focused"}
        p = _pyautogui()
        before=_chrome_current_url(); p.hotkey("ctrl", "tab"); time.sleep(.35); after=_chrome_current_url(); verified=bool(after and after!=before); return {"ok":verified,"executed":True,"browser":"Google Chrome","action":"switch_tab","verified":verified,"before_url":before,"after_url":after}

    if re.search(r"\b(?:previous|last) tab\b", low):
        focused = _focus_chrome_window(timeout=2.0)
        if not focused:
            return {"ok": False, "error": "google_chrome_not_focused"}
        p = _pyautogui()
        before=_chrome_current_url(); p.hotkey("ctrl", "shift", "tab"); time.sleep(.35); after=_chrome_current_url(); verified=bool(after and after!=before); return {"ok":verified,"executed":True,"browser":"Google Chrome","action":"previous_tab","verified":verified,"before_url":before,"after_url":after}

    # Read-only page extraction can use HTTP without launching another browser.
    m = re.search(r"\b(?:read|open and read|extract information from)\s+(https?://\S+)$", c, re.I)
    if m:
        import requests
        from bs4 import BeautifulSoup
        u = m.group(1)
        r = requests.get(u, timeout=12, headers={"User-Agent":"Mozilla/5.0"})
        r.raise_for_status()
        text = BeautifulSoup(r.text, "lxml").get_text(" ", strip=True)
        return {"ok": True, "action": "read_webpage", "url": u, "text": text[:12000]}

    # DOM-level operations that benefit from Playwright are a secondary path.
    pw = playwright_browser(c)
    if pw.get("ok"):
        return pw
    if re.search(r"\bfind (?:text|word|phrase)\s+(.+)$", c, re.I):
        # Final keyboard fallback if Playwright is unavailable.
        if _focus_chrome_window(timeout=2.0):
            p = _pyautogui()
            target = re.sub(r"^[\'\"]|[\'\"]$", "", re.search(
                r"\bfind (?:text|word|phrase)\s+(.+)$", c, re.I
            ).group(1))
            p.hotkey("ctrl", "f")
            p.write(target)
            return {"ok": True, "browser": "Google Chrome", "action": "find_on_page", "verified": True}
    return pw

def urllib_quote(s): 
    from urllib.parse import quote_plus
    return quote_plus(s)

# ---------- media ----------
# V7.0 FIX ("play <song> on YouTube" said "Completed: play pause"): the word "play" used to be treated as the keyboard Play/Pause key
# whatever followed it, so a request to PLAY A SONG just toggled whatever was (or wasn't) playing. The media key is now only used for a
# bare transport command ("play", "pause", "play the music", "pause the video", "play/pause", "next song" ...). "play <something>" and
# "play ... on youtube/spotify" are requests for content and go on to the YouTube / Spotify handlers.
_PLAY_FILLER = {"the", "this", "that", "my", "current", "it", "music", "song", "songs", "video", "videos", "track", "audio", "playback", "playing", "media",
                "please", "now", "again", "pause", "resume", "continue", "next", "previous", "last", "first", "sir", "friday", "for", "me"}


def is_play_request(command: str) -> bool:
    """True when `command` asks FRIDAY to play some content (a named song/video/artist, or anything on YouTube/Spotify) rather than to press Play/Pause."""
    low = (command or "").lower()
    m = re.search(r"\bplay\b(.*)$", low)
    if not m or re.search(r"\bplay\s*/\s*pause\b|\bplay\s+pause\b|\bplay\s+(?:the\s+)?(?:next|previous)\s+(?:song|track)\b", low):
        return False
    rest = re.sub(r"[^a-z0-9 ]", " ", m.group(1))
    if re.search(r"\b(?:youtube|you tube|spotify|netflix|prime video)\b", rest):
        return True
    return any(t not in _PLAY_FILLER for t in rest.split())


def media(command:str)->dict[str,Any]:
    p=_pyautogui(); low=command.lower()
    if is_play_request(low):
        return {"ok":False,"error":"play_request_is_not_a_media_key"}
    if "volume up" in low or "increase volume" in low:
        p.press("volumeup", presses=3); return {"ok":True,"action":"volume_up"}
    if "volume down" in low or "decrease volume" in low:
        p.press("volumedown", presses=3); return {"ok":True,"action":"volume_down"}
    if "mute" in low:
        p.press("volumemute"); return {"ok":True,"action":"mute"}
    if re.search(r"\b(skip|next song|next track)\b",low):
        p.press("nexttrack"); return {"ok":True,"action":"next"}
    if re.search(r"\b(previous song|previous track)\b",low):
        p.press("prevtrack"); return {"ok":True,"action":"previous"}
    if re.search(r"\bpause\b|\bplay\b",low):
        p.press("playpause"); return {"ok":True,"action":"play_pause"}
    return {"ok":False,"error":"no_unambiguous_media_action"}

# ---------- command router ----------
def handle(command:str):
    c=command.strip(); low=c.lower()
    if re.search(r"\b(?:system info|system information|pc status|computer status|how much ram|cpu usage|battery|disk space|storage)\b",low):
        return {"handled":True,"result":system_info()}
    if re.search(r"\b(?:what(?:'s| is) running|running applications|running apps)\b",low):
        return {"handled":True,"result":running_apps()}
    if re.search(r"\b(?:active window|what window is open|which app is active)\b",low):
        return {"handled":True,"result":{"active_window":active_window()}}
    if re.search(r"\b(?:undo|undo that|reverse that)\b",low):
        r=undo_last(); return {"handled":True,"result":r}
    if re.search(r"\b(?:minimi[sz]e|maximi[sz]e|restore|switch windows?|next window)\b",low):
        r=window_action(c)
        if r.get("ok"): return {"handled":True,"result":r}
    if re.search(r"\b(?:launch|open|start)\s+(?:the\s+)?(?:chrome|google chrome|edge|microsoft edge|notepad|calculator|calc|paint|explorer|file explorer|powershell|terminal|command prompt|cmd|vscode|vs code|whatsapp|wps|wps office|kingsoft wps|wps writer|wps spreadsheet|wps presentation)\b",low):
        m=re.search(r"\b(?:launch|open|start)\s+(?:the\s+)?(.+)$",c,re.I); r=launch_app(m.group(1)); return {"handled":True,"result":r}
    if re.search(r"\b(?:new tab|close (?:the )?tab|next tab|switch tab|previous tab|last tab|google search|search google|go to https?://|navigate to https?://|find (?:text|word|phrase))\b",low):
        return {"handled":True,"result":browser(c)}
    if re.search(r"\b(?:volume up|increase volume|volume down|decrease volume|mute|play|pause|skip|next song|next track|previous song|previous track)\b",low) and not is_play_request(low):
        return {"handled":True,"result":media(c)}
    if re.search(r"\b(?:find|search for|locate) (?:the )?(?:file|files?|pdf|document|duplicates?)\b|\b(?:create|rename|copy|move|open|extract|unzip|compress) (?:a )?(?:file|folder|pdf|document|archive)\b",low):
        return {"handled":True,"result":file_action(c)}
    if re.search(r"\b(?:click|press|activate|invoke)\s+(?:the\s+)?(?:button\s+)?[\"']?.+", c, re.I) and uia_available():
        ur=uia_action(c)
        if ur.get("ok"): return {"handled":True,"result":ur}
    if re.search(r"\b(?:click|double-click|right-click|middle-click|move cursor|type |write |select all|select everything|copy|cut|paste|scroll )\b",low):
        return {"handled":True,"result":computer(c)}
    return None
