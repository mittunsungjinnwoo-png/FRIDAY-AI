@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo FRIDAY 7.0 - Windows standalone build
 echo ============================================
echo.
echo Checking FRIDAY 7.0 icon assets...
if not exist "assets\friday.ico" (echo ERROR: assets\friday.ico is missing.& goto :fail)
if not exist "assets\friday_icon.png" (echo ERROR: assets\friday_icon.png is missing.& goto :fail)
echo Icon OK.
echo.
echo Installing Electron build dependencies...
call npm install --no-audit --no-fund
if errorlevel 1 goto :fail

echo.
echo Validating electron-builder configuration...
call npx electron-builder --win --dir --config.asar=false
if errorlevel 1 goto :fail

echo.
echo Building the Windows NSIS installer...
call npx electron-builder --win
if errorlevel 1 goto :fail

echo.
echo BUILD COMPLETE.
echo Installer should be in the dist folder.
exit /b 0

:fail
echo.
echo BUILD FAILED. See the error above.
exit /b 1
