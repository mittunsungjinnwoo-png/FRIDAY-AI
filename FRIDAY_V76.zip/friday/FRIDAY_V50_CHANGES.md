# FRIDAY 5.0 — what changed

FRIDAY is no longer a money-saving assistant. She is a **multi-tasking advanced AI assistant** (finance and meal planning remain as features under *Finance*, not as her purpose). Persona, spoken self-introduction, window title, sidebar, widget, installer and package are all FRIDAY 5.0. Saved data stays in the same folder — nothing is lost.

## 1. New listening + recognising (`friday_voice5.py`)
| Before (3.1) | Now (5.0) |
|---|---|
| mic opened and calibrated for every utterance | one always-open mic stream, adaptive noise floor, 400 ms pre-roll (first syllable never clipped) |
| waited **1.05 s** of silence, then ran recognition **after** that | **speculative endpointing**: recognition starts after 0.30 s of silence and keeps listening; reply starts at ~0.50 s. If you carry on, the speculative result is discarded |
| Google + Whisper hybrid + "deep verify" passes (serial) | **recognition race**: local faster-whisper vs Google, first good result wins; offline/blocked cloud is detected and skipped for 45 s |
| medium.en Whisper on CPU by default (very slow) | base.en default (cached models preferred); `FRIDAY_PEAK_MODE=1` still gives the big model |
| mic deaf while she talks | **full duplex**: say "stop", or just talk over her — she ducks, checks it is not her own echo, then stops mid-sentence and takes your new command |
| wake word only at the start | "Friday" works anywhere in a sentence in standby; in conversation only a leading "Hey Friday" is stripped (so "calendar for Friday" is safe) |
Whisper noise hallucinations ("Thank you.", "you") are filtered. If PyAudio/mic cannot start, FRIDAY automatically falls back to the 3.1 listener.

## 2. New speaking (`friday_speech5.py`)
In-memory synthesis (no temp files), all sentences of a reply synthesised in parallel, disk cache for short phrases ("Yes, sir." is instant and works offline), in-process playback (miniaudio/PyAudio) that can be ducked and **interrupted instantly**; automatically falls back to the 3.1 PowerShell player. Same voice (`en-US-AriaNeural`, `FRIDAY_EDGE_VOICE` to change).

## 3. Fast replies
* exact answers with **no network and no model**: maths ("what's 25 × 37", "15 percent of 240", spoken numbers), unit conversion, time and date — milliseconds
* local SQLite full-text memory instead of a network embedding call on every question
* router sends ordinary chat to the fast streamed model, only hard questions to the deep route
* first sentence is spoken while the rest is still being generated (as before) with shorter first-audio path

## 4. Intelligence router + verification (`friday_router5.py`)
`instant → fast → deep → research → agent`. The **deep** route says a short holding line, thinks at high effort, then an independent verifier checks the draft (and re-solves numeric questions independently); confidence is shown on the HUD. `FRIDAY_DEEP_MODEL` can name a stronger model.

## 5. Long-term memory, knowledge base and goals (`friday_knowledge5.py`)
Facts, preferences, decisions, projects, lessons from failures/successes — retrieved per question (BM25 + recency), never dumped wholesale. Secrets are never stored. Everything you attach is indexed so "what did that PDF say about X" works later. Say: *"remember that …"*, *"forget …"*, *"what did we decide about …"*, *"my goal is to … by 2026-11-30"*, *"goal progress"*, *"step 2 done"*, *"index the folder C:\\path"*.

## 6. Tools with permissions (`friday_tools5.py`)
FRIDAY picks the tool herself: *"why is my laptop getting hot"* → real CPU/RAM/temperature/process/battery/disk readings → diagnosis. Sandboxed code runner (timeout), file search/creation/folder analysis. Risky actions ask "Shall I go ahead?" first; permissions can be revoked by voice (*"revoke file writing"*) or in Settings; every action goes to `friday_data/audit5.jsonl` with secrets redacted.

## 7. Attach files in the chat — like Claude (`friday_attach5.py`, `friday_chat5.js`)
Paperclip, **drag-and-drop** or **paste a screenshot** into the message box. Files appear as cards in your message; FRIDAY actually reads them (PDF incl. scanned, Word, Excel/CSV, PowerPoint, code, ZIP, images, audio) and does the task you wrote ("fix the bugs", "summarise", "convert to CSV", "what does this chart show"). Anything she creates or edits comes back as a **file card** (Open / Save as… / Show). Attachments stay available for follow-ups for 45 minutes ("now translate it"); say "clear attachments" to drop them.

## 8. Live HUD + benchmark
Right-hand panel: core state, route, tool in use, task, memories used, reply time, confidence. **Tools → Run FRIDAY benchmark** (or say "run benchmark") scores her out of 100 across reasoning, maths, coding, memory, tools, voice, attachments, speed and recovery and keeps a history.

## Install notes
* `INSTALL_FRIDAY_WINDOWS.bat` now also installs `requirements-optional.txt` (miniaudio, soundfile) — optional; FRIDAY works without them.
* Tests (no hardware needed): `python FRIDAY_TEST_V5_ALL.py`
* Environment switches: `FRIDAY_V5_VOICE=0` (use 3.1 listener), `FRIDAY_V5_SPEECH=0`, `FRIDAY_BARGE_IN=0`, `FRIDAY_V5_CLOUD_STT=0` (fully local recognition), `FRIDAY_V5_COMMIT_MS`/`FRIDAY_V5_SPEC_MS` (endpoint timing).

## Honest limits
Written and tested without a Windows microphone, speakers or a Gemini key: the voice segmenter, recognition race, speech pipeline, router, memory, tools, attachments and the whole chat UI were exercised with simulated audio, fakes and a headless browser; real-microphone tuning (noise floor, barge-in sensitivity) may need small adjustments on your machine — the switches above exist for that.
