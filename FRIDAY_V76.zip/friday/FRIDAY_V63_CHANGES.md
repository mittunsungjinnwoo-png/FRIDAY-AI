# FRIDAY 6.3 - two targeted fixes on top of 6.2 (nothing else changed)

1. **"On my camera" (and similar) now really turns the camera on.**
   Before, only phrases like "turn on the camera" matched, so "on my camera" went to the chat AI, which just *said* the camera was on.
   Now any short sentence that is only a camera on/off request works in any word order: "on my camera", "camera on please",
   "put the camera on", "switch my webcam off", "off my camera"... The camera is opened (or released) by the real vision engine and
   FRIDAY only confirms after that happened.
   Questions are never treated as switches: "is my camera on?" is answered from the real state (it used to turn the camera on).
2. **Speech starts exactly when the reply appears.** The reply text is now pushed to the chat at the instant the first sound starts playing
   (not after a fixed wait for the voice). If the voice service is unusually slow (8 s) the words still appear so a reply is never lost.

Files changed: friday_vision_hub.py, friday_speech5.py, friday_backend.py.
Tested headlessly (command routing, text/sound start timing). Not run on a real Windows machine with a camera and speakers.
