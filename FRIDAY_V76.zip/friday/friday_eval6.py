"""FRIDAY 6.0 continuous evaluation and controlled self-improvement (blueprint section 15).

FRIDAY improves through evaluation and reviewed updates - NOT by rewriting her own production code on the fly:

  measure   a fixed deterministic benchmark (this module + the 5.0 benchmark), latency / reliability / cost from the model router
  learn     lessons from confirmed failures, regression tests built from past bugs and user corrections, recurring-correction tracking
  propose   suggestions and patch proposals (never applied automatically)
  test      a proposed patch is applied to a COPY of the app, built and tested in isolation and compared with the current version
  apply     only with the user's explicit approval and the `self_update` permission, after a full backup; rolled back automatically if the
            post-change check fails
  version   versioned configuration snapshots with rollback
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional

import friday_common6 as C
import friday_security6 as SEC

C.register_schema("""
CREATE TABLE IF NOT EXISTS evals6(id INTEGER PRIMARY KEY, ts REAL, version TEXT, score REAL, passed INTEGER, total INTEGER, ms INTEGER, detail TEXT, config TEXT);
CREATE TABLE IF NOT EXISTS regress6(id INTEGER PRIMARY KEY, ts REAL, prompt TEXT, expect TEXT, kind TEXT, note TEXT, fails INTEGER DEFAULT 0, source TEXT);
CREATE TABLE IF NOT EXISTS failures6(id INTEGER PRIMARY KEY, ts REAL, area TEXT, what TEXT, lesson TEXT, confirmed INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS configs6(id INTEGER PRIMARY KEY, ts REAL, label TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS patches6(id INTEGER PRIMARY KEY, ts REAL, title TEXT, diff TEXT, status TEXT, result TEXT);
""")

_probes: List = []         # (name, callable -> bool)


def probe(name: str):
    def deco(fn):
        _probes.append((name, fn))
        return fn
    return deco


def _config_blob() -> Dict:
    import friday_emotion6 as E, friday_perf6 as P, friday_voice6 as V
    return {"version": C.VERSION, "routing": P.cfg("routing", "auto"), "emotion": dict(E.SETTINGS), "voice": {k: V._cfg.get(k) for k in ("voice", "rate", "language", "style")},
            "permissions": {p["tool"]: p["allowed"] for p in SEC.permissions()}}


# ------------------------------------------------------------------ deterministic benchmark
def run_benchmark() -> Dict:
    from importlib import import_module
    results, t0 = [], time.time()
    for name, fn in _probes:
        t = time.perf_counter()
        try:
            ok = bool(fn())
            err = ""
        except Exception as exc:
            ok, err = False, f"{type(exc).__name__}: {str(exc)[:80]}"
        results.append({"name": name, "ok": ok, "ms": round((time.perf_counter() - t) * 1000, 1), "error": err})
    passed = sum(r["ok"] for r in results)
    score = round(100 * passed / max(1, len(results)), 1)
    ms = int((time.time() - t0) * 1000)
    C.x("INSERT INTO evals6(ts,version,score,passed,total,ms,detail,config) VALUES(?,?,?,?,?,?,?,?)", (C.now(), C.VERSION, score, passed, len(results), ms, C.jdump(results), C.jdump(_config_blob())))
    prev = C.q("SELECT score,version FROM evals6 ORDER BY id DESC LIMIT 1 OFFSET 1")
    return {"score": score, "passed": passed, "total": len(results), "ms": ms, "failed": [r["name"] for r in results if not r["ok"]], "results": results,
            "previous": prev[0]["score"] if prev else None, "regressed": bool(prev and score < prev[0]["score"])}


def history(n: int = 10) -> List[Dict]:
    return [{"when": C.iso(r["ts"]), "version": r["version"], "score": r["score"], "passed": r["passed"], "total": r["total"], "ms": r["ms"]} for r in C.q("SELECT * FROM evals6 ORDER BY id DESC LIMIT ?", (n,))]


def compare_last() -> str:
    h = history(2)
    if len(h) < 2:
        return "I need at least two benchmark runs to compare."
    a, b = h[0], h[1]
    d = a["score"] - b["score"]
    return f"Latest {a['score']} percent versus previous {b['score']} percent: " + ("no change" if d == 0 else (f"improved by {d:.1f} points" if d > 0 else f"REGRESSED by {abs(d):.1f} points - I'd hold off on any update and review what changed")) + "."


# ------------------------------------------------------------------ failures, lessons, regression tests
def record_failure(area: str, what: str, lesson: str = "", confirmed: bool = False):
    C.x("INSERT INTO failures6(ts,area,what,lesson,confirmed) VALUES(?,?,?,?,?)", (C.now(), area, C.clip(C.redact(what), 240), C.clip(lesson, 240), int(confirmed)))
    if confirmed and lesson:                    # only CONFIRMED failures become stored lessons
        try:
            import friday_knowledge5 as kb5
            kb5.remember(f"Lesson ({area}): {lesson}", "lesson", "failure", "friday", 0.7)
        except Exception:
            pass


def add_regression(prompt: str, expect: str, kind: str = "instant", note: str = "", source: str = "bug"):
    """kind 'instant': FRIDAY's local router must answer containing `expect` (fully deterministic). 'handler': pre-route must claim and contain `expect`."""
    if not C.q("SELECT id FROM regress6 WHERE prompt=? AND expect=?", (prompt, expect)):
        C.x("INSERT INTO regress6(ts,prompt,expect,kind,note,source) VALUES(?,?,?,?,?,?)", (C.now(), prompt, expect, kind, note, source))


_router: Dict[str, Callable] = {}


def set_router(fn: Callable[[str], Optional[str]]):
    _router["fn"] = fn


def run_regressions() -> Dict:
    import friday_router5 as R5
    bad, n = [], 0
    for r in C.q("SELECT * FROM regress6"):
        got = None
        try:
            got = R5.instant_answer(r["prompt"]) if r["kind"] == "instant" else (_router["fn"](r["prompt"]) if "fn" in _router else None)
        except Exception as exc:
            got = f"error {exc}"
        n += 1
        if not got or r["expect"].lower() not in str(got).lower():
            C.x("UPDATE regress6 SET fails=fails+1 WHERE id=?", (r["id"],))
            bad.append({"prompt": r["prompt"], "expected": r["expect"], "got": str(got)[:80]})
    return {"ran": n, "failed": bad}


def analyze_failures() -> Dict:
    """Group what has actually gone wrong: failed/partial tasks, unreliable providers, slow routes, recurring corrections, blocked actions."""
    out = {"tasks": [dict(r) for r in C.q("SELECT status, COUNT(*) n FROM tasks6 GROUP BY status")], "slow_or_unreliable": [], "corrections": [], "blocked": []}
    for r in C.q("SELECT provider, tier, COUNT(*) n, AVG(ms) ms, AVG(ok) rel FROM model_calls6 GROUP BY provider, tier"):
        if r["n"] >= 3 and (r["rel"] < 0.9 or r["ms"] > 8000):
            out["slow_or_unreliable"].append(f"{r['provider']}/{r['tier']}: {int(r['rel'] * 100)} percent reliable, {int(r['ms'])} ms average over {r['n']} calls")
    try:
        import friday_emotion6 as E
        out["corrections"] = E.relationship()["mistakes"]
    except Exception:
        pass
    out["blocked"] = [dict(r) for r in C.q("SELECT detail, COUNT(*) n FROM audit6 WHERE result='denied' GROUP BY detail ORDER BY n DESC LIMIT 5")]
    return out


def suggestions() -> List[str]:
    a = analyze_failures()
    s = []
    for x in a["slow_or_unreliable"]:
        s.append(f"Investigate {x}. Consider routing that tier to another provider or raising its timeout.")
    for x in a["corrections"][:2]:
        s.append(f"You've corrected me on '{x}' more than once - I'll add a regression test and a lesson for it.")
    for b in a["blocked"][:2]:
        s.append(f"I keep being blocked on '{b['detail'][:50]}' ({b['n']} times). If you want that capability, grant the permission; otherwise I'll stop trying.")
    failed = sum(r["n"] for r in a["tasks"] if r["status"] in ("failed", "partial"))
    if failed >= 3:
        s.append(f"{failed} tasks ended failed or partial. Review their logs with 'task history' for a shared cause.")
    return s or ["Nothing stands out. Performance and reliability are within normal limits."]


# ------------------------------------------------------------------ versioned configuration
def snapshot(label: str = "") -> int:
    return C.x("INSERT INTO configs6(ts,label,data) VALUES(?,?,?)", (C.now(), label or "auto", C.jdump(_config_blob())))


def configs() -> List[Dict]:
    return [{"id": r["id"], "when": C.iso(r["ts"]), "label": r["label"]} for r in C.q("SELECT id,ts,label FROM configs6 ORDER BY id DESC LIMIT 10")]


def rollback_config(cid: Optional[int] = None) -> str:
    r = C.q("SELECT * FROM configs6 WHERE id=?", (cid,)) if cid else C.q("SELECT * FROM configs6 ORDER BY id DESC LIMIT 1")
    if not r:
        return "There's no saved configuration to restore."
    d = C.jload(r[0]["data"], {})
    import friday_emotion6 as E, friday_perf6 as P, friday_voice6 as V
    for k, v in (d.get("emotion") or {}).items():
        E.set_setting(k, v)
    P.set_cfg("routing", d.get("routing", "auto"))
    V._cfg.update({k: v for k, v in (d.get("voice") or {}).items() if v is not None}); V.save(); V.apply()
    for tool, ok in (d.get("permissions") or {}).items():
        SEC.set_permission(tool, ok)
    SEC.audit("user", "config-rollback", f"#{r[0]['id']} {r[0]['label']}")
    return f"Restored configuration '{r[0]['label']}' from {C.iso(r[0]['ts'])}."


# ------------------------------------------------------------------ patch proposal -> isolated test -> approved apply -> auto rollback
def propose_patch(title: str, diff_text: str = "", files: Optional[List[str]] = None) -> int:
    """Store a patch proposal. If no diff is supplied the model drafts one (suggestion only)."""
    if not diff_text and C._cfg.get("llm"):
        diff_text = C.llm("Write a minimal unified diff (git format, paths relative to the project root) for this change. Output only the diff.\n\n" + title)
    return C.x("INSERT INTO patches6(ts,title,diff,status) VALUES(?,?,?,?)", (C.now(), C.clip(title, 120), diff_text, "proposed"))


def _apply_diff(root: Path, diff_text: str) -> Dict:
    p = root / "_proposal.diff"
    p.write_text(diff_text, "utf-8")
    if shutil.which("git"):
        r = subprocess.run(["git", "apply", "--whitespace=nowarn", str(p)], cwd=str(root), capture_output=True, text=True)
        return {"ok": r.returncode == 0, "out": (r.stdout + r.stderr)[-300:]}
    if shutil.which("patch"):
        r = subprocess.run(["patch", "-p1", "-i", str(p)], cwd=str(root), capture_output=True, text=True)
        return {"ok": r.returncode == 0, "out": (r.stdout + r.stderr)[-300:]}
    return {"ok": False, "out": "neither git nor patch is installed, so I can't apply diffs"}


def test_patch(pid: int, project: Optional[str] = None) -> Dict:
    """Apply the proposal to a throw-away COPY, then build/test it and compare against the untouched original."""
    import friday_engineer6 as ENG
    row = C.q("SELECT * FROM patches6 WHERE id=?", (pid,))
    if not row:
        return {"ok": False, "error": "no such proposal"}
    root = Path(project or C.HERE)
    with tempfile.TemporaryDirectory(prefix="friday_patchtest_") as tmp:
        copy = Path(tmp) / "app"
        shutil.copytree(root, copy, ignore=shutil.ignore_patterns("friday_data", "__pycache__", "node_modules", "*.pyc", "dist", ".git"))
        before = ENG.verify_build(str(copy))
        ap = _apply_diff(copy, row[0]["diff"])
        if not ap["ok"]:
            C.x("UPDATE patches6 SET status='does-not-apply', result=? WHERE id=?", (ap["out"], pid))
            return {"ok": False, "stage": "apply", "error": ap["out"]}
        after = ENG.verify_build(str(copy))
    better_or_same = (after["ok"] or not before["ok"]) and len(after["syntax_errors"]) <= len(before["syntax_errors"])
    res = {"ok": better_or_same, "before": before["ok"], "after": after["ok"], "syntax_errors_after": after["syntax_errors"][:3], "tests_after": after["tests"]}
    C.x("UPDATE patches6 SET status=?, result=? WHERE id=?", ("tested-ok" if better_or_same else "tested-failed", C.jdump(res), pid))
    return res


def apply_patch(pid: int, approved: bool) -> Dict:
    """Needs explicit approval AND the self_update permission. Backs up first; rolls back if the post-change check fails."""
    import friday_engineer6 as ENG
    if not approved:
        return {"ok": False, "error": "not approved"}
    blocked = SEC.require("self_update", "apply a patch to FRIDAY")
    if blocked:
        return {"ok": False, "error": blocked}
    row = C.q("SELECT * FROM patches6 WHERE id=?", (pid,))
    if not row or row[0]["status"] != "tested-ok":
        return {"ok": False, "error": "a patch must pass the isolated test before it can be applied"}
    bk = SEC.backup("pre-patch", include_source=True)
    ap = _apply_diff(Path(C.HERE), row[0]["diff"])
    if not ap["ok"]:
        return {"ok": False, "error": ap["out"], "backup": bk}
    v = ENG.verify_build(str(C.HERE))
    if not v["ok"]:
        import zipfile
        with zipfile.ZipFile(bk) as z:
            for n in z.namelist():
                if n.startswith("src/"):
                    (Path(C.HERE) / n[4:]).write_bytes(z.read(n))
        C.x("UPDATE patches6 SET status='rolled-back' WHERE id=?", (pid,))
        SEC.audit("friday", "patch-rolled-back", row[0]["title"], "failed")
        return {"ok": False, "error": "the post-change check failed, so I restored the previous files", "rolled_back": True}
    C.x("UPDATE patches6 SET status='applied' WHERE id=?", (pid,))
    SEC.audit("user", "patch-applied", row[0]["title"])
    return {"ok": True, "backup": bk}


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if re.match(r"^(?:run|start|do) (?:the |a |my |your )?(?:(?:full|continuous|v6|six|6|version 6|friday 6) )?(?:evaluation|benchmark|self[- ]?test)$|^(?:run )?(?:continuous )?evaluation$", low):
        r = run_benchmark()
        return f"Evaluation: {r['passed']} of {r['total']} checks passed, score {r['score']} percent in {r['ms']} milliseconds." + (f" Failing: {', '.join(r['failed'][:4])}." if r["failed"] else " Everything passed.") + (" That is a regression from last time." if r["regressed"] else "")
    if re.match(r"^compare (?:with |to )?(?:the )?(?:previous|last) (?:version|run|benchmark)$|^did (?:i|you) (?:improve|regress)$", low):
        return compare_last()
    m = re.match(r"^(?:that was wrong|you(?:'re| are) wrong|that'?s wrong|regression test)[: ,]+(?:(.+?) (?:should (?:be|give|equal|return)|is) (.+))$", t, re.I)
    if m:
        add_regression(m.group(1), m.group(2), "instant", "user correction", "correction")
        record_failure("answer", m.group(1) + " -> expected " + m.group(2), f"{m.group(1)} should be {m.group(2)}", True)
        return "Understood. I've saved that as a regression test and a lesson."
    if re.match(r"^(?:run|check) (?:my )?regression tests?$", low):
        r = run_regressions()
        return f"Ran {r['ran']} regression tests: " + ("all passed." if not r["failed"] else f"{len(r['failed'])} failed, first: {r['failed'][0]['prompt']}.")
    if re.match(r"^(?:how can you improve|what should (?:you|we) improve|suggest improvements(?: to yourself)?|analy[sz]e (?:your )?failures)$", low):
        return "Suggestions: " + " ".join(suggestions()[:3])
    m = re.match(r"^(?:save|snapshot|version) (?:my |the )?(?:config|configuration|settings)(?: as (.+))?$", low)
    if m:
        return f"Configuration saved as version {snapshot(m.group(1) or '')}."
    if re.match(r"^(?:roll ?back|restore|undo) (?:my |the )?(?:last )?(?:config|configuration|settings)(?: change)?$", low):
        return rollback_config()
    m = re.match(r"^propose (?:a )?patch (?:to|for) (.+)$", t, re.I)
    if m:
        return f"Patch proposal {propose_patch(m.group(1))} saved. Nothing has changed. Say 'test patch {C.q('SELECT MAX(id) m FROM patches6')[0]['m']}' and I'll try it on a copy."
    m = re.match(r"^test patch (\d+)$", low)
    if m:
        r = test_patch(int(m.group(1)))
        return ("On a copy, the patch " + ("applies and the build still verifies." if r["ok"] else f"fails: {r.get('error') or r.get('syntax_errors_after')}") ) + " I haven't touched the real app."
    m = re.match(r"^apply patch (\d+)$", low)
    if m:
        _pending_patch["id"] = int(m.group(1))
        return "That changes my own files. I'll back everything up first and roll back automatically if the check fails. Say 'confirm patch' to proceed."
    if low == "confirm patch" and "id" in _pending_patch:
        r = apply_patch(_pending_patch.pop("id"), True)
        return "Patch applied and verified." if r["ok"] else str(r["error"])
    return None


_pending_patch: Dict = {}


def ui_snapshot() -> Dict:
    return {"history": history(8), "suggestions": suggestions(), "configs": configs(), "patches": [dict(r) for r in C.q("SELECT id,title,status FROM patches6 ORDER BY id DESC LIMIT 6")],
            "regressions": [dict(r) for r in C.q("SELECT prompt,expect,fails FROM regress6 ORDER BY id DESC LIMIT 6")]}
