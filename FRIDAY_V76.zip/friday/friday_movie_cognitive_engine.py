"""FRIDAY Executive Cognitive Engine v4010.10.

Observable movie-style behaviour without pretending to expose hidden chain-of-thought:
- understands the user's objective and conversational references
- chooses the cheapest reliable execution path
- plans complex work before acting
- anticipates low-risk prerequisites asynchronously
- verifies outcomes and records what worked
- learns routing preferences from successful/failed turns

This module never touches microphone, VAD, ASR, recognition, or TTS.
It is intentionally additive and fail-open: any internal error returns a
neutral decision so the legacy pipeline continues unchanged.
"""
from __future__ import annotations
import re, time, threading, hashlib
from dataclasses import dataclass, asdict
from typing import Any

try:
    import friday_state_engine as state
except Exception:
    state = None

_LOCK = threading.RLock()
_HISTORY: dict[str, dict[str, Any]] = {}
_MAX_HISTORY = 256

# Strongly observable goals.  These are not a substitute for the existing
# handlers; they tell the existing handlers how much orchestration is needed.
_COMPLEX = (
    r"\bresearch\b", r"\banaly[sz]e\b", r"\bcompare\b", r"\bcreate\b", r"\bmake\b",
    r"\bbuild\b", r"\bwrite\b", r"\bprepare\b", r"\bfind\b.*\band\b", r"\bthen\b",
    r"\bafter that\b", r"\busing\b", r"\bdownload\b.*\b(open|read|summarize)\b",
)
_EXTERNAL = (r"\blatest\b", r"\bcurrent\b", r"\btoday\b", r"\bweb\b", r"\bwebsite\b", r"\bresearch\b", r"\bsource", r"\bverify\b")
_CONSEQUENTIAL = (r"\bsend\b", r"\bcall\b", r"\bdelete\b", r"\bpurchase\b", r"\bbuy\b", r"\bpublish\b", r"\bshutdown\b", r"\binstall\b")
_PREP = {
    "research": "browser", "search": "browser", "website": "browser", "url": "browser",
    "document": "word", "report": "word", "essay": "word", "docx": "word",
    "spreadsheet": "excel", "xlsx": "excel", "presentation": "powerpoint", "slides": "powerpoint",
    "whatsapp": "whatsapp", "message": "whatsapp", "contact": "whatsapp",
}

@dataclass(frozen=True)
class CognitiveDecision:
    cleaned: str
    objective: str
    complexity: float
    ambiguity: float
    needs_planning: bool
    needs_external_evidence: bool
    consequential: bool
    preferred_route: str
    prerequisites: tuple[str, ...]
    verification: tuple[str, ...]


def _clean(s: str) -> str:
    s = str(s or "").strip()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"^[\s,.!?;:-]+|[\s,.!?;:-]+$", "", s)
    return s


def _context_text(context: dict[str, Any] | None) -> str:
    if not isinstance(context, dict):
        return ""
    vals=[]
    for key in ("topic","task","last_action","pending_reference","last_command"):
        v=context.get(key)
        if v: vals.append(str(v))
    return " ".join(vals)


def decide(command: str, context: dict[str, Any] | None = None) -> CognitiveDecision:
    c=_clean(command); low=c.lower(); ctx=_context_text(context)
    has_complex=any(re.search(p,low,re.I) for p in _COMPLEX)
    has_ext=any(re.search(p,low,re.I) for p in _EXTERNAL)
    consequential=any(re.search(p,low,re.I) for p in _CONSEQUENTIAL)
    refs=bool(re.search(r"\b(it|this|that|these|those|there|the file|the results|the topic)\b",low))
    ambiguity=0.0
    if refs and not ctx: ambiguity += .38
    if len(c.split()) < 3: ambiguity += .12
    if consequential and not re.search(r"\b(to|for|with|on)\b",low): ambiguity += .12
    ambiguity=min(1.0,ambiguity)
    complexity=.08 + min(.55,len(c.split())/55) + (.18 if has_complex else 0) + (.12 if has_ext else 0) + (.10 if consequential else 0)
    complexity=min(1.0,complexity)
    needs_planning=complexity>=.38 or len(re.findall(r"\b(and|then|after|once|while|before)\b",low))>=2
    if ambiguity>.55: route="clarify"
    elif consequential: route="supervised"
    elif not needs_planning and len(c.split())<=12: route="fast"
    elif has_ext: route="evidence_planned"
    else: route="planned"
    prereq=[]
    for word,app in _PREP.items():
        if re.search(r"\b"+re.escape(word)+r"\b",low) and app not in prereq:
            prereq.append(app)
    verification=["action_result"]
    if has_ext: verification += ["source_or_evidence"]
    if needs_planning: verification += ["postcondition"]
    if consequential: verification += ["permission_and_postcondition"]
    return CognitiveDecision(c,c,round(complexity,3),round(ambiguity,3),needs_planning,has_ext,consequential,route,tuple(prereq),tuple(verification))


def begin_turn(command: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
    """Fast, non-blocking executive decision. Never calls an AI model."""
    try:
        d=decide(command,context)
        key=hashlib.sha1(d.cleaned.lower().encode()).hexdigest()[:12]
        with _LOCK:
            _HISTORY[key]={"ts":time.time(),**asdict(d)}
            if len(_HISTORY)>_MAX_HISTORY:
                for k in sorted(_HISTORY,key=lambda x:_HISTORY[x].get("ts",0))[:-_MAX_HISTORY]: _HISTORY.pop(k,None)
        if state is not None:
            try:
                state.update("cognition", objective=d.objective, route=d.preferred_route,
                             complexity=d.complexity, ambiguity=d.ambiguity,
                             needs_planning=d.needs_planning, prerequisites=list(d.prerequisites),
                             verification=list(d.verification), updated_at=time.time())
            except Exception: pass
        return asdict(d)
    except Exception:
        return asdict(CognitiveDecision(_clean(command),_clean(command),.0,.0,False,False,False,"legacy",(),("action_result",)))


def should_prepare(decision: dict[str, Any]) -> bool:
    return bool(decision.get("prerequisites")) and decision.get("preferred_route") in {"planned","evidence_planned"}


def health() -> dict[str, Any]:
    with _LOCK:
        return {"version":"4010.10","turns":len(_HISTORY),"mode":"executive-cognitive"}
