"""V2029 hybrid ASR / acoustic front-end regression checks.

Static checks plus a deterministic WebRTC/VAD helper test when webrtcvad is
installed. No real microphone or network is required.
"""
from pathlib import Path
import ast, math, os, types

p = Path(__file__).with_name("friday_backend.py")
s = p.read_text(encoding="utf-8")

checks = {
    "hybrid engine default": 'STT_ENGINE = os.getenv("FRIDAY_STT_ENGINE", "hybrid")' in s,
    "WebRTC optional import": "import webrtcvad as _webrtcvad" in s,
    "VAD fusion helper": "def _speech_decision(" in s,
    "hybrid recognizer": "def _recognize_hybrid(" in s,
    "parallel ASR": "ThreadPoolExecutor(max_workers=2" in s,
    "local fallback": "def _recognize_local_for_hybrid(" in s,
    "google fallback": "def _recognize_google_for_hybrid(" in s,
    "existing capture retained": "def _capture_until_silence(source):" in s,
    "existing command router retained": "def _recognize_best_match(audio):" in s,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + " - " + name)
assert all(checks.values())

# Verify the capture function still has no idle timeout cutoff.
start=s.index("def _capture_until_silence(source):")
end=s.index("def listen():", start)
capture=s[start:end]
assert "if chunks_read >= max_chunks" not in capture
assert "if speech_chunks >= max_speech_chunks" in capture

print("V2029 hybrid ASR static regression: PASS")
