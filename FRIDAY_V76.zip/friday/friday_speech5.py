"""FRIDAY 5.0 speech output.

Faster and interruptible replacement for the old "edge-tts -> temp mp3 -> PowerShell MediaPlayer" round trip:

  * synthesis happens in memory (no temp files), every sentence of a reply is synthesised in parallel and
    a disk cache makes repeated phrases ("Yes, sir.", "On it.") instant and available offline
  * playback is in-process (miniaudio decode -> PyAudio) when those libraries are present, so playback can start
    the moment audio exists, be ducked, and be stopped mid-word. Without them the old resident player is used.
  * interrupt() ends speech immediately (barge-in, "stop", a new typed command). Until begin_turn() is called
    again every later speak() of the same turn is skipped, so a half-generated answer never talks over the user.

Public API (all thread safe): usable(), say(), prefetch(), interrupt(), begin_turn(), is_aborted(), is_playing(),
duck(), warm_cache(), health().
"""
from __future__ import annotations

import asyncio
import hashlib
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Dict, Optional, Tuple

HERE = Path(__file__).resolve().parent
CACHE_DIR = Path(os.environ.get("FRIDAY_DATA") or (HERE / "friday_data")) / "speech_cache"
CACHE_MAX_FILES = 400

_enabled = os.getenv("FRIDAY_V5_SPEECH", "1").strip().lower() in {"1", "true", "yes", "on"}
_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="Friday5TTS")
_futures: Dict[Tuple[str, str, str], "object"] = {}
_lock = threading.Lock()

_abort = threading.Event()
_playing = threading.Event()
_gain = [1.0]
_fail_count = [0]
_retry_at = [0.0]
_last = {"first_audio_ms": None, "synth_ms": None}

# test seams / fallbacks (the backend sets legacy_play_file to its resident PowerShell player)
synth_override: Optional[Callable[[str, str, str], bytes]] = None
player_override: Optional[Callable[[bytes, Callable[[], bool], Callable[[], float]], None]] = None
legacy_play_file: Optional[Callable[[str, float], None]] = None
legacy_stop: Optional[Callable[[], None]] = None


# ---------------------------------------------------------------- state
def usable() -> bool:
    if not _enabled:
        return False
    if _fail_count[0] >= 3 and time.time() < _retry_at[0]:
        return False
    if synth_override is not None:
        return True
    try:
        import edge_tts  # noqa: F401
    except Exception:
        return False
    return True


def begin_turn():
    _abort.clear()


def interrupt():
    """Stop speaking right now and stay quiet until begin_turn()."""
    _abort.set()
    try:
        if legacy_stop is not None:
            legacy_stop()
    except Exception:
        pass


def is_aborted() -> bool:
    return _abort.is_set()


def is_playing() -> bool:
    return _playing.is_set()


def duck(on: bool):
    _gain[0] = 0.22 if on else 1.0


# ---------------------------------------------------------------- synthesis
def _key(text: str, voice: str, rate: str):
    return (text, voice, rate)


def _cache_path(text: str, voice: str, rate: str) -> Path:
    h = hashlib.sha1(f"{voice}|{rate}|{text}".encode("utf-8")).hexdigest()[:20]
    return CACHE_DIR / f"{h}.mp3"


def _edge_synth(text: str, voice: str, rate: str) -> bytes:
    import edge_tts  # type: ignore

    async def _go():
        comm = edge_tts.Communicate(text, voice=voice, rate=rate, volume="+0%", pitch="+0Hz")
        buf = bytearray()
        async for chunk in comm.stream():
            if chunk.get("type") == "audio":
                buf += chunk["data"]
        return bytes(buf)

    return asyncio.run(asyncio.wait_for(_go(), timeout=30))


def _synthesise(text: str, voice: str, rate: str, use_cache: bool = True) -> bytes:
    p = _cache_path(text, voice, rate)
    if use_cache and p.exists() and p.stat().st_size > 800:
        try:
            return p.read_bytes()
        except Exception:
            pass
    t0 = time.time()
    data = synth_override(text, voice, rate) if synth_override else _edge_synth(text, voice, rate)
    if not data or len(data) < 800:
        raise RuntimeError("speech synthesis returned no audio")
    _last["synth_ms"] = round((time.time() - t0) * 1000)
    if use_cache and len(text) <= 90:                         # short, reusable phrases only
        try:
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
            files = sorted(CACHE_DIR.glob("*.mp3"), key=lambda f: f.stat().st_mtime)
            for old in files[:-CACHE_MAX_FILES]:
                old.unlink(missing_ok=True)
        except Exception:
            pass
    return data


def prefetch(text: str, voice: str, rate: str):
    """Start synthesising a sentence that is about to be spoken. Never raises."""
    try:
        if not usable():
            return None
        k = _key(text, voice, rate)
        with _lock:
            fut = _futures.get(k)
            if fut is None:
                fut = _pool.submit(_synthesise, text, voice, rate)
                _futures[k] = fut
                if len(_futures) > 64:
                    for old in list(_futures)[:16]:
                        _futures.pop(old, None)
            return fut
    except Exception:
        return None


# ---------------------------------------------------------------- playback
def _decode(mp3: bytes):
    """mp3 -> (int16 mono PCM bytes, sample_rate) with miniaudio, then soundfile."""
    try:
        import miniaudio  # type: ignore
        d = miniaudio.decode(mp3, output_format=miniaudio.SampleFormat.SIGNED16, nchannels=1, sample_rate=24000)
        return d.samples.tobytes(), 24000
    except Exception:
        pass
    try:
        import io
        import numpy as np
        import soundfile as sf  # type: ignore
        data, sr = sf.read(io.BytesIO(mp3), dtype="int16", always_2d=True)
        return np.ascontiguousarray(data[:, 0]).tobytes(), int(sr)
    except Exception:
        return None


def _fire(on_start):
    """FRIDAY 6.3: tell the caller the audio is about to be heard (used to show the reply text at the same moment)."""
    if on_start is not None:
        try:
            on_start()
        except Exception:
            pass


def _play_inproc(mp3: bytes, on_start=None) -> bool:
    dec = _decode(mp3)
    if dec is None:
        return False
    pcm, rate = dec
    try:
        import numpy as np
        import pyaudio  # type: ignore
    except Exception:
        return False
    pa = pyaudio.PyAudio()
    stream = None
    try:
        stream = pa.open(format=pyaudio.paInt16, channels=1, rate=rate, output=True, frames_per_buffer=int(rate * 0.02))
        chunk = int(rate * 0.04) * 2
        _playing.set()
        started = False
        for i in range(0, len(pcm), chunk):
            if _abort.is_set():
                break
            block = pcm[i:i + chunk]
            g = _gain[0]
            if g < 0.99:
                block = (np.frombuffer(block, dtype=np.int16).astype(np.float32) * g).astype(np.int16).tobytes()
            if not started:
                started = True
                _fire(on_start)          # the very first sound is about to leave the speaker: show the reply now
            stream.write(block)
        return True
    finally:
        try:
            if stream is not None:
                stream.stop_stream()
                stream.close()
        except Exception:
            pass
        try:
            pa.terminate()
        except Exception:
            pass


def _play_legacy(mp3: bytes, on_start=None) -> bool:
    if legacy_play_file is None:
        return False
    import tempfile
    f = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    f.write(mp3)
    f.close()
    try:
        _playing.set()
        _fire(on_start)
        legacy_play_file(f.name, 60.0)
        return True
    finally:
        try:
            os.unlink(f.name)
        except OSError:
            pass


def say(text: str, voice: str, rate: str, on_start=None) -> bool:
    """Speak one sentence, blocking until it has been heard or interrupted. Raises if no audio path worked."""
    if _abort.is_set():
        return True
    text = (text or "").strip()
    if not text:
        return True
    t0 = time.time()
    try:
        fut = prefetch(text, voice, rate) or _pool.submit(_synthesise, text, voice, rate)
        mp3 = fut.result(timeout=45)
        if _abort.is_set():
            return True
        _last["first_audio_ms"] = round((time.time() - t0) * 1000)
        if player_override is not None:
            _playing.set()
            _fire(on_start)
            player_override(mp3, _abort.is_set, lambda: _gain[0])
            ok = True
        else:
            ok = _play_inproc(mp3, on_start) or _play_legacy(mp3, on_start)
        if not ok:
            raise RuntimeError("no audio playback path available")
        _fail_count[0] = 0
        return True
    except Exception:
        _fail_count[0] += 1
        if _fail_count[0] >= 3:
            _retry_at[0] = time.time() + 120.0
        raise
    finally:
        _playing.clear()
        with _lock:
            _futures.pop(_key(text, voice, rate), None)


def warm_cache(phrases, voice: str, rate: str):
    """Pre-synthesise short stock phrases in the background (instant acknowledgements, offline-safe)."""
    def _w():
        for ph in phrases:
            try:
                _synthesise(ph, voice, rate)
            except Exception:
                return
    threading.Thread(target=_w, name="Friday5TTSWarm", daemon=True).start()


def health() -> dict:
    return {"engine": "friday_speech5", "enabled": _enabled, "usable": usable(), "failures": _fail_count[0],
            "last": dict(_last), "cache_files": len(list(CACHE_DIR.glob("*.mp3"))) if CACHE_DIR.exists() else 0}
