"""FRIDAY 7.0 context and continuity manager (roadmap #9).

Before a related task starts, find what actually exists - an interrupted mission, an objective with an unfinished milestone, project notes,
earlier verified work - and offer to continue from the last *verified* checkpoint.  When several continuations fit, FRIDAY asks which one.
Everything reported comes from stored records; nothing about the past is ever invented.

    related(goal)        ranked candidates {kind, ref, title, score, state, checkpoint, when}
    preflight(goal)      {"mode": "none"|"continue"|"ask", "candidates": [...], "text": spoken line}
    resume(candidate)    resumes from the last verified step (mission) or starts the next milestone (objective)
    choose(text)         answers a pending "which one?" question ("the first", "the second", "the report one")
    context_for(goal)    short, dated, source-labelled text for the model prompt
"""
from __future__ import annotations

import re
import time
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

_pending: Dict = {"cands": [], "ts": 0.0, "goal": ""}
ASK_GAP = 0.12            # candidates closer than this are ambiguous
MIN_SCORE = 0.38
PENDING_TTL = 300.0


def _verified_checkpoint(job: Dict) -> Dict:
    plan = job.get("plan") or []
    done = [s for s in plan if s.get("status") == "done"]
    nxt = next((s for s in plan if s.get("status") not in ("done", "skipped") and not s.get("optional")), None)
    return {"done_steps": len(done), "total_steps": len(plan), "last_verified": done[-1]["desc"] if done else "", "next_step": nxt["desc"] if nxt else ""}


def related(goal: str, k: int = 4) -> List[Dict]:
    out: List[Dict] = []
    now = time.time()
    # 1) missions that did not finish (resumable) or finished with partial results
    try:
        import friday_orchestrator7 as O
        for j in O.jobs(40, ("paused", "partial", "failed", "cancelled")):
            if C.now() - j["created"] > 14 * 86400:
                continue
            s = C.similarity(goal, j["goal"])
            if s >= MIN_SCORE:
                cp = _verified_checkpoint(j)
                if cp["done_steps"] or j["state"] == "paused":
                    out.append({"kind": "mission", "ref": j["jid"], "title": j["goal"], "score": s + 0.06 + 0.06 * (j["state"] == "paused"), "state": j["state"], "checkpoint": cp, "when": j["created"]})
    except Exception:
        pass
    # 2) objectives with an unfinished milestone
    try:
        import friday_goals7 as G
        for o in G.objectives():
            s = max(C.similarity(goal, o["title"]), max([C.similarity(goal, m["text"]) for m in o["milestones"]] or [0]))
            if s >= MIN_SCORE and o["progress"] < 100:
                nxt = G.next_ready(o["oid"])
                out.append({"kind": "objective", "ref": o["oid"], "title": o["title"], "score": s + 0.08, "state": o["status"],
                            "checkpoint": {"progress": o["progress"], "next_step": nxt["text"] if nxt else "", "blocked": [b["text"] for b in o["blockers"]]}, "when": o["updated"]})
    except Exception:
        pass
    # 3) project notes (unfinished work, decisions)
    try:
        import friday_memory7 as M
        for p in M.projects()[:10]:
            s = C.similarity(goal, p["project"])
            if s >= 0.45 or p["project"] in goal.lower():
                st = M.project_state(p["project"])
                if st.get("unfinished"):
                    out.append({"kind": "project", "ref": p["project"], "title": f"project {p['project']}", "score": max(s, 0.5) + 0.04, "state": "unfinished work",
                                "checkpoint": {"unfinished": [u["text"] for u in st["unfinished"][:3]], "last_decision": (st["decision"][0]["text"] if st.get("decision") else "")},
                                "when": now})
    except Exception:
        pass
    # 4) earlier verified work (for reference - never resumed, only mentioned)
    try:
        import friday_orchestrator7 as O
        for j in O.jobs(40, ("done",)):
            s = C.similarity(goal, j["goal"])
            if s >= 0.6 and C.now() - j["created"] < 30 * 86400:
                out.append({"kind": "finished", "ref": j["jid"], "title": j["goal"], "score": s - 0.1, "state": "done", "checkpoint": _verified_checkpoint(j), "when": j["created"]})
    except Exception:
        pass
    out.sort(key=lambda c: -c["score"])
    return out[:k]


def preflight(goal: str) -> Dict:
    cands = [c for c in related(goal) if c["kind"] != "finished"]
    if not cands:
        fin = [c for c in related(goal) if c["kind"] == "finished"]
        if fin:
            return {"mode": "none", "candidates": fin[:1], "text": ""}
        return {"mode": "none", "candidates": [], "text": ""}
    if len(cands) == 1 or cands[0]["score"] - cands[1]["score"] >= ASK_GAP:
        c = cands[0]
        return {"mode": "continue", "candidates": [c], "text": _describe(c, ask=False)}
    return {"mode": "ask", "candidates": cands[:3], "text": "I have more than one thing this could continue: " + " ".join(f"{i + 1}. {_describe(c, ask=True)}" for i, c in enumerate(cands[:3])) + " Which one?"}


def _describe(c: Dict, ask: bool) -> str:
    cp = c["checkpoint"]
    when = K.ago(c["when"])
    if c["kind"] == "mission":
        step = f" Last confirmed: {cp['last_verified']}." if cp.get("last_verified") else ""
        return f"The mission '{c['title'][:60]}' ({c['state']}, {when}), {cp['done_steps']} of {cp['total_steps']} steps verified.{step}" if not ask else f"mission '{c['title'][:50]}' ({cp['done_steps']} of {cp['total_steps']} steps verified)."
    if c["kind"] == "objective":
        return (f"The objective '{c['title'][:60]}' is {cp['progress']} percent done" + (f"; next is {cp['next_step']}" if cp.get("next_step") else "") + ("; blocked: " + cp["blocked"][0] if cp.get("blocked") else "") + ".") if not ask else \
               f"objective '{c['title'][:50]}' ({cp['progress']} percent)."
    if c["kind"] == "project":
        u = cp["unfinished"][0] if cp.get("unfinished") else ""
        return f"{c['title']} has unfinished work: {u}." if not ask else f"{c['title']} (unfinished: {u[:50]})."
    return c["title"]


def resume(c: Dict) -> Dict:
    if c["kind"] == "mission":
        try:
            import friday_orchestrator7 as O
            jid = O.resume(c["ref"])
            return {"ok": bool(jid), "text": "Resuming from the last verified step." if jid else "That mission can't be resumed right now.", "jid": jid}
        except Exception as exc:
            return {"ok": False, "text": f"I couldn't resume it: {exc}"}
    if c["kind"] == "objective":
        import friday_goals7 as G
        r = G.run_next(c["ref"])
        return {"ok": r["ok"], "text": f"Starting: {r['milestone']}." if r["ok"] else f"I can't continue it yet: {r['error']}.", "jid": r.get("jid")}
    if c["kind"] == "project":
        cp = c["checkpoint"]
        return {"ok": True, "text": "Here is where that stands. Unfinished: " + "; ".join(cp.get("unfinished", [])[:3]) + (f". Last decision: {cp['last_decision']}" if cp.get("last_decision") else "") + ". Tell me which to pick up."}
    return {"ok": False, "text": "There's nothing to resume there."}


# ------------------------------------------------------------------ the pending question
def ask(goal: str, cands: List[Dict]):
    _pending.update({"cands": cands, "ts": time.time(), "goal": goal})


def pending() -> bool:
    return bool(_pending["cands"]) and time.time() - _pending["ts"] < PENDING_TTL


def choose(text: str) -> Optional[Dict]:
    if not pending():
        return None
    t = K.norm_cmd(text)
    cands = _pending["cands"]
    if re.match(r"^(?:none|neither|nothing|never ?mind|cancel|no)\b", t):
        _pending["cands"] = []
        return {"ok": True, "text": "Alright, I'll leave them alone and treat this as new."}
    pick: Optional[Dict] = None
    m = re.match(r"^(?:the\s+)?(first|second|third|1st|2nd|3rd|one|two|three|\d)\b", t)
    if m:
        n = K.ordinal_to_int(m.group(1))
        if n and 1 <= n <= len(cands):
            pick = cands[n - 1]
    if not pick:
        for kind in ("mission", "objective", "project"):
            if re.search(rf"\b{kind}\b", t) and sum(1 for c in cands if c["kind"] == kind) == 1:
                pick = next(c for c in cands if c["kind"] == kind)
                break
    if not pick:
        sc = sorted(((C.similarity(t, c["title"]), c) for c in cands), key=lambda x: -x[0])
        if sc and sc[0][0] >= 0.4 and (len(sc) == 1 or sc[0][0] - sc[1][0] >= 0.1):
            pick = sc[0][1]
    if not pick:
        if len(t.split()) > 3:           # a fresh request, not an answer to my question: drop the question and let the request through
            _pending["cands"] = []
            return None
        return {"ok": False, "text": "I'm not sure which you mean. Say the first, the second, or part of the name."}
    _pending["cands"] = []
    return resume(pick)


# ------------------------------------------------------------------ prompt context & chat
def context_for(goal: str) -> str:
    """Only recorded facts, each with how old it is. Empty when nothing relevant exists."""
    cs = related(goal, 2)
    if not cs:
        return ""
    lines = [f"- {c['kind']} ({K.ago(c['when'])}): {_describe(c, ask=True)}" for c in cs]
    return "\n\nRecorded earlier work that may be related (state only what is recorded here):\n" + "\n".join(lines)


_RX_CONTINUE = re.compile(r"^(?:continue|resume|carry on|pick up|go back to|get back to)\s+(?:with\s+|on\s+)?(?:where (?:we|i|you) left off|what we were doing|my (?:last|previous) (?:work|task|project)|(?:the |that )?(?:last|previous) (?:one|task|thing))(?:\s+on (.+))?$|^where (?:did|were) (?:we|i) (?:leave off|stop|get to)\??$", re.I)
_RX_CONTINUE_X = re.compile(r"^(?:continue|resume|carry on(?: with)?|pick up|get back to|go back to)\s+(?:working on\s+|with\s+|on\s+)?(?:the\s+|my\s+)?(.{4,})$", re.I)


def handle(command: str) -> Optional[str]:
    raw = K.strip_wake(command).strip(" .!?")
    t = raw.lower()
    if not t:
        return None
    r = choose(command) if pending() else None
    if r is not None:
        return r["text"]
    m = _RX_CONTINUE.match(raw)
    topic = None
    if m:
        topic = (m.group(1) if m.lastindex else None) or ""
    else:
        m2 = _RX_CONTINUE_X.match(raw)
        if m2 and not re.match(r"^(?:mission|job|the mission|that mission|it|that|this)$", m2.group(1).strip(), re.I):
            # leave "resume the mission", "continue the story" etc. to the engines that own them: only handle when something recorded matches
            topic = m2.group(1)
            if not related(topic, 1):
                return None
        else:
            return None
    if topic:
        pf = preflight(topic)
    else:
        # nothing named: look at the most recent unfinished things of any kind
        cands = []
        try:
            import friday_orchestrator7 as O
            for j in O.jobs(5, ("paused", "partial", "failed")):
                cands.append({"kind": "mission", "ref": j["jid"], "title": j["goal"], "score": 0.9, "state": j["state"], "checkpoint": _verified_checkpoint(j), "when": j["created"]})
            import friday_goals7 as G
            for o in G.objectives()[:3]:
                nxt = G.next_ready(o["oid"])
                cands.append({"kind": "objective", "ref": o["oid"], "title": o["title"], "score": 0.85, "state": o["status"],
                              "checkpoint": {"progress": o["progress"], "next_step": nxt["text"] if nxt else "", "blocked": [b["text"] for b in o["blockers"]]}, "when": o["updated"]})
        except Exception:
            pass
        cands = [c for c in cands if c["kind"] != "mission" or c["checkpoint"]["done_steps"] or c["state"] == "paused"][:3]
        if not cands:
            return "I don't have any unfinished missions or objectives on record, so I won't guess where we left off."
        pf = {"mode": "continue" if len(cands) == 1 else "ask", "candidates": cands,
              "text": _describe(cands[0], ask=False) if len(cands) == 1 else "I have more than one thing in progress: " + " ".join(f"{i + 1}. {_describe(c, ask=True)}" for i, c in enumerate(cands)) + " Which one?"}
    if pf["mode"] == "none":
        return "I don't have anything recorded that matches that, so I'll treat it as new."
    if pf["mode"] == "ask":
        ask(topic or "", pf["candidates"])
        return pf["text"]
    res = resume(pf["candidates"][0])
    return f"{pf['text']} {res['text']}"


def ui_snapshot() -> Dict:
    return {"candidates": [{k: v for k, v in c.items() if k != "score"} | {"score": round(c["score"], 2), "ago": K.ago(c["when"])} for c in related("", 0)] if False else [], "pending": pending()}
