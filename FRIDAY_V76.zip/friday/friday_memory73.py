"""FRIDAY 7.3 memory freshness  (upgrade 03) - old information must never be mistaken for a current fact.

memory7 already stores kind, source, source_ref, timestamp, confidence, supersession history, correction and deletion.  This adds the missing part:
a freshness judgement per item, derived from its age against the half-life of its kind, and a way to look at (and clear up) what may be outdated.

    fresh   younger than half the kind's half-life            - may be stated as current
    aging   up to one half-life old                           - state it WITH its date
    stale   older than one half-life, or lower confidence      - say "as of <date>" and offer to re-check; time-sensitive facts (prices, schedules) go stale faster
    flagged conflicts with another item                       - never stated as fact

`annotate()` adds `freshness`, `as_of` and `say` (a ready phrase with the date) to recall() results.  `stale_items()` lists what to re-confirm.
Nothing is deleted or changed automatically: the user inspects, corrects or removes items with the existing memory commands.
"""
from __future__ import annotations

import re
import time
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

_FAST = re.compile(r"\b(price|prices|costs?|rate|rates|today|tomorrow|this week|currently|right now|deadline|due|exam|appointment|meeting|rent|budget|balance|schedule|ticket)\b", re.I)


def _half_life_days(kind: str, text: str) -> float:
    try:
        import friday_memory7 as M
        base = float(M.HALF_LIFE_DAYS.get(kind, 180.0))
    except Exception:
        base = 180.0
    return min(base, 45.0) if _FAST.search(text or "") else base


def _item_ts(item: Dict) -> float:
    ts = item.get("ts")
    if isinstance(ts, (int, float)) and ts > 0:
        return float(ts)
    try:
        r = C.q("SELECT ts FROM mem7 WHERE id=?", (int(item.get("id", 0)),))
        if r:
            return float(r[0]["ts"])
    except Exception:
        pass
    return 0.0


def freshness(item: Dict, now: Optional[float] = None) -> Dict:
    now = now or time.time()
    ts = _item_ts(item)
    conf = float(item.get("confidence", 0.8) or 0.8)
    meta = item.get("meta") or {}
    if meta.get("conflicts_with"):
        return {"level": "flagged", "age_days": None, "as_of": "", "say": "I have conflicting notes about this, so I won't treat it as fact."}
    if ts <= 0:
        return {"level": "aging", "age_days": None, "as_of": "", "say": item.get("text", "")}
    age = max(0.0, (now - ts) / 86400.0)
    hl = _half_life_days(item.get("kind", "semantic"), item.get("text", ""))
    level = "fresh" if age < hl / 2 and conf >= 0.5 else "aging" if age <= hl and conf >= 0.4 else "stale"
    when = time.strftime("%d %b %Y", time.localtime(ts))
    text = item.get("text", "")
    say = text if level == "fresh" else f"As of {when}: {text}" if level == "aging" else f"As of {when} (may be out of date): {text}"
    return {"level": level, "age_days": round(age, 1), "as_of": when, "say": say}


def annotate(items: List[Dict]) -> List[Dict]:
    out = []
    for it in items:
        f = freshness(it)
        out.append({**it, "freshness": f["level"], "age_days": f["age_days"], "as_of": f["as_of"], "say": f["say"]})
    return out


def recall(query: str, k: int = 5, **kw) -> List[Dict]:
    import friday_memory7 as M
    return annotate(M.recall(query, k=k, **kw))


def stale_items(limit: int = 20) -> List[Dict]:
    try:
        rows = [dict(r) for r in C.q("SELECT * FROM mem7 WHERE status='active' ORDER BY ts ASC LIMIT 400")]
    except Exception:
        return []
    for r in rows:
        r["meta"] = K.jl(r.get("meta"), {})
    out = [{**r, **{"freshness": freshness(r)["level"], "as_of": freshness(r)["as_of"]}} for r in rows]
    return [r for r in out if r["freshness"] in ("stale", "flagged")][:limit]


def prompt_note(items: List[Dict]) -> str:
    """One line for the model prompt so it states old items with their date instead of as current fact."""
    ann = annotate(items)
    old = [a for a in ann if a["freshness"] in ("aging", "stale", "flagged")]
    if not old:
        return ""
    return "Memory caution: " + " | ".join(a["say"] for a in old[:3])


def handle(command: str) -> Optional[str]:
    low = K.norm_cmd(command)
    if re.match(r"^(?:what|which) (?:do you remember|memories|memory|facts) (?:that |which )?(?:might be|may be|are|is) (?:outdated|out of date|stale|old)\??$|^(?:show|list|check) (?:outdated|stale|old) memor(?:y|ies)$", low):
        s = stale_items(8)
        if not s:
            return "Nothing I remember looks out of date right now."
        return "These may be out of date: " + "; ".join(f"{r['text'][:80]} (from {r['as_of']})" for r in s) + ". Tell me which to correct or forget."
    return None
