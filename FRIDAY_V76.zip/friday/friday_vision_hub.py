"""
FRIDAY VISION HUB  -  the one door between FRIDAY and the OpenCV-5 vision / agent stack
=======================================================================================
* handle_command(text)  : spoken or typed commands ("turn on the camera", "agent: open my chemistry notes and verify it",
                          "run the vision benchmark" ...).  Returns True if it handled the text, otherwise None, so every
                          existing FRIDAY route keeps working exactly as before.  It also answers pending yes/no safety questions.
* handle_ui(payload)    : requests from the Vision page / Settings (get/set options, start camera, analyse a file, run the agent ...).
* emit(kind, payload)   : sends  VISION::<base64 json>  lines to the app UI (state, preview frame, agent progress, confirmations).

Long work always runs in its own daemon thread, so the microphone loop, the typed-command thread and the speech engine are never
blocked and nothing here touches how FRIDAY listens, recognises or speaks.
"""
from __future__ import annotations

import base64
import json
import re
import sys
import threading
import time
from pathlib import Path
from typing import Any, Optional

import friday_vision_config as cfg

_LOCK = threading.RLock()
_BASELINE: dict[str, Any] = {}
_AGENT_THREAD: Optional[threading.Thread] = None
_BENCH_THREAD: Optional[threading.Thread] = None
_LAST_STATE_PUSH = {"t": 0.0, "engine_sync": 0.0}
_WIRED = False
_PREVIEW = {"on": True}   # V7.6: live preview is on by default

IMG_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff", ".gif"}
VID_EXT = {".mp4", ".mkv", ".avi", ".mov", ".webm", ".m4v", ".wmv", ".3gp"}


# ----------------------------------------------------------------------------
# plumbing
# ----------------------------------------------------------------------------
def _backend():
    import friday_backend
    return friday_backend


def emit(kind: str, payload: Any = None, req: Optional[str] = None) -> None:
    try:
        msg = {"kind": kind, "data": payload}
        if req:
            msg["req"] = req
        # one single write so lines from different threads can never be interleaved mid-line
        sys.stdout.write("VISION::" + base64.b64encode(json.dumps(msg, default=str).encode("utf-8")).decode("ascii") + "\n")
        sys.stdout.flush()
    except Exception:
        pass


def _speak(text: str) -> None:
    try:
        if text:
            _backend().speak(text)
    except Exception:
        pass


def _log(text: str, kind: str = "info") -> None:
    try:
        _backend().log_event(text, kind=kind)
    except Exception:
        pass


def _engine():
    import friday_vision_engine as ve
    return ve


def _wire() -> None:
    """Connect the safety broker and the vision engine to the UI the first time anything is used."""
    global _WIRED
    if _WIRED:
        return
    _WIRED = True
    import friday_action_safety as safety
    safety.set_hooks(emit=lambda k, p: emit("safety_" + k, p), speak=_speak)
    try:
        ve = _engine()
        ve.subscribe(_on_engine_event)
    except Exception:
        pass


def _on_engine_event(kind: str, state: dict) -> None:
    now = time.time()
    if now - _LAST_STATE_PUSH["engine_sync"] > 3.0:
        _LAST_STATE_PUSH["engine_sync"] = now
        try:
            import friday_state_engine as se
            se.update("screen", summary=str(state.get("summary", ""))[:300], source=(state.get("source") or {}).get("kind"), objects=len(state.get("objects", [])), confidence=state.get("confidence"), ts=now)
        except Exception:
            pass


def _session_emit(kind: str, payload: dict) -> None:
    if kind == "state":
        ve = _engine()
        emit("state", ve.compact_state(payload))
    elif kind == "frame":
        emit("frame", payload)
    elif kind == "motion":
        emit("motion", payload)
        if payload.get("motion"):
            _log("Vision: motion detected", "result")
    elif kind == "notice":
        emit("notice", payload)
        _speak(payload.get("text", ""))
    elif kind == "stopped":
        emit("session", {"running": False, **payload})
        if payload.get("error"):
            _speak("The camera stopped: " + str(payload["error"]))


def _state_for_ui(state: dict) -> dict:
    return _engine().compact_state(state)


def _fail_text(exc: Exception) -> str:
    return str(exc).split("\n")[0][:220]


# ----------------------------------------------------------------------------
# actions (shared by voice and UI)
# ----------------------------------------------------------------------------
def camera_on(preview: bool = False, speak: bool = True) -> dict[str, Any]:
    _wire()
    ve = _engine()
    try:
        ve.SESSION.preview = bool(preview or _PREVIEW["on"])
        st = ve.SESSION.start("camera", _session_emit)
        emit("session", st)
        if speak:
            cloud = cfg.get("camera_allow_cloud")
            _speak("Camera vision is on. " + ("Frames may be analysed by Gemini or your cloud server because you allowed it." if cloud else "Everything stays on this computer.") + " Say turn off the camera whenever you like.")
        return {"ok": True, **st}
    except Exception as exc:
        emit("session", {"running": False, "error": _fail_text(exc)})
        if speak:
            _speak(_fail_text(exc))
        return {"ok": False, "error": _fail_text(exc)}


def _close_camera_apps() -> bool:
    """V3.1: the Windows Camera app (opened with "open camera") also holds the camera. Close it too. True if one was closed."""
    import os
    import subprocess
    if os.name != "nt":
        return False
    closed = False
    for exe in ("WindowsCamera.exe",):
        try:
            found = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {exe}", "/NH"], capture_output=True, text=True,
                                   timeout=6, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if exe.lower() in (found.stdout or "").lower():
                subprocess.run(["taskkill", "/F", "/T", "/IM", exe], capture_output=True, timeout=8,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                closed = True
        except Exception:
            pass
    return closed


def camera_off(speak: bool = True) -> dict[str, Any]:
    """V3.1: only says the camera is off after it has really been released."""
    ve = _engine()
    was = bool(ve.SESSION.running and ve.SESSION.kind == "camera")
    released = True
    if ve.SESSION.running:
        released = bool(ve.SESSION.stop())
    app_closed = _close_camera_apps()
    still = bool(ve.SESSION.running)
    emit("session", {"running": still})
    ok = released and not still
    if speak:
        if not ok:
            _speak("I asked the camera to stop, sir, but it has not released yet. Please give it a moment and ask me again.")
        elif was or app_closed:
            _speak("Camera off." if was else "I closed the Camera app, sir. The camera is off.")
        else:
            _speak("The camera was not on.")
    return {"ok": ok, "was_on": was, "app_closed": app_closed}


def screen_watch(on: bool, speak: bool = True) -> dict[str, Any]:
    _wire()
    ve = _engine()
    try:
        if on:
            ve.SESSION.preview = bool(_PREVIEW["on"])
            st = ve.SESSION.start("screen", _session_emit)
            emit("session", st)
            if speak:
                _speak("Screen vision is on. I am tracking changes and motion on your display.")
            return {"ok": True, **st}
        if ve.SESSION.running and ve.SESSION.kind == "screen":
            ve.SESSION.stop()
        emit("session", {"running": False})
        if speak:
            _speak("Screen vision off.")
        return {"ok": True}
    except Exception as exc:
        if speak:
            _speak(_fail_text(exc))
        return {"ok": False, "error": _fail_text(exc)}


def snapshot(kind: str = "screen", ask_gemini: Optional[bool] = None, question: str = "", speak: bool = True, ocr: bool = True) -> dict[str, Any]:
    _wire()
    ve = _engine()
    try:
        if kind == "camera":
            if ve.SESSION.running and ve.SESSION.kind == "camera" and ve.SESSION.last_frame is not None:
                frame = ve.SESSION.last_frame.copy()
                state = ve.analyze_frame(frame, "camera", label="camera", publish_state=False, do_ocr=False)
                use_g = cfg.get("camera_allow_cloud") if ask_gemini is None else ask_gemini
                if use_g:
                    g = ve.gemini_describe(frame, state, question, "camera")
                    if g.get("ok"):
                        state["scene"] = {"narrative": g["text"], "source": "gemini"}
                state["summary"] = ve.describe(state)
                state = ve.publish(state)
            else:
                use_g = cfg.get("camera_allow_cloud") if ask_gemini is None else ask_gemini
                state = ve.camera_snapshot(bool(use_g), question)
        else:
            use_g = bool(ask_gemini) if ask_gemini is not None else False
            state = ve.see_screen(ask_gemini=use_g, question=question, do_ocr=ocr)
        ui = _state_for_ui(state)
        try:                                   # V7.6: attach the exact picture that was analysed, with the detections drawn on it
            fr = ve._LAST_ANALYSED.get("frame")
            if fr is not None and abs(float(ve._LAST_ANALYSED.get("ts") or 0) - float(state.get("ts") or 0)) < 1e-6:
                ui["image"] = base64.b64encode(ve.encode_jpeg(ve.annotate_frame(fr, state, 960), 960, 78)).decode("ascii")
        except Exception:
            pass
        emit("snapshot", ui)
        if speak:
            _speak(state.get("summary") or "I could not make out anything.")
        return {"ok": True, "state": ui}
    except Exception as exc:
        if speak:
            _speak(_fail_text(exc))
        emit("notice", {"text": _fail_text(exc), "kind": "error"})
        return {"ok": False, "error": _fail_text(exc)}


def analyze_file(path: str, ask_gemini: bool = True, named: bool = False, speak: bool = True, question: str = "") -> dict[str, Any]:
    _wire()
    ve = _engine()
    p = Path(path)
    try:
        if not p.exists():
            raise FileNotFoundError(f"I can't find that file: {p.name or path}")
        ext = p.suffix.lower()
        if ext in VID_EXT:
            state = ve.analyze_video(str(p), ask_gemini=ask_gemini, progress=lambda f: emit("progress", {"what": "video", "fraction": round(f, 3)}))
        elif ext in IMG_EXT:
            state = ve.analyze_image(str(p), ask_gemini=ask_gemini, question=question, named_objects=named)
        else:
            raise ValueError("I can analyse pictures and videos. That file type is not one of them.")
        ui = _state_for_ui(state)
        ui["video"] = {k: v for k, v in (state.get("video") or {}).items() if k != "timeline"} if state.get("video") else None
        ui["video_timeline"] = [t["motion"] for t in (state.get("video") or {}).get("timeline", [])][-120:]
        emit("snapshot", ui)
        if speak:
            _speak(state.get("summary") or "Analysis complete.")
        return {"ok": True, "state": ui}
    except Exception as exc:
        if speak:
            _speak(_fail_text(exc))
        emit("notice", {"text": _fail_text(exc), "kind": "error"})
        return {"ok": False, "error": _fail_text(exc)}


def compare_view(kind: str = "screen", speak: bool = True) -> dict[str, Any]:
    """First call stores a baseline picture; later calls report what changed since then."""
    _wire()
    ve = _engine()
    try:
        if kind == "camera":
            if ve.SESSION.running and ve.SESSION.kind == "camera" and ve.SESSION.last_frame is not None:
                frame = ve.SESSION.last_frame.copy()
            else:
                raise RuntimeError("Turn the camera on first, then ask what changed.")
        else:
            frame = ve.grab_screen()
        base = _BASELINE.get(kind)
        _BASELINE[kind] = {"frame": frame, "t": time.time()}
        if base is None:
            msg = f"I have saved the current {kind} view. Ask me again later and I will tell you what changed."
            if speak:
                _speak(msg)
            return {"ok": True, "baseline": True, "message": msg}
        res = ve.compare_frames(base["frame"], frame)
        secs = int(time.time() - base["t"])
        where = ", ".join(sorted({r["where"] for r in res["regions"]})[:3])
        verdict = {"no_change": "Nothing has changed", "minor_change": "Only a small change", "significant_change": "Something changed", "major_change": "A lot has changed"}[res["verdict"]]
        msg = f"{verdict} since {secs} seconds ago" + (f", mostly in the {where} of the view" if res["regions"] and res["changed"] else "") + f". Confidence {round(res['confidence'] * 100)} percent."
        emit("change", {**{k: v for k, v in res.items()}, "message": msg, "kind": kind})
        if speak:
            _speak(msg)
        return {"ok": True, "result": res, "message": msg}
    except Exception as exc:
        if speak:
            _speak(_fail_text(exc))
        return {"ok": False, "error": _fail_text(exc)}


def find_on_screen(query: str, speak: bool = True) -> dict[str, Any]:
    _wire()
    ve = _engine()
    try:
        frame = ve.grab_screen()
        o = ve.ocr(frame)
        if o.get("engine") == "none":
            raise RuntimeError("Reading screen text needs Tesseract OCR. " + (o.get("error") or ""))
        hit = ve.find_text(frame, query, o)
        if not hit:
            msg = f"I can't see '{query}' on the screen right now."
        else:
            h, w = frame.shape[:2]
            msg = f"I can see '{query}' in the {ve.region_name(hit['center'][0], hit['center'][1], w, h)} of the screen."
        if speak:
            _speak(msg)
        return {"ok": True, "found": bool(hit), "hit": hit, "message": msg}
    except Exception as exc:
        if speak:
            _speak(_fail_text(exc))
        return {"ok": False, "error": _fail_text(exc)}


def motion_status(speak: bool = True) -> dict[str, Any]:
    ve = _engine()
    if not ve.SESSION.running:
        msg = "Vision is not running. Say turn on the camera first, then I can watch for movement."
        if speak:
            _speak(msg)
        return {"ok": False, "error": msg}
    st = ve.last_state()
    m = st.get("motion") or {}
    if m.get("motion"):
        d = m.get("direction")
        msg = "Yes, there is movement" + (f" toward the {d}" if d and d != "none" else "") + f" in the {ve.SESSION.kind} view."
    else:
        msg = f"I don't see any movement in the {ve.SESSION.kind} view right now."
    if speak:
        _speak(msg)
    return {"ok": True, "motion": bool(m.get("motion")), "message": msg}


# ----------------------------------------------------------------------------
# agent
# ----------------------------------------------------------------------------
def start_agent(goal: str, speak: bool = True) -> dict[str, Any]:
    global _AGENT_THREAD
    _wire()
    if not cfg.get("agent_enabled"):
        if speak:
            _speak("The vision agent is switched off in Settings.")
        return {"ok": False, "error": "agent disabled"}
    with _LOCK:
        if _AGENT_THREAD and _AGENT_THREAD.is_alive():
            if speak:
                _speak("I'm still working on the last task. Say stop the agent to cancel it.")
            return {"ok": False, "error": "busy"}
        import friday_vision_agent as va
        import friday_action_safety as safety

        def runner():
            try:
                res = va.run_goal(goal, va.RealEnv(), emit=lambda k, p: emit(k, p),
                                  ask_user=lambda q: safety.ask(q, safety.CONFIRM, {"tool": "verify", "text": q})[0],
                                  say=_speak)
                emit("agent_result", {k: v for k, v in res.items() if k != "steps"} | {"steps": [{kk: vv for kk, vv in s.items()} for s in res.get("steps", [])]})
                _log(f"Vision agent finished: {res['status']} ({res.get('seconds')}s)", "result")
                if speak:
                    _speak(res["summary"])
            except Exception as exc:
                emit("agent_result", {"ok": False, "status": "error", "summary": _fail_text(exc), "goal": goal})
                _speak("Something went wrong while I was working on that.")
        _AGENT_THREAD = threading.Thread(target=runner, name="FridayVisionAgent", daemon=True)
        _AGENT_THREAD.start()
        if speak:
            # spoken at once (own thread); the agent keeps working while she talks
            threading.Thread(target=_speak, args=("On it. I'll check the screen after each step.",), name="FridayVisionAck", daemon=True).start()
    return {"ok": True}


def stop_agent(speak: bool = True) -> dict[str, Any]:
    import friday_vision_agent as va
    try:
        import friday_agentic_vision as _av
        if _av._ACTIVE.get("running"):
            _av.stop()
    except Exception:
        pass
    running = bool(_AGENT_THREAD and _AGENT_THREAD.is_alive())
    va.cancel()
    if speak:
        _speak("Stopping." if running else "Nothing is running right now.")
    return {"ok": True, "was_running": running}


# ----------------------------------------------------------------------------
# evaluation
# ----------------------------------------------------------------------------
def run_benchmark(speak: bool = True) -> dict[str, Any]:
    global _BENCH_THREAD
    _wire()
    with _LOCK:
        if _BENCH_THREAD and _BENCH_THREAD.is_alive():
            return {"ok": False, "error": "A benchmark is already running."}

        def runner():
            import friday_eval_metrics as em
            try:
                res = em.run_suite(progress=lambda name, f: emit("bench_progress", {"step": name, "fraction": round(f, 3)}))
                emit("bench_done", res)
                if speak:
                    _speak(em.headline(res))
            except Exception as exc:
                emit("bench_done", {"error": _fail_text(exc)})
                if speak:
                    _speak("The benchmark could not finish: " + _fail_text(exc))
        _BENCH_THREAD = threading.Thread(target=runner, name="FridayVisionBench", daemon=True)
        _BENCH_THREAD.start()
        if speak:
            threading.Thread(target=_speak, args=("Running the vision benchmark. This takes about a minute.",), name="FridayVisionAck", daemon=True).start()
    return {"ok": True}


def metrics_summary_text() -> str:
    import friday_eval_metrics as em
    s = em.snapshot()
    c, r, lat = s["counters"], s["rates"], s["latency"]
    parts = []
    if c["tasks"]:
        parts.append(f"{c['tasks_ok']} of {c['tasks']} agent tasks succeeded")
    if c["verifications"]:
        parts.append(f"{c['verifications_ok']} of {c['verifications']} visual checks passed")
    if c["recoveries"]:
        parts.append(f"{c['recoveries_ok']} of {c['recoveries']} recoveries worked")
    if lat.get("vision_avg_ms") is not None:
        parts.append(f"average vision processing {round(lat['vision_avg_ms'])} milliseconds")
    if not parts:
        return "I have no live numbers yet. Run a few vision tasks, or say run the vision benchmark."
    return "So far, " + ", ".join(parts) + "."


def export_report(speak: bool = True) -> dict[str, Any]:
    import friday_eval_metrics as em
    try:
        cloud = None
        try:
            import friday_vision_cloud as vc
            if cfg.get("cloud_url"):
                cloud = vc.compare_local_vs_cloud()
        except Exception:
            cloud = None
        paths = em.export_report(cloud=cloud)
        emit("report", paths)
        if speak:
            _speak("The evaluation report is saved in your FRIDAY data folder, in the exports folder.")
        return {"ok": True, **paths}
    except Exception as exc:
        if speak:
            _speak("I could not write the report: " + _fail_text(exc))
        return {"ok": False, "error": _fail_text(exc)}


def vision_status(speak: bool = True) -> dict[str, Any]:
    ve = _engine()
    env = ve.environment()
    if not env.get("available"):
        msg = "OpenCV is not installed yet. Run the FRIDAY setup again, or install opencv-python-headless."
    else:
        d = ve.detector_status()
        msg = (f"OpenCV {env['opencv_version']} is ready" + (" with the new OpenCV 5 deep-learning engine" if env.get("opencv5") else "") + ". "
               + ("A custom ONNX detector is loaded. " if d.get("onnx_loaded") else "I am using the built-in detectors. ")
               + ("The cloud server is on. " if cfg.get("cloud_enabled") else "")
               + ("The camera is on." if ve.SESSION.running and ve.SESSION.kind == "camera" else "The camera is off."))
    if speak:
        _speak(msg)
    return {"ok": True, "message": msg, "environment": env}


# ----------------------------------------------------------------------------
# attachments helper
# ----------------------------------------------------------------------------
def _attached_media() -> Optional[str]:
    try:
        ctx = getattr(_backend(), "_ATTACHED_CONTEXT", []) or []
        for item in reversed(ctx):
            if item.get("kind") in ("image", "video") and item.get("path"):
                return item["path"]
    except Exception:
        pass
    return None


_PATH_RE = re.compile(r"(?:\"([^\"]+\.[A-Za-z0-9]{2,5})\"|'([^']+\.[A-Za-z0-9]{2,5})'|([A-Za-z]:[\\/][^\"'\n]*?\.[A-Za-z0-9]{2,5}))")


def _extract_path(text: str) -> Optional[str]:
    m = _PATH_RE.search(text or "")
    if m:
        return next(g for g in m.groups() if g)
    return None


# ----------------------------------------------------------------------------
# voice / typed command router
# ----------------------------------------------------------------------------
_RE = {
    # Explicit camera toggles: accept both "turn on the camera" and
    # "turn the camera on", including natural spoken fillers, without
    # touching the microphone/listening/recognition pipeline.
    "cam_on": re.compile(r"\b(?:turn|switch|power)\s+(?:the\s+|my\s+)?(?:camera|web\s?cam)(?:\s+vision)?\s+on\b|\b(?:turn|switch|power)\s+on\b(?:\s+the|\s+my)?\s+(?:web\s?cam|camera)(?:\s+vision)?\b|\b(?:enable|activate|start)\b(?:\s+the|\s+my)?\s+(?:web\s?cam|camera)(?:\s+vision)?\b|\bcamera\s+(?:vision\s+)?on\b|\bstart\s+camera\s+vision\b", re.I),
    "cam_off": re.compile(r"\b(?:turn|switch|power|shut)\s+(?:the\s+|my\s+)?(?:camera|web\s?cam)(?:\s+vision)?\s+(?:off|down)\b|\b(?:turn|switch|power)\s+off\b(?:\s+the|\s+my)?\s+(?:web\s?cam|camera)(?:\s+vision)?\b|\b(?:disable|deactivate|stop|close|release|kill|end)\b(?:\s+the|\s+my)?\s+(?:web\s?cam|camera)(?:\s+vision)?\b|\b(?:web\s?cam|camera)\s+(?:off|vision off)\b|\bstop\s+camera\s+vision\b|\bstop\s+using\s+(?:the\s+|my\s+)?(?:web\s?cam|camera)\b", re.I),
    "cam_look": re.compile(r"\bwhat(?:'s| is| do| can)?\b.{0,25}\b(?:see|in front of|on)\b.{0,25}\bcamera\b|\b(?:look|see)\s+(?:through|with|at)\s+(?:the |my )?camera\b|\buse\s+(?:the |my )?camera\s+to\b|\bcamera\s+(?:view|snapshot|snap)\b", re.I),
    "see_bare": re.compile(r"^\s*(?:what\s+(?:do|can)\s+(?:you|u)\s+see(?:\s+now|\s+right now)?|what(?:'s| is) in front of (?:you|u)|describe what you see)\s*[?.!]*\s*$", re.I),
    "screen_cv": re.compile(r"\b(?:opencv|open cv|vision engine)\b.{0,40}\b(?:screen|desktop|display)\b|\b(?:screen|desktop)\b.{0,30}\b(?:with|using)\s+(?:opencv|open cv)\b|\bis there an?\s+(?:error|problem|warning)(?:\s+message)?\s+on\s+(?:my\s+|the\s+)?screen\b|\bany\s+errors?\s+on\s+(?:my\s+|the\s+)?screen\b|\b(?:read|extract|get)\s+(?:all\s+)?(?:the\s+)?text\s+(?:on|from)\s+(?:my\s+|the\s+)?screen\b|\bdetect\s+(?:the\s+)?(?:objects?|elements|buttons)\s+on\s+(?:my\s+|the\s+)?screen\b", re.I),
    "find_screen": re.compile(r"\b(?:where(?:'s| is)|find|locate)\s+(?:the\s+)?[\"']?(.{2,40}?)[\"']?\s+(?:button\s+)?on\s+(?:my\s+|the\s+)?screen\b", re.I),
    "motion": re.compile(r"\b(?:is|was)\s+(?:there\s+)?(?:anything|anyone|something|someone)\s+(?:moving|move[ds]?|changing)\b|\bany\s+motion\b|\bdetect\s+motion\b|\bdid\s+(?:anything|something)\s+move\b", re.I),
    "changed": re.compile(r"\bwhat(?:'s| has| have)?\s+changed\b|\bany(?:thing)?\s+(?:visual\s+)?changes?\s+(?:on|in)\b|\bcompare\s+(?:the\s+)?(?:screen|view|camera)\b|\bwhat\s+is\s+different\b", re.I),
    "analyze": re.compile(r"\b(?:analy[sz]e|inspect|look at|describe|detect objects in|track objects in)\b.{0,40}\b(?:image|picture|photo|video|clip|recording)\b", re.I),
    "bench": re.compile(r"\b(?:run|start|do)\b.{0,20}\b(?:the\s+)?(?:vision|opencv|agent|evaluation|performance)?\s*benchmarks?\b", re.I),
    "report": re.compile(r"\b(?:evaluation|performance|metrics?)\s+report\b|\b(?:export|save|generate|create)\b.{0,25}\b(?:evaluation|performance|metrics)\b", re.I),
    "metrics": re.compile(r"\bhow\s+(?:well|accurate)\s+are\s+you\s+(?:doing|performing|working)\b|\bshow\s+(?:me\s+)?(?:your\s+)?(?:vision\s+|agent\s+)?(?:metrics|stats|success rate)\b|\b(?:vision|agent)\s+(?:metrics|stats)\b", re.I),
    "status": re.compile(r"\b(?:vision|opencv|open cv)\s+status\b|\bwhich\s+opencv\b|\bis\s+opencv\s+(?:ready|working|installed)\b", re.I),
    "agent": re.compile(r"^\s*(?:friday[, ]+)?(?:agent(?:\s+mode)?|verified|verify and|carefully)\s*[:,\-]?\s*(.+)$", re.I),
    "verify_tail": re.compile(r"^(.*?\b(?:open|launch|search|close|click|type|go to|find)\b.*?)[,]?\s+(?:and\s+)?(?:then\s+)?(?:verify|check|make sure|confirm)\b(?:\s+(?:that|it|they))?.{0,40}$", re.I),
    "stop_agent": re.compile(r"^\s*(?:stop|cancel|abort)\s+(?:the\s+)?(?:agent|task|that|everything|vision agent)\b", re.I),
}


# ----------------------------------------------------------------------------
# FRIDAY 6.3: word-order-free camera on/off detection.
# "on my camera", "camera on please", "put the camera on", "can you switch my webcam off" all work; questions
# ("is the camera on?", "what's on my camera") and look/describe requests are NOT toggles.
# ----------------------------------------------------------------------------
_CAM_NOUN = {"camera", "cameras", "webcam", "webcams", "cam", "web"}
_CAM_FILLER = {"the", "my", "your", "our", "a", "this", "that", "vision", "live", "please", "now", "for", "me", "sir", "friday",
               "it", "hey", "ok", "okay", "can", "could", "would", "will", "you", "i", "want", "need", "to", "go", "ahead",
               "just", "kindly", "so", "and", "then", "again", "back", "also", "up", "down", "of", "laptop", "built", "in", "pc", "computer"}
_CAM_ON_WORDS = {"on", "start", "enable", "activate", "turn", "switch", "power", "put", "bring", "get", "fire", "boot", "run", "resume", "restart", "begin", "launch"}
_CAM_OFF_WORDS = {"off", "stop", "disable", "deactivate", "close", "shut", "shutdown", "release", "kill", "end", "pause", "halt", "cut", "terminate"}


def camera_toggle_intent(text: str):
    """'on' / 'off' when the sentence is only a request to switch the camera on or off, otherwise None."""
    try:
        low = re.sub(r"[^a-z0-9' ]+", " ", (text or "").lower())
        words = low.split()
        if not words or len(words) > 12:
            return None
        if not any(w in _CAM_NOUN for w in words):
            return None
        rest = [w for w in words if w not in _CAM_NOUN and w not in _CAM_FILLER]
        if not rest:
            return None
        off = [w for w in rest if w in _CAM_OFF_WORDS]
        on = [w for w in rest if w in _CAM_ON_WORDS]
        if any(w not in _CAM_OFF_WORDS and w not in _CAM_ON_WORDS for w in rest):
            return None                      # anything else in the sentence (is, what, see, describe, open ...) -> not a plain toggle
        if off and not (on and not any(w in ("off", "stop", "close", "shut", "kill", "release", "disable", "deactivate", "end", "shutdown") for w in off)):
            return "off"
        if on and not off:
            if rest == ["turn"] or rest == ["switch"] or rest == ["put"]:
                return None                  # "turn the camera" alone is not clear
            return "on"
        return None
    except Exception:
        return None


def handle_command(text: str) -> Optional[bool]:
    """Claim only explicit vision / agent requests. Returns True when handled, None to let FRIDAY continue as normal."""
    t = (text or "").strip()
    if not t:
        return None
    low = t.lower()
    # 1) answers to a pending safety question ("yes", "no", "confirm", "cancel")
    try:
        import friday_action_safety as safety
        if safety.pending():
            reply = safety.resolve_from_text(t)
            if reply is not None:
                if reply:
                    _speak(reply)
                return True
    except Exception:
        pass
    # quick reject: nothing vision-like in the sentence
    if not re.search(r"camera|vision|opencv|open cv|agent|verif|benchmark|evaluation|metrics|motion|changed|different|screen|image|picture|photo|video|clip|recording|see|stop|cancel|abort|performance|check|confirm|make sure", low):
        return None
    try:
        m = _RE["stop_agent"].match(t)
        if m:
            import friday_vision_agent as va
            if _AGENT_THREAD and _AGENT_THREAD.is_alive():
                stop_agent()
                return True
            return None
        m = _RE["agent"].match(t)
        if m and m.group(1):
            start_agent(m.group(1).strip())
            return True
        _toggle = camera_toggle_intent(t)
        if _toggle is None and re.match(r"^\s*(?:friday[, ]+)?(?:is|are|was|were|does|did|has|have)\b.{0,30}\b(?:camera|web\s?cam)\b", low):
            # a QUESTION about the camera ("is my camera on?") is answered from the real state, never treated as a switch
            import friday_vision_engine as _ve_q
            _on = bool(_ve_q.SESSION.running and _ve_q.SESSION.kind == "camera")
            _speak("Yes sir, the camera is on." if _on else "No sir, the camera is off. Say turn on the camera when you want it.")
            return True
        if _toggle == "off" or _RE["cam_off"].search(t):
            camera_off()
            return True
        if _toggle == "on" or _RE["cam_on"].search(t):
            camera_on()
            return True
        if _RE["cam_look"].search(t):
            threading.Thread(target=snapshot, kwargs={"kind": "camera"}, name="FridayVisionSnap", daemon=True).start()
            return True
        if _RE["see_bare"].match(t):
            import friday_vision_engine as ve
            if ve.SESSION.running and ve.SESSION.kind == "camera":
                threading.Thread(target=snapshot, kwargs={"kind": "camera"}, name="FridayVisionSnap", daemon=True).start()
                return True
            return None                                        # not a camera session: leave it to the existing screen/AI routes
        m = _RE["find_screen"].search(t)
        if m:
            threading.Thread(target=find_on_screen, args=(m.group(1).strip(),), name="FridayVisionFind", daemon=True).start()
            return True
        if _RE["screen_cv"].search(t):
            threading.Thread(target=snapshot, kwargs={"kind": "screen", "ask_gemini": False}, name="FridayVisionScreen", daemon=True).start()
            return True
        if _RE["motion"].search(t):
            import friday_vision_engine as ve
            if ve.SESSION.running:
                motion_status()
                return True
            return None
        if _RE["changed"].search(t) and not re.search(r"\bgit\b|\bcode\b|\bfile\b", low):
            kind = "camera" if "camera" in low else "screen"
            threading.Thread(target=compare_view, args=(kind,), name="FridayVisionCompare", daemon=True).start()
            return True
        if _RE["analyze"].search(t) and not re.search(r"\b(?:i am|i'm|im)\s+(?:seeing|looking at)\b", low):
            path = _extract_path(t) or _attached_media()
            if path:
                threading.Thread(target=analyze_file, args=(path,), name="FridayVisionFile", daemon=True).start()
                return True
            if re.search(r"\b(?:attached|uploaded|this)\b", low):
                _speak("Please attach the picture or video with the paperclip first, then ask me again.")
                return True
            return None
        if _RE["bench"].search(t):
            run_benchmark()
            return True
        if _RE["report"].search(t):
            threading.Thread(target=export_report, name="FridayVisionReport", daemon=True).start()
            return True
        if _RE["metrics"].search(t):
            _speak(metrics_summary_text())
            return True
        if _RE["status"].search(t):
            vision_status()
            return True
        m = _RE["verify_tail"].match(t)
        if m and cfg.get("agent_enabled"):
            import friday_vision_agent as va
            if va.plan_from_text(m.group(1)):
                start_agent(m.group(1).strip())
                return True
        if cfg.get("agent_auto_claim"):
            import friday_vision_agent as va
            plan = va.plan_from_text(t)
            if plan and any(s["tool"] == "find_and_open_file" for s in plan):
                start_agent(t)
                return True
    except Exception as exc:
        _log(f"Vision command fell through safely: {exc}", "recovery")
    return None


# ----------------------------------------------------------------------------
# UI request router (Vision page + Settings)
# ----------------------------------------------------------------------------
def _agentic_status() -> dict[str, Any]:
    try:
        import friday_agentic_vision as av
        return av.snapshot()
    except Exception:
        return {}


def _full_status() -> dict[str, Any]:
    ve = _engine()
    import friday_eval_metrics as em
    import friday_vision_agent as va
    import friday_action_safety as safety
    return {
        "config": cfg.all_values(), "defaults": cfg.DEFAULTS, "environment": ve.environment(), "detector": ve.detector_status() if ve.available() else {},
        "session": ve.SESSION.status(), "metrics": em.snapshot(), "agent": va.status(), "pending": safety.pending(),
        "secrets": {"cloud_token": cfg.has_secret("cloud_token")}, "data_dir": str(cfg.DATA_DIR),
        "tesseract": {"ok": bool(ve.available() and ve._tesseract_ready()), "error": ve._TESS_STATE.get("error", "")} if ve.available() else {"ok": False},
        "last_state": _state_for_ui(ve.last_state()) if ve.available() and ve.last_state() else None,
        "history": ve.history(12) if ve.available() else [],
        "agentic": _agentic_status(),
    }


def handle_ui(payload: dict[str, Any]) -> None:
    """Runs on its own thread for anything slow. Replies with  VISION::{kind:'reply', req, data}."""
    op = str(payload.get("op", ""))
    req = payload.get("req")

    def reply(data: Any) -> None:
        emit("reply", data, req)

    def work() -> None:
        _wire()
        try:
            if op == "status":
                return reply({"ok": True, **_full_status()})
            if op == "config_set":
                vals = cfg.update(payload.get("changes") or {})
                return reply({"ok": True, "config": vals, "detector": _engine().detector_status() if _engine().available() else {}})
            if op == "config_reset":
                return reply({"ok": True, "config": cfg.reset()})
            if op == "camera_start":
                _PREVIEW["on"] = bool(payload.get("preview", True))
                return reply(camera_on(preview=_PREVIEW["on"], speak=bool(payload.get("speak", False))))
            if op == "camera_stop":
                return reply(camera_off(speak=False))
            if op == "screen_start":
                return reply(screen_watch(True, speak=False))
            if op == "screen_stop":
                return reply(screen_watch(False, speak=False))
            if op == "preview":
                _PREVIEW["on"] = bool(payload.get("on"))
                _engine().SESSION.preview = _PREVIEW["on"]
                return reply({"ok": True, "preview": _PREVIEW["on"]})
            if op == "snapshot":
                return reply(snapshot(payload.get("source", "screen"), ask_gemini=payload.get("gemini"), question=str(payload.get("question", "")), speak=bool(payload.get("speak", False)), ocr=bool(payload.get("ocr", True))))
            if op == "analyze_file":
                return reply(analyze_file(str(payload.get("path", "")), ask_gemini=bool(payload.get("gemini", True)), named=bool(payload.get("named", False)), speak=bool(payload.get("speak", False)), question=str(payload.get("question", ""))))
            if op == "compare":
                return reply(compare_view(payload.get("source", "screen"), speak=bool(payload.get("speak", False))))
            if op == "find_text":
                return reply(find_on_screen(str(payload.get("query", "")), speak=bool(payload.get("speak", False))))
            if op == "agent_run":
                return reply(start_agent(str(payload.get("goal", "")).strip(), speak=bool(payload.get("speak", True))))
            if op == "agent_stop":
                return reply(stop_agent(speak=False))
            if op == "confirm":
                import friday_action_safety as safety
                if payload.get("false_alarm"):
                    import friday_agentic_vision as av
                    av.mark_false_alarm()
                    return reply({"ok": True, "false_alarm": True})
                return reply(safety.resolve(bool(payload.get("approve")), payload.get("id"), str(payload.get("typed", "")), "ui"))
            if op.startswith("agentic_"):
                import friday_agentic_vision as av
                r = av.handle_ui(op, payload)
                return reply(r if r is not None else {"ok": False, "error": f"unknown request '{op}'"})
            if op == "bench_run":
                return reply(run_benchmark(speak=bool(payload.get("speak", False))))
            if op == "metrics":
                import friday_eval_metrics as em
                return reply({"ok": True, "metrics": em.snapshot()})
            if op == "metrics_reset":
                import friday_eval_metrics as em
                return reply({"ok": True, "metrics": em.reset()})
            if op == "report":
                return reply(export_report(speak=False))
            if op == "audit":
                import friday_action_safety as safety
                return reply({"ok": True, "audit": safety.audit_tail(40)})
            if op == "model_download":
                ve = _engine()
                r = ve.download_model(str(payload.get("url", "")).strip(), progress=lambda f: emit("progress", {"what": "model", "fraction": round(f, 3)}))
                return reply(r)
            if op == "model_test":
                ve = _engine()
                img, _ = ve.synthetic_scene()
                t0 = time.perf_counter()
                st = ve.analyze_frame(img, "image", publish_state=False, mode="onnx")
                d = ve.detector_status()
                return reply({"ok": bool(d.get("onnx_loaded")), "error": d.get("onnx_error"), "ms": round((time.perf_counter() - t0) * 1000, 1), "detectors": st.get("detectors"), "status": d})
            if op == "cloud_test":
                import friday_vision_cloud as vc
                return reply(vc.health())
            if op == "cloud_compare":
                import friday_vision_cloud as vc
                return reply({"ok": True, "result": vc.compare_local_vs_cloud()})
            if op == "install_packages":
                return reply(install_vision_packages())
            if op == "ocr_check":
                ve = _engine()
                return reply({"ok": ve._tesseract_ready(), "error": ve._TESS_STATE.get("error", "")})
            return reply({"ok": False, "error": f"unknown request '{op}'"})
        except Exception as exc:
            reply({"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:200]}"})

    threading.Thread(target=work, name=f"FridayVisionUI-{op}", daemon=True).start()


_INSTALL = {"running": False}


def install_vision_packages() -> dict[str, Any]:
    """Settings > Vision > 'Install / update OpenCV'. Installs OpenCV 5 (falls back to the newest available) into the Python FRIDAY runs on."""
    import subprocess
    import sys
    with _LOCK:
        if _INSTALL["running"]:
            return {"ok": False, "error": "An install is already running."}
        _INSTALL["running"] = True
    try:
        base = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--upgrade"]
        flags = {"creationflags": 0x08000000} if sys.platform == "win32" else {}
        last = ""
        for spec in ("opencv-python-headless>=5.0", "opencv-python-headless"):
            emit("progress", {"what": "install", "text": f"Installing {spec} ..."})
            r = subprocess.run(base + [spec, "numpy"], capture_output=True, text=True, timeout=900, **flags)
            last = (r.stderr or r.stdout or "")[-300:]
            if r.returncode == 0:
                break
        else:
            return {"ok": False, "error": "pip could not install OpenCV: " + last.strip()}
        return {"ok": True, "message": "OpenCV installed. Please restart FRIDAY so the new version is loaded."}
    except Exception as exc:
        return {"ok": False, "error": _fail_text(exc)}
    finally:
        _INSTALL["running"] = False


def handle_secret(name: str, value: str) -> None:
    """Called by the backend when the app hands over a secret from Windows secure storage."""
    cfg.set_secret(name, value)
    emit("secret", {"name": name, "set": bool(value)})


def shutdown() -> None:
    """Release the camera when FRIDAY quits."""
    try:
        import sys as _sys
        if "friday_agentic_vision" in _sys.modules:
            _sys.modules["friday_agentic_vision"].shutdown()
    except Exception:
        pass
    try:
        import friday_vision_engine as ve
        if ve.SESSION.running:
            ve.SESSION.stop()
        import friday_eval_metrics as em
        em.flush()
    except Exception:
        pass
