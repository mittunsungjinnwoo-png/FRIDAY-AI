"""FRIDAY 7.0 controlled self-improvement engine (roadmap #24).

    detect()    recurring failures from what actually happened: tool failures in the execution receipts, repeated incidents, tracebacks in the crash log,
                failing benchmark cases - grouped by a cleaned-up signature, counted, dated
    suggest()   a concrete, reviewable fix for each recurring problem:
                  config    e.g. a tool that keeps timing out gets a longer time limit (bounded, reversible)
                  install   a missing package: the exact pip command (never run for you)
                  permission / strategy   which switch or alternative tool would help
                  code      a patch drafted against the file named in the traceback and sent through the SANDBOX repair agent
                            (applied to a throw-away copy, tests before and after, compared) - a proposal, nothing on disk changes
    present     you decide: 'apply improvement N' then 'confirm improvement' for config changes; 'apply repair N' + 'confirm repair' for code.

Nothing is changed without your approval, nothing here edits production code by itself, and the voice engines are never touched.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS improvements7(id INTEGER PRIMARY KEY, ts REAL, kind TEXT, key TEXT, title TEXT, detail TEXT, status TEXT DEFAULT 'proposed', rid INTEGER DEFAULT 0, applied_ts REAL, undo TEXT);
CREATE INDEX IF NOT EXISTS ix_improvements7_key ON improvements7(key);
""")

MIN_COUNT = 3
WINDOW_DAYS = 7
MAX_TIMEOUT_S = 300.0
_pending_confirm: Dict = {"id": 0, "ts": 0.0}


def _signature(text: str) -> str:
    t = re.sub(r"[A-Za-z]:\\[^\s'\"]+|/(?:[\w.\-]+/)+[\w.\-]+", "<path>", text or "")
    t = re.sub(r"0x[0-9a-f]+|\d+", "N", t.lower())
    return re.sub(r"\s+", " ", t).strip()[:90]


# ------------------------------------------------------------------ detection
def detect(window_days: float = WINDOW_DAYS, min_count: int = MIN_COUNT) -> List[Dict]:
    cut = time.time() - window_days * 86400
    out: List[Dict] = []
    groups: Dict[str, Dict] = {}
    for r in C.q("SELECT tool, failure_class, error, ts FROM receipts7 WHERE ok=0 AND ts>=? AND failure_class!='cancelled'", (cut,)):
        sig = _signature(r["error"])
        key = f"tool:{r['tool']}:{r['failure_class']}:{sig[:40]}"
        g = groups.setdefault(key, {"key": key, "kind": "tool_failure", "tool": r["tool"], "cls": r["failure_class"], "count": 0, "first": r["ts"], "last": r["ts"], "example": r["error"][:160]})
        g["count"] += 1
        g["first"], g["last"] = min(g["first"], r["ts"]), max(g["last"], r["ts"])
    out += [g for g in groups.values() if g["count"] >= min_count]
    inc: Dict[str, Dict] = {}
    for r in C.q("SELECT component, text, ts FROM incidents7 WHERE ts>=? AND level IN ('warn','error')", (cut,)):
        key = f"incident:{r['component']}:{_signature(r['text'])[:40]}"
        g = inc.setdefault(key, {"key": key, "kind": "incident", "component": r["component"], "count": 0, "first": r["ts"], "last": r["ts"], "example": r["text"][:160]})
        g["count"] += 1
        g["last"] = max(g["last"], r["ts"])
    out += [g for g in inc.values() if g["count"] >= min_count]
    out += _crash_log_groups(cut)
    try:
        rows = C.q("SELECT cases FROM bench7_runs ORDER BY id DESC LIMIT 3")
        if len(rows) >= 2:
            fails = [{c["id"]: c for c in json.loads(r["cases"]) if c["status"] == "fail"} for r in rows]
            for cid in set(fails[0]) & set(fails[1]):
                c = fails[0][cid]
                out.append({"key": f"bench:{cid}", "kind": "benchmark", "case": c["name"], "count": sum(1 for f in fails if cid in f), "first": time.time(), "last": time.time(), "example": c["detail"][:160]})
    except Exception:
        pass
    out.sort(key=lambda g: (-g["count"], -g["last"]))
    return out


def _crash_log_groups(cut: float) -> List[Dict]:
    try:
        p = Path(C.HERE) / "friday_crash.log"
        if not p.exists() or p.stat().st_mtime < cut or p.stat().st_size > 6_000_000:
            return []
        txt = p.read_text(encoding="utf-8", errors="ignore")[-400_000:]
    except Exception:
        return []
    groups: Dict[str, Dict] = {}
    for m in re.finditer(r'File "([^"]+)", line (\d+), in [^\n]+\n(?:[^\n]*\n)?(\w+(?:Error|Exception)): ([^\n]*)', txt):
        f, line, exc, msg = m.group(1), m.group(2), m.group(3), m.group(4)
        key = f"trace:{Path(f).name}:{exc}:{_signature(msg)[:30]}"
        g = groups.setdefault(key, {"key": key, "kind": "traceback", "file": f, "line": int(line), "exc": exc, "count": 0, "first": p.stat().st_mtime, "last": p.stat().st_mtime, "example": f"{exc}: {msg}"[:160]})
        g["count"] += 1
    return [g for g in groups.values() if g["count"] >= 2]


# ------------------------------------------------------------------ suggestions
def suggest(problem: Dict) -> List[Dict]:
    out: List[Dict] = []
    kind = problem["kind"]
    if kind == "tool_failure":
        tool, cls, ex = problem["tool"], problem["cls"], problem["example"]
        if cls in ("timeout", "transient"):
            current = 60.0
            try:
                import friday_orchestrator7 as O
                current = float(O.registry.get(tool)["timeout"]) if O.registry.has(tool) else 60.0
                ov = K.cfg_get("tool_timeout:" + tool, "")
                current = max(current, float(ov)) if ov else current
            except Exception:
                pass
            new = min(MAX_TIMEOUT_S, round(current * 1.5))
            if new > current:
                out.append({"kind": "config", "title": f"give '{tool}' a longer time limit ({int(current)}s -> {new}s)", "detail": {"set": "tool_timeout:" + tool, "value": new, "was": current},
                            "why": f"it failed {problem['count']} times with '{ex[:60]}'"})
        if cls == "dependency":
            m = re.search(r"no module named '?([\w.]+)", ex, re.I)
            if m:
                pkg = m.group(1).split(".")[0]
                out.append({"kind": "install", "title": f"install the missing package '{pkg}'", "detail": {"command": f"pip install {pkg}"}, "why": f"'{tool}' needs it ({problem['count']} failures)"})
            else:
                out.append({"kind": "install", "title": f"'{tool}' is missing something it depends on", "detail": {"command": ""}, "why": ex[:100]})
        if cls == "permission":
            out.append({"kind": "permission", "title": f"'{tool}' is being blocked by a permission", "detail": {}, "why": f"{problem['count']} refusals: {ex[:80]}. If you want it to work, say 'allow <permission>'; otherwise nothing needs to change."})
        if cls in ("not_found", "invalid_args", "verification", "unknown"):
            out.append({"kind": "strategy", "title": f"'{tool}' keeps failing the same way", "detail": {}, "why": f"{problem['count']} times: {ex[:90]}. Corrections from you ('that was wrong, use X') teach the planner an alternative; say 'what have you learned' to see proposals."})
    elif kind == "incident":
        out.append({"kind": "strategy", "title": f"recurring problem in {problem['component']}", "detail": {}, "why": f"{problem['count']} incidents: {problem['example'][:100]}. Say 'diagnose yourself' for the full report."})
    elif kind == "traceback":
        f = Path(problem["file"])
        inside = False
        try:
            f.resolve().relative_to(Path(C.HERE).resolve())
            inside = True
        except Exception:
            pass
        out.append({"kind": "code", "title": f"{problem['exc']} in {f.name} line {problem['line']} ({problem['count']} times)", "detail": {"file": str(f), "line": problem["line"], "issue": problem["example"], "inside_project": inside},
                    "why": "a patch can be drafted and tested in a copy; production code needs your approval and the self-update permission"})
    elif kind == "benchmark":
        out.append({"kind": "strategy", "title": f"benchmark case failing in consecutive runs: {problem['case']}", "detail": {}, "why": problem["example"]})
    return out


def _store(problem: Dict, s: Dict) -> int:
    key = problem["key"] + "|" + s["kind"]
    ex = C.q("SELECT id FROM improvements7 WHERE key=? AND status IN ('proposed','applied')", (key,))
    if ex:
        return ex[0]["id"]
    return C.x("INSERT INTO improvements7(ts,kind,key,title,detail,status) VALUES(?,?,?,?,?,?)", (C.now(), s["kind"], key, s["title"], K.jd({**s["detail"], "why": s.get("why", ""), "count": problem["count"]}), "proposed"))


def review(window_days: float = WINDOW_DAYS) -> Dict:
    """Detect, suggest, and record proposals (deduplicated). Returns {problems, proposals}."""
    problems = detect(window_days)
    props = []
    for p in problems[:12]:
        for s in suggest(p):
            iid = _store(p, s)
            props.append({"id": iid, "kind": s["kind"], "title": s["title"], "why": s.get("why", ""), "problem": p["key"]})
    return {"problems": problems, "proposals": props}


def draft_code_fix(iid: int) -> Dict:
    """For a 'code' proposal: have the repair agent draft and sandbox-test a patch. Still only a proposal."""
    r = C.q("SELECT * FROM improvements7 WHERE id=?", (iid,))
    if not r or r[0]["kind"] != "code":
        return {"ok": False, "error": "that is not a code proposal"}
    d = K.jl(r[0]["detail"], {})
    import friday_repair7 as RP
    sug = RP.suggest(d["file"], d["issue"])
    if not sug.get("ok") and not sug.get("rid"):
        return {"ok": False, "error": sug.get("error", "no patch could be drafted")}
    rid = sug["rid"]
    t = RP.test(rid)
    C.x("UPDATE improvements7 SET rid=? WHERE id=?", (rid, iid))
    return {"ok": True, "rid": rid, "test": t, "diff": sug.get("diff", "")}


# ------------------------------------------------------------------ applying (config only; code goes through the repair agent's own approval)
def apply(iid: int, confirmed: bool = False) -> Dict:
    r = C.q("SELECT * FROM improvements7 WHERE id=?", (iid,))
    if not r:
        return {"ok": False, "error": f"there is no improvement #{iid}"}
    row = dict(r[0])
    if row["status"] != "proposed":
        return {"ok": False, "error": f"improvement #{iid} is already {row['status']}"}
    if row["kind"] == "install":
        cmd = K.jl(row["detail"], {}).get("command") or ""
        return {"ok": True, "text": ("I never install packages myself. To fix this, run this in a terminal: " + cmd + ". Then restart FRIDAY.") if cmd else "I never install packages myself; the error text above names what is missing."}
    if row["kind"] != "config":
        return {"ok": False, "error": {"code": f"code changes go through the repair agent (say 'draft a patch for improvement {iid}', then 'apply repair')",
                                       "permission": "permissions are yours to change ('allow <permission>')", "strategy": "this one needs a decision from you, not a setting"}.get(row["kind"], "not applicable")}
    d = K.jl(row["detail"], {})
    if not confirmed:
        _pending_confirm.update(id=iid, ts=time.time())
        return {"ok": True, "needs_confirm": True, "text": f"This will {row['title']}. Say 'confirm improvement' to apply it; 'undo improvement {iid}' reverses it."}
    prev = K.cfg_get(d["set"], "")
    K.cfg_set(d["set"], d["value"])
    C.x("UPDATE improvements7 SET status='applied', applied_ts=?, undo=? WHERE id=?", (C.now(), json.dumps({"set": d["set"], "was": prev}), iid))
    K.emit("improvement.applied", {"id": iid, "title": row["title"]})
    try:
        import friday_security6 as SEC
        SEC.audit("user", "improvement-applied", row["title"], "ok")
    except Exception:
        pass
    return {"ok": True, "text": f"Done: {row['title']}. Say 'undo improvement {iid}' to reverse it."}


def undo(iid: int) -> Dict:
    r = C.q("SELECT * FROM improvements7 WHERE id=?", (iid,))
    if not r or r[0]["status"] != "applied":
        return {"ok": False, "error": "that improvement is not applied"}
    u = K.jl(r[0]["undo"], {})
    K.cfg_set(u["set"], u.get("was", ""))
    C.x("UPDATE improvements7 SET status='undone' WHERE id=?", (iid,))
    return {"ok": True, "text": f"Reversed: {r[0]['title']}."}


def reject(iid: int) -> bool:
    return K.xn("UPDATE improvements7 SET status='rejected' WHERE id=? AND status='proposed'", (iid,)) > 0


def improvements(n: int = 12, status: Optional[str] = None) -> List[Dict]:
    rows = C.q("SELECT * FROM improvements7 " + ("WHERE status=? " if status else "") + "ORDER BY id DESC LIMIT ?", ((status, n) if status else (n,)))
    return [{"id": r["id"], "kind": r["kind"], "title": r["title"], "status": r["status"], "why": K.jl(r["detail"], {}).get("why", ""), "rid": r["rid"], "when": C.iso(r["ts"])} for r in rows]


# ------------------------------------------------------------------ chat
def describe(rev: Dict) -> str:
    if not rev["problems"]:
        return f"I found no failure that repeated {MIN_COUNT} or more times in the last {WINDOW_DAYS} days, so there is nothing to improve right now."
    lines = [f"{len(rev['problems'])} recurring problem(s) in the last {WINDOW_DAYS} days:"]
    by = {}
    for pr in rev["proposals"]:
        by.setdefault(pr["problem"], []).append(pr)
    for p in rev["problems"][:6]:
        label = {"tool_failure": f"tool '{p.get('tool')}' ({p.get('cls')})", "incident": f"{p.get('component')} incidents", "traceback": f"{p.get('exc')} in {Path(p.get('file', '')).name}", "benchmark": f"benchmark: {p.get('case')}"}[p["kind"]]
        lines.append(f"- {label}: {p['count']} times, last {K.ago(p['last'])}. e.g. {p['example'][:90]}")
        for pr in by.get(p["key"], []):
            lines.append(f"    -> #{pr['id']} [{pr['kind']}] {pr['title']}")
    lines.append("Nothing has been changed. 'apply improvement N' (config) or 'draft a patch for improvement N' (code) lets me prepare something for your approval.")
    return "\n".join(lines)


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if re.match(r"^(?:what|which) (?:keeps|is keep|things keep) (?:failing|breaking|going wrong)$|^(?:look for|find|check for) recurring (?:problems|failures|errors)$|^self[- ]improvement (?:report|review|check)$|^how can you improve (?:yourself)?$|^improve yourself$", t):
        return describe(review())
    if re.match(r"^(?:list|show)(?: me)? (?:the )?improvements$|^what improvements (?:are|have) (?:proposed|you proposed)$", t):
        rows = improvements()
        return "No improvements have been proposed yet." if not rows else "\n".join(f"#{r['id']} [{r['status']}] {r['title']}" for r in rows)
    m = re.match(r"^(?:apply|do|accept) improvement (?:number |no\.? |#)?(\d+)$", t)
    if m:
        r = apply(int(m.group(1)))
        return r.get("text") or r.get("error")
    if t in ("confirm improvement", "yes apply the improvement") and _pending_confirm["id"] and time.time() - _pending_confirm["ts"] < 180:
        r = apply(_pending_confirm["id"], confirmed=True)
        _pending_confirm["id"] = 0
        return r.get("text") or r.get("error")
    m = re.match(r"^undo improvement (?:number |no\.? |#)?(\d+)$", t)
    if m:
        r = undo(int(m.group(1)))
        return r.get("text") or r.get("error")
    m = re.match(r"^(?:reject|dismiss|ignore) improvement (?:number |no\.? |#)?(\d+)$", t)
    if m:
        return "Dismissed." if reject(int(m.group(1))) else "There was nothing to dismiss."
    m = re.match(r"^(?:draft|prepare|write) a (?:patch|fix) for improvement (?:number |no\.? |#)?(\d+)$", t)
    if m:
        r = draft_code_fix(int(m.group(1)))
        if not r["ok"]:
            return "I couldn't prepare a patch: " + r["error"]
        tr = r.get("test") or {}
        return f"I drafted repair #{r['rid']} and tested it in a copy: {tr.get('summary') or tr.get('error') or 'see the repair log'}. Nothing on disk has changed. Say 'apply repair {r['rid']}' if you want it."
    return None


def tick():
    """Once a day, when idle: look for new recurring problems and queue them for the proactive engine (a suggestion, never an action)."""
    last = float(K.cfg_get("selfimprove_last", "0") or 0)
    if time.time() - last < 86400:
        return None
    K.cfg_set("selfimprove_last", time.time())
    rev = review()
    new = [p for p in rev["proposals"] if C.q("SELECT id FROM improvements7 WHERE id=? AND ts>?", (p["id"], time.time() - 120))]
    if new:
        K.emit("improvement.found", {"count": len(new), "titles": [p["title"] for p in new[:3]]})
    return len(new)


def ui_snapshot() -> Dict:
    return {"improvements": improvements(8)}
