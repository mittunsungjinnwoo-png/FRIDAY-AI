"""FRIDAY 6.0 creativity and content production (blueprint section 11).

Local generators that work without a model: presentations (.pptx), Word documents, PDFs, spreadsheets, diagrams (Mermaid + SVG),
infographics, logo concepts, storyboards, proofreading and tone adaptation checks.  When the model is available it writes the
content; when it is not, you still get a well-formed file from the outline you give.  Images go through the connected Gemini image
model when a key is configured; audio transcription and voice-over use the same engines FRIDAY already has (faster-whisper, edge-tts).
Every multi-step pipeline stops at a review checkpoint before anything is published or sent.
"""
from __future__ import annotations

import html
import os
import re
import textwrap
from pathlib import Path
from typing import Dict, List, Optional

import friday_common6 as C


def _out(name: str) -> Path:
    d = C.DATA_DIR / "outputs"
    d.mkdir(parents=True, exist_ok=True)
    stem = re.sub(r"[^A-Za-z0-9_\-\.]+", "_", name)[:60]
    p = d / stem
    i = 1
    while p.exists():
        p = d / f"{Path(stem).stem}_{i}{Path(stem).suffix}"
        i += 1
    return p


def outline_from(topic: str, n: int = 6) -> List[Dict]:
    """[{title, bullets}] - from the model when available, otherwise from a sensible generic structure."""
    raw = C.llm(f"Create a {n}-section outline for: {topic}. Reply as lines 'Title | bullet; bullet; bullet'. No extra text.") if C._cfg.get("llm") else ""
    out = []
    for line in raw.splitlines():
        if "|" in line:
            a, b = line.split("|", 1)
            out.append({"title": a.strip(" -*#0123456789."), "bullets": [x.strip() for x in b.split(";") if x.strip()][:5]})
    if out:
        return out[:n]
    base = ["Overview", "Why it matters", "Key ideas", "How it works", "Examples", "Next steps"]
    return [{"title": f"{topic.title()}: {t}" if i == 0 else t, "bullets": ["Add your point here", "Add supporting detail", "Add an example"]} for i, t in enumerate(base[:n])]


def make_pptx(title: str, sections: List[Dict], path: Optional[str] = None) -> str:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    prs = Presentation()
    prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)
    s = prs.slides.add_slide(prs.slide_layouts[0])
    s.shapes.title.text = title
    s.placeholders[1].text = f"Prepared by FRIDAY {C.VERSION} · {C.day()}"
    for sec in sections:
        sl = prs.slides.add_slide(prs.slide_layouts[1])
        sl.shapes.title.text = sec["title"]
        tf = sl.placeholders[1].text_frame
        tf.clear()
        for i, b in enumerate(sec.get("bullets", [])):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.text = b
            p.font.size = Pt(24)
        if sec.get("notes"):
            sl.notes_slide.notes_text_frame.text = sec["notes"]
    p = Path(path) if path else _out(title + ".pptx")
    prs.save(str(p))
    return str(p)


def make_docx(title: str, sections: List[Dict], path: Optional[str] = None) -> str:
    from docx import Document
    d = Document()
    d.add_heading(title, 0)
    for sec in sections:
        d.add_heading(sec["title"], 1)
        for b in sec.get("bullets", []):
            d.add_paragraph(b, style="List Bullet")
        if sec.get("text"):
            d.add_paragraph(sec["text"])
    p = Path(path) if path else _out(title + ".docx")
    d.save(str(p))
    return str(p)


def make_pdf(title: str, sections: List[Dict], path: Optional[str] = None) -> str:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    st = getSampleStyleSheet()
    p = Path(path) if path else _out(title + ".pdf")
    doc = SimpleDocTemplate(str(p), pagesize=A4, title=title)
    flow = [Paragraph(html.escape(title), st["Title"]), Spacer(1, 12)]
    for sec in sections:
        flow.append(Paragraph(html.escape(sec["title"]), st["Heading2"]))
        for b in sec.get("bullets", []):
            flow.append(Paragraph("• " + html.escape(b), st["BodyText"]))
        if sec.get("text"):
            flow.append(Paragraph(html.escape(sec["text"]), st["BodyText"]))
        flow.append(Spacer(1, 8))
    doc.build(flow)
    return str(p)


def make_xlsx(title: str, rows: List[List], path: Optional[str] = None, chart: bool = True) -> str:
    from openpyxl import Workbook
    from openpyxl.chart import BarChart, Reference
    from openpyxl.styles import Font, PatternFill
    wb = Workbook(); ws = wb.active; ws.title = title[:30] or "Sheet1"
    for r in rows:
        ws.append(r)
    if rows:
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F4E79")
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = min(40, max(10, max(len(str(c.value or "")) for c in col) + 2))
        if chart and len(rows) > 2 and len(rows[0]) >= 2 and all(isinstance(r[1], (int, float)) for r in rows[1:] if len(r) > 1):
            ch = BarChart(); ch.title = title
            ch.add_data(Reference(ws, min_col=2, min_row=1, max_row=len(rows)), titles_from_data=True)
            ch.set_categories(Reference(ws, min_col=1, min_row=2, max_row=len(rows)))
            ws.add_chart(ch, "E2")
    p = Path(path) if path else _out(title + ".xlsx")
    wb.save(str(p))
    return str(p)


# ------------------------------------------------------------------ diagrams, infographics, logos
def mermaid_flow(steps: List[str], direction: str = "TD") -> str:
    ids = [f"S{i}" for i in range(len(steps))]
    lines = [f"flowchart {direction}"] + [f'  {i}["{s.replace(chr(34), chr(39))}"]' for i, s in zip(ids, steps)] + [f"  {a} --> {b}" for a, b in zip(ids, ids[1:])]
    return "\n".join(lines)


def svg_flow(steps: List[str], title: str = "", path: Optional[str] = None) -> str:
    w, bh, gap = 520, 54, 34
    h = 70 + len(steps) * (bh + gap)
    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-label="{html.escape(title or "Flow diagram")}">',
             '<defs><marker id="a" markerWidth="10" markerHeight="8" refX="8" refY="4" orient="auto"><path d="M0,0 L10,4 L0,8 z" fill="#38bdf8"/></marker></defs>',
             f'<rect width="{w}" height="{h}" fill="#0b1220"/>', f'<text x="{w // 2}" y="36" text-anchor="middle" fill="#e2e8f0" font-family="Segoe UI,Arial" font-size="20">{html.escape(title)}</text>']
    y = 60
    for i, s in enumerate(steps):
        parts.append(f'<rect x="90" y="{y}" width="{w - 180}" height="{bh}" rx="12" fill="#12263f" stroke="#38bdf8" stroke-width="2"/>')
        for j, ln in enumerate(textwrap.wrap(s, 34)[:2]):
            parts.append(f'<text x="{w // 2}" y="{y + 24 + j * 18}" text-anchor="middle" fill="#e2e8f0" font-family="Segoe UI,Arial" font-size="15">{html.escape(ln)}</text>')
        if i < len(steps) - 1:
            parts.append(f'<line x1="{w // 2}" y1="{y + bh}" x2="{w // 2}" y2="{y + bh + gap - 4}" stroke="#38bdf8" stroke-width="2" marker-end="url(#a)"/>')
        y += bh + gap
    parts.append("</svg>")
    p = Path(path) if path else _out((title or "flow") + ".svg")
    p.write_text("\n".join(parts), "utf-8")
    return str(p)


def svg_infographic(title: str, stats: List[tuple], path: Optional[str] = None) -> str:
    """stats: [(label, value, unit)]"""
    w, h = 720, 160 + 110 * ((len(stats) + 1) // 2)
    cols = ["#38bdf8", "#a78bfa", "#34d399", "#fbbf24", "#fb7185", "#60a5fa"]
    p_ = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-label="{html.escape(title)}">', f'<rect width="{w}" height="{h}" fill="#0b1220"/>',
          f'<text x="{w // 2}" y="62" text-anchor="middle" fill="#e2e8f0" font-family="Segoe UI,Arial" font-size="30" font-weight="600">{html.escape(title)}</text>']
    for i, (lab, val, unit) in enumerate(stats):
        x = 40 + (i % 2) * 340; y = 100 + (i // 2) * 110
        c = cols[i % len(cols)]
        p_ += [f'<rect x="{x}" y="{y}" width="320" height="92" rx="14" fill="#12263f" stroke="{c}" stroke-width="2"/>',
               f'<text x="{x + 20}" y="{y + 50}" fill="{c}" font-family="Segoe UI,Arial" font-size="38" font-weight="700">{html.escape(str(val))}<tspan font-size="16" fill="#94a3b8"> {html.escape(str(unit))}</tspan></text>',
               f'<text x="{x + 20}" y="{y + 76}" fill="#cbd5e1" font-family="Segoe UI,Arial" font-size="15">{html.escape(str(lab))}</text>']
    p_.append("</svg>")
    path = Path(path) if path else _out(title + ".svg")
    path.write_text("\n".join(p_), "utf-8")
    return str(path)


def logo_concepts(name: str, n: int = 3) -> List[str]:
    """Distinct SVG logo concepts (monogram badge, orbit ring, geometric mark) - starting points, not finished brand work."""
    ini = (name.strip()[:1] or "F").upper()
    pal = [("#38bdf8", "#0b1220"), ("#a78bfa", "#111827"), ("#34d399", "#052e2b")]
    paths = []
    for i in range(min(n, 3)):
        a, bg = pal[i]
        shapes = [
            f'<circle cx="100" cy="100" r="78" fill="none" stroke="{a}" stroke-width="10"/><text x="100" y="128" text-anchor="middle" font-size="86" font-weight="700" fill="{a}" font-family="Segoe UI,Arial">{ini}</text>',
            f'<ellipse cx="100" cy="100" rx="86" ry="34" fill="none" stroke="{a}" stroke-width="6" transform="rotate(-25 100 100)"/><circle cx="100" cy="100" r="30" fill="{a}"/><circle cx="158" cy="78" r="9" fill="#fff"/>',
            f'<polygon points="100,18 170,60 170,140 100,182 30,140 30,60" fill="none" stroke="{a}" stroke-width="10"/><polygon points="100,60 135,80 135,120 100,140 65,120 65,80" fill="{a}"/>']
        svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="260" viewBox="0 0 200 260" role="img" aria-label="{html.escape(name)} logo concept {i + 1}"><rect width="200" height="260" rx="18" fill="{bg}"/>{shapes[i]}<text x="100" y="236" text-anchor="middle" font-size="22" fill="#e2e8f0" font-family="Segoe UI,Arial" letter-spacing="3">{html.escape(name.upper()[:14])}</text></svg>'
        p = _out(f"{name}_logo_concept_{i + 1}.svg")
        p.write_text(svg, "utf-8")
        paths.append(str(p))
    return paths


def storyboard(idea: str, scenes: int = 6) -> str:
    raw = C.llm(f"Write a {scenes}-scene video storyboard for: {idea}. For each scene give: shot, voice-over line, on-screen text, approx seconds. Plain text.") if C._cfg.get("llm") else ""
    if raw:
        return raw
    beats = ["Hook", "Problem", "Idea", "Demonstration", "Proof", "Call to action"][:scenes]
    return "\n".join(f"Scene {i + 1} - {b}: shot ... | voice-over ... | on-screen text ... | ~8 s" for i, b in enumerate(beats))


# ------------------------------------------------------------------ editing: proofreading, adaptation
_COMMON = {"teh": "the", "recieve": "receive", "occured": "occurred", "seperate": "separate", "definately": "definitely", "wich": "which", "adress": "address", "untill": "until",
           "becuase": "because", "thier": "their", "alot": "a lot", "enviroment": "environment", "goverment": "government", "tommorow": "tomorrow", "acommodate": "accommodate"}


def proofread(text: str) -> Dict:
    issues, fixed = [], text
    for bad, good in _COMMON.items():
        if re.search(r"\b" + bad + r"\b", fixed, re.I):
            issues.append(f"'{bad}' -> '{good}'")
            fixed = re.sub(r"\b" + bad + r"\b", good, fixed, flags=re.I)
    for m in re.finditer(r"\b(\w+)\s+\1\b", fixed, re.I):
        issues.append(f"repeated word '{m.group(1)}'")
    fixed = re.sub(r"\b(\w+)\s+\1\b", r"\1", fixed, flags=re.I)
    if "  " in fixed:
        issues.append("double spaces"); fixed = re.sub(r" {2,}", " ", fixed)
    fixed = re.sub(r"\s+([,.;:!?])", r"\1", fixed)
    sents = re.split(r"(?<=[.!?])\s+", fixed)
    long_ = [s for s in sents if len(s.split()) > 38]
    if long_:
        issues.append(f"{len(long_)} very long sentence(s) - consider splitting")
    if re.search(r"\b(i|im|dont|cant|wont)\b(?!['’])", fixed) and re.search(r"\bi\b", fixed):
        issues.append("lower-case 'i' as a pronoun")
        fixed = re.sub(r"\bi\b(?!['’])", "I", fixed)
    return {"fixed": fixed, "issues": issues}


def adapt(text: str, audience: str) -> str:
    out = C.llm(f"Rewrite this for {audience}. Keep every fact; change vocabulary, length and tone only.\n\n{text}") if C._cfg.get("llm") else ""
    return out or f"(Needs the model to rewrite for {audience}. Original kept.)\n{text}"


def brainstorm(topic: str, n: int = 8) -> List[Dict]:
    raw = C.llm(f"Brainstorm {n} distinct ideas for: {topic}. One per line as 'idea | impact 1-5 | effort 1-5 | main risk'.") if C._cfg.get("llm") else ""
    ideas = []
    for line in raw.splitlines():
        p = [x.strip() for x in line.split("|")]
        if len(p) >= 4:
            try:
                ideas.append({"idea": p[0].lstrip("-*0123456789. "), "impact": int(re.sub(r"\D", "", p[1]) or 3), "effort": int(re.sub(r"\D", "", p[2]) or 3), "risk": p[3]})
            except ValueError:
                pass
    for i in ideas:
        i["score"] = round(i["impact"] * 2 - i["effort"], 1)
    return sorted(ideas, key=lambda d: -d["score"])


# ------------------------------------------------------------------ media
def generate_image(prompt: str) -> Dict:
    """Image generation through the connected Gemini image model (needs the Gemini key already configured in Settings)."""
    try:
        import friday_backend as fb
        fb._ensure_gemini_client()
        client = getattr(fb, "client", None)
        if client is None:
            return {"ok": False, "error": "no Gemini key is configured"}
        model = os.environ.get("FRIDAY_IMAGE_MODEL", "gemini-2.5-flash-image")
        r = client.models.generate_content(model=model, contents=prompt)
        for part in r.candidates[0].content.parts:
            if getattr(part, "inline_data", None) and part.inline_data.data:
                p = _out(re.sub(r"[^a-z0-9]+", "_", prompt.lower())[:30] + ".png")
                p.write_bytes(part.inline_data.data)
                return {"ok": True, "path": str(p)}
        return {"ok": False, "error": "the model returned no image"}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:120]}"}


def transcribe(path: str) -> Dict:
    try:
        from faster_whisper import WhisperModel
        m = WhisperModel(os.environ.get("FRIDAY_TRANSCRIBE_MODEL", "base.en"), device="cpu", compute_type="int8")
        segs, info = m.transcribe(path)
        text = " ".join(s.text.strip() for s in segs)
        return {"ok": True, "text": text, "language": info.language}
    except Exception as exc:
        return {"ok": False, "error": f"transcription needs faster-whisper and the model files ({type(exc).__name__})"}


def voice_over(text: str, path: Optional[str] = None, voice: str = "") -> Dict:
    try:
        import asyncio
        import edge_tts
        p = Path(path) if path else _out("voice_over.mp3")
        asyncio.run(edge_tts.Communicate(text, voice or os.environ.get("FRIDAY_EDGE_VOICE", "en-US-AriaNeural")).save(str(p)))
        return {"ok": True, "path": str(p)}
    except Exception as exc:
        return {"ok": False, "error": f"voice-over needs edge-tts and internet access ({type(exc).__name__})"}


def pipeline(topic: str, formats=("docx",)) -> Dict:
    """Outline -> REVIEW CHECKPOINT -> build files. The checkpoint returns the outline for approval; call build_approved() to continue."""
    sec = outline_from(topic)
    return {"stage": "awaiting_review", "topic": topic, "outline": sec, "formats": list(formats)}


def build_approved(plan: Dict) -> List[str]:
    out = []
    for f in plan["formats"]:
        out.append({"pptx": make_pptx, "docx": make_docx, "pdf": make_pdf}[f](plan["topic"].title(), plan["outline"]))
    return out


_pending: Dict = {}


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if low in ("approve the outline", "outline approved", "build it", "approve outline", "looks good build it") and "plan" in _pending:
        files = build_approved(_pending.pop("plan"))
        return "Built: " + ", ".join(Path(f).name for f in files) + f". Saved in {C.DATA_DIR / 'outputs'}."
    m = re.match(r"^(?:draft|plan|outline) (?:an? )?(?:(pptx|powerpoint|presentation|docx|word|pdf)(?: and (pptx|powerpoint|docx|word|pdf))? )?(?:outline |content )?(?:on|about|for) (.+)$", low)
    if m and re.search(r"^(?:draft|plan|outline)\b", low) and re.search(r"presentation|deck|slides|document|pptx|docx|pdf|word|powerpoint", low):
        fm = {"powerpoint": "pptx", "presentation": "pptx", "word": "docx"}
        fmts = [fm.get(x, x) for x in (m.group(1), m.group(2)) if x] or ["docx"]
        plan = pipeline(m.group(3), fmts)
        _pending["plan"] = plan
        return "Here's the outline for review: " + "; ".join(s["title"] for s in plan["outline"]) + ". Say 'approve the outline' to build the file, or tell me what to change."
    m = re.match(r"^(?:make|create|build|generate) (?:me )?(?:a |an )?(?:flow ?chart|flow diagram|process diagram|diagram)(?: (?:of|for|showing))?:? (.+)$", t, re.I)
    if m:
        steps = [s.strip() for s in re.split(r"\s*(?:->|→|,| then | and then )\s*", m.group(1)) if s.strip()]
        if len(steps) >= 2:
            p = svg_flow(steps, "Process")
            return f"Diagram saved as {Path(p).name}. Mermaid version:\n" + mermaid_flow(steps)
    m = re.match(r"^(?:make|create|design|generate) (?:me )?(?:some )?logo (?:concepts?|ideas?)(?: for)? (.+)$", t, re.I)
    if m:
        ps = logo_concepts(m.group(1).strip(), 3)
        return f"Three logo concepts saved: {', '.join(Path(p).name for p in ps)}. They're starting points to refine."
    m = re.match(r"^(?:proofread|check the spelling of|fix the grammar in|edit)[: ]+(.+)$", t, re.I | re.S)
    if m:
        r = proofread(m.group(1))
        return ("Corrected: " + r["fixed"] + (" (" + "; ".join(r["issues"][:4]) + ")" if r["issues"] else "")) if r["issues"] else "I found nothing to fix."
    m = re.match(r"^(?:rewrite|adapt|explain)(?: this)?(?: for| to| as if to) (?:an? |the )?(.+?)[: ]+(.{20,})$", t, re.I | re.S)
    if m and re.search(r"\b(kid|child|expert|beginner|executive|student|teenager|layperson|investor|audience|manager)\b", m.group(1), re.I):
        return adapt(m.group(2), m.group(1))
    m = re.match(r"^brainstorm(?: ideas)?(?: for| about| on)? (.+)$", low)
    if m:
        ideas = brainstorm(m.group(1))
        if not ideas:
            return "__MODEL__" + f"Brainstorm 8 distinct ideas for {m.group(1)}, rate each on impact and effort, and recommend the best two."
        return "Top ideas by impact versus effort: " + "; ".join(f"{i['idea']} (impact {i['impact']}, effort {i['effort']})" for i in ideas[:4]) + "."
    m = re.match(r"^(?:storyboard|plan a video)(?: for| about| on)? (.+)$", low)
    if m:
        return storyboard(m.group(1))
    m = re.match(r"^(?:generate|create|make|draw) (?:an? )?(?:image|picture|illustration|photo) (?:of|showing|about)? ?(.+)$", t, re.I)
    if m:
        r = generate_image(m.group(1))
        return f"Image saved at {r['path']}." if r["ok"] else f"I couldn't generate the image: {r['error']}."
    m = re.match(r"^transcribe (?:the )?(?:audio |recording |file )?(.+\.(?:mp3|wav|m4a|flac|ogg|mp4|mkv))$", t, re.I)
    if m:
        r = transcribe(m.group(1).strip('" '))
        return C.clip(r["text"], 600) if r["ok"] else r["error"] + "."
    m = re.match(r"^(?:make|record|produce) (?:a )?voice[- ]?over(?: of| for| saying)?[: ]+(.+)$", t, re.I)
    if m:
        r = voice_over(m.group(1))
        return f"Voice-over saved at {r['path']}." if r["ok"] else r["error"] + "."
    return None
