"""FRIDAY fast file finder (7.0).

Why this exists
---------------
"open <file name>" used to (a) walk every file under six folders with ``rglob`` on EVERY request, which is slow, (b) only
match literal substrings, so a spoken "my physics notes" never matched ``Physics_Notes_Final.docx`` and a typo found
nothing, and (c) when the name was not an installed app, fall through to "open its website".  This module keeps a compact,
in-memory, token-based index of the user's own folders (Desktop, Documents, Downloads, Pictures, Videos, Music and their
OneDrive copies, plus any extra folders listed in ``friday_data/file_roots.txt``), refreshed quietly in the background, and
answers a spoken file request in a few milliseconds:

* spoken forms are understood ("resume dot pdf", "the pdf called invoice march", "my latest screenshot")
* names are tokenised (``Physics_Notes-Final2.docx`` -> physics / note / final / 2), plurals and small typos tolerated
* ranking = how completely the words are covered, exact/compact name match, newest first, shallow folders first,
  Desktop/Documents/Downloads first, the extension you asked for
* programs and scripts (.exe .bat .ps1 ...) are never offered, so a voice command can't run a downloaded installer

Standard library only.  Nothing here touches the microphone, recognition or speech code.
"""
from __future__ import annotations

import bisect
import difflib
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

_HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("FRIDAY_DATA_DIR") or (_HERE / "friday_data"))
CACHE_FILE = DATA_DIR / "file_index7.json"
ROOTS_FILE = DATA_DIR / "file_roots.txt"

MAX_FILES = 120_000
MAX_DEPTH = 8
MAX_DIR_ENTRY_DEPTH = 5
STALE_SECONDS = 15 * 60

SKIP_DIRS = {
    "node_modules", ".git", "__pycache__", "appdata", "venv", ".venv", "site-packages", "$recycle.bin", "system volume information",
    ".cache", ".idea", ".vscode", "dist-packages", ".gradle", ".m2", ".npm", "cache", "caches", "temp", "tmp", "build",
}
# programs / scripts / shortcuts / junk: never opened by a spoken file request
SKIP_EXT = {
    ".exe", ".msi", ".bat", ".cmd", ".ps1", ".vbs", ".vbe", ".jar", ".scr", ".com", ".reg", ".hta", ".wsf", ".msc", ".dll", ".sys",
    ".lnk", ".url", ".tmp", ".ini", ".dat", ".cache", ".db", ".lock", ".pyc", ".class", ".obj", ".o", ".crdownload", ".part", ".ds_store",
}

KIND_EXT: Dict[str, Tuple[str, ...]] = {
    "pdf": (".pdf",),
    "word": (".docx", ".doc", ".odt", ".rtf"),
    "docx": (".docx",), "doc": (".doc", ".docx"),
    "excel": (".xlsx", ".xls", ".csv", ".ods"), "spreadsheet": (".xlsx", ".xls", ".csv", ".ods"), "sheet": (".xlsx", ".xls", ".csv", ".ods"),
    "powerpoint": (".pptx", ".ppt", ".odp"), "presentation": (".pptx", ".ppt", ".odp"), "slides": (".pptx", ".ppt", ".odp"), "slide": (".pptx", ".ppt", ".odp"),
    "image": (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".heic"), "photo": (".jpg", ".jpeg", ".png", ".heic", ".webp"),
    "picture": (".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".heic"), "screenshot": (".png", ".jpg", ".jpeg"),
    "video": (".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm"), "movie": (".mp4", ".mkv", ".avi", ".mov", ".wmv", ".webm"),
    "music": (".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg"), "song": (".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg"),
    "audio": (".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg", ".opus"),
    "text": (".txt", ".md"), "notepad": (".txt",),
    "zip": (".zip", ".rar", ".7z"), "archive": (".zip", ".rar", ".7z"),
}
# these words are hints about the KIND of file when they stand next to a name; they are not part of the name
_HINT_WORDS = set(KIND_EXT) - {"word", "doc", "text", "sheet", "slide"}
KNOWN_EXT = {e.lstrip(".") for exts in KIND_EXT.values() for e in exts} | {
    "txt", "md", "csv", "json", "py", "html", "htm", "xml", "log", "rtf", "svg", "ipynb", "tex", "epub", "pages", "numbers", "key"}
_DOC_EXT = {".pdf", ".docx", ".doc", ".xlsx", ".xls", ".pptx", ".ppt", ".txt", ".md", ".csv", ".png", ".jpg", ".jpeg", ".mp4", ".mp3", ".odt", ".rtf"}

STOP = {
    "open", "opne", "opn", "launch", "start", "show", "find", "get", "pull", "bring", "up", "please", "pls", "can", "you", "could", "would",
    "friday", "hey", "the", "a", "an", "my", "me", "for", "file", "files", "folder", "folders", "directory", "document", "documents",
    "docs", "called", "named", "name", "titled", "that", "is", "in", "on", "from", "sir", "now", "i", "want", "to", "need", "of", "this",
    "one", "it", "locate", "look", "search", "where", "wheres", "s", "there", "with", "and", "then", "again", "us", "our", "your", "some",
    "latest", "newest", "recent", "recently", "last", "new", "newly",
}
_RECENT_WORDS = {"latest", "newest", "recent", "recently", "last", "newly"}

_SPLIT = re.compile(r"[^a-z0-9]+")
_CAMEL = re.compile(r"(?<=[a-z])(?=[A-Z])|(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])")


# ------------------------------------------------------------------ text helpers
def _stem(t: str) -> str:
    if t.isdigit() or len(t) <= 3:
        return t
    if len(t) > 4 and t.endswith("ies"):
        return t[:-3] + "y"
    if len(t) > 4 and t.endswith(("sses", "shes", "ches", "xes", "zes")):
        return t[:-2]
    if t.endswith("s") and not t.endswith(("ss", "us", "is")):
        return t[:-1]
    return t


def tokenize(name: str) -> List[str]:
    spaced = _CAMEL.sub(" ", name)
    out = []
    for w in _SPLIT.split(spaced.lower()):
        if w:
            out.append(_stem(w))
    return out


def _compact(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", name.lower())


def parse_request(text: str) -> Dict:
    """Understand a spoken/typed file request.  Returns tokens (stemmed), raw tokens, extension hints, folder/recent flags."""
    t = " " + str(text or "").lower() + " "
    t = re.sub(r"\b(?:hey\s+)?friday\b[,]?", " ", t)
    t = re.sub(r"\bdot\s+(pdf|docx?|xlsx?|pptx?|txt|csv|png|jpe?g|gif|mp3|mp4|wav|zip|md|json|py|html?|rtf|odt)\b", r".\1", t)
    t = re.sub(r"\bunderscore\b", "_", t)
    t = re.sub(r"\b(?:word|ms word|microsoft word)\s+(?:document|doc|file)\b", " word ", t)
    t = re.sub(r"\b(?:excel|powerpoint|power point)\s+(?:document|doc|file|sheet|workbook|presentation)\b", lambda m: " " + m.group(0).split()[0] + " ", t)
    t = t.replace("power point", "powerpoint")
    ext_hint: set = set()
    explicit_ext = False
    for m in re.finditer(r"\.([a-z0-9]{2,5})\b", t):
        if m.group(1) in KNOWN_EXT:
            ext_hint.add("." + m.group(1))
            if m.group(1) == "jpg":
                ext_hint.add(".jpeg")
            if m.group(1) == "docx":
                ext_hint.add(".doc")
            explicit_ext = True
    t_noext = re.sub(r"\.([a-z0-9]{2,5})\b", lambda m: " " if m.group(1) in KNOWN_EXT else m.group(0), t)
    words = re.findall(r"[a-z0-9]+", t_noext)
    folder_intent = any(w in ("folder", "folders", "directory", "directories") for w in words)
    file_intent = explicit_ext or any(w in {"file", "files", "document", "documents", "doc", "docs", "pdf", "pdfs", "photo", "photos", "picture", "pictures",
                                             "image", "images", "video", "videos", "presentation", "presentations", "spreadsheet", "spreadsheets",
                                             "worksheet", "worksheets", "essay", "essays", "report", "reports", "assignment", "assignments"} for w in words)
    recent = any(w in _RECENT_WORDS for w in words)
    raw: List[str] = []
    kind_words: List[str] = []
    for w in words:
        if w in STOP:
            continue
        ws = _stem(w)
        if w in KIND_EXT or ws in KIND_EXT:
            kind_words.append(ws if ws in KIND_EXT else w)
            continue
        raw.append(w)
    # kind words are hints, but if the user only said "pdf" / "photo" they ARE the request
    for k in kind_words:
        for e in KIND_EXT.get(k, ()):
            ext_hint.add(e)
    tokens = [_stem(w) for w in raw]
    # keep a kind word as a name token only when nothing else was said and no hint could use it
    return {"tokens": tokens, "raw": raw, "ext": sorted(ext_hint), "explicit_ext": explicit_ext, "folder": folder_intent,
            "file_intent": file_intent or bool(kind_words) or folder_intent, "recent": recent, "kind_words": kind_words,
            "compact": "".join(raw)}


# ------------------------------------------------------------------ roots + scanning
def default_roots() -> List[Path]:
    home = Path(os.path.expanduser("~"))
    names = ["Desktop", "Documents", "Downloads", "Pictures", "Videos", "Music"]
    bases: List[Path] = [home]
    for env in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        v = os.environ.get(env)
        if v:
            bases.append(Path(v))
    try:
        for p in home.iterdir():
            if p.name.lower().startswith("onedrive") and p.is_dir():
                bases.append(p)
    except Exception:
        pass
    roots: List[Path] = []
    seen = set()

    def _add(p: Path):
        try:
            if not p.is_dir():
                return
            key = str(p.resolve()).lower()
        except Exception:
            return
        if key not in seen:
            seen.add(key)
            roots.append(p)

    for n in names:
        for b in bases:
            _add(b / n)
    # common personal work folders directly under the user's home (never AppData or system folders)
    for n in ("source", "projects", "project", "dev", "code", "work", "github", "repos", "development", "school", "college", "university",
              "study", "studies", "dropbox", "google drive", "mega"):
        for b in bases[:1]:
            _add(b / n)
        try:
            for b in bases[:1]:
                for p2 in b.iterdir():
                    if p2.name.lower() == n and p2.is_dir():
                        _add(p2)
        except Exception:
            pass
    for v in (os.environ.get("FRIDAY_FILE_ROOTS") or "").split(os.pathsep):
        if v.strip():
            _add(Path(v.strip().strip('"')))
    try:
        if ROOTS_FILE.exists():
            for line in ROOTS_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip().strip('"')
                if line and not line.startswith("#"):
                    _add(Path(os.path.expandvars(os.path.expanduser(line))))
    except Exception:
        pass
    return roots


_ROOT_PRIORITY_NAMES = {"desktop": 6.0, "documents": 5.0, "downloads": 4.0}


def _scan(roots: List[Path], max_depth: int = MAX_DEPTH, cap: int = MAX_FILES, yield_every: int = 400) -> List[tuple]:
    """Raw scan -> [(path, mtime, isdir, depth, pri)].  Never raises."""
    out: List[tuple] = []
    seen_dirs = set()
    n = 0
    for root in roots:
        pri = _ROOT_PRIORITY_NAMES.get(root.name.lower(), 2.0)
        stack = [(str(root), 0)]
        while stack:
            d, depth = stack.pop()
            try:
                real = os.path.realpath(d)
                if real in seen_dirs:
                    continue
                seen_dirs.add(real)
                with os.scandir(d) as it:
                    for e in it:
                        name = e.name
                        if name.startswith((".", "~$")):
                            continue
                        try:
                            is_dir = e.is_dir(follow_symlinks=False)
                        except OSError:
                            continue
                        if is_dir:
                            if name.lower() in SKIP_DIRS:
                                continue
                            if depth + 1 <= max_depth:
                                stack.append((e.path, depth + 1))
                            if depth + 1 <= MAX_DIR_ENTRY_DEPTH:
                                try:
                                    out.append((e.path, e.stat(follow_symlinks=False).st_mtime, True, depth + 1, pri))
                                except OSError:
                                    pass
                        else:
                            ext = os.path.splitext(name)[1].lower()
                            if ext in SKIP_EXT:
                                continue
                            try:
                                mt = e.stat(follow_symlinks=False).st_mtime
                            except OSError:
                                continue
                            out.append((e.path, mt, False, depth + 1, pri))
                        n += 1
                        if n % yield_every == 0:
                            time.sleep(0.0008)          # stay out of the way of the voice threads
                if len(out) >= cap:
                    return out
            except (PermissionError, OSError):
                continue
            except Exception:
                continue
    return out


def _entry(raw: tuple) -> tuple:
    """(path, mtime, isdir, depth, pri) -> index entry with tokens."""
    path, mtime, isdir, depth, pri = raw
    base = os.path.basename(path)
    stem, ext = (base, "") if isdir else os.path.splitext(base)
    toks = tuple(dict.fromkeys(tokenize(stem)))
    return (path, stem, ext.lower(), float(mtime), bool(isdir), int(depth), float(pri), toks, _compact(stem))


# ------------------------------------------------------------------ the index
class _Index:
    def __init__(self):
        self.lock = threading.RLock()
        self.items: List[tuple] = []
        self.inv: Dict[str, List[int]] = {}
        self.vocab: List[str] = []                  # sorted tokens
        self.by_len: Dict[int, List[str]] = {}
        self.paths: set = set()
        self.built_at = 0.0
        self.building = False
        self.ready = threading.Event()
        self.last_error = ""
        self.roots: List[str] = []
        self.last_used = time.time()

    # -- structure
    def _structure(self, entries: List[tuple]):
        inv: Dict[str, List[int]] = {}
        for i, e in enumerate(entries):
            for t in e[7]:
                inv.setdefault(t, []).append(i)
        vocab = sorted(inv)
        by_len: Dict[int, List[str]] = {}
        for t in vocab:
            by_len.setdefault(len(t), []).append(t)
        return inv, vocab, by_len

    def replace(self, entries: List[tuple], roots: Optional[List[str]] = None):
        inv, vocab, by_len = self._structure(entries)
        with self.lock:
            self.items, self.inv, self.vocab, self.by_len = entries, inv, vocab, by_len
            self.paths = {e[0] for e in entries}
            self.built_at = time.time()
            if roots is not None:
                self.roots = roots
        self.ready.set()

    def add(self, entries: List[tuple]) -> int:
        added = 0
        with self.lock:
            for e in entries:
                if e[0] in self.paths:
                    continue
                i = len(self.items)
                self.items.append(e)
                self.paths.add(e[0])
                for t in e[7]:
                    lst = self.inv.get(t)
                    if lst is None:
                        self.inv[t] = [i]
                        bisect.insort(self.vocab, t)
                        self.by_len.setdefault(len(t), []).append(t)
                    else:
                        lst.append(i)
                added += 1
        return added


_IDX = _Index()
_build_lock = threading.Lock()


def _lower_thread_priority():
    try:
        if os.name == "nt":
            import ctypes
            k = ctypes.windll.kernel32
            k.SetThreadPriority(k.GetCurrentThread(), -1)       # THREAD_PRIORITY_BELOW_NORMAL
    except Exception:
        pass


def _light_mode() -> bool:
    try:
        h = sys.modules.get("friday_health7")
        return bool(h is not None and h.light_mode())
    except Exception:
        return False


def _save_cache(raws: List[tuple], roots: List[str]):
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        tmp = CACHE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps({"v": 1, "ts": time.time(), "roots": roots, "items": [[r[0], r[1], 1 if r[2] else 0, r[3], r[4]] for r in raws]},
                                  separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, CACHE_FILE)
    except Exception:
        pass


def _load_cache(roots: List[str]) -> bool:
    try:
        if not CACHE_FILE.exists():
            return False
        j = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        if j.get("v") != 1 or sorted(j.get("roots") or []) != sorted(roots):
            return False
        items = j.get("items") or []
        entries = [_entry((p, m, bool(d), dep, pri)) for p, m, d, dep, pri in items]
        _IDX.replace(entries, roots)
        _IDX.built_at = float(j.get("ts") or time.time())
        return True
    except Exception:
        return False


def rebuild(force: bool = False, background: bool = True) -> bool:
    """(Re)scan the folders.  Safe to call any time; only one build runs at once."""
    if _IDX.building:
        return False
    if not force and _IDX.ready.is_set() and time.time() - _IDX.built_at < STALE_SECONDS:
        return False

    def _work():
        if not _build_lock.acquire(blocking=False):
            return
        _IDX.building = True
        try:
            _lower_thread_priority()
            roots = default_roots()
            rs = [str(r) for r in roots]
            raws = _scan(roots)
            entries = [_entry(r) for r in raws]
            _IDX.replace(entries, rs)
            _save_cache(raws, rs)
            _IDX.last_error = ""
        except Exception as exc:          # a failed refresh keeps the previous index
            _IDX.last_error = f"{type(exc).__name__}: {exc}"[:200]
        finally:
            _IDX.building = False
            _build_lock.release()

    if background:
        threading.Thread(target=_work, name="FridayFileIndex", daemon=True).start()
    else:
        _work()
    return True


def warm(delay: float = 0.0):
    """Called once at start-up: load the saved index instantly, then refresh quietly in the background."""
    def _go():
        if delay:
            time.sleep(delay)
        if _light_mode():
            time.sleep(20)
        try:
            roots = [str(r) for r in default_roots()]
            loaded = _load_cache(roots)
            if not loaded or time.time() - _IDX.built_at >= STALE_SECONDS:
                rebuild(force=True, background=False)
        except Exception as exc:
            _IDX.last_error = f"{type(exc).__name__}: {exc}"[:200]
    threading.Thread(target=_go, name="FridayFileWarm", daemon=True).start()


def unload() -> int:
    """Release the in-memory index (the on-disk cache stays). The next search reloads it from that cache in a moment. Returns how many entries were released."""
    if _IDX.building:
        return 0
    with _IDX.lock:
        n = len(_IDX.items)
        _IDX.items, _IDX.inv, _IDX.vocab, _IDX.by_len, _IDX.paths = [], {}, [], {}, set()
    _IDX.ready.clear()
    return n


def idle_seconds() -> float:
    return time.time() - _IDX.last_used


def _ensure(wait: float):
    """Make sure there is an index to search; the first-ever request waits (briefly) for the first build."""
    _IDX.last_used = time.time()
    if not _IDX.ready.is_set() and not _IDX.building:        # released while idle: bring the saved index back before scanning the disk again
        try:
            _load_cache([str(r) for r in default_roots()])
        except Exception:
            pass
    if _IDX.ready.is_set():
        if time.time() - _IDX.built_at > STALE_SECONDS and not _IDX.building and not _light_mode():
            rebuild(force=True, background=True)
        return
    if not _IDX.building:
        rebuild(force=True, background=True)
    _IDX.ready.wait(timeout=max(0.0, wait))


def _rescan_hot() -> int:
    """A file may have appeared a moment ago (just downloaded): look at the top two levels of every folder again."""
    try:
        roots = default_roots()
        raws = _scan(roots, max_depth=2, cap=40_000, yield_every=2000)
        return _IDX.add([_entry(r) for r in raws if r[0] not in _IDX.paths])
    except Exception:
        return 0


# ------------------------------------------------------------------ matching
def _token_matches(q: str) -> Dict[str, float]:
    """index tokens that satisfy query token q -> weight (1.0 exact, 0.78 prefix, ~0.6 fuzzy)."""
    inv, vocab, by_len = _IDX.inv, _IDX.vocab, _IDX.by_len
    out: Dict[str, float] = {}
    if q in inv:
        out[q] = 1.0
    if q.isdigit():
        return out
    if len(q) >= 3:
        lo = bisect.bisect_left(vocab, q)
        k = lo
        while k < len(vocab) and vocab[k].startswith(q) and k - lo < 400:
            if vocab[k] not in out:
                out[vocab[k]] = 0.78 if len(vocab[k]) - len(q) <= 6 else 0.7
            k += 1
        # the user said a longer form of a short token ("notebook" for "note")? only for 4+ letters
        if len(q) >= 5:
            for cut in range(len(q) - 1, 3, -1):
                p = q[:cut]
                if p in inv and p not in out:
                    out[p] = 0.58
                    break
    if len(q) >= 4 and not any(w >= 0.78 for w in out.values()):
        pool: List[str] = []
        for L in range(len(q) - 2, len(q) + 3):
            pool.extend(by_len.get(L, ()))
        for cand in difflib.get_close_matches(q, pool, n=4, cutoff=0.78):
            if cand not in out:
                out[cand] = max(0.56, 0.62 * difflib.SequenceMatcher(None, q, cand).ratio() + 0.02)
    return out


def _recency_bonus(mtime: float, now: float) -> float:
    age = max(0.0, now - mtime) / 86400.0
    if age <= 1:
        return 6.0
    if age <= 7:
        return 4.0
    if age <= 30:
        return 2.0
    if age <= 180:
        return 1.0
    return 0.0


def rank(req: Dict, limit: int = 8) -> List[Dict]:
    toks: List[str] = req["tokens"]
    now = time.time()
    with _IDX.lock:
        items = _IDX.items
        ext_hint = set(req.get("ext") or [])
        results: List[Tuple[float, int, List[float], float]] = []
        if not toks:
            # "my latest pdf" / "the newest photo": no name at all, only a kind of file
            if not (ext_hint and req.get("recent")):
                return []
            for i, e in enumerate(items):
                if e[4] or e[2] not in ext_hint:
                    continue
                results.append((e[3], i, [], 1.0))
            results.sort(key=lambda r: -r[0])
            return _finish(results[:limit], req, items, now, toks, recent_only=True)
        n = len(toks)
        weights = [1.0 + min(len(t), 8) / 8.0 for t in toks]
        total_w = sum(weights)
        cand: Dict[int, List[float]] = {}
        for qi, q in enumerate(toks):
            ws = _token_matches(q)
            best_for_item: Dict[int, float] = {}
            for tok, w in ws.items():
                for i in _IDX.inv.get(tok, ()):
                    if w > best_for_item.get(i, 0.0):
                        best_for_item[i] = w
            for i, w in best_for_item.items():
                row = cand.get(i)
                if row is None:
                    row = cand[i] = [0.0] * n
                row[qi] = w
        need = n if n <= 2 else int(n * 0.66 + 0.999)
        qcompact = req.get("compact") or "".join(toks)
        folder_intent = bool(req.get("folder"))
        for i, row in cand.items():
            matched = sum(1 for w in row if w >= 0.55)
            if matched < need:
                continue
            e = items[i]
            cov = sum((w if w >= 0.55 else 0.0) * wt for w, wt in zip(row, weights)) / total_w
            score = 100.0 * cov
            extra = max(0, len(e[7]) - matched)
            score -= min(extra, 6) * 2.5
            comp = e[8]
            if comp == qcompact:
                score += 40.0
            elif comp.startswith(qcompact):
                score += 12.0
            elif qcompact and qcompact in comp:
                score += 6.0
            score += e[6]                                   # folder priority (Desktop > Documents > Downloads > rest)
            score += _recency_bonus(e[3], now)
            score -= 0.8 * min(e[5], 8)
            if e[2] in _DOC_EXT:
                score += 2.0
            if ext_hint:
                if e[2] in ext_hint:
                    score += 60.0 if req.get("explicit_ext") else 35.0
            if e[4]:
                score += 20.0 if folder_intent else -20.0
            elif folder_intent:
                score -= 20.0
            results.append((score, i, row, cov))
        results.sort(key=lambda r: (-r[0], -items[r[1]][3]))
        if ext_hint and any(items[r[1]][2] in ext_hint for r in results):
            results = [r for r in results if items[r[1]][2] in ext_hint]
        if req.get("recent"):
            top = results[:12]
            top.sort(key=lambda r: -items[r[1]][3])
            results = top + results[12:]
        return _finish(results[:limit], req, items, now, toks)


def _finish(results, req, items, now, toks, recent_only: bool = False) -> List[Dict]:
    out: List[Dict] = []
    n = len(toks)
    for rank_i, (score, i, row, cov) in enumerate(results):
        e = items[i]
        if recent_only:
            conf = "medium"
        else:
            full = n > 0 and all(w >= 0.55 for w in row)
            strong = full and min(row) >= 0.75 and cov >= 0.9
            conf = "high" if strong else ("medium" if full else "low")
        out.append({"path": e[0], "name": os.path.basename(e[0]), "stem": e[1], "ext": e[2], "isdir": e[4], "mtime": e[3],
                    "score": round(score, 1), "confidence": conf, "coverage": round(cov, 2)})
    if out:
        top = out[0]
        ties = [o for o in out[1:] if o["score"] >= top["score"] - 4.0 and o["confidence"] != "low" and top["confidence"] != "low"]
        top["ties"] = len(ties)
        if ties and not req.get("recent"):
            pick = max([top] + ties, key=lambda o: o["mtime"])       # same score: the one you touched most recently
            if pick is not top:
                out.remove(pick)
                out.insert(0, pick)
                pick["ties"] = len(ties)
                top["ties"] = 0
    return out


def search(query: str, limit: int = 8, wait: float = 2.5) -> List[Dict]:
    """Ranked matches for a spoken/typed request (best first).  Refreshes the index itself when it has to."""
    req = parse_request(query)
    if not req["tokens"] and not (req["ext"] and req["recent"]):
        return []
    _ensure(wait)
    res = rank(req, limit)
    res = [r for r in res if os.path.exists(r["path"])] if res else res
    if not res or res[0]["confidence"] == "low":
        if _rescan_hot():
            better = [r for r in rank(req, limit) if os.path.exists(r["path"])]
            if better and (not res or better[0]["score"] >= res[0]["score"]):
                res = better
    return res


def best(query: str, wait: float = 2.5) -> Optional[Dict]:
    """The single best file for the request, with .alternatives (next names) and .ties; None when nothing matches."""
    res = search(query, limit=6, wait=wait)
    if not res:
        return None
    top = dict(res[0])
    top["alternatives"] = [r["name"] for r in res[1:4]]
    top["request"] = parse_request(query)
    return top


def find_paths(query: str, limit: int = 50, where: Optional[str] = None) -> List[str]:
    """Drop-in for the old substring search: ranked paths.  ``where`` limits results to a folder."""
    res = search(query, limit=limit * 3 if where else limit)
    paths = [r["path"] for r in res]
    if where:
        w = os.path.normcase(os.path.abspath(where))
        paths = [p for p in paths if os.path.normcase(p).startswith(w)]
    return paths[:limit]


def open_path(path: str, opener: Optional[Callable[[str], None]] = None) -> bool:
    try:
        if opener is not None:
            opener(path)
        elif os.name == "nt":
            os.startfile(path)                                     # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def spoken_name(hit: Dict) -> str:
    s = hit.get("stem") or hit.get("name") or ""
    s = re.sub(r"[_\-]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s[:60]


def status() -> Dict:
    return {"files": len(_IDX.items), "built_at": _IDX.built_at, "building": _IDX.building, "ready": _IDX.ready.is_set(),
            "roots": list(_IDX.roots), "error": _IDX.last_error}


def reset_for_tests():
    global _IDX
    _IDX = _Index()
