"""FRIDAY 6.0 hybrid model routing, fallback, caching, retries, resource management and performance profiling
(blueprint sections 1 "multi-model / routing", 13 "cloud + local models", 17 "speed and resources").

* providers      cloud (Gemini through the backend) and optional local (Ollama on this PC) behind one `call()`
* routing        coding / research / maths / chat -> the right tier; privacy words -> local model when available
* fallback       circuit breaker per provider, timeouts, retries with back-off, automatic fallback to the next provider
* caching        short-lived cache for repeatable, non-personal prompts
* monitoring     CPU / RAM / disk / battery / network, hardware profile (low / medium / high) and model-loading policy
* metrics        latency, reliability and rough cost per provider and tier (feeds the continuous-evaluation module)
"""
from __future__ import annotations

import json
import re
import threading
import time
import urllib.request
from collections import OrderedDict
from typing import Callable, Dict, List, Optional

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS model_calls6(id INTEGER PRIMARY KEY, ts REAL, provider TEXT, tier TEXT, task TEXT, ms INTEGER, ok INTEGER, chars INTEGER, cached INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS cfg6(k TEXT PRIMARY KEY, v TEXT);
""")

_providers: Dict[str, Dict] = {}
_cache: "OrderedDict[str, tuple]" = OrderedDict()
_cache_lock = threading.Lock()
_cancel = threading.Event()
CACHE_TTL = 600.0
COST_PER_1K = {"cloud": 0.0004, "local": 0.0}       # rough relative cost units, used only to compare routes


def cfg(k: str, default: str = "") -> str:
    r = C.q("SELECT v FROM cfg6 WHERE k=?", (k,))
    return r[0]["v"] if r else default


def set_cfg(k: str, v: str):
    C.x("INSERT INTO cfg6(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))


def register_provider(name: str, fn: Callable[[str, str], str], kind: str = "cloud"):
    _providers[name] = {"fn": fn, "kind": kind, "fails": 0, "open_until": 0.0}


def providers() -> List[Dict]:
    return [{"name": n, "kind": p["kind"], "healthy": time.time() >= p["open_until"], "fails": p["fails"]} for n, p in _providers.items()]


# ------------------------------------------------------------------ local model (Ollama) - optional
def ollama_available() -> bool:
    try:
        urllib.request.urlopen(cfg("ollama_url", "http://127.0.0.1:11434") + "/api/tags", timeout=0.6).read(64)
        return True
    except Exception:
        return False


def _ollama_call(prompt: str, tier: str) -> str:
    url = cfg("ollama_url", "http://127.0.0.1:11434") + "/api/generate"
    model = cfg("ollama_model", "llama3.2")
    req = urllib.request.Request(url, data=json.dumps({"model": model, "prompt": prompt, "stream": False}).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return str(json.loads(r.read().decode()).get("response", ""))


def enable_local():
    if "local" not in _providers:
        register_provider("local", _ollama_call, "local")


# ------------------------------------------------------------------ routing
_RE_CODE = re.compile(r"\b(code|function|bug|debug|script|python|javascript|compile|regex|sql|refactor|class|stack ?trace|api)\b", re.I)
_RE_MATH = re.compile(r"\b(solve|integral|derivative|equation|probability|prove|calculate|statistic|matrix|theorem)\b|\d\s*[\^*/]\s*\d", re.I)
_RE_RESEARCH = re.compile(r"\b(research|sources?|latest|compare|literature|evidence|cite|news)\b", re.I)
_RE_PRIVATE = re.compile(r"\b(private|confidential|offline|don'?t send|keep (?:this )?local|personal diary|medical|password)\b", re.I)


def classify_task(text: str) -> str:
    if _RE_CODE.search(text):
        return "coding"
    if _RE_MATH.search(text):
        return "maths"
    if _RE_RESEARCH.search(text):
        return "research"
    return "chat" if len(text.split()) < 40 else "analysis"


def choose(text: str, tier: Optional[str] = None) -> Dict:
    task = classify_task(text)
    tier = tier or ("deep" if task in ("coding", "maths", "research", "analysis") else "fast")
    mode = cfg("routing", "auto")                          # auto | cloud | local
    order: List[str] = []
    local_ok = "local" in _providers and (mode == "local" or ollama_available())
    private = bool(_RE_PRIVATE.search(text)) or mode == "local"
    if private and local_ok:
        order = ["local", "gemini"] if mode != "local" else ["local"]
    elif tier == "fast" and local_ok and mode == "auto" and len(text) < 300 and cfg("prefer_local_small", "0") == "1":
        order = ["local", "gemini"]
    else:
        order = ["gemini"] + (["local"] if local_ok else [])
    return {"task": task, "tier": tier, "order": [o for o in order if o in _providers], "private": private}


def call(prompt: str, tier: Optional[str] = None, retries: int = 1, timeout: float = 45.0, cache: bool = True) -> str:
    """Route -> (cache) -> provider with timeout -> retry/back-off -> fall back to the next provider. Returns '' when everything failed."""
    plan = choose(prompt, tier)
    key = None
    if cache and not plan["private"] and "{memory}" not in prompt and len(prompt) < 4000:
        key = plan["tier"] + "|" + C.fingerprint(prompt)
        with _cache_lock:
            hit = _cache.get(key)
            if hit and time.time() - hit[1] < CACHE_TTL:
                C.x("INSERT INTO model_calls6(ts,provider,tier,task,ms,ok,chars,cached) VALUES(?,?,?,?,?,?,?,1)", (C.now(), "cache", plan["tier"], plan["task"], 0, 1, len(hit[0])))
                return hit[0]
    for name in plan["order"]:
        p = _providers[name]
        if time.time() < p["open_until"]:
            continue                                            # circuit open: skip this provider for a while
        for attempt in range(retries + 1):
            if _cancel.is_set():
                return ""
            t0 = time.time()
            box: Dict = {}

            def run():
                try:
                    box["r"] = p["fn"](prompt, plan["tier"])
                except Exception as exc:
                    box["e"] = exc

            th = threading.Thread(target=run, daemon=True)
            th.start()
            th.join(timeout)
            ms = int((time.time() - t0) * 1000)
            out = str(box.get("r") or "")
            ok = bool(out.strip()) and "e" not in box
            C.x("INSERT INTO model_calls6(ts,provider,tier,task,ms,ok,chars) VALUES(?,?,?,?,?,?,?)", (C.now(), name, plan["tier"], plan["task"], ms, int(ok), len(out)))
            if ok:
                p["fails"] = 0
                if key:
                    with _cache_lock:
                        _cache[key] = (out, time.time())
                        while len(_cache) > 128:
                            _cache.popitem(last=False)
                return out
            p["fails"] += 1
            if p["fails"] >= 3:
                p["open_until"] = time.time() + 30.0         # breaker: 30 s cool-down, then try again
                break
            time.sleep(min(1.5, 0.3 * (attempt + 1)))        # back-off
    return ""


def cancel_current():
    _cancel.set()
    threading.Timer(0.5, _cancel.clear).start()


def metrics() -> Dict:
    rows = C.q("SELECT provider, tier, COUNT(*) n, AVG(ms) ms, AVG(ok) rel, SUM(chars) ch FROM model_calls6 GROUP BY provider, tier ORDER BY provider")
    return {"routes": [{"provider": r["provider"], "tier": r["tier"], "calls": r["n"], "avg_ms": int(r["ms"] or 0), "reliability": round(r["rel"] or 0, 3),
                        "rel_cost": round((r["ch"] or 0) / 4000 * COST_PER_1K.get("local" if r["provider"] == "local" else "cloud", 0.0004), 5)} for r in rows],
            "providers": providers(), "cache_entries": len(_cache), "routing": cfg("routing", "auto")}


# ------------------------------------------------------------------ resources
def resources() -> Dict:
    out = {"cpu": None, "ram": None, "disk": None, "battery": None, "plugged": None, "net_kbps": None, "process_mb": None}
    try:
        import psutil
        out["cpu"] = psutil.cpu_percent(interval=0.15)
        vm = psutil.virtual_memory()
        out["ram"] = round(vm.percent, 1)
        out["ram_total_gb"] = round(vm.total / 1e9, 1)
        out["disk"] = round(psutil.disk_usage(str(C.DATA_DIR.anchor or "/")).percent, 1)
        b = psutil.sensors_battery()
        if b:
            out["battery"], out["plugged"] = round(b.percent), bool(b.power_plugged)
        n1 = psutil.net_io_counters(); time.sleep(0.1); n2 = psutil.net_io_counters()
        out["net_kbps"] = round(((n2.bytes_sent + n2.bytes_recv) - (n1.bytes_sent + n1.bytes_recv)) / 0.1 / 1024, 1)
        out["process_mb"] = round(psutil.Process().memory_info().rss / 1e6, 1)
        out["cores"] = psutil.cpu_count()
    except Exception:
        pass
    return out


def hardware_profile() -> Dict:
    """low / medium / high - drives graceful degradation on limited hardware and model loading policy."""
    r = resources()
    gb, cores = r.get("ram_total_gb") or 8, r.get("cores") or 4
    level = "low" if (gb < 6 or cores <= 2) else ("high" if (gb >= 16 and cores >= 8) else "medium")
    policy = {"low": {"whisper": "tiny.en", "animations": "reduced", "parallel_agents": 1, "unload_idle_models_s": 120},
              "medium": {"whisper": "base.en", "animations": "full", "parallel_agents": 2, "unload_idle_models_s": 600},
              "high": {"whisper": "small.en", "animations": "full", "parallel_agents": 3, "unload_idle_models_s": 1800}}[level]
    stressed = (r.get("ram") or 0) > 90 or (r.get("cpu") or 0) > 95
    return {"level": level, "policy": policy, "stressed": stressed, "resources": r}


def profile(fn: Callable, *a, repeat: int = 5, **kw) -> Dict:
    ts = []
    for _ in range(max(1, repeat)):
        t0 = time.perf_counter()
        fn(*a, **kw)
        ts.append((time.perf_counter() - t0) * 1000)
    ts.sort()
    return {"runs": len(ts), "min_ms": round(ts[0], 2), "median_ms": round(ts[len(ts) // 2], 2), "max_ms": round(ts[-1], 2)}


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if re.match(r"^(?:system|resource|performance) (?:status|monitor|usage)$|^how(?:'s| is) (?:my|the) (?:pc|computer|system) (?:doing|performing)$|^performance monitor$", low):
        r = resources()
        bits = [f"CPU {r['cpu']} percent" if r["cpu"] is not None else "", f"memory {r['ram']} percent" if r["ram"] is not None else "", f"disk {r['disk']} percent" if r["disk"] is not None else "",
                (f"battery {r['battery']} percent" + (", charging" if r["plugged"] else "")) if r["battery"] is not None else "", f"my own process {r['process_mb']} megabytes" if r["process_mb"] else ""]
        return "Right now: " + ", ".join(b for b in bits if b) + "."
    m = re.match(r"^(?:use|switch to|set routing to) (auto|cloud|local|offline) (?:model|models|routing|mode)?$|^(?:use|run) (?:the )?(cloud|local) (?:model|models) (?:only|always)$", low)
    if m:
        mode = (m.group(1) or m.group(2)).replace("offline", "local")
        if mode == "local":
            enable_local()
            if not ollama_available():
                return "I can't reach a local model. Install Ollama, pull a model, and I'll use it. Staying on automatic routing for now."
        set_cfg("routing", mode)
        return f"Model routing set to {mode}."
    if re.match(r"^(?:model|routing|latency) (?:stats|statistics|report|metrics)$|^how fast are you$", low):
        m2 = metrics()["routes"]
        return "No model calls recorded yet." if not m2 else "Model stats: " + "; ".join(f"{r['provider']} {r['tier']}: {r['calls']} calls, {r['avg_ms']} ms, {int(r['reliability'] * 100)} percent reliable" for r in m2[:4]) + "."
    if re.match(r"^(?:hardware|what hardware|how powerful is (?:my|this) (?:pc|computer)|check my hardware)$", low):
        h = hardware_profile()
        return f"This machine rates as {h['level']} spec. I'll use the {h['policy']['whisper']} listening model and {h['policy']['parallel_agents']} parallel agent(s)." + (" It's under heavy load right now, so I'll keep things light." if h["stressed"] else "")
    return None
