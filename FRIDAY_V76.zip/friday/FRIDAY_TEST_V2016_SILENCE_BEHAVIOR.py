from pathlib import Path

backend = Path(__file__).with_name("friday_backend.py").read_text(encoding="utf-8")

assert 'def _capture_until_silence(source):' in backend
assert 'LISTEN_TIMEOUT_SECONDS = None' in backend
assert 'PHRASE_TIME_LIMIT_SECONDS = None' in backend
assert 'def _capture_until_silence(source):' in backend
listen_body = backend[backend.index('def listen():'):backend.index('def listen():') + 4000]
assert 'audio = _capture_until_silence(source)' in listen_body
assert 'audio = recognizer.listen(source' not in listen_body

print("PASS: FRIDAY waits indefinitely for first speech, then ends only after 1.25s of continuous silence.")
