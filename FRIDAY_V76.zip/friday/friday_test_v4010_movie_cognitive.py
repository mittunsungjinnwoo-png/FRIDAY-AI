import os, sys, time
sys.path.insert(0, os.path.dirname(__file__))
import friday_movie_cognitive_engine as c

def test_simple_fast():
    d=c.begin_turn('close WhatsApp for me', {})
    assert d['preferred_route']=='fast'
    assert not d['needs_planning']

def test_complex_plan():
    d=c.begin_turn('research the latest chemistry bonding topic and make a PDF report', {})
    assert d['needs_planning']
    assert d['needs_external_evidence']
    assert d['preferred_route']=='evidence_planned'
    assert 'browser' in d['prerequisites'] or 'word' in d['prerequisites']

def test_consequential_supervised():
    d=c.begin_turn('send this message to Harshik on WhatsApp', {'topic':'WhatsApp'})
    assert d['consequential']
    assert d['preferred_route']=='supervised'

def test_reference_ambiguity():
    d=c.begin_turn('open it', {})
    assert d['ambiguity'] > 0.3

if __name__=='__main__':
    test_simple_fast(); test_complex_plan(); test_consequential_supervised(); test_reference_ambiguity(); print('PASS: movie cognitive engine tests')
