# FRIDAY V2201 - full UI customisation (Settings)

Open **Settings** (sidebar gear or the "S" button). Seven tabs:

- **Appearance** - 7 one-tap looks (Stark Blue, Mark VII, Emerald Ops, Violet Nebula, Amber Terminal, Ghost Mono, Daylight); dark / light / match Windows; any accent colour and any background colour; background style (soft glow, flat, tech grid, aurora, starfield, scanlines); solid or frosted-glass panels; glow strength; corner roundness; font; animations on/off.
- **Reactor** - 8 arc reactor designs with live previews (Classic HUD, Stark Core, Orb, Gyro, Hex Grid, Voice Wave, Pulse, Static); match the accent or use its own colour; size, speed, glow; test Idle / Listening / Speaking.
- **Icons** - line style (thin, regular, bold, glow, neon), colour (default, accent, text, rainbow), holder shape (rounded, circle, square, none), size.
- **Widget** - desktop widget type: reactor + hover panel, reactor only, mini orb, command bar; opacity; always on top; its own reactor design.
- **Layout** - sidebar (full / icons only / hidden) and which pages show; show or hide each right-hand panel; spacing (compact / comfortable / roomy); interface size 80-130%.
- **Assistant** - how FRIDAY addresses you: Sir, Madam, Ma'am, Boss, Captain, your name, any custom title, or no title. Applies to the greeting, on-screen replies AND spoken replies. Also greeting style, the line under the greeting, and the name/tagline shown on screen.
- **General** - the original settings (currency, permissions, erase data) plus export / import / reset of your look.

## Files
- NEW `friday_theme.js` (theme engine + reactor designs, shared by dashboard and widget)
- NEW `friday_settings.js` (the Settings screens)
- `index.html`, `widget.html` - colours moved to theme variables; default look is unchanged
- `preload.js`, `main.js` - saves the look to `friday_data/ui_config.json`, syncs dashboard and widget live, resizes the widget, interface zoom
- `friday_backend.py` - the spoken "sir" now follows your chosen address (`__FRIDAY_ADDRESS__` command)

Wake word stays "Friday".
