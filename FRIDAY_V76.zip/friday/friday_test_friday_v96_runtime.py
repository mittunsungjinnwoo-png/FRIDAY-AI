import os, tempfile
import friday_v96_runtime as r

assert r.permission_level("what is the weather")[0] == 0
assert r.permission_level("click 500 400")[0] == 1
assert r.permission_level("delete all files")[0] == 4

t=r.create_task("runtime smoke",["research","verify"])
assert t["status"]=="queued" and len(t["steps"])==2
r.set_step(t["id"],0,"verified",100)
r.set_step(t["id"],1,"done",100)
assert r.TASKS[t["id"]]["progress"]==100

r.remember("runtime smoke remembers autonomous task", "test", .9)
hits=r.recall("autonomous task",10)
assert hits

assert r.resolve_reference("summarize it", "AI agents").endswith("regarding AI agents")

seen=[]
r.register_tool("test.echo","test",lambda value: {"ok":True,"value":value},0)
out=r.run_tool("test.echo",value="ok")
assert out["ok"] and out["value"]=="ok"

r.TASKS.pop(t["id"],None)
r.MEMORY[:] = [m for m in r.MEMORY if m.get("kind")!="test"]
r._persist_tasks(); r._save(r.MEMORY_FILE,r.MEMORY)
print("FRIDAY v96 runtime smoke: PASS")
