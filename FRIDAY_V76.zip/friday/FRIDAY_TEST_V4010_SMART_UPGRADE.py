"""V4010.2 targeted regression suite.
Tests new reasoning/router logic without requiring microphone, TTS, Gemini, or GUI.
"""
from pathlib import Path
import ast, zipfile, hashlib, sys
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from friday_adaptive_reasoning import analyze, plan, canonical_app_command
from friday_smart_router import classify

# 1) Natural language normalization / intent understanding.
assert canonical_app_command("Friday, can u close WhatsApp for me") == "close whatsapp"
assert canonical_app_command("please open google chrome right now") == "open chrome"
assert canonical_app_command("launch spottyfy please") == "open spotify"
assert canonical_app_command("can you close WhatsApp and then open Chrome") is None

# 2) Confidence and route selection.
a = analyze("can you close WhatsApp for me")
assert a.route == "deterministic" and a.confidence >= .90
b = analyze("research the latest AI chips and make a PDF report")
assert b.route in {"planned", "generative"} and len(b.steps) >= 1
p = plan("research the latest AI chips and make a PDF report")
assert "evidence_check" in p["gates"] and "output_check" in p["gates"] and "verify" in p["gates"]

# 3) Existing smart router remains compatible.
r = classify("hey Friday, can u close WhatsApp for me")
assert r is not None and r.canonical == "close whatsapp" and r.confidence >= .90

# 4) Parse every Python file after the upgrade.
for path in ROOT.glob("*.py"):
    ast.parse(path.read_text(encoding="utf-8", errors="ignore"), filename=str(path))

# 5) Voice engine remains byte-for-byte identical to the supplied V4010 source.
source_zip = Path("/mnt/data/FRIDAY_V4010_SMARTER_AUTONOMY_FAST.zip")
with zipfile.ZipFile(source_zip) as z:
    original_voice = z.read("friday/friday_voice_engine.py")
assert hashlib.sha256((ROOT / "friday_voice_engine.py").read_bytes()).digest() == hashlib.sha256(original_voice).digest()

print("V4010.2 SMART ROUTER=PASS")
print("V4010.2 ADAPTIVE REASONING=PASS")
print("V4010.2 AST ALL PYTHON=PASS")
print("V4010.2 VOICE ENGINE UNCHANGED=PASS")
