# FRIDAY V2.2.7 - computer control: minimise + go back to an open app (only these two fixed)

## Problem
- "Minimise <app>" was a blind Alt+Space,N keystroke sent to whatever window was in front (usually FRIDAY itself),
  and was reported as done without checking. The spelling "minimise" was not even recognised by that path.
- "Go back to / switch to <app>" had no handler, and "open <app>" for an app that was already running never brought
  its window forward but still said it was open.

## Fix
- friday_system_control.py: new real window control (Win32 EnumWindows/ShowWindow/SetForegroundWindow, with the
  Alt-tap + thread-attach trick so Windows allows the focus change). FRIDAY's own windows are never targeted.
  Success is reported only after re-checking IsIconic (minimise) / GetForegroundWindow (bring to front).
- friday_backend.py: try_handle_window_control() understands "minimise/minimize <app>", "minimise this/all windows",
  "go back to / switch to / bring back / focus <app>", "go back to the previous app". Honest spoken result if the app
  isn't open or Windows refuses. Not-an-app phrases ("switch to dark mode") fall through as before.
  "minimise friday/yourself/the interface" (British spelling) now also reaches the existing FRIDAY-minimise branch.
- friday_app_launcher.py / friday_desktop_agent.py: "open <app>" on an already-open app now restores/brings that
  window to the front and only claims success once it is in front. desktop_agent.window_action minimise uses the same
  verified code.
Nothing else (voice, listening, finance, notes, WhatsApp, UI) was touched.
