"""FRIDAY 6.0 OS conveniences and perception wrappers: clipboard assistance (authorised), notifications, screen/vision helpers built on the
existing OpenCV engine (image comparison, visual change detection, visual debugging of error dialogs, video summary), and a recovery
wrapper that retries safe operations.  Camera and screen use is always explicit and shows an indicator through friday_security6.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
import time
from typing import Callable, Dict, Optional

import friday_common6 as C
import friday_security6 as SEC

_last_clip = {"text": ""}


# ------------------------------------------------------------------ clipboard (only when authorised)
def clipboard_get() -> Optional[str]:
    try:
        import pyperclip
        return pyperclip.paste()
    except Exception:
        pass
    try:
        if sys.platform.startswith("win"):
            return subprocess.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard -Raw"], capture_output=True, text=True, timeout=5).stdout
    except Exception:
        pass
    return None


def clipboard_set(text: str) -> bool:
    try:
        import pyperclip
        pyperclip.copy(text)
        return True
    except Exception:
        return False


def transform_text(text: str, how: str) -> str:
    how = how.lower()
    if "upper" in how:
        return text.upper()
    if "lower" in how:
        return text.lower()
    if "title" in how:
        return text.title()
    if "trim" in how or "clean" in how or "whitespace" in how:
        return re.sub(r"[ \t]+", " ", re.sub(r"\n{3,}", "\n\n", text)).strip()
    if "sort" in how:
        return "\n".join(sorted(text.splitlines()))
    if "unique" in how or "dedup" in how:
        seen, out = set(), []
        for l in text.splitlines():
            if l not in seen:
                seen.add(l); out.append(l)
        return "\n".join(out)
    if "json" in how:
        import json
        return json.dumps(json.loads(text), indent=2, ensure_ascii=False)
    if "bullet" in how:
        return "\n".join("• " + l for l in text.splitlines() if l.strip())
    if "count" in how:
        return f"{len(text.split())} words, {len(text)} characters, {len(text.splitlines())} lines"
    return C.llm(f"Transform this text: {how}.\n\n{text}") or text


# ------------------------------------------------------------------ notifications
def notify(title: str, message: str) -> bool:
    try:
        if sys.platform.startswith("win"):
            ps = ("[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;"
                  "$t=[Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02);"
                  f"$t.GetElementsByTagName('text').Item(0).AppendChild($t.CreateTextNode('{title.replace(chr(39), '')}'))>$null;"
                  f"$t.GetElementsByTagName('text').Item(1).AppendChild($t.CreateTextNode('{message.replace(chr(39), '')[:200]}'))>$null;"
                  "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('FRIDAY').Show([Windows.UI.Notifications.ToastNotification]::new($t))")
            subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", ps], creationflags=0x08000000)
            return True
        if sys.platform == "darwin":
            subprocess.Popen(["osascript", "-e", f'display notification "{message[:200]}" with title "{title}"'])
            return True
        subprocess.Popen(["notify-send", title, message[:200]])
        return True
    except Exception:
        return False


# ------------------------------------------------------------------ recovery
def with_recovery(fn: Callable, *args, retries: int = 2, safe: bool = True, component: str = "op", **kw) -> Dict:
    """Detect a failed action, capture useful error details and retry only safe (idempotent) operations."""
    last = ""
    for i in range(retries + 1):
        try:
            return {"ok": True, "result": fn(*args, **kw), "attempts": i + 1}
        except Exception as exc:
            last = f"{type(exc).__name__}: {str(exc)[:200]}"
            SEC.audit("friday", "action-failed", f"{component}: {last}", "error")
            if not safe or SEC.note_failure(component):
                break
            time.sleep(0.4 * (i + 1))
    return {"ok": False, "error": last, "attempts": i + 1}


# ------------------------------------------------------------------ vision helpers (thin wrappers over the OpenCV engine)
def _engine():
    import friday_vision_engine as ve
    return ve


def compare_images(a: str, b: str) -> Dict:
    ve = _engine()
    fa, fb_ = ve.read_image(a), ve.read_image(b)
    if fa is None or fb_ is None:
        return {"ok": False, "error": "I couldn't open one of the images"}
    r = ve.compare_frames(fa, fb_)
    return {"ok": True, **{k: v for k, v in r.items() if k in ("changed", "change_ratio", "regions", "score", "summary", "similarity", "changed_regions")}, "raw_keys": sorted(r)[:8]}


def screen_text() -> Dict:
    SEC.sensor_set("screen", True)
    try:
        ve = _engine()
        r = ve.see_screen(ask_gemini=False, do_ocr=True)
        return {"ok": True, "text": str(((r or {}).get("text") or {}).get("text", "") if isinstance((r or {}).get("text"), dict) else (r or {}).get("text", ""))[:1500], "state": r}
    except Exception as exc:
        return {"ok": False, "error": str(exc)[:160]}
    finally:
        SEC.sensor_set("screen", False)


def debug_visual_error() -> str:
    """Look at the screen, read any error text and say what it probably means (visual debugging)."""
    r = screen_text()
    if not r["ok"]:
        return "I couldn't read the screen: " + r["error"]
    text = r["text"]
    if not text.strip():
        return "I can't see any readable text on the screen."
    try:
        ve = _engine()
        found = ve.detect_errors(text)
    except Exception:
        found = {}
    import friday_engineer6 as E
    hint = E.diagnose_install(text)
    return "I can see an error on screen. " + hint if re.search(r"error|exception|failed|traceback|not found|denied", text, re.I) else "I read the screen and I don't see an error message."


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    m = re.match(r"^(?:read|what(?:'s| is) on|show) (?:my |the )?clipboard$|^what did i (?:just )?copy$", low)
    if m:
        blocked = SEC.require("clipboard_read", "read the clipboard")
        if blocked:
            return blocked
        txt = clipboard_get()
        SEC.audit("friday", "clipboard-read", f"{len(txt or '')} chars")
        return "The clipboard is empty." if not txt else "On your clipboard: " + C.clip(txt, 300)
    m = re.match(r"^(?:clean up|transform|convert|fix|format|summari[sz]e|translate)(?: the| my)? clipboard(?: (?:to|into|as|text|content))?\s*(.*)$", low)
    if m:
        blocked = SEC.require("clipboard_read", "transform the clipboard") or SEC.require("clipboard_write", "write the clipboard")
        if blocked:
            return blocked
        txt = clipboard_get() or ""
        if not txt.strip():
            return "The clipboard is empty."
        how = (m.group(0).split("clipboard", 1)[0] + " " + m.group(1)).strip()
        try:
            out = transform_text(txt, how)
        except Exception as exc:
            return f"I couldn't transform it: {exc}"
        clipboard_set(out)
        SEC.audit("friday", "clipboard-write", how)
        return "Done. The result is on your clipboard: " + C.clip(out, 160)
    m = re.match(r"^(?:notify|send (?:me )?a notification)(?: me)?(?: that| saying| about)?[: ]+(.+)$", t, re.I)
    if m:
        return "Notification sent." if notify("FRIDAY", m.group(1)) else "I couldn't show a notification on this system."
    m = re.match(r"^compare (?:the )?images? (.+?) (?:and|with|to) (.+)$", t, re.I)
    if m:
        r = compare_images(m.group(1).strip('" '), m.group(2).strip('" '))
        if not r["ok"]:
            return r["error"] + "."
        return f"Compared. Changed: {r.get('changed')}, difference {r.get('change_ratio', r.get('score', 'n/a'))}."
    if re.match(r"^(?:debug|read) (?:the |this )?(?:error|error message|error dialog) (?:on|from) (?:my |the )?screen$|^what(?:'s| is) (?:this|that) error on (?:my )?screen$", low):
        blocked = SEC.require("screen_capture", "read the screen")
        return blocked or debug_visual_error()
    return None
