"""FRIDAY feature-hardening layer.

This module strengthens non-voice features without changing the existing
microphone listing/capture/recognition mechanism.

Goals:
- deterministic intent confidence
- hybrid memory relevance (semantic + lexical + recency)
- bounded action retries with post-condition verification
- task checkpoints for resumable agent work
- source/file quality helpers
- human-response cleanup helpers

No external dependency is required.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import tempfile
import time
from pathlib import Path
from typing import Any, Callable, Optional

_STATE = Path(__file__).with_name("friday_hardening_state.json")


def _atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip()).lower()


def lexical_overlap(a: str, b: str) -> float:
    wa = set(re.findall(r"[a-z0-9]{2,}", normalize(a)))
    wb = set(re.findall(r"[a-z0-9]{2,}", normalize(b)))
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / max(1, len(wa | wb))


def recency_score(ts: float, half_life_days: float = 30.0) -> float:
    age_days = max(0.0, (time.time() - float(ts or 0)) / 86400.0)
    return math.exp(-math.log(2) * age_days / half_life_days)


def hybrid_memory_score(query: str, text: str, vector_score: float, ts: float) -> float:
    # Semantic similarity remains dominant; lexical matching prevents vague
    # hashed-vector collisions from outranking exact topic matches.
    semantic = max(-1.0, min(1.0, float(vector_score)))
    semantic = (semantic + 1.0) / 2.0
    lexical = lexical_overlap(query, text)
    recent = recency_score(ts)
    return 0.62 * semantic + 0.28 * lexical + 0.10 * recent


def intent_confidence(features: dict[str, Any], command: str) -> float:
    flags = [
        features.get("is_research"), features.get("is_youtube"),
        features.get("is_vision"), features.get("is_open"),
        features.get("is_message"), features.get("is_study"),
        features.get("is_document"),
    ]
    hits = sum(bool(x) for x in flags)
    words = len(normalize(command).split())
    base = 0.72 if hits else 0.58
    if hits > 1:
        base += 0.08
    if words >= 5:
        base += 0.05
    if words >= 12:
        base += 0.04
    return round(min(0.97, base), 3)


def run_verified(name: str, fn: Callable[[], Any], *, attempts: int = 2,
                 verify: Optional[Callable[[Any], bool]] = None) -> Any:
    attempts = max(1, min(3, int(attempts)))
    last: Optional[Exception] = None
    for _ in range(attempts):
        try:
            result = fn()
            if verify is None or verify(result):
                return result
            raise RuntimeError(f"{name}: post-condition verification failed")
        except Exception as exc:
            last = exc
    raise last or RuntimeError(f"{name}: failed")


def validate_file(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    result = {"path": str(p), "exists": False, "readable": False, "size": 0}
    try:
        result["exists"] = p.exists() and p.is_file()
        if result["exists"]:
            result["size"] = p.stat().st_size
            with p.open("rb") as fh:
                fh.read(64)
            result["readable"] = True
    except Exception as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result


def checkpoint(task_id: str, state: dict[str, Any]) -> None:
    try:
        current = json.loads(_STATE.read_text(encoding="utf-8")) if _STATE.exists() else {}
    except Exception:
        current = {}
    current[str(task_id)] = {"updated_at": time.time(), "state": state}
    # Keep the state bounded.
    items = sorted(current.items(), key=lambda kv: kv[1].get("updated_at", 0), reverse=True)[:50]
    _atomic_json(_STATE, dict(items))


def load_checkpoint(task_id: str) -> Optional[dict[str, Any]]:
    try:
        data = json.loads(_STATE.read_text(encoding="utf-8")) if _STATE.exists() else {}
        entry = data.get(str(task_id))
        return entry.get("state") if isinstance(entry, dict) else None
    except Exception:
        return None


def humanize_response(text: str) -> str:
    """Remove common robotic filler without changing factual content."""
    text = re.sub(r"^(Sure[,!]?|Certainly[,!]?|Of course[,!]?)[ ]+", "", text or "", flags=re.I)
    text = re.sub(r"\bI am unable to\b", "I can't", text, flags=re.I)
    text = re.sub(r"\bI cannot\b", "I can't", text, flags=re.I)
    text = re.sub(r"[ \t]+", " ", text).strip()
    return text


def quality_self_test() -> dict[str, Any]:
    checks = {}
    checks["normalization"] = normalize("  FRIDAY   test ") == "friday test"
    checks["lexical_match"] = lexical_overlap("open google cats", "google cats search") > 0.15
    checks["recency"] = 0.0 < recency_score(time.time()) <= 1.0
    checks["hybrid_score"] = hybrid_memory_score("google", "google search", 0.8, time.time()) > 0.5
    checks["file_validator"] = validate_file(Path(__file__)).get("readable") is True
    checks["intent_confidence"] = intent_confidence({"is_research": True}, "research this topic") >= 0.7
    return {"overall": all(checks.values()), "checks": checks}

# --- v2026 orchestration hardening -------------------------------------------------
# These helpers are intentionally dependency-free and operate only after speech
# recognition. They reduce duplicate work, malformed plans and retry storms.

class CircuitBreaker:
    def __init__(self, threshold: int = 3, cooldown: float = 20.0):
        self.threshold = max(1, int(threshold))
        self.cooldown = max(1.0, float(cooldown))
        self.failures: dict[str, tuple[int, float]] = {}

    def allow(self, name: str) -> bool:
        count, last = self.failures.get(name, (0, 0.0))
        if count < self.threshold:
            return True
        if time.time() - last >= self.cooldown:
            self.failures.pop(name, None)
            return True
        return False

    def success(self, name: str) -> None:
        self.failures.pop(name, None)

    def failure(self, name: str) -> None:
        count, _ = self.failures.get(name, (0, 0.0))
        self.failures[name] = (count + 1, time.time())


_BREAKER = CircuitBreaker()
_DEDUP: dict[str, float] = {}


def request_fingerprint(command: str) -> str:
    return hashlib.sha256(normalize(command).encode("utf-8")).hexdigest()[:24]


def recently_started(command: str, ttl: float = 8.0) -> bool:
    """Return True only for an identical request already started very recently."""
    now = time.time()
    key = request_fingerprint(command)
    # prune stale entries while keeping the map tiny
    for k, t in list(_DEDUP.items()):
        if now - t > max(30.0, ttl * 4):
            _DEDUP.pop(k, None)
    if now - _DEDUP.get(key, 0.0) < ttl:
        return True
    _DEDUP[key] = now
    return False


def validate_plan(steps: list[Any]) -> tuple[bool, str]:
    names = {getattr(s, "name", "") for s in steps}
    if len(names) != len(steps) or not names:
        return False, "plan contains duplicate or empty step names"
    graph = {getattr(s, "name", ""): list(getattr(s, "dependencies", []) or []) for s in steps}
    for name, deps in graph.items():
        if any(dep not in names for dep in deps):
            return False, f"step {name!r} references an unknown dependency"
    visiting: set[str] = set()
    visited: set[str] = set()
    def dfs(node: str) -> bool:
        if node in visiting:
            return False
        if node in visited:
            return True
        visiting.add(node)
        if any(not dfs(dep) for dep in graph[node]):
            return False
        visiting.remove(node)
        visited.add(node)
        return True
    if not all(dfs(n) for n in graph):
        return False, "plan contains a dependency cycle"
    return True, "ok"


def source_quality(url: str, title: str = "", snippet: str = "") -> float:
    """Conservative source-quality heuristic for ranking, never a factual claim."""
    u = normalize(url)
    score = 0.45
    trusted = (".gov", ".edu", "who.int", "nature.com", "nih.gov", "reuters.com",
               "apnews.com", "bbc.com", "nasa.gov")
    if any(x in u for x in trusted):
        score += 0.30
    if u.startswith("https://"):
        score += 0.05
    if len(normalize(title)) >= 12:
        score += 0.05
    if len(normalize(snippet)) >= 80:
        score += 0.05
    if any(x in u for x in ("pinterest.", "facebook.", "tiktok.", "x.com")):
        score -= 0.15
    return round(max(0.0, min(1.0, score)), 3)

# --- v2026 orchestration hardening -------------------------------------------------
class CircuitBreaker:
    def __init__(self, threshold: int = 3, cooldown: float = 20.0):
        self.threshold = max(1, int(threshold)); self.cooldown = max(1.0, float(cooldown)); self.failures = {}
    def allow(self, name: str) -> bool:
        count, last = self.failures.get(name, (0, 0.0))
        if count < self.threshold: return True
        if time.time() - last >= self.cooldown: self.failures.pop(name, None); return True
        return False
    def success(self, name: str): self.failures.pop(name, None)
    def failure(self, name: str): self.failures[name] = (self.failures.get(name, (0, 0.0))[0] + 1, time.time())

_BREAKER = CircuitBreaker()
_DEDUP: dict[str, float] = {}

def request_fingerprint(command: str) -> str:
    return hashlib.sha256(normalize(command).encode("utf-8")).hexdigest()[:24]

def recently_started(command: str, ttl: float = 8.0) -> bool:
    now = time.time(); key = request_fingerprint(command)
    for k, t in list(_DEDUP.items()):
        if now - t > max(30.0, ttl * 4): _DEDUP.pop(k, None)
    if now - _DEDUP.get(key, 0.0) < ttl: return True
    _DEDUP[key] = now; return False

def validate_plan(steps: list[Any]) -> tuple[bool, str]:
    names = {getattr(s, "name", "") for s in steps}
    if len(names) != len(steps) or not names: return False, "plan contains duplicate or empty step names"
    graph = {getattr(s, "name", ""): list(getattr(s, "dependencies", []) or []) for s in steps}
    for name, deps in graph.items():
        if any(dep not in names for dep in deps): return False, f"step {name!r} references an unknown dependency"
    visiting, visited = set(), set()
    def dfs(node):
        if node in visiting: return False
        if node in visited: return True
        visiting.add(node)
        if any(not dfs(dep) for dep in graph[node]): return False
        visiting.remove(node); visited.add(node); return True
    return (True, "ok") if all(dfs(n) for n in graph) else (False, "plan contains a dependency cycle")

def source_quality(url: str, title: str = "", snippet: str = "") -> float:
    u = normalize(url); score = 0.45
    trusted = (".gov", ".edu", "who.int", "nature.com", "nih.gov", "reuters.com", "apnews.com", "bbc.com", "nasa.gov")
    if any(x in u for x in trusted): score += 0.30
    if u.startswith("https://"): score += 0.05
    if len(normalize(title)) >= 12: score += 0.05
    if len(normalize(snippet)) >= 80: score += 0.05
    if any(x in u for x in ("pinterest.", "facebook.", "tiktok.", "x.com")): score -= 0.15
    return round(max(0.0, min(1.0, score)), 3)
