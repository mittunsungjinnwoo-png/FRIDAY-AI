"""
FRIDAY LAYERED MEMORY
---------------------
Implements the research doc's "3. Memory should have layers" and
"Memory - 9.5+" sections:

    Working memory -> Conversation memory -> Episodic memory ->
    Semantic memory -> User preference/model

Every stored item carries exactly the metadata schema from the doc:

    {
        "content": "...",
        "importance": 0.8,
        "confidence": 0.95,
        "created": "...",
        "last_used": "...",
        "source": "...",
        "expires": None,
    }

and a `should_remember()` heuristic decides whether something is
"actually worth remembering" instead of blindly saving everything,
exactly as the doc asks.

This module writes ONLY to its own new file, friday_memory_layers_state.json.
It does not modify memory.json, friday_semantic_memory.json,
conversation_context.json, or study_memory.json -- your existing memory
system keeps working exactly as it does today. `import_existing_snapshot()`
is an optional, read-only helper that peeks at those files (if present)
purely so new code can see a merged picture; it never writes back to them.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Optional

STATE_FILE = Path(os.environ.get("FRIDAY_DATA") or (Path(__file__).parent / "friday_data")) / "friday_memory_layers_state.json"
BASE_DIR = Path(__file__).parent

LAYERS = ("working", "conversation", "episodic", "semantic", "user_model")

# Soft cap per layer so this can never grow without bound.
_LAYER_CAPS = {
    "working": 40,
    "conversation": 300,
    "episodic": 1000,
    "semantic": 2000,
    "user_model": 500,
}

_lock = threading.RLock()
_store: dict[str, list[dict[str, Any]]] = {layer: [] for layer in LAYERS}

_IMPORTANCE_HINTS = (
    (r"\b(always|never|prefer|favou?rite|hate|love|allerg|remember that i)\b", 0.25),
    (r"\b(deadline|due|appointment|meeting|birthday|anniversary)\b", 0.2),
    (r"\b(password|api key|secret|token)\b", -1.0),  # never boost, handled specially below
    (r"\b(decided|decision|plan to|going to|will)\b", 0.15),
    (r"\b(my name is|call me|i am|i work at|i live in)\b", 0.2),
)

_SENSITIVE_PATTERN = re.compile(r"\b(password|api key|secret key|ssn|social security|credit card)\b", re.I)


def _load() -> None:
    global _store
    try:
        if STATE_FILE.exists():
            raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                for layer in LAYERS:
                    items = raw.get(layer)
                    if isinstance(items, list):
                        _store[layer] = items
    except Exception:
        pass


def _save() -> None:
    try:
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_store, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        os.replace(tmp, STATE_FILE)
    except Exception:
        pass


_load()


def score_importance(content: str, hint: Optional[float] = None) -> float:
    """0..1 heuristic importance score used when the caller doesn't supply one."""
    if hint is not None:
        return max(0.0, min(1.0, hint))
    text = (content or "").lower()
    if _SENSITIVE_PATTERN.search(text):
        return 0.0  # never elevate secrets; caller should not store these at all
    score = 0.35  # baseline
    for pattern, weight in _IMPORTANCE_HINTS:
        if weight > 0 and re.search(pattern, text):
            score += weight
    return max(0.0, min(1.0, score))


def should_remember(content: str, importance: Optional[float] = None, min_importance: float = 0.3) -> tuple[bool, float]:
    """Decide whether `content` clears the bar for being worth remembering.

    Returns (decision, score). Sensitive-looking content (passwords, API
    keys, SSNs, card numbers) is always rejected regardless of score, in
    line with "don't blindly save everything".
    """
    if _SENSITIVE_PATTERN.search((content or "").lower()):
        return False, 0.0
    score = score_importance(content, importance)
    return score >= min_importance, score


def record(
    layer: str,
    content: str,
    *,
    importance: Optional[float] = None,
    confidence: float = 0.8,
    source: str = "conversation",
    expires: Optional[float] = None,
    force: bool = False,
) -> Optional[dict[str, Any]]:
    """Store `content` in the given layer if (and only if) it's worth
    remembering, unless force=True. Returns the stored record, or None if
    it was rejected (not important enough, or looked sensitive)."""
    if layer not in LAYERS:
        return None
    ok, score = should_remember(content, importance)
    if not ok and not force:
        return None
    now = time.time()
    record_ = {
        "id": uuid.uuid4().hex[:12],
        "content": str(content)[:4000],
        "importance": round(score if importance is None else max(0.0, min(1.0, importance)), 3),
        "confidence": round(max(0.0, min(1.0, confidence)), 3),
        "created": now,
        "last_used": now,
        "source": source,
        "expires": expires,
    }
    with _lock:
        items = _store.setdefault(layer, [])
        items.append(record_)
        cap = _LAYER_CAPS.get(layer, 500)
        if len(items) > cap:
            # Drop the least important, oldest-used items first.
            items.sort(key=lambda r: (r.get("importance", 0), r.get("last_used", 0)))
            del items[: len(items) - cap]
        _store[layer] = items
        _save()
    return record_


def recall(layer: str, query: Optional[str] = None, top_k: int = 5, min_importance: float = 0.0) -> list[dict[str, Any]]:
    """Keyword-overlap recall (no embedding dependency, matches the rest of
    this codebase's zero-extra-dependency style for anything that must run
    even when optional ML packages aren't installed)."""
    if layer not in LAYERS:
        return []
    with _lock:
        items = [r for r in _store.get(layer, []) if r.get("importance", 0) >= min_importance and not _is_expired(r)]

    if not query:
        items.sort(key=lambda r: (r.get("importance", 0), r.get("last_used", 0)), reverse=True)
        chosen = items[:top_k]
    else:
        q_tokens = set(re.findall(r"[a-z0-9]{2,}", query.lower()))

        def _score(r: dict[str, Any]) -> float:
            c_tokens = set(re.findall(r"[a-z0-9]{2,}", r.get("content", "").lower()))
            overlap = len(q_tokens & c_tokens) / max(1, len(q_tokens))
            return overlap * 0.7 + r.get("importance", 0) * 0.3

        items.sort(key=_score, reverse=True)
        chosen = [r for r in items[: top_k * 3] if _score(r) > 0][:top_k]

    now = time.time()
    with _lock:
        for r in chosen:
            for stored in _store.get(layer, []):
                if stored.get("id") == r.get("id"):
                    stored["last_used"] = now
        _save()
    return chosen


def _is_expired(record_: dict[str, Any]) -> bool:
    expires = record_.get("expires")
    return bool(expires) and time.time() > float(expires)


def prune_expired() -> int:
    removed = 0
    with _lock:
        for layer in LAYERS:
            items = _store.get(layer, [])
            kept = [r for r in items if not _is_expired(r)]
            removed += len(items) - len(kept)
            _store[layer] = kept
        if removed:
            _save()
    return removed


def promote(record_id: str, from_layer: str, to_layer: str) -> Optional[dict[str, Any]]:
    """Move something from e.g. 'working' up to 'episodic' or 'semantic' once
    it has proven durable/important -- the doc's memory layers are meant to
    be a pipeline, not five disconnected buckets."""
    if from_layer not in LAYERS or to_layer not in LAYERS:
        return None
    with _lock:
        items = _store.get(from_layer, [])
        found = None
        for r in items:
            if r.get("id") == record_id:
                found = r
                break
        if not found:
            return None
        items.remove(found)
        _store[from_layer] = items
        _store.setdefault(to_layer, []).append(found)
        _save()
        return dict(found)


def layer_stats() -> dict[str, int]:
    with _lock:
        return {layer: len(_store.get(layer, [])) for layer in LAYERS}


# ---------------------------------------------------------------------------
# Read-only bridge to the existing (unmodified) memory files, so new code can
# see a fuller picture without this module ever writing back to them.
# ---------------------------------------------------------------------------

_EXISTING_MEMORY_FILES = (
    "memory.json",
    "friday_semantic_memory.json",
    "conversation_context.json",
    "study_memory.json",
)


def import_existing_snapshot() -> dict[str, Any]:
    """Best-effort, read-only peek at your existing memory files. Returns a
    dict keyed by filename -> parsed JSON (or {"error": ...} if unreadable).
    Never raises, never writes anything back."""
    out: dict[str, Any] = {}
    for name in _EXISTING_MEMORY_FILES:
        path = BASE_DIR / name
        try:
            if path.exists():
                out[name] = json.loads(path.read_text(encoding="utf-8"))
            else:
                out[name] = None
        except Exception as exc:
            out[name] = {"error": str(exc)}
    return out
