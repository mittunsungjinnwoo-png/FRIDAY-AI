"""FRIDAY Adaptive Learning & Pattern Recognition Engine v4041.

Lightweight, local-first machine learning for recurring workflow prediction.
Uses online multinomial Naive-Bayes-style token statistics plus sequence
transition learning. No cloud training and no new mandatory dependency.

The learner predicts *candidate next tasks*, but the existing supervisor is
still authoritative: only high-confidence, low-impact preparatory actions can
run automatically. Consequential actions remain confirmation-gated.
"""
from __future__ import annotations
import json, math, re, threading, time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / "friday_learning_state.json"
VERSION = "4041-learning-1"
_LOCK = threading.RLock()
_MAX_EVENTS = 1200
_MAX_CLASSES = 80

_STATE: dict[str, Any] = {
    "events": [],
    "class_counts": Counter(),
    "token_counts": defaultdict(Counter),
    "token_totals": Counter(),
    "transitions": defaultdict(Counter),
    "last_label": None,
    "metrics": {"learned": 0, "predictions": 0, "auto_actions": 0},
}

def _load() -> None:
    try:
        if not STATE_FILE.exists(): return
        raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        _STATE["events"] = raw.get("events", [])[-_MAX_EVENTS:]
        _STATE["class_counts"] = Counter(raw.get("class_counts", {}))
        _STATE["token_counts"] = defaultdict(Counter, {k: Counter(v) for k,v in raw.get("token_counts", {}).items()})
        _STATE["token_totals"] = Counter(raw.get("token_totals", {}))
        _STATE["transitions"] = defaultdict(Counter, {k: Counter(v) for k,v in raw.get("transitions", {}).items()})
        _STATE["last_label"] = raw.get("last_label")
        _STATE["metrics"].update(raw.get("metrics", {}))
    except Exception:
        pass

_load()

def _save() -> None:
    try:
        raw = {
            "events": _STATE["events"][-_MAX_EVENTS:],
            "class_counts": dict(_STATE["class_counts"]),
            "token_counts": {k: dict(v) for k,v in _STATE["token_counts"].items()},
            "token_totals": dict(_STATE["token_totals"]),
            "transitions": {k: dict(v) for k,v in _STATE["transitions"].items()},
            "last_label": _STATE["last_label"], "metrics": dict(_STATE["metrics"]),
        }
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(raw, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        tmp.replace(STATE_FILE)
    except Exception:
        pass

def _tokens(text: str) -> list[str]:
    return [x for x in re.findall(r"[a-z0-9]{2,}", (text or "").lower()) if x not in {
        "the","and","for","with","from","this","that","please","jarvis","sir","can","you","could","would","make","do"
    }]

def _features(text: str) -> set[str]:
    toks = _tokens(text)
    feats = set(toks)
    feats.update(f"ng:{a}_{b}" for a,b in zip(toks, toks[1:]))
    return feats

def _label(text: str) -> str:
    s = (text or "").lower()
    # Action verbs outrank generic topic nouns so workflows remain distinct.
    if re.search(r"\b(research|latest|look up|search|sources?|investigate|verify|youtube)\b", s): return "research"
    if re.search(r"\b(create|generate|write|draft|document|docx|pdf|report|word)\b", s): return "document"
    if re.search(r"\b(excel|xlsx|spreadsheet)\b", s): return "spreadsheet"
    if re.search(r"\b(powerpoint|pptx|slides|presentation)\b", s): return "presentation"
    if re.search(r"\b(whatsapp|message|contact|call|send|email)\b", s): return "communication"
    if re.search(r"\b(open|launch|start)\b", s): return "open_app"
    if re.search(r"\b(browser|chrome|edge|website|url)\b", s): return "browser"
    if re.search(r"\b(syllabus|checklist|exam|study|revision|notes|quiz|practice|learn)\b", s): return "study"
    return "general"

def learn(command: str, outcome: str = "completed", label: str | None = None) -> None:
    """Online learning step. Tiny, local and CPU-cheap."""
    text = str(command or "").strip()
    if len(text) < 3:
        return
    cls = label or _label(text)
    feats = _features(text)
    with _LOCK:
        _STATE["class_counts"][cls] += 1
        for f in feats:
            _STATE["token_counts"][cls][f] += 1
            _STATE["token_totals"][cls] += 1
        prev = _STATE.get("last_label")
        if prev and prev != cls:
            _STATE["transitions"][prev][cls] += 1
        _STATE["last_label"] = cls
        _STATE["events"].append({"ts": time.time(), "label": cls, "outcome": str(outcome)[:80], "tokens": list(feats)[:80]})
        _STATE["events"] = _STATE["events"][-_MAX_EVENTS:]
        _STATE["metrics"]["learned"] += 1
        _save()

def _nb_score(feats: set[str], cls: str) -> float:
    classes = _STATE["class_counts"]
    total = sum(classes.values()) or 1
    prior = math.log((classes.get(cls,0) + 1) / (total + len(classes) + 1))
    vocab = max(1, len({f for c in _STATE["token_counts"].values() for f in c}))
    denom = _STATE["token_totals"].get(cls,0) + vocab
    score = prior
    for f in feats:
        score += math.log((_STATE["token_counts"][cls].get(f,0) + 1) / denom)
    return score

def predict(command: str, *, min_confidence: float = 0.86) -> dict[str, Any] | None:
    """Predict the next workflow family and return confidence + reason."""
    feats = _features(command)
    if not feats or sum(_STATE["class_counts"].values()) < 6: return None
    with _LOCK:
        classes = list(_STATE["class_counts"])
        scores = sorted(((c, _nb_score(feats,c)) for c in classes), key=lambda x:x[1], reverse=True)
        best, second = scores[0], scores[1] if len(scores)>1 else (None, -999)
        # softmax confidence plus transition evidence
        mx = best[1]; ex = [math.exp(max(-30,min(30,s-mx))) for _,s in scores[:8]]
        conf = ex[0] / (sum(ex) or 1)
        prev = _label(command)
        trans = _STATE["transitions"].get(prev, Counter())
        if trans:
            t_total = sum(trans.values())
            t_best = trans.most_common(1)[0]
            if t_best[0] == best[0]: conf = min(0.995, conf + 0.12 * t_best[1]/t_total)
        _STATE["metrics"]["predictions"] += 1
        if conf < min_confidence: return None
        return {"family": best[0], "confidence": round(conf,3), "alternative": second[0] if second else None,
                "learned_examples": int(_STATE["class_counts"][best[0]]), "reason": "online pattern model"}

def predict_next_after(command: str, *, min_confidence: float = 0.90) -> dict[str, Any] | None:
    """Infer a useful next step from the learned transition graph."""
    current = _label(command)
    with _LOCK:
        c = _STATE["transitions"].get(current, Counter())
        if not c: return None
        nxt, count = c.most_common(1)[0]; total = sum(c.values())
        conf = count / max(1,total)
        if count < 3 or conf < min_confidence: return None
        return {"family": nxt, "confidence": round(conf,3), "observations": count, "reason": "learned recurring workflow transition"}

def health() -> dict[str, Any]:
    with _LOCK:
        return {"version": VERSION, "examples": sum(_STATE["class_counts"].values()),
                "classes": dict(_STATE["class_counts"]), "metrics": dict(_STATE["metrics"])}
