from pathlib import Path
import ast
ROOT=Path(__file__).parent
b=(ROOT/"friday_backend.py").read_text(encoding="utf8")
i=(ROOT/"index.html").read_text(encoding="utf8")
ast.parse(b)
for x in ["FRIDAY_FIXED_VOICE_RATE = 173","def _analyze_user_audio","def _fuse_human_interaction","def study_pseudocode_generate","def study_pseudocode_explain","pseudocode::","pseudocode_explain::","STUDY_PSEUDOCODE::","STUDY_PSEUDOCODE_EXPLANATION::"]: assert x in b,x
for x in ['id="page-pseudocode"','data-page="pseudocode"','renderPseudocode','study-pseudocode-explanation']: assert x in i,x
print("PASS: v2026 Human Interaction + Pseudocode static checks")
