"""FRIDAY V87 non-destructive smoke tests.
These tests exercise the additive agent layer without launching the microphone,
Electron UI, WhatsApp, or external services.
"""
from pathlib import Path
import importlib.util
import sys
import types
import tempfile

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("friday_advanced_agent_test", ROOT / "friday_advanced_agent.py")
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
spec.loader.exec_module(mod)

fake = types.SimpleNamespace(
    study_state={"active": False, "topic": None},
    get_active_window_title=lambda: "SmokeTestWindow",
    friday_web_research=types.SimpleNamespace(gather_sources=lambda *a, **k: [{"title": "source"}]),
    friday_youtube_research=types.SimpleNamespace(gather_youtube_sources=lambda *a, **k: [{"title": "video"}]),
    handle_study_command=lambda c: True,
    handle_command=lambda c: True,
    speak=lambda *a, **k: None,
    emit_progress=lambda *a, **k: None,
    log_event=lambda *a, **k: None,
)
mod._backend = lambda: fake

# Planning + dependency graph
task = mod.plan_request_v87(
    "research orbital hybridisation and find YouTube videos and create a PDF"
)
assert [s.tool for s in task.steps] == [
    "web_research", "youtube_research", "document_creation"
]
assert len(task.steps[2].dependencies) == 2

# Permission boundaries
assert mod.permission_required("open calculator")[0] == 1
assert mod.permission_required("create a PDF")[0] == 2
assert mod.permission_required("send a WhatsApp message")[0] == 3
assert mod.permission_required("delete a file")[0] == 4

# Verification of a real file
with tempfile.TemporaryDirectory() as td:
    p = Path(td) / "test.txt"
    p.write_text("friday smoke test", encoding="utf-8")
    v = mod.verify_path(p, "friday smoke test")
    assert v["exists"] and v["size"] > 0 and v["readable"] and v["valid"]

# Plugin registration
assert mod.register_tool("smoke_test", lambda command: True, permission=0)
assert any(x["name"] == "smoke_test" for x in mod.list_tools())
assert mod.unregister_tool("smoke_test")

# Semantic memory remains local/offline by default
mod.remember_semantic("orbital hybridisation chemistry", {"test": True})
assert mod.retrieve_semantic("chemistry hybridisation", 1)

print("FRIDAY V87 smoke tests: PASS")
