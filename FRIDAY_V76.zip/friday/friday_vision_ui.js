/* FRIDAY Vision UI  (V2.3.0)
   - window.FridayVision        : request/response + event bridge to the Python vision hub
   - window.visionV(e)          : the "Vision" page (Live / Agent / Evaluation)
   - window.FridayVisionSettings: the Settings > Vision tab (every option + the cloud access-token field)
   - floating confirmation card : Approve / Deny for yellow and red agent actions (works on every page)
   - header indicators          : camera-on and agent-activity pills
   Pure addition: it reads the globals that index.html already defines (B, $, esc, ic, view, toast, V) and changes nothing else. */
(function () {
  'use strict';
  const B = window.fridayBridge || null;
  const E = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const dec = b => { try { return decodeURIComponent(escape(atob(b))); } catch (e) { return atob(b); } };
  const pct = v => (v == null ? '–' : Math.round(v * 100) + '%');

  /* ------------------------------------------------------------ bridge */
  const pending = {};
  let reqN = 0;
  const VS = { status: null, state: null, session: { running: false }, agent: { plan: [], steps: [], result: null, running: false, note: '' },
    bench: { running: false, step: '', fraction: 0, result: null }, ag: { phases: [], finding: null, result: null, running: false, snap: null, watch: false, bench: null }, metrics: null, frame: null, motion: null, notices: [], confirms: [], tab: 'Live', change: null, report: null,
    progress: null, audit: [] };
  const listeners = [];

  function call(op, payload, timeoutMs) {
    return new Promise(resolve => {
      if (!B || !B.visionSend) { resolve({ ok: false, error: 'Vision is available in the FRIDAY desktop app.' }); return; }
      const req = 'r' + (++reqN) + '_' + Date.now();
      const t = setTimeout(() => { delete pending[req]; resolve({ ok: false, error: 'No answer from FRIDAY\u2019s engine (is it still starting?).' }); }, timeoutMs || 180000);
      pending[req] = d => { clearTimeout(t); resolve(d); };
      B.visionSend(Object.assign({ op, req }, payload || {}));
    });
  }

  function onMsg(m) {
    const k = m.kind, d = m.data;
    if (k === 'reply') { const f = pending[m.req]; if (f) { delete pending[m.req]; f(d); } return; }
    if (k === 'state') { VS.state = d; }
    else if (k === 'snapshot') { VS.state = d; VS.snapImg = d && d.image ? d.image : null; VS.snapTs = Date.now(); }
    else if (k === 'frame') { VS.frame = d; VS.frameAt = Date.now(); liveFrame(); return; }
    else if (k === 'session') { VS.session = d || { running: false }; if (!VS.session.running) { VS.frame = null; } else { VS.snapImg = null; } indicators(); }
    else if (k === 'motion') { VS.motion = d; }
    else if (k === 'change') { VS.change = d; }
    else if (k === 'progress') { VS.progress = d; }
    else if (k === 'notice') { VS.notices.unshift({ t: Date.now(), text: d.text, kind: d.kind }); VS.notices.length = Math.min(VS.notices.length, 6); if (typeof toast === 'function') toast(d.text); }
    else if (k === 'agent') { agentEvent(d); }
    else if (k === 'agent_result') { VS.agent.result = d; VS.agent.running = false; VS.agent.note = ''; indicators(); if (d && !d.ok && d.summary && typeof toast === 'function') toast(d.summary.slice(0, 140)); }
    else if (k === 'agentic') { agenticEvent(d); }
    else if (k === 'agentic_watch') { VS.ag.watch = !!(d && d.on); }
    else if (k === 'agentic_bench_progress') { VS.ag.bench = { running: true, step: d.step, fraction: d.fraction }; }
    else if (k === 'agentic_bench_done') { VS.ag.bench = { running: false, result: d }; call('agentic_metrics').then(r => { if (r && r.agentic) { VS.ag.snap = r.agentic; paint(); } }); }
    else if (k === 'safety_confirm') { VS.confirms = VS.confirms.filter(c => c.id !== d.id).concat([d]); confirmCard(); }
    else if (k === 'safety_confirm_done') { VS.confirms = VS.confirms.filter(c => c.id !== d.id); confirmCard(); }
    else if (k === 'safety_blocked') { if (typeof toast === 'function') toast('Blocked for your safety: ' + (d.reason || '')); }
    else if (k === 'bench_progress') { VS.bench.running = true; VS.bench.step = d.step; VS.bench.fraction = d.fraction; }
    else if (k === 'bench_done') { VS.bench.running = false; VS.bench.result = d; VS.bench.fraction = 1; call('metrics').then(r => { if (r && r.metrics) { VS.metrics = r.metrics; paint(); } }); }
    else if (k === 'report') { VS.report = d; if (typeof toast === 'function') toast('Report saved'); }
    for (const l of listeners) { try { l(k, d); } catch (e) { } }
    paint();
  }

  function agenticEvent(d) {
    const G = VS.ag;
    if (d.event === 'observe') { G.phases = [{ n: 'Look', s: 'run' }]; G.finding = null; G.result = null; G.running = true; }
    else if (d.event === 'detected') { G.finding = d.finding; G.phases.push({ n: 'Detect', s: 'ok' }); }
    else if (d.event === 'proposal') { G.phases.push({ n: 'Propose', s: 'ok', t: (d.steps || []).join(' \u2192 ') }); }
    else if (d.event === 'approved') { G.phases.push({ n: 'Approved', s: 'ok' }); }
    else if (d.event === 'act') { G.phases.push({ n: 'Act', s: 'run', t: (d.steps || []).join(' \u2192 ') }); }
    else if (d.event === 'verified') { G.phases.push({ n: 'Check', s: d.verdict === 'RESOLVED' || d.verdict === 'ASSISTED' ? 'ok' : 'bad', t: d.verdict + ': ' + (d.evidence || []).slice(0, 2).join('; ') }); }
    else if (d.event === 'done') { G.running = false; G.result = d; call('agentic_metrics').then(r => { if (r && r.agentic) { G.snap = r.agentic; paint(); } }); }
    indicators();
  }

  function agentEvent(d) {
    const A = VS.agent;
    if (d.event === 'plan') { A.plan = d.steps.map(s => ({ text: s.text, tool: s.tool, state: 'pending', level: '', evidence: [] })); A.steps = []; A.result = null; A.running = true; A.note = 'Planning with ' + d.planner; }
    else if (d.event === 'observe') { A.observe = d.summary; A.running = true; A.result = null; }
    else if (d.event === 'step_start') { const s = A.plan[d.n - 1]; if (s) { s.state = 'running'; s.level = d.color; s.reason = d.reason; } A.note = 'Step ' + d.n + ' of ' + A.plan.length + ': ' + d.text; }
    else if (d.event === 'step_done') { const s = A.plan[d.n - 1]; if (s) { s.state = d.verdict === 'SUCCESS' ? 'ok' : d.verdict === 'SKIPPED' ? 'skipped' : 'failed'; s.verdict = d.verdict; s.confidence = d.confidence; s.evidence = d.evidence || []; s.detail = d.detail || d.error; } }
    else if (d.event === 'replan') { const s = A.plan[d.n - 1]; if (s) { s.state = 'retry'; s.retry = (d.steps || []).join(' \u2192 '); } A.note = 'That didn\u2019t work \u2013 trying another way'; }
    else if (d.event === 'done') { A.running = false; A.note = ''; }
    indicators();
  }

  if (B && B.onLine) {
    B.onLine(l => { if (typeof l === 'string' && l.startsWith('VISION::')) { try { onMsg(JSON.parse(dec(l.slice(8)))); } catch (e) { console.warn('vision msg', e); } } });
  }

  /* ------------------------------------------------------------ styles */
  const css = document.createElement('style');
  css.textContent = `
  .vgrid{display:grid;grid-template-columns:minmax(260px,1fr) minmax(300px,1.3fr);gap:14px}@media(max-width:1180px){.vgrid{grid-template-columns:1fr}}
  .vprev{position:relative;background:#000;border-radius:var(--r2);overflow:hidden;min-height:180px;display:flex;align-items:center;justify-content:center;border:1px solid var(--k3)}
  .vprev img{width:100%;display:block}.vprev .note{padding:18px;text-align:center}
  .vchip{display:inline-block;padding:2px 9px;border-radius:12px;font-size:11.5px;margin:0 6px 4px 0;border:1px solid var(--k3);background:var(--p2)}
  .vchip.ok{border-color:#3fbf7f;color:#7be0a8}.vchip.warn{border-color:#d9a441;color:#f0c46a}.vchip.bad{border-color:#d9534f;color:#ff8b87}
  .vbar{height:6px;border-radius:4px;background:var(--k3);overflow:hidden;min-width:70px}.vbar i{display:block;height:100%;background:var(--a2)}
  .vtbl{width:100%;border-collapse:collapse;font-size:12.5px}.vtbl td,.vtbl th{padding:4px 8px;border-bottom:1px solid var(--k3);text-align:left}
  .vstep{display:flex;gap:10px;align-items:flex-start;padding:8px 10px;border:1px solid var(--k3);border-radius:var(--r2);margin:0 0 8px;background:var(--p2)}
  .vstep .dot{width:12px;height:12px;border-radius:50%;margin-top:4px;flex:none;background:var(--k3)}
  .vstep.running .dot{background:var(--a);box-shadow:0 0 8px var(--a)}.vstep.ok .dot{background:#3fbf7f}.vstep.failed .dot,.vstep.skipped .dot{background:#d9534f}.vstep.retry .dot{background:#d9a441}
  .vstep small{display:block;color:var(--m);font-size:11.5px;margin-top:2px}
  .lvl{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px}.lvl.green{background:#3fbf7f}.lvl.yellow{background:#e3b341}.lvl.red{background:#e5534b}
  .vtiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px;margin-bottom:12px}
  .vtile{border:1px solid var(--k3);border-radius:var(--r2);padding:10px 12px;background:var(--p2)}.vtile b{font-size:22px;display:block}.vtile span{color:var(--m);font-size:12px}
  #vsn-confirm{position:fixed;right:22px;bottom:22px;z-index:9999;width:min(420px,calc(100vw - 44px));display:flex;flex-direction:column;gap:10px}
  #vsn-confirm .cc{border:1px solid var(--a2);background:var(--p);border-radius:var(--r2);padding:14px 16px;box-shadow:0 8px 40px rgba(0,0,0,.55)}
  #vsn-confirm .cc.red{border-color:#e5534b}#vsn-confirm .cc.yellow{border-color:#e3b341}
  #vsn-confirm .cc h5{margin:0 0 6px;font-size:13px;letter-spacing:.04em}#vsn-confirm .cc .row{margin-top:10px;display:flex;gap:8px}
  .vind{display:none;align-items:center;gap:6px;padding:3px 10px;border-radius:14px;font-size:12px;border:1px solid var(--k3);background:var(--p2);margin-left:8px;white-space:nowrap}
  .vind.on{display:inline-flex}.vind i{width:8px;height:8px;border-radius:50%;background:#e5534b;box-shadow:0 0 6px #e5534b}.vind.agent i{background:var(--a);box-shadow:0 0 6px var(--a);animation:vpulse 1s infinite}
  @keyframes vpulse{50%{opacity:.35}}
  .vset label.f{display:block;margin:8px 0 3px;font-size:12.5px;color:var(--m)}.vset .row{align-items:center;margin-top:4px}.vset input[type=text],.vset input[type=number],.vset input[type=password],.vset select{min-width:260px;max-width:560px}
  .vset input[type=number]{min-width:110px;max-width:140px}.vset .okline{color:#7be0a8;font-size:12px;min-height:16px}
  `;
  document.head.appendChild(css);

  /* ------------------------------------------------------------ header indicators + confirmation card */
  function indicators() {
    const hdr = document.querySelector('header');
    if (!hdr) return;
    let cam = document.getElementById('vsn-cam'), ag = document.getElementById('vsn-agent');
    if (!cam) {
      const anchor = document.getElementById('pill');
      cam = document.createElement('span'); cam.id = 'vsn-cam'; cam.className = 'vind'; cam.title = 'Camera is on. Click to turn it off.'; cam.innerHTML = '<i></i><span>Camera on</span>';
      cam.style.cursor = 'pointer'; cam.onclick = () => call('camera_stop');
      ag = document.createElement('span'); ag.id = 'vsn-agent'; ag.className = 'vind agent'; ag.title = 'FRIDAY is working on a task. Click to stop it.'; ag.innerHTML = '<i></i><span id="vsn-agent-t">Agent working</span>';
      ag.style.cursor = 'pointer'; ag.onclick = () => call('agent_stop');
      if (anchor && anchor.parentNode) { anchor.parentNode.insertBefore(cam, anchor.nextSibling); anchor.parentNode.insertBefore(ag, cam.nextSibling); } else { hdr.appendChild(cam); hdr.appendChild(ag); }
    }
    const s = VS.session || {};
    cam.classList.toggle('on', !!(s.running && s.kind === 'camera'));
    ag.classList.toggle('on', !!VS.agent.running);
    const t = document.getElementById('vsn-agent-t'); if (t) t.textContent = VS.agent.note ? VS.agent.note.slice(0, 46) : 'Agent working';
  }

  function confirmCard() {
    let box = document.getElementById('vsn-confirm');
    if (!box) { box = document.createElement('div'); box.id = 'vsn-confirm'; document.body.appendChild(box); }
    box.innerHTML = VS.confirms.map(c => `<div class="cc ${E(c.color)}" data-id="${E(c.id)}"><h5><span class="lvl ${E(c.color)}"></span>${c.level === 'restricted' ? 'RESTRICTED ACTION' : 'CONFIRM ACTION'}</h5><div>${E(c.prompt)}</div>
      <div class="row"><button class="btn" data-ok="1">${c.level === 'restricted' ? 'Confirm' : 'Approve'}</button><button class="btn g" data-ok="0">${c.level === 'restricted' ? 'Cancel' : 'Deny'}</button>${c.action && c.action.false_alarm_button ? '<button class="btn g" data-fa="1" title="Tell FRIDAY this is not a real error">Not an error</button>' : ''}</div></div>`).join('');
    box.querySelectorAll('.cc').forEach(card => card.querySelectorAll('button').forEach(b => b.onclick = () => {
      call('confirm', { id: card.dataset.id, approve: b.dataset.ok === '1', typed: 'confirm', false_alarm: b.dataset.fa === '1' });
      VS.confirms = VS.confirms.filter(c => c.id !== card.dataset.id); confirmCard();
    }));
  }

  /* ------------------------------------------------------------ Vision page */
  let host = null;
  const TABS = ['Live', 'Agent', 'Evaluation'];
  const lvl = c => `<span class="lvl ${E(c || '')}"></span>`;

  function paint() {
    if (!host || !document.body.contains(host) || typeof V === 'undefined' || V !== 'Vision') return;
    if (VS.tab === 'Live') paintLive(); else if (VS.tab === 'Agent') { paintAgent(); paintAgentic(); } else paintEval();
  }

  window.visionV = function (e) {
    host = e;
    e.innerHTML = `<h2>Vision</h2><p class="note">FRIDAY sees through OpenCV 5 (screen, camera, pictures, video), reasons with Gemini, acts with its computer tools and checks the result with vision before it says it is done.</p>
      <div class="tabs" id="vtabs">${TABS.map(t => `<button class="tb ${t === VS.tab ? 'on' : ''}" data-vt="${t}">${t}</button>`).join('')}</div><div id="vbody"></div>`;
    e.querySelectorAll('[data-vt]').forEach(b => b.onclick = () => { VS.tab = b.dataset.vt; window.visionV(e); });
    if (VS.tab === 'Live') buildLive(); else if (VS.tab === 'Agent') buildAgent(); else buildEval();
    call('status').then(r => { if (r && r.ok) { VS.status = r; VS.metrics = r.metrics; VS.session = r.session || VS.session; if (r.agent && r.agent.running) VS.agent.running = true; if (r.last_state && !VS.state) VS.state = r.last_state; if (r.pending && r.pending.length) { VS.confirms = r.pending; confirmCard(); } indicators(); paint(); } });
  };

  /* ---- Live ---- */
  function buildLive() {
    const b = host.querySelector('#vbody');
    b.innerHTML = `<div class="vgrid">
      <div>
        <div class="sg"><h4>Sources</h4><p class="note">Nothing is watched until you switch it on. The camera turns itself off after the idle limit in Settings &gt; Vision.</p>
          <div class="row"><button class="btn" id="v-cam"></button> <button class="btn g" id="v-scr"></button></div>
          <label class="tgl" style="display:block;margin-top:8px"><input type="checkbox" id="v-prev" ${VS.session && VS.session.preview === false ? '' : 'checked'}> Show live preview with boxes</label>
          <div class="row" style="margin-top:10px"><button class="btn g s" id="v-ss">Look at screen</button> <button class="btn g s" id="v-sc">Look through camera</button> <button class="btn g s" id="v-sf">Analyse a picture or video...</button> <button class="btn g s" id="v-ch">What changed?</button></div>
          <label class="tgl" style="display:block;margin-top:8px"><input type="checkbox" id="v-gem"> Also ask Gemini to describe it <span class="note">(sends the picture to Google)</span></label>
          <div class="note" id="v-msg"></div>
        </div>
        <div class="sg"><h4>Live view</h4><div class="vprev"><img id="v-img" style="display:none"><span class="vchip" id="v-live" style="position:absolute;left:8px;top:8px;margin:0;display:none;background:#000a"></span><div class="note" id="v-nolive">Turn on the camera or screen vision (or press a Look button) to see exactly what FRIDAY sees, with her detections drawn on it.</div></div><div id="v-chips" style="margin-top:8px"></div></div>
      </div>
      <div>
        <div class="sg"><h4>What I see</h4><div id="v-sum" class="tip">Nothing analysed yet.</div><div id="v-details"></div></div>
      </div></div>`;
    const ask = () => b.querySelector('#v-gem').checked;
    const msg = t => { const m = b.querySelector('#v-msg'); if (m) m.textContent = t || ''; };
    b.querySelector('#v-cam').onclick = async () => { msg('...'); const on = VS.session.running && VS.session.kind === 'camera'; const r = on ? await call('camera_stop') : await call('camera_start', { preview: b.querySelector('#v-prev').checked, speak: false }); msg(r.ok === false ? r.error : ''); paint(); };
    b.querySelector('#v-scr').onclick = async () => { const on = VS.session.running && VS.session.kind === 'screen'; const r = await call(on ? 'screen_stop' : 'screen_start'); msg(r.ok === false ? r.error : ''); paint(); };
    b.querySelector('#v-prev').onchange = e => call('preview', { on: e.target.checked });
    b.querySelector('#v-ss').onclick = async () => { msg('Looking at the screen...'); const r = await call('snapshot', { source: 'screen', gemini: ask() }); msg(r.ok ? '' : r.error); };
    b.querySelector('#v-sc').onclick = async () => { msg('Looking through the camera...'); const r = await call('snapshot', { source: 'camera', gemini: ask() }); msg(r.ok ? '' : r.error); };
    b.querySelector('#v-sf').onclick = async () => { const p = B && B.pickVisionFile ? await B.pickVisionFile('media') : ''; if (!p) return; msg('Analysing ' + p.split(/[\\/]/).pop() + '...'); const r = await call('analyze_file', { path: p, gemini: ask() }); msg(r.ok ? '' : r.error); };
    b.querySelector('#v-ch').onclick = async () => { const r = await call('compare', { source: VS.session.running && VS.session.kind === 'camera' ? 'camera' : 'screen' }); msg(r.message || r.error || ''); };
    paintLive();
  }

  /* V7.6: frames update only the picture (no full repaint, so no flicker) and say how fresh the boxes are */
  function liveFrame() {
    const b = host && host.querySelector('#vbody'); if (!b || VS.tab !== 'Live') return;
    const img = b.querySelector('#v-img'), nl = b.querySelector('#v-nolive'); if (!img || !VS.frame || !(VS.session && VS.session.running)) return;
    img.src = 'data:image/jpeg;base64,' + VS.frame.jpeg; img.style.display = 'block'; if (nl) nl.style.display = 'none';
    liveTag();
  }
  function liveTag() {
    const b = host && host.querySelector('#vbody'); if (!b) return;
    const t = b.querySelector('#v-live'), img = b.querySelector('#v-img'); if (!t) return;
    const f = VS.frame, s = VS.session || {};
    if (f && s.running && img && img.style.display !== 'none') {
      t.style.display = 'inline-block';
      t.textContent = 'LIVE \u00b7 ' + (f.boxes ? f.boxes + ' box' + (f.boxes === 1 ? '' : 'es') : 'no boxes') + (f.state_age_ms != null ? ' \u00b7 ' + (f.state_age_ms / 1000).toFixed(1) + ' s old' : '');
    } else if (img && img.style.display !== 'none' && VS.snapImg) { t.style.display = 'inline-block'; t.textContent = 'Picture that was analysed'; }
    else t.style.display = 'none';
  }
  setInterval(() => {
    const el = document.getElementById('v-stamp'); if (!el) return;
    const ts = parseFloat(el.dataset.ts), a = document.getElementById('v-age'); if (!ts || !a) return;
    const d = Math.max(0, Date.now() / 1000 - ts);
    a.textContent = '\u00b7 ' + (d < 1.5 ? 'just now' : d < 90 ? Math.round(d) + ' s ago' : Math.round(d / 60) + ' min ago');
  }, 500);

  function paintLive() {
    const b = host && host.querySelector('#vbody'); if (!b || !b.querySelector('#v-cam')) return;
    const s = VS.session || {}, camOn = s.running && s.kind === 'camera', scrOn = s.running && s.kind === 'screen';
    b.querySelector('#v-cam').textContent = camOn ? 'Camera: ON (click to stop)' : 'Turn on camera';
    b.querySelector('#v-scr').textContent = scrOn ? 'Screen vision: ON (click to stop)' : 'Turn on screen vision';
    const img = b.querySelector('#v-img'), nl = b.querySelector('#v-nolive');
    if (VS.frame && s.running && s.preview !== false) { img.src = 'data:image/jpeg;base64,' + VS.frame.jpeg; img.style.display = 'block'; nl.style.display = 'none'; }
    else if (!s.running && VS.snapImg) { img.src = 'data:image/jpeg;base64,' + VS.snapImg; img.style.display = 'block'; nl.style.display = 'none'; }
    else { img.style.display = 'none'; nl.style.display = 'block'; nl.textContent = s.running && s.preview === false ? 'Live preview is switched off. Tick \u201cShow live preview with boxes\u201d to watch it.' : s.running ? 'Starting the picture...' : nl.textContent; }
    liveTag();
    const st = VS.state;
    const chips = [];
    if (s.running) chips.push(`<span class="vchip ok">${E(s.kind)} on</span>`);
    if (VS.motion && VS.motion.motion && s.running) chips.push(`<span class="vchip warn">motion${VS.motion.direction && VS.motion.direction !== 'none' ? ' \u2192 ' + E(VS.motion.direction) : ''}</span>`);
    if (st) { chips.push(`<span class="vchip">${(st.objects || []).length} object(s)</span>`); if (st.timings_ms && st.timings_ms.total != null) chips.push(`<span class="vchip">${Math.round(st.timings_ms.total)} ms</span>`); chips.push(`<span class="vchip ${st.confidence >= .6 ? 'ok' : st.confidence >= .35 ? 'warn' : 'bad'}">confidence ${pct(st.confidence)}</span>`); if (st.remote) chips.push('<span class="vchip ok">cloud</span>'); }
    b.querySelector('#v-chips').innerHTML = chips.join('');
    const sum = b.querySelector('#v-sum'), det = b.querySelector('#v-details');
    if (!st) { sum.textContent = 'Nothing analysed yet.'; det.innerHTML = ''; return; }
    const kindName = { camera: 'Camera', screen: 'Screen', image: 'Picture', video: 'Video' }[(st.source || {}).kind] || 'View';
    const ageS = st.ts ? Math.max(0, (Date.now() / 1000) - st.ts) : null;
    const live = s.running && s.kind === (st.source || {}).kind;
    const stamp = `<div class="note" id="v-stamp" data-ts="${st.ts || ''}" data-live="${live ? 1 : 0}" style="margin-bottom:6px">${E(kindName)}${st.size ? ' \u00b7 ' + st.size[0] + '\u00d7' + st.size[1] : ''} \u00b7 ${live ? 'live' : 'last look'} <span id="v-age"></span></div>`;
    sum.innerHTML = stamp + E(st.summary || '') + ((st.changes || []).length ? `<br><small class="note">Changed: ${E(st.changes.join(', '))}</small>` : '');
    const rows = (st.objects || []).map(o => `<tr><td>${E(o.label)}${o.id ? ' <small class="note">#' + o.id + '</small>' : ''}</td><td><div class="vbar"><i style="width:${Math.round((o.conf || 0) * 100)}%"></i></div></td><td>${pct(o.conf)}</td><td>${E(o.region || '')}</td></tr>`).join('');
    const tracks = (st.tracks || []).filter(t => t.moving).map(t => `<li>${E(t.label)} #${t.id}: ${E(t.from)} \u2192 ${E(t.to)}</li>`).join('');
    const vid = st.video ? `<p class="note">Video: ${E(st.video.duration_s)} s, ${E(st.video.frames_analyzed)} frames analysed in ${E(st.video.analysis_seconds)} s; scene changes: ${(st.video.scene_changes || []).length}</p>` : '';
    det.innerHTML = `${rows ? `<table class="vtbl"><tr><th>Object</th><th>Confidence</th><th></th><th>Where</th></tr>${rows}</table>` : ''}
      ${(st.relations || []).length ? `<h4 style="margin:10px 0 4px">Spatial relationships</h4><ul style="margin:0 0 0 18px">${st.relations.map(r => `<li>${E(r)}</li>`).join('')}</ul>` : ''}
      ${tracks ? `<h4 style="margin:10px 0 4px">Tracked movement</h4><ul style="margin:0 0 0 18px">${tracks}</ul>` : ''}
      ${st.errors && st.errors.has_error ? `<div class="tip" style="border-color:#e5534b"><b>Error message on screen:</b> ${E(st.errors.matches[0] || '')}</div>` : ''}
      ${st.text && st.text.excerpt ? `<h4 style="margin:10px 0 4px">Text read (OCR ${pct(st.text.confidence)})</h4><pre style="white-space:pre-wrap;margin:0;font-size:12px;max-height:150px;overflow:auto">${E(st.text.excerpt)}</pre>` : ''}
      ${st.quality ? `<p class="note">Picture quality ${pct(st.quality.score)}${(st.quality.notes || []).length ? ' (' + E(st.quality.notes.join(', ')) + ')' : ''}. Detectors: ${E((st.detectors || []).join(', ') || 'none')}.</p>` : ''}${vid}
      ${VS.change ? `<div class="tip">${E(VS.change.message || '')}</div>` : ''}`;
  }

  /* ---- Agent ---- */
  function buildAgent() {
    const b = host.querySelector('#vbody');
    b.innerHTML = `<div class="vgrid"><div>
      <div class="sg"><h4>Give FRIDAY a goal</h4><p class="note">She looks at the screen, plans, acts, then checks the result with vision. Green actions run by themselves, yellow ones ask first, red ones are blocked or need your explicit confirmation.</p>
        <div class="row"><input id="a-goal" placeholder="e.g. open my chemistry notes" style="flex:1;min-width:240px"><button class="btn" id="a-run">Run</button><button class="btn g" id="a-stop">Stop</button></div>
        <div style="margin-top:8px">${['open notepad', 'open my chemistry notes', 'search the web for photosynthesis diagram', 'open calculator and then open chrome', 'close chrome'].map(x => `<button class="chip" data-ex="${E(x)}">${E(x)}</button>`).join('')}</div>
        <div class="note" id="a-msg"></div>
      </div>
      <div class="sg"><h4>Problem solver (sees an error, proposes a fix, asks, fixes, checks)</h4>
        <p class="note">She reads the error on screen, says what she would do, and only acts after your yes. Then she looks again and tells you honestly whether it is gone. Say \u201cfix the error on my screen\u201d.</p>
        <div class="row"><button class="btn" id="g-run">Scan my screen and fix problems</button><button class="btn g" id="g-stop">Stop</button><label class="tgl"><input type="checkbox" id="g-watch"> Watch for errors and ask me</label><button class="btn g" id="g-bench">Run benchmark</button></div>
        <div id="g-prog"></div><div id="g-tiles"></div></div>
      <div class="sg"><h4>Safety log</h4><div id="a-audit" class="note">Loading...</div></div>
    </div><div><div class="sg"><h4>Task progress</h4><div id="a-prog"></div></div></div></div>`;
    b.querySelector('#g-run').onclick = () => { VS.ag = Object.assign(VS.ag, { phases: [], finding: null, result: null, running: true }); call('agentic_run', { speak: true }); paintAgentic(); };
    b.querySelector('#g-stop').onclick = () => call('agentic_stop');
    b.querySelector('#g-watch').checked = !!VS.ag.watch;
    b.querySelector('#g-watch').onchange = e => call('agentic_watch', { on: e.target.checked, speak: true });
    b.querySelector('#g-bench').onclick = () => call('agentic_bench', { speak: false });
    call('agentic_metrics').then(r => { if (r && r.agentic) { VS.ag.snap = r.agentic; VS.ag.watch = !!r.agentic.watch; paintAgentic(); } });
    const run = async () => { const g = b.querySelector('#a-goal').value.trim(); if (!g) return; VS.agent = { plan: [], steps: [], result: null, running: true, note: 'Starting...' }; indicators(); paint(); const r = await call('agent_run', { goal: g, speak: true }); if (r && r.ok === false) { VS.agent.running = false; b.querySelector('#a-msg').textContent = r.error === 'busy' ? 'Still working on the previous task.' : r.error; indicators(); } };
    b.querySelector('#a-run').onclick = run;
    b.querySelector('#a-goal').onkeydown = e => { if (e.key === 'Enter') run(); };
    b.querySelector('#a-stop').onclick = () => call('agent_stop');
    b.querySelectorAll('[data-ex]').forEach(x => x.onclick = () => { b.querySelector('#a-goal').value = x.dataset.ex; b.querySelector('#a-goal').focus(); });
    call('audit').then(r => { VS.audit = (r && r.audit) || []; paintAgent(); });
    paintAgent();
  }

  function paintAgentic() {
    const b = host && host.querySelector('#vbody'); if (!b || !b.querySelector('#g-prog')) return;
    const G = VS.ag; let h = '';
    if (G.finding) h += `<div class="tip" style="border-color:#e3b341"><b>Saw:</b> ${E(G.finding.app || '')} \u2013 ${E((G.finding.message || '').slice(0, 160))}<br><small class="note">${E(G.finding.category || '')} \u00b7 confidence ${pct(G.finding.confidence)} \u00b7 ${E((G.finding.evidence || []).slice(0, 2).join('; '))}</small></div>`;
    h += (G.phases || []).map(p => `<span class="vchip ${p.s === 'ok' ? 'ok' : p.s === 'bad' ? 'bad' : 'warn'}" title="${E(p.t || '')}">${E(p.n)}</span>`).join('');
    if (G.result) h += `<div class="tip" style="border-color:${G.result.ok ? '#3fbf7f' : '#e5534b'}"><b>${E(G.result.status || '')}</b> \u2013 ${E(G.result.summary || '')}<br><small class="note">${G.result.active_seconds != null ? G.result.active_seconds + ' s working' : ''}</small></div>`;
    else if (G.running) h += '<p class="note">\u2699 Working...</p>';
    if (G.bench && G.bench.running) h += `<p class="note">Benchmark: ${E(G.bench.step || '')} (${Math.round((G.bench.fraction || 0) * 100)}%)</p>`;
    b.querySelector('#g-prog').innerHTML = h;
    const s = VS.ag.snap, m = (s && s.measures) || {}, c = (s && s.counters) || {}, lb = (s && s.last_benchmark) || {};
    const tl = (v, l, sub) => `<div class="vtile"><b>${v == null ? '\u2013' : v}</b><span>${E(l)}</span><small>${E(sub || '')}</small></div>`;
    const med = m.time_to_complete && m.time_to_complete.median;
    b.querySelector('#g-tiles').innerHTML = `<div class="vtiles" style="margin-top:8px">${tl(m.task_completion_pct == null ? null : m.task_completion_pct + '%', 'Task completion', (c.resolved || 0) + '/' + (c.acted || 0) + ' fixed')}${tl(m.false_detection_pct == null ? null : m.false_detection_pct + '%', 'False detections', (c.false_alarms || 0) + '/' + (c.incidents || 0) + ' flagged')}${tl(m.recovery_pct == null ? null : m.recovery_pct + '%', 'Recovery rate', (c.recovered || 0) + '/' + (c.first_try_failed || 0))}${tl(med == null ? null : med + ' s', 'Median time to fix', 'excludes waiting for you')}</div>` +
      (lb.task_completion_pct != null ? `<p class="note">Last benchmark (${lb.scenarios} simulated scenarios): completion ${lb.task_completion_pct}% \u00b7 false detections ${lb.false_detection_pct}% \u00b7 recovery ${lb.recovery_pct}% \u00b7 median ${(lb.time_to_complete || {}).median} s \u00b7 unsafe stopped ${E(lb.unsafe_stopped || '')}</p>` : '');
  }

  function paintAgent() {
    const b = host && host.querySelector('#vbody'); if (!b || !b.querySelector('#a-prog')) return;
    const A = VS.agent;
    let html = '';
    if (A.observe) html += `<p class="note">\ud83d\udc41 Saw: ${E(A.observe.slice(0, 200))}</p>`;
    html += A.plan.map((s, i) => `<div class="vstep ${s.state}"><span class="dot"></span><div style="flex:1"><b>${i + 1}. ${E(s.text)}</b> ${s.level ? lvl(s.level) : ''}<small>${s.state === 'running' ? 'working...' : s.state === 'ok' ? 'Verified on screen (' + pct(s.confidence) + ')' : s.state === 'failed' ? 'Could not verify' : s.state === 'skipped' ? 'Not done: ' + E(s.detail || '') : s.state === 'retry' ? 'Trying another way: ' + E(s.retry || '') : 'waiting'}</small>
      ${(s.evidence || []).length ? `<small>${s.evidence.slice(0, 4).map(E).join(' \u00b7 ')}</small>` : ''}</div></div>`).join('');
    if (!A.plan.length) html += '<p class="note">No task yet.</p>';
    if (A.running && A.note) html += `<p class="note">\u2699 ${E(A.note)}</p>`;
    const r = A.result;
    if (r) html += `<div class="tip" style="border-color:${r.ok ? '#3fbf7f' : '#e5534b'}"><b>${r.ok ? 'Done and verified' : 'Not completed'}</b><br>${E(r.summary || '')}<br><small class="note">${r.seconds != null ? r.seconds + ' s' : ''}${r.replans ? ' \u00b7 ' + r.replans + ' replan(s)' : ''}${r.confidence ? ' \u00b7 confidence ' + pct(r.confidence) : ''}</small></div>`;
    b.querySelector('#a-prog').innerHTML = html;
    b.querySelector('#a-audit').innerHTML = (VS.audit || []).slice(-8).reverse().map(a => `<div>${lvl(a.level === 'safe' ? 'green' : a.level === 'confirm' ? 'yellow' : 'red')}${E(a.ts || '')} \u2013 ${E((a.action || '').slice(0, 70))} <b>${E(a.decision || '')}</b></div>`).join('') || 'No actions recorded yet.';
  }

  /* ---- Evaluation ---- */
  function buildEval() {
    const b = host.querySelector('#vbody');
    b.innerHTML = `<div id="e-tiles"></div>
      <div class="sg"><h4>Benchmark</h4><p class="note">Runs reproducible tests on this PC: detection accuracy, motion, change detection, tracking, OCR, OpenCV speed and a simulated-desktop run of the agent. Takes about a minute.</p>
        <div class="row"><button class="btn" id="e-run">Run benchmark</button><button class="btn g" id="e-rep">Export report</button><button class="btn g" id="e-open">Open reports folder</button><button class="btn g s" id="e-reset">Reset live counters</button></div>
        <div class="vbar" style="margin-top:10px"><i id="e-bar" style="width:0"></i></div><div class="note" id="e-step"></div></div>
      <div id="e-res"></div>`;
    b.querySelector('#e-run').onclick = async () => { VS.bench = { running: true, step: 'Starting', fraction: 0.02, result: null }; paint(); await call('bench_run', { speak: false }); };
    b.querySelector('#e-rep').onclick = async () => { const r = await call('report'); b.querySelector('#e-step').textContent = r.ok ? 'Saved: ' + r.markdown : (r.error || ''); };
    b.querySelector('#e-open').onclick = () => B && B.openVisionFolder && B.openVisionFolder('exports');
    b.querySelector('#e-reset').onclick = async () => { const r = await call('metrics_reset'); if (r.metrics) { VS.metrics = r.metrics; paint(); } };
    paintEval();
  }

  function paintEval() {
    const b = host && host.querySelector('#vbody'); if (!b || !b.querySelector('#e-tiles')) return;
    const m = VS.metrics || {}, r = m.rates || {}, c = m.counters || {}, l = m.latency || {};
    const tile = (v, n, sub) => `<div class="vtile"><b>${v == null ? '–' : v}</b><span>${n}${sub ? '<br>' + sub : ''}</span></div>`;
    b.querySelector('#e-tiles').innerHTML = `<h4 style="margin:0 0 8px">Live (counted from real use)</h4><div class="vtiles">${tile(r.task_success_pct == null ? null : r.task_success_pct + '%', 'Task success', (c.tasks_ok || 0) + '/' + (c.tasks || 0))}
      ${tile(r.action_success_pct == null ? null : r.action_success_pct + '%', 'Action success', (c.actions_ok || 0) + '/' + (c.actions || 0))}
      ${tile(r.verification_success_pct == null ? null : r.verification_success_pct + '%', 'Verification success', (c.verifications_ok || 0) + '/' + (c.verifications || 0))}
      ${tile(r.recovery_success_pct == null ? null : r.recovery_success_pct + '%', 'Recovery success', (c.recoveries_ok || 0) + '/' + (c.recoveries || 0))}
      ${tile(l.vision_avg_ms == null ? null : Math.round(l.vision_avg_ms) + ' ms', 'Vision latency (avg)', l.vision_p95_ms != null ? 'p95 ' + Math.round(l.vision_p95_ms) + ' ms' : '')}
      ${tile(l.llm_avg_ms == null ? null : Math.round(l.llm_avg_ms) + ' ms', 'Gemini latency (avg)')}
      ${tile((c.approved || 0) + '/' + (c.denied || 0) + '/' + (c.blocked || 0), 'Approved / denied / blocked')}</div>`;
    b.querySelector('#e-bar').style.width = Math.round((VS.bench.fraction || 0) * 100) + '%';
    b.querySelector('#e-step').textContent = VS.bench.running ? 'Running: ' + (VS.bench.step || '') : (VS.report ? 'Report saved: ' + VS.report.markdown : '');
    b.querySelector('#e-run').disabled = !!VS.bench.running;
    const res = VS.bench.result || m.last_benchmark;
    const out = b.querySelector('#e-res');
    if (!res || !res.detection && !res.micro && !res.error) { out.innerHTML = ''; return; }
    if (res.error) { out.innerHTML = `<div class="tip" style="border-color:#e5534b">${E(res.error)}</div>`; return; }
    const d = (res.detection || {}).clean || {}, mo = res.motion || {}, ch = res.change || {}, tr = res.tracking || {}, oc = res.ocr || {}, ag = res.agent_sim || {};
    const micro = ((res.micro || {}).operations) || {};
    const env = res.environment || {};
    out.innerHTML = `<div class="sg"><h4>Last benchmark <small class="note">${E(res.finished || '')} \u00b7 ${E(res.total_seconds)} s</small></h4>
      <p class="note">OpenCV ${E(env.opencv_version)} on ${E(env.machine)} (${E(env.cpu_count)} cores). COOL build: ${env.cool && env.cool.active ? 'active' : 'not detected'}.</p>
      <div class="vtiles">${tile(d.f1, 'Detection F1', 'precision ' + (d.precision == null ? '–' : d.precision) + ', recall ' + (d.recall == null ? '–' : d.recall))}${tile(mo.accuracy == null ? null : Math.round(mo.accuracy * 100) + '%', 'Motion accuracy')}${tile(ch.accuracy == null ? null : Math.round(ch.accuracy * 100) + '%', 'Change detection')}${tile(tr.identity_consistency == null ? null : Math.round(tr.identity_consistency * 100) + '%', 'Tracking identity')}
      ${tile(oc.skipped ? 'skipped' : (oc.char_similarity == null ? null : Math.round(oc.char_similarity * 100) + '%'), 'OCR accuracy', oc.skipped ? E(oc.reason || '') : '')}${tile(ag.tasks_ok == null ? null : ag.tasks_ok + '/' + ag.achievable, 'Agent tasks completed (sim)', 'recoveries ' + (ag.recoveries_ok || 0) + '/' + (ag.recoveries || 0) + ' \u00b7 unsafe blocked ' + (ag.unsafe_blocked || 0) + '/' + (ag.unsafe_total || 0))}</div>
      ${Object.keys(micro).length ? `<table class="vtbl"><tr><th>OpenCV operation (${E((res.micro || {}).frame)})</th><th>median ms</th><th>p95 ms</th></tr>${Object.entries(micro).map(([k, v]) => `<tr><td>${E(k)}</td><td>${v.median_ms != null ? v.median_ms : '–'}</td><td>${v.p95_ms != null ? v.p95_ms : '–'}</td></tr>`).join('')}</table>` : ''}</div>`;
  }

  /* ------------------------------------------------------------ Settings > Vision */
  const FS = {};
  FS.html = function () { return '<div class="vset" id="vsn-set"><p class="note">Loading Vision settings...</p></div>'; };
  FS.wire = async function (box) {
    const root = box.querySelector('#vsn-set'); if (!root) return;
    const r = await call('status', {}, 20000);
    if (!r || !r.ok) { root.innerHTML = `<p class="note">${E((r && r.error) || 'Vision settings are available in the desktop app.')}</p>`; return; }
    let cfg = r.config;
    const env = r.environment || {};
    const field = (key, label, type, opts) => {
      opts = opts || {};
      const v = cfg[key];
      let input;
      if (type === 'bool') input = `<label class="tgl"><input type="checkbox" data-vk="${key}" ${v ? 'checked' : ''}> ${label}</label>`;
      else if (type === 'select') input = `<label class="f">${label}</label><select data-vk="${key}">${opts.options.map(([val, n]) => `<option value="${val}" ${String(v) === String(val) ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
      else if (type === 'range') input = `<label class="f">${label}: <b data-vo="${key}">${v}</b></label><input type="range" data-vk="${key}" min="${opts.min}" max="${opts.max}" step="${opts.step}" value="${v}" style="width:260px">`;
      else if (type === 'number') input = `<label class="f">${label}</label><input type="number" data-vk="${key}" value="${E(v)}" ${opts.min != null ? `min="${opts.min}"` : ''} ${opts.max != null ? `max="${opts.max}"` : ''} step="${opts.step || 1}">`;
      else input = `<label class="f">${label}</label><div class="row" style="margin-top:0"><input type="text" data-vk="${key}" value="${E(v)}" placeholder="${E(opts.ph || '')}" spellcheck="false" autocomplete="off">${opts.browse ? `<button class="btn g s" data-browse="${opts.browse}" data-for="${key}">Browse...</button>` : ''}</div>`;
      return `<div style="margin:4px 0">${input}${opts.note ? `<div class="note">${opts.note}</div>` : ''}</div>`;
    };
    const sec = (title, note, body) => `<div class="sg"><h4>${title}</h4>${note ? `<p class="note">${note}</p>` : ''}${body}</div>`;
    root.innerHTML = `<div class="okline" id="vs-saved"></div>
      ${sec('Status', '', `<p class="note">OpenCV: <b>${E(env.opencv_version || 'not installed')}</b>${env.opencv5 ? ' (OpenCV 5, new DNN engine available)' : env.available ? ' (OpenCV 4 \u2013 works, but the new OpenCV 5 DNN engine needs OpenCV 5)' : ''} \u00b7 OCR (Tesseract): <b>${r.tesseract && r.tesseract.ok ? 'ready' : 'not found'}</b> \u00b7 Machine: ${E(env.machine || '')}, ${E(env.cpu_count || '')} cores \u00b7 COOL: ${env.cool && env.cool.active ? 'active' : 'not detected'}</p>
        ${!env.available || !env.opencv5 ? `<div class="tip" style="border-color:${env.available ? '#e3b341' : '#e5534b'}">${env.available ? 'You have OpenCV 4. Everything works, but the new OpenCV 5 DNN engine needs OpenCV 5.' : 'OpenCV is not installed yet.'} <button class="btn s" id="vs-inst">${env.available ? 'Upgrade to OpenCV 5' : 'Install OpenCV'}</button> <span class="note" id="vs-inststat"></span></div>` : ''}
        ${env.available && !(r.tesseract && r.tesseract.ok) ? `<div class="tip">Reading text on screen needs <b>Tesseract OCR</b> (free). Install the free UB-Mannheim Windows build, then FRIDAY finds it automatically (or point to tesseract.exe below).</div>` : ''}`)}
      ${sec('Sources and privacy', 'The camera and screen are only used when you ask. Nothing leaves this PC unless you tick the options below.',
      field('camera_index', 'Camera number (0 = first camera)', 'number', { min: 0, max: 9 }) + field('camera_auto_off_minutes', 'Camera switches itself off after (minutes, 0 = never)', 'number', { min: 0, max: 600 }) +
      field('monitor_index', 'Monitor to look at (1 = main, 0 = all together)', 'number', { min: 0, max: 8 }) +
      field('camera_allow_cloud', 'Allow camera pictures to be sent to Gemini / my cloud server', 'bool') + field('chat_camera_describe', 'When I ask FRIDAY what she sees, send that one camera picture to Gemini so she can describe it like a person', 'bool') + field('screen_allow_cloud', 'Allow screenshots to be sent to Gemini when I ask a visual question', 'bool'))}
      ${sec('Object detector', 'Out of the box FRIDAY finds objects with OpenCV itself (no download). For named objects (phone, laptop, cup ...) give it an ONNX detector such as a YOLO model; it runs on OpenCV\u2019s DNN engine.',
      field('detector', 'Detector', 'select', { options: [['auto', 'Automatic (best available)'], ['onnx', 'ONNX model only'], ['builtin', 'OpenCV built-in (faces / people)'], ['contours', 'Object shapes only']] }) +
      field('onnx_model_path', 'ONNX model file', 'text', { browse: 'model', ph: 'C:\\models\\yolo.onnx' }) +
      `<div class="row"><input type="text" id="vs-murl" placeholder="or paste an https:// link to a .onnx file" style="min-width:340px"><button class="btn g s" id="vs-mdl">Download</button><button class="btn g s" id="vs-mtest">Test model</button></div><div class="note" id="vs-mstat"></div>` +
      field('onnx_labels_path', 'Labels file (optional, one name per line; COCO names are built in)', 'text', { browse: 'labels' }) +
      field('onnx_input_size', 'Model input size', 'number', { min: 128, max: 1920, step: 32 }) +
      field('onnx_output_format', 'Model output format', 'select', { options: [['auto', 'Detect automatically'], ['yolov8', 'YOLOv8 / v11 style'], ['yolov5', 'YOLOv5 style'], ['end2end', 'End-to-end (NMS built in)']] }) +
      field('dnn_engine', 'OpenCV DNN engine', 'select', { options: [['auto', 'Automatic'], ['new', 'New OpenCV 5 engine'], ['classic', 'Classic engine']] }) +
      field('conf_threshold', 'Minimum confidence', 'range', { min: 0.05, max: 0.95, step: 0.05 }) + field('nms_threshold', 'Overlap filter (NMS)', 'range', { min: 0.1, max: 0.9, step: 0.05 }))}
      ${sec('Motion, change and text', '', field('motion_sensitivity', 'Motion sensitivity', 'range', { min: 1, max: 100, step: 1 }) + field('motion_min_area', 'Smallest movement to notice (pixels)', 'number', { min: 50, max: 50000, step: 50 }) +
      field('change_threshold', 'How much must change to count as \u201cchanged\u201d (fraction of the picture)', 'range', { min: 0.002, max: 0.1, step: 0.002 }) + field('analysis_max_side', 'Analysis size (longer side, pixels \u2013 smaller is faster)', 'number', { min: 320, max: 2560, step: 40 }) +
      field('preview_fps', 'Live preview speed (frames per second)', 'number', { min: 1, max: 15 }) +
      field('ocr_language', 'OCR language code (eng, sin, tam, fra ...)', 'text') + field('tesseract_path', 'Path to tesseract.exe (leave empty to find it automatically)', 'text', { browse: 'tesseract' }))}
      ${sec('Agent', 'The agent plans, acts, then checks the screen. Say \u201cagent: open my chemistry notes\u201d or \u201copen X and make sure it opened\u201d, or use the Vision page.',
      field('agent_enabled', 'Turn the vision agent on', 'bool') + field('agent_auto_claim', 'Also use it for \u201copen my ... notes / file\u201d requests', 'bool') +
      field('agent_use_gemini_planner', 'Let Gemini plan and re-plan (needs your Gemini key; otherwise built-in rules are used)', 'bool') + field('agent_use_gemini_verifier', 'Ask Gemini for a second opinion when the screen check is uncertain', 'bool') +
      field('agent_max_steps', 'Most steps in one plan', 'number', { min: 1, max: 20 }) + field('agent_max_replans', 'Most re-tries per step', 'number', { min: 0, max: 5 }))}
      ${sec('Problem solver', 'Sees an error on screen, tells you what it would do, asks, fixes it and checks. It never acts without your yes (only reading and web searches run by themselves).',
      field('agentic_enabled', 'Turn the problem solver on', 'bool') + field('agentic_use_gemini', 'Let Gemini double-check borderline detections', 'bool') +
      field('agentic_max_attempts', 'Most different fixes for one problem', 'number', { min: 1, max: 5 }) + field('agentic_settle_seconds', 'Seconds to keep looking after a fix', 'number', { min: 0, max: 15 }) +
      field('agentic_watch_interval', 'Seconds between checks while watching', 'number', { min: 2, max: 60 }))}
      ${sec('Safety and human control', 'Green = runs automatically (open an app, search, read). Yellow = FRIDAY asks first. Red = blocked, or explicit confirmation.',
      field('safety_confirm_yellow', 'Ask before yellow (confirm-level) actions', 'bool') +
      field('safety_restricted_policy', 'Red (restricted) actions', 'select', { options: [['block', 'Always block them'], ['typed_confirm', 'Ask me to confirm explicitly']] }) +
      field('safety_confirm_timeout', 'Wait for my answer for (seconds)', 'number', { min: 10, max: 600 }))}
      ${sec('Cloud (AWS Graviton / COOL) \u2013 optional', 'Run the vision engine on your own AWS Graviton server. Off by default. See cloud/deploy_graviton.md for the 10-minute setup.',
      field('cloud_enabled', 'Use my cloud server for vision', 'bool') + field('cloud_url', 'Server address', 'text', { ph: 'https://your-server:8443' }) +
      `<label class="f">Access token</label><div class="row"><input type="password" id="vs-tok" placeholder="${r.secrets && r.secrets.cloud_token ? 'Token saved \u2013 paste a new one to replace it' : 'Paste the FRIDAY_CLOUD_TOKEN of your server'}" autocomplete="off" spellcheck="false" style="min-width:340px"><button class="btn s" id="vs-toksave">Save token</button><button class="btn g s" id="vs-tokdel">Remove token</button></div><div class="note" id="vs-tokstat">${r.secrets && r.secrets.cloud_token ? '\u2713 Token stored in Windows secure storage.' : 'No token saved.'}</div>` +
      field('cloud_fallback_local', 'If the server is unreachable, use this PC instead', 'bool') + field('cloud_timeout', 'Server timeout (seconds)', 'number', { min: 3, max: 120 }) +
      `<div class="row" style="margin-top:10px"><button class="btn g s" id="vs-ctest">Test connection</button><button class="btn g s" id="vs-ccmp">Compare local vs cloud speed</button></div><div class="note" id="vs-cstat"></div>`)}
      ${sec('Data', '', `<div class="row"><button class="btn g s" id="vs-open">Open vision folder (reports, models)</button><button class="btn g s" id="vs-reset">Reset Vision settings</button></div><p class="note">Stored in: ${E(r.data_dir || '')}</p>`)}`;
    const saved = root.querySelector('#vs-saved');
    const flash = t => { saved.textContent = t; clearTimeout(flash.h); flash.h = setTimeout(() => saved.textContent = '', 2200); };
    const save = async (key, val) => { const x = await call('config_set', { changes: { [key]: val } }, 20000); if (x && x.ok) { cfg = x.config; flash('\u2713 Saved'); } else flash('Could not save: ' + ((x && x.error) || '')); };
    root.querySelectorAll('[data-vk]').forEach(el => {
      const key = el.dataset.vk;
      const read = () => el.type === 'checkbox' ? el.checked : el.type === 'number' || el.type === 'range' ? Number(el.value) : el.value.trim();
      if (el.type === 'range') el.oninput = () => { const o = root.querySelector(`[data-vo="${key}"]`); if (o) o.textContent = el.value; };
      el.onchange = () => save(key, read());
    });
    root.querySelectorAll('[data-browse]').forEach(btn => btn.onclick = async () => { const p = B && B.pickVisionFile ? await B.pickVisionFile(btn.dataset.browse) : ''; if (p) { const inp = root.querySelector(`[data-vk="${btn.dataset.for}"]`); inp.value = p; save(btn.dataset.for, p); } });
    const inst = root.querySelector('#vs-inst');
    if (inst) inst.onclick = async () => { const st = root.querySelector('#vs-inststat'); inst.disabled = true; st.textContent = 'Installing (a minute or two)...'; const x = await call('install_packages', {}, 1000000); inst.disabled = false; st.textContent = x.ok ? '\u2713 ' + x.message : '\u2715 ' + x.error; };
    root.querySelector('#vs-mdl').onclick = async () => { const u = root.querySelector('#vs-murl').value.trim(); const st = root.querySelector('#vs-mstat'); if (!u) { st.textContent = 'Paste an https:// link first.'; return; } st.textContent = 'Downloading...'; const x = await call('model_download', { url: u }, 900000); if (x.ok) { root.querySelector('[data-vk="onnx_model_path"]').value = x.path; st.textContent = '\u2713 Downloaded ' + x.size_mb + ' MB and selected it.'; } else st.textContent = '\u2715 ' + x.error; };
    root.querySelector('#vs-mtest').onclick = async () => { const st = root.querySelector('#vs-mstat'); st.textContent = 'Testing...'; const x = await call('model_test', {}, 120000); st.textContent = x.ok ? '\u2713 Model loaded and ran in ' + x.ms + ' ms.' : '\u2715 ' + (x.error || 'The model could not be loaded. Check the path and that it is a detector in ONNX format.'); };
    const tokstat = root.querySelector('#vs-tokstat');
    root.querySelector('#vs-toksave').onclick = async () => { const v = root.querySelector('#vs-tok').value.trim(); if (!v) { tokstat.textContent = 'Paste the token first.'; return; } const x = await B.setVisionSecret('cloud_token', v); if (x.ok) { root.querySelector('#vs-tok').value = ''; tokstat.textContent = '\u2713 Token stored in Windows secure storage.'; } else tokstat.textContent = '\u2715 ' + x.error; };
    root.querySelector('#vs-tokdel').onclick = async () => { const x = await B.setVisionSecret('cloud_token', ''); tokstat.textContent = x.ok ? 'Token removed.' : '\u2715 ' + x.error; };
    root.querySelector('#vs-ctest').onclick = async () => { const st = root.querySelector('#vs-cstat'); st.textContent = 'Testing...'; const x = await call('cloud_test', {}, 30000); if (x.ok) { const e = (x.server || {}).environment || {}; st.textContent = `\u2713 Connected in ${x.ms} ms \u2013 OpenCV ${e.opencv_version} on ${e.machine}${e.cool && e.cool.active ? ' (COOL active)' : ' (COOL not detected)'}`; } else st.textContent = '\u2715 ' + x.error; };
    root.querySelector('#vs-ccmp').onclick = async () => { const st = root.querySelector('#vs-cstat'); st.textContent = 'Comparing (about 30 seconds)...'; const x = await call('cloud_compare', {}, 400000); const c = x.result || {}; if (c.cloud) { const sp = Object.entries(c.speedup || {}).map(([k, v]) => `${k}: ${v}\u00d7`).join(' \u00b7 '); st.textContent = 'Cloud vs this PC (higher = cloud faster): ' + sp; } else st.textContent = '\u2715 ' + (c.error || x.error || 'No result.'); };
    root.querySelector('#vs-open').onclick = () => B && B.openVisionFolder && B.openVisionFolder('');
    root.querySelector('#vs-reset').onclick = async () => { if (!confirm('Reset all Vision settings to their defaults? (Your cloud token is kept.)')) return; await call('config_reset'); FS.wire(box); };
  };

  window.FridayVision = { call, state: VS, onEvent: f => listeners.push(f) };
  window.FridayVisionSettings = FS;
  window.addEventListener('DOMContentLoaded', indicators);
  setTimeout(indicators, 400);
})();
