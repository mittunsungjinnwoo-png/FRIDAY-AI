# FRIDAY V2.2.8 - speak every reply aloud + mic/status kept in sync (only this changed)

## Problem
- While FRIDAY was speaking, the microphone loop kept running (typed / widget / UI replies are spoken from a
  different thread than the mic loop), so it picked up her own voice and the status flipped to "Recognizing...".
- If two replies were queued, the first one to finish cleared the "speaking" flag and sent SPEAK_END while the
  second was still talking, so the status / mic indicator / reactor were wrong.

## Fix
- friday_backend.py
  - speak(): speaking state is now a depth counter. ACTION::SPEAK_START is sent when the first queued reply begins,
    ACTION::SPEAK_END only after the LAST one finishes.
  - _capture_until_silence(): while FRIDAY is speaking (plus a 0.45 s echo tail) the mic is deaf: audio is discarded
    and the capture state reset, so her own voice can never start a capture or trigger Recognizing.
- index.html: "Recognizing..." / "Thinking..." are ignored while speaking; the mic indicator is off while she speaks
  and comes back on at SPEAK_END with "Listening...".
- widget.html: same rule for the widget's reactor/mode.
Replies still reach the chat and are spoken in the same step (the backend prints the chat line, then speaks it).
Nothing else (voice recognition settings, finance, notes, WhatsApp, UI layout, widget mode) was touched.
