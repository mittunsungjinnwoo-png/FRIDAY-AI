"""FRIDAY V2.3.0 vision regression test.  Run:  python FRIDAY_TEST_V230_VISION.py   (no camera, no key, no network needed)"""
import os, sys, tempfile, time
os.environ["FRIDAY_VISION_DATA"] = tempfile.mkdtemp(prefix="friday_vision_test_")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import friday_vision_config as cfg, friday_vision_engine as ve, friday_action_safety as safety, friday_vision_agent as va, friday_eval_metrics as em
import numpy as np, cv2

PASS = FAIL = 0
def check(name, cond, extra=""):
    global PASS, FAIL
    PASS += bool(cond); FAIL += (not cond)
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))

check("OpenCV importable", ve.available(), ve.cv_version())
img, truth = ve.synthetic_scene(seed=7)
st = ve.analyze_frame(img, "image", publish_state=False, mode="contours")
check("detects all 5 objects", len(st["objects"]) == 5, st["summary"][:70])
check("confidence scores present", all(0 < o["conf"] <= 1 for o in st["objects"]) and 0 < st["confidence"] <= 1)
check("spatial relations produced", len(st["relations"]) > 0)
md = ve.MotionDetector(); r = None
for i in range(12):
    f = img.copy()
    if i >= 5: cv2.rectangle(f, (100 + (i - 5) * 60, 300), (220 + (i - 5) * 60, 420), (255, 255, 255), -1)
    r = md.update(f)
check("motion detected, direction right", r["motion"] and r["direction"] == "right")
b = img.copy(); cv2.rectangle(b, (900, 100), (1200, 400), (200, 50, 50), -1)
check("visual change detected", ve.compare_frames(img, b)["changed"])
check("no false change on identical frames", not ve.compare_frames(img, img.copy())["changed"])
tr = ve.ObjectTracker()
for i in range(8): out = tr.update([{"label": "red object", "conf": .9, "bbox": [100 + i * 30, 200, 80, 80]}], (1280, 720), t=i * .5)
check("tracker follows a moving object", out and out[0]["moving"] and out[0]["id"] == 1)
check("error text recognised", ve.detect_errors("Error: file not found")["has_error"])
c = safety.classify
check("safety green", c({"tool": "open_app", "args": {"name": "notepad"}})["level"] == "safe")
check("safety yellow", c({"tool": "type_text", "args": {"text": "hi"}})["level"] == "confirm")
check("safety red", c({"tool": "delete_file", "args": {}})["level"] == "restricted")
check("red blocked by default", not safety.decide({"tool": "delete_file", "text": "delete x"}, simulate=True)["allowed"])
sim = va.SimDesktop(); res = va.run_goal("open my chemistry notes", sim, simulate=True, record=False)
check("agent completes and verifies a task", res["ok"] and sim.has_file_open("chemistry notes"))
sim = va.SimDesktop(flaky={"open_app:notepad": 1}); res = va.run_goal("open notepad", sim, simulate=True, record=False)
check("agent notices a silent failure and recovers", res["ok"] and res["replans"] >= 1 and sim.has_app("notepad"))
sim = va.SimDesktop(); res = va.run_goal("open photoshop", sim, simulate=True, record=False)
check("agent reports an impossible task honestly", (not res["ok"]) and res["status"] == "failed")
s = va.run_simulation_suite()
check("simulation: all achievable tasks verified", s["tasks_ok"] == s["achievable"], f"{s['tasks_ok']}/{s['achievable']}")
check("simulation: every unsafe request stopped", s["unsafe_blocked"] == s["unsafe_total"])
import friday_vision_hub as hub
claimed = [hub.handle_command(x) for x in ("open notepad", "what's on my screen", "who is your creator", "how much did I save")]
check("hub ignores ordinary commands", claimed == [None] * 4)
print(f"\n{PASS} passed, {FAIL} failed")
sys.exit(1 if FAIL else 0)
