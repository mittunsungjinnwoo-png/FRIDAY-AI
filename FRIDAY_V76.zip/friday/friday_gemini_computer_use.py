"""Gemini Computer Use adapter for FRIDAY.

Gemini is used as a visual action planner; FRIDAY remains the execution and
permission layer. Coordinates are normalized 0..999 by Gemini and converted
locally to the real Windows screen. Prompt-injection detection is enabled.
"""
from __future__ import annotations
import base64, json, os, time
from typing import Any

MODEL=os.getenv("FRIDAY_COMPUTER_USE_MODEL", os.getenv("FRIDAY_GEMINI_MODEL", "gemini-3.1-flash-lite"))


def available():
    try:
        from google import genai
        c=genai.Client(api_key=os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))
        return hasattr(c,"interactions")
    except Exception:
        return False


def _client():
    from google import genai
    return genai.Client(api_key=os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))


def _dump(x):
    if hasattr(x,"model_dump"):
        try:return x.model_dump()
        except Exception:pass
    return x


def _steps(interaction):
    steps=getattr(interaction,"steps",None)
    if steps is None:
        d=_dump(interaction); steps=d.get("steps",[]) if isinstance(d,dict) else []
    return steps or []


def _field(obj,key,default=None):
    if isinstance(obj,dict): return obj.get(key,default)
    return getattr(obj,key,default)


def _args(fc):
    a=_field(fc,"arguments",{})
    return _dump(a) if not isinstance(a,dict) else a


def _is_function_call(step): return _field(step,"type","")=="function_call"


def _model_text(interaction):
    out=[]
    for step in _steps(interaction):
        if _field(step,"type","")!="model_output": continue
        content=_field(step,"content",[]) or []
        for block in content:
            if _field(block,"type","")=="text": out.append(str(_field(block,"text","")))
    return " ".join(x for x in out if x).strip()


def _safety_blocked(step):
    sd=_field(step,"safety_decision",None)
    if sd is None:return False,None
    sd=_dump(sd)
    decision=(sd.get("decision") if isinstance(sd,dict) else str(sd)).lower()
    if "block" in decision or "confirmation" in decision:
        return True,decision
    return False,decision


def _screen_png():
    import mss
    from PIL import Image
    with mss.mss() as sct:
        mon=sct.monitors[0]
        shot=sct.grab(mon)
        return Image.frombytes("RGB",shot.size,shot.rgb),shot.width,shot.height


def _norm_xy(args,w,h):
    return int(max(0,min(999,args.get("x",0)))/999*w), int(max(0,min(999,args.get("y",0)))/999*h)


def _execute(fname,args,w,h):
    import pyautogui
    x,y=_norm_xy(args,w,h) if "x" in args and "y" in args else (None,None)
    try:
        from friday_truth_verifier import snapshot, compare
    except Exception:
        snapshot=compare=None

    before=snapshot() if snapshot else None
    try:
        if fname in ("click","click_at"):
            pyautogui.click(x,y)
        elif fname=="double_click": pyautogui.doubleClick(x,y)
        elif fname=="triple_click": pyautogui.click(x,y,clicks=3,interval=.08)
        elif fname=="right_click": pyautogui.rightClick(x,y)
        elif fname=="middle_click": pyautogui.middleClick(x,y)
        elif fname=="move": pyautogui.moveTo(x,y,duration=.12)
        elif fname=="mouse_down": pyautogui.moveTo(x,y); pyautogui.mouseDown()
        elif fname=="mouse_up": pyautogui.moveTo(x,y); pyautogui.mouseUp()
        elif fname=="drag_and_drop":
            sx,sy=_norm_xy({"x":args.get("start_x",0),"y":args.get("start_y",0)},w,h); ex,ey=_norm_xy({"x":args.get("end_x",0),"y":args.get("end_y",0)},w,h)
            pyautogui.moveTo(sx,sy); pyautogui.dragTo(ex,ey,duration=.35)
        elif fname in ("type","type_text_at"):
            if x is not None: pyautogui.click(x,y)
            if args.get("clear_before_typing",True): pyautogui.hotkey("ctrl","a")
            text=str(args.get("text", "")); pyautogui.write(text,interval=.002)
            if args.get("press_enter",False): pyautogui.press("enter")
        elif fname=="press_key": pyautogui.press(str(args.get("key","enter")))
        elif fname=="key_down": pyautogui.keyDown(str(args.get("key","shift")))
        elif fname=="key_up": pyautogui.keyUp(str(args.get("key","shift")))
        elif fname=="hotkey": pyautogui.hotkey(*[str(k).lower() for k in args.get("keys",[])])
        elif fname=="scroll":
            if x is not None: pyautogui.moveTo(x,y)
            direction=str(args.get("direction","down")).lower(); mag=int(args.get("magnitude_in_pixels",300)); clicks=max(1,mag//100)
            pyautogui.scroll(clicks if direction=="up" else -clicks)
        elif fname=="wait": time.sleep(min(10,max(0,int(args.get("seconds",1)))))
        elif fname=="take_screenshot": pass
        else: return {"ok":False,"executed":False,"error":"unsupported_computer_use_action","action":fname}
    except Exception as exc:
        return {"ok":False,"executed":False,"error":str(exc),"action":fname}

    if fname in ("wait","take_screenshot","move"):
        # These are special: waiting/screenshot are observations; move is
        # verified directly by the cursor position.
        if fname=="move":
            pos=pyautogui.position(); verified=(x is not None and int(pos.x)==int(x) and int(pos.y)==int(y))
        else: verified=True
        return {"ok":True,"executed":True,"action":fname,"verified":verified}

    after=snapshot() if snapshot else None
    evidence=compare(before,after,expected_text=str(args.get("text","")) if fname in ("type","type_text_at") else None) if before and after and compare else {}
    # A low-level call is never sufficient. Require at least one independent
    # observable signal: visual change, UIA tree change, OCR match, or cursor/window change.
    verified=bool(evidence.get("verified") or evidence.get("cursor_changed") or evidence.get("window_match"))
    return {"ok":verified,"executed":True,"action":fname,"verified":verified,"evidence":evidence,
            **({} if verified else {"error":"action_executed_but_post_state_not_verified"})}


def _function_responses(results, img, w, h):
    import io
    b=io.BytesIO(); img.save(b,format="PNG")
    enc=base64.b64encode(b.getvalue()).decode("ascii")
    responses=[]
    for fname,call_id,result in results:
        responses.append({"type":"function_result","name":fname,"call_id":call_id,
            "result":[{"type":"text","text":json.dumps({"screen_width":w,"screen_height":h,**result},ensure_ascii=False)},
                       {"type":"image","data":enc,"mime_type":"image/png"}]})
    return responses


def run(task: str, max_steps: int = 8):
    if not (os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")):
        return {"ok":False,"error":"GEMINI_API_KEY_not_configured"}
    try:
        client=_client()
        if not hasattr(client,"interactions"):
            return {"ok":False,"error":"google-genai_2.7.0_or_newer_required"}
        img,w,h=_screen_png()
        png=__import__('io').BytesIO(); img.save(png,format="PNG")
        first_input=[{"type":"text","text":task},{"type":"image","data":base64.b64encode(png.getvalue()).decode("ascii"),"mime_type":"image/png"}]
        tools=[{"type":"computer_use","environment":"desktop","enable_prompt_injection_detection":True}]
        interaction=client.interactions.create(model=MODEL,input=first_input,tools=tools)
        verified_actions=0
        executed_actions=0
        for step_no in range(max_steps):
            calls=[]
            for step in _steps(interaction):
                if not _is_function_call(step): continue
                blocked,decision=_safety_blocked(step)
                if blocked:
                    return {"ok":False,"confirmation_required":True,"safety_decision":decision,"step":step_no}
                fname=str(_field(step,"name","")); args=_args(step); call_id=str(_field(step,"id","") or _field(step,"call_id",""))
                calls.append((fname,call_id,args))
            if not calls:
                text=_model_text(interaction)
                # A computer-use task that never executed an action can still
                # be an observation request. For action tasks, however, the
                # model's final sentence is not evidence of completion.
                observation_only=bool(__import__('re').search(r"\b(what(?:'s| is) on (?:my|the) screen|describe|read|inspect|look at)\b", task, __import__('re').I))
                ok=bool(observation_only or verified_actions>0)
                return {"ok":ok,"backend":"gemini_computer_use","text":text,"steps":step_no,"executed_actions":executed_actions,"verified_actions":verified_actions,
                        **({} if ok else {"error":"model_reported_completion_without_verified_action"})}
            results=[]
            for fname,call_id,args in calls:
                try: result=_execute(fname,args,w,h)
                except Exception as e: result={"ok":False,"error":str(e)}
                results.append((fname,call_id,result))
                if result.get("executed"): executed_actions+=1
                if result.get("verified"): verified_actions+=1
                if not result.get("ok"):
                    return {"ok":False,"backend":"gemini_computer_use","error":result.get("error"),"action":fname,"executed_actions":executed_actions,"verified_actions":verified_actions}
                time.sleep(.35)
            img,w,h=_screen_png()
            interaction=client.interactions.create(model=MODEL,previous_interaction_id=interaction.id,input=_function_responses(results,img,w,h),tools=tools)
        return {"ok":False,"backend":"gemini_computer_use","error":"computer_use_step_limit_reached","max_steps":max_steps}
    except Exception as e:
        return {"ok":False,"backend":"gemini_computer_use","error":str(e)}
