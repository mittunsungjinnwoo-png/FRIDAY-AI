; FRIDAY installer/uninstaller extras (electron-builder custom NSIS include)

; Make sure FRIDAY and its private Python engine are fully stopped before uninstalling,
; so the uninstaller is never blocked by a running copy (including one hidden in widget mode).
; Add an "Uninstall FRIDAY 6.0" shortcut to the Start menu next to the FRIDAY shortcut.
!macro customInstall
  CreateShortCut "$SMPROGRAMS\Uninstall FRIDAY 6.0.lnk" "$INSTDIR\Uninstall FRIDAY.exe"
!macroend

!macro customUnInit
  nsExec::Exec 'taskkill /F /T /IM "${APP_EXECUTABLE_FILENAME}"'
  Pop $0
!macroend

; Offer to remove saved data too. Default is to KEEP it (same as before); skipped on upgrades.
!macro customUnInstall
  Delete "$SMPROGRAMS\Uninstall FRIDAY 6.0.lnk"
  ${ifNot} ${isUpdated}
    MessageBox MB_YESNO|MB_ICONQUESTION "Also delete FRIDAY 6.0's saved data (memory, finance data, API key and the private Python runtime)?$\r$\n$\r$\nChoose No to keep it for a future reinstall." /SD IDNO IDNO friday_keep_data
      RMDir /r "$APPDATA\friday-ui"
      RMDir /r "$APPDATA\FRIDAY"
      RMDir /r "$APPDATA\FRIDAY 2.0"
    friday_keep_data:
  ${endIf}
!macroend
