# FRIDAY V7.6 - live preview on, and the Vision readout matches what she actually sees

Built on V7.5. Voice, listening, widget, finance/food, the problem solver and every other feature are untouched.

## Live preview
- The live picture is now ON by default for the camera and for screen vision, however they are started (button, voice "turn on the camera", Camera card). Before, it only appeared if you ticked a box first, and voice never started it.
- It is sharper (640 px, was 400) and updates only the picture, so the page no longer flickers or loses its scroll position every frame.
- A "LIVE" badge on the picture shows how many boxes are drawn and how old the detection behind them is.
- Untick "Show live preview with boxes" to hide it.

## What I see now matches the picture
- Boxes come only from the live session's own analysis of that same source and only when under 1.5 s old; a stale or other-source result is never drawn on the live picture. Boxes are scaled from the size the detector worked on, so they sit on the right pixels (checked: 4/4 detections on the real shapes of a test scene).
- Each box shows its label and confidence.
- The readout is stamped with the source, resolution, "live" or "last look" and how long ago ("just now", "12 s ago").
- "Look at screen / Look through camera / Analyse a picture" now show the exact picture that was analysed, with the detections drawn on it, next to the text.

## Files
Changed: friday_vision_engine.py, friday_vision_hub.py, friday_vision_ui.js. Tested headlessly with a simulated screen; not run on real Windows/webcam.
