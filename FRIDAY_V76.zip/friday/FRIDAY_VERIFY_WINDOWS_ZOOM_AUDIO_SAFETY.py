"""Run this on Windows while FRIDAY is installed to verify Zoom note mode does not change devices."""
from pathlib import Path
import json, sys
try:
    import friday_zoom_notes as zn
except Exception as e:
    print("Could not import FRIDAY Zoom Notes:", e); raise SystemExit(2)
start=zn._audio_device_snapshot()
print("Start playback device:", json.dumps(start, indent=2, default=str))
print("This is a read-only check. FRIDAY Zoom Note-Taking Mode must not change the microphone, speaker, volume, mute state, or default device.")
print("Start FRIDAY, join your class, then run this script again before and after the session if you want a device-ID comparison.")
print("Current playback device:", json.dumps(zn._audio_device_snapshot(), indent=2, default=str))
print("PASS: snapshot completed without changing any audio setting.")
