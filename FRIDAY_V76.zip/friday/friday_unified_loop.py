"""
FRIDAY UNIFIED COGNITIVE LOOP
------------------------------
Implements the research doc's "14. The final 9.5+ loop" -- meant to
"eventually become the heartbeat of your entire program":

    PERCEIVE -> UNDERSTAND -> PLAN -> EXECUTE -> OBSERVE -> VERIFY ->
        FAIL -> DIAGNOSE -> REPLAN --,
        SUCCESS -> UPDATE STATE ------+--> GOAL COMPLETE? -> NO -> PLAN
                                                            -> YES -> RESPOND

This is the single new optional entry point that wires together every
other new module in this set (state engine, perception, executive,
supervisor, verifier, memory layers, proactive monitor). It is a pure
ADDITION: nothing in your existing ~70 files is imported at module
load time, so importing this file can never fail, and calling
run_cycle() never touches any existing file's behaviour unless you
choose to register your existing agents with friday_supervisor
yourself (see INTEGRATION_GUIDE_UNIFIED_ARCHITECTURE.md).

Typical use once wired in:

    import friday_unified_loop as loop
    response = loop.run_cycle(command="Find the latest fusion energy news and make a document")
    print(response["summary"])

or, for a world event instead of a typed/spoken command:

    loop.run_cycle(event={"type": "download_complete", "description": "invoice.pdf"})
"""

from __future__ import annotations

import time
from typing import Any, Callable, Optional

import friday_state_engine as state
import friday_perception as perception
import friday_supervisor as supervisor
import friday_memory_layers as memory
import friday_proactive_monitor as proactive
import friday_task_graph as graph


def _try_resolve_reference(command: str) -> Optional[str]:
    """Best-effort, read-only use of your EXISTING friday_context.resolve,
    if that module happens to be importable, so 'do the same thing again'
    style follow-ups still work through the new loop. Never raises, never
    writes back to friday_context's own files -- it only reads a return
    value from it."""
    try:
        import friday_context  # existing module, used read-only if present
        result = friday_context.resolve(command)
        return result if isinstance(result, str) else None
    except Exception:
        return None


def run_cycle(
    *,
    command: Optional[str] = None,
    event: Optional[dict[str, Any]] = None,
    ask_user: Optional[Callable[[str], bool]] = None,
    describe_screen: bool = False,
    plan_override: Optional[list[dict[str, Any]]] = None,
    fast: bool = True,
) -> dict[str, Any]:
    """Run exactly one PERCEIVE->...->RESPOND cycle for either a user
    `command` or a proactive `event` (pass exactly one). Returns:

        {
            "success": bool,
            "summary": str,           # ready to speak/display
            "confidence": float,
            "goal_id": str | None,
            "task_results": [...],
            "perception": {...},
        }
    """
    if command is None and event is None:
        return {"success": False, "summary": "Nothing to do: no command or event was given.",
                 "confidence": 0.0, "goal_id": None, "task_results": [], "perception": None}

    # Standalone use of this loop gets the same real agent registry as the
    # backend path, without touching any voice/listening/recognition code.
    try:
        import friday_unified_gateway as gateway
        gateway.register_default_agents()
    except Exception:
        pass

    # 1. PERCEIVE
    # Fast path is the default: passive screen/OCR capture can easily add hundreds of
    # milliseconds or several seconds on an 8 GB Windows laptop. Screen perception is pulled
    # only when the request actually needs it. Voice/listening/recognition are untouched.
    needs_screen = bool(describe_screen or (command and __import__("re").search(r"\b(screen|screenshot|look at|what am i seeing|image|picture)\b", command, __import__("re").I)))
    perceived = perception.snapshot_all(
        describe_screen=describe_screen,
        include_screen=(needs_screen or not fast),
        include_system=(not fast),
    )
    state.replace("screen", perceived.get("screen", {}))
    state.update("environment", last_perceived_system=perceived.get("system", {}), last_cycle_ts=time.time())

    # 2. UNDERSTAND (+ PLAN + EXECUTE + OBSERVE + VERIFY, for events)
    if event is not None:
        report = proactive.emit(event, ask_user=ask_user)
        if not report.get("acted"):
            return {"success": False, "summary": f"No action taken: {report.get('reason')}",
                     "confidence": 0.0, "goal_id": None, "task_results": [], "perception": perceived}
        result = report["result"]
    else:
        resolved = _try_resolve_reference(command)
        goal_text = resolved if resolved else command
        state.update("conversation", last_command=command, resolved_reference=resolved, updated_at=time.time())

        # 3-6. PLAN -> EXECUTE -> OBSERVE -> VERIFY (with internal
        # DIAGNOSE/REPLAN/RETRY handled inside friday_executive).
        result = supervisor.run_goal(goal_text, plan_override=plan_override, ask_user=ask_user, proactive=False)

    # 7. UPDATE STATE / MEMORY on success, regardless of path taken above.
    success = result.get("status") == "COMPLETED"
    if success:
        memory.record(
            "episodic",
            f"Goal '{result.get('goal_id')}' completed: {result.get('explanation', '')}",
            confidence=result.get("confidence", 0.8),
            source="unified_loop",
        )
    state.update("goals", last_goal_id=result.get("goal_id"), last_goal_status=result.get("status"))

    # 8. GOAL COMPLETE? -> RESPOND. (Replanning/retry already happened
    # inside friday_executive.execute_goal before this function ever
    # gets control back, so by this point the loop's job is just to
    # produce the final spoken/displayed response.)
    return {
        "success": success,
        "summary": result.get("explanation", "No explanation was produced."),
        "confidence": result.get("confidence", 0.0),
        "goal_id": result.get("goal_id"),
        "task_results": result.get("task_results", []),
        "perception": perceived,
    }


def health() -> dict[str, Any]:
    """Quick self-report, matching the health()-style functions already
    present elsewhere in this codebase (friday_proactive_reasoning.health,
    friday_cognitive_architecture.health)."""
    return {
        "state_updated_at": state.get().get("updated_at"),
        "registered_agents": supervisor.list_agents(),
        "memory_layer_sizes": memory.layer_stats(),
        "open_goals": graph.open_goal_count(),
    }
