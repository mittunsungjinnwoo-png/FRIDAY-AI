from pathlib import Path
p = Path(__file__).with_name("friday_backend.py")
s = p.read_text(encoding="utf-8")
assert "def _run_edge_tts" in s  # compatibility code may remain, but is not used by speak()
speak = s[s.index("def speak("): ]
assert "_run_edge_tts(" not in speak.split("def ",1)[0]
assert "result = _run_powershell_tts" in speak
assert "_capture_until_silence" in s
assert "FRIDAY_VAD_PAUSE" in s
assert "FRIDAY_MAX_SPEECH_SECONDS" in s
print("Current voice routing compatibility check passed")
