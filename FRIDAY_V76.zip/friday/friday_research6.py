"""FRIDAY 6.0 research and knowledge acquisition (blueprint section 8).

Adds the discipline around the existing web-research pipeline: every source is graded (primary / official / academic / news /
community / unknown) with URL and publication date, claims are classified as established fact / estimate / speculation,
conflicting claims are compared instead of averaged, reports carry numbered citations, and a research notebook keeps
sources, claims, open questions and follow-up experiments per topic.  A search result is never treated as automatically true.
"""
from __future__ import annotations

import re
import time
from typing import Dict, List, Optional
from urllib.parse import urlparse

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS rs_topics(id INTEGER PRIMARY KEY, name TEXT UNIQUE, created REAL, watch INTEGER DEFAULT 0, last_check REAL);
CREATE TABLE IF NOT EXISTS rs_sources(id INTEGER PRIMARY KEY, topic INTEGER, url TEXT, title TEXT, pub TEXT, grade TEXT, score REAL, retrieved REAL, UNIQUE(topic,url));
CREATE TABLE IF NOT EXISTS rs_claims(id INTEGER PRIMARY KEY, topic INTEGER, text TEXT, kind TEXT, source INTEGER, confidence REAL, ts REAL);
CREATE TABLE IF NOT EXISTS rs_questions(id INTEGER PRIMARY KEY, topic INTEGER, text TEXT, open INTEGER DEFAULT 1, ts REAL);
""")

_PRIMARY = ("arxiv.org", "doi.org", "nature.com", "science.org", "sciencedirect.com", "springer.com", "ieee.org", "acm.org", "nih.gov", "who.int", "nasa.gov",
            "pubmed.ncbi.nlm.nih.gov", "jstor.org", "plos.org", "cell.com", "thelancet.com", "nejm.org", "cambridge.org", "oup.com", "iso.org", "w3.org", "ietf.org", "docs.python.org")
_NEWS = ("reuters.com", "apnews.com", "bbc.", "nytimes.com", "theguardian.com", "wsj.com", "ft.com", "economist.com", "bloomberg.com", "aljazeera.com")
_COMMUNITY = ("reddit.com", "quora.com", "medium.com", "stackoverflow.com", "stackexchange.com", "blogspot.", "wordpress.com", "tumblr.com", "facebook.com", "x.com", "twitter.com", "tiktok.com", "youtube.com", "pinterest.")
_REFERENCE = ("wikipedia.org", "britannica.com")


def grade_source(url: str, text: str = "") -> Dict:
    host = (urlparse(url).netloc or url).lower().replace("www.", "")
    grade, score = "unknown", 0.4
    if host.endswith((".gov", ".gov.uk", ".gov.lk", ".mil")) or ".gov." in host:
        grade, score = "official", 0.9
    elif host.endswith((".edu", ".ac.uk", ".ac.lk")) or ".edu." in host or ".ac." in host:
        grade, score = "academic", 0.85
    elif any(host == d or host.endswith("." + d) or d in host for d in _PRIMARY):
        grade, score = "primary", 0.92
    elif any(d in host for d in _NEWS):
        grade, score = "news", 0.7
    elif any(d in host for d in _REFERENCE):
        grade, score = "reference", 0.62
    elif any(d in host for d in _COMMUNITY):
        grade, score = "community", 0.35
    elif host.endswith(".org"):
        grade, score = "organisation", 0.55
    if url.startswith("http://"):
        score -= 0.05
    if text:
        if re.search(r"\b(sponsored|affiliate|buy now|limited offer|click here|you won'?t believe)\b", text, re.I):
            score -= 0.15
        if re.search(r"\b(doi:|references|et al\.|peer[- ]reviewed|methodology)\b", text, re.I):
            score += 0.05
    return {"host": host, "grade": grade, "score": round(max(0.05, min(0.99, score)), 2)}


_PUB = re.compile(r"\b(20\d\d|19\d\d)[-/](\d{1,2})[-/](\d{1,2})\b|\b(?:Published|Updated|Posted|Date)[:\s]+([A-Z][a-z]{2,8} \d{1,2},? \d{4})", re.I)


def find_pub_date(text: str) -> str:
    m = _PUB.search(text or "")
    if not m:
        return ""
    return m.group(0).split(":")[-1].strip() if m.group(4) else f"{m.group(1)}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"


_SPEC = re.compile(r"\b(might|may|could|possibly|perhaps|reportedly|rumou?red?|allegedly|speculat\w+|it is thought|some believe|unconfirmed|likely to|expected to|predicted?)\b", re.I)
_EST = re.compile(r"\b(about|around|approximately|roughly|estimated?|an estimate|nearly|almost|~|\bc\.\s?\d|forecast|projected|up to)\b", re.I)


def classify_claim(text: str) -> str:
    """established fact / estimate / speculation - by wording, to be confirmed by sources, never a guarantee of truth."""
    if _SPEC.search(text):
        return "speculation"
    if _EST.search(text) or re.search(r"\d[\d,\.]*\s*(?:%|percent|million|billion|thousand)", text, re.I):
        return "estimate"
    return "fact"


def topic_id(name: str) -> int:
    name = name.strip().lower()[:80]
    r = C.q("SELECT id FROM rs_topics WHERE name=?", (name,))
    return r[0]["id"] if r else C.x("INSERT INTO rs_topics(name,created) VALUES(?,?)", (name, C.now()))


def add_source(topic: str, url: str, title: str = "", text: str = "") -> Dict:
    g = grade_source(url, text)
    tid = topic_id(topic)
    C.x("INSERT OR REPLACE INTO rs_sources(topic,url,title,pub,grade,score,retrieved) VALUES(?,?,?,?,?,?,?)", (tid, url, C.clip(title, 120), find_pub_date(text), g["grade"], g["score"], C.now()))
    return {"url": url, **g, "pub": find_pub_date(text)}


def add_claim(topic: str, text: str, source_url: str = "", confidence: Optional[float] = None) -> Dict:
    tid = topic_id(topic)
    sid = None
    if source_url:
        r = C.q("SELECT id,score FROM rs_sources WHERE topic=? AND url=?", (tid, source_url))
        sid = r[0]["id"] if r else None
        confidence = confidence if confidence is not None else (r[0]["score"] if r else 0.4)
    kind = classify_claim(text)
    cid = C.x("INSERT INTO rs_claims(topic,text,kind,source,confidence,ts) VALUES(?,?,?,?,?,?)", (tid, C.clip(text, 400), kind, sid, confidence if confidence is not None else 0.4, C.now()))
    return {"id": cid, "kind": kind}


def compare_claims(topic: str) -> List[Dict]:
    """Find claims about the same thing that disagree (different numbers, or one denies what another asserts), best-sourced first."""
    tid = topic_id(topic)
    rows = [dict(r) for r in C.q("SELECT c.*, s.url, s.grade, s.score FROM rs_claims c LEFT JOIN rs_sources s ON s.id=c.source WHERE c.topic=?", (tid,))]
    out = []
    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            a, b = rows[i], rows[j]
            if C.similarity(a["text"], b["text"]) < 0.35:
                continue
            na = re.findall(r"\d[\d,\.]*", a["text"]); nb = re.findall(r"\d[\d,\.]*", b["text"])
            neg = bool(re.search(r"\b(not|no|never|false|denied|refuted)\b", a["text"], re.I)) != bool(re.search(r"\b(not|no|never|false|denied|refuted)\b", b["text"], re.I))
            if (na and nb and set(na) != set(nb)) or neg:
                better = a if (a.get("score") or 0) >= (b.get("score") or 0) else b
                out.append({"a": a["text"], "b": b["text"], "prefer": better["text"], "why": f"better-graded source ({better.get('grade') or 'unknown'})"})
    return out


def add_question(topic: str, text: str):
    C.x("INSERT INTO rs_questions(topic,text,ts) VALUES(?,?,?)", (topic_id(topic), C.clip(text, 200), C.now()))


def open_questions(topic: str) -> List[str]:
    return [r["text"] for r in C.q("SELECT text FROM rs_questions WHERE topic=? AND open=1 ORDER BY ts", (topic_id(topic),))]


def report(topic: str) -> str:
    """A report in which every statement has a numbered citation with grade, date and URL; weak/conflicting points are flagged."""
    tid = topic_id(topic)
    srcs = [dict(r) for r in C.q("SELECT * FROM rs_sources WHERE topic=? ORDER BY score DESC", (tid,))]
    idx = {s["id"]: i + 1 for i, s in enumerate(srcs)}
    claims = [dict(r) for r in C.q("SELECT * FROM rs_claims WHERE topic=? ORDER BY confidence DESC", (tid,))]
    lines = [f"# Research report: {topic}", f"_Prepared {C.iso()} by FRIDAY {C.VERSION}. Claims are labelled fact / estimate / speculation; sources are graded, not assumed true._", "", "## Findings"]
    for k, title in (("fact", "Established (as stated by sources)"), ("estimate", "Estimates"), ("speculation", "Speculation - treat with caution")):
        sel = [c for c in claims if c["kind"] == k]
        if sel:
            lines.append(f"**{title}**")
            for c in sel:
                ref = f" [{idx[c['source']]}]" if c["source"] in idx else " [no source recorded]"
                lines.append(f"- {c['text']}{ref}")
            lines.append("")
    conf = compare_claims(topic)
    if conf:
        lines += ["## Conflicting claims"] + [f"- \"{c['a']}\" vs \"{c['b']}\" - preferred: \"{c['prefer']}\" ({c['why']})" for c in conf] + [""]
    q = open_questions(topic)
    if q:
        lines += ["## Unanswered questions"] + [f"- {x}" for x in q] + [""]
    lines += ["## Sources"] + [f"{i + 1}. {s['title'] or s['url']} - {s['grade']} (reliability {s['score']}), published {s['pub'] or 'date not found'}, retrieved {C.day(s['retrieved'])}. {s['url']}" for i, s in enumerate(srcs)]
    return "\n".join(lines)


def follow_up_experiments(topic: str) -> str:
    q = open_questions(topic)
    base = "Propose 3 concrete follow-up experiments or checks (what to measure, expected result, how it would change the conclusion) for this research topic: " + topic + (". Open questions: " + "; ".join(q[:5]) if q else "")
    out = C.llm(base) if C._cfg.get("llm") else ""
    return out or ("Without the model I can only suggest the generic route: pick the highest-impact open question, find the primary source that would settle it, and replicate the key figure independently." if q else "No open questions recorded yet.")


def watch(topic: str, on: bool = True):
    C.x("UPDATE rs_topics SET watch=? WHERE id=?", (int(on), topic_id(topic)))


def watched() -> List[Dict]:
    return [dict(r) for r in C.q("SELECT name,last_check FROM rs_topics WHERE watch=1")]


def run(topic: str, depth: str = "normal") -> Dict:
    """Research a topic through FRIDAY's web pipeline, grade every source, record claims in the notebook and return a spoken summary."""
    try:
        import friday_web_research as fwr
        res = fwr.run_web_research(topic)
    except Exception as exc:
        return {"ok": False, "answer": f"I couldn't reach the research pipeline ({exc}).", "sources": []}
    answer = str(res.get("answer", ""))
    sources = list(res.get("sources", []))
    raw = dict(res.get("_raw_sources") or []) if isinstance(res.get("_raw_sources"), list) else {}
    graded = []
    for u in sources[:10]:
        graded.append(add_source(topic, u, text=str(raw.get(u, ""))[:4000]))
    for sent in re.split(r"(?<=[.!?])\s+", answer):
        if 25 < len(sent) < 300:
            add_claim(topic, sent, sources[0] if sources else "")
    add_question(topic, f"What do primary sources say about {topic}?") if not any(g["grade"] in ("primary", "official", "academic") for g in graded) else None
    C.x("UPDATE rs_topics SET last_check=? WHERE id=?", (C.now(), topic_id(topic)))
    top = sorted(graded, key=lambda g: -g["score"])[:3]
    warn = "" if any(g["grade"] in ("primary", "official", "academic") for g in graded) else " I found no primary or academic source, so treat this as provisional."
    return {"ok": bool(res.get("ok")), "answer": answer + warn, "sources": top, "graded": graded}


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    m = re.match(r"^(?:grade|rate|evaluate|how reliable is) (?:the )?(?:source |site |website )?(https?://\S+|[\w\.\-]+\.[a-z]{2,}\S*)$", low)
    if m:
        g = grade_source(m.group(1) if m.group(1).startswith("http") else "https://" + m.group(1))
        return f"{g['host']} grades as {g['grade']}, reliability {int(g['score'] * 100)} percent. That's a heuristic from the site type; I still check what it actually says."
    m = re.match(r"^(?:deep )?research (?:the )?(?:topic )?(.+?)(?: with (?:cited )?sources)?$", low)
    if m and not re.match(r"^(?:report|notebook)\b", m.group(1)):
        r = run(m.group(1))
        return r["answer"] or "I couldn't find enough to report."
    m = re.match(r"^(?:show|give me|write|produce|generate) (?:a |the )?(?:research )?report (?:on|about|for) (.+)$", low)
    if m:
        txt = report(m.group(1))
        p = C.DATA_DIR / "outputs" / (re.sub(r"[^a-z0-9]+", "_", m.group(1))[:40] + "_report.md")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(txt, "utf-8")
        return f"The cited report is saved at {p}. It lists {len(txt.splitlines())} lines including graded sources and any conflicting claims."
    m = re.match(r"^(?:add|note) (?:a )?(?:question|unknown)(?: to (?:my )?(?:research )?(?:notebook|topic) (.+?))?[: ]+(.+)$", low)
    if m and re.search(r"question|unknown", low[:18]):
        add_question(m.group(1) or "general", m.group(2))
        return "Added to the research notebook as an open question."
    m = re.match(r"^(?:what (?:is|are) )?(?:still )?(?:unanswered|open) questions(?: (?:on|about|for) (.+))?$", low)
    if m:
        q = open_questions(m.group(1) or "general")
        return "Open questions: " + "; ".join(q[:5]) + "." if q else "No open questions recorded."
    m = re.match(r"^(?:track|watch|monitor) (?:changes in |the topic |news on )?(.+)$", low)
    if m and re.search(r"\b(topic|changes|news|developments)\b|^(?:track|watch|monitor) [a-z]", low) and not re.search(r"\b(order|package|parcel|flight|my )", low):
        watch(m.group(1))
        return f"I'll keep watching {m.group(1)} and tell you what changes when you ask 'any updates'."
    if re.match(r"^(?:any )?updates(?: on (?:my )?(?:watched )?topics)?$", low):
        w = watched()
        if not w:
            return "You aren't watching any topics yet."
        out = []
        for x in w[:3]:
            r = run(x["name"])
            out.append(f"{x['name']}: {C.clip(r['answer'], 160)}")
        return " ".join(out)
    m = re.match(r"^(?:suggest|propose) follow[- ]?up experiments(?: (?:for|on) (.+))?$", low)
    if m:
        return follow_up_experiments(m.group(1) or "general")
    return None


def ui_snapshot() -> Dict:
    topics = []
    for r in C.q("SELECT * FROM rs_topics ORDER BY created DESC LIMIT 8"):
        s = C.q("SELECT url,title,grade,score,pub FROM rs_sources WHERE topic=? ORDER BY score DESC LIMIT 8", (r["id"],))
        c = C.q("SELECT text,kind,confidence FROM rs_claims WHERE topic=? ORDER BY confidence DESC LIMIT 8", (r["id"],))
        topics.append({"topic": r["name"], "watch": bool(r["watch"]), "sources": [dict(x) for x in s], "claims": [dict(x) for x in c], "questions": open_questions(r["name"])})
    return {"topics": topics}
