"""FRIDAY 7.0 Permission and Policy Engine  (roadmap #13).

Classifies every action by risk, then decides: ALLOW routine permitted work, ASK before sensitive or irreversible work, DENY what is not
authorised.  Instructions that arrive inside web pages, documents, attachments or tool output are UNTRUSTED input: they can inform an
answer but can never trigger an action.

    safe         read-only, no side effects                              -> allowed
    routine      reversible, inside FRIDAY's own folders / opening things -> allowed (asked first at autonomy "ask_more")
    sensitive    changes your files elsewhere, runs code, sends, captures  -> needs the permission AND (usually) your yes
    irreversible delete / overwrite / purchase / send                      -> always asks, whatever the autonomy level
    forbidden    system folders, security switches, secret exfiltration   -> never

Autonomy levels (setting `autonomy_level`) change how much FRIDAY does without asking INSIDE the permissions you granted.  They never
grant access: "independent" means handling more work on her own, not unlimited access to your computer.
"""
from __future__ import annotations

import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS policy_rules7(tool TEXT PRIMARY KEY, mode TEXT, note TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS policy_log7(id INTEGER PRIMARY KEY, ts REAL, tool TEXT, risk TEXT, decision TEXT, source TEXT, reason TEXT, job TEXT);
CREATE INDEX IF NOT EXISTS ix_policy_log7_ts ON policy_log7(ts);
""")

RISKS = ("safe", "routine", "sensitive", "irreversible", "forbidden")
UNTRUSTED_SOURCES = {"webpage", "web", "document", "attachment", "search", "tool_output", "email", "clipboard", "file_content", "model"}
LEVELS = ("ask_more", "balanced", "independent")

# tool -> (risk, SEC permission key or None)
TOOL_RISK: Dict[str, tuple] = {
    "think": ("safe", None), "system_info": ("safe", None), "analyze_folder": ("safe", "read_files"), "memory_search": ("safe", None), "calc": ("safe", None),
    "investigate": ("safe", "web_research"), "web_research": ("safe", "web_research"), "synthesize": ("safe", None), "critic_review": ("safe", None),
    "cost_recipe": ("safe", None), "compare_costs": ("safe", None), "budget_check": ("safe", None), "finance_snapshot": ("safe", None),
    "code_map": ("safe", "read_files"), "code_review": ("safe", "read_files"), "repair_inspect": ("safe", "read_files"), "organise_preview": ("safe", "read_files"),
    "capability_report": ("safe", None), "find_file": ("safe", "read_files"), "multimodal_understand": ("safe", None), "notify": ("safe", None),
    "verify_build": ("safe", "read_files"), "context_lookup": ("safe", None), "team_run": ("safe", None), "computer_act": ("routine", None),
    "repair_review": ("safe", "read_files"), "repair_rollback": ("routine", "write_files"),
    "open_app": ("routine", None), "open_file": ("routine", None), "window_control": ("routine", None),
    "save_report": ("routine", "write_files"), "write_file": ("routine", "write_files"),
    "file_op": ("sensitive", "write_files"), "run_python": ("sensitive", "run_code"), "run_tests": ("sensitive", "run_code"),
    "capture_verify": ("sensitive", "screen_capture"), "repair_test": ("sensitive", "run_code"), "repair_propose": ("routine", "write_files"),
    "send_message": ("irreversible", "send_message"), "delete_file": ("irreversible", "delete_files"), "purchase": ("irreversible", "purchases"),
    "apply_patch": ("irreversible", "self_update"), "restore_backup": ("irreversible", "self_update"),
}
ALWAYS_ASK = {"send_message", "delete_file", "purchase", "apply_patch", "restore_backup"}

_FORBIDDEN_CMD = re.compile(
    r"\brm\s+-rf?\s+[/~]|\bdel\s+/[sfq]|\bformat\s+[a-z]:|\brmdir\s+/s|\bshutdown\b|\breg\s+(?:add|delete)\b|\bnet\s+user\b|\bpowershell\b.*-enc|"
    r"\bcurl\b[^\n|]*\|\s*(?:sh|bash)|\bbcdedit\b|\bdiskpart\b|\bvssadmin\b.*delete|\bdisable\b.*\b(?:defender|firewall|antivirus)\b", re.I)
_DELETE_WORDS = re.compile(r"\b(?:delete|remove|erase|wipe|shred|empty the recycle|uninstall)\b", re.I)
_SYSTEM_DIRS = ("c:\\windows", "c:\\program files", "c:\\programdata", "/etc/", "/usr/", "/bin/", "/sbin/", "/boot/", "/system/", "/library/")


# ------------------------------------------------------------------ settings
def autonomy() -> str:
    v = K.cfg_get("autonomy_level", "balanced").strip().lower().replace(" ", "_").replace("-", "_")
    return v if v in LEVELS else "balanced"


def set_autonomy(level: str) -> str:
    lv = (level or "").strip().lower().replace(" ", "_").replace("-", "_")
    lv = {"ask": "ask_more", "askmore": "ask_more", "careful": "ask_more", "cautious": "ask_more", "medium": "balanced", "normal": "balanced", "default": "balanced",
          "auto": "independent", "free": "independent", "more": "independent"}.get(lv, lv)
    if lv not in LEVELS:
        return ""
    K.cfg_set("autonomy_level", lv)
    try:
        import friday_security6 as SEC
        SEC.audit("user", "autonomy", lv)
    except Exception:
        pass
    return lv


# ------------------------------------------------------------------ rules (your own overrides)
def set_rule(tool: str, mode: str, note: str = ""):
    """mode: allow | ask | never"""
    if mode not in ("allow", "ask", "never"):
        raise ValueError("mode must be allow, ask or never")
    C.x("INSERT INTO policy_rules7(tool,mode,note,ts) VALUES(?,?,?,?) ON CONFLICT(tool) DO UPDATE SET mode=excluded.mode, note=excluded.note, ts=excluded.ts", (tool, mode, note, C.now()))


def clear_rule(tool: str):
    C.x("DELETE FROM policy_rules7 WHERE tool=?", (tool,))


def rules() -> List[Dict]:
    return [{"tool": r["tool"], "mode": r["mode"], "note": r["note"]} for r in C.q("SELECT * FROM policy_rules7 ORDER BY tool")]


def _rule(tool: str) -> str:
    r = C.q("SELECT mode FROM policy_rules7 WHERE tool=?", (tool,))
    return r[0]["mode"] if r else ""


# ------------------------------------------------------------------ classification
def _paths_in(args: Dict) -> List[str]:
    out: List[str] = []
    for k, v in (args or {}).items():
        if isinstance(v, str) and (k in ("path", "folder", "file", "target", "dest", "dst", "src", "name") or re.match(r"^[A-Za-z]:[\\/]|^/|^~", v)):
            out.append(v)
    return out


def _inside_friday(path: str) -> bool:
    try:
        p = Path(os.path.expandvars(os.path.expanduser(path))).resolve()
        for base in (C.DATA_DIR, C.HERE / "friday_output", C.HERE / "outputs", Path(os.path.expanduser("~")) / "FRIDAY"):
            try:
                p.relative_to(base.resolve())
                return True
            except ValueError:
                continue
    except Exception:
        pass
    return False


def classify(tool: str, args: Optional[Dict] = None) -> Dict:
    """{risk, permission, reasons}"""
    args = args or {}
    risk, perm = TOOL_RISK.get(tool, ("sensitive", None))
    reasons: List[str] = []
    blob = " ".join(str(v) for v in args.values() if isinstance(v, (str, int, float)))[:2000]
    if _FORBIDDEN_CMD.search(blob):
        return {"risk": "forbidden", "permission": perm, "reasons": ["the request contains a destructive or system-level command"]}
    for p in _paths_in(args):
        low = p.lower().replace("/", "\\") if re.match(r"^[A-Za-z]:", p) else p.lower()
        if any(low.startswith(d) for d in _SYSTEM_DIRS):
            if tool in ("save_report", "write_file", "file_op", "delete_file", "apply_patch"):
                return {"risk": "forbidden", "permission": perm, "reasons": [f"{p} is a protected system location"]}
    if tool in ("save_report", "write_file"):
        paths = _paths_in(args)
        if paths and not all(_inside_friday(p) or ("/" not in p and "\\" not in p) for p in paths):
            risk = "sensitive"
            reasons.append("writes outside FRIDAY's own folders")
    if tool == "file_op":
        op = str(args.get("op") or args.get("action") or "").lower()
        if op in ("delete", "remove", "erase") or _DELETE_WORDS.search(blob):
            risk, perm = "irreversible", "delete_files"
            reasons.append("deletes data")
        elif op in ("move", "rename", "overwrite"):
            risk = "sensitive"
            reasons.append(f"{op} changes existing files")
        elif op in ("copy", "create_folder", "mkdir"):
            risk = "routine"
    if tool in ("run_python", "run_tests") and re.search(r"\b(?:os\.remove|shutil\.rmtree|subprocess|os\.system|socket|requests\.post|open\([^)]*['\"]w)", blob):
        risk = "sensitive"
        reasons.append("the code touches files, processes or the network")
    return {"risk": risk, "permission": perm, "reasons": reasons}


def _perm_allowed(perm: Optional[str]) -> bool:
    if not perm:
        return True
    try:
        import friday_security6 as SEC
        return SEC.allowed(perm)
    except Exception:
        return False


def _log(tool: str, risk: str, decision: str, source: str, reason: str, job: str):
    try:
        C.x("INSERT INTO policy_log7(ts,tool,risk,decision,source,reason,job) VALUES(?,?,?,?,?,?,?)", (C.now(), tool, risk, decision, source, K.clip(reason, 200), job or ""))
        if decision != "allow" or risk in ("sensitive", "irreversible"):
            import friday_security6 as SEC
            SEC.audit("policy", f"{decision}:{tool}", f"{risk}; {source}; {reason}"[:200], "ok" if decision == "allow" else "denied" if decision == "deny" else "asked")
    except Exception:
        pass


def decide(tool: str, args: Optional[Dict] = None, source: str = "user", level: Optional[str] = None, job: str = "", approved: bool = False) -> Dict:
    """-> {decision: allow|ask|deny, risk, permission, reason, spoken}.  `approved` = the user just said yes to exactly this action."""
    args = args or {}
    lv = level or autonomy()
    c = classify(tool, args)
    risk, perm = c["risk"], c["permission"]
    why = "; ".join(c["reasons"])

    def out(decision: str, reason: str, spoken: str = "") -> Dict:
        _log(tool, risk, decision, source, reason, job)
        return {"decision": decision, "risk": risk, "permission": perm, "reason": reason, "spoken": spoken or reason, "level": lv}

    if risk == "forbidden":
        return out("deny", why or "that is not something I will do", "I won't do that, sir. " + (why or "It is outside what I am allowed to do."))
    if source in UNTRUSTED_SOURCES and risk != "safe":
        return out("deny", f"instructions found in {source} content are untrusted", f"That request came from {source} content, not from you, so I won't act on it. Tell me directly if you want it done.")
    rule = _rule(tool)
    if rule == "never":
        return out("deny", "you told me never to do this", f"You told me never to use {tool.replace('_', ' ')}, sir.")
    if risk == "safe":
        if not _perm_allowed(perm):
            return out("ask", f"{perm.replace('_', ' ')} is switched off", f"{perm.replace('_', ' ').capitalize()} is switched off. Shall I use it just for this?")
        return out("allow", "read-only")
    if approved:
        return out("allow", "you approved this")
    if rule == "ask" or tool in ALWAYS_ASK or risk == "irreversible":
        return out("ask", why or f"{risk} action", f"This {why or risk + ' action'} needs your OK first, sir. Shall I go ahead with {tool.replace('_', ' ')}?")
    if not _perm_allowed(perm):
        return out("ask", f"{perm.replace('_', ' ')} is switched off", f"{perm.replace('_', ' ').capitalize()} is switched off. Shall I use it just for this?")
    if rule == "allow":
        return out("allow", "you allowed this")
    if risk == "routine":
        return out("ask" if lv == "ask_more" else "allow", "routine and reversible" if lv != "ask_more" else "you asked me to check first", "Shall I go ahead, sir?")
    # sensitive with the permission granted
    if lv == "independent":
        return out("allow", "permission granted and autonomy is independent")
    return out("ask", why or "this changes things outside my own folders", f"This {why or 'is a sensitive action'}, sir. Shall I go ahead with {tool.replace('_', ' ')}?")


# ------------------------------------------------------------------ untrusted content
def untrusted(text: str, source: str = "document") -> Dict:
    """Wrap content so it is treated as data.  Never lets it become an instruction."""
    try:
        import friday_security6 as SEC
        scan = SEC.scan_untrusted(text, source)
        return {"risky": bool(scan.get("risky")), "hits": scan.get("hits", []), "text": SEC.fence(text, source)}
    except Exception:
        return {"risky": False, "hits": [], "text": text}


def log(n: int = 15) -> List[Dict]:
    return [{"when": C.iso(r["ts"]), "tool": r["tool"], "risk": r["risk"], "decision": r["decision"], "source": r["source"], "reason": r["reason"]}
            for r in C.q("SELECT * FROM policy_log7 ORDER BY id DESC LIMIT ?", (n,))]


def summary() -> Dict:
    perms = []
    try:
        import friday_security6 as SEC
        perms = SEC.permissions()
    except Exception:
        pass
    by = {"allow": 0, "ask": 0, "deny": 0}
    for r in C.q("SELECT decision, COUNT(*) n FROM policy_log7 WHERE ts>? GROUP BY decision", (C.now() - 7 * 86400,)):
        by[r["decision"]] = r["n"]
    return {"autonomy": autonomy(), "rules": rules(), "permissions": perms, "last_7_days": by, "recent": log(8)}


# ------------------------------------------------------------------ commands
def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    m = re.match(r"^(?:set|change|switch|put)\s+(?:your\s+|the\s+)?autonomy(?:\s+level)?\s+(?:to\s+)?(.+)$", t) or re.match(r"^(?:be|work)\s+(more independent|independent|more careful|careful|balanced)$", t)
    if m:
        lv = set_autonomy(m.group(1).replace("more independent", "independent").replace("more careful", "ask more"))
        if not lv:
            return "I know three autonomy levels: ask more, balanced and independent."
        return {"ask_more": "Understood. I'll check with you before most things, sir.", "balanced": "Balanced it is. Routine things I'll just do; sensitive ones I'll ask about.",
                "independent": "Independent. I'll handle more on my own, but only inside the permissions you've granted and I'll still ask before anything irreversible."}[lv]
    if re.match(r"^(?:what(?:'s| is) )?(?:your |the )?autonomy(?: level| setting)?\??$", t) or t in ("how independent are you", "how much do you ask before acting"):
        return f"My autonomy level is {autonomy().replace('_', ' ')}. Irreversible actions always need your OK, whatever the level."
    if re.match(r"^(?:what (?:are you|can you do) (?:allowed|permitted)(?: to do)?(?: without asking)?|what can you do without asking|what are your permissions|what do you do without asking)\??$", t):
        s = summary()
        on = [p["tool"].replace("_", " ") for p in s["permissions"] if p["allowed"]]
        off = [p["tool"].replace("_", " ") for p in s["permissions"] if not p["allowed"]]
        return (f"At the {autonomy().replace('_', ' ')} level I read, research and calculate freely. I'm allowed to: {', '.join(on[:8]) or 'nothing extra'}. "
                f"Switched off: {', '.join(off[:8]) or 'nothing'}. I always ask before deleting, sending, buying or changing my own code.")
    m = re.match(r"^(?:always )?ask (?:me )?before (?:you )?(.+)$", t)
    if m:
        tool = _tool_from_phrase(m.group(1))
        if tool:
            set_rule(tool, "ask", "user rule")
            return f"From now on I'll ask before {m.group(1).strip()}."
    m = re.match(r"^never (.+)$", t)
    if m and _tool_from_phrase(m.group(1)):
        tool = _tool_from_phrase(m.group(1))
        set_rule(tool, "never", "user rule")
        return f"Understood, I will never {m.group(1).strip()}."
    m = re.match(r"^(?:you (?:can|may) )?(?:always )?(?:go ahead and )?(?:allow|let) (?:yourself to )?(.+?) without asking$", t)
    if m and _tool_from_phrase(m.group(1)):
        tool = _tool_from_phrase(m.group(1))
        if TOOL_RISK.get(tool, ("sensitive",))[0] == "irreversible" or tool in ALWAYS_ASK:
            return "I'll always ask before that one, sir. It can't be undone."
        set_rule(tool, "allow", "user rule")
        return f"Done. I'll {m.group(1).strip()} without asking."
    return None


def _tool_from_phrase(p: str) -> str:
    p = p.lower()
    for key, tool in (("writ", "write_file"), ("sav", "save_report"), ("delet", "delete_file"), ("send", "send_message"), ("messag", "send_message"), ("buy", "purchase"), ("purchas", "purchase"),
                      ("run code", "run_python"), ("running code", "run_python"), ("run python", "run_python"), ("captur", "capture_verify"), ("screenshot", "capture_verify"),
                      ("mov", "file_op"), ("renam", "file_op"), ("patch", "apply_patch"), ("updat", "apply_patch")):
        if key in p:
            return tool
    return ""
