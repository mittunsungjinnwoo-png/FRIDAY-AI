"""
FRIDAY V2035 SEMANTIC INTENT ENGINE
-----------------------------------
Fast, deterministic parsing for common compound voice commands.
It does not replace the AI agent. It handles high-confidence browser
intent before the slower general agent so natural speech maps to the
right action without changing the user's requested content.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class BrowserIntent:
    kind: str
    target: str = ""
    payload: str = ""

def _clean_spoken(s: str) -> str:
    s = re.sub(r"\s+", " ", str(s or "").strip())
    # Common ASR duplication of an action verb: "type type hi".
    s = re.sub(r"\b(type|enter|write)\s+\1\b", r"\1", s, flags=re.I)
    return s.strip(" .!?")

def parse_browser_intent(command: str) -> Optional[BrowserIntent]:
    c = _clean_spoken(command)
    if not c:
        return None

    # "open Google and type hi in the search bar"
    # Also accepts "go to Google and enter hi into the search bar".
    m = re.match(
        r"^(?:please\s+)?(?:open|launch|start|go\s+to|navigate\s+to)\s+"
        r"(?:google(?:\s+chrome)?|chrome)\s+"
        r"(?:and|then)\s+(?:please\s+)?(?:type|enter|write)\s+"
        r"(.+?)\s+(?:in|into|on)\s+(?:the\s+)?(?:google\s+)?"
        r"(?:search|address|omnibox)\s*(?:bar)?$",
        c, re.I
    )
    if m:
        return BrowserIntent("google_type_search", "google", _clean_spoken(m.group(1)))

    # "open <site> and search for <query>"
    m = re.match(
        r"^(?:please\s+)?(?:open|launch|start|go\s+to|navigate\s+to)\s+"
        r"(.+?)\s+(?:and|then)\s+(?:search|look)\s+(?:for\s+)?(.+)$",
        c, re.I
    )
    if m:
        site, q = m.group(1).strip(), _clean_spoken(m.group(2))
        if site.lower() in {"google", "google chrome", "chrome"}:
            return BrowserIntent("google_search", "google", q)
        return BrowserIntent("site_search", site, q)

    # "open <site>" is left to the existing browser router unless it is a
    # clearly named web destination.
    return None
