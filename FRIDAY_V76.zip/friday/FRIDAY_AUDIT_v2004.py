"""FRIDAY v2004 reliability audit.
Read-only dependency/module audit plus deterministic artifact validation.
Run on Windows with the same Python environment used by FRIDAY.
"""
from __future__ import annotations
import importlib.util, os, py_compile, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def check(label, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'} | {label}" + (f" | {detail}" if detail else ""))
    return ok

def main():
    results=[]
    required_modules=[
        "friday_backend","friday_agent_core","friday_voice_engine","friday_web_research",
        "friday_creation_engine","friday_context","friday_notes_engine","friday_system_control",
        "friday_screen_intelligence","friday_omni_engine","friday_advanced_agent","friday_v96_runtime",
        "friday_desktop_agent","friday_uia","friday_gemini_computer_use"
    ]
    for name in required_modules:
        results.append(check(f"project module {name}", (ROOT/f"{name}.py").exists()))
    deps={
        "google.genai":"AI brain", "dotenv":"key loading (optional)", "speech_recognition":"voice fallback",
        "faster_whisper":"local STT", "numpy":"audio processing", "pyautogui":"mouse/keyboard",
        "mss":"screen capture", "pytesseract":"OCR bridge", "docx":"DOCX", "pypdf":"PDF",
        "openpyxl":"XLSX", "pptx":"PPTX", "odf":"ODF", "pywinauto":"Windows UIA",
        "playwright":"browser automation", "psutil":"system state"
    }
    for mod, label in deps.items():
        results.append(check(f"dependency {label}", importlib.util.find_spec(mod) is not None, mod))
    # Compile every source file so syntax/import-time parsing errors are caught.
    for f in ROOT.glob("*.py"):
        try:
            py_compile.compile(str(f), doraise=True)
            results.append(check(f"compile {f.name}", True))
        except Exception as e:
            results.append(check(f"compile {f.name}", False, str(e)))
    # Validate deterministic artifact builders without network/Gemini.
    try:
        import friday_creation_engine as ce
        plan={"title":"FRIDAY Validation","summary":"Synthetic validation package.","key_facts":["Fact A"],"methodology":"Synthetic test.","sections":[{"heading":"Section 1","body":"Body","bullets":["Bullet"],"table":{"headers":["A","B"],"rows":[["1","2"]]},"source_ids":[1]}]}
        sources=[("https://example.com","Synthetic source")]
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            ce._build_docx(plan,sources,td/"a.docx")
            ce._build_pdf(plan,sources,td/"a.pdf")
            ce._build_xlsx(plan,sources,td/"a.xlsx")
            ce._build_pptx(plan,sources,td/"a.pptx")
            if getattr(ce,"ODF_AVAILABLE",False):
                ce._build_odt(plan,sources,td/"a.odt")
                ce._build_ods(plan,sources,td/"a.ods")
                ce._build_odp(plan,sources,td/"a.odp")
            results.append(check("artifact generation + structural validation", True))
    except Exception as e:
        results.append(check("artifact generation + structural validation", False, repr(e)))
    key=os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    results.append(check("Gemini credential visible to process", bool(key), "Paste it into GEMINI_API_KEY_INLINE_FALLBACK in friday_backend.py" if not key else "key present (value not printed)"))
    print("\nRESULT:", "PASS" if all(results) else "FAIL")
    return 0 if all(results) else 1

if __name__ == "__main__":
    raise SystemExit(main())
