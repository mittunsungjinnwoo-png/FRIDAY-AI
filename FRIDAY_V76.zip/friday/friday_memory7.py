"""FRIDAY 7.0 Advanced Memory Architecture  (roadmap #7).

Five complementary memory types in one store (table mem7), layered ON TOP of the 6.0 memory (which keeps working and is searched too):

    episodic    what happened in previous sessions / missions
    semantic    useful facts and knowledge about you and your world
    procedural  how a workflow that worked is done (steps + the plan that succeeded)
    project     goals, progress, decisions and unfinished work, per project
    preference  response and workflow preferences you stated or approved

Every item has: timestamp, source (user | approved | job | session | inferred | legacy) and a reference to where it came from, importance,
confidence and a status.  Retrieval is scored by relevance x recency x importance x confidence x source reliability.
Conflicts are resolved explicitly (what you said beats what was inferred; newer beats older; the loser is kept as history, never silently
dropped), and anything can be corrected or deleted.  Secrets are refused.  Nothing here invents a past event: only stored items are returned,
always with their date and source.
"""
from __future__ import annotations

import math
import re
import threading
import time
from typing import Any, Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS mem7(id INTEGER PRIMARY KEY, kind TEXT, text TEXT, subject TEXT, source TEXT, source_ref TEXT, ts REAL, updated REAL, last_used REAL,
    uses INTEGER DEFAULT 0, importance REAL DEFAULT 0.5, confidence REAL DEFAULT 0.8, status TEXT DEFAULT 'active', project TEXT DEFAULT '', meta TEXT DEFAULT '{}',
    supersedes INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_mem7_kind ON mem7(kind, status);
CREATE INDEX IF NOT EXISTS ix_mem7_project ON mem7(project);
CREATE TABLE IF NOT EXISTS sessions7(id INTEGER PRIMARY KEY, sid TEXT UNIQUE, started REAL, ended REAL, summary TEXT, turns INTEGER DEFAULT 0, topics TEXT DEFAULT '');
""")

KINDS = ("episodic", "semantic", "procedural", "project", "preference")
HALF_LIFE_DAYS = {"episodic": 30.0, "semantic": 365.0, "procedural": 180.0, "project": 60.0, "preference": 365.0}
SOURCE_WEIGHT = {"user": 1.0, "approved": 0.95, "job": 0.85, "session": 0.7, "legacy": 0.8, "inferred": 0.5, "import": 0.6}
PROJECT_KINDS = ("goal", "progress", "decision", "unfinished", "note")

_turns: List[Dict] = []
_session = {"sid": None, "started": 0.0}
_lock = threading.Lock()


# ------------------------------------------------------------------ helpers
def _subject(text: str) -> str:
    t = re.sub(r"^(?:i|my|the|our)\s+", "", C.norm(text))
    m = re.match(r"^([a-z0-9' ]{2,40}?)\s+(?:is|are|was|were|likes?|prefers?|wants?|costs?|uses?|has|have|=|:)\b", t)
    return (m.group(1) if m else " ".join(t.split()[:3])).strip()


def _recency(ts: float, kind: str, now: float) -> float:
    age_d = max(0.0, now - ts) / 86400.0
    return math.pow(0.5, age_d / HALF_LIFE_DAYS.get(kind, 90.0))


def _row(r) -> Dict:
    d = dict(r)
    d["meta"] = K.jl(d.get("meta"), {})
    return d


def _public(r: Dict, score: float = 0.0) -> Dict:
    return {"id": r["id"], "kind": r["kind"], "text": r["text"], "score": round(score, 3), "when": C.iso(r["ts"]), "ago": K.ago(r["ts"]), "source": r["source"],
            "source_ref": r.get("source_ref", ""), "confidence": round(float(r.get("confidence") or 0), 2), "project": r.get("project", ""), "status": r["status"], "meta": r.get("meta", {})}


# ------------------------------------------------------------------ write
def remember(kind: str, text: str, source: str = "user", source_ref: str = "", project: str = "", importance: Optional[float] = None, confidence: Optional[float] = None,
             meta: Optional[Dict] = None, ts: Optional[float] = None) -> Dict:
    kind = kind if kind in KINDS else "semantic"
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(text) < 3:
        return {"action": "ignored", "id": 0}
    if C.SECRET.search(text):
        return {"action": "refused", "id": 0, "reason": "looks like a secret"}
    now = ts or C.now()
    imp = importance if importance is not None else (0.8 if source == "user" else 0.55)
    conf = confidence if confidence is not None else SOURCE_WEIGHT.get(source, 0.6)
    subj = _subject(text)
    same = [_row(r) for r in C.q("SELECT * FROM mem7 WHERE kind=? AND status='active' AND project=?", (kind, project))]
    # exact / near duplicate -> reinforce
    for r in same:
        if C.similarity(r["text"], text) >= 0.92:
            C.x("UPDATE mem7 SET updated=?, confidence=MIN(1.0, confidence+0.05), uses=uses+1 WHERE id=?", (now, r["id"]))
            return {"action": "duplicate", "id": r["id"]}
    # same subject, different content -> conflict resolution (facts and preferences only; episodes and project notes accumulate)
    if kind in ("semantic", "preference") and subj:
        for r in same:
            if r["subject"] == subj and C.similarity(r["text"], text) < 0.92 and len(subj) >= 4:
                new_rank, old_rank = SOURCE_WEIGHT.get(source, 0.5), SOURCE_WEIGHT.get(r["source"], 0.5)
                if new_rank >= old_rank:                      # newer + at least as reliable wins; the old one stays as history
                    C.x("UPDATE mem7 SET status='superseded', updated=? WHERE id=?", (now, r["id"]))
                    nid = _insert(kind, text, subj, source, source_ref, now, imp, conf, project, meta, supersedes=r["id"])
                    K.emit("memory.superseded", {"old": r["id"], "new": nid})
                    return {"action": "superseded", "id": nid, "old": r["id"]}
                # a weaker (inferred) claim contradicting a firmer one: keep both, flag it, lower confidence
                nid = _insert(kind, text, subj, source, source_ref, now, imp, min(conf, 0.4), project, {**(meta or {}), "conflicts_with": r["id"]})
                return {"action": "conflict", "id": nid, "old": r["id"]}
    nid = _insert(kind, text, subj, source, source_ref, now, imp, conf, project, meta)
    return {"action": "added", "id": nid}


def _insert(kind, text, subj, source, source_ref, now, imp, conf, project, meta, supersedes: int = 0) -> int:
    return C.x("INSERT INTO mem7(kind,text,subject,source,source_ref,ts,updated,importance,confidence,project,meta,supersedes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
               (kind, text, subj, source, source_ref, now, now, imp, conf, project, K.jd(meta or {}), supersedes))


# ------------------------------------------------------------------ read
def recall(query: str, kinds: Optional[List[str]] = None, k: int = 5, project: Optional[str] = None, min_score: float = 0.2, include_legacy: bool = True,
           touch: bool = True) -> List[Dict]:
    """Ranked, dated, source-tagged items.  Score = 0.55 relevance + 0.15 recency + 0.15 importance + 0.15 confidence (x source reliability)."""
    q_toks = set(C.tokens(query, expand=True))
    if not q_toks:
        return []
    now = C.now()
    sql = "SELECT * FROM mem7 WHERE status='active'"
    args: list = []
    if kinds:
        sql += f" AND kind IN ({','.join('?' * len(kinds))})"
        args += list(kinds)
    if project is not None:
        sql += " AND project=?"
        args.append(project)
    scored: List[tuple] = []
    for r in C.q(sql, args):
        d = _row(r)
        t_toks = set(C.tokens(d["text"] + " " + d["subject"], expand=True))
        overlap = len(q_toks & t_toks) / max(1, min(len(q_toks), 6))
        rel = min(1.0, 0.6 * overlap + 0.4 * C.similarity(query, d["text"]))
        if rel < 0.12:
            continue
        s = (0.55 * rel + 0.15 * _recency(d["ts"], d["kind"], now) + 0.15 * float(d["importance"] or 0.5) + 0.15 * float(d["confidence"] or 0.5)) * (0.6 + 0.4 * SOURCE_WEIGHT.get(d["source"], 0.6))
        scored.append((s, d))
    out = [_public(d, s) for s, d in sorted(scored, key=lambda x: -x[0]) if s >= min_score][:k]
    if include_legacy and (not kinds or "semantic" in kinds or "preference" in kinds):
        try:
            import friday_memory6 as MEM
            for h in MEM.search(query, 3):
                txt = h.get("text", "")
                if txt and not any(C.similarity(txt, o["text"]) > 0.85 for o in out):
                    out.append({"id": -int(h.get("id", 0) or 0), "kind": h.get("kind", "semantic"), "text": txt, "score": round(float(h.get("score", 0.3)), 3), "when": h.get("when", ""),
                                "ago": h.get("ago", ""), "source": "legacy", "source_ref": "memory6", "confidence": 0.7, "project": "", "status": "active", "meta": {}})
        except Exception:
            pass
    out = sorted(out, key=lambda o: -o["score"])[:k]
    if touch:
        for o in out:
            if o["id"] > 0:
                try:
                    C.x("UPDATE mem7 SET last_used=?, uses=uses+1 WHERE id=?", (now, o["id"]))
                except Exception:
                    pass
    return out


def get(mid: int) -> Optional[Dict]:
    r = C.q("SELECT * FROM mem7 WHERE id=?", (mid,))
    return _public(_row(r[0])) if r else None


def history(mid: int) -> List[Dict]:
    """The chain of superseded versions behind an item (newest first)."""
    out, cur = [], mid
    for _ in range(8):
        r = C.q("SELECT * FROM mem7 WHERE id=?", (cur,))
        if not r:
            break
        d = _row(r[0])
        out.append(_public(d))
        if not d["supersedes"]:
            break
        cur = d["supersedes"]
    return out


def correct(hint: str, new_text: str) -> Dict:
    """You told me something I had wrong: keep the old one as history, store the corrected one with full confidence."""
    hits = recall(hint, k=1, min_score=0.15, touch=False)
    if hits and hits[0]["id"] > 0:
        old = hits[0]
        C.x("UPDATE mem7 SET status='corrected', updated=? WHERE id=?", (C.now(), old["id"]))
        nid = _insert(old["kind"], new_text, _subject(new_text), "user", "correction", C.now(), 0.85, 1.0, old.get("project", ""), {"corrected_from": old["text"]}, supersedes=old["id"])
        K.emit("memory.corrected", {"old": old["id"], "new": nid})
        return {"ok": True, "old": old["text"], "id": nid}
    r = remember("semantic", new_text, source="user", source_ref="correction", confidence=1.0)
    return {"ok": r["action"] in ("added", "superseded", "duplicate"), "old": "", "id": r.get("id", 0)}


def forget(hint: str, threshold: float = 0.3) -> int:
    n = 0
    for h in recall(hint, k=3, min_score=threshold, touch=False):
        if h["id"] > 0:
            C.x("UPDATE mem7 SET status='deleted', text='[deleted]', subject='', meta='{}', updated=? WHERE id=?", (C.now(), h["id"]))
            n += 1
    return n


def forget_id(mid: int):
    C.x("UPDATE mem7 SET status='deleted', text='[deleted]', subject='', meta='{}', updated=? WHERE id=?", (C.now(), mid))


def forget_all(kind: Optional[str] = None) -> int:
    if kind:
        return K.xn("UPDATE mem7 SET status='deleted', text='[deleted]', subject='', meta='{}' WHERE kind=? AND status!='deleted'", (kind,))
    return K.xn("UPDATE mem7 SET status='deleted', text='[deleted]', subject='', meta='{}' WHERE status!='deleted'")


def apply_retention(days: int) -> int:
    if days <= 0:
        return 0
    return K.xn("DELETE FROM mem7 WHERE kind='episodic' AND ts<? AND importance<0.8", (C.now() - days * 86400,))


# ------------------------------------------------------------------ procedural memory
def procedure_add(goal: str, steps: List[Dict], plan: Optional[List[Dict]] = None, source_ref: str = "") -> Dict:
    names = " -> ".join(s.get("desc", s.get("tool", "")) for s in steps)[:300]
    text = f"To {goal[:100]}: {names}"
    r = remember("procedural", text, source="job", source_ref=source_ref, importance=0.7,
                 meta={"goal": goal, "steps": [{"tool": s.get("tool"), "desc": s.get("desc")} for s in steps], "plan": plan or [], "successes": 1})
    if r["action"] == "duplicate":
        C.x("UPDATE mem7 SET meta=json_set(meta,'$.successes', COALESCE(json_extract(meta,'$.successes'),1)+1) WHERE id=?", (r["id"],))
    return r


def procedure_for(goal: str) -> Optional[Dict]:
    hits = recall(goal, kinds=["procedural"], k=1, min_score=0.3, include_legacy=False, touch=False)
    return hits[0] if hits else None


# ------------------------------------------------------------------ project memory
def project_note(project: str, text: str, kind: str = "note", source: str = "user") -> Dict:
    kind = kind if kind in PROJECT_KINDS else "note"
    return remember("project", f"[{kind}] {text}", source=source, project=project.strip().lower(), importance=0.75 if kind in ("goal", "decision", "unfinished") else 0.55, meta={"pkind": kind})


def project_state(project: str) -> Dict:
    p = project.strip().lower()
    items = [_row(r) for r in C.q("SELECT * FROM mem7 WHERE kind='project' AND status='active' AND project=? ORDER BY ts", (p,))]
    out: Dict[str, List[Dict]] = {k: [] for k in PROJECT_KINDS}
    for d in items:
        out.setdefault(d["meta"].get("pkind", "note"), []).append(_public(d))
    return {"project": p, **out, "count": len(items), "last": C.iso(items[-1]["ts"]) if items else ""}


def projects() -> List[Dict]:
    return [{"project": r["project"], "items": r["n"], "last": C.iso(r["last"])} for r in C.q("SELECT project, COUNT(*) n, MAX(ts) last FROM mem7 WHERE kind='project' AND status='active' AND project!='' GROUP BY project ORDER BY last DESC")]


def resolve_unfinished(project: str, hint: str) -> int:
    n = 0
    for r in C.q("SELECT id,text FROM mem7 WHERE kind='project' AND status='active' AND project=? AND json_extract(meta,'$.pkind')='unfinished'", (project.strip().lower(),)):
        if C.similarity(hint, r["text"]) > 0.3:
            C.x("UPDATE mem7 SET status='superseded', updated=? WHERE id=?", (C.now(), r["id"]))
            n += 1
    return n


# ------------------------------------------------------------------ preference memory (stated or approved only)
def preference_set(text: str, source: str = "user") -> Dict:
    if source not in ("user", "approved"):
        return {"action": "refused", "id": 0, "reason": "preferences must be stated or approved by you"}
    return remember("preference", text, source=source, importance=0.8)


def preferences(k: int = 10) -> List[Dict]:
    return [_public(_row(r)) for r in C.q("SELECT * FROM mem7 WHERE kind='preference' AND status='active' ORDER BY updated DESC LIMIT ?", (k,))]


# ------------------------------------------------------------------ episodic memory (sessions)
def begin_session():
    with _lock:
        if _session["sid"]:
            return
        _session["sid"] = K.SESSION_ID
        _session["started"] = time.time()
    try:
        C.x("INSERT OR IGNORE INTO sessions7(sid,started,turns) VALUES(?,?,0)", (K.SESSION_ID, time.time()))
    except Exception:
        pass


def log_turn(user: str, answer: str):
    begin_session()
    with _lock:
        _turns.append({"u": (user or "")[:200], "a": (answer or "")[:200], "ts": time.time()})
        del _turns[:-60]
    try:
        C.x("UPDATE sessions7 SET turns=turns+1 WHERE sid=?", (K.SESSION_ID,))
    except Exception:
        pass


def _topics(texts: List[str], n: int = 5) -> List[str]:
    cnt: Dict[str, int] = {}
    for t in texts:
        for w in set(C.tokens(t)):
            if len(w) > 3:
                cnt[w] = cnt.get(w, 0) + 1
    return [w for w, c in sorted(cnt.items(), key=lambda x: -x[1])[:n] if c >= 2] or [w for w, _ in sorted(cnt.items(), key=lambda x: -x[1])[:3]]


def end_session(jobs_done: Optional[List[str]] = None) -> Optional[int]:
    """Store ONE episodic memory for this session (deterministic: topics and what was completed, no model, nothing invented)."""
    with _lock:
        turns = list(_turns)
    if len(turns) < 2 and not jobs_done:
        return None
    tops = _topics([t["u"] for t in turns])
    stamp = time.strftime("%A %d %B %Y", time.localtime(_session["started"] or time.time()))
    text = f"On {stamp} we spoke {len(turns)} time(s)" + (f", mostly about {', '.join(tops)}" if tops else "") + (f". Finished: {'; '.join(jobs_done[:3])}" if jobs_done else "") + "."
    r = remember("episodic", text, source="session", source_ref=K.SESSION_ID, importance=0.5)
    try:
        C.x("UPDATE sessions7 SET ended=?, summary=?, topics=? WHERE sid=?", (time.time(), text, ",".join(tops), K.SESSION_ID))
    except Exception:
        pass
    return r.get("id")


def episodes(n: int = 5) -> List[Dict]:
    return [{"when": C.iso(r["started"]), "summary": r["summary"] or "(session in progress)", "turns": r["turns"]} for r in C.q("SELECT * FROM sessions7 ORDER BY id DESC LIMIT ?", (n,))]


# ------------------------------------------------------------------ prompt
def prompt_block(question: str, k: int = 3) -> str:
    """A few relevant stored items WITH their dates and sources, so the model can use them without inventing history."""
    try:
        hits = [h for h in recall(question, k=k + 2, min_score=0.32, touch=True) if h["source"] != "legacy"][:k]
    except Exception:
        return ""
    if not hits:
        return ""
    lines = [f"- ({h['kind']}, {h['ago']}, from {h['source']}) {h['text']}" for h in hits]
    return "\n\nRelevant stored notes (use only if they help; never claim more than they say):\n" + "\n".join(lines)


# ------------------------------------------------------------------ bus: learn from verified outcomes
def _on_job_done(p: Dict):
    if not p:
        return
    goal = p.get("goal", "")
    state = p.get("state")
    ratio = float(p.get("verified_ratio") or 0)
    if state == "done" and ratio >= 0.5 and not str(goal).startswith("benchmark"):
        steps = p.get("plan") or []
        procedure_add(goal, steps, plan=steps, source_ref=p.get("jid", ""))
        remember("episodic", f"Finished a mission: {goal[:100]} ({int(ratio * 100)}% of steps independently verified).", source="job", source_ref=p.get("jid", ""), importance=0.55)
    elif state in ("failed", "partial"):
        why = "; ".join(f"{f.get('tool')}: {f.get('error', '')[:60]}" for f in (p.get("failures") or [])[:2])
        remember("episodic", f"A mission was {state}: {goal[:100]}" + (f" ({why})" if why else "") + ".", source="job", source_ref=p.get("jid", ""), importance=0.5)


def install_events():
    K.on("job.done", _on_job_done)


# ------------------------------------------------------------------ commands (6.0 memory keeps remember/forget wording; these are the 7.0 additions)
def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if re.match(r"^(?:what did we (?:do|talk about|discuss)|what happened|what were we (?:doing|working on)) (?:last time|last session|before|yesterday|earlier)\??$", t) or t in ("recap our last session", "what did we do last time"):
        ep = episodes(3)
        done = [e for e in ep if e["summary"] and "in progress" not in e["summary"]]
        return done[0]["summary"] if done else "I don't have a record of an earlier session yet."
    if re.match(r"^(?:what are my preferences|show my preferences|what preferences do you have(?: for me)?|list my preferences)\??$", t):
        ps = preferences(6)
        return ("Preferences I have on record: " + "; ".join(p["text"] for p in ps) + ".") if ps else "I have no stored preferences yet."
    m = re.match(r"^(?:how do you know|where did you (?:learn|get)|what(?:'s| is) your source for|why do you think) (?:that )?(.+?)\??$", t)
    if m:
        hits = recall(m.group(1), k=1, min_score=0.2, touch=False)
        if not hits:
            return "I don't have a stored note behind that."
        h = hits[0]
        return f"I have a note from {h['when']} ({h['ago']}), source: {h['source']}" + (f", reference {h['source_ref']}" if h["source_ref"] else "") + f", confidence {int(h['confidence'] * 100)} percent: {h['text']}"
    m = re.match(r"^(?:remember (?:as a )?preference|i prefer|from now on(?: please)?)[: ,]+(.+)$", t)
    if m and len(m.group(1)) > 6:
        r = preference_set(K.strip_wake(command).split(None, 1)[-1] if t.startswith("from now on") is False else m.group(1), "user")
        return "Noted that as a preference." if r["action"] in ("added", "superseded", "duplicate") else None
    m = re.match(r"^(?:project note|note for (?:the )?project|for (?:the )?project)\s+(.+?)[:,]\s*(?:(goal|progress|decision|unfinished|note)[:,]?\s*)?(.+)$", t)
    if m:
        project_note(m.group(1), m.group(3), m.group(2) or "note")
        return f"Added to the {m.group(1)} project."
    m = re.match(r"^(?:project status|status of (?:the )?project|where are we on (?:the )?project|show (?:the )?project)\s+(.+)$", t)
    if m:
        st = project_state(m.group(1))
        if not st["count"]:
            return f"I have nothing recorded for a project called {m.group(1)}."
        bits = []
        for k_, lab in (("goal", "goals"), ("progress", "progress"), ("decision", "decisions"), ("unfinished", "unfinished")):
            if st[k_]:
                bits.append(f"{lab}: " + "; ".join(re.sub(r'^\[\w+\]\s*', '', x['text']) for x in st[k_][-2:]))
        return f"Project {m.group(1)} (last updated {st['last']}). " + " ".join(bits)
    if t in ("show my projects", "list my projects", "what projects do i have"):
        ps = projects()
        return ("Projects on record: " + ", ".join(f"{p['project']} ({p['items']} notes)" for p in ps[:6]) + ".") if ps else "No projects recorded yet."
    m = re.match(r"^(?:correction|correct that|that(?:'s| is) not right)[: ,]+(?:it(?:'s| is) |actually )?(.+)$", t)
    if m and len(m.group(1)) > 5:
        r = correct(m.group(1), m.group(1))
        return "Corrected. I kept the old note as history." if r["ok"] else None
    return None


def ui_snapshot(query: str = "") -> Dict:
    items = recall(query, k=12, min_score=0.1, touch=False) if query else [_public(_row(r)) for r in C.q("SELECT * FROM mem7 WHERE status='active' ORDER BY updated DESC LIMIT 25")]
    counts = {r["kind"]: r["n"] for r in C.q("SELECT kind, COUNT(*) n FROM mem7 WHERE status='active' GROUP BY kind")}
    return {"items": items, "counts": counts, "projects": projects(), "episodes": episodes(5), "preferences": preferences(8)}
