"""FRIDAY 5.0 core (still the first layer in 6.0) - the single front door that ties the new layers together.

    perceive -> understand -> plan -> act -> observe -> verify -> learn

`pre_route(command)` runs first for every typed or spoken command and claims only what FRIDAY can answer or do
without the language model (confirmations, exact maths/units/time, memory + goals, system diagnosis, tools,
permissions, benchmark).  Everything else flows on unchanged to the existing handlers and the model, with the route
(fast / deep / research / agent), the retrieved memories and the file attachments attached by the backend.

`hud()` publishes a compact status line for the screen: core state, route, tool in use, task progress, confidence,
memories used.  It shows useful state, never private reasoning.
"""
from __future__ import annotations

import base64
import json
import re
import threading
import time
from typing import Callable, Dict, Optional

import friday_knowledge5 as kb5
import friday_router5 as router5
import friday_tools5 as tools5

_cfg: Dict[str, Callable] = {"speak": lambda t: None, "emit": lambda l: print(l, flush=True), "log": lambda m, k="core": None}
_hud: Dict = {"core": "Ready", "route": "", "tool": "", "task": "", "confidence": None, "memory": [], "vision": "", "latency_ms": None, "version": "7.0"}
_hud_lock = threading.Lock()
_turn = {"t0": 0.0, "route": "", "first_audio": None}
_stats = {"turns": 0, "instant": 0, "fast": 0, "deep": 0, "research": 0, "agent": 0, "latency": []}


def configure(**kw):
    _cfg.update({k: v for k, v in kw.items() if v is not None})


def hud(**fields):
    with _hud_lock:
        _hud.update(fields)
        payload = dict(_hud)
    try:
        _cfg["emit"]("FRIDAY_HUD::" + base64.b64encode(json.dumps(payload, ensure_ascii=False).encode("utf-8")).decode("ascii"))
    except Exception:
        pass


def hud_state() -> dict:
    with _hud_lock:
        return dict(_hud)


# ------------------------------------------------------------------ turn bookkeeping
def turn_start(command: str, route: str = ""):
    _turn.update(t0=time.perf_counter(), route=route, first_audio=None)
    _stats["turns"] += 1
    hud(core="Thinking", route=route or "", tool="", task=command[:80], confidence=None)


def note_first_audio():
    if _turn["t0"] and _turn["first_audio"] is None:
        _turn["first_audio"] = time.perf_counter()
        ms = round((_turn["first_audio"] - _turn["t0"]) * 1000)
        _stats["latency"] = (_stats["latency"] + [ms])[-30:]
        hud(core="Speaking", latency_ms=ms)


def turn_end():
    hud(core="Ready", tool="")


def count_route(route: str):
    if route in _stats:
        _stats[route] += 1


def avg_latency_ms() -> Optional[int]:
    l = _stats["latency"]
    return round(sum(l) / len(l)) if l else None


# ------------------------------------------------------------------ pre-route
def _say(text: str, route: str):
    count_route(route)
    hud(route=route)
    _cfg["speak"](text)
    turn_end()


def pre_route(command: str) -> bool:
    """True when handled (and already spoken)."""
    t = (command or "").strip()
    if not t:
        return False
    try:
        # 1. a yes/no to something FRIDAY asked permission for
        r = tools5.answer_confirmation(t)
        if r is not None:
            hud(core="Acting", tool="confirmation")
            _say(r, "agent")
            return True
        # 2. exact local answers: maths, units, time and date (no network, no model)
        r = router5.instant_answer(t)
        if r:
            _say(r, "instant")
            return True
        # 3. permissions, system diagnosis, file tools
        low = t.lower()
        r = tools5.handle(t)
        if r:
            hud(tool="system / files")
            _say(r, "agent")
            return True
        # 4. memory, knowledge base and goals
        r = kb5.handle(t)
        if r:
            hud(tool="memory", memory=[m["text"][:60] for m in kb5.all_memories(3)])
            _say(r, "instant")
            return True
        # 5. benchmark
        if re.match(r"^(?:run|start|do)\s+(?:a\s+|the\s+|your\s+)?(?:benchmark|self[- ]?test)(?:\s+(?:suite|on yourself))?$|^benchmark yourself$", low.strip(" .!?")):
            hud(core="Benchmarking", tool="benchmark")
            _cfg["speak"]("Running my benchmark. This takes a few seconds.")
            import friday_benchmark5 as bm
            res = bm.run_all()
            _say(bm.spoken_summary(res), "agent")
            return True
        if re.match(r"^(?:what(?:'s| is) )?(?:your|the) (?:version|build)\b|^which version are you$", low.strip(" .!?")):
            _say("I'm FRIDAY version 7.0.", "instant")
            return True
    except Exception as exc:
        _cfg["log"](f"Core5 pre-route fell through safely: {exc}", "recovery")
    return False


# ------------------------------------------------------------------ helpers used by ask_ai
def route_for(question: str, has_attachments: bool = False) -> dict:
    r = router5.classify(question, has_attachments)
    count_route(r["route"])
    hud(route=r["route"])
    return r


def memory_context(question: str) -> str:
    try:
        block = kb5.context_block(question)
        if block:
            hud(memory=[m["text"][:60] for m in kb5.search(question, k=3)])
        return block
    except Exception:
        return ""


def after_exchange(question: str, answer: str, route: str = "fast", ok: bool = True):
    """Learn: extract durable facts + record outcome of agent-style tasks. Always off the critical path."""
    def _w():
        try:
            kb5.extract_from_exchange(question, answer)
            if route in ("agent", "deep") and len(question) > 25:
                kb5.record_outcome(question, ok)
        except Exception:
            pass
    threading.Thread(target=_w, name="Friday5Learn", daemon=True).start()


def status() -> dict:
    return {"version": "7.0", "stats": dict(_stats), "avg_latency_ms": avg_latency_ms(), "knowledge": kb5.health(),
            "tools": tools5.tool_list(), "audit": tools5.recent_audit(5)}
