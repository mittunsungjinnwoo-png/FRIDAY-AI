# FRIDAY 6.0 - what changed, where it lives, and what is honestly limited

FRIDAY 6.0 = FRIDAY 5.0 (untouched core: listening, recognition, speaking, tools, memory, router) + a new layer built from the research
document "FRIDAY: The Ultimate AI Assistant". Every new command goes through one front door, `friday_core6.route()`, which runs right after the
5.0 core and only claims what it can do itself. Anything else flows on exactly as before.

**Not touched (byte-identical to 5.0):** `friday_voice5.py` (listening / recognition / mic capture) and `friday_speech5.py` (instant speaking).
Replies are still spoken the moment they appear in the chat. 6.0 only sets the same knobs those files already read (mic index, voice, rate, language).

Run the self-test any time: `python FRIDAY_TEST_V60.py` (43 checks, no mic / internet / API key needed). Say "run the evaluation" for the 19-check benchmark.

## Where each part of the document lives

| Document section | File | What you get |
|---|---|---|
| Personality, emotional state simulation, emotional memory, emotional reasoning, relationship continuity | `friday_emotion6.py` | Perception -> Memory -> Emotional state -> Reasoning -> Action -> Reflection. Seven decaying state variables change wording, reply length, humour and which memories are recalled first. Witty/calm by default, serious when it matters, "no jokes" / "more sarcastic" by voice. Remembers rough moments ("you were frustrated with the payment module yesterday"), learns how you like answers (length, technical level, projects, repeat slips). Always honest: the states are a simulation, never claimed as real suffering. |
| Memory (time-aware, semantic, reliable, controllable) | `friday_memory6.py` | Dated memories with source and status (confirmed / assumed / superseded), meaning-aware search, duplicate + conflict handling, importance scoring, knowledge graph, reminders/follow-ups, project continuity ("where did we leave off"), daily summaries, working memory, retention, export, encrypted export, correct/forget. Secrets are refused. |
| Autonomous tasks | `friday_tasks6.py` | Plan -> approved tools -> verify each step -> retry with a *different* strategy -> honest report (done / partial / failed). Dependencies, deadlines, priority queue, parallel steps, approval gates, cancel, emergency stop, loop + repeated-failure detection, checkpoints and crash recovery, history and logs. |
| Multi-agent | `friday_agents6.py` | Code, research, study, vision, planning, analysis, memory and verification agents. Automatic selection, parallel runs, conflict detection, independent review, escalation to the stronger model, and measured coordination cost. |
| Privacy, security, reliability | `friday_security6.py` | Tamper-evident audit chain, per-tool least-privilege permissions (shared with the 5.0 permission panel), prompt-injection defence for files / web / clipboard, dangerous-file checks, backups with safe restore, dependency scan, sensor indicators, failure watchdog, emergency stop. |
| Hybrid models, routing, speed, resources | `friday_perf6.py` | Cloud + optional local (Ollama) providers, task routing, fallback, circuit breaker, retries, cache, latency/reliability metrics, hardware profile, resource monitor. All internal model calls go through it. |
| Software engineering | `friday_engineer6.py` | Whole-codebase map, bug / security / complexity review, test generation + running, isolated code runs, build verification, minimal diff edits with rollback, git status/diff/log/branch/commit proposal, install-error diagnosis, generated documentation. |
| Science, maths, engineering | `friday_science6.py` | SymPy maths, calculus, statistics, t-tests, regression, uncertainty propagation, units + dimension checks, physics and chemistry helpers, equation balancing, theory-vs-experiment, reproducible notebooks. Every numeric answer is checked by a second method before it is spoken. |
| Research | `friday_research6.py` | Source grading, publication dates, fact / estimate / speculation labels, conflicting-claim comparison, cited reports, research notebook, open questions, follow-up experiments, topic watching. |
| Study and academic | `friday_study6.py` | Syllabus topics, past-paper bank, mark-scheme marking (only against marking points you supply), mistake tracker, spaced-repetition flashcards, revision priorities from real results, timed mock exams, analytics. |
| Productivity | `friday_productivity6.py` | Daily briefing, schedule (mirrored into the original calendar page), weekly summary, time tracking, contacts, meeting prep and notes, email drafting (opens your mail app; never sends), routines, activity search, folder organising (preview -> approve -> undo), trip plans. |
| Creativity | `friday_creative6.py` | .pptx / .docx / .pdf / .xlsx from an outline (with a review checkpoint first), flow diagrams (SVG + Mermaid), infographics, logo concepts, storyboards, proofreading, audience adaptation, brainstorming, image generation (Gemini image model), transcription, voice-over. |
| Vision + computer control | `friday_osint6.py` | Clipboard assistance (needs permission), desktop notifications, image comparison, visual error debugging from the screen, retry-with-recovery wrapper. Builds on the existing OpenCV vision engine. |
| Voice settings | `friday_voice6.py` | List / choose microphone, reset to default if she can't hear you, voice, speed, speaking style, optional multilingual conversation. |
| Integrations | `friday_integrations6.py` | Registry with scopes and "what can it access", time zones, maps, calendar .ics import/export, smart-home / IoT webhooks (permission + confirmation), encrypted token storage, sandboxed plugin loader (off until you enable; switches itself off if the file changes). |
| Self-improvement | `friday_eval6.py` | 19-check benchmark with history, regression tests from your corrections, failure analysis, versioned config snapshots + rollback, patch proposals that are tested on a *copy* and applied only with your approval and the `self_update` permission (auto-rollback on failure). FRIDAY never rewrites her own code on her own. |
| UI | `friday_v6_ui.js` + `index.html` | "Command Centre" page with 13 tabs (live tasks + approvals, memory browser, agents, emotion meters, permissions + audit, performance + model routing, research sources, study, productivity, engineering, integrations, evaluation), header mic indicator, emergency-stop button, hide/show conversation panel, customisable overview. |

## Honest limits (please read)
* I could not test with a real microphone, speaker, your Gemini key, or the packaged Electron app in my environment. What I did test: all 43 new checks, the 19-check benchmark, the real backend `process_command` with the 6.0 core loaded, the new UI in a headless browser against real data, and the original 5.0 test-suite (all still pass; three very old 2016/2021 voice tests fail identically on your original 5.0 zip, so they are not caused by 6.0).
* "Listens and recognises accurately" and "speaks as soon as the reply appears" are carried by the unchanged 5.0 voice code. Accuracy still depends on your microphone, room and the Google speech service; 6.0 adds mic selection and a one-phrase reset ("fix the microphone").
* Emotions are a behavioural simulation. FRIDAY will say so if asked.
* Study marking is only as good as the marking points you give her; she never invents an official mark scheme. Recognition for non-English speech depends on the speech service.
* Encrypted export / stored tokens need `pip install cryptography` (in requirements-optional.txt); without it tokens are stored un-encrypted in your local database and she tells you so.
* Image generation, research and model-written content need your Gemini key / internet. Everything else in 6.0 works offline.
* Safety-critical engineering, medical, legal or financial output still needs expert review.
