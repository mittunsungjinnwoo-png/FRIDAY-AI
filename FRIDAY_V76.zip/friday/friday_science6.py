"""FRIDAY 6.0 scientific, mathematical and engineering problem-solving (blueprint section 12).

Calculations are done by code, never "in the model's head": symbolic maths (SymPy), equation solving, calculus, statistics and
hypothesis tests, units and dimensional analysis, uncertainty / error propagation, physics and chemistry helpers, theory-versus-experiment
comparison and reproducible notebooks.  Every numeric result is double-checked by a second, independent method before it is spoken.
Safety-critical engineering results still need expert review and physical validation - FRIDAY says so.
"""
from __future__ import annotations

import json
import math
import re
import statistics as st
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import friday_common6 as C

try:
    import sympy as sp
except Exception:                                    # SymPy is optional; basic arithmetic still works through friday_router5
    sp = None

SAFETY_NOTE = "For safety-critical or real-world engineering work this still needs expert review and physical validation."


def _fmt(x) -> str:
    try:
        f = float(x)
        if abs(f - round(f)) < 1e-9 and abs(f) < 1e15:
            return str(int(round(f)))
        return f"{f:.6g}"
    except Exception:
        return str(x)


def _sympify(expr: str):
    expr = expr.replace("^", "**").replace("×", "*").replace("÷", "/")
    expr = re.sub(r"(?<=\d)\s*([a-zA-Z(])", r"*\1", expr)          # 2x -> 2*x
    from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application
    return parse_expr(expr, transformations=standard_transformations + (implicit_multiplication_application,), evaluate=True)


# ------------------------------------------------------------------ symbolic maths + verification
def solve_equation(text: str) -> Dict:
    if sp is None:
        return {"ok": False, "error": "SymPy is not installed (pip install sympy)"}
    t = text.replace("^", "**")
    if "=" in t:
        lhs, rhs = t.split("=", 1)
        eq = sp.Eq(_sympify(lhs), _sympify(rhs))
    else:
        eq = sp.Eq(_sympify(t), 0)
    syms = sorted(eq.free_symbols, key=lambda s: s.name)
    if not syms:
        return {"ok": True, "result": str(bool(eq)), "check": "direct evaluation"}
    var = syms[0]
    sols = sp.solve(eq, var)
    # independent verification: substitute each solution back and also solve numerically
    verified = all(abs(complex(sp.N(eq.lhs.subs(var, s) - eq.rhs.subs(var, s)))) < 1e-8 for s in sols if not s.free_symbols) if sols else False
    return {"ok": bool(sols), "variable": str(var), "solutions": [str(s) for s in sols], "numeric": [_fmt(sp.N(s)) if s.is_real else str(sp.N(s)) for s in sols if not s.free_symbols],
            "verified": verified, "check": "substituting back into the original equation"}


def derivative(expr: str, var: str = "x") -> Dict:
    e = _sympify(expr); v = sp.Symbol(var)
    d = sp.diff(e, v)
    h = 1e-5; pt = 1.3          # numeric cross-check by central difference at a sample point
    try:
        f = sp.lambdify(v, e, "math"); g = sp.lambdify(v, d, "math")
        ok = abs((f(pt + h) - f(pt - h)) / (2 * h) - g(pt)) < 1e-4 * max(1, abs(g(pt)))
    except Exception:
        ok = None
    return {"ok": True, "result": str(d), "verified": ok, "check": "central finite difference at x=1.3"}


def integral(expr: str, var: str = "x", a=None, b=None) -> Dict:
    e = _sympify(expr); v = sp.Symbol(var)
    if a is not None and b is not None:
        val = sp.integrate(e, (v, sp.sympify(a), sp.sympify(b)))
        try:
            from scipy import integrate as si
            f = sp.lambdify(v, e, "math")
            num = si.quad(f, float(sp.N(sp.sympify(a))), float(sp.N(sp.sympify(b))))[0]
            ok = abs(float(sp.N(val)) - num) < 1e-6 * max(1, abs(num))
        except Exception:
            ok = None
        return {"ok": True, "result": str(val), "numeric": _fmt(sp.N(val)), "verified": ok, "check": "numerical quadrature"}
    r = sp.integrate(e, v)
    back = sp.simplify(sp.diff(r, v) - e) == 0
    return {"ok": True, "result": str(r) + " + C", "verified": bool(back), "check": "differentiating the answer to recover the integrand"}


def simplify_expr(expr: str) -> Dict:
    return {"ok": True, "result": str(sp.simplify(_sympify(expr)))}


# ------------------------------------------------------------------ statistics
def describe(data: List[float]) -> Dict:
    n = len(data)
    if n == 0:
        return {"ok": False, "error": "no data"}
    m = st.fmean(data)
    sd = st.stdev(data) if n > 1 else 0.0
    return {"ok": True, "n": n, "mean": m, "median": st.median(data), "stdev": sd, "sem": sd / math.sqrt(n) if n > 1 else 0.0,
            "min": min(data), "max": max(data), "variance": st.variance(data) if n > 1 else 0.0}


def t_test(a: List[float], b: Optional[List[float]] = None, mu: float = 0.0, alpha: float = 0.05) -> Dict:
    """One-sample (vs mu) or Welch two-sample t-test. SciPy when present, otherwise an exact implementation of the same formula."""
    def welch(a, b):
        ma, mb, va, vb = st.fmean(a), st.fmean(b), st.variance(a), st.variance(b)
        na, nb = len(a), len(b)
        se = math.sqrt(va / na + vb / nb)
        t = (ma - mb) / se
        df = (va / na + vb / nb) ** 2 / ((va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1))
        return t, df
    if b is None:
        n = len(a); t = (st.fmean(a) - mu) / (st.stdev(a) / math.sqrt(n)); df = n - 1
    else:
        t, df = welch(a, b)
    try:
        from scipy import stats as ss
        p = float(2 * ss.t.sf(abs(t), df))
        check = None
        if b is None:
            check = float(ss.ttest_1samp(a, mu).pvalue)
        else:
            check = float(ss.ttest_ind(a, b, equal_var=False).pvalue)
        verified = abs(check - p) < 1e-6
    except Exception:
        p, verified = float("nan"), None
    return {"ok": True, "t": t, "df": df, "p": p, "significant": (p < alpha) if p == p else None, "alpha": alpha, "verified": verified,
            "reading": ("reject the null hypothesis" if p < alpha else "fail to reject the null hypothesis") + f" at the {int(alpha * 100)} percent level" if p == p else "p-value needs SciPy"}


def linear_fit(x: List[float], y: List[float]) -> Dict:
    n = len(x)
    mx, my = st.fmean(x), st.fmean(y)
    sxx = sum((a - mx) ** 2 for a in x); sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    m = sxy / sxx; c = my - m * mx
    ss_res = sum((b - (m * a + c)) ** 2 for a, b in zip(x, y)); ss_tot = sum((b - my) ** 2 for b in y) or 1e-12
    r2 = 1 - ss_res / ss_tot
    se_m = math.sqrt(ss_res / (n - 2) / sxx) if n > 2 else float("nan")
    try:
        import numpy as np
        chk = np.polyfit(x, y, 1); verified = abs(chk[0] - m) < 1e-8 and abs(chk[1] - c) < 1e-8
    except Exception:
        verified = None
    return {"ok": True, "slope": m, "intercept": c, "r2": r2, "slope_uncertainty": se_m, "verified": verified}


# ------------------------------------------------------------------ uncertainty / error propagation
def propagate(expr: str, values: Dict[str, Tuple[float, float]]) -> Dict:
    """Quadrature propagation  sigma_f^2 = sum (df/dxi)^2 sigma_i^2  using exact symbolic partial derivatives (independent inputs)."""
    e = _sympify(expr)
    syms = {s.name: s for s in e.free_symbols}
    sub = {syms[k]: v[0] for k, v in values.items() if k in syms}
    f0 = float(sp.N(e.subs(sub)))
    var = 0.0
    parts = {}
    for k, (val, sig) in values.items():
        if k in syms:
            d = float(sp.N(sp.diff(e, syms[k]).subs(sub)))
            parts[k] = abs(d * sig)
            var += (d * sig) ** 2
    sigma = math.sqrt(var)
    # Monte-Carlo cross-check
    try:
        import random
        f = sp.lambdify(list(syms.values()), e, "math")
        names = list(syms)
        samp = [f(*[random.gauss(*values[n]) if n in values else 0 for n in names]) for _ in range(4000)]
        mc = st.stdev(samp)
        ok = abs(mc - sigma) < 0.12 * max(sigma, 1e-12)
    except Exception:
        ok = None
    dom = max(parts, key=parts.get) if parts else ""
    return {"ok": True, "value": f0, "uncertainty": sigma, "relative_percent": (sigma / abs(f0) * 100) if f0 else float("inf"), "dominant": dom, "verified": ok, "check": "Monte-Carlo simulation (4000 samples)"}


# ------------------------------------------------------------------ units and dimensions
_DIM = {"m": (1, "L"), "km": (1000, "L"), "cm": (0.01, "L"), "mm": (0.001, "L"), "in": (0.0254, "L"), "ft": (0.3048, "L"), "mi": (1609.344, "L"),
        "kg": (1, "M"), "g": (0.001, "M"), "lb": (0.45359237, "M"), "s": (1, "T"), "min": (60, "T"), "h": (3600, "T"), "ms": (0.001, "T"),
        "n": (1, "MLT-2"), "kn": (1000, "MLT-2"), "j": (1, "ML2T-2"), "kj": (1000, "ML2T-2"), "cal": (4.184, "ML2T-2"), "kwh": (3.6e6, "ML2T-2"),
        "w": (1, "ML2T-3"), "kw": (1000, "ML2T-3"), "pa": (1, "ML-1T-2"), "kpa": (1000, "ML-1T-2"), "bar": (1e5, "ML-1T-2"), "atm": (101325, "ML-1T-2"),
        "m/s": (1, "LT-1"), "km/h": (1 / 3.6, "LT-1"), "mph": (0.44704, "LT-1"), "m/s2": (1, "LT-2"), "l": (0.001, "L3"), "ml": (1e-6, "L3"), "m3": (1, "L3"),
        "hz": (1, "T-1"), "v": (1, "ML2T-3I-1"), "a": (1, "I"), "ohm": (1, "ML2T-3I-2")}


def convert(value: float, a: str, b: str) -> Dict:
    ka, kb = a.lower().replace("²", "2").replace("³", "3"), b.lower().replace("²", "2").replace("³", "3")
    if ka in ("c", "f", "k", "°c", "°f") or kb in ("c", "f", "k", "°c", "°f"):
        def to_k(v, u):
            u = u.strip("°")
            return v + 273.15 if u == "c" else ((v - 32) * 5 / 9 + 273.15 if u == "f" else v)
        def from_k(v, u):
            u = u.strip("°")
            return v - 273.15 if u == "c" else ((v - 273.15) * 9 / 5 + 32 if u == "f" else v)
        return {"ok": True, "result": from_k(to_k(value, ka), kb)}
    if ka not in _DIM or kb not in _DIM:
        return {"ok": False, "error": f"unknown unit {a if ka not in _DIM else b}"}
    if _DIM[ka][1] != _DIM[kb][1]:
        return {"ok": False, "error": f"dimension mismatch: {a} is {_DIM[ka][1]}, {b} is {_DIM[kb][1]} - they can't be converted"}
    return {"ok": True, "result": value * _DIM[ka][0] / _DIM[kb][0], "dimension": _DIM[ka][1]}


def check_dimensions(lhs: str, rhs: str) -> Dict:
    ok = _DIM.get(lhs.lower(), (0, "?"))[1] == _DIM.get(rhs.lower(), (0, "?"))[1]
    return {"ok": ok, "lhs": _DIM.get(lhs.lower(), (0, "?"))[1], "rhs": _DIM.get(rhs.lower(), (0, "?"))[1]}


# ------------------------------------------------------------------ physics and chemistry
G = 9.80665


def projectile(v: float, angle_deg: float, h0: float = 0.0, g: float = G) -> Dict:
    a = math.radians(angle_deg)
    vy, vx = v * math.sin(a), v * math.cos(a)
    t = (vy + math.sqrt(vy * vy + 2 * g * h0)) / g
    return {"ok": True, "time_of_flight": t, "range": vx * t, "max_height": h0 + vy * vy / (2 * g), "impact_speed": math.sqrt(vx * vx + (vy - g * t) ** 2)}


def suvat(**k) -> Dict:
    """Give any three of s,u,v,a,t; returns the rest."""
    s, u, v, a, t = (k.get(x) for x in "suvat")
    known = sum(x is not None for x in (s, u, v, a, t))
    if known < 3:
        return {"ok": False, "error": "need three of s, u, v, a, t"}
    if a is None:
        a = (v - u) / t if (v is not None and u is not None and t) else ((2 * (s - u * t)) / t ** 2 if (s is not None and u is not None and t) else (v * v - u * u) / (2 * s))
    if u is None and v is not None and t is not None:
        u = v - a * t
    if u is None and s is not None and t is not None:
        u = s / t - a * t / 2
    if v is None:
        v = u + a * t if t is not None else math.sqrt(u * u + 2 * a * s)
    if t is None:
        t = (v - u) / a
    if s is None:
        s = u * t + 0.5 * a * t * t
    return {"ok": True, "s": s, "u": u, "v": v, "a": a, "t": t}


def ideal_gas(P=None, V=None, n=None, T=None) -> Dict:
    R = 8.314462618
    unknown = [k for k, x in (("P", P), ("V", V), ("n", n), ("T", T)) if x is None]
    if len(unknown) != 1:
        return {"ok": False, "error": "leave exactly one of P (Pa), V (m3), n (mol), T (K) unknown"}
    u = unknown[0]
    val = {"P": lambda: n * R * T / V, "V": lambda: n * R * T / P, "n": lambda: P * V / (R * T), "T": lambda: P * V / (n * R)}[u]()
    return {"ok": True, u: val}


def ohms(V=None, I=None, R=None) -> Dict:
    if V is None:
        return {"ok": True, "V": I * R, "P": I * I * R}
    if I is None:
        return {"ok": True, "I": V / R, "P": V * V / R}
    return {"ok": True, "R": V / I, "P": V * I}


_AW = {"H": 1.008, "He": 4.0026, "Li": 6.94, "Be": 9.0122, "B": 10.81, "C": 12.011, "N": 14.007, "O": 15.999, "F": 18.998, "Ne": 20.180, "Na": 22.990, "Mg": 24.305, "Al": 26.982,
       "Si": 28.085, "P": 30.974, "S": 32.06, "Cl": 35.45, "Ar": 39.948, "K": 39.098, "Ca": 40.078, "Ti": 47.867, "Cr": 51.996, "Mn": 54.938, "Fe": 55.845, "Co": 58.933, "Ni": 58.693,
       "Cu": 63.546, "Zn": 65.38, "Br": 79.904, "Ag": 107.87, "I": 126.90, "Ba": 137.33, "Au": 196.97, "Hg": 200.59, "Pb": 207.2, "U": 238.03}


def _parse_formula(f: str) -> Dict[str, int]:
    def parse(s: str, i=0):
        counts: Dict[str, int] = {}
        while i < len(s):
            c = s[i]
            if c == "(":
                sub, i = parse(s, i + 1)
                j = i
                while j < len(s) and s[j].isdigit():
                    j += 1
                mult = int(s[i:j] or 1)
                for k, v in sub.items():
                    counts[k] = counts.get(k, 0) + v * mult
                i = j
            elif c == ")":
                return counts, i + 1
            elif c.isupper():
                j = i + 1
                while j < len(s) and s[j].islower():
                    j += 1
                el = s[i:j]
                k = j
                while k < len(s) and s[k].isdigit():
                    k += 1
                counts[el] = counts.get(el, 0) + int(s[j:k] or 1)
                i = k
            else:
                i += 1
        return counts, i
    return parse(f.replace("·", ""))[0]


def molar_mass(formula: str) -> Dict:
    c = _parse_formula(formula)
    bad = [e for e in c if e not in _AW]
    if not c or bad:
        return {"ok": False, "error": f"unknown element {bad[0]}" if bad else "could not read the formula"}
    return {"ok": True, "formula": formula, "mass": sum(_AW[e] * n for e, n in c.items()), "composition": c}


def balance(equation: str) -> Dict:
    """Balance a chemical equation exactly (integer null-space of the element matrix), then verify atom counts on both sides."""
    if sp is None:
        return {"ok": False, "error": "SymPy needed"}
    l, r = [s.strip() for s in re.split(r"->|=|→", equation)]
    L = [x.strip() for x in l.split("+")]; R = [x.strip() for x in r.split("+")]
    comps = [_parse_formula(x) for x in L + R]
    els = sorted({e for c in comps for e in c})
    M = sp.Matrix([[(1 if i < len(L) else -1) * c.get(e, 0) for i, c in enumerate(comps)] for e in els])
    ns = M.nullspace()
    if len(ns) != 1:
        return {"ok": False, "error": "the equation cannot be balanced uniquely"}
    v = ns[0]
    lcm = sp.ilcm(*[sp.fraction(x)[1] for x in v])
    co = [int(x * lcm) for x in v]
    if any(c < 0 for c in co):
        co = [-c for c in co]
    ok = all(sum(co[i] * comps[i].get(e, 0) for i in range(len(L))) == sum(co[i] * comps[i].get(e, 0) for i in range(len(L), len(comps))) for e in els)
    fmt = lambda xs, cs: " + ".join((str(c) if c != 1 else "") + x for x, c in zip(xs, cs))
    return {"ok": ok, "balanced": fmt(L, co[:len(L)]) + " -> " + fmt(R, co[len(L):]), "verified": ok}


def compare_theory(theory: float, measured: float, sigma: float = 0.0) -> Dict:
    diff = measured - theory
    pct = diff / theory * 100 if theory else float("inf")
    sig = abs(diff) / sigma if sigma else None
    verdict = "consistent within uncertainty" if (sig is not None and sig <= 2) else ("a significant discrepancy" if sig is not None else ("close" if abs(pct) < 5 else "a notable difference"))
    return {"ok": True, "difference": diff, "percent": pct, "sigmas": sig, "verdict": verdict}


# ------------------------------------------------------------------ reproducible notebook
def make_notebook(title: str, code_cells: List[str], path: Optional[str] = None) -> str:
    cells = [{"cell_type": "markdown", "metadata": {}, "source": [f"# {title}\n", f"Generated by FRIDAY {C.VERSION} on {C.iso()}. Re-run every cell top to bottom to reproduce."]}]
    for c in code_cells:
        cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": c.splitlines(True)})
    nb = {"cells": cells, "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python"}}, "nbformat": 4, "nbformat_minor": 5}
    p = Path(path) if path else C.DATA_DIR / "outputs" / (re.sub(r"[^A-Za-z0-9_]+", "_", title)[:40] + ".ipynb")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(nb, indent=1), "utf-8")
    return str(p)


# ------------------------------------------------------------------ language front end
def _nums(s: str) -> List[float]:
    return [float(x) for x in re.findall(r"-?\d+(?:\.\d+)?(?:e-?\d+)?", s)]


def _speak(r: Dict, label: str = "") -> str:
    if not r.get("ok"):
        return "I couldn't do that: " + str(r.get("error", "no solution found")) + "."
    chk = ""
    if r.get("verified") is True:
        chk = f" Checked by {r.get('check', 'a second method')}."
    elif r.get("verified") is False:
        chk = " Warning: my independent check disagreed, so treat this with caution."
    return label + chk


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if low.startswith("convert "):                      # the app's symbol normaliser turns "km/h" into "km or h"; put the slash back
        low = re.sub(r"(?<=[a-z°]) or (?=[a-z]{1,3}\b)", "/", low)
    try:
        m = re.match(r"^(?:please )?(?:solve|find x in|find the roots of)\s+(.+)$", low)
        if m and sp is not None and re.search(r"[a-z]", re.sub(r"\b(?:for|x|y|z)\b", "", m.group(1))) is None or (m and sp is not None and re.search(r"[xyzt]", m.group(1)) and re.search(r"[\d=]", m.group(1)) and len(m.group(1)) < 80):
            body = re.sub(r"\s+for\s+[xyzt]$", "", m.group(1))
            r = solve_equation(body)
            if r.get("ok"):
                return _speak(r, f"{r['variable']} equals " + " or ".join(r["numeric"] or r["solutions"]) + ".")
            return _speak(r)
        m = re.match(r"^(?:differentiate|derivative of|what(?:'s| is) the derivative of|d/dx of)\s+(.+?)(?: with respect to ([a-z]))?$", low)
        if m and sp is not None:
            r = derivative(m.group(1), m.group(2) or "x")
            return _speak(r, "The derivative is " + r["result"] + ".")
        m = re.match(r"^(?:integrate|integral of|what(?:'s| is) the integral of)\s+(.+?)(?: from (-?[\d\.]+) to (-?[\d\.]+))?$", low)
        if m and sp is not None:
            r = integral(m.group(1), "x", m.group(2), m.group(3))
            return _speak(r, "The integral is " + (r.get("numeric") or r["result"]) + ("" if r.get("numeric") else ".") + ("." if r.get("numeric") else ""))
        m = re.match(r"^(?:simplify|expand|factori[sz]e)\s+(.+)$", low)
        if m and sp is not None:
            return "That simplifies to " + simplify_expr(m.group(1))["result"] + "."
        m = re.match(r"^(?:what(?:'s| is) the |calculate the |find the |work out the )?(?:mean|average|median|standard deviation|stdev|describe|statistics?)(?: of| for)?\s*[:\-]?\s*([\d\.,\s\-]+)$", low)
        if m:
            d = _nums(m.group(1))
            r = describe(d)
            return _speak(r, f"{r['n']} values: mean {_fmt(r['mean'])}, median {_fmt(r['median'])}, standard deviation {_fmt(r['stdev'])}, standard error {_fmt(r['sem'])}.") if r["ok"] else _speak(r)
        m = re.match(r"^(?:t[- ]?test|test the hypothesis)(?: of| on| for)?\s*([\d\.,\s\-]+?)(?:\s+(?:against|vs|versus|and)\s+([\d\.,\s\-]+))?(?:\s+(?:with|mean|mu)\s+([\d\.\-]+))?$", low)
        if m:
            a = _nums(m.group(1)); b = _nums(m.group(2)) if m.group(2) else None
            r = t_test(a, b, float(m.group(3)) if m.group(3) else 0.0)
            return _speak(r, f"t equals {_fmt(r['t'])} with {_fmt(r['df'])} degrees of freedom, p equals {_fmt(r['p'])}. I {r['reading']}.")
        m = re.match(r"^convert\s+(-?[\d\.]+)\s*([a-z°/23]+)\s+(?:to|into|in)\s+([a-z°/23]+)$", low)
        if m:
            r = convert(float(m.group(1)), m.group(2), m.group(3))
            return (f"{m.group(1)} {m.group(2)} is {_fmt(r['result'])} {m.group(3)}." if r["ok"] else _speak(r))
        m = re.match(r"^molar mass of\s+([A-Za-z0-9\(\)·]+)$", t.strip(" .!?"), re.I) or re.match(r"^what(?:'s| is) the molar mass of\s+([A-Za-z0-9\(\)]+)$", t.strip(" .!?"), re.I)
        if m:
            r = molar_mass(m.group(1))
            return f"The molar mass of {m.group(1)} is {r['mass']:.3f} grams per mole." if r["ok"] else _speak(r)
        m = re.match(r"^balance(?: the equation| this equation)?[: ]+(.+)$", t, re.I)
        if m:
            r = balance(m.group(1))
            return ("Balanced: " + r["balanced"] + ". Atoms counted on both sides to verify.") if r["ok"] else _speak(r)
        m = re.match(r"^projectile(?: launched)? (?:at )?(-?[\d\.]+)\s*(?:m/s)?\s*(?:at|and)\s*(-?[\d\.]+)\s*degrees?(?: from (?:a )?height(?: of)? ([\d\.]+))?", low)
        if m:
            r = projectile(float(m.group(1)), float(m.group(2)), float(m.group(3) or 0))
            return f"Time of flight {r['time_of_flight']:.2f} seconds, range {r['range']:.1f} metres, maximum height {r['max_height']:.1f} metres. " + "Ignoring air resistance."
        m = re.match(r"^(?:propagate|error propagation|uncertainty)(?: of| in| for)?\s+(.+?)\s+(?:with|where)\s+(.+)$", t, re.I)
        if m and sp is not None:
            vals = {}
            for nm, v, s in re.findall(r"([a-zA-Z]\w*)\s*=\s*(-?[\d\.]+)\s*(?:±|\+/-|\+-|plus or minus)\s*([\d\.]+)", m.group(2)):
                vals[nm] = (float(v), float(s))
            if vals:
                r = propagate(m.group(1), vals)
                return _speak(r, f"The result is {_fmt(r['value'])} plus or minus {_fmt(r['uncertainty'])}, that's {r['relative_percent']:.1f} percent; the biggest contributor is {r['dominant']}.")
        m = re.match(r"^compare (?:theory|theoretical) (-?[\d\.]+) (?:with|to|and|against) (?:measured|experiment(?:al)?|result) (-?[\d\.]+)(?:\s+(?:with|±|uncertainty|\+/-)?\s*([\d\.]+))?", low)
        if m:
            r = compare_theory(float(m.group(1)), float(m.group(2)), float(m.group(3) or 0))
            return f"The measurement differs from theory by {r['percent']:.2f} percent" + (f", {r['sigmas']:.1f} standard deviations" if r["sigmas"] is not None else "") + f": {r['verdict']}."
    except Exception as exc:
        return f"I couldn't work that out cleanly ({type(exc).__name__}). Try writing the expression with explicit operators, for example 2*x + 3 = 11."
    return None
