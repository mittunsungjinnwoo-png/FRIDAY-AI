"""
FRIDAY V2036 OFFLINE NOTES LIBRARY
----------------------------------
When the live research / Gemini structuring step cannot run (no API key, no
internet, quota, malformed model output ...) FRIDAY used to fall back to an
empty "best-effort" template.  This module replaces that template with real,
curated study notes for the topics it knows well, complete with diagram specs
that friday_notes_diagrams.py draws as actual pictures.

Public API
    lookup(topic, syllabus_name="", syllabus_year="") -> dict | None
        Returns a `sections` dict in exactly the schema that
        friday_notes_engine.build_gorgeous_notes() already accepts, or None
        when the topic is not in the library (the caller must then say so
        honestly instead of producing a hollow sheet).
    covered_topics() -> list[str]

Currently covered: sp3 / sp2 / sp hybridisation (bonding chemistry), plus the
general "hybridisation" overview.  Add more packs by writing another builder
and registering it in _PACKS.
"""
from __future__ import annotations

import re

_LIB_SOURCE = ("FRIDAY built-in offline reference library (curated, exam-style). "
               "No live web research was used - cross-check against your syllabus PDF.")


# --------------------------------------------------------------------------- shared data
_COMPARE_HYBRIDS = {
    "title": "sp3 vs sp2 vs sp - side-by-side",
    "columns": ["Feature", "sp3", "sp2", "sp"],
    "rows": [
        ["Orbitals mixed", "1 s + 3 p", "1 s + 2 p", "1 s + 1 p"],
        ["Hybrid orbitals formed", "4", "3", "2"],
        ["Unhybridised p orbitals left", "0", "1", "2"],
        ["s-character / p-character", "25% / 75%", "33% / 67%", "50% / 50%"],
        ["Regions of electron density", "4", "3", "2"],
        ["Arrangement / bond angle", "tetrahedral, 109.5 degrees", "trigonal planar, 120 degrees", "linear, 180 degrees"],
        ["Bonds made", "sigma only", "sigma + one pi", "sigma + two pi"],
        ["Typical carbon bond length (C-C type)", "0.154 nm (C-C)", "0.134 nm (C=C)", "0.120 nm (C#C)"],
        ["Examples", "CH4, C2H6, NH3, H2O", "C2H4, BF3, C6H6, C=O carbon", "C2H2, CO2, HCN, BeCl2"],
    ],
}

_COMPARE_SP3_MOLECULES = {
    "title": "Same hybridisation, different angle: lone pairs",
    "columns": ["Molecule", "Bonding pairs", "Lone pairs", "Shape", "Bond angle"],
    "rows": [
        ["CH4 (C is sp3)", "4", "0", "tetrahedral", "109.5 degrees"],
        ["NH3 (N is sp3)", "3", "1", "pyramidal (trigonal pyramidal)", "107 degrees"],
        ["H2O (O is sp3)", "2", "2", "bent (V-shaped)", "104.5 degrees"],
    ],
}


def _energy_spec(kind):
    if kind == "sp3":
        third = {"title": "sp3 hybrids", "levels": [{"label": "sp3", "energy": 0.62, "boxes": [1, 1, 1, 1]}]}
    elif kind == "sp2":
        third = {"title": "sp2 hybrids + 1 p", "levels": [
            {"label": "2p", "energy": 1.0, "boxes": [1]},
            {"label": "sp2", "energy": 0.62, "boxes": [1, 1, 1]}]}
    else:
        third = {"title": "sp hybrids + 2 p", "levels": [
            {"label": "2p", "energy": 1.0, "boxes": [1, 1]},
            {"label": "sp", "energy": 0.55, "boxes": [1, 1]}]}
    mix = {"sp3": "mix 1 s + 3 p", "sp2": "mix 1 s + 2 p", "sp": "mix 1 s + 1 p"}[kind]
    return {
        "kind": "energy",
        "title": "Orbital box diagram: ground state -> promotion -> hybridisation",
        "caption": "Follow the arrows left to right. Promotion moves ONE electron up so carbon has four unpaired "
                   "electrons; mixing then makes hybrid orbitals of equal energy between 2s and 2p.",
        "columns": [
            {"title": "Ground state C", "levels": [
                {"label": "2p", "energy": 1.0, "boxes": [1, 1, 0]},
                {"label": "2s", "energy": 0.0, "boxes": [2]}]},
            {"title": "After promotion", "levels": [
                {"label": "2p", "energy": 1.0, "boxes": [1, 1, 1]},
                {"label": "2s", "energy": 0.0, "boxes": [1]}]},
            third,
        ],
        "transitions": ["promote one 2s electron into empty 2p", mix],
    }


# --------------------------------------------------------------------------- sp3 pack
def _sp3(syllabus_name, syllabus_year, overview=False):
    title = "Hybridisation: sp3, sp2 and sp" if overview else "How sp3 Orbitals Are Formed"
    return {
        "chapter_title": title,
        "subject_line": f"{syllabus_name} {syllabus_year} | Chemical bonding | sp3 hybridisation".replace("  ", " ").strip(),
        "what_is": ("sp3 hybridisation is the model in which ONE 2s orbital and THREE 2p orbitals of the same atom mix to "
                    "form FOUR new, identical sp3 hybrid orbitals. Each is 25% s-character and 75% p-character, has one big "
                    "lobe and one small back lobe, and the four point to the corners of a tetrahedron, 109.5 degrees apart. "
                    "Each sp3 orbital either overlaps head-on with another orbital to make a sigma bond, or holds a lone pair."),
        "topic_coverage": [
            "Why carbon has to hybridise: 2s2 2p2 gives only two unpaired electrons, yet carbon forms four bonds",
            "Promotion of one 2s electron into the empty 2p orbital",
            "Mixing 1 s + 3 p orbitals -> 4 equivalent sp3 orbitals (25% s, 75% p)",
            "Why the angle is 109.5 degrees: four electron regions repel to maximum separation",
            "Sigma bond formation by head-on overlap: C-H in CH4, C-C in C2H6",
            "sp3 atoms with lone pairs: NH3 (107 degrees), H2O (104.5 degrees)",
            "Quick rule for exam questions: 4 regions of electron density = sp3",
            "Comparison with sp2 and sp, and how hybridisation changes in reactions",
        ],
        "key_points": [
            "Carbon ground state is 1s2 2s2 2p2 - only 2 unpaired electrons, but methane needs 4 bonds.",
            "One 2s electron is promoted to the empty 2p orbital: 2s1 2p3 (4 unpaired electrons).",
            "1 s + 3 p atomic orbitals mix to give 4 sp3 hybrid orbitals: the number of orbitals is conserved.",
            "The 4 sp3 orbitals are equivalent (same energy, same shape) and point tetrahedrally at 109.5 degrees.",
            "sp3 orbitals form sigma bonds by head-on overlap (or hold lone pairs) - never pi bonds.",
            "Count regions of electron density on the atom: 4 = sp3, 3 = sp2, 2 = sp.",
            "Lone pairs sit in sp3 orbitals too, so N in NH3 and O in H2O are sp3 even though the angles shrink.",
        ],
        "equation_items": [
            {"formula": "1 s + 3 p -> 4 sp3",
             "meaning": "4 atomic orbitals in, 4 hybrid orbitals out (orbitals are conserved). Each hybrid = 1/4 s + 3/4 p = 25% s, 75% p."},
            {"formula": "4 regions = sp3",
             "meaning": "Regions of electron density = sigma bonds + lone pairs on the atom. A double or triple bond still counts as ONE region."},
        ],
        "requirements": [
            "Only orbitals of similar energy on the SAME atom can mix (here 2s and 2p).",
            "The atom needs four regions of electron density (bonding pairs + lone pairs).",
            "Hybrid orbitals form when the atom bonds - it is a model to explain observed shapes, not a separate real step.",
        ],
        "process_items": [
            {"title": "HOW SP3 ORBITALS FORM (CARBON)", "steps": [
                {"title": "Ground state", "explanation": "C is 1s2 2s2 2p2: the 2s box is full, two 2p orbitals hold one electron each, one 2p is empty. Only 2 unpaired electrons would mean only 2 bonds."},
                {"title": "Promotion", "explanation": "One 2s electron is promoted into the empty 2p orbital: 2s1 2p3, four unpaired electrons. This costs energy, but forming two extra bonds releases much more."},
                {"title": "Hybridisation", "explanation": "The 2s and three 2p orbitals mix into four identical sp3 orbitals of equal energy (between 2s and 2p). Each holds one electron."},
                {"title": "Geometry", "explanation": "Four regions of negative charge repel to maximum separation: tetrahedral, 109.5 degrees apart."},
                {"title": "Overlap", "explanation": "Each sp3 lobe overlaps head-on with an orbital of another atom (H 1s, or another C sp3). The shared pair between the nuclei is a sigma bond."},
            ]},
            {"title": "EXAM METHOD: IS THIS ATOM sp3?", "steps": [
                {"title": "Draw it", "explanation": "Show every bond and lone pair on the atom (displayed formula or dot-and-cross)."},
                {"title": "Count regions", "explanation": "Add sigma bonds + lone pairs. A double or triple bond counts as ONE region (only its sigma bond)."},
                {"title": "Match", "explanation": "4 regions = sp3, 3 regions = sp2, 2 regions = sp."},
                {"title": "Shape and angle", "explanation": "Name the shape from bonding pairs only: 4 bp tetrahedral 109.5; 3 bp + 1 lp pyramidal 107; 2 bp + 2 lp bent 104.5."},
            ]},
        ],
        "key_ideas": [
            {"name": "Why carbon must hybridise",
             "explanation": "Ground-state carbon (2s2 2p2) has two unpaired electrons and would form only two bonds at 90 degrees. Experiment shows CH4 has four identical C-H bonds at 109.5 degrees. Promotion plus hybridisation gives four equivalent singly-occupied orbitals that explain this."},
            {"name": "Promotion energy is repaid",
             "explanation": "Moving a 2s electron to 2p costs energy. It is worth it because two extra covalent bonds form, and each bond releases energy. Overall the molecule is far more stable."},
            {"name": "s-character controls bond properties",
             "explanation": "sp3 is 25% s. More s-character keeps electrons closer to the nucleus, so bonds get shorter and stronger and the carbon more electronegative in the order sp > sp2 > sp3. Compare C-C 0.154 nm, C=C 0.134 nm, C#C 0.120 nm."},
            {"name": "Sigma bonds from sp3 orbitals",
             "explanation": "The large lobe overlaps head-on along the line between the nuclei, giving electron density concentrated on the bond axis. This is a sigma bond. It is cylindrically symmetrical, so the groups can rotate freely about a single bond."},
            {"name": "Why 109.5 degrees",
             "explanation": "Four electron regions around one atom repel each other equally. The arrangement of greatest separation is a tetrahedron, giving 109.5 degrees. This is why methane and every sp3 carbon with four identical groups is tetrahedral."},
            {"name": "Lone pairs in sp3 orbitals",
             "explanation": "N in NH3 (2s2 2p3) and O in H2O (2s2 2p4) also form four sp3 orbitals; some hold lone pairs. Lone pairs are held closer to the nucleus and repel more strongly: lp-lp > lp-bp > bp-bp. So angles shrink to 107 (NH3) and 104.5 degrees (H2O)."},
            {"name": "Ethane: sp3-sp3 overlap",
             "explanation": "Each carbon in C2H6 is sp3. One sp3-sp3 overlap forms the C-C sigma bond and six sp3(C)-1s(H) overlaps form the C-H sigma bonds: 7 sigma bonds, no pi bonds. Each carbon is tetrahedral at about 109.5 degrees."},
            {"name": "Where sp3 appears",
             "explanation": "Saturated carbons in alkanes, alcohols, halogenoalkanes, amines; N in NH3 and NH4+; O in H2O, H3O+ and alcohols; every carbon in diamond (giant covalent, four sigma bonds each); C in CCl4."},
            {"name": "Hybridisation changes in reactions",
             "explanation": "When ethene reacts with H2 to give ethane, each carbon changes from sp2 (3 regions, 120 degrees) to sp3 (4 regions, 109.5 degrees). Addition to a double bond turns sp2 carbons into sp3 carbons."},
            {"name": "It is a model",
             "explanation": "Hybridisation is a way of explaining measured shapes and bond angles using orbitals. Say 'the orbitals hybridise' or 'mix' - never that the electrons hybridise."},
        ],
        "diagrams": [
            {"kind": "flow", "title": "Carbon: ground state to four sp3 bonds",
             "caption": "The five stages you must be able to state in order in an exam answer.",
             "nodes": [
                 {"label": "Ground state", "detail": "2s2 2p2: only 2 unpaired electrons"},
                 {"label": "Promotion", "detail": "one 2s electron moves to empty 2p: 2s1 2p3"},
                 {"label": "Hybridisation", "detail": "1 s + 3 p mix -> 4 equivalent sp3 orbitals"},
                 {"label": "Tetrahedral layout", "detail": "4 orbitals repel to 109.5 degrees"},
                 {"label": "Sigma overlap", "detail": "head-on overlap with H 1s gives 4 C-H sigma bonds"}]},
            _energy_spec("sp3"),
            {"kind": "lobes", "title": "The four sp3 hybrid orbitals (schematic)",
             "caption": "Each hybrid has one large lobe pointing at a bonding partner and a small back lobe. Solid lobes point towards you, dashed lobes point away (drawn as a tetrahedron seen from one side).",
             "angles": [45, 135, 225, 315], "back": [1, 3], "labels": ["sp3", "sp3", "sp3", "sp3"], "center": "C"},
            {"kind": "molecule3d", "title": "Methane, CH4: wedge-and-dash structure",
             "caption": "Solid line = in the plane of the paper, solid wedge = towards you, dashed wedge = away from you. Four C-H sigma bonds, H-C-H = 109.5 degrees.",
             "shape": "tetrahedral", "center": "C", "substituents": ["H", "H", "H", "H"], "angle_label": "H-C-H = 109.5 degrees"},
            {"kind": "hub", "title": "sp3 hybridisation: concept map", "center": "sp3",
             "caption": "Everything you need to link together for one sp3 answer.",
             "nodes": [
                 {"label": "Formation", "detail": "1 s + 3 p -> 4 orbitals"},
                 {"label": "Character", "detail": "25% s, 75% p"},
                 {"label": "Geometry", "detail": "tetrahedral, 109.5 degrees"},
                 {"label": "Bonding", "detail": "head-on overlap = sigma bonds"},
                 {"label": "Lone pairs", "detail": "NH3 107 deg, H2O 104.5 deg"},
                 {"label": "Examples", "detail": "CH4, C2H6, NH4+, diamond"}]},
        ],
        "worked_examples": [
            {"question": "Describe how sp3 hybrid orbitals are formed in a carbon atom and how they bond in methane. [4 marks]",
             "answer": "Carbon 1s2 2s2 2p2: one 2s electron is promoted to the empty 2p (2s1 2p3). The 2s and three 2p orbitals mix to give four equivalent sp3 orbitals, each with one electron, arranged tetrahedrally at 109.5 degrees. Each overlaps head-on with an H 1s orbital, giving four C-H sigma bonds."},
            {"question": "State the hybridisation of nitrogen in NH3 and explain why the H-N-H angle is 107 degrees, not 109.5. [3 marks]",
             "answer": "N has 3 bonding pairs + 1 lone pair = 4 regions, so N is sp3. The lone pair is closer to N and repels bonding pairs more strongly than bond pairs repel each other (lp-bp > bp-bp), squeezing the angle to about 107 degrees."},
            {"question": "Give the hybridisation of each carbon in CH3-CH=CH-C#CH, counting from the CH3 end. [2 marks]",
             "answer": "CH3 = sp3 (4 regions); CH= and =CH = sp2 (3 regions each); C# and #CH = sp (2 regions each). So: sp3, sp2, sp2, sp, sp."},
            {"question": "Ethene is hydrogenated to ethane. State the change in hybridisation of each carbon and in the bond angle. [2 marks]",
             "answer": "Each carbon changes from sp2 to sp3 (3 regions to 4 regions). The bond angle changes from 120 to 109.5 degrees, and the shape at each carbon from trigonal planar to tetrahedral."},
        ],
        "common_mistakes": [
            "Saying 'electrons hybridise'. It is the ORBITALS that mix; electrons just occupy the new orbitals.",
            "Skipping the promotion step. Without it carbon has only two unpaired electrons and cannot make four bonds.",
            "Writing that sp3 comes from '1 s and 4 p' or '3 s and 1 p'. It is 1 s + 3 p (the name sp3 = one s, three p).",
            "Giving 109.5 degrees for NH3 or H2O. They are sp3 but lone-pair repulsion reduces the angles to 107 and 104.5 degrees.",
            "Confusing hybridisation with shape. sp3 counts electron regions (including lone pairs); the shape name (pyramidal, bent) counts only bonding pairs.",
            "Counting a double bond as two regions. For hybridisation a double or triple bond is ONE region.",
            "Saying sp3 orbitals form pi bonds. Pi bonds need unhybridised p orbitals overlapping side-on; sp3 gives sigma bonds only.",
        ],
        "exam_tips": [
            "'Explain the formation of sp3 orbitals' earns marks for: promotion, mixing 1 s + 3 p, four equivalent orbitals, tetrahedral 109.5 degrees, head-on overlap. Hit each one.",
            "Quote numbers: '1 s + 3 p -> 4 sp3', '109.5 degrees', '25% s-character' - vague answers lose marks.",
            "Use the phrases 'head-on overlap' and 'sigma bond'; for lone pairs use 'lone pair repels more than bonding pair'.",
            "Draw energy-level boxes with an energy axis and arrows for electrons; put the sp3 level between 2s and 2p.",
            "Draw methane with wedge and dash and label the 109.5 degree angle.",
            "'Describe' asks WHAT happens; 'explain' asks WHY - add the reason (minimise repulsion, form more bonds).",
        ],
        "vocabulary": [
            {"term": "Hybridisation", "meaning": "Mixing of atomic orbitals of one atom to form new hybrid orbitals of equal energy."},
            {"term": "Hybrid orbital", "meaning": "New orbital made by mixing s and p orbitals; here sp3 = one large lobe + a small back lobe."},
            {"term": "Promotion", "meaning": "Moving an electron to a higher-energy empty orbital in the same atom (2s to 2p) to gain unpaired electrons."},
            {"term": "Degenerate / equivalent", "meaning": "Orbitals with exactly the same energy and shape, like the four sp3 orbitals."},
            {"term": "Sigma (sigma) bond", "meaning": "Bond formed by head-on overlap, electron density on the line between the nuclei."},
            {"term": "Tetrahedral", "meaning": "Four groups at the corners of a tetrahedron, 109.5 degrees apart."},
            {"term": "Lone pair", "meaning": "Non-bonding pair of outer electrons; occupies a hybrid orbital and repels strongly."},
            {"term": "s-character", "meaning": "Fraction of an s orbital in a hybrid (sp3 = 25%). More s = shorter, stronger bond."},
        ],
        "quick_facts": [
            "Carbon: 1s2 2s2 2p2 (ground) -> 2s1 2p3 (promoted) -> four sp3, one electron each.",
            "sp3 = 25% s, 75% p; sp2 = 33% s; sp = 50% s.",
            "Tetrahedral angle = 109.5 degrees (CH4, C2H6 at each carbon).",
            "Ethane has 7 sigma bonds: 1 C-C + 6 C-H, no pi bonds.",
            "N in NH3 and NH4+ is sp3; O in H2O and H3O+ is sp3.",
            "Every carbon in diamond is sp3 with four sigma bonds.",
            "Bond lengths: C-C 0.154 nm, C=C 0.134 nm, C#C 0.120 nm.",
        ],
        "exam_keywords": ["promotion", "hybridisation", "equivalent orbitals", "tetrahedral", "109.5 degrees",
                          "head-on overlap", "sigma bond", "regions of electron density", "lone pair repulsion", "s-character"],
        "memory_hook": "Count the regions: 4 = sp3 (109.5), 3 = sp2 (120), 2 = sp (180). The small number after 'sp' is how many p orbitals were mixed with the one s.",
        "summary_points": [
            "sp3 = one 2s + three 2p orbitals mixed into four equivalent hybrid orbitals.",
            "Carbon needs promotion (2s to 2p) first so that it has four unpaired electrons.",
            "The four orbitals point tetrahedrally, 109.5 degrees apart, to minimise repulsion.",
            "They overlap head-on to form sigma bonds (CH4 has four C-H sigma bonds; C2H6 has seven sigma bonds).",
            "Lone pairs occupy sp3 orbitals as well, which is why NH3 and H2O are sp3 but with smaller angles.",
            "Shortcut: four regions of electron density means sp3.",
            "sp3 -> sp2 -> sp: more s-character, wider angle, shorter and stronger bond.",
        ],
        "key_points_to_remember": [],
        "reference_outline": [
            {"number": 1, "title": "What is sp3 hybridisation?",
             "content": "Mixing one s and three p orbitals of the same atom to form four identical sp3 orbitals pointing to the corners of a tetrahedron.",
             "bullets": ["4 orbitals in = 4 orbitals out", "25% s, 75% p", "109.5 degrees apart"]},
            {"number": 2, "title": "Why does carbon hybridise?",
             "content": "Ground-state carbon cannot explain four identical bonds in methane.",
             "bullets": ["1s2 2s2 2p2 = 2 unpaired electrons", "CH4 has 4 equal C-H bonds", "hybrids give 4 unpaired electrons in equivalent orbitals"]},
            {"number": 3, "title": "Step-by-step formation",
             "content": "Follow the same order in every answer.",
             "bullets": ["1 promote a 2s electron to 2p", "2 mix 2s + 2px + 2py + 2pz", "3 four sp3 orbitals, 1 electron each", "4 overlap head-on with H 1s"]},
            {"number": 4, "title": "Shape and angle",
             "content": "Four electron regions repel equally, so they sit at the corners of a tetrahedron.",
             "bullets": ["tetrahedral", "109.5 degrees", "each hybrid: big lobe + small back lobe"]},
            {"number": 5, "title": "Bonding: sigma only",
             "content": "sp3 orbitals overlap end-on (head-on), giving sigma bonds with electron density on the bond axis.",
             "bullets": ["CH4: 4 sigma C-H", "C2H6: 1 sigma C-C + 6 sigma C-H", "free rotation about single bonds"]},
            {"number": 6, "title": "sp3 with lone pairs",
             "content": "Lone pairs fill sp3 orbitals and repel harder than bonding pairs.",
             "bullets": ["NH3: 3 bp + 1 lp, 107 degrees", "H2O: 2 bp + 2 lp, 104.5 degrees", "lp-lp > lp-bp > bp-bp"]},
            {"number": 7, "title": "Where you will meet it",
             "content": "Any atom with four regions of electron density.",
             "bullets": ["alkanes, alcohols, halogenoalkanes", "NH3, NH4+, H2O, H3O+", "diamond, CCl4"]},
            {"number": 8, "title": "Quick identification rule",
             "content": "Count sigma bonds plus lone pairs on the atom (multiple bonds count once).",
             "bullets": ["4 = sp3", "3 = sp2", "2 = sp"]},
        ],
        "comparison_tables": [_COMPARE_HYBRIDS, _COMPARE_SP3_MOLECULES],
        "sources": [_LIB_SOURCE],
        "footer_line": "Promote, mix, point tetrahedrally, overlap head-on.",
        "_offline_library": True,
    }


# --------------------------------------------------------------------------- sp2 pack
def _sp2(syllabus_name, syllabus_year):
    return {
        "chapter_title": "How sp2 Orbitals Are Formed",
        "subject_line": f"{syllabus_name} {syllabus_year} | Chemical bonding | sp2 hybridisation".replace("  ", " ").strip(),
        "what_is": ("sp2 hybridisation is the model in which ONE 2s orbital and TWO 2p orbitals mix to form THREE identical sp2 "
                    "hybrid orbitals (33% s, 67% p) lying in one plane, 120 degrees apart. The third 2p orbital is left "
                    "unhybridised, perpendicular to that plane. sp2 orbitals form sigma bonds; the leftover p orbitals overlap "
                    "side-on to form a pi bond, giving a double bond (1 sigma + 1 pi)."),
        "topic_coverage": [
            "Promotion of a 2s electron and mixing of 1 s + 2 p orbitals",
            "Three equivalent sp2 orbitals in a plane at 120 degrees (trigonal planar)",
            "The unhybridised p orbital and pi bond formation by side-on overlap",
            "Ethene: 5 sigma bonds + 1 pi bond; restricted rotation and cis/trans isomerism",
            "Other sp2 centres: BF3, benzene, carbonyl carbon, carbocations",
            "Quick rule: 3 regions of electron density = sp2",
            "Comparison with sp3 and sp",
        ],
        "key_points": [
            "1 s + 2 p mix to give 3 sp2 orbitals (33% s, 67% p); one p orbital remains unhybridised.",
            "The 3 sp2 orbitals are coplanar and 120 degrees apart: trigonal planar.",
            "sp2-sp2 and sp2-s overlaps are head-on: sigma bonds.",
            "The unhybridised p orbitals on neighbouring carbons overlap side-on above and below the plane: one pi bond.",
            "C=C = one sigma + one pi bond. The pi bond stops rotation, so cis/trans isomers exist.",
            "3 regions of electron density = sp2.",
        ],
        "equation_items": [
            {"formula": "1 s + 2 p -> 3 sp2 (+ 1 p left)", "meaning": "3 orbitals mixed give 3 hybrids; the remaining p orbital keeps its shape and makes the pi bond."},
            {"formula": "3 regions = sp2", "meaning": "Count sigma bonds + lone pairs. The double bond counts as one region."},
        ],
        "requirements": [
            "Three regions of electron density around the atom.",
            "One p orbital must stay unhybridised so a pi bond (or empty p orbital) is available.",
            "Pi overlap needs the two p orbitals parallel, so the atoms and their substituents lie in one plane.",
        ],
        "process_items": [
            {"title": "HOW SP2 ORBITALS FORM (CARBON)", "steps": [
                {"title": "Ground state", "explanation": "C is 1s2 2s2 2p2 with two unpaired electrons."},
                {"title": "Promotion", "explanation": "One 2s electron moves to the empty 2p orbital: 2s1 2p3."},
                {"title": "Hybridisation", "explanation": "The 2s and TWO 2p orbitals mix into three sp2 orbitals; the third 2p orbital is unchanged."},
                {"title": "Geometry", "explanation": "The three sp2 orbitals lie in a plane at 120 degrees (trigonal planar); the p orbital is perpendicular to it."},
                {"title": "Bonding", "explanation": "sp2 orbitals overlap head-on to make sigma bonds; the two p orbitals overlap side-on to make one pi bond."},
            ]},
            {"title": "BUILDING ETHENE, C2H4", "steps": [
                {"title": "C-H bonds", "explanation": "Each carbon uses two sp2 orbitals to overlap with two H 1s orbitals: 4 sigma C-H bonds."},
                {"title": "C-C sigma", "explanation": "The third sp2 orbital on each carbon overlaps head-on with the other: 1 sigma C-C bond."},
                {"title": "Pi bond", "explanation": "The unhybridised p orbitals overlap side-on above and below the molecular plane: 1 pi bond."},
                {"title": "Result", "explanation": "5 sigma + 1 pi bond; all six atoms are in one plane, H-C-H and H-C-C about 120 degrees; C=C 0.134 nm."},
            ]},
        ],
        "key_ideas": [
            {"name": "Why only 2 p orbitals are mixed",
             "explanation": "Carbon needs three sigma bonds (two C-H, one C-C) and one pi bond. Mixing 1 s + 2 p gives exactly three sigma-bonding orbitals and leaves one p orbital for the pi bond."},
            {"name": "Sigma versus pi overlap",
             "explanation": "Sigma: head-on overlap, density between the nuclei, strong, allows rotation. Pi: side-on overlap of parallel p orbitals, density above and below the bond axis, weaker, prevents rotation."},
            {"name": "Restricted rotation and cis/trans isomers",
             "explanation": "Rotating about C=C would break the pi overlap, so the two ends are locked. Different groups on each carbon can therefore sit on the same side (cis/Z) or opposite sides (trans/E)."},
            {"name": "Reactivity of the pi bond",
             "explanation": "The pi electrons are exposed above and below the plane and further from the nuclei than sigma electrons, so alkenes undergo electrophilic addition. Carbon changes from sp2 to sp3 as it reacts."},
            {"name": "Other sp2 atoms",
             "explanation": "Boron in BF3 (3 sigma bonds, empty p orbital, electron-deficient); each carbon in benzene (delocalised pi ring, 120 degrees); the carbon of C=O in aldehydes, ketones and acids; planar carbocations."},
            {"name": "Bond length and s-character",
             "explanation": "sp2 is 33% s. The C=C bond (0.134 nm) is shorter and stronger than C-C (0.154 nm) because there are two shared pairs."},
        ],
        "diagrams": [
            {"kind": "flow", "title": "Carbon: ground state to sp2 + p",
             "caption": "Same first two steps as sp3; only two p orbitals are mixed.",
             "nodes": [
                 {"label": "Ground state", "detail": "2s2 2p2"},
                 {"label": "Promotion", "detail": "2s1 2p3"},
                 {"label": "Hybridisation", "detail": "1 s + 2 p -> 3 sp2; 1 p left over"},
                 {"label": "Planar layout", "detail": "3 sp2 orbitals at 120 degrees"},
                 {"label": "Overlap", "detail": "sigma bonds head-on; pi bond side-on from the p orbitals"}]},
            _energy_spec("sp2"),
            {"kind": "molecule3d", "title": "Each carbon in ethene (trigonal planar)",
             "caption": "All three bonds lie in the plane of the paper. The unhybridised p orbital sticks out of the plane and makes the pi bond.",
             "shape": "trigonal_planar", "center": "C", "substituents": ["H", "H", "C"], "angle_label": "about 120 degrees"},
            {"kind": "lobes", "title": "Three sp2 lobes and the leftover p orbital",
             "caption": "Purple = sp2 hybrids in the plane; blue = the unhybridised p orbital (perpendicular to the plane, tilted here so you can see it).",
             "angles": [0, 120, 240], "labels": ["sp2", "sp2", "sp2"], "center": "C",
             "p_lobes": [{"angle": 90, "label": "p (pi)"}]},
        ],
        "worked_examples": [
            {"question": "Describe the bonding in ethene in terms of orbitals. [4 marks]",
             "answer": "Each C is sp2 (1 s + 2 p mixed, 120 degrees, planar). Head-on overlap of sp2 orbitals with H 1s and with each other gives 5 sigma bonds. The unhybridised p orbitals overlap side-on above and below the plane to form one pi bond, so C=C is 1 sigma + 1 pi."},
            {"question": "Why does but-2-ene show cis/trans isomerism but butane does not? [2 marks]",
             "answer": "The C=C pi bond needs parallel p orbitals, so rotation about C=C is restricted; the groups are fixed on the same or opposite sides. Rotation about the sigma C-C bonds in butane is free."},
            {"question": "State the hybridisation of B in BF3 and the F-B-F angle. [2 marks]",
             "answer": "Three bonding pairs, no lone pair = 3 regions, so B is sp2 and the molecule is trigonal planar with F-B-F = 120 degrees."},
        ],
        "common_mistakes": [
            "Forgetting the leftover p orbital: sp2 leaves ONE p orbital unhybridised, which forms the pi bond.",
            "Saying the pi bond is made from sp2 orbitals. Pi bonds come from unhybridised p orbitals overlapping side-on.",
            "Counting the C=C double bond as two regions. It is one region (sigma + pi), so carbon has 3 regions in ethene.",
            "Saying the p orbitals overlap head-on. Head-on = sigma; side-on = pi.",
            "Forgetting that the pi bond, not the sigma bond, is what stops rotation.",
        ],
        "exam_tips": [
            "For ethene, state the numbers: 5 sigma + 1 pi bond, 120 degrees, planar, C=C 0.134 nm.",
            "Draw the two p orbitals as lobes above and below the plane joined by shading (the pi bond).",
            "Link structure to properties: pi bond gives restricted rotation (isomerism) and reactivity (addition).",
        ],
        "vocabulary": [
            {"term": "sp2 hybrid orbital", "meaning": "One of three orbitals made by mixing 1 s and 2 p; 33% s, planar at 120 degrees."},
            {"term": "Unhybridised p orbital", "meaning": "The p orbital left out of the mixing; perpendicular to the sp2 plane; forms pi bonds."},
            {"term": "Pi (pi) bond", "meaning": "Side-on overlap of parallel p orbitals; density above and below the bond axis."},
            {"term": "Sigma (sigma) bond", "meaning": "Head-on overlap; density on the bond axis."},
            {"term": "Trigonal planar", "meaning": "Three groups in one plane, 120 degrees apart."},
            {"term": "Restricted rotation", "meaning": "No free rotation about a double bond because rotating would break pi overlap."},
            {"term": "cis / trans (E/Z)", "meaning": "Isomers that differ in whether groups are on the same or opposite sides of C=C."},
        ],
        "quick_facts": [
            "sp2 = 33% s, 67% p, three orbitals at 120 degrees.",
            "Ethene: 5 sigma + 1 pi; all atoms coplanar.",
            "C=C 0.134 nm vs C-C 0.154 nm.",
            "BF3: B is sp2, trigonal planar, electron deficient.",
            "Benzene: six sp2 carbons, delocalised pi ring.",
        ],
        "exam_keywords": ["unhybridised p orbital", "side-on overlap", "pi bond", "sigma bond", "trigonal planar", "120 degrees", "restricted rotation"],
        "memory_hook": "sp2 = three in a plane + one p left over. The left-over p is the pi bond.",
        "summary_points": [
            "sp2 = 1 s + 2 p -> 3 hybrids in a plane at 120 degrees, plus one unhybridised p.",
            "Hybrids make sigma bonds; the p orbitals make one pi bond.",
            "A C=C is 1 sigma + 1 pi and cannot rotate.",
            "3 regions of electron density = sp2.",
        ],
        "key_points_to_remember": [],
        "reference_outline": [
            {"number": 1, "title": "What is sp2 hybridisation?", "content": "One s and two p orbitals mix to give three identical sp2 orbitals; one p orbital is left over.", "bullets": ["33% s, 67% p", "planar, 120 degrees"]},
            {"number": 2, "title": "Bonding picture", "content": "Sigma bonds from sp2 orbitals; pi bond from the p orbitals.", "bullets": ["head-on = sigma", "side-on = pi"]},
            {"number": 3, "title": "Ethene", "content": "5 sigma bonds and 1 pi bond; planar molecule.", "bullets": ["4 sigma C-H", "1 sigma C-C + 1 pi"]},
        ],
        "comparison_tables": [_COMPARE_HYBRIDS],
        "sources": [_LIB_SOURCE],
        "footer_line": "Three in a plane, one p left for the pi bond.",
        "_offline_library": True,
    }


# --------------------------------------------------------------------------- sp pack
def _sp(syllabus_name, syllabus_year):
    return {
        "chapter_title": "How sp Orbitals Are Formed",
        "subject_line": f"{syllabus_name} {syllabus_year} | Chemical bonding | sp hybridisation".replace("  ", " ").strip(),
        "what_is": ("sp hybridisation is the model in which ONE 2s orbital and ONE 2p orbital mix to form TWO identical sp hybrid "
                    "orbitals (50% s, 50% p) pointing in opposite directions, 180 degrees apart (linear). Two 2p orbitals are "
                    "left unhybridised, at right angles to each other and to the sp axis. sp orbitals form sigma bonds; the two "
                    "leftover p orbitals on each atom make two pi bonds, giving a triple bond (1 sigma + 2 pi)."),
        "topic_coverage": [
            "Promotion of a 2s electron and mixing of 1 s + 1 p orbital",
            "Two equivalent sp orbitals at 180 degrees (linear)",
            "Two unhybridised p orbitals and two perpendicular pi bonds",
            "Ethyne: 3 sigma + 2 pi bonds; cylindrical electron density",
            "Other sp centres: CO2, HCN, BeCl2",
            "Quick rule: 2 regions of electron density = sp",
        ],
        "key_points": [
            "1 s + 1 p mix to give 2 sp orbitals (50% s, 50% p); two p orbitals remain.",
            "The two sp orbitals are 180 degrees apart: linear.",
            "sp orbitals form sigma bonds; the leftover p orbitals form two pi bonds at 90 degrees to each other.",
            "C#C = 1 sigma + 2 pi; shortest (0.120 nm) and strongest carbon-carbon bond.",
            "2 regions of electron density = sp.",
        ],
        "equation_items": [
            {"formula": "1 s + 1 p -> 2 sp (+ 2 p left)", "meaning": "2 orbitals mixed give 2 hybrids; the 2 remaining p orbitals make the two pi bonds."},
            {"formula": "2 regions = sp", "meaning": "Sigma bonds + lone pairs on the atom; a triple bond is one region."},
        ],
        "requirements": [
            "Two regions of electron density around the atom.",
            "Two p orbitals must stay unhybridised so two pi bonds (or empty p orbitals) are available.",
        ],
        "process_items": [
            {"title": "HOW SP ORBITALS FORM (CARBON)", "steps": [
                {"title": "Ground state", "explanation": "C is 1s2 2s2 2p2."},
                {"title": "Promotion", "explanation": "One 2s electron moves to the empty 2p orbital: 2s1 2p3."},
                {"title": "Hybridisation", "explanation": "The 2s and ONE 2p orbital mix into two sp orbitals; two 2p orbitals are unchanged."},
                {"title": "Geometry", "explanation": "The two sp orbitals point 180 degrees apart (linear); the two p orbitals are perpendicular to the axis and to each other."},
                {"title": "Bonding", "explanation": "sp orbitals overlap head-on (sigma); the p orbitals overlap side-on in two perpendicular planes (two pi bonds)."},
            ]},
            {"title": "BUILDING ETHYNE, C2H2", "steps": [
                {"title": "C-H bonds", "explanation": "Each carbon overlaps one sp orbital with an H 1s: 2 sigma C-H bonds."},
                {"title": "C-C sigma", "explanation": "The other sp orbital on each carbon overlaps head-on: 1 sigma C-C bond."},
                {"title": "Two pi bonds", "explanation": "The two pairs of unhybridised p orbitals overlap side-on, one pair above/below and one pair in front/behind: 2 pi bonds."},
                {"title": "Result", "explanation": "3 sigma + 2 pi; linear H-C-C-H, 180 degrees; C#C 0.120 nm; electron density is cylindrical around the axis."},
            ]},
        ],
        "key_ideas": [
            {"name": "Why one p orbital is mixed",
             "explanation": "Carbon in ethyne needs two sigma bonds (one C-H, one C-C) and two pi bonds. One s + one p gives exactly two sigma orbitals and leaves two p orbitals for the two pi bonds."},
            {"name": "Triple bond = 1 sigma + 2 pi",
             "explanation": "The sigma bond lies on the axis. The two pi bonds are at right angles to each other, so together they form a cylinder of electron density around the C-C axis."},
            {"name": "Highest s-character",
             "explanation": "50% s-character holds the electrons closest to the nucleus: shortest bonds (C#C 0.120 nm, C-H about 0.106 nm), strongest bonds, and the most electronegative carbon. This is why terminal alkynes are slightly acidic."},
            {"name": "Other sp atoms",
             "explanation": "C in CO2 (two C=O, 2 regions, 180 degrees); C in HCN (H-C#N); Be in BeCl2 (2 bonding pairs, electron deficient, linear)."},
            {"name": "Linear shape",
             "explanation": "Two regions repel to the maximum separation, 180 degrees, so every sp centre with two groups is linear."},
        ],
        "diagrams": [
            {"kind": "flow", "title": "Carbon: ground state to sp + 2 p",
             "caption": "Same promotion step; only one p orbital mixes.",
             "nodes": [
                 {"label": "Ground state", "detail": "2s2 2p2"},
                 {"label": "Promotion", "detail": "2s1 2p3"},
                 {"label": "Hybridisation", "detail": "1 s + 1 p -> 2 sp; 2 p left over"},
                 {"label": "Linear layout", "detail": "2 sp orbitals at 180 degrees"},
                 {"label": "Overlap", "detail": "sigma head-on; two pi bonds side-on"}]},
            _energy_spec("sp"),
            {"kind": "molecule3d", "title": "Ethyne, H-C#C-H (linear)",
             "caption": "Each carbon has two regions of electron density, so H-C-C = 180 degrees.",
             "shape": "linear", "center": "C", "substituents": ["H", "C"], "angle_label": "180 degrees"},
            {"kind": "lobes", "title": "Two sp lobes and a p orbital",
             "caption": "Purple = the two sp hybrids along the axis; blue = one of the two unhybridised p orbitals (the other points out of the page).",
             "angles": [0, 180], "labels": ["sp", "sp"], "center": "C",
             "p_lobes": [{"angle": 90, "label": "p (pi)"}]},
        ],
        "worked_examples": [
            {"question": "Describe the bonding in ethyne in terms of orbitals. [4 marks]",
             "answer": "Each C is sp (1 s + 1 p mixed, 180 degrees, linear). Head-on overlap of sp orbitals with H 1s and with each other gives 3 sigma bonds. The two unhybridised p orbitals on each carbon overlap side-on in two perpendicular planes to make 2 pi bonds, so C#C is 1 sigma + 2 pi."},
            {"question": "State the hybridisation of carbon in CO2 and the O-C-O angle. [2 marks]",
             "answer": "Carbon has two double bonds = 2 regions, so it is sp and CO2 is linear with O-C-O = 180 degrees."},
        ],
        "common_mistakes": [
            "Saying a triple bond is three sigma bonds. It is one sigma + two pi.",
            "Forgetting that TWO p orbitals stay unhybridised in sp (one in sp2).",
            "Counting a triple bond as three regions. For hybridisation it is one region.",
            "Drawing the two pi bonds in the same plane. They are perpendicular to each other.",
        ],
        "exam_tips": [
            "State: 3 sigma + 2 pi, 180 degrees, linear, C#C 0.120 nm for ethyne.",
            "Explain why a triple bond is shorter and stronger: more shared pairs and higher s-character.",
        ],
        "vocabulary": [
            {"term": "sp hybrid orbital", "meaning": "One of two orbitals made by mixing 1 s and 1 p; 50% s, 180 degrees apart."},
            {"term": "Linear", "meaning": "Two groups 180 degrees apart in a straight line."},
            {"term": "Triple bond", "meaning": "One sigma + two pi bonds."},
            {"term": "Cylindrical symmetry", "meaning": "Electron density spread evenly around the bond axis, as in a triple bond."},
        ],
        "quick_facts": [
            "sp = 50% s, 50% p, two orbitals at 180 degrees.",
            "Ethyne: 3 sigma + 2 pi, linear.",
            "C-C 0.154 nm > C=C 0.134 nm > C#C 0.120 nm.",
            "CO2, HCN, BeCl2 are linear (sp centres).",
        ],
        "exam_keywords": ["linear", "180 degrees", "two unhybridised p orbitals", "two pi bonds", "sigma bond", "cylindrical"],
        "memory_hook": "sp = two in a line + two p left over = two pi bonds.",
        "summary_points": [
            "sp = 1 s + 1 p -> 2 hybrids at 180 degrees, plus two unhybridised p orbitals.",
            "Hybrids make sigma bonds; the p orbitals make two pi bonds.",
            "A C#C is 1 sigma + 2 pi: shortest and strongest carbon-carbon bond.",
            "2 regions of electron density = sp.",
        ],
        "key_points_to_remember": [],
        "reference_outline": [
            {"number": 1, "title": "What is sp hybridisation?", "content": "One s and one p orbital mix to give two identical sp orbitals; two p orbitals are left over.", "bullets": ["50% s, 50% p", "linear, 180 degrees"]},
            {"number": 2, "title": "Bonding picture", "content": "Sigma bonds from sp orbitals; two pi bonds from the p orbitals.", "bullets": ["head-on = sigma", "side-on = pi (x2)"]},
            {"number": 3, "title": "Ethyne", "content": "3 sigma bonds and 2 pi bonds; linear molecule.", "bullets": ["2 sigma C-H", "1 sigma C-C + 2 pi"]},
        ],
        "comparison_tables": [_COMPARE_HYBRIDS],
        "sources": [_LIB_SOURCE],
        "footer_line": "Two in a line, two p left for the pi bonds.",
        "_offline_library": True,
    }


# --------------------------------------------------------------------------- atomic orbitals pack
def _orbitals(syllabus_name, syllabus_year):
    return {
        "chapter_title": "Atomic Orbitals",
        "subject_line": f"{syllabus_name} {syllabus_year} | Atomic structure | shells, subshells and orbitals".replace("  ", " ").strip(),
        "what_is": ("An atomic orbital is a region of space around the nucleus where there is a high probability of finding an "
                    "electron. Each orbital holds a maximum of TWO electrons, which must have opposite spins. Orbitals are grouped "
                    "into subshells (s, p, d, f) and subshells into shells (n = 1, 2, 3 ...). The type of orbital fixes its shape and "
                    "energy, and the way electrons fill them gives every atom's electronic configuration."),
        "topic_coverage": [
            "Shells (n), subshells (s, p, d, f) and how many orbitals each contains",
            "Maximum electrons: 2 per orbital, 2, 6, 10, 14 per subshell, 2n^2 per shell",
            "Shapes of s and p orbitals (spherical, dumbbell; px, py, pz at 90 degrees)",
            "Relative energies: 1s < 2s < 2p < 3s < 3p < 4s < 3d < 4p",
            "Filling rules: Aufbau (lowest energy first), Pauli exclusion, Hund's rule",
            "Writing electronic configurations of atoms and ions (1s2 2s2 2p6 ... and [Ar] shorthand)",
            "Why 4s electrons are lost first, and the Cr and Cu exceptions",
            "Unpaired electrons and links to ionisation energy and bonding (sigma / pi, hybridisation)",
        ],
        "key_points": [
            "An orbital = region of space with a high probability of finding an electron; maximum 2 electrons with opposite spins.",
            "Subshell s has 1 orbital (2 electrons), p has 3 (6), d has 5 (10), f has 7 (14).",
            "Shell n holds at most 2n^2 electrons: 2, 8, 18, 32.",
            "s orbitals are spherical; p orbitals are dumbbell-shaped and lie along the x, y and z axes at 90 degrees to each other.",
            "Filling order: 1s 2s 2p 3s 3p 4s 3d 4p. 4s fills before 3d but 4s electrons are lost first when transition metals form ions.",
            "Hund's rule: orbitals of equal energy are filled singly with parallel spins before any pairing occurs.",
            "Chromium ([Ar] 3d5 4s1) and copper ([Ar] 3d10 4s1) are exceptions: a half-full or full 3d subshell is extra stable.",
        ],
        "equation_items": [
            {"formula": "max electrons in shell = 2n^2",
             "meaning": "n = 1, 2, 3, 4 gives 2, 8, 18, 32 electrons. (Sum of the subshell capacities in that shell.)"},
            {"formula": "orbitals: s=1, p=3, d=5, f=7",
             "meaning": "Each orbital holds 2 electrons, so subshell capacity = 2, 6, 10, 14 electrons."},
        ],
        "requirements": [
            "Pauli exclusion principle: no two electrons in an atom can have the same set of four quantum numbers, so an orbital holds at most two electrons and they spin in opposite directions.",
            "Aufbau principle: electrons occupy the lowest-energy available orbital first.",
            "Hund's rule: electrons occupy degenerate (equal-energy) orbitals singly, with parallel spins, before pairing up.",
        ],
        "process_items": [
            {"title": "WRITE AN ELECTRONIC CONFIGURATION", "steps": [
                {"title": "Count electrons", "explanation": "For a neutral atom, electrons = proton number. Configure the atom first, then adjust for any charge."},
                {"title": "Fill in energy order", "explanation": "1s 2s 2p 3s 3p 4s 3d 4p 5s ... always lowest energy first."},
                {"title": "Respect capacities", "explanation": "s holds 2, p holds 6, d holds 10 electrons. Write each as e.g. 2p4 (four electrons in the 2p subshell)."},
                {"title": "Apply Hund's rule", "explanation": "In the last partly-filled subshell draw boxes: one electron in each box first, then pair up."},
                {"title": "Check exceptions", "explanation": "Cr is [Ar] 3d5 4s1 and Cu is [Ar] 3d10 4s1 (half-full / full 3d is extra stable)."},
            ]},
            {"title": "IONS AND UNPAIRED ELECTRONS", "steps": [
                {"title": "Write the atom first", "explanation": "e.g. Fe = [Ar] 3d6 4s2."},
                {"title": "Cations lose outer electrons", "explanation": "Remove electrons from the highest shell first: 4s BEFORE 3d. Fe2+ = [Ar] 3d6, Fe3+ = [Ar] 3d5."},
                {"title": "Anions gain electrons", "explanation": "Add electrons to the next empty places in the same subshell: Cl- = 1s2 2s2 2p6 3s2 3p6."},
                {"title": "Draw boxes", "explanation": "Sketch the outer subshell as boxes with arrows."},
                {"title": "Count unpaired", "explanation": "Unpaired electrons = boxes containing a single arrow (Fe: 4, Fe3+: 5)."},
            ]},
        ],
        "key_ideas": [
            {"name": "What an orbital is (and is not)",
             "explanation": "An orbital is NOT a fixed path. It is a region of space where an electron is most likely to be found (a probability picture). The 'shape' shows where the electron is likely to be, and an orbital can hold 0, 1 or 2 electrons."},
            {"name": "Shells, subshells, orbitals",
             "explanation": "Shell n = 1, 2, 3, 4 (main energy level). Shell 1 has only 1s; shell 2 has 2s and 2p; shell 3 has 3s, 3p, 3d; shell 4 has 4s, 4p, 4d, 4f. The number of subshells in a shell equals n."},
            {"name": "Shapes and size",
             "explanation": "s orbitals are spherical and get larger as n increases (2s is bigger than 1s). p orbitals are dumbbell-shaped with a node at the nucleus; px, py, pz point along three perpendicular axes and have the same energy. d orbitals have more complex shapes (not needed at this level)."},
            {"name": "Energy order and 4s / 3d",
             "explanation": "Energy rises 1s < 2s < 2p < 3s < 3p < 4s < 3d < 4p. Because 4s is slightly lower than 3d in a neutral atom, 4s fills first. Once 3d is occupied its energy drops below 4s, so 4s electrons are lost first when transition metals form positive ions."},
            {"name": "Pauli exclusion principle",
             "explanation": "Each orbital can hold at most two electrons and they must have opposite spins (shown as up and down arrows). This is why s holds 2, p holds 6 and d holds 10 electrons."},
            {"name": "Hund's rule and unpaired electrons",
             "explanation": "Electrons in equal-energy orbitals occupy separate orbitals with parallel spins first because this minimises repulsion. So carbon 2p2 has two unpaired electrons, nitrogen 2p3 has three, and oxygen 2p4 has two (one pair + two single)."},
            {"name": "Chromium and copper exceptions",
             "explanation": "Cr is [Ar] 3d5 4s1 (not 3d4 4s2) and Cu is [Ar] 3d10 4s1 (not 3d9 4s2). A half-full (d5) or completely full (d10) subshell has extra stability, so one 4s electron moves into 3d."},
            {"name": "Link to ionisation energy",
             "explanation": "Orbital energies explain the dips in first ionisation energy. Boron is lower than beryllium because the outer electron is in a higher-energy 2p orbital. Oxygen is lower than nitrogen because in 2p4 two electrons share one orbital and repel each other, so one is removed more easily."},
            {"name": "Link to bonding",
             "explanation": "Covalent bonds form when orbitals overlap. Head-on overlap gives a sigma bond, side-on overlap of p orbitals gives a pi bond. When carbon needs four equivalent bonds, its 2s and 2p orbitals mix (hybridise) into sp3, sp2 or sp orbitals."},
            {"name": "Electronic configuration notation",
             "explanation": "Write shell number, subshell letter and electrons as a superscript: 1s2 2s2 2p6. The shorthand [Ne] or [Ar] stands for the noble-gas core: Fe = [Ar] 3d6 4s2. Ions: Na+ = 1s2 2s2 2p6; O2- = 1s2 2s2 2p6."},
        ],
        "diagrams": [
            {"kind": "flow", "title": "How electrons fill orbitals",
             "caption": "Apply these in order every time you write a configuration or draw an orbital box diagram.",
             "nodes": [
                 {"label": "Lowest energy first", "detail": "1s, 2s, 2p, 3s, 3p, 4s, 3d, 4p (Aufbau)"},
                 {"label": "Max two per orbital", "detail": "opposite spins (Pauli exclusion)"},
                 {"label": "Singly first", "detail": "equal-energy orbitals get one electron each, parallel spins (Hund)"},
                 {"label": "Check exceptions", "detail": "Cr [Ar]3d5 4s1 and Cu [Ar]3d10 4s1"},
                 {"label": "Ions", "detail": "remove 4s electrons before 3d electrons"}]},
            {"kind": "shapes", "title": "Shapes of s and p orbitals",
             "caption": "s is a sphere. The three p orbitals are identical dumbbells at 90 degrees to each other along x, y and z. Each orbital holds two electrons."},
            {"kind": "energy", "title": "Hund's rule in action: carbon, nitrogen, oxygen",
             "caption": "In 2p the electrons go into separate boxes (parallel spins) until each box has one; only then do they pair. That is why N has 3 unpaired electrons and O has 2.",
             "columns": [
                 {"title": "Carbon 1s2 2s2 2p2", "levels": [
                     {"label": "2p", "energy": 1.4, "boxes": [1, 1, 0]},
                     {"label": "2s", "energy": 0.7, "boxes": [2]},
                     {"label": "1s", "energy": 0.0, "boxes": [2]}]},
                 {"title": "Nitrogen 1s2 2s2 2p3", "levels": [
                     {"label": "2p", "energy": 1.4, "boxes": [1, 1, 1]},
                     {"label": "2s", "energy": 0.7, "boxes": [2]},
                     {"label": "1s", "energy": 0.0, "boxes": [2]}]},
                 {"title": "Oxygen 1s2 2s2 2p4", "levels": [
                     {"label": "2p", "energy": 1.4, "boxes": [2, 1, 1]},
                     {"label": "2s", "energy": 0.7, "boxes": [2]},
                     {"label": "1s", "energy": 0.0, "boxes": [2]}]}],
             "transitions": ["+1 electron: goes into the empty 2p box", "+1 electron: must now pair up"]},
            {"kind": "energy", "title": "Why transition metals lose 4s electrons first (iron)",
             "caption": "4s fills before 3d, but when iron forms ions the 4s electrons leave first: Fe2+ is [Ar] 3d6 and Fe3+ is [Ar] 3d5.",
             "columns": [
                 {"title": "Fe atom [Ar] 3d6 4s2", "levels": [
                     {"label": "3d", "energy": 1.0, "boxes": [2, 1, 1, 1, 1]},
                     {"label": "4s", "energy": 0.4, "boxes": [2]}]},
                 {"title": "Fe2+ [Ar] 3d6", "levels": [
                     {"label": "3d", "energy": 1.0, "boxes": [2, 1, 1, 1, 1]},
                     {"label": "4s", "energy": 0.4, "boxes": [0]}]},
                 {"title": "Fe3+ [Ar] 3d5", "levels": [
                     {"label": "3d", "energy": 1.0, "boxes": [1, 1, 1, 1, 1]},
                     {"label": "4s", "energy": 0.4, "boxes": [0]}]}],
             "transitions": ["lose both 4s electrons", "lose one 3d electron"]},
            {"kind": "hub", "title": "Atomic orbitals: concept map", "center": "Orbital",
             "caption": "How the main ideas connect.",
             "nodes": [
                 {"label": "Definition", "detail": "region of high electron probability; max 2 e-"},
                 {"label": "Shells / subshells", "detail": "n = 1,2,3; s p d f"},
                 {"label": "Shapes", "detail": "s sphere; p dumbbell x, y, z"},
                 {"label": "Energy order", "detail": "1s 2s 2p 3s 3p 4s 3d 4p"},
                 {"label": "Filling rules", "detail": "Aufbau, Pauli, Hund"},
                 {"label": "Use", "detail": "configurations, ions, bonding"}]},
        ],
        "worked_examples": [
            {"question": "Write the electronic configuration of iron (Z = 26) and of Fe3+. [3 marks]",
             "answer": "Fe: 1s2 2s2 2p6 3s2 3p6 3d6 4s2 = [Ar] 3d6 4s2. For Fe3+ remove the two 4s electrons first, then one 3d electron: [Ar] 3d5 (1s2 2s2 2p6 3s2 3p6 3d5)."},
            {"question": "State the number of unpaired electrons in a ground-state nitrogen atom and explain. [2 marks]",
             "answer": "N is 1s2 2s2 2p3. By Hund's rule the three 2p electrons occupy three separate p orbitals with parallel spins, so there are 3 unpaired electrons."},
            {"question": "Explain why the first ionisation energy of oxygen is lower than that of nitrogen. [3 marks]",
             "answer": "N is 2p3 (each 2p orbital singly occupied). O is 2p4, so two electrons share one 2p orbital and repel each other. Less energy is needed to remove one of the paired electrons, so oxygen's first ionisation energy is lower."},
            {"question": "Explain why chromium is [Ar] 3d5 4s1 and not [Ar] 3d4 4s2. [2 marks]",
             "answer": "A half-filled 3d subshell (one electron in each of the five d orbitals) gives extra stability, so one 4s electron is promoted into 3d."},
            {"question": "Describe the shape and orientation of the 2p orbitals. [2 marks]",
             "answer": "Each 2p orbital is dumbbell-shaped with two lobes either side of the nucleus. There are three, 2px, 2py and 2pz, along mutually perpendicular axes (90 degrees) and all have the same energy."},
        ],
        "common_mistakes": [
            "Saying an orbital is 'where the electron is' or 'a circular path'. It is a region of space with a high PROBABILITY of finding the electron.",
            "Saying each subshell holds 2 electrons. An orbital holds 2; s = 2, p = 6, d = 10, f = 14 electrons.",
            "Writing Fe2+ as [Ar] 3d4 4s2. The 4s electrons are lost BEFORE the 3d electrons: Fe2+ = [Ar] 3d6.",
            "Filling 3d before 4s for atoms. In the atom 4s is filled first; only when ionising is 4s removed first.",
            "Pairing electrons in p orbitals too early. Put one electron in each box first (Hund's rule).",
            "Forgetting Cr and Cu exceptions, or explaining them with 'half-filled orbitals are stable' without mentioning the d SUBSHELL.",
            "Drawing p orbitals as one dumbbell. There are three p orbitals (px, py, pz) at 90 degrees.",
        ],
        "exam_tips": [
            "Use the exact definition: 'a region of space with a high probability of finding an electron' (maximum two electrons).",
            "Always write superscripts as numbers after the subshell (2p4) and check the total equals the electrons in the atom or ion.",
            "For ions: write the atom's configuration first, then remove electrons from the outermost shell (4s before 3d).",
            "Draw electrons-in-boxes with arrows in opposite directions for a pair; show Hund's rule clearly.",
            "Link questions: ionisation energy dips (Be to B, N to O) are explained by orbital energy and pairing repulsion.",
            "Sketch s as a sphere and p as a dumbbell on the axes, and label px, py, pz.",
        ],
        "vocabulary": [
            {"term": "Orbital", "meaning": "Region of space with a high probability of finding an electron; holds a maximum of two electrons."},
            {"term": "Shell / principal quantum number (n)", "meaning": "Main energy level, n = 1, 2, 3 ...; holds up to 2n^2 electrons."},
            {"term": "Subshell", "meaning": "s, p, d or f group of orbitals within a shell."},
            {"term": "Degenerate", "meaning": "Orbitals with exactly the same energy, e.g. the three 2p orbitals."},
            {"term": "Pauli exclusion principle", "meaning": "An orbital holds at most two electrons and they must spin in opposite directions."},
            {"term": "Hund's rule", "meaning": "Degenerate orbitals fill singly with parallel spins before pairing."},
            {"term": "Aufbau principle", "meaning": "Electrons fill the lowest-energy available orbital first."},
            {"term": "Unpaired electron", "meaning": "An electron alone in an orbital; responsible for paramagnetism."},
        ],
        "quick_facts": [
            "Orbitals per subshell: s 1, p 3, d 5, f 7.",
            "Electrons per subshell: s 2, p 6, d 10, f 14.",
            "Electrons per shell: 2, 8, 18, 32 (2n^2).",
            "Filling order: 1s 2s 2p 3s 3p 4s 3d 4p 5s.",
            "Cr = [Ar] 3d5 4s1; Cu = [Ar] 3d10 4s1.",
            "Unpaired electrons: C 2, N 3, O 2, Fe 4, Fe3+ 5, Cr 6, Cu 1.",
            "Noble-gas cores: [He] 2 e-, [Ne] 10 e-, [Ar] 18 e-.",
        ],
        "exam_keywords": ["region of space", "high probability", "maximum two electrons", "opposite spins", "subshell",
                          "degenerate", "Hund's rule", "Pauli exclusion", "unpaired electrons", "4s before 3d"],
        "memory_hook": "Lowest energy first, two per orbital, one each before pairing. s = 1 orbital, p = 3, d = 5. For ions, 4s leaves before 3d.",
        "summary_points": [
            "An orbital is a region of high electron probability holding up to two electrons of opposite spin.",
            "s (1 orbital, spherical), p (3 orbitals, dumbbell, 90 degrees), d (5 orbitals), f (7 orbitals).",
            "Energy order: 1s 2s 2p 3s 3p 4s 3d 4p; 4s fills first but is lost first.",
            "Follow Aufbau, Pauli and Hund's rule when filling; remember the Cr and Cu exceptions.",
            "Configurations explain unpaired electrons, ion formation, ionisation-energy trends and bonding.",
        ],
        "key_points_to_remember": [],
        "reference_outline": [
            {"number": 1, "title": "What is an orbital?", "content": "A region of space with a high probability of finding an electron; at most two electrons with opposite spins.", "bullets": ["not a path", "0, 1 or 2 electrons", "shape depends on the type"]},
            {"number": 2, "title": "Shells and subshells", "content": "Shell n contains n subshells.", "bullets": ["n=1: 1s", "n=2: 2s 2p", "n=3: 3s 3p 3d", "n=4: 4s 4p 4d 4f"]},
            {"number": 3, "title": "Shapes", "content": "s orbitals are spherical; p orbitals are dumbbells along x, y, z.", "bullets": ["3 p orbitals at 90 degrees", "same energy = degenerate", "s grows with n"]},
            {"number": 4, "title": "Capacities", "content": "Each orbital holds 2 electrons.", "bullets": ["s 2, p 6, d 10, f 14", "shell holds 2n^2", "2, 8, 18, 32"]},
            {"number": 5, "title": "Energy order", "content": "Fill from the lowest energy upwards.", "bullets": ["1s 2s 2p 3s 3p 4s 3d 4p", "4s fills before 3d", "4s lost first in ions"]},
            {"number": 6, "title": "Filling rules", "content": "Three rules decide every configuration.", "bullets": ["Aufbau: lowest energy first", "Pauli: max 2, opposite spins", "Hund: singly first"]},
            {"number": 7, "title": "Configurations", "content": "Write shell, subshell and electron count.", "bullets": ["C 1s2 2s2 2p2", "Fe [Ar] 3d6 4s2", "Cr and Cu exceptions"]},
            {"number": 8, "title": "Why it matters", "content": "Orbitals explain trends and bonding.", "bullets": ["unpaired electrons", "ionisation energy dips", "sigma / pi bonds, hybridisation"]},
        ],
        "comparison_tables": [
            {"title": "Subshells at a glance",
             "columns": ["Subshell", "Orbitals", "Max electrons", "Shape", "First in shell"],
             "rows": [["s", "1", "2", "spherical", "n = 1"],
                      ["p", "3 (px, py, pz)", "6", "dumbbell, 90 degrees apart", "n = 2"],
                      ["d", "5", "10", "more complex", "n = 3"],
                      ["f", "7", "14", "more complex", "n = 4"]]},
            {"title": "Filling rules",
             "columns": ["Rule", "Statement", "Example"],
             "rows": [["Aufbau", "Fill the lowest-energy orbital available first", "1s before 2s before 2p"],
                      ["Pauli exclusion", "Maximum two electrons per orbital, opposite spins", "1s2 = one up, one down"],
                      ["Hund's rule", "Equal-energy orbitals fill singly (parallel spins) before pairing", "N: 2p3 = three unpaired"]]},
        ],
        "sources": [_LIB_SOURCE],
        "footer_line": "Lowest first, two per orbital, one each before pairing.",
        "_offline_library": True,
    }


# --------------------------------------------------------------------------- matching
def _which_pack(topic):
    t = re.sub(r"[\u00b3\u00b2]", lambda m: {"\u00b3": "3", "\u00b2": "2"}[m.group(0)], (topic or "").lower())
    t = re.sub(r"\s+", " ", t)
    if re.search(r"\bsp\s*-?\s*3(?![0-9a-z])|\bsp\s*(?:cubed|three)\b", t):
        return "sp3"
    if re.search(r"\bsp\s*-?\s*2(?![0-9a-z])|\bsp\s*(?:squared|two)\b", t):
        return "sp2"
    if re.search(r"\bsp\b(?!\s*-?\s*\d)(?:\s+(?:hybrid|orbital|bond))", t) or re.search(r"\bsp\s+hybridi[sz]", t):
        return "sp"
    if re.search(r"hybridi[sz]ation|hybrid orbital|hybridi[sz]ed orbital|hybrid atomic", t):
        return "overview"
    if re.search(r"\b(?:atomic\s+|electron\s+)?orbitals?\b|\bsubshells?\b|electron(?:ic)?\s+configuration", t):
        return "orbitals"
    return None


def lookup(topic, syllabus_name="", syllabus_year=""):
    """Return curated `sections` for the topic, or None when it is not covered."""
    try:
        key = _which_pack(topic)
        name = (syllabus_name or "").strip()
        year = str(syllabus_year or "").strip()
        if key == "sp3":
            return _sp3(name, year)
        if key == "sp2":
            return _sp2(name, year)
        if key == "sp":
            return _sp(name, year)
        if key == "overview":
            return _sp3(name, year, overview=True)
        if key == "orbitals":
            return _orbitals(name, year)
    except Exception:
        return None
    return None


def covered_topics():
    return ["sp3 hybridisation", "sp2 hybridisation", "sp hybridisation", "hybridisation overview",
            "atomic orbitals / electronic configuration"]


def to_plan(sections, topic=""):
    """Convert a curated notes dict into the document 'content package' used by the
    Word / PDF / PowerPoint / Excel builders in friday_creation_engine.py."""
    if not isinstance(sections, dict):
        return None

    def txt(x):
        if isinstance(x, dict):
            for k in ("text", "explanation", "meaning", "detail", "content", "point"):
                if x.get(k):
                    return str(x[k])
            return ""
        return str(x or "")

    out = []
    if sections.get("what_is"):
        out.append({"heading": "What it is", "body": sections["what_is"],
                    "bullets": [txt(x) for x in (sections.get("key_points") or [])][:7]})
    if sections.get("topic_coverage"):
        out.append({"heading": "What this document covers", "body": "", "bullets": [txt(x) for x in sections["topic_coverage"]]})
    for proc in (sections.get("process_items") or []):
        steps = proc.get("steps") or []
        out.append({"heading": str(proc.get("title") or "Process").title(), "body": "",
                    "bullets": [f"{st.get('title', '')}: {st.get('explanation', '')}".strip(": ") if isinstance(st, dict) else txt(st) for st in steps]})
    eqs = sections.get("equation_items") or []
    if eqs:
        out.append({"heading": "Key rules and formulae", "body": "",
                    "bullets": [f"{e.get('formula', '')} - {e.get('meaning', '')}" if isinstance(e, dict) else txt(e) for e in eqs]})
    for idea in (sections.get("key_ideas") or []):
        if isinstance(idea, dict):
            out.append({"heading": str(idea.get("name") or idea.get("title") or "Key idea"),
                        "body": txt(idea), "bullets": []})
    for comp in (sections.get("comparison_tables") or []):
        if isinstance(comp, dict) and comp.get("columns") and comp.get("rows"):
            out.append({"heading": str(comp.get("title") or "Comparison"), "body": "", "bullets": [],
                        "table": {"headers": [str(c) for c in comp["columns"]],
                                  "rows": [[str(c) for c in r] for r in comp["rows"]]}})
    ex = sections.get("worked_examples") or []
    if ex:
        out.append({"heading": "Worked examples", "body": "",
                    "bullets": [f"Q: {e.get('question', '')}  A: {e.get('answer', '')}" for e in ex if isinstance(e, dict)]})
    if sections.get("common_mistakes"):
        out.append({"heading": "Common mistakes to avoid", "body": "", "bullets": [txt(x) for x in sections["common_mistakes"]]})
    if sections.get("exam_tips"):
        out.append({"heading": "Exam tips", "body": "", "bullets": [txt(x) for x in sections["exam_tips"]]})
    vocab = sections.get("vocabulary") or []
    if vocab:
        out.append({"heading": "Key terms", "body": "", "bullets": [],
                    "table": {"headers": ["Term", "Meaning"],
                              "rows": [[str(v.get("term", "")), str(v.get("meaning", ""))] for v in vocab if isinstance(v, dict)]}})
    facts = [txt(x) for x in (sections.get("quick_facts") or [])] or [txt(x) for x in (sections.get("summary_points") or [])]
    def sup(value):
        if isinstance(value, str):
            return re.sub(r"\^([0-9])", lambda m: "\u2070\u00b9\u00b2\u00b3\u2074\u2075\u2076\u2077\u2078\u2079"[int(m.group(1))], value)
        if isinstance(value, list):
            return [sup(v) for v in value]
        if isinstance(value, dict):
            return {k: sup(v) for k, v in value.items()}
        return value

    plan = {
        "title": str(sections.get("chapter_title") or topic or "Study Document"),
        "summary": " ".join(re.split(r"(?<=[.!?])\s+", str(sections.get("what_is") or "").strip())[:2]).strip()[:600],
        "key_facts": facts[:12],
        "methodology": ("Written from FRIDAY's curated exam-style reference library because the AI planning step was unavailable; "
                        "any web sources listed at the end were retrieved by the research step. Cross-check with your syllabus."),
        "sections": [s for s in out if s.get("body") or s.get("bullets") or s.get("table")],
        "_offline_library": True,
    }
    return sup(plan)
