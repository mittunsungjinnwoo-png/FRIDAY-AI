"""FRIDAY 7.3 Mission engine - one front door that wires the EXISTING modules together  (upgrade 02).

    request -> strategy73.select      what kind of request, which handler, which verification, is approval needed
            -> deterministic?         exact local answer, no model (router5.instant_answer)
            -> consequential?         STOP and report "needs_approval" unless the caller passes context["approved"]=True
            -> planner7.make_plan     bounded, dependency-aware plan (validated: no cycles, only tools that exist)
            -> orchestrator7.submit   executes with layers run in parallel where safe, per-step policy7 approvals, retries, alternatives, checkpoints
            -> verification           the orchestrator's receipts (did the file exist? did the process start?) + critic7 deterministic checks on the answer
            -> memory7                a verified outcome becomes a dated, sourced project note; an unverified one is never stored as fact
            -> truthful result        {status, verified, answer, limitations, timings}

It does NOT replace the planner, orchestrator or verifier; it only connects them and keeps four timings apart (first response, first audio,
completion, verified success) so "fast" cannot hide "wrong".  `run()` is synchronous; `ahandle()` is the asyncio wrapper; `handle(command)` answers the spoken/typed 'performance report' commands for core7.
Nothing here touches the microphone, recognition or speech code.
"""
from __future__ import annotations

import asyncio
import re
import time
from typing import Any, Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS mission73_log(id INTEGER PRIMARY KEY, ts REAL, rid TEXT, request TEXT, kind TEXT, handler TEXT, status TEXT, verified INTEGER, jid TEXT,
    first_response_ms INTEGER, first_audio_ms INTEGER, completion_ms INTEGER, steps INTEGER, verified_steps INTEGER, note TEXT);
""")

VERIFIED_MIN = 0.6              # share of finished steps the orchestrator must have independently verified
WAIT_S = 240.0

_open: Dict[str, Dict] = {}     # rid -> live timing record (for mark_first_audio)


# ------------------------------------------------------------------ timings
def begin(request: str) -> str:
    rid = K.new_id("R")
    _open[rid] = {"t0": time.perf_counter(), "first_response": None, "first_audio": None, "request": request}
    return rid


def mark_first_response(rid: str):
    r = _open.get(rid)
    if r and r["first_response"] is None:
        r["first_response"] = time.perf_counter()


def mark_first_audio(rid: Optional[str] = None):
    """Call when speech audio actually starts. With no id it marks the most recent open request."""
    r = _open.get(rid) if rid else (list(_open.values())[-1] if _open else None)
    if r and r["first_audio"] is None:
        r["first_audio"] = time.perf_counter()


def _ms(rid: str, field: str) -> Optional[int]:
    r = _open.get(rid) or {}
    v = r.get(field)
    return None if v is None else int((v - r["t0"]) * 1000)


def _finish(rid: str, st: Dict, status: str, verified: bool, jid: str, steps: int, vsteps: int, note: str) -> Dict:
    now = time.perf_counter()
    r = _open.pop(rid, {"t0": now, "first_response": None, "first_audio": None, "request": ""})
    t = {"first_response_ms": None if r["first_response"] is None else int((r["first_response"] - r["t0"]) * 1000),
         "first_audio_ms": None if r["first_audio"] is None else int((r["first_audio"] - r["t0"]) * 1000), "completion_ms": int((now - r["t0"]) * 1000)}
    try:
        C.x("INSERT INTO mission73_log(ts,rid,request,kind,handler,status,verified,jid,first_response_ms,first_audio_ms,completion_ms,steps,verified_steps,note) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (time.time(), rid, (r.get("request") or "")[:200], st["kind"], st["handler"], status, int(verified), jid, t["first_response_ms"], t["first_audio_ms"], t["completion_ms"], steps, vsteps, note[:200]))
    except Exception:
        pass
    return t


def metrics(days: float = 7.0) -> Dict:
    """The four numbers that must be read together. Verified success counts only requests that ended verified."""
    cut = time.time() - days * 86400
    rows = [dict(r) for r in C.q("SELECT * FROM mission73_log WHERE ts>?", (cut,))]
    if not rows:
        return {"requests": 0}

    def avg(f):
        v = [r[f] for r in rows if r[f] is not None]
        return int(sum(v) / len(v)) if v else None

    def p95(f):
        v = sorted(r[f] for r in rows if r[f] is not None)
        return v[min(len(v) - 1, int(len(v) * 0.95))] if v else None
    graded = [r for r in rows if r["status"] in ("done", "partial", "failed", "answered")]
    return {"requests": len(rows), "avg_first_response_ms": avg("first_response_ms"), "avg_first_audio_ms": avg("first_audio_ms"), "avg_completion_ms": avg("completion_ms"),
            "p95_completion_ms": p95("completion_ms"), "verified_success_rate": round(sum(r["verified"] for r in graded) / len(graded), 3) if graded else None,
            "needs_approval": sum(1 for r in rows if r["status"] == "needs_approval")}


# ------------------------------------------------------------------ engine
def _local_answer(text: str) -> Optional[str]:
    try:
        import friday_router5 as R5
        return R5.instant_answer(text)
    except Exception:
        return None


def _wait_job(jid: str, wait_s: float) -> Dict:
    import friday_orchestrator7 as O
    end = time.time() + wait_s
    j = O.get(jid)
    while time.time() < end:
        j = O.get(jid)
        if j and (j["state"] in O.TERMINAL or j["state"] == "waiting_approval"):
            return j
        time.sleep(0.05)
    return j or {}


def _critic_ok(answer: str, kind: str, receipts: Optional[List[Dict]]) -> Dict:
    if not answer.strip():
        return {"ok": True, "issues": []}
    try:
        import friday_critic7 as CR
        r = CR.review(answer, kind="research" if kind == "research" else None, receipts=receipts, allow_model=False)
        return {"ok": bool(r.get("ok", True)), "issues": [str(i.get("what", i))[:120] for i in (r.get("issues") or [])][:3]}
    except Exception:
        return {"ok": True, "issues": []}


def run(request: str, context: Optional[Dict] = None) -> Dict:
    """Run a request end to end. Never raises. Returns
    {status: answered|done|partial|failed|needs_approval|waiting_approval|blocked, verified: bool, answer, limitations: [..], strategy, jid, timings}"""
    ctx = dict(context or {})
    request = (request or "").strip()
    rid = begin(request)
    out: Dict[str, Any] = {"status": "failed", "verified": False, "answer": "", "limitations": [], "jid": "", "rid": rid}
    st = {"kind": "chat", "handler": "model", "verify": "none", "approval_required": False, "route": "general", "blocked": False}
    try:
        import friday_strategy73 as S
        st = S.select(request, ctx)
        out["strategy"] = {k: st[k] for k in ("kind", "handler", "route", "verify", "approval_required", "reason")}
        # 1. deterministic: exact local answer
        if st["handler"] == "local":
            ans = _local_answer(request)
            if ans:
                mark_first_response(rid)
                out.update(status="answered", verified=True, answer=ans)
                out["timings"] = _finish(rid, st, "answered", True, "", 0, 0, "local handler")
                return out
        # 2. privacy: nothing leaves the machine when no local model exists
        if st.get("blocked"):
            out.update(status="blocked", limitations=["This looks private and no local model is available, so I did not send it anywhere."])
            out["timings"] = _finish(rid, st, "blocked", False, "", 0, 0, "private, no local model")
            return out
        # 3. consequential action: the caller (or the user) must approve first
        if st["approval_required"] and not ctx.get("approved"):
            out.update(status="needs_approval", limitations=["This would change something outside FRIDAY or cannot be undone, so I need your explicit approval first."],
                       answer=f"Before I do this: {request[:160]}. Shall I go ahead?")
            mark_first_response(rid)
            out["timings"] = _finish(rid, st, "needs_approval", False, "", 0, 0, "approval gate")
            return out
        # 4. plain model answer (no mission needed)
        if st["handler"] in ("model", "research") and st["kind"] != "mission" and not ctx.get("force_mission"):
            r = S.call(request, strategy=st, caller=ctx.get("caller"))
            mark_first_response(rid)
            ok = bool(r["ok"])
            crit = _critic_ok(r["text"], st["kind"], None) if ok and st["verify"] in ("critic", "arithmetic", "evidence") else {"ok": True, "issues": []}
            lim = []
            if not ok:
                lim.append(r["note"] or "no model produced an answer")
            if r.get("quality", 1) < 0.45 and ok:
                lim.append("the answer scored low on my quality checks; treat it with care")
            lim += crit["issues"]
            if st["kind"] == "research":
                lim.append("answer is from a model, not independently source-checked; ask me to research it for cited evidence")
            if st["kind"] == "code":
                lim.append("code was not executed; ask me to run the tests")
            verified = ok and crit["ok"] and st["verify"] in ("none", "arithmetic", "critic") and r["quality"] >= 0.45 and st["kind"] not in ("code", "research")
            out.update(status="answered" if ok else "failed", verified=verified, answer=r["text"], limitations=lim, model=r["model"], quality=r["quality"])
            out["timings"] = _finish(rid, st, "answered" if ok else "failed", verified, "", 0, 0, r["note"])
            return out
        # 5. mission: plan -> execute -> verify
        import friday_orchestrator7 as O
        import friday_planner7 as P
        plan = ctx.get("plan") or P.make_plan(request, None, O.registry)
        mark_first_response(rid)
        jid = O.submit(request, plan=plan, source=ctx.get("source", "user"), speak=bool(ctx.get("speak", False)), budget_s=float(ctx.get("budget_s", O.DEFAULT_BUDGET)),
                       intent=O.classify_intent(request).get("domain"))
        out["jid"] = jid
        job = _wait_job(jid, float(ctx.get("wait_s", WAIT_S)))
        state = job.get("state", "failed")
        if state == "waiting_approval":
            out.update(status="waiting_approval", limitations=["A step needs your approval before the mission can continue."], answer=job.get("report") or "")
            out["timings"] = _finish(rid, st, "waiting_approval", False, jid, 0, 0, "waiting for approval")
            return out
        steps = job.get("plan") or []
        results = job.get("results") or {}
        done = [s for s in steps if s.get("status") == "done"]
        vsteps = sum(1 for s in done if (results.get(str(s["id"])) or {}).get("status") == "verified")
        ratio = vsteps / len(done) if done else 0.0
        report = job.get("report") or ""
        crit = _critic_ok(report, st["kind"], None)
        lim = []
        bad = [s for s in steps if s.get("status") in ("failed", "cancelled") or (s.get("status") == "skipped" and not s.get("optional"))]
        lim += [f"not completed: {s.get('desc')} ({str(s.get('error', s.get('status')))[:70]})" for s in bad[:3]]
        if done and ratio < VERIFIED_MIN:
            lim.append(f"only {vsteps} of {len(done)} finished steps were independently verified")
        lim += crit["issues"]
        verified = state == "done" and ratio >= VERIFIED_MIN and crit["ok"]
        out.update(status=state, verified=verified, answer=report, limitations=lim, steps={"total": len(steps), "done": len(done), "verified": vsteps})
        # 6. memory: only verified work is stored, with provenance
        if verified and ctx.get("project"):
            try:
                import friday_memory7 as M
                M.project_note(ctx["project"], f"Completed and verified: {request[:120]} ({vsteps}/{len(done)} steps verified).", kind="progress", source="job")
            except Exception:
                pass
        out["timings"] = _finish(rid, st, state, verified, jid, len(steps), vsteps, "; ".join(lim)[:200])
        return out
    except Exception as exc:
        C.log(f"mission73 failed safely: {type(exc).__name__}: {exc}", "recovery")
        out.update(status="failed", limitations=[f"internal error: {type(exc).__name__}"])
        out["timings"] = _finish(rid, st, "failed", False, out.get("jid", ""), 0, 0, f"{type(exc).__name__}")
        return out


async def ahandle(request: str, context: Optional[Dict] = None) -> Dict:
    return await asyncio.to_thread(run, request, context)


class FridayMissionEngine:
    """The shape from the upgrade plan, backed by the real modules. Pass your own to substitute a part (used by the tests)."""

    def __init__(self, **parts):
        self.parts = parts

    def handle(self, request: str, context: Optional[Dict] = None) -> Dict:
        return run(request, {**(context or {}), **self.parts})

    async def ahandle(self, request: str, context: Optional[Dict] = None) -> Dict:
        return await ahandle(request, {**(context or {}), **self.parts})


def spoken(res: Dict) -> str:
    if res["status"] == "needs_approval":
        return res["answer"]
    head = {"answered": "", "done": "Done and verified. " if res["verified"] else "Done, but not fully verified. ", "partial": "Partly done. ", "failed": "I couldn't do that. ",
            "blocked": "I didn't send that anywhere. ", "waiting_approval": "I need your approval to continue. "}.get(res["status"], "")
    body = re.sub(r"\s+", " ", (res.get("answer") or "")).strip()
    lim = (" Note: " + res["limitations"][0]) if res.get("limitations") and res["status"] != "answered" else ""
    return (head + K.clip(body, 500) + lim).strip()


def handle(command: str) -> Optional[str]:
    low = K.norm_cmd(command)
    if re.match(r"^(?:speed|performance|latency) (?:metrics|numbers|report)$|^how (?:fast|reliable) (?:are|is) (?:you|friday)$", low):
        m = metrics()
        if not m.get("requests"):
            return "No missions have been recorded yet."
        return (f"Over {m['requests']} request(s): first response about {m['avg_first_response_ms']} ms, first audio {m['avg_first_audio_ms'] if m['avg_first_audio_ms'] is not None else 'not measured'} ms, "
                f"completion about {m['avg_completion_ms']} ms, verified success {'n/a' if m['verified_success_rate'] is None else format(m['verified_success_rate'], '.0%')}.")
    return None
