"""FRIDAY 5.0 long-term memory, personal knowledge base and goal manager (one local SQLite file, no network).

Retrieval -> reasoning -> response -> memory update, instead of dumping a memory file into every prompt:

  memories   facts, preferences, decisions, projects, events, lessons (failures / successes), tasks
  kb         chunks of the user's documents (attachments, folders) searchable by full text
  goals      long-term goals with steps, deadline and progress

Everything is searched with SQLite FTS5 (BM25) plus a recency/importance boost, in a few milliseconds, so it is
safe to call on the voice critical path. Secrets (API keys, passwords, card numbers) are never stored.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import threading
import time
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Optional

HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("FRIDAY_DATA") or (HERE / "friday_data"))
DB_PATH = Path(os.environ.get("FRIDAY_V5_DB") or (DATA_DIR / "friday5.db"))
_lock = threading.RLock()
_conn: Optional[sqlite3.Connection] = None
_fts = True

KINDS = ("fact", "preference", "decision", "project", "event", "lesson", "task", "person")

_SECRET = re.compile(r"(AIza[0-9A-Za-z_\-]{20,}|sk-[A-Za-z0-9_\-]{16,}|\b(?:password|passcode|pin|cvv|api[ _-]?key|secret)\b\s*(?:is|=|:)\s*\S+|\b\d{13,19}\b)", re.I)


def _db() -> sqlite3.Connection:
    global _conn, _fts
    if _conn is not None:
        return _conn
    with _lock:
        if _conn is not None:
            return _conn
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=10)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.executescript("""
        CREATE TABLE IF NOT EXISTS memories(
            id INTEGER PRIMARY KEY, kind TEXT, text TEXT, norm TEXT UNIQUE, tags TEXT, source TEXT,
            importance REAL, created REAL, used INTEGER DEFAULT 0, last_used REAL);
        CREATE TABLE IF NOT EXISTS kb(
            id INTEGER PRIMARY KEY, doc TEXT, path TEXT, chunk INTEGER, text TEXT, created REAL);
        CREATE TABLE IF NOT EXISTS goals(
            id INTEGER PRIMARY KEY, title TEXT, deadline TEXT, status TEXT, created REAL, notes TEXT);
        CREATE TABLE IF NOT EXISTS goal_steps(
            id INTEGER PRIMARY KEY, goal_id INTEGER, idx INTEGER, text TEXT, done INTEGER DEFAULT 0);
        """)
        try:
            c.executescript("""
            CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(text, tags, content='memories', content_rowid='id');
            CREATE VIRTUAL TABLE IF NOT EXISTS kb_fts USING fts5(text, doc, content='kb', content_rowid='id');
            """)
            _fts = True
        except sqlite3.OperationalError:
            _fts = False
        c.commit()
        _conn = c
        return c


def reset_for_tests(path: Path):
    global _conn, DB_PATH
    with _lock:
        if _conn is not None:
            _conn.close()
        _conn = None
        DB_PATH = Path(path)


def _norm(t: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", "", (t or "").lower()).strip()


def _tokens(q: str) -> List[str]:
    stop = {"the", "a", "an", "is", "are", "was", "were", "of", "to", "in", "on", "for", "and", "or", "what", "did", "do", "we",
            "i", "my", "me", "you", "it", "that", "this", "about", "with", "have", "has", "how", "when", "why", "who", "can", "tell"}
    return [w for w in re.findall(r"[a-z0-9]{2,}", (q or "").lower()) if w not in stop][:12]


def _fts_query(q: str) -> str:
    toks = _tokens(q)
    return " OR ".join(f'"{t}"*' for t in toks)


# ----------------------------------------------------------------- memories
def remember(text: str, kind: str = "fact", tags: str = "", source: str = "user", importance: float = 0.6) -> Optional[int]:
    text = re.sub(r"\s+", " ", (text or "")).strip(" .")
    if len(text) < 3 or _SECRET.search(text):
        return None
    kind = kind if kind in KINDS else "fact"
    with _lock:
        c = _db()
        n = _norm(text)
        row = c.execute("SELECT id FROM memories WHERE norm=?", (n,)).fetchone()
        if row:
            c.execute("UPDATE memories SET importance=MAX(importance,?), last_used=? WHERE id=?", (importance, time.time(), row["id"]))
            c.commit()
            return int(row["id"])
        cur = c.execute("INSERT INTO memories(kind,text,norm,tags,source,importance,created,last_used) VALUES(?,?,?,?,?,?,?,?)",
                        (kind, text, n, tags, source, float(importance), time.time(), time.time()))
        mid = cur.lastrowid
        if _fts:
            c.execute("INSERT INTO memories_fts(rowid,text,tags) VALUES(?,?,?)", (mid, text, tags))
        c.commit()
        return int(mid)


def forget(text: str) -> int:
    toks = _tokens(text)
    if not toks:
        return 0
    removed = 0
    with _lock:
        c = _db()
        for r in c.execute("SELECT id,text FROM memories").fetchall():
            low = r["text"].lower()
            if all(t in low for t in toks):
                if _fts:
                    c.execute("INSERT INTO memories_fts(memories_fts,rowid,text,tags) SELECT 'delete',id,text,tags FROM memories WHERE id=?", (r["id"],))
                c.execute("DELETE FROM memories WHERE id=?", (r["id"],))
                removed += 1
        c.commit()
    return removed


def search(query: str, k: int = 6, kinds: Optional[List[str]] = None) -> List[Dict]:
    c = _db()
    rows = []
    with _lock:
        try:
            if _fts and _fts_query(query):
                rows = c.execute(
                    "SELECT m.*, bm25(memories_fts) AS rank FROM memories_fts JOIN memories m ON m.id=memories_fts.rowid "
                    "WHERE memories_fts MATCH ? ORDER BY rank LIMIT ?", (_fts_query(query), k * 3)).fetchall()
            else:
                toks = _tokens(query)
                if toks:
                    like = " OR ".join("lower(text) LIKE ?" for _ in toks)
                    rows = c.execute(f"SELECT *, 0.0 AS rank FROM memories WHERE {like} LIMIT ?", [f"%{t}%" for t in toks] + [k * 3]).fetchall()
        except sqlite3.OperationalError:
            rows = []
    now = time.time()
    out = []
    for r in rows:
        if kinds and r["kind"] not in kinds:
            continue
        age_days = (now - (r["created"] or now)) / 86400.0
        score = -float(r["rank"] or 0) + 1.5 * float(r["importance"] or 0.5) + 0.8 / (1.0 + age_days / 30.0) + 0.1 * min(5, r["used"] or 0)
        out.append((score, dict(r)))
    out.sort(key=lambda x: -x[0])
    return [d for _, d in out[:k]]


def touch(ids: List[int]):
    if not ids:
        return
    with _lock:
        c = _db()
        c.executemany("UPDATE memories SET used=used+1,last_used=? WHERE id=?", [(time.time(), i) for i in ids])
        c.commit()


def all_memories(limit: int = 200) -> List[Dict]:
    with _lock:
        return [dict(r) for r in _db().execute("SELECT * FROM memories ORDER BY created DESC LIMIT ?", (limit,)).fetchall()]


_PATTERNS = [
    (re.compile(r"\b(?:remember|note|keep in mind)(?: that)?\s+(.+)", re.I), "fact", 0.9),
    (re.compile(r"\b(?:i|we)\s+(?:have\s+)?(?:decided|chose|choose|agreed)(?: to| on| that)?\s+(.+)", re.I), "decision", 0.85),
    (re.compile(r"\bmy\s+((?:favou?rite|preferred|main|usual)\s+[a-z ]{2,30}?\s+(?:is|are)\s+.+)", re.I), "preference", 0.8),
    (re.compile(r"\bi\s+(?:prefer|like|love|hate|dislike|always|never|usually)\s+(.+)", re.I), "preference", 0.6),
    (re.compile(r"\bi(?:'m| am)\s+(?:currently\s+)?(?:working on|building|making|studying|learning)\s+(.+)", re.I), "project", 0.75),
    (re.compile(r"\bmy\s+(name|birthday|exam|deadline|competition|project|school|college|laptop|phone)\s+(?:is|are|will be|starts|ends|on)\s+(.+)", re.I), "fact", 0.8),
    (re.compile(r"\bcall me\s+(.+)", re.I), "preference", 0.8),
]


def extract_from_exchange(user_text: str, answer: str = "") -> List[int]:
    """Cheap, deterministic extraction of durable facts from what the user said (runs off the critical path)."""
    ids = []
    t = (user_text or "").strip()
    if not t or len(t) > 600 or t.endswith("?"):
        return ids
    for rx, kind, imp in _PATTERNS:
        m = rx.search(t)
        if m:
            body = " ".join(g for g in m.groups() if g) if rx.groups > 1 else m.group(1)
            if rx.groups > 1:
                body = f"my {m.group(1)} is {m.group(2)}" if m.group(1) in {"name", "birthday", "exam", "deadline", "competition", "project", "school", "college", "laptop", "phone"} else body
            mid = remember(body.strip(), kind=kind, source="chat", importance=imp)
            if mid:
                ids.append(mid)
            break
    return ids


def record_outcome(task: str, success: bool, detail: str = ""):
    """Learn from failed and successful attempts (kind='lesson')."""
    txt = f"{'Worked' if success else 'Failed'}: {task[:140]}" + (f" - {detail[:160]}" if detail else "")
    remember(txt, kind="lesson", source="agent", importance=0.5 if success else 0.7)


# ----------------------------------------------------------------- knowledge base
def _chunks(text: str, size: int = 1100, overlap: int = 150) -> List[str]:
    text = re.sub(r"[ \t]+", " ", text or "")
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    out, i = [], 0
    while i < len(text):
        j = min(len(text), i + size)
        if j < len(text):
            cut = max(text.rfind("\n", i + size // 2, j), text.rfind(". ", i + size // 2, j))
            if cut > i:
                j = cut + 1
        out.append(text[i:j].strip())
        if j >= len(text):
            break
        i = max(j - overlap, i + 1)
    return [c for c in out if len(c) > 30]


def ingest_text(doc: str, text: str, path: str = "") -> int:
    chunks = _chunks(text)
    if not chunks:
        return 0
    with _lock:
        c = _db()
        old = c.execute("SELECT id FROM kb WHERE doc=?", (doc,)).fetchall()
        for r in old:
            if _fts:
                c.execute("INSERT INTO kb_fts(kb_fts,rowid,text,doc) SELECT 'delete',id,text,doc FROM kb WHERE id=?", (r["id"],))
        c.execute("DELETE FROM kb WHERE doc=?", (doc,))
        for i, ch in enumerate(chunks[:2000]):
            cur = c.execute("INSERT INTO kb(doc,path,chunk,text,created) VALUES(?,?,?,?,?)", (doc, path, i, ch, time.time()))
            if _fts:
                c.execute("INSERT INTO kb_fts(rowid,text,doc) VALUES(?,?,?)", (cur.lastrowid, ch, doc))
        c.commit()
    return len(chunks)


def search_kb(query: str, k: int = 4) -> List[Dict]:
    c = _db()
    with _lock:
        try:
            if _fts and _fts_query(query):
                rows = c.execute("SELECT kb.*, bm25(kb_fts) AS rank FROM kb_fts JOIN kb ON kb.id=kb_fts.rowid WHERE kb_fts MATCH ? ORDER BY rank LIMIT ?",
                                 (_fts_query(query), k)).fetchall()
            else:
                toks = _tokens(query)
                rows = c.execute("SELECT *, 0 AS rank FROM kb WHERE " + " OR ".join("lower(text) LIKE ?" for _ in toks) + " LIMIT ?",
                                 [f"%{t}%" for t in toks] + [k]).fetchall() if toks else []
        except sqlite3.OperationalError:
            rows = []
    return [dict(r) for r in rows]


def kb_docs() -> List[Dict]:
    with _lock:
        return [dict(r) for r in _db().execute("SELECT doc, COUNT(*) AS chunks FROM kb GROUP BY doc ORDER BY MAX(created) DESC").fetchall()]


def index_folder(folder: str, max_files: int = 300) -> int:
    exts = {".txt", ".md", ".py", ".js", ".json", ".csv", ".html", ".css", ".java", ".c", ".cpp", ".cs", ".ts", ".tsx", ".yml", ".yaml", ".log"}
    n = 0
    for p in Path(folder).rglob("*"):
        if n >= max_files:
            break
        if p.is_file() and p.suffix.lower() in exts and p.stat().st_size < 1_500_000 and not any(x in p.parts for x in ("node_modules", ".git", "__pycache__")):
            try:
                ingest_text(p.name, p.read_text(encoding="utf-8", errors="replace"), str(p))
                n += 1
            except Exception:
                pass
    return n


# ----------------------------------------------------------------- goals
def goal_add(title: str, steps: Optional[List[str]] = None, deadline: str = "", notes: str = "") -> int:
    with _lock:
        c = _db()
        cur = c.execute("INSERT INTO goals(title,deadline,status,created,notes) VALUES(?,?,?,?,?)", (title.strip(), deadline, "active", time.time(), notes))
        gid = cur.lastrowid
        for i, s in enumerate(steps or []):
            c.execute("INSERT INTO goal_steps(goal_id,idx,text) VALUES(?,?,?)", (gid, i, s.strip()))
        c.commit()
    remember(f"Goal: {title.strip()}" + (f" (deadline {deadline})" if deadline else ""), kind="project", source="goal", importance=0.85)
    return int(gid)


def goal_steps_add(goal_id: int, steps: List[str]):
    with _lock:
        c = _db()
        base = c.execute("SELECT COALESCE(MAX(idx)+1,0) FROM goal_steps WHERE goal_id=?", (goal_id,)).fetchone()[0]
        for i, s in enumerate(steps):
            c.execute("INSERT INTO goal_steps(goal_id,idx,text) VALUES(?,?,?)", (goal_id, base + i, s.strip()))
        c.commit()


def goals(active_only: bool = True) -> List[Dict]:
    with _lock:
        c = _db()
        rows = c.execute("SELECT * FROM goals" + (" WHERE status='active'" if active_only else "") + " ORDER BY created DESC").fetchall()
        out = []
        for g in rows:
            st = [dict(s) for s in c.execute("SELECT * FROM goal_steps WHERE goal_id=? ORDER BY idx", (g["id"],)).fetchall()]
            done = sum(1 for s in st if s["done"])
            d = dict(g)
            d["steps"] = st
            d["progress"] = round(100 * done / len(st)) if st else 0
            out.append(d)
        return out


def find_goal(name: str) -> Optional[Dict]:
    toks = _tokens(name)
    best, score = None, 0
    for g in goals():
        s = sum(1 for t in toks if t in g["title"].lower())
        if s > score:
            best, score = g, s
    return best or (goals()[0] if goals() and not toks else None)


def step_done(goal_id: int, which) -> bool:
    with _lock:
        c = _db()
        steps = c.execute("SELECT * FROM goal_steps WHERE goal_id=? ORDER BY idx", (goal_id,)).fetchall()
        target = None
        if isinstance(which, int) and 0 <= which < len(steps):
            target = steps[which]
        else:
            toks = _tokens(str(which))
            for s in steps:
                if toks and all(t in s["text"].lower() for t in toks[:2]):
                    target = s
                    break
        if not target:
            return False
        c.execute("UPDATE goal_steps SET done=1 WHERE id=?", (target["id"],))
        c.commit()
        return True


def goal_complete(goal_id: int):
    with _lock:
        c = _db()
        c.execute("UPDATE goals SET status='done' WHERE id=?", (goal_id,))
        c.commit()


def goals_text() -> str:
    gs = goals()
    if not gs:
        return "You have no active goals yet. Say, for example, 'my goal is to prepare for my exams' and I will build a plan."
    parts = []
    for g in gs[:5]:
        nxt = next((s["text"] for s in g["steps"] if not s["done"]), None)
        parts.append(f"{g['title']}: {g['progress']} percent" + (f", next step: {nxt}" if nxt else "") + (f", deadline {g['deadline']}" if g["deadline"] else ""))
    return "Your active goals. " + ". ".join(parts) + "."


# ----------------------------------------------------------------- prompt context
def context_block(question: str, k_mem: int = 5, k_kb: int = 3) -> str:
    """Relevant memories + document snippets + active goals for ONE question (a few hundred tokens, not the whole memory)."""
    parts = []
    try:
        mem = search(question, k=k_mem)
        if mem:
            touch([m["id"] for m in mem])
            parts.append("Relevant things FRIDAY remembers about the user:\n" + "\n".join(f"- [{m['kind']}] {m['text']}" for m in mem))
        if re.search(r"\b(document|file|pdf|notes?|project|code|report|decid|earlier|before|last time|we discussed|attached|uploaded)\b", question, re.I) or not mem:
            kb = search_kb(question, k=k_kb)
            if kb:
                parts.append("Relevant excerpts from the user's own documents:\n" + "\n".join(f"- ({d['doc']}) {d['text'][:420]}" for d in kb))
        if re.search(r"\b(goal|plan|progress|deadline|prepare|schedule|study|revis)\b", question, re.I):
            gs = goals()
            if gs:
                parts.append("Active goals:\n" + "\n".join(f"- {g['title']} ({g['progress']}%)" for g in gs[:4]))
    except Exception:
        return ""
    return ("\n\n" + "\n\n".join(parts)) if parts else ""


# ----------------------------------------------------------------- natural language commands
def handle(command: str) -> Optional[str]:
    """Memory / knowledge / goal voice-and-text commands. Returns the spoken reply, or None if not for us."""
    t = (command or "").strip()
    low = t.lower().strip(" .!?")
    m = re.match(r"^(?:please\s+)?remember(?: that)?\s+(.+)$", t, re.I)
    if m:
        body = m.group(1)
        kind = "decision" if re.match(r"(?:we|i)\s+(?:decided|agreed|chose)", body, re.I) else "fact"
        if remember(body, kind=kind, source="user", importance=0.9):
            return "Noted. I will remember that."
        return "I can't store that one, as it looks like a secret such as a password or key."
    m = re.match(r"^(?:please\s+)?forget(?: about| that)?\s+(.+)$", t, re.I)
    if m:
        n = forget(m.group(1))
        return "Done. I have forgotten that." if n else "I could not find a memory matching that."
    m = re.match(r"^(?:what|who)\s+(?:do you|did you)\s+(?:remember|know)\s+about\s+(.+)$", low) or re.match(r"^(?:what did we|what have we)\s+(?:decide|discuss|say|agree)(?:d)?\s+(?:about|on|regarding)\s+(.+)$", low) \
        or re.match(r"^(?:remind me\s+(?:what|about)|do you remember(?:\s+(?:what|about))?)\s+(.+)$", low)
    if m:
        topic = m.group(1)
        mem = search(topic, k=5)
        kb = search_kb(topic, k=2)
        if not mem and not kb:
            try:                                            # FRIDAY 6.0: dated memories live in a second store; look there before giving up
                import friday_memory6 as _m6
                hits = _m6.search(topic, k=3)
                if hits:
                    return "Here is what I have. " + ". ".join(f"{h['text']} (noted {_m6.C.day(h['ts'])}" + ("" if h["status"] == "confirmed" else ", not confirmed") + ")" for h in hits) + "."
            except Exception:
                pass
            return f"I don't have anything stored about {topic} yet."
        bits = [x["text"] for x in mem]
        bits += [f"from {d['doc']}: {d['text'][:200]}" for d in kb]
        touch([x["id"] for x in mem])
        return "Here is what I have. " + ". ".join(bits[:5]) + "."
    if re.match(r"^(?:what do you remember|show (?:me )?(?:my )?memories|list (?:my )?memories)$", low):
        mem = all_memories(8)
        return ("I remember: " + ". ".join(x["text"] for x in mem) + ".") if mem else "I haven't stored anything yet."
    m = re.match(r"^(?:my goal is(?: to)?|set (?:a )?goal(?: to| of)?|new goal[: ]|add (?:a )?goal(?: to)?)\s+(.+)$", t, re.I)
    if m:
        title = m.group(1).strip(" .")
        dl = ""
        d = re.search(r"\bby\s+((?:\d{4}-\d{2}-\d{2})|(?:[A-Z][a-z]+ \d{1,2}(?:, \d{4})?))\s*$", title)
        if d:
            dl, title = d.group(1), title[:d.start()].strip(" ,")
        gid = goal_add(title, deadline=dl)
        return f"Goal set: {title}. Tell me the steps, or say 'plan my goal' and I will break it down for you."
    if re.match(r"^(?:goal progress|my goals|show (?:my )?goals|how are my goals(?: going)?|goal status)$", low):
        return goals_text()
    m = re.match(r"^(?:add step|next step)\s+(.+?)(?:\s+to\s+(?:my\s+)?goal\s+(.+))?$", t, re.I)
    if m and goals():
        g = find_goal(m.group(2) or "")
        if g:
            goal_steps_add(g["id"], [m.group(1)])
            return f"Added that step to {g['title']}."
    m = re.match(r"^(?:mark\s+)?step\s+(.+?)\s+(?:as\s+)?done(?:\s+(?:in|for|on)\s+(?:my\s+)?goal\s+(.+))?$", low) or re.match(r"^i(?:'ve| have)?\s+(?:finished|completed|done)\s+(?:the\s+)?step\s+(.+)$", low)
    if m and goals():
        g = find_goal(m.group(2) if m.lastindex and m.lastindex >= 2 and m.group(2) else "") or goals()[0]
        w = m.group(1).strip()
        which = int(w) - 1 if w.isdigit() else w
        if step_done(g["id"], which):
            g2 = next((x for x in goals() if x["id"] == g["id"]), g)
            return f"Done. {g2['title']} is now {g2['progress']} percent complete."
        return "I couldn't find that step."
    m = re.match(r"^(?:index|learn from|add to (?:my )?knowledge(?: base)?)\s+(?:the\s+)?(?:folder\s+)?(.+)$", t, re.I)
    if m and os.path.isdir(m.group(1).strip().strip('"')):
        n = index_folder(m.group(1).strip().strip('"'))
        return f"Indexed {n} files. You can now ask me about what is in them."
    return None


def health() -> dict:
    try:
        c = _db()
        return {"engine": "friday_knowledge5", "fts5": _fts, "memories": c.execute("SELECT COUNT(*) FROM memories").fetchone()[0],
                "kb_chunks": c.execute("SELECT COUNT(*) FROM kb").fetchone()[0], "goals": len(goals())}
    except Exception as exc:
        return {"engine": "friday_knowledge5", "error": str(exc)}
