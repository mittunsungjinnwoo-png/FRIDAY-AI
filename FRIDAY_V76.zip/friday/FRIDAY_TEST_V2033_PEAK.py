import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parent
files = list(ROOT.glob("*.py"))
for path in files:
    ast.parse(path.read_text(encoding="utf-8", errors="ignore"), filename=str(path))

required = [
    "friday_voice_engine.py",
    "friday_backend.py",
    "friday_peak_engine.py",
    "friday_peak_orchestrator.py",
]
missing = [x for x in required if not (ROOT / x).exists()]
if missing:
    raise SystemExit("Missing required V2033 files: " + ", ".join(missing))

backend = (ROOT / "friday_backend.py").read_text(encoding="utf-8", errors="ignore")
voice = (ROOT / "friday_voice_engine.py").read_text(encoding="utf-8", errors="ignore")
assert "_adaptive_vad_pause_seconds" in backend
assert "recognize_google" in voice or "recognize_google" in backend
assert "faster_whisper" in voice
print(f"FRIDAY V2033 peak architecture audit: PASS ({len(files)} Python files)")
