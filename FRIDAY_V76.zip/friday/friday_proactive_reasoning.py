"""FRIDAY Peak Proactive Reasoning Engine v2043.

A deterministic, bounded, domain-neutral anticipatory reasoning layer.  It
constructs a compact model of the user's objective, predicts prerequisites,
latent constraints, dependencies, risks, temporal conditions, opportunities,
recovery paths and verification gates, then exposes that model to the existing
agent planner.  It NEVER performs external or consequential actions.

Design guarantees:
- No microphone, VAD, ASR, recognition or TTS code.
- No automatic sending, deleting, installing, shutdown or other consequential action.
- No network dependency and no background worker.
- Bounded persistence and CPU/memory use suitable for an 8 GB-class Windows PC.
- Conservative initiative: proactive preparation, not autonomous authority.
- Fail-safe API: malformed input returns a valid conservative model.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import threading
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

VERSION = "2043.0"
ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / "friday_proactive_state.json"
_LOCK = threading.RLock()
_MAX_RECENT = 300
_MAX_OUTCOMES = 600
_MAX_PATTERN_HISTORY = 400

_STATE: dict[str, Any] = {
    "patterns": {},
    "outcomes": {},
    "recent": [],
    "metrics": {"analyses": 0, "high_confidence": 0, "clarifications": 0},
}

try:
    if STATE_FILE.exists():
        raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            for k in _STATE:
                if k in raw and isinstance(raw[k], type(_STATE[k])):
                    _STATE[k] = raw[k]
except Exception:
    pass


def _save() -> None:
    """Atomically persist bounded state; proactive reasoning never depends on it."""
    try:
        _STATE["recent"] = _STATE.get("recent", [])[-_MAX_RECENT:]
        _STATE["outcomes"] = dict(list(_STATE.get("outcomes", {}).items())[-_MAX_OUTCOMES:])
        _STATE["patterns"] = dict(list(_STATE.get("patterns", {}).items())[-_MAX_PATTERN_HISTORY:])
        payload = json.dumps(_STATE, ensure_ascii=False, indent=2, separators=(",", ":"))
        if len(payload) > 1_800_000:
            _STATE["recent"] = _STATE["recent"][-150:]
            _STATE["patterns"] = dict(list(_STATE["patterns"].items())[-200:])
            payload = json.dumps(_STATE, ensure_ascii=False, indent=2)
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(payload, encoding="utf-8")
        tmp.replace(STATE_FILE)
    except Exception:
        pass


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9][a-z0-9_-]{1,}", (text or "").lower())


def _id(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8", "ignore")).hexdigest()[:16]


def _has(text: str, *patterns: str) -> bool:
    low = (text or "").lower()
    return any(re.search(p, low) for p in patterns)


def _clamp(value: float) -> float:
    return round(max(0.0, min(1.0, float(value))), 3)


def _sigmoid(x: float) -> float:
    try:
        return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, x))))
    except Exception:
        return 0.5


def _request_signals(command: str) -> dict[str, Any]:
    c = (command or "").strip()
    low = c.lower()
    return {
        "research": _has(low, r"\b(research|look\s*up|find out|investigate|latest|current|verify|sources?)\b"),
        "creation": _has(low, r"\b(create|make|generate|build|write|draft|document|report|pdf|docx|xlsx|pptx)\b"),
        "comparison": _has(low, r"\b(compare|difference|versus|vs\.?|better|contrast|pros? and cons?)\b"),
        "planning": _has(low, r"\b(plan|planning|schedule|roadmap|steps|strategy|organize|prepare)\b"),
        "system_action": _has(low, r"\b(open|close|run|execute|install|change|delete|remove|shutdown|restart|launch|click|type)\b"),
        "communication": _has(low, r"\b(send|message|email|whatsapp|reply|tell|post|share)\b"),
        "learning": _has(low, r"\b(learn|study|explain|teach|notes|exam|quiz|practice|understand)\b"),
        "time_sensitive": _has(low, r"\b(today|tonight|tomorrow|now|latest|current|deadline|due|urgent|this week)\b"),
        "file_output": _has(low, r"\b(file|folder|document|pdf|docx|xlsx|pptx|save|export|download)\b"),
        "security_sensitive": _has(low, r"\b(password|credential|token|api key|secret|permission|admin|security|delete|wipe)\b"),
        "financial": _has(low, r"\b(pay|payment|purchase|buy|sell|transfer|bank|money|invoice)\b"),
        "question": bool(re.search(r"\?|\b(what|why|how|when|where|which|who|can you|could you)\b", low)),
        "multi_stage": _has(low, r"\b(and then|after that|then|once|followed by|first|next|finally)\b") or c.count(",") >= 2,
    }


def _classify_goal(command: str, signals: dict[str, Any]) -> dict[str, Any]:
    """Infer goal structure without pretending uncertain intent is certain."""
    low = command.lower()
    if signals["communication"]:
        family = "communication"
    elif signals["system_action"]:
        family = "computer_action"
    elif signals["creation"]:
        family = "artifact_creation"
    elif signals["research"]:
        family = "research"
    elif signals["learning"]:
        family = "learning"
    elif signals["planning"]:
        family = "planning"
    else:
        family = "information"

    explicit_goal = command.strip()[:500]
    success_cues = []
    if signals["creation"]:
        success_cues += ["artifact exists", "artifact passes structural/content inspection"]
    if signals["research"]:
        success_cues += ["claims have adequate evidence", "important uncertainty is surfaced"]
    if signals["system_action"]:
        success_cues += ["requested state change is observed"]
    if signals["communication"]:
        success_cues += ["recipient and content are verified before transmission"]
    if not success_cues:
        success_cues.append("answer addresses the explicit objective accurately")

    return {"family": family, "explicit_goal": explicit_goal, "success_cues": success_cues,
            "user_intent_strength": _clamp(0.55 + 0.08 * len(_tokens(command)) + 0.12 * signals["multi_stage"])}


def _missing_constraints(command: str, signals: dict[str, Any]) -> list[dict[str, Any]]:
    c = (command or "").strip().lower()
    missing: list[dict[str, Any]] = []

    if signals["communication"] and not re.search(r"\b(to|for)\s+[a-z][a-z0-9_.@+-]{1,}\b", c):
        missing.append({"field": "recipient", "reason": "communication target is not explicit", "severity": "high", "ask_before_action": True})
    if signals["file_output"] and signals["creation"] and not re.search(r"\b(as|named|called|save|export)\b", c):
        missing.append({"field": "output_location_or_name", "reason": "output destination/name is unspecified", "severity": "medium", "ask_before_action": False})
    if signals["time_sensitive"] and not re.search(r"\b(\d{1,2}(?::\d{2})?\s*(?:am|pm)?|\d{4}-\d{2}-\d{2})\b", c):
        missing.append({"field": "time_scope", "reason": "time-sensitive wording lacks an exact date/time", "severity": "medium", "ask_before_action": True})
    if signals["system_action"] and not re.search(r"\b(\S+\.(?:exe|bat|cmd|ps1)|chrome|edge|firefox|notepad|explorer|terminal|settings|browser|app)\b", c):
        missing.append({"field": "target", "reason": "system action target is not explicit", "severity": "high", "ask_before_action": True})
    if signals["comparison"] and not re.search(r"\b(vs\.?|versus|between|compare)\b", c) and len(_tokens(c)) < 8:
        missing.append({"field": "comparison_scope", "reason": "comparison subjects or scope may be incomplete", "severity": "medium", "ask_before_action": False})
    if signals["creation"] and signals["learning"] and not re.search(r"\b(for|about|on|topic)\b", c):
        missing.append({"field": "content_scope", "reason": "created learning material lacks a clear topic/scope", "severity": "medium", "ask_before_action": False})
    return missing[:8]


def _infer_prerequisites(signals: dict[str, Any], goal: dict[str, Any]) -> list[dict[str, Any]]:
    rules = [
        ("research", "source_quality_check", "establish provenance and cross-source validation", "evidence"),
        ("comparison", "normalize_comparison_criteria", "apply comparable criteria to each side", "fairness"),
        ("creation", "output_integrity_check", "inspect generated structure, content and readability", "artifact"),
        ("system_action", "precondition_and_permission_check", "validate target, permissions and preconditions", "safety"),
        ("communication", "recipient_and_content_check", "verify recipient, content and intended channel", "safety"),
        ("time_sensitive", "time_context_check", "resolve relative dates/times against authoritative context", "temporal"),
    ]
    out = []
    for flag, step, why, kind in rules:
        if signals.get(flag):
            out.append({"step": step, "why": why, "kind": kind, "safe": True, "blocking": kind in {"safety", "temporal"}})
    if signals["research"] or goal["family"] in {"research", "information"}:
        out.append({"step": "uncertainty_boundary_check", "why": "separate observed evidence from inference", "kind": "epistemic", "safe": True, "blocking": False})
    if signals["multi_stage"]:
        out.append({"step": "dependency_order_check", "why": "respect explicit and inferred stage dependencies", "kind": "planning", "safe": True, "blocking": False})
    return out[:10]


def _infer_followups(signals: dict[str, Any], missing: list[dict[str, Any]], goal: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    fields = {x["field"] for x in missing}
    if signals["research"]:
        out += [
            {"action": "summarize_key_findings", "trigger": "after verified research", "priority": 8},
            {"action": "surface_uncertainties_and_source_conflicts", "trigger": "when material disagreement or weak evidence exists", "priority": 9},
        ]
    if signals["research"] and not signals["creation"]:
        out.append({"action": "offer_structured_report_or_notes", "trigger": "if a reusable deliverable would help", "priority": 5})
    if signals["creation"]:
        out.append({"action": "verify_generated_artifact", "trigger": "after file creation", "priority": 9})
    if signals["comparison"]:
        out.append({"action": "surface_material_differences_and_uncertainties", "trigger": "after comparison", "priority": 8})
    if signals["learning"]:
        out.append({"action": "offer_next_learning_step", "trigger": "after explanation/notes", "priority": 4})
    if goal["family"] == "planning":
        out.append({"action": "check_plan_dependencies_and_failure_paths", "trigger": "before execution", "priority": 8})
    if "recipient" in fields:
        out.append({"action": "request_missing_recipient", "trigger": "before communication", "priority": 10})
    if "target" in fields:
        out.append({"action": "request_missing_target", "trigger": "before system action", "priority": 10})
    return sorted(out, key=lambda x: (-int(x.get("priority", 0)), x.get("action", "")))[:10]


def _history_signal(command: str) -> dict[str, Any]:
    toks = set(_tokens(command))
    if not toks:
        return {"matched_recent": 0, "continuity_confidence": 0.0, "themes": [], "recency_weight": 0.0}
    scored = []
    now = time.time()
    for item in _STATE.get("recent", [])[-100:]:
        prior = set(_tokens(str(item.get("command", ""))))
        if not prior:
            continue
        overlap = len(toks & prior) / max(1, len(toks | prior))
        age_hours = max(0.0, (now - float(item.get("ts", now))) / 3600.0)
        recency = math.exp(-age_hours / 72.0)
        score = overlap * (0.55 + 0.45 * recency)
        if score > 0.10:
            scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    themes = []
    for _, item in scored[:6]:
        theme = str(item.get("theme") or "").strip()
        if theme and theme not in themes:
            themes.append(theme)
    top = scored[0][0] if scored else 0.0
    return {"matched_recent": len(scored), "continuity_confidence": _clamp(min(1.0, top * 2.0)),
            "themes": themes[:6], "recency_weight": _clamp(scored[0][0] if scored else 0.0)}


def _learned_signal(command: str, signals: dict[str, Any]) -> dict[str, Any]:
    key = _id(_theme(signals))
    rec = _STATE.get("patterns", {}).get(key, {})
    count = int(rec.get("count", 0)) if isinstance(rec, dict) else 0
    successes = int(rec.get("success", 0)) if isinstance(rec, dict) else 0
    rate = successes / max(1, count)
    return {"pattern": key, "observations": count, "success_rate": round(rate, 3),
            "usable": count >= 3, "confidence": _clamp(min(0.85, 0.20 + 0.12 * math.log1p(count)) if count else 0.0)}


def _risk_model(signals: dict[str, Any], missing: list[dict[str, Any]]) -> dict[str, Any]:
    score = 0.10
    factors = []
    if signals["system_action"]:
        score += 0.28; factors.append("system_state_change")
    if signals["communication"]:
        score += 0.22; factors.append("external_communication")
    if signals["security_sensitive"]:
        score += 0.25; factors.append("security_sensitive")
    if signals["financial"]:
        score += 0.30; factors.append("financial_consequence")
    if missing:
        score += 0.10 * min(3, len(missing)); factors.append("missing_constraints")
    score = _clamp(score)
    level = "low" if score < .25 else "moderate" if score < .5 else "high" if score < .75 else "critical"
    return {"score": score, "level": level, "factors": factors,
            "consequential_action_allowed": False if (score >= .5 or signals["communication"] or signals["system_action"] or signals["financial"]) else True,
            "required_gate": "existing_permission_confirmation_controls" if score >= .25 else "normal_verification"}


def _uncertainty_model(command: str, signals: dict[str, Any], missing: list[dict[str, Any]], history: dict[str, Any]) -> dict[str, Any]:
    words = len(_tokens(command))
    ambiguity = 0.0
    ambiguity += 0.16 * bool(re.search(r"\b(it|that|this|they|them|there|something|somehow)\b", command.lower()))
    ambiguity += 0.12 * bool(re.search(r"\b(maybe|probably|roughly|whatever|etc)\b", command.lower()))
    ambiguity += 0.08 * (len(missing) > 0)
    ambiguity += 0.10 * (words < 5)
    ambiguity += 0.08 * signals["multi_stage"] and len(_tokens(command)) < 10
    continuity = history["continuity_confidence"]
    ambiguity -= 0.10 * continuity
    ambiguity = _clamp(ambiguity)
    confidence = _clamp(0.80 - ambiguity - 0.08 * (signals["research"] and not signals["time_sensitive"]))
    return {"ambiguity": ambiguity, "confidence": confidence,
            "known": ["explicit user wording", "detected request signals"],
            "inferred": ["goal family", "likely prerequisites", "likely follow-ups"],
            "unknown": [x["field"] for x in missing]}


def _dependency_graph(signals: dict[str, Any], prerequisites: list[dict[str, Any]], task_steps: list[str]) -> dict[str, Any]:
    nodes = []
    edges = []
    for p in prerequisites:
        name = str(p["step"]); nodes.append({"id": name, "type": "prerequisite", "blocking": bool(p.get("blocking"))})
    for step in task_steps[:30]:
        sid = str(step); nodes.append({"id": sid, "type": "task_step", "blocking": False})
    # Conservative deterministic dependencies.
    if signals["research"] and any(str(x) == "web_research" for x in task_steps):
        for p in ("source_quality_check", "uncertainty_boundary_check"):
            if any(n["id"] == p for n in nodes): edges.append([p, "web_research"])
    if signals["creation"] and any(str(x) == "document_creation" for x in task_steps):
        if any(n["id"] == "output_integrity_check" for n in nodes): edges.append(["output_integrity_check", "document_creation"])
    if signals["communication"] and any(str(x) == "communication" for x in task_steps):
        if any(n["id"] == "recipient_and_content_check" for n in nodes): edges.append(["recipient_and_content_check", "communication"])
    if signals["system_action"] and any(str(x) == "computer_control" for x in task_steps):
        if any(n["id"] == "precondition_and_permission_check" for n in nodes): edges.append(["precondition_and_permission_check", "computer_control"])
    return {"nodes": nodes[:50], "edges": edges[:80], "acyclic": True}


def _counterfactuals(signals: dict[str, Any], missing: list[dict[str, Any]], risk: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    if signals["research"]:
        out.append({"if": "sources disagree or are weak", "then": "do not silently collapse disagreement; expose uncertainty and seek stronger evidence", "severity": "high"})
    if signals["creation"]:
        out.append({"if": "artifact validation fails", "then": "repair/rebuild or report the artifact as incomplete", "severity": "high"})
    if signals["system_action"]:
        out.append({"if": "target or permission is uncertain", "then": "stop before the consequential action and clarify", "severity": "critical"})
    if signals["communication"]:
        out.append({"if": "recipient/content cannot be verified", "then": "do not transmit", "severity": "critical"})
    if missing:
        out.append({"if": "required constraint remains unknown", "then": "ask or use an explicitly safe default; never invent the missing fact", "severity": "high"})
    if risk["level"] in {"high", "critical"}:
        out.append({"if": "risk increases during execution", "then": "re-enter the existing confirmation/safety gate", "severity": "critical"})
    return out[:8]


def _opportunities(signals: dict[str, Any], goal: dict[str, Any], history: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    if signals["research"] and signals["creation"]:
        out.append({"opportunity": "reuse verified research directly in the requested artifact", "value": "reduces duplicate work", "confidence": .86})
    if signals["research"] and signals["learning"]:
        out.append({"opportunity": "turn verified findings into exam-oriented notes or a study aid if requested", "value": "improves reuse", "confidence": .75})
    if signals["creation"]:
        out.append({"opportunity": "run a post-generation structural and content inspection", "value": "catches silent artifact defects", "confidence": .92})
    if history["continuity_confidence"] > .45:
        out.append({"opportunity": "reuse relevant recent context after explicit reference resolution", "value": "reduces repeated setup", "confidence": history["continuity_confidence"]})
    if goal["family"] == "planning":
        out.append({"opportunity": "precompute failure/recovery branches before execution", "value": "reduces avoidable dead ends", "confidence": .82})
    return out[:7]


def _recovery_policy(signals: dict[str, Any], errors: list[str], risk: dict[str, Any]) -> dict[str, Any]:
    if risk["level"] in {"critical", "high"}:
        return {"mode": "gate_first", "retry_limit": 1, "fallback": "clarify_or_report_partial", "escalate_on": ["permission uncertainty", "target uncertainty", "verification failure"]}
    if errors:
        return {"mode": "recovery_first", "retry_limit": 2, "fallback": "alternate_existing_tool_or_degrade_gracefully", "escalate_on": ["repeated failure", "contradictory evidence"]}
    return {"mode": "standard", "retry_limit": 1, "fallback": "report_partial_if_unverified", "escalate_on": ["postcondition failure"]}


def analyze(command: str, *, task_steps: Iterable[str] | None = None, recent_errors: Iterable[str] | None = None) -> dict[str, Any]:
    """Build a bounded proactive reasoning model. Never performs an external action."""
    try:
        c = (command or "").strip()
        signals = _request_signals(c)
        goal = _classify_goal(c, signals)
        missing = _missing_constraints(c, signals)
        prerequisites = _infer_prerequisites(signals, goal)
        followups = _infer_followups(signals, missing, goal)
        history = _history_signal(c)
        learned = _learned_signal(c, signals)
        steps = [str(x) for x in (task_steps or []) if str(x).strip()][:30]
        errors = [str(x) for x in (recent_errors or []) if str(x).strip()][:10]
        risk = _risk_model(signals, missing)
        uncertainty = _uncertainty_model(c, signals, missing, history)
        dependencies = _dependency_graph(signals, prerequisites, steps)
        counterfactuals = _counterfactuals(signals, missing, risk)
        opportunities = _opportunities(signals, goal, history)
        recovery = _recovery_policy(signals, errors, risk)

        evidence = 0.32 + .12 * signals["research"] + .10 * signals["creation"] + .08 * signals["comparison"]
        evidence += .08 * bool(history["matched_recent"]) + .05 * learned["confidence"]
        evidence -= .10 * min(3, len(missing)) + .06 * min(3, len(errors))
        confidence = _clamp((evidence + uncertainty["confidence"]) / 2.0)
        initiative = _clamp(.30 + .06 * len(prerequisites) + .05 * len(followups) + .08 * len(opportunities)
                             + .10 * history["continuity_confidence"] - .16 * (risk["level"] in {"high", "critical"}))
        clarify = [x for x in missing if x.get("ask_before_action")]
        recommended = (
            "clarify before consequential action" if clarify else
            "prepare evidence, dependency and verification gates" if signals["research"] else
            "prepare artifact inspection and postconditions" if signals["creation"] else
            "continue with bounded plan, monitor postconditions and verify completion"
        )

        result = {
            "version": VERSION,
            "objective": c[:2000],
            "goal_model": goal,
            "signals": signals,
            "inferred_prerequisites": prerequisites,
            "anticipated_followups": followups,
            "missing_constraints": missing,
            "dependency_graph": dependencies,
            "counterfactuals": counterfactuals,
            "opportunities": opportunities,
            "recovery_policy": recovery,
            "risk_model": risk,
            "uncertainty_model": uncertainty,
            "history": history,
            "learned_pattern": learned,
            "current_plan_steps": steps,
            "recent_errors": errors,
            "initiative_score": initiative,
            "confidence": confidence,
            "clarification_required": bool(clarify),
            "recommended_behavior": recommended,
            "reasoning_contract": {
                "known_vs_inferred": True,
                "lookahead_depth": 3,
                "counterfactual_analysis": True,
                "postcondition_verification": True,
                "self_consistency": True,
            },
            "autonomy_boundary": "anticipate_and_prepare_only; consequential actions still require existing permission/confirmation controls",
        }
        with _LOCK:
            metrics = _STATE["metrics"]
            metrics["analyses"] = int(metrics.get("analyses", 0)) + 1
            if confidence >= .70:
                metrics["high_confidence"] = int(metrics.get("high_confidence", 0)) + 1
            if clarify:
                metrics["clarifications"] = int(metrics.get("clarifications", 0)) + 1
            _STATE["recent"].append({"id": _id(c + str(time.time())), "ts": time.time(),
                                    "command": c[:1200], "theme": _theme(signals), "risk": risk["level"]})
            _save()
        return result
    except Exception:
        # Absolute fail-safe: a malformed request must never break the agent.
        return {
            "version": VERSION, "objective": str(command or "")[:2000], "signals": {},
            "inferred_prerequisites": [], "anticipated_followups": [], "missing_constraints": [],
            "dependency_graph": {"nodes": [], "edges": [], "acyclic": True}, "counterfactuals": [],
            "opportunities": [], "recovery_policy": {"mode": "report_partial", "retry_limit": 0},
            "risk_model": {"score": 1.0, "level": "critical", "consequential_action_allowed": False},
            "uncertainty_model": {"ambiguity": 1.0, "confidence": 0.0}, "history": {}, "learned_pattern": {},
            "current_plan_steps": [], "recent_errors": [], "initiative_score": 0.0, "confidence": 0.0,
            "clarification_required": True, "recommended_behavior": "clarify before consequential action",
            "reasoning_contract": {"known_vs_inferred": True, "lookahead_depth": 0},
            "autonomy_boundary": "anticipate_and_prepare_only; consequential actions still require existing permission/confirmation controls",
        }


def _theme(signals: dict[str, Any]) -> str:
    active = [k for k, v in signals.items() if v]
    return "+".join(active[:6]) or "general"


def record_outcome(command: str, outcome: str, followup_taken: str | None = None) -> None:
    key = _id(_theme(_request_signals(command)))
    with _LOCK:
        rec = _STATE["outcomes"].setdefault(key, {"command": (command or "")[:1000], "count": 0, "outcomes": {}})
        rec["count"] = int(rec.get("count", 0)) + 1
        counts = rec.get("outcomes") if isinstance(rec.get("outcomes"), dict) else {}
        counts[str(outcome)] = int(counts.get(str(outcome), 0)) + 1
        rec["outcomes"] = counts
        if followup_taken:
            rec["last_followup"] = str(followup_taken)[:300]
        rec["updated_at"] = time.time()

        theme = _theme(_request_signals(command))
        p = _STATE["patterns"].setdefault(_id(theme), {"theme": theme, "count": 0, "success": 0, "failure": 0})
        p["count"] = int(p.get("count", 0)) + 1
        if str(outcome) == "success":
            p["success"] = int(p.get("success", 0)) + 1
        else:
            p["failure"] = int(p.get("failure", 0)) + 1
        p["updated_at"] = time.time()
        _save()


def health() -> dict[str, Any]:
    with _LOCK:
        metrics = dict(_STATE.get("metrics", {}))
        total = int(metrics.get("analyses", 0))
        return {
            "version": VERSION,
            "analyses": total,
            "high_confidence": int(metrics.get("high_confidence", 0)),
            "clarifications": int(metrics.get("clarifications", 0)),
            "recent_context_items": len(_STATE.get("recent", [])),
            "learned_outcomes": len(_STATE.get("outcomes", {})),
            "learned_patterns": len(_STATE.get("patterns", {})),
            "autonomous_consequential_actions": False,
            "network_dependency": False,
            "background_worker": False,
            "lookahead_depth": 3,
            "bounded_state": True,
        }
