"""
FRIDAY V2044 - SHARED NATURAL-LANGUAGE UNDERSTANDING (NLU)
==========================================================

One place that understands the three action families that used to be parsed
by several drifting copies of regexes scattered across the backend, the
desktop agent and the advanced agent:

    * "send Harshik a message saying bro"        -> parse_message()
    * "open discord" / "launch vs code"          -> parse_open_target()
    * "show me search results for X in google"   -> extract_search()

Design rules
------------
1.  TOKEN based, not one giant regex.  The command "skeleton" (verb, "a
    message", "saying", "to") is matched fuzzily, so typing/speech slips such
    as "an u send harshik a messge saying bro?" still parse.  The PAYLOAD
    (contact name, message text, search query, app name) is never fuzzed - it
    is cut out of the ORIGINAL text exactly as the user wrote it.
2.  Conservative.  Every parser returns None when it is not confident, so the
    legacy handlers keep working exactly as before for anything unusual.
3.  Pure Python, no third-party imports, no I/O, no speech/listening code.
4.  Optional grounded LLM router (llm_route): Gemini may only SEGMENT the
    user's own words into fields; every field is verified to be present in
    the original command, so the model can never invent a message, a contact
    or a search query.
"""
from __future__ import annotations

import difflib
import json
import re
from dataclasses import dataclass
from typing import Callable, Optional

# ----------------------------------------------------------------------------
# generic helpers
# ----------------------------------------------------------------------------
_QUOTE_CHARS = "\"'\u201c\u201d\u2018\u2019`"
_TOKEN_RE = re.compile(r"\S+")


def _sim(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a, b).ratio()


def _norm_tok(tok: str) -> str:
    """lower-case, strip surrounding punctuation (keeps inner apostrophes)."""
    return re.sub(r"^[^\w']+|[^\w']+$", "", tok.lower())


def _is(tok: str, word: str, cutoff: float = 0.8, min_len: int = 3) -> bool:
    t = _norm_tok(tok)
    if t == word:
        return True
    if len(t) < min_len:
        return False
    return _sim(t, word) >= cutoff


def _strip_edges(s: str) -> str:
    return s.strip().strip(_QUOTE_CHARS).strip()


class _Toks:
    """Tokens of the ORIGINAL text with their character spans."""

    def __init__(self, text: str):
        self.text = text
        self.spans = [(m.start(), m.end()) for m in _TOKEN_RE.finditer(text)]
        self.raw = [text[a:b] for a, b in self.spans]
        self.n = [_norm_tok(t) for t in self.raw]

    def __len__(self):
        return len(self.raw)

    def slice_text(self, i: int, j: int) -> str:
        """Original substring covering tokens [i, j)."""
        if i >= j or i >= len(self.spans):
            return ""
        j = min(j, len(self.spans))
        return self.text[self.spans[i][0]:self.spans[j - 1][1]]


# ----------------------------------------------------------------------------
# request-form fillers ("can you please ...", "an u" = garbled "can u")
# ----------------------------------------------------------------------------
_FILLERS = {
    "hey", "hi", "hello", "ok", "okay", "so", "yo", "friday", "please", "pls",
    "plz", "kindly", "can", "could", "would", "will", "cn", "an", "kan", "cud",
    "wud", "you", "u", "yu", "ya", "i", "want", "wanna", "need", "like", "to",
    "id", "i'd", "ill", "i'll", "lets", "let's", "just", "go", "ahead", "and",
    "now", "also", "if", "possible", "able", "are", "do", "me", "for", "us",
    "then", "actually", "quickly", "quick", "right", "hmm", "um", "uh", "again",
}
_REQUEST_STARTERS = {"can", "could", "would", "will", "cn", "an", "kan", "cud", "wud", "do", "are"}

_PRONOUNS = {
    "me", "myself", "you", "yourself", "us", "him", "her", "them", "it", "this",
    "that", "everyone", "everybody", "someone", "somebody", "anyone", "these",
    "those", "he", "she", "they", "we", "i", "friday",
}
_QUESTION_WORDS = {
    "how", "what", "when", "where", "why", "who", "are", "is", "do", "does",
    "did", "will", "can", "could", "would", "should", "wanna", "u", "you",
}


def _skip_fillers(nt: list[str], start: int = 0, limit: int = 9) -> int:
    i = start
    while i < len(nt) and i - start < limit and nt[i] in _FILLERS:
        i += 1
    return i


def _is_request_form(nt: list[str]) -> bool:
    return bool(nt) and nt[0] in _REQUEST_STARTERS or (
        len(nt) > 1 and nt[0] in {"hey", "ok", "okay", "friday", "please", "so"} and nt[1] in _REQUEST_STARTERS
    )


# ----------------------------------------------------------------------------
# MESSAGE PARSING
# ----------------------------------------------------------------------------
@dataclass
class MessageIntent:
    contact: str = ""
    body: str = ""
    channel: str = "default"      # "default" | "whatsapp" | "other"
    other_channel: str = ""
    form: str = ""


_OTHER_CHANNELS = {
    "email", "e-mail", "gmail", "outlook", "sms", "imessage", "telegram",
    "messenger", "instagram", "insta", "discord", "slack", "signal",
    "snapchat", "teams", "viber", "wechat", "linkedin", "twitter",
}
_ARTICLES = {"a", "an", "the", "one", "some"}
_MSG_ADJ = {"quick", "short", "new", "little", "small", "brief", "nice", "simple"}
_MSG_NOUN_EXACT = {"msg", "msgs", "text", "texts", "note", "dm"}
_SAY_SINGLE_EXACT = {"says", "say", "stating", "reading", "reads", "writing"}
_LEADING_CONTACT_JUNK = {"my", "our", "the", "to", "for", "a", "an", "friend", "buddy", "pal", "mate", "dude", "guy"}
_CONTACT_STOP = {
    "message", "saying", "that", "and", "or", "then", "with", "about", "from",
    "whatsapp", "please", "text", "msg", "says", "say",
}


def _is_whatsapp_tok(tok: str) -> bool:
    t = _norm_tok(tok)
    return t in {"whatsapp", "whatsap", "whatsapp's", "whatapp", "watsapp", "whatsapps", "wa"} or (
        len(t) >= 6 and _sim(t, "whatsapp") >= 0.82
    )


def _is_msg_noun(tok: str) -> bool:
    """message / messge / mesage / massage / msg / text ... (typo tolerant)."""
    t = _norm_tok(tok)
    if t in _MSG_NOUN_EXACT or t in {"messages", "massage", "massages"}:
        return True
    return len(t) >= 5 and _sim(t, "message") >= 0.72 and t[0] in "mn"


def _is_channel_noun(tok: str) -> bool:
    """'send harshik an EMAIL saying ...' - a channel used as the message noun."""
    return _norm_tok(tok) in _OTHER_CHANNELS


def _is_send_verb(tok: str) -> bool:
    t = _norm_tok(tok)
    if t in {"send", "sent", "write", "shoot", "drop", "compose", "draft"}:
        return True
    return len(t) >= 4 and _sim(t, "send") >= 0.75 and t not in {"sand", "seed", "band", "bend", "tend", "lend", "mend", "sends"}


def _direct_verb(nt: list[str], i: int) -> tuple[Optional[str], int]:
    """Verbs that already contain the channel: text/message/whatsapp/dm/ping."""
    t = nt[i]
    if t == "whats" and i + 1 < len(nt) and nt[i + 1] in {"app", "ap"}:
        return "whatsapp", 2
    if _is_whatsapp_tok(t) and t != "wa":
        return "whatsapp", 1
    if t in {"text", "msg", "dm", "ping"}:
        return t, 1
    if t == "message" or (len(t) >= 6 and _sim(t, "message") >= 0.8 and t not in {"messages", "massage"}):
        return "message", 1
    return None, 0


_SAY_FUZZY_BLOCK = {"paying", "staying", "playing", "praying", "spraying", "slaying", "swaying", "saying"}


def _find_say(nt: list[str], start: int, end: Optional[int] = None) -> tuple[int, int]:
    """Earliest 'saying'-style marker in nt[start:end] -> (contact_end, body_start), else (-1, -1)."""
    end = len(nt) if end is None else end
    for k in range(start, end):
        t = nt[k]
        nxt = nt[k + 1] if k + 1 < len(nt) else ""
        nxt2 = nt[k + 2] if k + 2 < len(nt) else ""
        if t == "saying" or (len(t) >= 4 and t not in _SAY_FUZZY_BLOCK and _sim(t, "saying") >= 0.78):
            return k, k + 1
        if t in {"that", "which", "and"} and nxt in {"says", "say"}:
            return k, k + 2
        if t == "to" and nxt == "say":
            return k, k + 2
        if t == "with":
            if nxt in {"message", "text", "msg"}:
                return k, k + 2
            if nxt in {"the", "a"} and nxt2 in {"message", "text", "msg"}:
                return k, k + 3
        if t in _SAY_SINGLE_EXACT and k > start:
            return k, k + 1
        if t == "and" and nxt == "tell" and nxt2 in {"him", "her", "them"}:
            return k, k + 3
    return -1, -1


def _boundary(T: "_Toks", start: int, end: Optional[int] = None) -> tuple[int, int]:
    """(contact_end, body_start): a 'saying'-style word OR a ':' / '-' separator."""
    ce, bs = _find_say(T.n, start, end)
    if ce != -1:
        return ce, bs
    stop = len(T) if end is None else end
    for k in range(start, stop):
        raw = T.raw[k]
        if raw in {":", "-", "--", "\u2013", "\u2014"}:
            return k, k + 1
        if raw.endswith(":") and len(raw) > 1:
            return k + 1, k + 1          # "harshik: bro" -> contact includes the token, colon is stripped later
    return -1, -1


def _clean_contact(text: str) -> str:
    text = _strip_edges(text)
    words = text.split()
    while len(words) > 1 and words[0].lower().strip(",.") in _LEADING_CONTACT_JUNK:
        words.pop(0)
    while words and words[-1].lower().strip(",.:") in {"a", "an", "the", "one", "to", "on", "via", "whatsapp", "in", "with", "message", "please"}:
        words.pop()
    return " ".join(words).strip(" ,.:;-")


def _contact_ok(contact: str) -> bool:
    if not contact:
        return False
    words = contact.lower().split()
    if len(words) > 4:
        return False
    if words[0] in _PRONOUNS or all(w in _PRONOUNS for w in words):
        return False
    if any(w in _CONTACT_STOP or w in _OTHER_CHANNELS for w in words):
        return False
    return bool(re.search(r"[A-Za-z0-9\u0080-\uffff]", contact))


_TRAILING_CHANNEL_RE = re.compile(
    r"\s+(?:on|via|using|through|over|in|by)\s+(?:the\s+)?(whats\s*app|whatsapp|whatsap|telegram|email|e-mail|gmail|sms|instagram|discord|messenger|slack|signal|imessage)\s*$",
    re.I,
)
_TRAILING_POLITE_RE = re.compile(r"\s+(?:for\s+me|for\s+us)\s*$", re.I)


def _clean_body(body: str, question_form: bool) -> tuple[str, str]:
    """Return (clean_body, trailing_channel_or_empty)."""
    body = _strip_edges(body)
    channel = ""
    for _ in range(2):
        m = _TRAILING_CHANNEL_RE.search(body)
        if m:
            channel = re.sub(r"\s+", "", m.group(1).lower())
            body = body[: m.start()].rstrip()
        m2 = _TRAILING_POLITE_RE.search(body)
        if m2:
            body = body[: m2.start()].rstrip()
    body = _strip_edges(body)
    if body.endswith("?") and question_form:
        words = {_norm_tok(w) for w in body.split()}
        if not (words & _QUESTION_WORDS):
            body = body[:-1].rstrip()
    return body.strip(), channel


def _skeleton_channel(nt: list[str], skeleton_idx: list[int]) -> tuple[str, str]:
    """Channel named in the skeleton (never inside the message body)."""
    chan, other = "default", ""
    for k in skeleton_idx:
        if not 0 <= k < len(nt):
            continue
        t = nt[k]
        if (_is_whatsapp_tok(t) and t != "wa") or (t == "whats" and k + 1 < len(nt) and nt[k + 1] in {"app", "ap"}):
            chan = "whatsapp"
        elif t in _OTHER_CHANNELS:
            other = t
    if other and chan != "whatsapp":
        return "other", other
    return chan, other


def _finish_message(T: "_Toks", skeleton: list[int], contact: str, body: str,
                    question_form: bool, form: str) -> Optional[MessageIntent]:
    contact = _clean_contact(contact)
    if not _contact_ok(contact):
        return None
    if T.n and T.n[skeleton[0]] in {"write", "compose", "draft"} and not (body or "").strip():
        return None                      # "write a message for my teacher" = compose a draft, not send
    body, tail_chan = _clean_body(body or "", question_form)
    chan, other = _skeleton_channel(T.n, skeleton)
    if tail_chan:
        if tail_chan.startswith("whats"):
            chan, other = "whatsapp", ""
        elif chan != "whatsapp":
            chan, other = "other", tail_chan
    if chan == "other" and not body:
        # "I need to send an email to my teacher" names no actual content to send -- this is a
        # statement of intent, not a command with something to act on. Let the AI/legacy flow
        # handle it (e.g. it may offer to draft the email) rather than half-parsing it here.
        return None
    return MessageIntent(contact=contact, body=body, channel=chan, other_channel=other, form=form)


def _is_pre_noun(nt: list[str], k: int) -> tuple[bool, int]:
    """article / adjective / channel word that may precede the message noun. -> (yes, tokens consumed)"""
    t = nt[k]
    if t == "whats" and k + 1 < len(nt) and nt[k + 1] in {"app", "ap"}:
        return True, 2
    if t in _ARTICLES or t in _MSG_ADJ or (_is_whatsapp_tok(t) and t != "wa"):
        return True, 1
    return False, 0


def parse_message(text: str) -> Optional[MessageIntent]:
    """Understand 'send <contact> a message saying <body>' in all its natural,
    typo-ridden shapes. Returns None when this is not clearly a messaging request."""
    text = str(text or "").strip()
    if not text:
        return None
    T = _Toks(text)
    nt = T.n
    n = len(nt)
    if n < 2 or n > 80:
        return None
    question_form = _is_request_form(nt)
    i = _skip_fillers(nt)
    if i >= n:
        return None

    # ---- "tell X that ..." / "let X know ..." ------------------------------
    if nt[i] in {"tell", "let", "inform", "notify"} and i + 2 < n:
        marker_word = "know" if nt[i] == "let" else "that"
        m = next((k for k in range(i + 2, min(i + 6, n)) if nt[k] == marker_word), -1)
        if m == -1:
            return None
        body_start = m + 1
        if marker_word == "know" and body_start < n and nt[body_start] == "that":
            body_start += 1
        return _finish_message(T, [i], T.slice_text(i + 1, m), T.slice_text(body_start, n), question_form, "tell") \
            if body_start < n else None

    send_verb = _is_send_verb(nt[i])
    dverb, dlen = _direct_verb(nt, i)
    if not send_verb and not dverb:
        return None

    # ------------------------------------------------------------ SEND family
    if send_verb and not dverb:
        drafting_verb = nt[i] in {"write", "compose", "draft"}
        j = i + 1
        skeleton = [i]
        k, last_pre_wa = j, False
        while k < n:
            ok, used = _is_pre_noun(nt, k)
            if not ok:
                break
            last_pre_wa = (nt[k] == "whats" or _is_whatsapp_tok(nt[k])) and nt[k] != "wa"
            skeleton += list(range(k, k + used))
            k += used
        has_noun = k < n and (_is_msg_noun(nt[k]) or _is_channel_noun(nt[k])) and (k > j or nt[k] not in {"text", "texts", "note", "dm"})
        if has_noun:
            skeleton.append(k)
            r = k + 1
        elif last_pre_wa and k > j:
            r = k                      # "send a whatsapp to harshik saying hi": whatsapp WAS the noun
            has_noun = True
        else:
            r = -1

        if has_noun:
            while r < n and (_is_msg_noun(nt[r]) or nt[r] == "message") and not T.raw[r - 1].endswith(":"):
                skeleton.append(r)          # "a text message", "a whatsapp text message"
                r += 1
            if r < n and nt[r] in {"to", "for"}:
                skeleton.append(r)
                ce, bs = _boundary(T, r + 1)
                if ce != -1:
                    skeleton += list(range(ce, bs))
                    return _finish_message(T, skeleton, T.slice_text(r + 1, ce), T.slice_text(bs, n), question_form, "send-a-message-to")
                if n - (r + 1) > 4:
                    return None
                skeleton += list(range(r + 1, n))
                return _finish_message(T, skeleton, T.slice_text(r + 1, n), "", question_form, "send-a-message-to")
            ce, bs = _find_say(nt, r)
            if ce == r:
                # body first:  send a message saying <body> to <contact>
                skeleton += list(range(ce, bs))
                to_idx = next((q for q in range(n - 1, bs, -1) if nt[q] == "to" and 1 <= n - (q + 1) <= 3), -1)
                if to_idx == -1:
                    return None
                skeleton += [to_idx] + list(range(to_idx + 1, n))
                return _finish_message(T, skeleton, T.slice_text(to_idx + 1, n), T.slice_text(bs, to_idx), question_form, "body-first")
            return None       # "send a message" with nobody named: the legacy flow asks who

        # ---- contact first:  send <contact> a message saying <body>
        m_idx = next((q for q in range(j + 1, min(n, j + 8))
                      if _is_msg_noun(nt[q]) or _is_channel_noun(nt[q])), -1)
        if m_idx != -1:
            contact_end = m_idx
            while contact_end > j:
                ok, _u = _is_pre_noun(nt, contact_end - 1)
                if ok or (contact_end - 2 >= j and nt[contact_end - 2] == "whats" and nt[contact_end - 1] in {"app", "ap"}):
                    contact_end -= 1
                else:
                    break
            skeleton += list(range(contact_end, m_idx + 1))
            if T.raw[m_idx].endswith(":"):
                ce, bs = m_idx, m_idx + 1          # "send harshik a message: bro"
            else:
                ce, bs = _boundary(T, m_idx + 1)
            if ce != -1:
                skeleton += list(range(m_idx + 1, bs))
                body = T.slice_text(bs, n)
            else:
                trailing = T.slice_text(m_idx + 1, n)
                body = ""
                if trailing.strip() and not re.fullmatch(r"(?:on|via|using|through)\s+(?:the\s+)?(?:whats\s*app|whatsapp)", trailing.strip(), re.I):
                    return None
                skeleton += list(range(m_idx + 1, n))
            return _finish_message(T, skeleton, T.slice_text(j, contact_end), body, question_form, "contact-first")

        # "send harshik saying bro"  (verb literally 'send', no noun)
        if nt[i] in {"send", "sent"}:
            ce, bs = _boundary(T, j)
            if ce != -1 and ce > j:
                skeleton += list(range(ce, bs))
                return _finish_message(T, skeleton, T.slice_text(j, ce), T.slice_text(bs, n), question_form, "send-saying")
        return None

    # ---------------------------------------------------------- DIRECT family
    skeleton = list(range(i, i + dlen))
    j = i + dlen
    if dverb == "text" and j < n and nt[j] in (_MSG_NOUN_EXACT | {"message"}):
        return None
    while j < n and ((nt[j] in _ARTICLES and j + 1 < n and _is_msg_noun(nt[j + 1])) or _is_msg_noun(nt[j])):
        skeleton.append(j)
        j += 1
    if j < n and nt[j] in {"to", "for"}:
        skeleton.append(j)
        j += 1
    if j >= n:
        return None
    ce, bs = _boundary(T, j)
    if ce != -1 and ce > j:
        skeleton += list(range(ce, bs))
        return _finish_message(T, skeleton, T.slice_text(j, ce), T.slice_text(bs, n), question_form, "direct-saying")
    if dverb == "text":
        return None                      # "text me later" / "text book": never guess without a body marker
    if nt[j] in _PRONOUNS or nt[j] in {"from", "about", "is", "was", "if", "when", "later", "tomorrow", "today", "now"}:
        return None
    if n - j > 3:
        return None
    skeleton += list(range(j, n))
    return _finish_message(T, skeleton, T.slice_text(j, n), "", question_form, "direct-contact")


# ----------------------------------------------------------------------------
# WEB SEARCH QUERY EXTRACTION
# ----------------------------------------------------------------------------
@dataclass
class SearchIntent:
    query: str
    engine: str = "google"        # google | bing | duckduckgo | youtube


_ENGINE_WORDS = {
    "google": "google", "google chrome": "google", "chrome": "google", "googles": "google",
    "bing": "bing", "duckduckgo": "duckduckgo", "duck duck go": "duckduckgo",
    "youtube": "youtube", "you tube": "youtube",
}
_ENGINE_ALT = r"google\s+chrome|google|chrome|bing|duck\s*duck\s*go|duckduckgo|you\s*tube|youtube"
_GENERIC_WEB = r"the\s+(?:web|internet|net)|(?:my\s+)?(?:web\s+)?browser|(?:the\s+)?internet|online|the\s+web|web"

_SEARCH_TYPOS = {"serach", "seach", "saerch", "searh", "serch", "searck", "sarch", "searhc",
                 "seaerch", "searchh", "seearch", "sesrch", "searvh", "dearch", "zearch", "wearch", "searc", "seacrh"}
_GOOGLE_TYPOS = {"gogle", "googel", "goole", "googl", "gooogle", "goggle", "goodle", "gpogle", "googlr"}

_NON_WEB_HEAD = re.compile(
    r"^(?:my\s+|the\s+|a\s+|any\s+|all\s+)?(?:files?|folders?|documents?|docs?|pdfs?|emails?|inbox|computer|pc|laptop|"
    r"drive|downloads?|desktop|wikipedia|notes?)\s*(?:$|(?:named|called|containing|with|on my|in my|for)\b)",
    re.I,
)

_PREFIX_FILLER = re.compile(
    r"^(?:(?:hey|hi|ok|okay|so|yo|please|pls|plz|kindly|friday)[,\s]+)+", re.I)
_REQUEST_PREFIX = re.compile(
    r"^(?:(?:can|could|would|will|cn|kan|cud|wud|an)\s+(?:you|u|yu|ya)\s+(?:please\s+|pls\s+|just\s+|also\s+)*|"
    r"i\s+(?:want|need|would\s+like|wanna|'d\s+like)\s+(?:you\s+)?to\s+|"
    r"i\s*'?d\s+like\s+(?:you\s+)?to\s+|"
    r"(?:go\s+ahead\s+and|please|just|then|also|and)\s+)+", re.I)
_TRAILING_FILLER = re.compile(
    r"(?:\s+(?:please|pls|plz|thanks|thank\s+you|now|for\s+me|quickly|right\s+now|real\s+quick|friday))+\s*$", re.I)
_TRAILING_ENGINE = re.compile(
    r"\s+(?:on|in|using|with|via|through|at|from|by)\s+(?:the\s+|my\s+)?(?P<eng>" + _ENGINE_ALT + r"|" + _GENERIC_WEB + r")\s*$", re.I)
_ENGINE_ONLY_TAIL = re.compile(r"\s+(?:on|in|using|with|via|through|at)\s+(?:the\s+)?(?:google\s+)?(?:chrome|browser)\s*$", re.I)


def _engine_from(text: str) -> str:
    t = re.sub(r"\s+", " ", text.lower().strip())
    if "youtube" in t or "you tube" in t:
        return "youtube"
    if "bing" in t:
        return "bing"
    if "duck" in t:
        return "duckduckgo"
    return "google"


def _finish_search(query: str, engine: str) -> Optional[SearchIntent]:
    q = _strip_edges(query)
    for _ in range(3):
        before = q
        m = _TRAILING_ENGINE.search(q)
        if m:
            eng_txt = m.group("eng") or ""
            if re.fullmatch(_ENGINE_ALT, eng_txt.strip(), re.I):
                engine = _engine_from(eng_txt) if engine == "google" else engine
            q = q[: m.start()].rstrip()
        q = _TRAILING_FILLER.sub("", q).strip()
        q = re.sub(r"^(?:for|about|up|the\s+following|on)\s+", "", q, flags=re.I).strip()
        q = _strip_edges(q)
        if q == before:
            break
    q = q.strip(" .,;:!?")
    if not q or len(q) < 2:
        return None
    if re.fullmatch(r"(?:it|this|that|them|these|those|something|anything|stuff|things?)", q, re.I):
        return None
    if _NON_WEB_HEAD.match(q) and not re.search(r"\b(?:online|on the web|on google)\b", q, re.I):
        return None
    return SearchIntent(q, engine)


_RESULTS_RE = re.compile(
    r"^(?:(?:what\s+(?:are|is)|what's)\s+)?(?:show|display|give|get|bring\s+up|pull\s+up|open|load|find|see|fetch|pull)?\s*"
    r"(?:me\s+)?(?:all\s+)?(?:the\s+)?(?:(?:google|web|search|online|internet|bing|youtube)\s+)*"
    r"(?:search\s+)?results?\s+(?:for|of|on|about|regarding)\s+(?P<q>.+)$", re.I)
_DO_SEARCH_RE = re.compile(
    r"^(?:do|make|run|perform|start)\s+(?:a|an|the)\s+(?:(?:google|web|online|internet|quick|bing|youtube)\s+)*search\s+"
    r"(?:(?:for|on|about|of|regarding)\s+)?(?P<q>.+)$", re.I)
_LOOKUP_RE = re.compile(r"^(?:look\s*up|lookup|google\s+up)\s+(?P<q>.+)$", re.I)
_SEARCH_VERB_RE = re.compile(
    r"^(?P<verb>[a-z]{3,9})(?P<up>\s+up)?"
    r"(?:\s+(?:in|on|with|using|via|through)\s+(?P<eng1>" + _ENGINE_ALT + r"|" + _GENERIC_WEB + r"|[a-z]+)"
    r"|\s+(?P<eng2>" + _ENGINE_ALT + r"|" + _GENERIC_WEB + r")(?=\s+(?:for|about)\s))?"
    r"(?:\s+(?:for|about))?\s+(?P<q>.+)$", re.I)
_OPEN_SITE_PREFIX = re.compile(
    r"^(?:open|launch|start|go\s+to|navigate\s+to|fire\s+up)\s+(?P<site>google(?:\s+chrome)?|chrome|(?:the\s+)?browser|youtube|bing)\s*(?:,\s*)?(?:and|then)\s+", re.I)
_GOOGLE_VERB_RE = re.compile(
    r"^(?P<verb>[a-z]{4,7})(?:\s+search)?(?:\s+for)?\s+(?P<q>.+)$", re.I)


def _is_search_verb(tok: str) -> bool:
    t = tok.lower()
    if t == "search" or t in _SEARCH_TYPOS:
        return True
    if t.startswith("research") or t in {"searching", "searched", "searches"}:
        return False
    return len(t) >= 5 and _sim(t, "search") >= 0.85


def _is_google_verb(tok: str) -> bool:
    t = tok.lower()
    return t == "google" or t in _GOOGLE_TYPOS or (len(t) >= 5 and _sim(t, "google") >= 0.83 and t not in {"goggles", "toggle"})


def _prep_search_text(text: str) -> str:
    t = re.sub(r"\s+", " ", str(text or "").strip())
    t = t.strip(" \t\r\n")
    t = re.sub(r"[.!?]+$", "", t).strip()
    for _ in range(3):
        n = _PREFIX_FILLER.sub("", t)
        n = _REQUEST_PREFIX.sub("", n)
        n = _OPEN_SITE_PREFIX.sub("", n)       # "open google and show me results for X"
        if n == t:
            break
        t = n.strip()
    return t


def extract_search(text: str) -> Optional[SearchIntent]:
    """Extract ONLY the words to search from a natural request.

    'show me search results for orbitals in google'      -> orbitals
    'can you google gojo cats for me'                    -> gojo cats
    'search on youtube for organic chemistry lectures'   -> organic chemistry lectures (youtube)
    'serach orbitals'                                    -> orbitals
    'search my files for resume'                         -> None (not a web search)
    """
    t = _prep_search_text(text)
    if not t:
        return None
    if re.match(r"^research\b", t, re.I):
        return None

    m = _RESULTS_RE.match(t)
    if m:
        eng = _engine_from(t[: m.start("q")])
        return _finish_search(m.group("q"), eng)

    m = _DO_SEARCH_RE.match(t)
    if m:
        return _finish_search(m.group("q"), _engine_from(t[: m.start("q")]))

    m = _LOOKUP_RE.match(t)
    if m:
        return _finish_search(m.group("q"), "google")

    first = t.split(" ", 1)[0]
    if _is_search_verb(first):
        m = _SEARCH_VERB_RE.match(t)
        if m:
            eng_txt = (m.group("eng1") or m.group("eng2") or "").strip()
            q = m.group("q")
            engine = "google"
            if eng_txt:
                if re.fullmatch(_ENGINE_ALT, eng_txt, re.I):
                    engine = _engine_from(eng_txt)
                elif re.fullmatch(_GENERIC_WEB, eng_txt, re.I):
                    engine = "google"
                else:
                    # "search in my documents for ..." - a non-web search; leave it to legacy
                    return None
            # bare "search up X" / "search for X" / "search X"
            return _finish_search(q, engine)
        return None

    if _is_google_verb(first):
        m = _GOOGLE_VERB_RE.match(t)
        if m:
            q = m.group("q")
            # "google search" alone / "google chrome" alone are not queries
            if re.fullmatch(r"(?:search|chrome|it|maps?)", q.strip(), re.I) and q.strip().lower() != "maps":
                return None
            return _finish_search(q, "google")
    return None


def search_url(intent: SearchIntent) -> str:
    from urllib.parse import quote_plus
    q = quote_plus(intent.query)
    return {
        "youtube": f"https://www.youtube.com/results?search_query={q}",
        "bing": f"https://www.bing.com/search?q={q}",
        "duckduckgo": f"https://duckduckgo.com/?q={q}",
    }.get(intent.engine, f"https://www.google.com/search?q={q}")


# ----------------------------------------------------------------------------
# OPEN-APPLICATION PARSING
# ----------------------------------------------------------------------------
@dataclass
class OpenIntent:
    target: str
    strict: bool        # True for explicit "open"/"launch": a miss deserves an honest answer
    verb: str = "open"


_OPEN_STRICT = {"open", "launch"}
_OPEN_LOOSE = {"start", "run", "load", "execute", "boot", "fire", "bring", "opne", "opn", "oepn", "opem", "opan",
               "lauch", "lanuch", "launh", "launc", "lunch", "strat", "opens", "openn", "oppen", "oen"}
_OPEN_DETERMINERS = {"the", "a", "an", "my", "that", "this", "our", "up", "new"}
_OPEN_TAIL_RE = re.compile(
    r"(?:\s+(?:please|pls|plz|now|for\s+me|for\s+us|quickly|again|real\s+quick|right\s+now|thanks|thank\s+you|friday|sir))+\s*$"
    r"|(?:\s+(?:on|in|from)\s+(?:my|this|the)\s+(?:laptop|computer|pc|system|machine|desktop|device|windows))\s*$"
    r"|(?:\s+(?:app|application|program|software|exe|desktop\s+app))\s*$", re.I)
_FRIDAY_INTERNAL = {
    "friday", "yourself", "you", "settings", "setting", "study mode", "study", "interface", "the interface",
    "widget", "notes", "quiz", "syllabus", "tab", "new tab", "a new tab", "window", "new window", "incognito",
    "private window", "chat", "conversation", "it", "this", "that", "something", "anything", "everything",
}
_SPECIAL_FOLDER = re.compile(
    r"^(?:my\s+)?(?:(?:downloads?|documents?|pictures?|videos?|music|desktop)\s+folder|downloads|documents|pictures|videos|music|desktop|"
    r"recycle\s+bin|this\s+pc|my\s+computer|file\s+explorer|explorer)$", re.I)
_URLISH = re.compile(r"https?://|www\.|\.(?:com|org|net|io|lk|edu|gov|co|in|ai|app|dev|info|me|tv|uk|us)\b", re.I)
_FILEISH = re.compile(r"\b(?:files?|folders?|directory|documents?|docs?|pdfs?|photos?|pictures?|images?|videos?|"
                      r"presentations?|spreadsheets?|worksheets?|essays?|reports?|assignments?|homework|resume|cv|zip|"
                      r"link|links|website|webpage|site|tab|tabs|page)\b", re.I)


def parse_open_target(text: str) -> Optional[OpenIntent]:
    text = str(text or "").strip()
    if not text:
        return None
    T = _Toks(text)
    nt = T.n
    if len(nt) < 2 or len(nt) > 14:
        return None
    i = _skip_fillers(nt)
    if i >= len(nt) - 0:
        return None
    verb = nt[i]
    strict = verb in _OPEN_STRICT
    loose = verb in _OPEN_LOOSE or (len(verb) >= 4 and (_sim(verb, "open") >= 0.75 and verb not in {"oven", "pens", "pen", "open"} or _sim(verb, "launch") >= 0.8))
    if not strict and not loose:
        return None
    if verb in {"opens"}:
        loose = True
    j = i + 1
    if verb in {"fire", "bring", "boot"}:
        if j < len(nt) and nt[j] == "up":
            j += 1
        else:
            return None
    while j < len(nt) and nt[j] in _OPEN_DETERMINERS:
        j += 1
    if j >= len(nt):
        return None
    target = T.slice_text(j, len(nt))
    for _ in range(3):
        new = _OPEN_TAIL_RE.sub("", target).strip()
        if new == target:
            break
        target = new
    target = target.strip(" ,.;:!?\"'")
    # "the app called discord" -> discord ;  but keep the "app" of the spoken name "whats app"
    target = re.sub(r"^(?:the\s+)?(?:app|application|program|software)\s+(?:called|named)\s+", "", target, flags=re.I)
    if re.fullmatch(r"whats", target, re.I) and re.search(r"whats\s+app\b", T.slice_text(j, len(nt)), re.I):
        target = "whats app"
    if not target:
        return None
    low = target.lower()
    if re.search(r"\s(?:and|then|also|after that|plus)\s|[,;]", low):
        return None
    if len(low.split()) > 5:
        return None
    if low in _FRIDAY_INTERNAL or _URLISH.search(low):
        return None
    if re.match(r"^(?:new\s+)?(?:tab|tabs|window|windows)$", low):
        return None
    if not _SPECIAL_FOLDER.match(low):
        if _FILEISH.search(low) or re.search(r"\.[a-z0-9]{2,5}\b", low):
            return None
    return OpenIntent(target=target, strict=strict, verb=verb)


# ----------------------------------------------------------------------------
# "does this look like an action request?"  (gate for the LLM router)
# ----------------------------------------------------------------------------
_ACTION_HINT = re.compile(
    r"\b(?:send|sent|message|msg|text|whatsapp|whatsap|ping|dm|tell|open|launch|start|run|search|google|look\s*up|"
    r"show\s+me|results?|browse|lauch|opne|serach|messge|mesage)\b", re.I)


def looks_actionable(text: str) -> bool:
    t = str(text or "").strip()
    if not t or len(t.split()) > 30:
        return False
    return bool(_ACTION_HINT.search(t))


# ----------------------------------------------------------------------------
# GROUNDED LLM ROUTER (optional, injected generator)
# ----------------------------------------------------------------------------
@dataclass
class RoutedAction:
    action: str                 # send_message | open_app | web_search
    contact: str = ""
    message: str = ""
    app: str = ""
    query: str = ""


_ROUTER_PROMPT = (
    "You convert ONE command given to a Windows PC voice assistant into JSON. The command may contain typos or "
    "speech-recognition errors. Reply with ONLY a JSON object and nothing else:\n"
    '{"action": "send_message" | "open_app" | "web_search" | "none", '
    '"contact": "", "message": "", "app": "", "query": ""}\n'
    "Rules:\n"
    "- send_message: the user wants to message/text/WhatsApp a person. contact = the person's name exactly as written. "
    "message = the words to send, copied EXACTLY from the command (empty string if the command does not say what to send).\n"
    "- open_app: the user wants to open/launch/start a program installed on the computer. app = its name as written.\n"
    "- web_search: the user wants web/Google search results. query = ONLY the words to search for, copied exactly "
    "(no 'show me', 'results for', 'in google', 'please').\n"
    "- none: questions, chit-chat, or anything else.\n"
    "Never invent, translate, correct or add words. Copy text from the command only.\n"
    "Command: <<<{command}>>>"
)


def _strip_fences(raw: str) -> str:
    raw = (raw or "").strip()
    raw = re.sub(r"^```[a-zA-Z]*\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)
    m = re.search(r"\{.*\}", raw, re.S)
    return m.group(0) if m else raw


def _grounded(fragment: str, command: str, fuzzy: bool = False) -> bool:
    """True if `fragment` really occurs in `command` (case/punctuation-insensitive)."""
    def squash(s: str) -> str:
        return re.sub(r"[^\w]+", " ", s.lower()).strip()
    f, c = squash(fragment), squash(command)
    if not f:
        return False
    if f in c:
        return True
    if fuzzy:
        ctoks = c.split()
        return all(any(_sim(w, ct) >= 0.8 for ct in ctoks) for w in f.split())
    return False


def llm_route(command: str, generate: Callable[[str], str]) -> Optional[RoutedAction]:
    """Ask an LLM to SEGMENT the command; verify every field against the original text.

    `generate(prompt) -> str` is injected by the backend (Gemini) so this module
    stays dependency-free and unit-testable. Returns None if the model says
    'none', fails, or produces anything that is not grounded in the command."""
    command = str(command or "").strip()
    if not looks_actionable(command):
        return None
    try:
        raw = generate(_ROUTER_PROMPT.replace("{command}", command))
        data = json.loads(_strip_fences(raw))
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    action = str(data.get("action", "none")).strip().lower()
    g = lambda k: _strip_edges(str(data.get(k, "") or ""))
    if action == "send_message":
        contact, message = g("contact"), g("message")
        if not _contact_ok(contact) or not _grounded(contact, command, fuzzy=True):
            return None
        if message and not _grounded(message, command):
            message = ""          # never send words the user did not say
        return RoutedAction("send_message", contact=contact, message=message)
    if action == "open_app":
        app = g("app")
        if not app or len(app.split()) > 5 or not _grounded(app, command, fuzzy=True):
            return None
        return RoutedAction("open_app", app=app)
    if action == "web_search":
        query = g("query")
        if not query or not _grounded(query, command):
            return None
        return RoutedAction("web_search", query=query)
    return None
