# ============================================================
# FRIDAY NOTES ENGINE — REFERENCE NOTEBOOK STYLE
# ------------------------------------------------------------
# Renders AI-researched, syllabus-aware study notes as a notebook
# page inspired by the user's handwritten reference image:
# cream paper, green ink, rounded section boxes, handwritten-style
# headings, compact study blocks, equations, examples, exam tips,
# vocabulary and self-test prompts.
#
# This module deliberately remains independent from friday_backend.py.
# ============================================================

import json
import re
import datetime
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    Image as RLImage, KeepTogether, ListFlowable, ListItem, HRFlowable,
    PageBreak, CondPageBreak,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing, Line, Rect, String

# V2036: real vector diagrams (arrows, cycles, concept maps, orbital boxes, molecule
# geometry). Optional import so the notes engine still works if the module is missing.
try:
    from friday_notes_diagrams import build_diagram_drawing as _build_diagram_drawing
except Exception:  # pragma: no cover
    _build_diagram_drawing = None

APP_DIR = Path(__file__).resolve().parent
STUDY_FILES_DIR = APP_DIR / "study_files"
NOTES_DIR = STUDY_FILES_DIR / "notes"
NOTES_INDEX_PATH = STUDY_FILES_DIR / "notes_index.json"
QUICK_NOTES_INDEX_PATH = STUDY_FILES_DIR / "quick_notes.json"

# Three-reference notebook palette: blue + lavender + pink on warm paper.
# The renderer deliberately combines the visual grammar of all three supplied
# references: large handwritten titles, pastel section labels, boxed content,
# numbered processes, highlighted keywords, diagrams and a Remember callout.
PAPER = colors.HexColor("#FBF7EE")
INK = colors.HexColor("#24232A")
PURPLE = colors.HexColor("#8A63B8")
PURPLE_DARK = colors.HexColor("#5E3E85")
PURPLE_LIGHT = colors.HexColor("#EADCF5")
PINK = colors.HexColor("#F2D5E4")
PINK_DARK = colors.HexColor("#9A4F72")
BLUE = colors.HexColor("#D7E8F6")
BLUE_DARK = colors.HexColor("#4A6F96")
YELLOW = colors.HexColor("#F5E9B9")
GREEN = colors.HexColor("#8BA77A")
GRID = colors.HexColor("#E7E1D7")
MUTED = colors.HexColor("#66616B")
WHITE = colors.white
# Backward-compatible aliases for older helper functions kept in this module.
GREEN_DARK = PURPLE_DARK
GREEN_PALE = PURPLE_LIGHT
GREEN_LIGHT = PURPLE_LIGHT
YELLOW_DARK = PINK_DARK

_STYLES = getSampleStyleSheet()


def _register_fonts():
    """Register Windows fonts that closely reproduce the supplied notebook styles."""
    candidates = [
        ("SegoePrint", r"C:\Windows\Fonts\segoepr.ttf"),
        ("SegoeScript", r"C:\Windows\Fonts\segoesc.ttf"),
        ("SegoeUI", r"C:\Windows\Fonts\segoeui.ttf"),
        ("SegoeUILight", r"C:\Windows\Fonts\segoeuil.ttf"),
        ("ComicSans", r"C:\Windows\Fonts\comic.ttf"),
        ("BradleyHand", r"C:\Windows\Fonts\BRADHITC.TTF"),
        ("Arial", r"C:\Windows\Fonts\arial.ttf"),
    ]
    registered=set()
    for name, raw in candidates:
        path=Path(raw)
        if path.exists():
            try:
                pdfmetrics.registerFont(TTFont(name, str(path)))
                registered.add(name)
            except Exception:
                pass
    return registered

REGISTERED_FONTS=_register_fonts()
HAND_FONT="SegoePrint" if "SegoePrint" in REGISTERED_FONTS else ("ComicSans" if "ComicSans" in REGISTERED_FONTS else "Helvetica")
SCRIPT_FONT="SegoeScript" if "SegoeScript" in REGISTERED_FONTS else HAND_FONT
LIGHT_FONT="SegoeUILight" if "SegoeUILight" in REGISTERED_FONTS else ("SegoeUI" if "SegoeUI" in REGISTERED_FONTS else HAND_FONT)
BODY_FONT=HAND_FONT

def _font_has_glyph(font_name, codepoint):
    try:
        face=pdfmetrics.getFont(font_name).face
        return codepoint in getattr(face,"charToGlyph",{})
    except Exception:
        return False
_TRIPLE_BOND="\u2261" if _font_has_glyph(BODY_FONT,0x2261) else "(triple bond)"

# The three reference pages are intentionally represented as three distinct
# notebook page grammars instead of generic cards.  Page 1 follows the
# British-Rule reference, page 2 follows the Photosynthesis reference, and
# page 3 follows the Newton reference.  They rotate across a multi-page PDF.
PAPER=colors.HexColor("#FBF7EE")
INK=colors.HexColor("#28262D")
BLUE=colors.HexColor("#D7E8F6"); BLUE_DARK=colors.HexColor("#3F6E9E")
PURPLE_LIGHT=colors.HexColor("#E9D8F3"); PURPLE=colors.HexColor("#8A5DB1"); PURPLE_DARK=colors.HexColor("#5C3B7A")
PINK=colors.HexColor("#F1D0E0"); PINK_DARK=colors.HexColor("#9A4F72")
YELLOW=colors.HexColor("#F6E9B6"); GRID=colors.HexColor("#DDD6CB"); MUTED=colors.HexColor("#6B6570")
WHITE=colors.white
GREEN=colors.HexColor("#7E9E79")
GREEN_LIGHT=colors.HexColor("#DCE8D6")
GREEN_PALE=colors.HexColor("#EAF1E6")
GREEN_DARK=PURPLE_DARK
YELLOW_DARK=PINK_DARK

_STYLES=getSampleStyleSheet()
def _styles(page_style=1):
    title_font = SCRIPT_FONT if page_style in (1,3) else LIGHT_FONT
    title_size = 28 if page_style==1 else (30 if page_style==2 else 27)
    title_color = BLUE_DARK if page_style==1 else INK
    return {
      "title": ParagraphStyle("NTitle", parent=_STYLES["Title"], fontName=title_font,fontSize=title_size,leading=title_size+3,textColor=title_color,alignment=TA_CENTER,spaceAfter=2),
      "subtitle": ParagraphStyle("NSub", parent=_STYLES["Normal"], fontName=HAND_FONT,fontSize=10.5,leading=13,textColor=PURPLE_DARK,alignment=TA_CENTER),
      "card_title": ParagraphStyle("NCardTitle", parent=_STYLES["Heading3"], fontName=HAND_FONT,fontSize=11.5,leading=13.5,textColor=PURPLE_DARK,spaceAfter=3),
      "body": ParagraphStyle("NBody", parent=_STYLES["Normal"], fontName=BODY_FONT,fontSize=8.8,leading=11.5,textColor=INK),
      "small": ParagraphStyle("NSmall", parent=_STYLES["Normal"], fontName=BODY_FONT,fontSize=7.6,leading=9.5,textColor=INK),
      "bullet": ParagraphStyle("NBullet", parent=_STYLES["Normal"], fontName=BODY_FONT,fontSize=8.5,leading=11.1,textColor=INK,spaceAfter=1.5),
      "number": ParagraphStyle("NNumber", parent=_STYLES["Normal"], fontName=BODY_FONT,fontSize=8.5,leading=11.1,textColor=INK),
      "formula": ParagraphStyle("NFormula", parent=_STYLES["Normal"], fontName="Helvetica-Bold",fontSize=11,leading=13,alignment=TA_CENTER,textColor=PURPLE_DARK),
      "quote": ParagraphStyle("NQuote", parent=_STYLES["Normal"], fontName=SCRIPT_FONT,fontSize=9,leading=11.5,textColor=PINK_DARK,alignment=TA_CENTER),
      "chip": ParagraphStyle("NChip", parent=_STYLES["Normal"], fontName=HAND_FONT,fontSize=7.5,leading=9,alignment=TA_CENTER,textColor=PURPLE_DARK),
      "term": ParagraphStyle("NTerm", parent=_STYLES["Normal"], fontName=HAND_FONT,fontSize=8,leading=10,textColor=PURPLE_DARK),
    }

def _escape(text):
    """Convert model text into safe, clean notebook text.

    The notes renderer must never expose raw JSON, escaped newlines, or
    decorative unicode artifacts produced by a model. Scientific meaning is
    retained while problematic display-only glyphs are normalised.
    """
    if text is None:
        return ""
    t = str(text).strip()
    # Never print a Python/JSON object representation into a study box.
    if (t.startswith("{") and t.endswith("}")) or (t.startswith("[") and t.endswith("]")):
        try:
            obj = json.loads(t)
            if isinstance(obj, dict):
                t = obj.get("text") or obj.get("explanation") or obj.get("meaning") or obj.get("answer") or obj.get("question") or ""
            elif isinstance(obj, list):
                t = "; ".join(str(x) for x in obj)
        except Exception:
            t = re.sub(r'[{}\[\]"]', '', t)
    t = t.replace("\\n", " ").replace("\\t", " ")
    # Chemistry shorthand: "C#C" is written as a triple bond. Use the real symbol when the
    # body font has the glyph, otherwise spell it out so it never prints as a black box.
    t = re.sub(r"(?<=[A-Za-z0-9)])#(?=[A-Za-z0-9(])", _TRIPLE_BOND, t)
    replacements = {
        "₀":"0","₁":"1","₂":"2","₃":"3","₄":"4","₅":"5","₆":"6","₇":"7","₈":"8","₉":"9",
        "⁰":"0","¹":"1","²":"2","³":"3","⁴":"4","⁵":"5","⁶":"6","⁷":"7","⁸":"8","⁹":"9",
        "→":" to ","←":" from ","↔":" ↔ ","↓":"", "↑":"",
        "σ":"sigma","π":"pi","λ":"lambda","μ":"mu","°":" degrees",
        "•":"","▪":"","◦":"","–":"-","—":"-","…":"...",
    }
    for a,b in replacements.items():
        t=t.replace(a,b)
    # Remove control characters and collapse whitespace.
    t="".join(ch for ch in t if ch in "\\n\\t" or ord(ch)>=32)
    t=re.sub(r"\s+", " ", t).strip(" -")
    return t.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

def _plain_text(value):
    """Return clean text for dedupe comparisons without HTML escaping."""
    if value is None:
        return ""
    return re.sub(r"\s+", " ", re.sub(r"[{}\[\]\"]", "", str(value))).strip().lower()

def _clean_list(value,limit=None):
    if value is None:return []
    if isinstance(value,str): value=[value]
    out=[]
    seen=set()
    for item in value:
        if isinstance(item,dict):
            # Keep structured objects, but discard empty ones.
            if not any(str(v).strip() for v in item.values() if v is not None):
                continue
            key=_plain_text(item)
        else:
            x=_plain_text(item)
            if not x: continue
            key=x
        if key in seen:
            continue
        seen.add(key); out.append(item)
    return out[:limit] if limit else out

def _item_text(item):
    if isinstance(item,dict):
        # Prefer human-facing fields over serialising the whole object.
        if item.get("question") and item.get("answer"):
            q=str(item.get("question")).strip()
            a=str(item.get("answer")).strip()
            return f"Question: {q}  Answer: {a}"
        for key in ("text","point","explanation","meaning","detail","name","title","answer","body"):
            value=item.get(key)
            if value:
                return str(value)
        return ""
    return str(item)

def _bullets(items,styles,max_items=8):
    items=_clean_list(items,max_items)
    out=[]
    for item in items:
        text=_item_text(item)
        if text.strip():
            out.append(Paragraph(f"• {_escape(text)}",styles["bullet"]))
    return out

def _two_col(left,right,col_w):
    t=Table([[left,right]],colWidths=[col_w,col_w])
    t.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),3)]))
    return t

def _card(title,body,styles,width,fill=PURPLE_LIGHT,accent=PURPLE,padding=6):
    if not isinstance(body,list): body=[body]
    inner=[Paragraph(_escape(title),styles["card_title"])] + body
    t=Table([[inner]],colWidths=[width])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),fill),("BOX",(0,0),(-1,-1),.7,accent),("LEFTPADDING",(0,0),(-1,-1),padding),("RIGHTPADDING",(0,0),(-1,-1),padding),("TOPPADDING",(0,0),(-1,-1),padding),("BOTTOMPADDING",(0,0),(-1,-1),padding),("VALIGN",(0,0),(-1,-1),"TOP")]))
    return t

def _tape_label(text,styles,fill=PURPLE_LIGHT,accent=PURPLE,width=85*mm):
    t=Table([[Paragraph(_escape(text).upper(),styles["card_title"])]],colWidths=[width])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),fill),("BOX",(0,0),(-1,-1),.8,accent),("ALIGN",(0,0),(-1,-1),"CENTER"),("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),2.5),("BOTTOMPADDING",(0,0),(-1,-1),2.5)]))
    return t

def _content_box(title,content,styles,width,fill=PURPLE_LIGHT,accent=PURPLE):
    if not content:return None
    body=[Paragraph(_escape(content),styles["body"])] if isinstance(content,str) else _bullets(content,styles,10)
    return _card(title,body,styles,width,fill,accent)

def _vocab_table(terms,styles,width):
    rows=[[Paragraph("TERM",styles["term"]),Paragraph("MEANING",styles["term"])]]
    for item in _clean_list(terms,8):
        if isinstance(item,dict): a=item.get("term") or ""; b=item.get("meaning") or item.get("definition") or ""
        else: a=str(item); b=""
        if a: rows.append([Paragraph(_escape(a),styles["small"]),Paragraph(_escape(b),styles["small"])])
    t=Table(rows,colWidths=[width*.34,width*.66],repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),PURPLE_LIGHT),("GRID",(0,0),(-1,-1),.35,GRID),("BOX",(0,0),(-1,-1),.55,PURPLE),("ROWBACKGROUNDS",(0,1),(-1,-1),[PAPER,PINK]),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3)]))
    return t

def _doodle(canvas,x,y,kind="sparkle",scale=1):
    canvas.saveState(); canvas.setStrokeColor(PURPLE); canvas.setLineWidth(.65)
    if kind=="heart":
        p=canvas.beginPath(); p.moveTo(x,y); p.curveTo(x-5*scale,y+5*scale,x-7*scale,y+12*scale,x,y+7*scale); p.curveTo(x+7*scale,y+12*scale,x+5*scale,y+5*scale,x,y); canvas.drawPath(p,stroke=1,fill=0)
    elif kind=="leaf":
        canvas.line(x,y,x+20*scale,y+24*scale); 
        for i in range(4):
            yy=y+(i+1)*5*scale; xx=x+(i+1)*4*scale
            canvas.ellipse(xx-5*scale,yy-3*scale,xx+3*scale,yy+3*scale,stroke=1,fill=0)
    else:
        canvas.line(x-5*scale,y,x+5*scale,y); canvas.line(x,y-5*scale,x,y+5*scale); canvas.line(x-3*scale,y-3*scale,x+3*scale,y+3*scale); canvas.line(x-3*scale,y+3*scale,x+3*scale,y-3*scale)
    canvas.restoreState()

def _page_background(canvas,doc):
    canvas.saveState(); w,h=A4; canvas.setFillColor(PAPER); canvas.rect(0,0,w,h,fill=1,stroke=0)
    # Fine ruled paper + left notebook margin, common to all three references.
    canvas.setStrokeColor(GRID); canvas.setLineWidth(.25); y=17*mm
    while y<h-10*mm: canvas.line(9*mm,y,w-9*mm,y); y+=7*mm
    canvas.setStrokeColor(colors.HexColor("#E4B7C7")); canvas.setLineWidth(.45); canvas.line(17*mm,8*mm,17*mm,h-8*mm)
    # Tiny pastel margin dots emulate the hand-drawn notebook binding.
    canvas.setFillColor(colors.HexColor("#DCCAE8"))
    for yy in range(25,int(h/mm)-12,15): canvas.circle(12.5*mm,yy*mm,.55,fill=1,stroke=0)
    # Rotate the three reference-specific doodle grammars page-by-page.
    style=((doc.page-1)%3)+1
    if style==1:
        _doodle(canvas,w-24*mm,h-27*mm,"sparkle",1); _doodle(canvas,w-27*mm,24*mm,"leaf",.8); _doodle(canvas,25*mm,h-26*mm,"sparkle",.7)
    elif style==2:
        _doodle(canvas,25*mm,h-28*mm,"leaf",.8); _doodle(canvas,w-25*mm,30*mm,"leaf",.75); _doodle(canvas,w-30*mm,h-35*mm,"heart",.8)
    else:
        _doodle(canvas,25*mm,h-30*mm,"sparkle",.8); _doodle(canvas,w-27*mm,h-28*mm,"leaf",.7); _doodle(canvas,w-28*mm,28*mm,"sparkle",.8); _doodle(canvas,25*mm,30*mm,"heart",.8)
    canvas.restoreState()

def _build_mandatory_diagram(sections, topic):
    """Create a clean, topic-grounded diagram whenever the AI omitted one.

    Notes must always contain at least one visual.  Prefer the actual process
    steps supplied by the research/AI layer; otherwise fall back to key ideas
    and finally the definition.  This is intentionally schematic so it never
    invents unsupported scientific structures merely to fill a page.
    """
    s = sections or {}
    title = str(s.get("chapter_title") or topic or "Study Topic").strip()
    process_items = s.get("process_items") or s.get("processes") or []
    steps = []
    for proc in process_items[:2] if isinstance(process_items, list) else []:
        if not isinstance(proc, dict):
            continue
        raw_steps = proc.get("steps") or []
        for step in raw_steps[:8]:
            if isinstance(step, dict):
                label = str(step.get("title") or step.get("name") or "Step").strip()
                detail = str(step.get("explanation") or step.get("text") or step.get("content") or "").strip()
            else:
                label = "Step"
                detail = str(step).strip()
            if label or detail:
                steps.append((label or "Step", detail))
        if steps:
            break

    if not steps:
        for item in (s.get("key_ideas") or s.get("key_points") or [])[:6]:
            if isinstance(item, dict):
                label = str(item.get("title") or item.get("name") or "Key idea").strip()
                detail = str(item.get("content") or item.get("explanation") or item.get("detail") or "").strip()
            else:
                label = "Key idea"
                detail = str(item).strip()
            if label or detail:
                steps.append((label or "Key idea", detail))

    if not steps:
        definition = str(s.get("what_is") or s.get("about") or "").strip()
        steps = [("Core concept", definition)] if definition else [("Topic", title)]

    # Always provide a compact, readable visual with 3-6 connected stages.
    steps = steps[:6]
    nodes = [{"label": label, "detail": detail[:180]} for label, detail in steps]
    return {
        "kind": "flow",
        "title": f"{title} — Visual Summary",
        "caption": "A topic-grounded visual summary built from the researched study content.",
        "nodes": nodes,
        "relationships": ["leads to"] * max(0, len(nodes) - 1),
        "parts": [n["label"] for n in nodes],
        "meaning": "This diagram links the main ideas or stages so the learner can see the structure at a glance."
    }


def _diagram_is_usable(d):
    if not isinstance(d, dict):
        return False
    return bool(d.get("nodes") or d.get("parts") or d.get("columns") or d.get("angles")
                or d.get("shape") or d.get("caption") or d.get("meaning"))


def _ensure_mandatory_diagram(sections, topic):
    """Guarantee at least one usable visual; keep up to 5 distinct diagrams.

    V2036: diagram specs that carry a `kind` (energy / lobes / molecule3d /
    hub / cycle / flow, see friday_notes_diagrams.py) are recognised as usable
    even when they have no `nodes`, and the old "keep only the first diagram"
    cap is lifted so the notes can carry several different pictures.
    """
    s = dict(sections or {})
    diagrams = s.get("diagrams") if isinstance(s.get("diagrams"), list) else []
    usable = [d for d in diagrams if isinstance(d, dict) and (
        d.get("nodes") or d.get("parts") or d.get("columns") or d.get("angles") or d.get("shape")
        or d.get("caption") or d.get("meaning"))]
    if not usable:
        s["diagrams"] = [_build_mandatory_diagram(s, topic)]
    else:
        s["diagrams"] = usable[:5]
    return s

def _normalize_sections(sections,topic,subject_label):
    s=dict(sections or {})
    s.setdefault("what_is",s.get("about", "")); s.setdefault("subject_line",subject_label); s.setdefault("chapter_title",topic.title() if topic else "Study Notes")
    s["reference_outline"]=_clean_list(s.get("reference_outline") or s.get("sections"),12)
    # Normalize the AI schema into the renderer schema.  The AI intentionally
    # returns richer teaching fields (equation, process_steps, key_ideas,
    # diagram.nodes, common_mistakes, exam_tips, etc.); older renderer fields
    # are still accepted for backward compatibility.
    eq_items = s.get("equation_items") or s.get("equations")
    if not eq_items and s.get("equation"):
        eq_items = [{"formula": s.get("equation"), "meaning": s.get("equation_explanation", "")}]
    s["equation_items"]=_clean_list(eq_items,8)

    proc_items = s.get("process_items") or s.get("processes")
    if not proc_items and s.get("process_steps"):
        proc_items = [{"title":"HOW IT WORKS", "steps":s.get("process_steps", [])}]
    s["process_items"]=_clean_list(proc_items,8)

    diagrams = _clean_list(s.get("diagrams"),6)
    # Convert the AI's node-based diagrams to the renderer's parts/relationships
    # representation without losing labels, details or captions.
    normalized_diagrams=[]
    for d in diagrams:
        if not isinstance(d,dict):
            continue
        if d.get("nodes") and not d.get("parts"):
            nodes=d.get("nodes") or []
            parts=[]; rels=[]
            for n in nodes:
                if isinstance(n,dict):
                    label=str(n.get("label") or n.get("title") or "").strip()
                    detail=str(n.get("detail") or n.get("explanation") or "").strip()
                    if label: parts.append(label)
                    if detail: rels.append(f"{label}: {detail}" if label else detail)
                elif str(n).strip():
                    parts.append(str(n).strip())
            d=dict(d); d["parts"]=parts; d["relationships"]=rels
            d["meaning"]=d.get("meaning") or d.get("caption") or d.get("explanation") or ""
        normalized_diagrams.append(d)
    s["diagrams"]=normalized_diagrams

    s["worked_examples"]=_clean_list(s.get("worked_examples") or s.get("examples"),8)
    s["key_points"]=_clean_list(s.get("key_points"),10)
    s["key_ideas"]=_clean_list(s.get("key_ideas"),10)
    s["common_mistakes"]=_clean_list(s.get("common_mistakes"),8)
    s["exam_tips"]=_clean_list(s.get("exam_tips"),8)
    s["quick_facts"]=_clean_list(s.get("quick_facts"),8)
    s["exam_keywords"]=_clean_list(s.get("exam_keywords"),10)
    s["summary_points"]=_clean_list(s.get("summary_points") or s.get("key_points_to_remember"),10)
    s["comparison_tables"]=_clean_list(s.get("comparison_tables"),4)
    s["vocabulary"]=_clean_list(s.get("vocabulary") or s.get("key_terms"),10)
    s["topic_coverage"]=_clean_list(s.get("topic_coverage"),12)
    s["requirements"]=_clean_list(s.get("requirements"),8)
    s["memory_hook"]=s.get("memory_hook") or s.get("remember") or ""
    s = _ensure_mandatory_diagram(s, topic)
    return s

def _definition(s,styles,width):
    return _content_box("DEFINITION",s.get("what_is") or "",styles,width,fill=PURPLE_LIGHT,accent=PURPLE)

def _equations(eqs,styles,width):
    if not eqs:return None
    rows=[]
    for eq in eqs:
        if isinstance(eq,dict): f=eq.get("formula") or eq.get("equation") or ""; m=eq.get("meaning") or eq.get("explanation") or ""
        else:f=str(eq);m=""
        if f: rows.append([Paragraph(_escape(f),styles["formula"]),Paragraph(_escape(m),styles["small"])])
    if not rows:return None
    t=Table(rows,colWidths=[width*.48,width*.52]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),YELLOW),("BOX",(0,0),(-1,-1),.75,PINK_DARK),("INNERGRID",(0,0),(-1,-1),.35,WHITE),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
    return _card("EQUATION",[t],styles,width,fill=YELLOW,accent=PINK_DARK)

def _process(proc,styles,width):
    if not isinstance(proc,dict):return None
    title=proc.get("title") or "PROCESS"; steps=proc.get("steps") or []
    inner_w=width-16
    flow=[_tape_label(title,styles,PINK,PINK_DARK,min(inner_w,100*mm)),Spacer(1,3)]
    for i,step in enumerate(steps[:10],1):
        txt=step.get("explanation") or step.get("text") or "" if isinstance(step,dict) else str(step)
        if isinstance(step,dict) and step.get("title"): txt=f"<b>{_escape(step['title'])}</b> — {_escape(txt)}"
        elif not isinstance(step,dict): txt=_escape(txt)
        num=Table([[Paragraph(f"<b>{i}</b>",styles["number"])]],colWidths=[8*mm]); num.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),PINK),("BOX",(0,0),(-1,-1),.6,PINK_DARK),("ALIGN",(0,0),(-1,-1),"CENTER"),("TOPPADDING",(0,0),(-1,-1),2),("BOTTOMPADDING",(0,0),(-1,-1),2)]))
        row=Table([[num,Paragraph(txt,styles["body"])]],colWidths=[9*mm,inner_w-9*mm]); row.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),1),("RIGHTPADDING",(0,0),(-1,-1),1),("TOPPADDING",(0,0),(-1,-1),1.5),("BOTTOMPADDING",(0,0),(-1,-1),1.5)])); flow.append(row)
    return _card("PROCESS",flow,styles,width,fill=PAPER,accent=PURPLE)

def _diagram_card(diagram,styles,width):
    """V2036: a real vector diagram (arrows / cycle / orbital boxes / molecule) inside a card."""
    if _build_diagram_drawing is None or not isinstance(diagram,dict): return None
    title=str(diagram.get("title") or "DIAGRAM")
    caption=str(diagram.get("caption") or diagram.get("meaning") or diagram.get("explanation") or "").strip()
    drawing=_build_diagram_drawing(diagram,width-16)
    if drawing is None: return None
    flow=[drawing]
    if caption: flow += [Spacer(1,3),Paragraph(f"<b>What it shows:</b> {_escape(caption)}",styles["body"])]
    return _card(title,flow,styles,width,fill=WHITE,accent=BLUE_DARK)

def _diagram(diagram,styles,width):
    """Render a notebook-style concept diagram (real drawing first, boxed fallback second)."""
    if not isinstance(diagram,dict): return None
    real=_diagram_card(diagram,styles,width)
    if real is not None: return real
    title=str(diagram.get("title") or "DIAGRAM")
    caption=str(diagram.get("caption") or diagram.get("meaning") or diagram.get("explanation") or "").strip()
    nodes=diagram.get("nodes") or []
    if nodes:
        clean=[]
        for n in nodes[:8]:
            if isinstance(n,dict):
                label=str(n.get("label") or n.get("title") or "").strip()
                detail=str(n.get("detail") or n.get("explanation") or "").strip()
            else:
                label=str(n).strip(); detail=""
            if label: clean.append((label,detail))
    else:
        parts=[str(x).strip() for x in (diagram.get("parts") or []) if str(x).strip()][:8]
        rels=[str(x).strip() for x in (diagram.get("relationships") or []) if str(x).strip()]
        clean=[(x, rels[i] if i < len(rels) else "") for i,x in enumerate(parts)]
    if not clean and not caption and not diagram.get("columns") and not diagram.get("angles") and not diagram.get("shape"): return None

    # Fallback: connected boxes when the vector drawing is unavailable.
    box_w=max(28*mm,min(43*mm,(width-18*mm)/3)); box_h=18*mm
    rows=[]
    for i in range(0,len(clean),3):
        cells=[]
        for label,detail in clean[i:i+3]:
            txt=f"<b>{_escape(label)}</b>"
            if detail: txt += f"<br/><font size='6.8'>{_escape(detail[:115])}</font>"
            cells.append(Paragraph(txt,styles["small"]))
        while len(cells)<3: cells.append(Spacer(1,box_h))
        row=Table([cells],colWidths=[box_w]*3,rowHeights=[None])
        row.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,-1),BLUE),("BOX",(0,0),(-1,-1),.8,BLUE_DARK),
            ("INNERGRID",(0,0),(-1,-1),.45,WHITE),("VALIGN",(0,0),(-1,-1),"MIDDLE"),
            ("ALIGN",(0,0),(-1,-1),"CENTER"),("LEFTPADDING",(0,0),(-1,-1),5),
            ("RIGHTPADDING",(0,0),(-1,-1),5),("TOPPADDING",(0,0),(-1,-1),5),
            ("BOTTOMPADDING",(0,0),(-1,-1),5)]))
        rows.append(row)
        if i+3 < len(clean): rows.append(Paragraph("v   v   v",styles["formula"]))
    flow=[_tape_label(title,styles,BLUE,BLUE_DARK,min(width,110*mm)),Spacer(1,4)] + rows
    if caption: flow += [Spacer(1,4),Paragraph(f"<b>Why it matters:</b> {_escape(caption)}",styles["body"])]
    return _card(title,flow[1:],styles,width,fill=BLUE,accent=BLUE_DARK)

def _section_cards(items,styles,width,col_w):
    cards=[]
    for item in items[:12]:
        if not isinstance(item,dict):continue
        title=item.get("title") or item.get("name") or "STUDY CONTENT"; body=[]; c=item.get("content") or item.get("explanation") or ""
        if c:body.append(Paragraph(_escape(c),styles["body"]))
        if item.get("bullets"):body += [Spacer(1,2)] + _bullets(item["bullets"],styles,8)
        if body:cards.append(_card(title,body,styles,col_w,fill=[BLUE,PURPLE_LIGHT,PINK][len(cards)%3],accent=[BLUE_DARK,PURPLE,PINK_DARK][len(cards)%3]))
    out=[]
    for i in range(0,len(cards),2):out += [_two_col(cards[i],cards[i+1] if i+1<len(cards) else Spacer(1,0),col_w),Spacer(1,4)]
    return out

def build_gorgeous_notes(topic,subject_label,sections,output_path):
    """Render study notes in a three-page notebook grammar based on all supplied references.

    Page 1 = chapter/aesthetic-notes composition, Page 2 = definition/equation/
    process/diagram composition, Page 3 = numbered-law/key-idea composition.
    The exact content is generated from lecture evidence; decorative structure
    follows the references without copying their unrelated text.
    """
    output_path=Path(output_path); output_path.parent.mkdir(parents=True,exist_ok=True)
    s=_normalize_sections(sections,topic,subject_label)
    width=A4[0]-31*mm; gap=5*mm; col_w=(width-gap)/2
    doc=SimpleDocTemplate(str(output_path),pagesize=A4,leftMargin=19*mm,rightMargin=12*mm,topMargin=11*mm,bottomMargin=11*mm,title=f"FRIDAY Study Notes - {topic}",author="FRIDAY")
    story=[]

    # ---------- REFERENCE 1: chapter / aesthetic-note page ----------
    st=_styles(1)
    chapter_row=Table([[Paragraph("CHAPTER",st["card_title"]),Paragraph("1",st["title"])]],colWidths=[27*mm,15*mm])
    chapter_row.setStyle(TableStyle([("BACKGROUND",(0,0),(0,0),PAPER),("BACKGROUND",(1,0),(1,0),PURPLE_LIGHT),("BOX",(1,0),(1,0),.7,PURPLE),("ALIGN",(1,0),(1,0),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),2),("RIGHTPADDING",(0,0),(-1,-1),2),("TOPPADDING",(0,0),(-1,-1),2),("BOTTOMPADDING",(0,0),(-1,-1),2)]))
    story += [chapter_row,Spacer(1,1),Paragraph(_escape(s.get("chapter_title") or topic),st["title"]),Spacer(1,1)]
    # Hand-drawn-looking underline used in the first and third references.
    story += [HRFlowable(width=min(width,155*mm),color=BLUE_DARK,thickness=1.2,spaceBefore=1,spaceAfter=4,hAlign="CENTER")]
    d=_definition(s,st,width)
    if d:story += [_tape_label("CORE STUDY CONTENT",st,BLUE,BLUE_DARK,min(width,105*mm)),Spacer(1,4),d,Spacer(1,5)]
    if s.get("topic_coverage"):story += [_card("WHAT YOU NEED TO KNOW",_bullets(s["topic_coverage"],st,10),st,width,fill=PAPER,accent=PURPLE),Spacer(1,5)]
    cards=[]
    for item in (s.get("reference_outline") or [])[:8]:
        if not isinstance(item,dict):continue
        body=[]; c=item.get("content") or item.get("explanation") or ""
        if c:body.append(Paragraph(_escape(c),st["body"]))
        if item.get("bullets"):body += _bullets(item["bullets"],st,6)
        if body:cards.append(_card(item.get("title") or "STUDY POINT",body,st,col_w,fill=[BLUE,PURPLE_LIGHT,PINK][len(cards)%3],accent=[BLUE_DARK,PURPLE,PINK_DARK][len(cards)%3],padding=5))
    for i in range(0,len(cards),2):story += [_two_col(cards[i],cards[i+1] if i+1<len(cards) else Spacer(1,0),col_w),Spacer(1,4)]
    if s.get("key_points"):story += [_card("KEY POINTS",_bullets(s["key_points"],st,7),st,width,fill=BLUE,accent=BLUE_DARK),Spacer(1,4)]

    # ---------- REFERENCE 2: science-page composition ----------
    story += [CondPageBreak(A4[1]*0.4)]  # V2036: never leaves a nearly-empty page after an overflow
    st=_styles(2)
    story += [Paragraph(_escape(s.get("chapter_title") or topic),st["title"]),Spacer(1,3)]
    top_left=_definition(s,st,col_w) or Spacer(1,1)
    eq=_equations(s.get("equation_items"),st,col_w) or Spacer(1,1)
    story += [_two_col(top_left,eq,col_w),Spacer(1,5)]
    procs=s.get("process_items") or []
    if procs:
        proc_cards=[]
        for p in procs[:2]:
            q=_process(p,st,col_w)
            if q:proc_cards.append(q)
        if proc_cards:story += [_two_col(proc_cards[0],proc_cards[1] if len(proc_cards)>1 else Spacer(1,0),col_w),Spacer(1,5)]
    diags=s.get("diagrams") or []
    if diags:
        q=_diagram(diags[0],st,width)
        if q:story += [q,Spacer(1,5)]
    # Keep page 2 focused on explanation mechanics. Worked examples and key
    # points are deliberately rendered once on page 3 so the same material
    # is never duplicated across the notebook template.

    # ---------- REFERENCE 3: Newton-style numbered study page ----------
    story += [CondPageBreak(A4[1]*0.4)]  # V2036: never leaves a nearly-empty page after an overflow
    st=_styles(3)
    story += [Paragraph(_escape(s.get("chapter_title") or topic),st["title"]),Spacer(1,2)]
    # V2036: any additional diagrams open the consolidation page so no page is left half empty.
    _rest=[x for x in (s.get("diagrams") or [])[1:5] if isinstance(x,dict)]
    _small={"lobes","molecule3d","molecule","geometry","structure","hybrid_lobes","orbital_lobes"}
    def _kind_small(x): return str(x.get("kind","")).lower() in _small
    _i=0
    while _i<len(_rest):
        # Two small pictures (orbital lobes, molecule geometry) sit side by side.
        if _i+1<len(_rest) and _kind_small(_rest[_i]) and _kind_small(_rest[_i+1]):
            _pair=[_diagram(_rest[_i],st,col_w),_diagram(_rest[_i+1],st,col_w)]
            if all(_pair):
                story += [_two_col(_pair[0],_pair[1],col_w),Spacer(1,5)]; _i+=2; continue
        _c=_diagram(_rest[_i],st,width)
        if _c:story += [_c,Spacer(1,5)]
        _i+=1
    # Page 3 is the consolidation page. Use the AI's key ideas as the
    # numbered cards instead of repeating the page-1 outline.
    points=s.get("key_ideas") or []
    if not points:
        points=s.get("reference_outline") or []
    for idx,item in enumerate(points[:6],1):
        if not isinstance(item,dict):
            item={"title":"STUDY POINT","content":str(item)}
        body=[]
        c=item.get("content") or item.get("explanation") or item.get("detail") or item.get("meaning") or ""
        if c:body.append(Paragraph(_escape(c),st["body"]))
        if item.get("bullets"):body += _bullets(item["bullets"],st,5)
        if not body: continue
        n=Table([[Paragraph(str(idx),st["number"])]],colWidths=[9*mm]); n.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),PURPLE_LIGHT),("BOX",(0,0),(-1,-1),.7,PURPLE),("ALIGN",(0,0),(-1,-1),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3)]))
        content=_card(item.get("name") or item.get("title") or "STUDY POINT",body,st,width-12*mm,fill=PAPER,accent=PURPLE,padding=5)
        row=Table([[n,content]],colWidths=[10*mm,width-10*mm]); row.setStyle(TableStyle([("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),2),("TOPPADDING",(0,0),(-1,-1),1),("BOTTOMPADDING",(0,0),(-1,-1),1)])); story += [row,Spacer(1,4)]
    # Keep page 3 as a consolidation page. Equations and diagrams are already
    # shown on page 2, so they are intentionally not repeated here.
    remember_text=s.get("memory_hook") or "Review the key relationships and examples above."
    remember=_card("KEY IDEA",[Paragraph(_escape(remember_text),st["quote"])],st,col_w,fill=YELLOW,accent=PINK_DARK)
    story += [remember,Spacer(1,5)]
    if s.get("worked_examples"):
        example_cards=[]
        for ex in s["worked_examples"][:4]:
            if isinstance(ex,dict):
                q=_escape(ex.get("question") or "Example")
                a=_escape(ex.get("answer") or ex.get("explanation") or "")
                body=[Paragraph(f"<b>Question:</b> {q}",st["body"])]
                if a: body.append(Paragraph(f"<b>Answer:</b> {a}",st["small"]))
                example_cards.append(_card("WORKED EXAMPLE",body,st,col_w,fill=PURPLE_LIGHT,accent=PURPLE,padding=5))
        if example_cards:
            for i in range(0,len(example_cards),2):
                story += [_two_col(example_cards[i],example_cards[i+1] if i+1<len(example_cards) else Spacer(1,0),col_w),Spacer(1,4)]
    if s.get("vocabulary"):
        story += [_card("KEY TERMS",[_vocab_table(s["vocabulary"],st,width-12)],st,width,fill=PINK,accent=PINK_DARK)]

    # Rich teaching content that older versions of the renderer silently
    # dropped even though the AI was generating it. Keep it in the same
    # notebook/card grammar rather than changing the user's template.
    if len(s.get("key_ideas") or [])>6:
        story += [Spacer(1,3), _card("MORE EXPLANATIONS", _section_cards(s["key_ideas"][6:],st,width,col_w), st, width, fill=BLUE, accent=BLUE_DARK)]
    if s.get("requirements"):
        story += [Spacer(1,4), _card("CONDITIONS AND RULES", _bullets(s["requirements"],st,8), st, width, fill=PAPER, accent=PURPLE)]
    if s.get("common_mistakes"):
        story += [Spacer(1,4), _card("COMMON MISTAKES", _bullets(s["common_mistakes"],st,8), st, width, fill=PINK, accent=PINK_DARK)]
    if s.get("exam_tips"):
        story += [Spacer(1,4), _card("EXAM TIPS", _bullets(s["exam_tips"],st,8), st, width, fill=YELLOW, accent=PINK_DARK)]
    if s.get("quick_facts"):
        story += [Spacer(1,4), _card("QUICK FACTS", _bullets(s["quick_facts"],st,8), st, width, fill=PURPLE_LIGHT, accent=PURPLE)]
    if s.get("comparison_tables"):
        for comp in s["comparison_tables"][:2]:
            if not isinstance(comp,dict): continue
            cols=comp.get("columns") or [] ; data=[cols]
            data += (comp.get("rows") or [])[:8]
            if cols and len(data)>1:
                _inner=width-16; _first=_inner*0.30 if len(cols)>2 else _inner/len(cols)
                _cw=[_first]+[(_inner-_first)/max(1,len(cols)-1)]*(len(cols)-1)
                table=Table([[Paragraph(_escape(str(x)),st["small"]) for x in row] for row in data],colWidths=_cw,repeatRows=1)
                table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),PURPLE_LIGHT),("GRID",(0,0),(-1,-1),.4,GRID),("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4)]))
                story += [Spacer(1,4), _card(comp.get("title") or "COMPARISON", [table], st, width, fill=BLUE, accent=BLUE_DARK)]
    if s.get("summary_points"):
        story += [Spacer(1,4), _card("SUMMARY", _bullets(s["summary_points"],st,8), st, width, fill=GREEN_LIGHT, accent=GREEN)]
    if s.get("exam_keywords"):
        kw="  |  ".join(_escape(_item_text(k)) for k in s["exam_keywords"][:10] if _item_text(k))
        if kw:story += [Spacer(1,4), _card("EXAM KEYWORDS", [Paragraph(kw,st["small"])], st, width, fill=PAPER, accent=PINK_DARK)]
    if s.get("sources"):
        story += [Spacer(1,5), _card("RESEARCH SOURCES", _bullets(s["sources"],st,8), st, width, fill=PAPER, accent=PURPLE)]
    doc.build(story,onFirstPage=_page_background,onLaterPages=_page_background)
    return output_path

def images_to_pdf_fallback(image_paths,output_path,title="Scanned Notes"):
    output_path=Path(output_path); output_path.parent.mkdir(parents=True,exist_ok=True); st=_styles(1); width=A4[0]-30*mm
    doc=SimpleDocTemplate(str(output_path),pagesize=A4,leftMargin=18*mm,rightMargin=13*mm,topMargin=12*mm,bottomMargin=13*mm,title=title)
    story=[Paragraph(_escape(title),st["title"]),Spacer(1,5)]
    added=False
    for path in image_paths:
        try:
            p=Path(str(path).strip().strip('"').strip("'"))
            if not p.exists():continue
            img=RLImage(str(p)); max_w,max_h=width,A4[1]-45*mm; ratio=min(max_w/img.imageWidth,max_h/img.imageHeight,1.0); img.drawWidth,img.drawHeight=img.imageWidth*ratio,img.imageHeight*ratio; story += [img,PageBreak()]; added=True
        except Exception:pass
    if not added:story.append(Paragraph("No readable images were attached.",st["body"]))
    doc.build(story,onFirstPage=_page_background,onLaterPages=_page_background); return output_path

def _load_index():
    if NOTES_INDEX_PATH.exists():
        try:return json.loads(NOTES_INDEX_PATH.read_text(encoding="utf-8"))
        except Exception:return []
    return []
def _save_index(entries):
    NOTES_INDEX_PATH.parent.mkdir(parents=True,exist_ok=True); NOTES_INDEX_PATH.write_text(json.dumps(entries,indent=2,ensure_ascii=False),encoding="utf-8")
def register_note(subject,topic,pdf_path,source="ai-generated"):
    entries=_load_index(); entry={"id":f"note_{int(datetime.datetime.now().timestamp()*1000)}","subject":subject or "general","topic":topic or "Untitled","path":str(Path(pdf_path).resolve()),"source":source,"created":datetime.datetime.now().isoformat(timespec="seconds")}; entries.append(entry); _save_index(entries); return entry
def list_notes():return _load_index()
def _load_quick_notes():
    if QUICK_NOTES_INDEX_PATH.exists():
        try:return json.loads(QUICK_NOTES_INDEX_PATH.read_text(encoding="utf-8"))
        except Exception:return []
    return []
def _save_quick_notes(entries):
    QUICK_NOTES_INDEX_PATH.parent.mkdir(parents=True,exist_ok=True); QUICK_NOTES_INDEX_PATH.write_text(json.dumps(entries,indent=2,ensure_ascii=False),encoding="utf-8")
def save_quick_note(subject,text):
    entries=_load_quick_notes(); entry={"id":f"qnote_{int(datetime.datetime.now().timestamp()*1000)}","subject":subject or "general","text":text or "","created":datetime.datetime.now().isoformat(timespec="seconds")}; entries.append(entry); _save_quick_notes(entries); return entry
def list_quick_notes():return _load_quick_notes()
def safe_filename(text):
    text=re.sub(r"[^A-Za-z0-9 _-]","",text or "").strip() or "notes"; return re.sub(r"\s+","_",text)[:100]

