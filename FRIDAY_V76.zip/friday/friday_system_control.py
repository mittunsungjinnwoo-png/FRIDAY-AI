"""
FRIDAY SYSTEM CONTROL
----------------------
Real, verified "close it" actions: closing an application and closing
browser tabs.

WHY THIS FILE EXISTS
=====================
Before this module, handle_command() had no keyword branch and no
Gemini intent label for "close the X app" / "close N tabs" / "force
quit chrome". Those commands fell all the way through to ask_ai(),
which is a PURE TEXT chat call to Gemini with no tool access at all.
ask_ai() also has tone-aware framing that prepends "Right away. " to
answers when the user sounds urgent (see friday_backend.py, the
_LAST_USER_TONE == "urgent" branch). The result was exactly the bug
you saw in the transcript: Friday narrates "Right away, Sir. I have
terminated the process." in confident character voice, having done
precisely nothing, because nothing in that code path touches the
operating system.

This module actually touches the operating system, and — just as
important — never reports success it hasn't verified. Every function
here returns a dict with "ok" set only after re-checking reality
(re-enumerating windows/processes), never based on "the command
completed without raising".

Windows-only, matching the rest of the backend (see _IS_WINDOWS in
friday_backend.py: notepad.exe/calc.exe/shutdown are already
Windows-specific).
"""

from __future__ import annotations

import ctypes
import platform
import re
import time
import difflib
from ctypes import wintypes
from typing import Optional

_IS_WINDOWS = platform.system() == "Windows"

try:
    import psutil
except Exception:
    psutil = None

try:
    import pyautogui
    pyautogui.PAUSE = 0.05
except Exception:
    pyautogui = None


# ------------------------------------------------------------------
# Low-level window enumeration (ctypes, same approach friday_backend's
# get_active_window_title already uses -- no new dependency needed).
# ------------------------------------------------------------------

WM_CLOSE = 0x0010
SW_RESTORE = 9


def _user32():
    return ctypes.windll.user32 if _IS_WINDOWS else None


def list_open_windows() -> list[dict]:
    """Every visible top-level window with a non-empty title, as
    [{"hwnd": int, "title": str, "pid": int}]. Best-effort; returns
    [] on non-Windows or on any enumeration failure."""
    if not _IS_WINDOWS:
        return []
    results: list[dict] = []
    user32 = _user32()

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _callback(hwnd, _lparam):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if length <= 0:
                return True
            buffer = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buffer, length + 1)
            title = buffer.value.strip()
            if not title:
                return True
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            results.append({"hwnd": int(hwnd), "title": title, "pid": int(pid.value)})
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(_callback, 0)
    except Exception:
        pass
    return results


def _windows_matching(keyword: str) -> list[dict]:
    keyword = keyword.strip().lower()
    if not keyword:
        return []
    return [w for w in list_open_windows() if keyword in w["title"].lower()]


def focus_window(hwnd: int) -> bool:
    if not _IS_WINDOWS:
        return False
    try:
        user32 = _user32()
        user32.ShowWindow(hwnd, SW_RESTORE)
        return bool(user32.SetForegroundWindow(hwnd))
    except Exception:
        return False


def _foreground_title() -> Optional[str]:
    if not _IS_WINDOWS:
        return None
    try:
        user32 = _user32()
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return None
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        return buffer.value.strip() or None
    except Exception:
        return None


# ------------------------------------------------------------------
# App name -> process/window aliases. Extend this as you find gaps --
# it is deliberately a plain data table, not scattered if/elif code.
# ------------------------------------------------------------------

APP_ALIASES = {
    "python idle": {"window": "idle", "proc_names": ["python.exe", "pythonw.exe"], "cmdline_hint": "idlelib"},
    "idle": {"window": "idle", "proc_names": ["python.exe", "pythonw.exe"], "cmdline_hint": "idlelib"},
    "chrome": {"window": "google chrome", "proc_names": ["chrome.exe"]},
    "google chrome": {"window": "google chrome", "proc_names": ["chrome.exe"]},
    "google chrom": {"window": "google chrome", "proc_names": ["chrome.exe"]},
    "chrome browser": {"window": "google chrome", "proc_names": ["chrome.exe"]},
    "edge": {"window": "microsoft edge", "proc_names": ["msedge.exe"]},
    "firefox": {"window": "mozilla firefox", "proc_names": ["firefox.exe"]},
    "notepad": {"window": "notepad", "proc_names": ["notepad.exe"]},
    "calculator": {"window": "calculator", "proc_names": ["calculatorapp.exe", "calc.exe"]},
    "word": {"window": "word", "proc_names": ["winword.exe"]},
    "excel": {"window": "excel", "proc_names": ["excel.exe"]},
    "spotify": {"window": "spotify", "proc_names": ["spotify.exe"]},
    "vscode": {"window": "visual studio code", "proc_names": ["code.exe"]},
    "vs code": {"window": "visual studio code", "proc_names": ["code.exe"]},
}

_STRIP_WORDS = ("the ", "please ", "app", "application", "program", "window")


def _normalize_app_name(raw: str) -> str:
    name = raw.lower().strip()
    for w in ("app", "application", "program", "window"):
        name = re.sub(rf"\b{w}\b", "", name)
    name = re.sub(r"^\s*the\s+", "", name)
    return name.strip()


def close_application(raw_name: str, timeout: float = 3.0) -> dict:
    """Close an application by name. Tries a graceful WM_CLOSE to any
    matching visible window first, waits, and escalates to killing the
    matching process(es) if the window (or the process) is still
    there. Returns only after re-checking reality -- "ok" is never
    True just because a close call didn't raise."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows", "detail": "System control is only implemented for Windows."}

    name = _normalize_app_name(raw_name)
    if not name:
        return {"ok": False, "error": "empty_name"}

    alias = APP_ALIASES.get(name, {})
    if not alias and len(name) >= 5:
        close = difflib.get_close_matches(name, list(APP_ALIASES.keys()), n=1, cutoff=0.78)
        if close:
            name = close[0]
            alias = APP_ALIASES[name]
    window_keyword = alias.get("window", name)
    proc_names = {p.lower() for p in alias.get("proc_names", [])}
    cmdline_hint = alias.get("cmdline_hint")

    closed_windows: list[str] = []
    closed_procs: list[str] = []

    # Step 1: graceful window close.
    matches = _windows_matching(window_keyword)
    user32 = _user32()
    for w in matches:
        try:
            user32.PostMessageW(w["hwnd"], WM_CLOSE, 0, 0)
            closed_windows.append(w["title"])
        except Exception:
            pass

    if matches:
        time.sleep(min(timeout, 1.5))

    # Step 2: escalate to process termination if a window is still
    # open under that title, OR we had no proc_names to fall back on
    # matching by window alone, OR we never found a window at all
    # (app may be running with no visible window right now).
    still_windows = _windows_matching(window_keyword)
    need_process_kill = bool(still_windows) or not matches

    if need_process_kill and psutil is not None:
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                pname = (proc.info.get("name") or "").lower()
                cmdline = " ".join(proc.info.get("cmdline") or []).lower()
                is_match = False
                if proc_names and pname in proc_names:
                    if cmdline_hint:
                        is_match = cmdline_hint in cmdline
                    else:
                        is_match = True
                elif not proc_names and name in pname:
                    is_match = True
                if not is_match:
                    continue
                proc.terminate()
                closed_procs.append(f"{pname} (pid {proc.pid})")
            except Exception:
                continue

        if closed_procs:
            deadline = time.time() + timeout
            while time.time() < deadline:
                alive = [p for p in closed_procs if _pid_alive_by_label(p)]
                if not alive:
                    break
                time.sleep(0.2)
            # Force-kill anything that ignored terminate().
            for proc in psutil.process_iter(["pid", "name", "cmdline"]):
                try:
                    pname = (proc.info.get("name") or "").lower()
                    label = f"{pname} (pid {proc.pid})"
                    if label in closed_procs and proc.is_running():
                        proc.kill()
                except Exception:
                    continue

    # Step 3: verify against reality, not against "no exception raised".
    time.sleep(0.3)
    remaining_windows = _windows_matching(window_keyword)
    remaining_procs = []
    if psutil is not None and proc_names:
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                pname = (proc.info.get("name") or "").lower()
                cmdline = " ".join(proc.info.get("cmdline") or []).lower()
                if pname in proc_names and (not cmdline_hint or cmdline_hint in cmdline):
                    remaining_procs.append(f"{pname} (pid {proc.pid})")
            except Exception:
                continue

    found_anything = bool(matches or closed_procs)
    ok = found_anything and not remaining_windows and not remaining_procs

    if not found_anything:
        return {
            "ok": False,
            "error": "not_found",
            "detail": f"No window or process matching \"{raw_name}\" was found running.",
        }

    return {
        "ok": ok,
        "closed_windows": closed_windows,
        "closed_processes": closed_procs,
        "still_open": remaining_windows + [{"title": p} for p in remaining_procs],
    }


def _pid_alive_by_label(label: str) -> bool:
    if psutil is None:
        return False
    try:
        pid = int(label.rsplit("pid ", 1)[1].rstrip(")"))
        return psutil.pid_exists(pid) and psutil.Process(pid).is_running()
    except Exception:
        return False


# ------------------------------------------------------------------
# Browser tab closing.
# ------------------------------------------------------------------

BROWSER_ALIASES = {
    "chrome": "google chrome",
    "google chrome": "google chrome",
    "edge": "edge",
    "firefox": "firefox",
}


def close_browser_tabs(count: int, keep_keywords: Optional[list[str]] = None, browser: str = "chrome") -> dict:
    """Close `count` tabs in the given browser, skipping any tab whose
    title contains one of keep_keywords (e.g. ["chatgpt"]).

    Honesty note: without Chrome's remote-debugging protocol this can
    only see ONE tab at a time (the active one, via its window title)
    -- there is no reliable way to see or verify the full tab list.
    So this is real automation (it genuinely activates the browser and
    sends real Ctrl+W / Ctrl+Tab keystrokes), but the count of tabs
    closed is what was observed being closed, not independently
    reverified afterwards. That distinction is returned in the result
    so Friday can say it honestly instead of over-claiming.
    """
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows"}
    if pyautogui is None:
        return {"ok": False, "error": "pyautogui_unavailable", "detail": "pyautogui is not installed."}

    keep_keywords = [k.lower() for k in (keep_keywords or [])]
    browser_keyword = BROWSER_ALIASES.get(browser.lower(), browser.lower())
    windows = _windows_matching(browser_keyword)
    if not windows:
        return {"ok": False, "error": "browser_not_found", "detail": f"No open {browser} window was found."}

    if not focus_window(windows[0]["hwnd"]):
        return {"ok": False, "error": "focus_failed"}
    time.sleep(0.3)

    closed_titles: list[str] = []
    skipped_titles: list[str] = []
    close_evidence: list[dict] = []
    safety_limit = max(count * 4, 8)
    attempts = 0

    while len(closed_titles) < count and attempts < safety_limit:
        attempts += 1
        title = _foreground_title() or ""
        if browser_keyword not in title.lower() and "chrome" not in title.lower() and "edge" not in title.lower() and "firefox" not in title.lower():
            # Focus was lost (e.g. a "save changes?" dialog appeared).
            break
        if keep_keywords and any(k in title.lower() for k in keep_keywords):
            skipped_titles.append(title)
            pyautogui.hotkey("ctrl", "tab")
            time.sleep(0.25)
            continue
        before_title=title
        try:
            from friday_truth_verifier import snapshot
            before=snapshot()
        except Exception:
            before=None
        pyautogui.hotkey("ctrl", "w")
        time.sleep(0.35)
        after_title=_foreground_title() or ""
        try:
            after=snapshot() if before is not None else None
            from friday_truth_verifier import compare
            evidence=compare(before,after) if before and after else {"visual_changed": bool(after_title and after_title!=before_title),"evidence_quality":"moderate"}
        except Exception:
            evidence={"visual_changed": bool(after_title and after_title!=before_title),"evidence_quality":"moderate"}
        changed=bool(evidence.get("visual_changed") or evidence.get("uia_changed") or (after_title and after_title!=before_title))
        close_evidence.append({"before":before_title,"after":after_title,"verified":changed,"evidence":evidence})
        if changed:
            closed_titles.append(title)

    return {
        "ok": len(closed_titles) > 0,
        "closed_count": len(closed_titles),
        "requested_count": count,
        "closed_titles": closed_titles,
        "skipped_titles": skipped_titles,
        "verified": bool(len(closed_titles)==count and all(x.get("verified") for x in close_evidence)),
        "evidence": close_evidence,
        "verification_note": "Each requested close was checked for an observable post-close UI/window change; full hidden-tab enumeration is not available without browser debugging access."
    }


# ------------------------------------------------------------------
# REAL, VERIFIED WINDOW CONTROL: minimise an app / go back to an open app.
#
# WHY: "minimise X" used to be a blind Alt+Space,N keystroke sent to whatever
# window happened to be in front (usually FRIDAY itself) and was reported as
# done without looking; "go back to X" had no handler at all and "open X" on an
# app that was already running never brought its window forward. Here we find
# the app's actual top-level window(s) with the Win32 API, act on them, and
# report success only after re-reading the window state (IsIconic /
# GetForegroundWindow).
# ------------------------------------------------------------------

SW_MINIMIZE = 6
SW_FORCEMINIMIZE = 11
SW_SHOW = 5
WM_SYSCOMMAND = 0x0112
SC_MINIMIZE = 0xF020
SW_MAXIMIZE = 3
SC_MAXIMIZE = 0xF030
SC_RESTORE = 0xF120
GWL_STYLE = -16
WS_MAXIMIZEBOX = 0x00010000
GW_OWNER = 4
GA_ROOT = 2
GWL_EXSTYLE = -20
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_APPWINDOW = 0x00040000

_wc_u32 = None


def _wc():
    """Private user32 handle with proper argtypes (does not touch the shared
    ctypes.windll.user32 used by other modules)."""
    global _wc_u32
    if _wc_u32 is None:
        u = ctypes.WinDLL("user32", use_last_error=True)
        H = wintypes.HWND
        u.IsWindowVisible.argtypes = [H]
        u.IsWindowVisible.restype = wintypes.BOOL
        u.IsIconic.argtypes = [H]
        u.IsIconic.restype = wintypes.BOOL
        u.ShowWindow.argtypes = [H, ctypes.c_int]
        u.ShowWindow.restype = wintypes.BOOL
        u.IsZoomed.argtypes = [H]
        u.IsZoomed.restype = wintypes.BOOL
        u.GetForegroundWindow.argtypes = []
        u.GetForegroundWindow.restype = H
        u.GetAncestor.argtypes = [H, wintypes.UINT]
        u.GetAncestor.restype = H
        u.GetWindow.argtypes = [H, wintypes.UINT]
        u.GetWindow.restype = H
        u.GetWindowTextLengthW.argtypes = [H]
        u.GetWindowTextLengthW.restype = ctypes.c_int
        u.GetWindowTextW.argtypes = [H, wintypes.LPWSTR, ctypes.c_int]
        u.GetWindowTextW.restype = ctypes.c_int
        u.GetWindowThreadProcessId.argtypes = [H, ctypes.POINTER(wintypes.DWORD)]
        u.GetWindowThreadProcessId.restype = wintypes.DWORD
        u.GetWindowLongW.argtypes = [H, ctypes.c_int]
        u.GetWindowLongW.restype = ctypes.c_long
        u.BringWindowToTop.argtypes = [H]
        u.BringWindowToTop.restype = wintypes.BOOL
        u.SetForegroundWindow.argtypes = [H]
        u.SetForegroundWindow.restype = wintypes.BOOL
        u.SwitchToThisWindow.argtypes = [H, wintypes.BOOL]
        u.SwitchToThisWindow.restype = None
        u.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        u.AttachThreadInput.restype = wintypes.BOOL
        u.PostMessageW.argtypes = [H, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.PostMessageW.restype = wintypes.BOOL
        u.keybd_event.argtypes = [wintypes.BYTE, wintypes.BYTE, wintypes.DWORD, ctypes.c_size_t]
        u.keybd_event.restype = None
        _wc_u32 = u
    return _wc_u32


def _is_cloaked(hwnd) -> bool:
    """Hidden UWP/virtual-desktop ghost windows are 'visible' to EnumWindows but not on screen."""
    try:
        val = ctypes.c_int(0)
        ctypes.WinDLL("dwmapi").DwmGetWindowAttribute(wintypes.HWND(hwnd), 14, ctypes.byref(val), 4)
        return bool(val.value)
    except Exception:
        return False


def _own_pids() -> set:
    """This process and its ancestors (the Electron shell that owns FRIDAY's windows)."""
    import os
    pids = {os.getpid()}
    if psutil is not None:
        try:
            for parent in psutil.Process().parents():
                pids.add(parent.pid)
        except Exception:
            pass
    return pids


def _proc_stem(pid: int) -> str:
    if psutil is None:
        return ""
    try:
        name = psutil.Process(pid).name().lower()
        return name[:-4] if name.endswith(".exe") else name
    except Exception:
        return ""


def _compact(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def list_app_windows(include_self: bool = False) -> list:
    """Real top-level application windows in z-order (front first):
    [{"hwnd","title","pid","proc","iconic"}]. FRIDAY's own windows are excluded
    unless include_self=True."""
    if not _IS_WINDOWS:
        return []
    u = _wc()
    own = set() if include_self else _own_pids()
    found: list = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _cb(hwnd, _lp):
        try:
            if not hwnd or not u.IsWindowVisible(hwnd):
                return True
            if u.GetWindow(hwnd, GW_OWNER):          # owned popups/dialogs are not app windows
                return True
            ex = u.GetWindowLongW(hwnd, GWL_EXSTYLE)
            if (ex & WS_EX_TOOLWINDOW) and not (ex & WS_EX_APPWINDOW):
                return True
            n = u.GetWindowTextLengthW(hwnd)
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            u.GetWindowTextW(hwnd, buf, n + 1)
            title = buf.value.strip()
            if not title or title == "Program Manager":
                return True
            if _is_cloaked(hwnd):
                return True
            pid = wintypes.DWORD()
            u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value in own:
                return True
            if not include_self and title.lower().startswith("friday"):
                return True
            found.append({"hwnd": int(hwnd), "title": title, "pid": int(pid.value),
                          "proc": _proc_stem(int(pid.value)), "iconic": bool(u.IsIconic(hwnd))})
        except Exception:
            pass
        return True

    try:
        u.EnumWindows(_cb, 0)
    except Exception:
        pass
    return found


def _match_app_windows(raw_name: str, windows: list, matcher=None) -> list:
    """Windows belonging to the app the user named. Process name is the strong
    signal; window title is only a fallback so e.g. a document called 'word list'
    in Notepad is not mistaken for Microsoft Word."""
    if matcher is not None:
        return [w for w in windows if matcher(w["title"], w["proc"])]
    name = _normalize_app_name(raw_name)
    if not name:
        return []
    alias = APP_ALIASES.get(name, {})
    if not alias and len(name) >= 5:
        close = difflib.get_close_matches(name, list(APP_ALIASES.keys()), n=1, cutoff=0.78)
        if close:
            name = close[0]
            alias = APP_ALIASES[name]
    proc_names = {p.lower()[:-4] if p.lower().endswith(".exe") else p.lower() for p in alias.get("proc_names", [])}
    hint = alias.get("cmdline_hint")
    keyword = alias.get("window", name).lower()
    compact = _compact(name)

    by_proc = []
    for w in windows:
        stem = w["proc"]
        if not stem:
            continue
        if proc_names and stem in proc_names:
            if hint and psutil is not None:
                try:
                    if hint not in " ".join(psutil.Process(w["pid"]).cmdline()).lower():
                        continue
                except Exception:
                    pass
            by_proc.append(w)
        elif not proc_names and len(compact) >= 3 and (compact == _compact(stem) or compact in _compact(stem)):
            by_proc.append(w)
    if by_proc:
        return by_proc
    by_title = [w for w in windows
                if keyword in w["title"].lower()
                or (len(compact) >= 4 and compact in _compact(w["title"]))]
    return by_title


def _foreground_root():
    u = _wc()
    fg = u.GetForegroundWindow()
    if not fg:
        return 0
    root = u.GetAncestor(fg, GA_ROOT)
    return int(root or fg)


def _force_foreground(hwnd: int, timeout: float = 1.2) -> bool:
    """Restore (if minimised) and bring a window to the front, then CHECK that it
    really is the foreground window. Windows blocks plain SetForegroundWindow
    from background processes, so we use the standard Alt-tap + thread-attach trick."""
    if not _IS_WINDOWS:
        return False
    u = _wc()
    kernel32 = ctypes.windll.kernel32
    deadline = time.time() + timeout
    attempt = 0
    while True:
        attempt += 1
        try:
            if u.IsIconic(hwnd):
                u.ShowWindow(hwnd, SW_RESTORE)
            else:
                u.ShowWindow(hwnd, SW_SHOW)
            fg = u.GetForegroundWindow()
            cur_tid = kernel32.GetCurrentThreadId()
            fg_tid = u.GetWindowThreadProcessId(fg, None) if fg else 0
            attached = False
            if fg_tid and fg_tid != cur_tid:
                attached = bool(u.AttachThreadInput(cur_tid, fg_tid, True))
            try:
                u.keybd_event(0x12, 0, 0, 0)         # tap Alt: lifts the foreground lock
                u.keybd_event(0x12, 0, 2, 0)
                u.BringWindowToTop(hwnd)
                u.SetForegroundWindow(hwnd)
            finally:
                if attached:
                    u.AttachThreadInput(cur_tid, fg_tid, False)
            if attempt >= 2 and _foreground_root() != hwnd:
                u.SwitchToThisWindow(hwnd, True)
        except Exception:
            pass
        end = time.time() + 0.25
        while time.time() < end:
            if _foreground_root() == hwnd and not u.IsIconic(hwnd):
                return True
            time.sleep(0.03)
        if time.time() >= deadline:
            return _foreground_root() == hwnd and not u.IsIconic(hwnd)


def _minimize_hwnd(hwnd: int) -> bool:
    """Minimise one window and verify with IsIconic."""
    u = _wc()
    if u.IsIconic(hwnd):
        return True
    for how in ("show", "syscommand", "force"):
        try:
            if how == "show":
                u.ShowWindow(hwnd, SW_MINIMIZE)
            elif how == "syscommand":
                u.PostMessageW(hwnd, WM_SYSCOMMAND, SC_MINIMIZE, 0)
            else:
                u.ShowWindow(hwnd, SW_FORCEMINIMIZE)
        except Exception:
            continue
        end = time.time() + 0.6
        while time.time() < end:
            if u.IsIconic(hwnd):
                return True
            time.sleep(0.04)
    return bool(u.IsIconic(hwnd))


def _front_app_window(windows: list):
    """The window the user is working in: the foreground one, or, if that is
    FRIDAY itself, the top-most other app window."""
    fg = _foreground_root()
    for w in windows:
        if w["hwnd"] == fg:
            return w
    for w in windows:
        if not w["iconic"]:
            return w
    return None


def minimize_application(raw_name: str = "", matcher=None) -> dict:
    """Minimise the named app's window(s). Empty name = the window in front.
    ok is True only after every targeted window is confirmed minimised."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows"}
    windows = list_app_windows()
    name = (raw_name or "").strip()
    if not name:
        w = _front_app_window(windows)
        targets = [w] if w else []
    else:
        targets = _match_app_windows(name, windows, matcher)
    if not targets:
        return {"ok": False, "error": "not_found", "found": False}
    done, failed = [], []
    for w in targets:
        (done if _minimize_hwnd(w["hwnd"]) else failed).append(w["title"])
    return {"ok": bool(done) and not failed, "found": True, "minimized": done, "failed": failed}


# ------------------------------------------------------------------
# V6.4: real maximise / restore-down. Before this, "maximise chrome" was treated as "bring chrome to the front" and never
# changed the window size. Same approach as minimise: act on the app's real window, then re-read IsZoomed to confirm.
# ------------------------------------------------------------------

def _is_maximized(hwnd: int) -> bool:
    u = _wc()
    return bool(u.IsZoomed(hwnd)) and not bool(u.IsIconic(hwnd))


def _can_maximize(hwnd: int) -> bool:
    try:
        style = _wc().GetWindowLongW(hwnd, GWL_STYLE) & 0xFFFFFFFF
        return bool(style & WS_MAXIMIZEBOX)
    except Exception:
        return True


def _maximize_hwnd(hwnd: int) -> bool:
    """Maximise one window (also when it is minimised) and verify with IsZoomed."""
    u = _wc()
    if _is_maximized(hwnd):
        return True
    for how in ("show", "syscommand", "foreground"):
        try:
            if how == "show":
                if u.IsIconic(hwnd):
                    u.ShowWindow(hwnd, SW_RESTORE)          # a window minimised from maximised comes back maximised
                    time.sleep(0.12)
                if not _is_maximized(hwnd):
                    u.ShowWindow(hwnd, SW_MAXIMIZE)
            elif how == "syscommand":
                u.PostMessageW(hwnd, WM_SYSCOMMAND, SC_MAXIMIZE, 0)
            else:
                _force_foreground(hwnd, 1.0)
                u.ShowWindow(hwnd, SW_MAXIMIZE)
        except Exception:
            continue
        end = time.time() + 0.7
        while time.time() < end:
            if _is_maximized(hwnd):
                return True
            time.sleep(0.04)
    return _is_maximized(hwnd)


def _restore_down_hwnd(hwnd: int) -> bool:
    """Take a maximised window back to its normal size (and un-minimise it) and verify."""
    u = _wc()
    if not u.IsIconic(hwnd) and not u.IsZoomed(hwnd):
        return True
    for how in ("show", "syscommand"):
        try:
            if how == "show":
                u.ShowWindow(hwnd, SW_RESTORE)
                if u.IsZoomed(hwnd) and not u.IsIconic(hwnd):
                    pass
                elif u.IsIconic(hwnd):                       # was minimised from maximised: restore once more
                    time.sleep(0.12)
                    u.ShowWindow(hwnd, SW_RESTORE)
            else:
                u.PostMessageW(hwnd, WM_SYSCOMMAND, SC_RESTORE, 0)
        except Exception:
            continue
        end = time.time() + 0.7
        while time.time() < end:
            if not u.IsZoomed(hwnd) and not u.IsIconic(hwnd):
                return True
            time.sleep(0.04)
    return not u.IsZoomed(hwnd) and not u.IsIconic(hwnd)


def _pick_targets(raw_name: str, matcher=None, only_front: bool = True) -> list:
    """Windows to act on. Empty name = the window the user is working in. A named app with several windows = its front-most one."""
    windows = list_app_windows()
    name = (raw_name or "").strip()
    if not name:
        w = _front_app_window(windows)
        return [w] if w else []
    matches = _match_app_windows(name, windows, matcher)
    if not matches:
        return []
    matches.sort(key=lambda w: w["iconic"])      # on-screen windows first (list_app_windows is already front-to-back)
    return matches[:1] if only_front else matches


def maximize_application(raw_name: str = "", matcher=None) -> dict:
    """Maximise the named app's window (empty name = the window in front) and confirm it is really maximised.
    Result: ok, found, maximized (titles), already (titles), failed (titles), not_maximizable (titles)."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows", "found": False}
    targets = _pick_targets(raw_name, matcher)
    if not targets:
        return {"ok": False, "error": "not_found", "found": False}
    done, already, failed, fixed = [], [], [], []
    for w in targets:
        h = w["hwnd"]
        if _is_maximized(h):
            already.append(w["title"])
            continue
        if _maximize_hwnd(h):
            done.append(w["title"])
        else:
            (fixed if not _can_maximize(h) else failed).append(w["title"])
    focused = False
    if done or already:
        try:
            focused = _force_foreground(targets[0]["hwnd"], 1.0)
        except Exception:
            focused = False
    return {"ok": bool(done or already) and not failed and not fixed, "found": True, "maximized": done, "already": already,
            "failed": failed, "not_maximizable": fixed, "focused": focused}


def maximize_all_windows() -> dict:
    """Maximise every on-screen app window except FRIDAY's own."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows", "found": False}
    targets = [w for w in list_app_windows() if not w["iconic"]]
    if not targets:
        return {"ok": True, "found": True, "maximized": [], "already": [], "failed": [], "not_maximizable": []}
    done, already, failed, fixed = [], [], [], []
    for w in targets:
        h = w["hwnd"]
        if _is_maximized(h):
            already.append(w["title"])
        elif _maximize_hwnd(h):
            done.append(w["title"])
        else:
            (fixed if not _can_maximize(h) else failed).append(w["title"])
    return {"ok": bool(done or already) and not failed, "found": True, "maximized": done, "already": already,
            "failed": failed, "not_maximizable": fixed}


def restore_down_application(raw_name: str = "", matcher=None) -> dict:
    """'Un-maximise': return the named window (empty = the one in front) to its normal size and confirm it."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows", "found": False}
    targets = _pick_targets(raw_name, matcher)
    if not targets:
        return {"ok": False, "error": "not_found", "found": False}
    done, failed = [], []
    for w in targets:
        (done if _restore_down_hwnd(w["hwnd"]) else failed).append(w["title"])
    return {"ok": bool(done) and not failed, "found": True, "restored": done, "failed": failed}


def minimize_all_windows() -> dict:
    """Minimise every app window except FRIDAY's own."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows"}
    targets = [w for w in list_app_windows() if not w["iconic"]]
    if not targets:
        return {"ok": True, "found": True, "minimized": [], "failed": []}
    done, failed = [], []
    for w in targets:
        (done if _minimize_hwnd(w["hwnd"]) else failed).append(w["title"])
    return {"ok": bool(done) and not failed, "found": True, "minimized": done, "failed": failed}


def focus_application(raw_name: str, matcher=None) -> dict:
    """Bring an ALREADY OPEN app's window to the front (restoring it if it is
    minimised) and verify that it is now the foreground window.
    Result has found=False when the app has no open window."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows", "found": False}
    windows = list_app_windows()
    targets = _match_app_windows(raw_name, windows, matcher)
    if not targets:
        return {"ok": False, "error": "not_found", "found": False}
    # Prefer a window that is on screen, front-most first; fall back to a minimised one.
    targets.sort(key=lambda w: w["iconic"])
    for w in targets:
        if _force_foreground(w["hwnd"]):
            return {"ok": True, "found": True, "focused": w["title"], "hwnd": w["hwnd"]}
    return {"ok": False, "error": "focus_failed", "found": True, "focused": targets[0]["title"]}


def focus_previous_window() -> dict:
    """'Go back to the previous app': the next window in z-order behind the current one."""
    if not _IS_WINDOWS:
        return {"ok": False, "error": "not_windows", "found": False}
    windows = list_app_windows()
    fg = _foreground_root()
    candidates = [w for w in windows if w["hwnd"] != fg]
    if not candidates:
        return {"ok": False, "error": "not_found", "found": False}
    w = candidates[0]
    if _force_foreground(w["hwnd"]):
        return {"ok": True, "found": True, "focused": w["title"], "hwnd": w["hwnd"]}
    return {"ok": False, "error": "focus_failed", "found": True, "focused": w["title"]}
