"""FRIDAY 7.0 security and recovery center (roadmap #25).

One place that answers "is FRIDAY safe, intact and recoverable?" - built on the 6.0 security engine (tamper-evident audit chain, per-tool permissions,
backups, dependency scan) and adding what was missing:

    secrets        scans the project and its logs for API keys / tokens / private keys (masked in every report; nothing is ever printed in full)
    integrity      protected files (listening, speaking) and every module against the last known-good build; database quick-check
    backups        newest backup tested (zip integrity), its age, and a verified "back up now"
    privileges     what FRIDAY may do right now (permissions, sensors, autonomy), with the riskiest switches flagged
    crash recovery a run marker: an unclean shutdown is detected on the next start and interrupted missions are paused, not lost or silently re-run
    audit          every consequential tool run and finished mission is written into the tamper-evident audit chain

Nothing here touches the microphone, recognition or speech code, and nothing is changed without you saying so.
"""
from __future__ import annotations

import atexit
import json
import os
import re
import threading
import time
import zipfile
from pathlib import Path
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

HERE = Path(__file__).resolve().parent
RUN_MARK = lambda: C.DATA_DIR / "running7.json"        # noqa: E731
SECRET_PATTERNS = [
    ("Google API key", re.compile(r"AIza[0-9A-Za-z_\-]{35}")),
    ("OpenAI-style key", re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}")),
    ("Slack token", re.compile(r"\bxox[abprs]-[A-Za-z0-9\-]{10,}")),
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("private key block", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----")),
]
SCAN_EXT = {".py", ".js", ".json", ".env", ".md", ".txt", ".log", ".html", ".bat", ".cfg", ".ini", ".yml", ".yaml", ".jsonl"}
SKIP = {"node_modules", "__pycache__", ".git", "dist", "speech_cache", "attachments", "captures", "backups", "repair_backups", "trash"}
MAX_FILES, MAX_BYTES, SCAN_BUDGET_S = 5000, 2_000_000, 15.0
CONSEQUENTIAL = {"sensitive", "irreversible"}


def _mask(s: str) -> str:
    return s[:4] + "…" + s[-2:] if len(s) > 10 else "…"


# ------------------------------------------------------------------ secrets
def scan_secrets(root: Optional[Path] = None) -> Dict:
    root = Path(root or HERE)
    t0 = time.time()
    finds: List[Dict] = []
    scanned = 0
    roots = [root]
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP]
        for name in fn:
            p = Path(dp) / name
            if p.suffix.lower() not in SCAN_EXT and name != ".env":
                continue
            if scanned >= MAX_FILES or time.time() - t0 > SCAN_BUDGET_S:
                return {"scanned": scanned, "findings": finds, "complete": False}
            try:
                if p.stat().st_size > MAX_BYTES:
                    continue
                txt = p.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            scanned += 1
            for label, rx in SECRET_PATTERNS:
                for m in rx.finditer(txt):
                    line = txt.count("\n", 0, m.start()) + 1
                    ctx = txt[max(0, m.start() - 40):m.start()].lower()
                    if "example" in ctx or "your_key" in ctx or "xxxx" in m.group(0).lower() or p.name.startswith(("FRIDAY_TEST", "friday_test", "friday_seccenter7", "friday_security6", "friday_common6")):
                        continue
                    finds.append({"file": str(p.relative_to(root)), "line": line, "kind": label, "masked": _mask(m.group(0)), "where": "log" if p.suffix in (".log", ".jsonl") else "file"})
                    break
    env = root / ".env"
    perm_note = ""
    try:
        if env.exists() and os.name != "nt" and (env.stat().st_mode & 0o077):
            perm_note = ".env is readable by other users on this computer (run: chmod 600 .env)"
    except Exception:
        pass
    return {"scanned": scanned, "findings": finds, "complete": True, "env_present": env.exists(), "env_permission_note": perm_note}


# ------------------------------------------------------------------ integrity
def integrity(root: Optional[Path] = None) -> Dict:
    root = Path(root or HERE)
    out: Dict = {"protected": [], "modified": [], "new_modules": [], "baseline": "", "db": ""}
    try:
        import friday_ci7 as CI
        kg = CI.load_known_good(root)
        cur = CI.build_manifest(root, with_symbols=False)
        if kg:
            out["baseline"] = kg.get("_path", "")
            for f in CI.PROTECTED:
                a, b = (kg.get("files") or {}).get(f), cur["files"].get(f)
                out["protected"].append({"file": f, "status": "unchanged" if a and a == b else ("missing" if not b else "CHANGED" if a else "no baseline")})
            out["modified"] = sorted(f for f, h in cur["files"].items() if f in (kg.get("files") or {}) and kg["files"][f] != h and f.endswith(".py"))
            out["new_modules"] = sorted(f for f in cur["files"] if f not in (kg.get("files") or {}) and f.endswith(".py"))
        else:
            out["protected"] = [{"file": f, "status": "no baseline"} for f in CI.PROTECTED]
    except Exception as exc:
        out["error"] = f"{type(exc).__name__}: {exc}"[:120]
    try:
        r = C.q("PRAGMA quick_check")
        out["db"] = "ok" if r and list(dict(r[0]).values())[0] == "ok" else "PROBLEM: " + str(list(dict(r[0]).values())[0])[:80]
    except Exception as exc:
        out["db"] = f"could not check: {exc}"[:80]
    return out


# ------------------------------------------------------------------ backups
def backups() -> Dict:
    d = C.DATA_DIR / "backups"
    files = sorted(d.glob("backup_*.zip"), reverse=True) if d.exists() else []
    if not files:
        return {"count": 0, "newest": "", "age_days": None, "valid": None}
    f = files[0]
    try:
        with zipfile.ZipFile(f) as z:
            bad = z.testzip()
            has_db = any(n.endswith("friday6.db") for n in z.namelist())
        valid = bad is None
    except Exception as exc:
        valid, has_db = False, False
    return {"count": len(files), "newest": f.name, "age_days": round((time.time() - f.stat().st_mtime) / 86400, 1), "valid": valid, "has_database": has_db, "size_kb": round(f.stat().st_size / 1024)}


def backup_now(include_source: bool = True) -> Dict:
    import friday_security6 as SEC
    path = SEC.backup("manual", include_source=include_source)
    try:
        with zipfile.ZipFile(path) as z:
            bad = z.testzip()
            n = len(z.namelist())
        return {"ok": bad is None, "path": path, "files": n, "error": f"corrupt entry {bad}" if bad else ""}
    except Exception as exc:
        return {"ok": False, "path": path, "files": 0, "error": f"{type(exc).__name__}: {exc}"}


# ------------------------------------------------------------------ privileges
def privileges() -> Dict:
    perms, sensors = [], {}
    try:
        import friday_security6 as SEC
        perms = SEC.permissions()
        sensors = SEC.sensors()
    except Exception:
        pass
    flags = []
    on = {p["tool"] for p in perms if p.get("allowed")}
    if "delete_files" in on:
        flags.append("file deletion is allowed (say 'disable delete files' if you don't need it)")
    if "run_code" in on:
        flags.append("running code is allowed (say 'disable run code' if you don't need it)")
    for s, v in sensors.items():
        if v:
            flags.append(f"the {s} is switched on")
    return {"permissions": perms, "sensors": sensors, "autonomy": K.cfg_get("autonomy_level"), "flags": flags}


# ------------------------------------------------------------------ crash recovery
def _pid_alive(pid: int) -> bool:
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        try:
            os.kill(pid, 0)
            return True
        except Exception:
            return False


def boot_check() -> Dict:
    """Call once at start-up. Detects an unclean shutdown from the run marker, pauses interrupted missions and writes a fresh marker."""
    res = {"unclean": False, "since": "", "paused_jobs": []}
    p = RUN_MARK()
    try:
        if p.exists():
            old = json.loads(p.read_text(encoding="utf-8"))
            if not (old.get("pid") and old["pid"] != os.getpid() and _pid_alive(int(old["pid"])) and time.time() - float(old.get("ts", 0)) < 60):
                if not old.get("clean"):
                    res["unclean"], res["since"] = True, C.iso(float(old.get("ts", 0)))
    except Exception:
        pass
    if res["unclean"]:
        try:
            import friday_orchestrator7 as O
            res["paused_jobs"] = O.recover()
        except Exception:
            pass
        try:
            import friday_health7 as H
            H.incident("system", f"FRIDAY did not shut down cleanly (last heartbeat {res['since']}); {len(res['paused_jobs'])} mission(s) paused")
        except Exception:
            pass
        try:
            import friday_security6 as SEC
            SEC.audit("friday", "unclean-shutdown", res["since"], "recovered")
        except Exception:
            pass
    heartbeat()
    atexit.register(clean_shutdown)
    return res


def heartbeat():
    try:
        RUN_MARK().parent.mkdir(parents=True, exist_ok=True)
        RUN_MARK().write_text(json.dumps({"pid": os.getpid(), "ts": time.time(), "clean": False, "session": K.SESSION_ID}), encoding="utf-8")
    except Exception:
        pass


def clean_shutdown():
    try:
        RUN_MARK().write_text(json.dumps({"pid": os.getpid(), "ts": time.time(), "clean": True, "session": K.SESSION_ID}), encoding="utf-8")
    except Exception:
        pass


# ------------------------------------------------------------------ audit
def _on_receipt(rec: Dict):
    try:
        tool = rec.get("tool", "")
        import friday_policy7 as POL
        risk = POL.TOOL_RISK.get(tool, ("safe", None))[0]
        if risk not in CONSEQUENTIAL:
            return
        import friday_security6 as SEC
        a = rec.get("args")
        detail = (json.dumps(a, default=str) if not isinstance(a, str) else a)[:200]
        SEC.audit("friday", f"tool:{tool}", detail, "ok" if rec.get("ok") else "failed")
    except Exception:
        pass


def _on_job_done(p: Dict):
    try:
        import friday_security6 as SEC
        SEC.audit("friday", "mission", f"{p.get('goal', '')[:120]} -> {p.get('state')}", "ok" if p.get("state") == "done" else str(p.get("state")))
    except Exception:
        pass


def install_events():
    K.on("receipt", _on_receipt)
    K.on("job.done", _on_job_done)


def consequential_actions(hours: float = 24.0, n: int = 20) -> List[Dict]:
    cut = time.time() - hours * 3600
    rows = C.q("SELECT * FROM audit6 WHERE ts>=? AND (action LIKE 'tool:%' OR action IN ('mission','backup','restore','unclean-shutdown','repair-applied','file-op')) ORDER BY id DESC LIMIT ?", (cut, n)) if C.q("SELECT name FROM sqlite_master WHERE name='audit6'") else []
    return [{"when": C.iso(r["ts"]), "action": r["action"], "detail": r["detail"], "result": r["result"]} for r in rows]


# ------------------------------------------------------------------ the report
def full_report(deps: bool = True) -> Dict:
    sec = scan_secrets()
    integ = integrity()
    bk = backups()
    priv = privileges()
    d = {}
    if deps:
        try:
            import friday_security6 as SEC
            d = SEC.scan_dependencies()
        except Exception as exc:
            d = {"conflicts": [f"scan unavailable: {exc}"], "risky": [], "checked": 0}
    try:
        import friday_security6 as SEC
        chain = SEC.verify_audit()
    except Exception:
        chain = {"ok": None, "checked": 0}
    issues, notes = [], []
    if sec["findings"]:
        issues.append(f"{len(sec['findings'])} possible secret(s) found in files: " + "; ".join(f"{f['kind']} {f['masked']} in {f['file']}:{f['line']}" for f in sec["findings"][:3]))
    if sec.get("env_permission_note"):
        issues.append(sec["env_permission_note"])
    if any(p["status"] in ("CHANGED", "missing") for p in integ["protected"]):
        issues.append("a protected listening/speaking file differs from the known-good build")
    if integ["db"] not in ("ok", ""):
        issues.append("database check: " + integ["db"])
    if bk["count"] == 0:
        issues.append("there is no backup yet (say 'back up now')")
    elif bk["valid"] is False:
        issues.append(f"the newest backup {bk['newest']} failed its integrity test")
    elif bk["age_days"] is not None and bk["age_days"] > 7:
        issues.append(f"the newest backup is {bk['age_days']:.0f} days old")
    if d.get("risky"):
        issues.append("risky packages: " + "; ".join(d["risky"][:2]))
    if d.get("conflicts") and d["conflicts"] and "unavailable" not in d["conflicts"][0]:
        issues.append("package conflicts: " + "; ".join(d["conflicts"][:2]))
    if chain.get("ok") is False:
        issues.append(f"the audit chain was altered at entry {chain.get('broken_at')}")
    if integ["modified"]:
        notes.append(f"{len(integ['modified'])} module(s) differ from the last known-good build (normal after an update)")
    if not integ["baseline"]:
        notes.append("no known-good baseline is recorded yet")
    notes += priv["flags"]
    if not sec["complete"]:
        notes.append("the secret scan stopped early (time limit) - it covered " + str(sec["scanned"]) + " files")
    return {"issues": issues, "notes": notes, "secrets": sec, "integrity": integ, "backups": bk, "privileges": priv, "dependencies": d, "audit_chain": chain, "ts": C.iso(time.time())}


def describe(rep: Dict) -> str:
    lines = [f"Security and recovery check - {rep['ts']}"]
    lines.append(("ATTENTION - " + str(len(rep["issues"])) + " issue(s):") if rep["issues"] else "No issues found.")
    lines += [f"  ✗ {i}" for i in rep["issues"]]
    s, i, b, d = rep["secrets"], rep["integrity"], rep["backups"], rep["dependencies"]
    lines.append(f"  secrets: {s['scanned']} files scanned, {len(s['findings'])} possible secret(s)" + (", API key kept in .env" if s.get("env_present") else ""))
    lines.append("  integrity: " + ", ".join(f"{p['file']} {p['status']}" for p in i["protected"]) + f"; database {i['db'] or 'not checked'}")
    lines.append("  backups: " + (f"{b['count']} kept, newest {b['newest']} ({b['age_days']} days old, {'valid' if b['valid'] else 'INVALID'})" if b["count"] else "none"))
    lines.append(f"  dependencies: {d.get('checked', 0)} packages checked, {len(d.get('risky', []))} risky, {len(d.get('conflicts', []))} conflicts")
    lines.append(f"  audit chain: {'intact, ' + str(rep['audit_chain'].get('checked')) + ' entries' if rep['audit_chain'].get('ok') else 'NOT intact' if rep['audit_chain'].get('ok') is False else 'n/a'}")
    lines.append(f"  autonomy: {rep['privileges']['autonomy']}")
    lines += [f"  note: {n}" for n in rep["notes"][:6]]
    return "\n".join(lines)


def spoken(rep: Dict) -> str:
    if not rep["issues"]:
        return "Security check done: no leaked secrets, the listening and speaking files are unchanged, and your backups are fine."
    return f"Security check found {len(rep['issues'])} thing(s) to look at. " + " ".join(rep["issues"][:2])


# ------------------------------------------------------------------ chat
_busy = {"on": False}


def _bg(label: str, fn):
    if _busy["on"]:
        return "A security check is already running."
    _busy["on"] = True

    def work():
        try:
            rep = fn()
            K.emit_ui("security_report", {"text": describe(rep)})
            K.say(spoken(rep))
        except Exception as exc:
            K.say(f"The security check failed: {type(exc).__name__}.")
        finally:
            _busy["on"] = False
    threading.Thread(target=work, name="Friday7Security", daemon=True).start()
    return f"Running the {label}. The package scan can take half a minute; I'll tell you the result."


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if re.match(r"^(?:run |do |start )?(?:a |the )?(?:full )?security (?:center|centre|report|audit|check|status)$|^security and recovery (?:center|centre|check|report)$", t):
        return _bg("full security and recovery check", full_report)
    if re.match(r"^(?:scan|check|look) (?:my |the )?(?:project |files |folder )?for (?:leaked |exposed )?(?:secrets|api keys|passwords|tokens)$|^secret scan$|^(?:are|is) (?:my|the) (?:api )?keys? (?:safe|leaked|exposed)$", t):
        s = scan_secrets()
        if not s["findings"]:
            return f"I scanned {s['scanned']} files and found no exposed keys or tokens" + (". Your API key is kept in the .env file, as it should be - don't share that file." if s.get("env_present") else ".")
        return f"Found {len(s['findings'])} possible secret(s): " + "; ".join(f"{f['kind']} {f['masked']} in {f['file']} line {f['line']}" for f in s["findings"][:4]) + ". I have not changed anything."
    if re.match(r"^(?:check|verify) (?:the )?(?:integrity|my files|my installation|the installation)$|^integrity check$|^(?:has|was) anything (?:been )?(?:tampered|changed|modified)(?: with)?$", t):
        i = integrity()
        prot = ", ".join(f"{p['file']} {p['status']}" for p in i["protected"])
        s = f"Protected listening and speaking files: {prot}. Database: {i['db'] or 'not checked'}."
        if i["modified"]:
            s += f" {len(i['modified'])} module(s) differ from the last known-good build."
        if not i["baseline"]:
            s += " No known-good baseline is recorded yet."
        return s
    if re.match(r"^(?:verify|check|test) (?:my |the )?backups?$|^are my backups (?:ok|fine|good|valid)$", t):
        b = backups()
        if not b["count"]:
            return "There are no backups yet. Say 'back up now' to make one."
        return f"{b['count']} backup(s). The newest is {b['newest']}, {b['age_days']} days old, {'passes' if b['valid'] else 'FAILS'} its integrity test" + (" and contains the database." if b.get("has_database") else ".")
    if re.match(r"^(?:verified |safe )?back ?up (?:everything )?(?:and verify|with source)$|^back ?up (?:and|then) verify(?: it)?$", t):
        r = backup_now()
        return f"Backup saved and verified: {Path(r['path']).name}, {r['files']} files." if r["ok"] else f"The backup was written but failed verification: {r['error']}."
    if re.match(r"^(?:crash recovery|recovery) status$|^did you (?:crash|shut down (?:badly|unexpectedly))$", t):
        rows = [i for i in (__import__("friday_health7").incidents(False, 30)) if "did not shut down" in i["text"]][:1]
        return f"Yes - {rows[0]['text']}." if rows else "No unclean shutdown has been recorded."
    if re.match(r"^(?:least privilege|privilege|access) report$|^what (?:access|permissions) do you have(?: right now)?$", t):
        p = privileges()
        on = [x["tool"].replace("_", " ") for x in p["permissions"] if x.get("allowed")]
        off = [x["tool"].replace("_", " ") for x in p["permissions"] if not x.get("allowed")]
        return f"Allowed: {', '.join(on) or 'nothing'}. Blocked: {', '.join(off) or 'nothing'}. Autonomy: {p['autonomy']}." + (" Worth reviewing: " + "; ".join(p["flags"][:3]) + "." if p["flags"] else "")
    if re.match(r"^(?:show |list )?(?:the )?(?:consequential|important) actions(?: (?:today|you(?:'ve| have) taken))?$|^what (?:have you|did you) (?:changed?|done) (?:today|recently)$", t):
        a = consequential_actions()
        return "Nothing consequential has been recorded in the last 24 hours." if not a else "Recorded in the tamper-evident log:\n" + "\n".join(f"{x['when']} {x['action']} {x['detail'][:70]} ({x['result']})" for x in a[:8])
    return None


def ui_snapshot() -> Dict:
    return {"security": {"backups": backups(), "privileges": privileges(), "consequential": consequential_actions(24, 8)}}
