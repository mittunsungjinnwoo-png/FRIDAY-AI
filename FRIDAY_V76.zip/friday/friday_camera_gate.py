"""FRIDAY 7.0 camera gate.

Any sentence that mentions the camera together with "on" / "off" (or start / stop / enable / disable ...) is handled by the camera
feature itself, locally and instantly. It never reaches the language model, so a camera switch is never answered with a guess.

* intent(text)  -> "on" | "off" | "state" | None
* handle(text)  -> True when the sentence was handled here, None to let FRIDAY carry on exactly as before.

Look / describe requests ("what do you see on the camera", "describe my room") are NOT switches; they keep their existing routes.
"""
from __future__ import annotations

import re
from typing import Optional

_NOUN = re.compile(r"\b(?:camera|cameras|webcam|webcams|web cam|web cams|cam)\b")
_ON_WORDS = {"on", "start", "starts", "enable", "activate", "resume", "restart", "begin", "boot", "unmute"}
_OFF_WORDS = {"off", "stop", "disable", "deactivate", "shut", "shutdown", "close", "kill", "release", "pause", "halt", "terminate"}
_SWITCH_VERBS = {"turn", "switch", "power", "put", "bring", "get", "start", "stop", "enable", "disable", "activate", "deactivate",
                 "shut", "kill", "release", "close", "pause", "halt", "terminate", "resume", "restart", "begin", "boot", "keep", "leave"}
_LOOKISH = re.compile(r"\b(?:what|whats|who|whom|how many|how much|see|seeing|saw|look|looking|describe|show me|tell me|picture|photo|snapshot|"
                      r"record|recording|video|motion|changed|resolution|quality|why|detect|analy[sz]e|scan|read)\b")
_STATE_Q = re.compile(r"^\s*(?:friday[, ]+)?(?:hey[, ]+)?(?:is|are|was|were|does|did|has|have|do)\b|"
                      r"\b(?:tell me|let me know|check|confirm|status)\b.{0,25}\b(?:camera|webcam|cam)\b.{0,15}\b(?:on|off|running|working|active)\b|"
                      r"\b(?:camera|webcam|cam)\b.{0,10}\bstatus\b|\b(?:camera|webcam|cam)\s+(?:is|was)\s+(?:on|off)\b")
_NEGATION = re.compile(r"\b(?:don'?t|do not|dont|no need|not|never|without)\b")
_SPLIT = re.compile(r"\b(?:and then|and|then|but|also|while|so that|so)\b|[,;.]")


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9' ]+", " ", (text or "").lower())).strip()


def intent(text: str) -> Optional[str]:
    try:
        low = _clean(text)
        if not low or len(low.split()) > 28 or not _NOUN.search(low):
            return None
        words = low.split()
        has_switch_verb = any(w in _SWITCH_VERBS for w in words)
        has_onoff = any(w in _ON_WORDS or w in _OFF_WORDS for w in words)
        if not has_onoff:
            return None
        if _STATE_Q.search(low) and not re.search(r"\b(?:turn|switch|power|put|start|stop|enable|disable|activate|deactivate|shut|kill|release|close)\b", low):
            return "state"
        if _LOOKISH.search(low) and not has_switch_verb:
            return None                                   # "what's on my camera", "can you see me on camera" -> existing look/describe route
        # use the clause that talks about the camera ("turn on the camera and the screen vision off")
        raw = re.split(r"\b(?:and then|and|then|but|also|while|so that|so)\b", re.sub(r"[,;.]", " | ", (text or "").lower()))
        clause = ""
        for c in raw:
            for part in c.split("|"):
                cc = _clean(part)
                if cc and _NOUN.search(cc) and any(w in _ON_WORDS or w in _OFF_WORDS for w in cc.split()):
                    clause = cc
                    break
            if clause:
                break
        if not clause:
            clause = low
        toks = clause.split()
        direction = None
        for w in toks:                                    # the LAST on/off word decides: "switch the camera back on" -> on
            if w in _ON_WORDS:
                direction = "on"
            elif w in _OFF_WORDS:
                direction = "off"
        if direction is None:
            return None
        if direction == "on" and "on" in toks and not any(w in _SWITCH_VERBS or w == "on" for w in toks if w != "on") and len(toks) > 3:
            # a lone preposition "on" in a long sentence that has no switch verb is not a command
            if not re.search(r"\b(?:camera|webcam|cam)\s+on\b|\bon\s+(?:the\s+|my\s+|your\s+)?(?:camera|webcam|cam)\b", clause):
                return None
        if _NEGATION.search(clause):
            direction = "off" if direction == "on" else "on"
        return direction
    except Exception:
        return None


def _speak(text: str) -> None:
    try:
        import friday_vision_hub as hub
        hub._speak(text)
    except Exception:
        pass


def handle(text: str) -> Optional[bool]:
    which = intent(text)
    if which is None:
        return None
    try:
        import friday_vision_hub as hub
        if which == "state":
            import friday_vision_engine as ve
            on = bool(ve.SESSION.running and ve.SESSION.kind == "camera")
            hub._speak("Yes sir, the camera is on." if on else "No sir, the camera is off. Say turn on the camera when you want it.")
            return True
        if which == "off":
            hub.camera_off()
            return True
        hub.camera_on()
        return True
    except Exception as exc:                              # never block the normal route because of a camera error
        try:
            _speak(f"I could not switch the camera, sir. {str(exc)[:120]}")
            return True
        except Exception:
            return None
