# ============================================================
# FRIDAY BACKEND
# Python 3.13
# Gemini + Speech Recognition + Reliable Windows TTS
# + ADVANCED CAMBRIDGE STUDY MODE
# ------------------------------------------------------------
# NEURAL / SEMANTIC PROCESSING LAYER
# This file's "understand what was actually meant" logic runs in
# tiers, cheapest and most literal first, falling through to
# progressively smarter (and more expensive) checks only when needed:
#   1. Exact / near-exact text match (difflib) against known phrases
#      or saved contacts -- catches spelling-level near-misses.
#   2. Embedding-based semantic matching (Gemini's embedding model,
#      cosine similarity) -- catches matches by MEANING/SOUND rather
#      than spelling, e.g. "how chilly is it" ~ "how's the weather",
#      or "Jon" ~ "John". See _semantic_best_match (commands) and
#      _wa_semantic_best_contact (contact names).
#   3. Gemini itself as a full language-model fallback for anything
#      tiers 1-2 couldn't resolve (open-ended questions, phonetic
#      name cleanup, etc.).
# Every tier is wrapped so a failure (offline, bad key, model
# unavailable) just skips that tier silently -- Friday always still
# falls back to the tier below it rather than erroring out.
# ============================================================

import os
import re
import importlib
import importlib.util
import difflib
import json
import base64  # FIX: used by HEARD / ANSWER_PART / ASK:: / finance-sync lines (was never imported)
import datetime
import random
import webbrowser
import subprocess
import urllib.parse
import time
import sys
import threading
import queue
import faulthandler
import math
import collections
import platform
import ctypes
import wave
import shutil

# FRIDAY compatibility: all lazy FRIDAY feature modules resolve their backend globals
# to this single running module instead of importing a second backend instance.
sys.modules.setdefault("friday_backend", sys.modules[__name__])

# Reliability hardening: bounded retries, circuit breakers and atomic persistence.
try:
    from friday_reliability import run_resilient, atomic_json_save, load_json_recover, health_snapshot
except Exception:
    def run_resilient(name, fn, attempts=1, **kwargs): return fn()
    def atomic_json_save(path, data):
        with open(path, "w", encoding="utf-8") as f: json.dump(data, f, indent=4, ensure_ascii=False)
    def load_json_recover(path, default):
        try:
            with open(path, "r", encoding="utf-8") as f: return json.load(f)
        except Exception: return default
    def health_snapshot(): return {}

try:
    from friday_truth_verifier import snapshot as _truth_snapshot
except Exception:
    _truth_snapshot = None

# Peak-performance layer: telemetry and conservative duplicate protection.
try:
    import friday_peak_engine
except Exception:
    friday_peak_engine = None

# V2034 additive quality governor: observation only; existing execution paths stay intact.
try:
    import friday_quality_governor
except Exception:
    friday_quality_governor = None

# V2044: shared natural-language understanding (typo-tolerant message / open-app / search
# parsing) and the universal application launcher. Both are optional: if either fails to
# import, every legacy route below keeps working exactly as before.
try:
    import friday_nlu
except Exception:
    friday_nlu = None
# V4010: asynchronous autonomous initiative layer; never on the foreground critical path.
try:
    import friday_autonomous_reasoning
except Exception:
    friday_autonomous_reasoning = None

# V4010.10: movie-style executive cognition. Additive only; voice/listening/recognition are untouched.
try:
    import friday_movie_cognitive_engine
except Exception:
    friday_movie_cognitive_engine = None

# V4042 additive layers ported from the Jarvis autonomy build. These never touch
# the microphone, VAD, ASR/recognition, or TTS pipeline.
try:
    import friday_movie_agent
except Exception:
    friday_movie_agent = None
try:
    import friday_learning_engine
except Exception:
    friday_learning_engine = None
try:
    import friday_apex_intelligence
except Exception:
    friday_apex_intelligence = None

# ---- FRIDAY 5.0 layers (each optional: if one fails to import, the previous behaviour stays in place) ----
def _v5_import(_name):
    try:
        return importlib.import_module(_name)
    except Exception as _e5:
        print(f"FRIDAY_BOOT::V5_MODULE_UNAVAILABLE::{_name}::{_e5}", flush=True)
        return None
friday_voice5 = _v5_import("friday_voice5")
friday_speech5 = _v5_import("friday_speech5")
friday_core5 = _v5_import("friday_core5")
friday_knowledge5 = _v5_import("friday_knowledge5")
friday_router5 = _v5_import("friday_router5")
friday_tools5 = _v5_import("friday_tools5")
friday_attach5 = _v5_import("friday_attach5")
# ---- FRIDAY 6.0 layer (optional: if it fails to import, 5.0 behaviour stays exactly as it was) ----
friday_core6 = _v5_import("friday_core6")
# ---- FRIDAY 7.0 layer (optional, additive: if it fails to import, 6.x behaviour stays exactly as it was) ----
friday_core7 = _v5_import("friday_core7")

# V7.0: fast indexed file finder ("open <file name>"); optional - the old search stays as the fallback.
try:
    import friday_filesearch7
    if platform.system() == "Windows" and os.environ.get("FRIDAY_TESTING") != "1":
        friday_filesearch7.warm(delay=4.0)
except Exception:
    friday_filesearch7 = None

try:
    import friday_app_launcher
    if platform.system() == "Windows":
        # Build the installed-app index in the background so the first "open <app>" is instant.
        threading.Thread(target=friday_app_launcher.warm, name="FridayAppIndexWarm", daemon=True).start()
except Exception:
    friday_app_launcher = None

# V2045: Study Intelligence -- the shared brain behind "one FRIDAY, not two".
# Reads/writes the SAME study_memory/study_state dicts this file already owns;
# see friday_study_intelligence.py for the full explanation. Optional import
# so a missing/broken file degrades gracefully instead of breaking startup.
study_intel = None

# Which channel a command arrived on. The UI's typed-command channel sets kind="typed";
# spoken commands keep the default "voice". Typed text needs no speech-recognition
# suspicion (no "please spell that name" round trip).
_INPUT_SOURCE = threading.local()


def _is_typed_input():
    return getattr(_INPUT_SOURCE, "kind", "voice") == "typed"


# Only an explicit goodbye may end the assistant. handle_command() historically returned
# False from several ordinary handlers on failure (open_notepad, open_website, ...), which
# process_command() then mistook for "exit" and FRIDAY quit after any failed action.
_EXIT_REQUESTED = False


class _LazyModule:
    """Import a heavy/optional module only when one of its features is used."""
    def __init__(self, module_name):
        self._module_name = module_name
        self._module = None
        self._lock = threading.Lock()

    def _load(self):
        if self._module is None:
            with self._lock:
                if self._module is None:
                    self._module = importlib.import_module(self._module_name)
        return self._module

    def __getattr__(self, name):
        return getattr(self._load(), name)


# Keep the core microphone/HTTP libraries available immediately, but defer
# heavyweight feature modules until their first real use.
import speech_recognition as sr
import requests

# Optional neural/ML voice activity detector.  It is used only when installed;
# the adaptive RMS VAD remains the compatibility fallback.
try:
    import webrtcvad as _webrtcvad
except Exception:
    _webrtcvad = None

friday_agent_core = _LazyModule("friday_agent_core")
friday_voice_engine = _LazyModule("friday_voice_engine")
wikipedia = _LazyModule("wikipedia")

# pywhatkit is intentionally NOT imported here at module load time.
# It runs an internet-connectivity check the instant it's imported
# (pywhatkit.core.core.check_connection()), and if that check fails --
# a flaky wifi moment, a VPN/firewall/antivirus hiccup, anything --
# it raises and kills this entire process before the backend ever
# gets far enough to connect to the UI. That's what "Connection
# aborted" / "requests.exceptions.ConnectionError" during
# "import pywhatkit" means in the crash log: it's not a bug in this
# script, it's pywhatkit's own import-time check failing.
#
# Instead, pywhatkit is imported lazily inside the two functions that
# actually use it (search_google / play_youtube), each guarded by its
# own try/except with the existing webbrowser fallback. A bad network
# moment now only disables those two features for that one call
# instead of preventing Friday from starting at all.
def _import_pywhatkit():
    import pywhatkit
    return pywhatkit

from pathlib import Path
from urllib.parse import urlparse, urljoin
genai = _LazyModule("google.genai")
import sys
import io

# ------------------------------------------------------------
# NEW (this update): Web Research + Creation Engine modules.
# Kept as separate files on purpose (see the docstring at the top
# of each) so none of the logic above/below this line had to change.
# Both modules lazily "import friday_backend" *inside* their own
# functions, not at their top level, so this import here is safe
# and does not create a circular-import problem at startup.
# ------------------------------------------------------------
friday_web_research = _LazyModule("friday_web_research")
friday_youtube_research = _LazyModule("friday_youtube_research")
friday_creation_engine = _LazyModule("friday_creation_engine")

# ------------------------------------------------------------
# NEW (this update): Context Engine + Persona layer.
# friday_context.py builds proactive context (resolving "make it into
# slides" / "compare the prices" against whatever Friday just did) and
# the fluid long-term memory layer on TOP of the existing memory.json
# system -- it never replaces it. friday_persona.py just supplies
# varied phrasings for lines that used to be hardcoded, so Friday
# doesn't say the exact same greeting/acknowledgement every time.
# Both are additive, both degrade silently to today's exact behavior
# on any failure -- see each module's own docstring.
# ------------------------------------------------------------
friday_context = _LazyModule("friday_context")
friday_persona = _LazyModule("friday_persona")

# ------------------------------------------------------------
# NEW (this update): AI Notes Engine -- turns a topic (+ optional
# attached source material) or a set of photographed handwritten/
# printed notes into a polished, colour-coded PDF, saved into
# study_files/notes/<subject>/ and registered so the Notes tab can
# list and reopen it. See friday_notes_engine.py.
# ------------------------------------------------------------
friday_notes_engine = _LazyModule("friday_notes_engine")
friday_zoom_notes = _LazyModule("friday_zoom_notes")

# ------------------------------------------------------------
# NEW (this update): System Control -- REAL, verified app-closing and
# browser-tab-closing. See friday_system_control.py's module
# docstring for exactly why this had to exist: without it, "close X"
# commands silently fell through to ask_ai() (plain text chat, no
# tool access), which is why Friday used to confidently claim it had
# closed things it never touched.
# ------------------------------------------------------------
friday_system_control = _LazyModule("friday_system_control")

# Advanced agent orchestration layer: planner -> tools -> executor -> verifier -> recovery.
# Kept lazy so existing startup remains resilient when optional packages are absent.
friday_advanced_agent = _LazyModule("friday_advanced_agent")
friday_omni_engine = _LazyModule("friday_omni_engine")
# v96 unified runtime: shared event bus, task graph, tool contracts, security,
# multi-agent orchestration, vision/computer loop and diagnostics.
friday_v96_runtime = _LazyModule("friday_v96_runtime")
# V3095: unified 9.5+ gateway. Lazy-loaded so startup and the existing voice/listening/recognition path stay untouched.
friday_unified_gateway = _LazyModule("friday_unified_gateway")
# V2.3.0 OpenCV-5 vision + verifying agent (camera, screen, image/video analysis, SEE->THINK->ACT->CHECK->ADAPT, safety levels, evaluation).
# Lazy and additive: it only claims explicit vision / agent requests and never touches the listening, recognition or speech code.
friday_vision_hub = _LazyModule("friday_vision_hub")
# V2.3.1 CHAT ACCESS: lets the chat describe the camera like a person, open any page, add calendar events and know what is in
# Calendar / Memory / Tasks / Files. Lazy and additive: it only claims explicit requests and never touches listening or speech code.
friday_chat_access = _LazyModule("friday_chat_access")
friday_camera_gate = _LazyModule("friday_camera_gate")   # 7.0 update: camera on/off sentences never reach Gemini
# V7.5 AGENTIC VISION: see a problem on screen -> read it -> propose a fix -> ask -> act -> look again. Lazy; claims only explicit "fix the error on my screen" style
# requests and answers to its own question; every other sentence returns False in microseconds and flows on exactly as before.
friday_agentic_vision = _LazyModule("friday_agentic_vision")

# ============================================================
# FRIDAY EVENT STREAM
# ------------------------------------------------------------
# From the "behavioral intelligence" research: a live, timestamped
# feed of what Friday is actually doing (voice heard -> research
# started -> sources found -> diagram generated -> ...), printed as
# FRIDAY_EVENT:: markers app.js/widget.js can render as a HUD feed --
# "makes the UI and AI feel like one system rather than a webpage
# with a voice assistant attached." Deliberately just an in-memory
# ring buffer + a print() -- no new file, no new failure mode; if
# printing somehow fails the event is still kept in memory.
# ============================================================
_EVENT_LOG = collections.deque(maxlen=300)


def log_event(text, kind="info"):
    try:
        entry = {"ts": datetime.datetime.now().strftime("%H:%M:%S"), "text": text, "kind": kind}
        _EVENT_LOG.append(entry)
        print(f"FRIDAY_EVENT::{json.dumps(entry)}")
    except Exception as error:
        print("Event log error (ignored):", error)


# ============================================================
# SITUATIONAL AWARENESS (best-effort, Windows only)
# ------------------------------------------------------------
# From the same research: "FRIDAY should know what is happening on
# your computer" -- which application/window is currently focused.
# This is intentionally modest in scope: it reads the FOREGROUND
# WINDOW TITLE via ctypes (built into Python -- no new dependency),
# which is honest, cheap, and works without special permissions. It
# does NOT read window contents, screenshots, or any other app's
# data. On non-Windows platforms, or if anything about this fails,
# it simply returns None and every caller treats that as "unknown"
# rather than an error.
# ============================================================
_IS_WINDOWS = platform.system() == "Windows"


def get_active_window_title():
    """Best-effort current foreground window title, or None. Used to
    give ask_ai() a one-line hint of what the user is currently
    looking at, e.g. so "what do you think of this?" has SOME chance
    of resolving without the user re-explaining themselves -- exactly
    the "situational awareness" gap the research called out. This is
    deliberately shallow (a window title, not window contents) so it
    stays honest about what Friday can actually see."""
    if not _IS_WINDOWS:
        return None
    try:
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return None
        buffer = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buffer, length + 1)
        title = buffer.value.strip()
        return title or None
    except Exception:
        return None


_last_logged_window_title = None


def _maybe_log_window_change():
    """Called opportunistically (e.g. once per command) -- logs a
    Situational Awareness event only when the focused window actually
    changed, so this doesn't spam the event feed on every command
    while the user stays in the same app."""
    global _last_logged_window_title
    title = get_active_window_title()
    if title and title != _last_logged_window_title:
        _last_logged_window_title = title
        log_event(f"Active window: {title}", kind="awareness")


# Configure the existing Electron pipes in-place.
# Do NOT wrap sys.stdout/sys.stderr around their existing .buffer objects:
# doing so can let the old TextIOWrapper be garbage-collected and close the
# shared underlying pipe, causing "ValueError: I/O operation on closed file".
try:
    sys.stdout.reconfigure(
        encoding="utf-8",
        errors="replace",
        line_buffering=True,
        write_through=True,
    )
except Exception:
    pass

try:
    sys.stderr.reconfigure(
        encoding="utf-8",
        errors="replace",
        line_buffering=True,
        write_through=True,
    )
except Exception:
    pass
# line_buffering + write_through: without these, a freshly built
# TextIOWrapper defaults to block-buffering, which silently cancels
# out the "-u" (unbuffered) flag main.js launches this script with.
# Every print() would then sit in an internal buffer instead of
# reaching Electron right away -- the backend runs fine, it just
# never tells the UI anything until that buffer happens to fill up.
# That's what was making the UI's "Connection" field hang on
# "Connecting..." even when Friday was working normally underneath.

# Catches crashes that a normal try/except CANNOT catch -- segfaults,
# access violations, native-DLL crashes (the exact kind of thing that
# makes Python just vanish with no traceback). If Friday dies again,
# open friday_crash.log (created next to this script) -- it will contain
# the real Python-level traceback pointing at the line that was running
# the instant it died.
_CRASH_LOG = open("friday_crash.log", "w", buffering=1)
faulthandler.enable(file=_CRASH_LOG, all_threads=True)


# ============================================================
# SETTINGS
# ============================================================

# NAME and VOICE_RATE together aim for a brisk, calm, confident delivery
# similar to the fast conversational pacing you requested of the fictional "FRIDAY" -- measured pacing rather
# than a rushed default assistant voice. Lower VOICE_RATE a little
# further (e.g. 150-160) if you want it even more deliberate.
NAME = "Friday"

# HARD-LOCKED FRIDAY SPEAKING RATE
# One consistent delivery speed across every feature and mode.
FRIDAY_FIXED_VOICE_RATE = 185  # same speaking rate as JARVIS
VOICE_RATE = FRIDAY_FIXED_VOICE_RATE
os.environ["FRIDAY_VOICE_RATE"] = str(FRIDAY_FIXED_VOICE_RATE)

# HUMAN-VOICE LOCK (V3095.1): the natural Edge neural voice is selected
# explicitly in the TTS worker. This does not alter listening, recognition,
# VAD, pitch/tone logic, or the configured speaking rate.
VOICE_VOLUME = 1.0

# ------------------------------------------------------------
# TONE-AWARE DELIVERY
# ------------------------------------------------------------
# detect_user_tone() (defined near ask_ai) sets this before Friday
# speaks its reply. speak() nudges the TTS rate by a small, clamped
# amount based on it -- a little quicker for urgency, a little
# steadier/calmer for frustration -- instead of always speaking at
# one flat rate regardless of the moment. Never changes WHAT Friday
# says, only the pacing of how it's said.
_LAST_USER_TONE = "neutral"
# Emotional adaptation never changes speaking speed.
_TONE_RATE_DELTA = {"frustrated": 0, "urgent": 0, "neutral": 0}

def _configured_microphone_index():
    """Use Windows' default input unless the user explicitly selects one.

    Hard-coding device 1 makes FRIDAY silently listen to the wrong device on
    many laptops, USB headsets, and Bluetooth setups. An explicit environment
    override remains supported for users with a deliberate device choice.
    """
    raw = os.getenv("FRIDAY_MICROPHONE_INDEX", "").strip()
    if not raw:
        return None
    try:
        return int(raw)
    except ValueError:
        print("Invalid FRIDAY_MICROPHONE_INDEX; using the Windows default microphone.")
        return None


MICROPHONE_INDEX = _configured_microphone_index()
SPEECH_RECOGNITION_LANGUAGE = os.getenv("FRIDAY_SPEECH_LANGUAGE", "en-US").strip() or "en-US"

# Voice architecture controls. Voice mode uses the research-recommended
# idle -> wake -> full-STT flow by default. UI/typed commands still bypass the
# wake gate because they originate from an explicit user interface action.
# Voice session state:
#   STANDBY -> the microphone remains alive, but only a sentence containing
#              the standalone word "friday" can wake the assistant.
#   ACTIVE  -> subsequent utterances are treated as commands without needing
#              to repeat "friday". Saying "standby" returns to STANDBY.
# This is deliberately separate from the UI connection state.
# Voice conversation state:
#   STANDBY -> only a sentence containing the standalone word "friday" wakes Friday.
#   ACTIVE  -> every subsequent utterance is treated as a command/question and
#              does NOT require the wake word again.
#   "standby" / "stand by" returns to STANDBY immediately.
#
# This is deliberately separate from the optional legacy wake-word setting so
# there is no ambiguous "sometimes gated, sometimes ungated" behaviour.
WAKE_WORD_REQUIRED = True
WAKE_WORDS = ("hey friday", "okay friday", "ok friday", "friday")
VOICE_ACTIVE = False
VOICE_SESSION_STARTS_IN_STANDBY = os.getenv("FRIDAY_START_IN_STANDBY", "1").strip().lower() in {"1", "true", "yes", "on"}
STT_ENGINE = os.getenv("FRIDAY_STT_ENGINE", "hybrid").strip().lower()
# "hybrid" runs the existing cloud recognizer and local Faster-Whisper
# concurrently when the local model is already warm, then chooses using
# confidence + FRIDAY command evidence. If either engine is unavailable the
# other path is used unchanged.
# Accuracy-first recognition keeps the existing Google-first capture mechanism,
# but cross-checks ambiguous results with the local recognizer and semantic
# command matcher. Set to "balanced" to reduce verification work.
STT_ACCURACY_MODE = os.getenv("FRIDAY_STT_ACCURACY_MODE", "high").strip().lower()
# Fast recognition keeps the proven Google-first mechanism, but avoids
# expensive verification work on every clear utterance. Deep verification is
# reserved for transcripts that actually look uncertain.
STT_FAST_PATH = os.getenv("FRIDAY_STT_FAST_PATH", "1").strip().lower() in {"1", "true", "yes", "on"}
STT_DEEP_VERIFY_WORDS = int(os.getenv("FRIDAY_STT_DEEP_VERIFY_WORDS", "3"))
STT_DEEP_VERIFY_MAX_SECONDS = float(os.getenv("FRIDAY_STT_DEEP_VERIFY_MAX_SECONDS", "8.0"))
WAKE_ACKNOWLEDGEMENT = "Yes, sir."
MAX_SPEECH_SECONDS = float(os.getenv("FRIDAY_MAX_SPEECH_SECONDS", "30"))
TRAILING_SPEECH_BUFFER_SECONDS = float(os.getenv("FRIDAY_TRAILING_BUFFER_SECONDS", "0.65"))
RECOGNITION_RETRY_LIMIT = int(os.getenv("FRIDAY_RECOGNITION_RETRIES", "2"))
RECOGNITION_CONFIDENCE_THRESHOLD = float(os.getenv("FRIDAY_RECOGNITION_CONFIDENCE", "0.55"))
# Seconds of silence required AFTER speech has started before FRIDAY
# ends the microphone capture and sends the audio to speech recognition.
# Low-latency capture: wait indefinitely for speech to start, then finalize
# after a short continuous-silence window. The PCM VAD below remains the same
# proven capture mechanism; only its endpoint is tuned for conversational speed.
VAD_PAUSE_THRESHOLD = float(os.getenv("FRIDAY_VAD_PAUSE", "1.05"))
VAD_PHRASE_THRESHOLD = float(os.getenv("FRIDAY_VAD_PHRASE", "0.06"))
VAD_NON_SPEAKING_DURATION = float(os.getenv("FRIDAY_VAD_NON_SPEAKING", "0.22"))

# Advanced acoustic front-end controls. These do not remove any existing
# recognition path. WebRTC VAD supplies a second, speech-trained decision
# signal; RMS remains the fallback and a safety gate. A single laptop mic
# cannot perform true multi-microphone beamforming, so "far-field" support
# here means robust single-channel noise rejection and optional VAD fusion.
ADVANCED_VAD_ENABLED = os.getenv("FRIDAY_ADVANCED_VAD", "1").strip().lower() in {"1","true","yes","on"}
# Mode 0 = least aggressive filtering ("quality") = most sensitive to quiet/
# far-field speech; mode 3 = most aggressive = fewest false positives but can
# clip soft voices. Default lowered from 2 -> 1 for higher sensitivity while
# _speech_decision()'s RMS floor still guards against noise false-triggers.
WEBRTC_VAD_AGGRESSIVENESS = max(0, min(3, int(os.getenv("FRIDAY_WEBRTC_VAD_MODE", "1"))))
WEBRTC_VAD_MIN_RATIO = max(0.15, min(0.90, float(os.getenv("FRIDAY_WEBRTC_VAD_MIN_RATIO", "0.28"))))

# Print a per-stage timing breakdown for every utterance
# (capture / enhance / transcribe). Set FRIDAY_VOICE_DEBUG=1 to enable.
VOICE_TIMING_DEBUG = os.getenv("FRIDAY_VOICE_DEBUG", "0").strip().lower() in {"1", "true", "yes", "on"}
# Latency-first mode keeps expensive semantic memory/embedding work off the voice critical path.
VOICE_LATENCY_FIRST = os.getenv("FRIDAY_LATENCY_FIRST", "1").strip().lower() in {"1", "true", "yes", "on"}

# How long FRIDAY waits for speech to START. This is deliberately unlimited.
# FRIDAY must NOT interpret the post-speech silence rule as an overall
# listening timeout. Once speech starts, capture ends only after
# VAD_PAUSE_THRESHOLD seconds of continuous silence.
# Do NOT stop waiting merely because 10 seconds passed before the user speaks.
# None means wait indefinitely for the first detected speech. The 10-second
# silence rule applies only AFTER speech has started (VAD_PAUSE_THRESHOLD).
LISTEN_TIMEOUT_SECONDS = None

# How long FRIDAY waits AFTER YOU STOP SPEAKING before ending the capture.
# This is the ONLY automatic end condition for an utterance.
#   - LISTEN_TIMEOUT_SECONDS = None -> wait indefinitely for first speech
#   - VAD_PAUSE_THRESHOLD = 10.0s by default -> do not cut the user off during natural pauses
#   - PHRASE_TIME_LIMIT_SECONDS = None -> no arbitrary command-length cutoff
# This prevents FRIDAY from cutting off normal human speech or long commands.
# No phrase-duration ceiling: a long human sentence/lecture command is allowed
# to continue. Capture ends only after VAD_PAUSE_THRESHOLD seconds of silence.
PHRASE_TIME_LIMIT_SECONDS = None

_UI_CONNECTED = False

MEMORY_FILE = Path("memory.json")
STUDY_MEMORY_FILE = Path("study_memory.json")
STUDY_STATE_FILE = Path("study_state.json")
STUDY_FILES_DIR = Path("study_files")
STUDY_FILES_DIR.mkdir(exist_ok=True)
CONTACTS_FILE = Path("contacts.json")


# ============================================================
# GEMINI
# ============================================================
# No .env file is used any more -- it kept going wrong on Windows
# (hidden ".env.txt" extensions, a system environment variable
# silently blocking the file from loading). There's exactly one place
# to put your key now: GEMINI_API_KEY_INLINE_FALLBACK, right below.

# ---- Paste your key on the line below, between the quotes ----
# IMPORTANT: once you fill this in, this file contains your real key.
# Don't upload, share, or paste this file anywhere with the key still
# in it -- treat it exactly like a password. If you ever need to share
# this file (e.g. for a bug report), blank this line out first.
GEMINI_API_KEY_INLINE_FALLBACK = ""  # e.g. "AIzaSyABC123yourRealKeyHere"

# A GEMINI_API_KEY/GOOGLE_API_KEY environment variable, if one happens
# to already be set system-wide, is still honoured automatically and
# takes priority over the line above -- most people can ignore this.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()

client = None
_gemini_client_init_attempted = False
_gemini_client_key = ""
_RUNTIME_GEMINI_API_KEY = ""
_ATTACHED_CONTEXT = []

# Human-readable reason the AI brain is unavailable, refreshed on every
# _ensure_gemini_client() call. Lets callers (ask_ai, the diagnostics
# command, etc.) tell the user something more accurate than "not
# configured" when the real cause is e.g. an invalid key or a network/
# library error rather than a missing key.
GEMINI_STATUS_REASON = "not_checked_yet"
_gemini_last_init_failure_at = 0.0
_GEMINI_INIT_RETRY_SECONDS = 5.0


def _clean_api_key(raw):
    """Tolerant key cleaner: a key pasted with quotes, spaces, a line break,
    "key=" or "Bearer " in front still works instead of failing silently."""
    key = str(raw or "").replace("\r", " ").replace("\n", " ").strip()
    if not key:
        return ""
    found = re.search(r"AIza[0-9A-Za-z_\-]{30,}", key)
    if found:
        return found.group(0)
    key = key.strip("\"'`").strip()
    for prefix in ("key=", "api_key=", "gemini_api_key=", "google_api_key=", "bearer "):
        if key.lower().startswith(prefix):
            key = key[len(prefix):].strip().strip("\"'`").strip()
    parts = key.split()
    return parts[0] if parts else ""


def _resolve_gemini_key():
    """
    Figure out the actual Gemini/Google API key to use, and *why*.
    Checks an environment variable first (for anyone who happens to
    have one set), then the GEMINI_API_KEY_INLINE_FALLBACK constant
    above -- no .env file involved anywhere. Returns (key, source).
    """
    if _clean_api_key(_RUNTIME_GEMINI_API_KEY):
        return _clean_api_key(_RUNTIME_GEMINI_API_KEY), "FRIDAY Settings (encrypted local app storage)"
    for var_name in ("GEMINI_API_KEY", "GOOGLE_API_KEY"):
        env_val = _clean_api_key(os.getenv(var_name, ""))
        if env_val:
            return env_val, f"process environment variable {var_name}"
    inline = _clean_api_key(GEMINI_API_KEY_INLINE_FALLBACK)
    if inline and inline != "AIzaSyABC123yourRealKeyHere":
        return inline, "GEMINI_API_KEY_INLINE_FALLBACK in friday_backend.py"
    return "", f"GEMINI_API_KEY_INLINE_FALLBACK in {Path(__file__).name} is still empty"


def _ensure_gemini_client():
    """
    Build the Gemini client lazily, on first actual use, instead of at
    import time. Client construction shouldn't normally touch the
    network -- but this project already hit exactly this failure mode
    once before (pywhatkit's import-time internet check killing the
    whole process), on a machine where antivirus/firewall software is
    known to interfere with outbound connections (see the earlier
    ConnectionAbortedError). Any blocking call before Friday's first
    print delays the UI's "Connecting..." status indefinitely. Making
    this lazy removes it from the list of suspects entirely, and means
    a slow/blocked network only affects the AI brain when it's
    actually asked a question, not Friday's ability to start at all.
    """
    global client, _gemini_client_init_attempted, _gemini_client_key, GEMINI_API_KEY, GEMINI_STATUS_REASON, _gemini_last_init_failure_at
    current_key, key_source = _resolve_gemini_key()
    GEMINI_API_KEY = current_key
    # Also publish the resolved key to the process environment so any
    # other module that reads os.getenv("GEMINI_API_KEY") directly
    # (friday_gemini_computer_use.py, etc.) sees the same key this
    # module resolved, including when it came from the inline fallback
    # rather than an actual environment variable.
    if current_key:
        os.environ["GEMINI_API_KEY"] = current_key
    if not current_key:
        client = None
        _gemini_client_init_attempted = False
        GEMINI_STATUS_REASON = f"no_key: {key_source}"
        print(f"WARNING: GEMINI_API_KEY/GOOGLE_API_KEY is missing. The AI brain is unavailable. ({key_source})")
        print(f"Paste your key into GEMINI_API_KEY_INLINE_FALLBACK near the top of {Path(__file__).name}.")
        return
    # If the key became available/changed after startup, allow recovery instead
    # of permanently caching the earlier 'missing key' state.
    if client is not None and _gemini_client_key == current_key:
        GEMINI_STATUS_REASON = "ready"
        return
    if _gemini_client_init_attempted and _gemini_client_key == current_key:
        # Never permanently cache a transient constructor failure.  A blocked
        # network, DNS hiccup, proxy restart, or temporary SDK failure during
        # startup used to leave FRIDAY saying "AI brain unavailable" forever
        # until the whole application was restarted.
        if (time.monotonic() - _gemini_last_init_failure_at) < _GEMINI_INIT_RETRY_SECONDS:
            return
    _gemini_client_init_attempted = True
    _gemini_client_key = current_key
    try:
        client = genai.Client(api_key=current_key)
        _gemini_last_init_failure_at = 0.0
        GEMINI_STATUS_REASON = "ready"
        print(f"GEMINI_STATUS::CLIENT_READY (key from {key_source}, {len(current_key)} chars)", flush=True)
    except Exception as error:
        client = None
        _gemini_last_init_failure_at = time.monotonic()
        GEMINI_STATUS_REASON = f"init_error: {error} (key was read from {key_source})"
        print("GEMINI_STATUS::CLIENT_ERROR", flush=True)
        print(f"Gemini client initialization error (key from {key_source}); will retry automatically:", error)

# Current Gemini model used by the study system and normal AI brain.
# Gemini 3.8 Flash is the current stable Flash model used by this build.
# It supports multimodal input and computer use. The model can be overridden
# with FRIDAY_GEMINI_MODEL when a different supported model is required.
GEMINI_MODEL = os.getenv("FRIDAY_GEMINI_MODEL", "gemini-3.1-flash-lite").strip() or "gemini-3.1-flash-lite"

# Used only for the optional semantic (embedding-based) command
# re-ranking in _recognize_best_match, and the tone classifier escalation
# in detect_user_tone -- both fall back gracefully (silently) to their
# existing non-neural behavior if this model/call ever fails.
EMBEDDING_MODEL = "gemini-embedding-001"


# ============================================================
# WEATHER
# ============================================================
# Open-Meteo (https://open-meteo.com) needs no API key and no signup,
# which is why it's used here instead of a keyed service like
# OpenWeatherMap -- one less secret to manage or leak. Coordinates are
# for Wattala, Alwis Town, Sri Lanka; update these two numbers (and
# WEATHER_LOCATION_NAME) if Friday ever needs to report on a different
# location.
WEATHER_LATITUDE = 6.9891
WEATHER_LONGITUDE = 79.8994
WEATHER_LOCATION_NAME = "Wattala, Sri Lanka"

# WMO weather codes -> plain-English condition, per Open-Meteo's docs.
_WMO_WEATHER_DESCRIPTIONS = {
    0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "foggy", 48: "foggy with rime",
    51: "light drizzle", 53: "moderate drizzle", 55: "dense drizzle",
    56: "light freezing drizzle", 57: "dense freezing drizzle",
    61: "light rain", 63: "moderate rain", 65: "heavy rain",
    66: "light freezing rain", 67: "heavy freezing rain",
    71: "light snow", 73: "moderate snow", 75: "heavy snow", 77: "snow grains",
    80: "light rain showers", 81: "moderate rain showers", 82: "violent rain showers",
    85: "light snow showers", 86: "heavy snow showers",
    95: "a thunderstorm", 96: "a thunderstorm with light hail", 99: "a thunderstorm with heavy hail",
}



# V2045 FIX: get_weather() previously ALWAYS reported WEATHER_LOCATION_NAME
# no matter what the user asked for, because it silently ignored its own
# `command` argument -- "weather in Tokyo" and "weather in Wattala" produced
# the identical answer. _extract_weather_location() + _geocode_location()
# below actually read the place name out of the request and look up real
# coordinates for it (via Open-Meteo's free geocoding endpoint -- no API
# key, same provider already used for the forecast itself); the hardcoded
# WEATHER_LATITUDE/LONGITUDE constants are now only the DEFAULT used when
# no place is named, exactly as their comment always said they should be.
_WEATHER_GEOCODE_CACHE = {}

_WEATHER_LOCATION_FILLER_WORDS = (
    "right now", "today", "currently", "please", "sir", "outside",
    "at the moment", "just now", "over there", "for me",
)


def _extract_weather_location(command):
    """Pulls a place name out of a spoken/typed weather request.
    Returns None when no location was named, so callers fall back to
    the configured home location."""
    command = (command or "").strip()
    if not command:
        return None
    patterns = [
        r"\bweather\s*(?:report|update|forecast)?\s+(?:like\s+)?(?:in|at|for|of)\s+([A-Za-z][A-Za-z\s,.'\-]{1,60})",
        r"\btemperature\s+(?:in|at|for|of)\s+([A-Za-z][A-Za-z\s,.'\-]{1,60})",
        r"\b(?:in|at|for)\s+([A-Za-z][A-Za-z\s,.'\-]{1,60})\s+(?:weather|temperature|forecast)\b",
        r"\bhow(?:'s| is) (?:the )?weather\s+(?:in|at|for|of)\s+([A-Za-z][A-Za-z\s,.'\-]{1,60})",
    ]
    loc = None
    for pattern in patterns:
        m = re.search(pattern, command, re.I)
        if m:
            loc = m.group(1).strip(" ?.!,")
            break
    if not loc:
        return None
    for filler in _WEATHER_LOCATION_FILLER_WORDS:
        loc = re.sub(r"\b" + re.escape(filler) + r"\b", "", loc, flags=re.I).strip(" ,.")
    loc = re.sub(r"\s+", " ", loc).strip(" ,.")
    return loc or None


def _geocode_location(name):
    """Resolves a free-text place name to coordinates via Open-Meteo's
    geocoding API. Returns None if nothing matched (never raises --
    callers treat None as 'ask the user to clarify', not an error)."""
    cache_key = name.strip().lower()
    if cache_key in _WEATHER_GEOCODE_CACHE:
        return _WEATHER_GEOCODE_CACHE[cache_key]
    try:
        response = requests.get(
            "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": name, "count": 1, "language": "en", "format": "json"},
            timeout=10,
        )
        response.raise_for_status()
        results = response.json().get("results") or []
    except Exception as error:
        print("Weather geocoding lookup failed:", error)
        return None
    if not results:
        _WEATHER_GEOCODE_CACHE[cache_key] = None
        return None
    top = results[0]
    label_parts = [top.get("name")]
    if top.get("admin1") and top.get("admin1") != top.get("name"):
        label_parts.append(top["admin1"])
    if top.get("country"):
        label_parts.append(top["country"])
    resolved = {
        "latitude": top["latitude"],
        "longitude": top["longitude"],
        "label": ", ".join(p for p in label_parts if p) or name,
        "timezone": top.get("timezone") or "auto",
    }
    _WEATHER_GEOCODE_CACHE[cache_key] = resolved
    return resolved


def _fetch_weather_data(latitude=None, longitude=None, location_name=None, timezone=None):
    """
    Shared Open-Meteo lookup used both by get_weather() (spoken reply
    to "what's the weather") and by the periodic header push below.
    Returns a plain dict; raises on any failure so each caller decides
    how to handle it (speak an error vs. just skip that header update).
    Defaults to the configured home location when no coordinates are
    given, but ANY resolved lat/lon (e.g. from _geocode_location) can
    be passed in to report on a different place.
    """
    response = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": WEATHER_LATITUDE if latitude is None else latitude,
            "longitude": WEATHER_LONGITUDE if longitude is None else longitude,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m",
            "timezone": timezone or "auto",
        },
        timeout=10,
    )
    response.raise_for_status()
    current = response.json().get("current", {})
    temperature = current.get("temperature_2m")
    if temperature is None:
        raise ValueError("Open-Meteo response had no current temperature.")

    return {
        "temperature": temperature,
        "feels_like": current.get("apparent_temperature"),
        "humidity": current.get("relative_humidity_2m"),
        "wind_speed": current.get("wind_speed_10m"),
        "condition": _WMO_WEATHER_DESCRIPTIONS.get(current.get("weather_code"), "changeable conditions"),
        "location": location_name or WEATHER_LOCATION_NAME,
    }


def push_weather_update():
    """
    Prints a WEATHER_DATA::<json> line the UI's header reads to show a
    persistent live temperature + location (matching the reference
    design) instead of the old "tap to check" placeholder. Silently
    skips on failure -- the header just keeps whatever it last showed,
    same "don't crash Friday over a flaky network call" spirit as
    everything else network-related in this file.
    """
    try:
        data = _fetch_weather_data()
        print("WEATHER_DATA::" + json.dumps({
            "temperature": round(data["temperature"]),
            "condition": data["condition"],
            "location": data["location"],
        }))
    except Exception as error:
        print("Weather header push skipped:", error)


def _weather_push_loop():
    while True:
        push_weather_update()
        time.sleep(900)  # 15 minutes


def get_weather(command=""):
    """
    Real current-conditions lookup. Defaults to WEATHER_LOCATION_NAME,
    but actually reads a place name out of `command` first (V2045 fix
    -- this used to be silently ignored, so every request answered
    with the home-location weather no matter what city/country was
    asked about). No API key required for either the forecast or the
    geocoding lookup. Any failure (offline, DNS blocked, service down,
    unrecognized place name) speaks a clear message instead of
    guessing or letting Gemini improvise a fake forecast.
    """
    try:
        latitude = longitude = timezone = None
        location_label = WEATHER_LOCATION_NAME
        place_name = _extract_weather_location(command)
        if place_name:
            geo = _geocode_location(place_name)
            if geo is None:
                speak(f"I couldn't find a place called {place_name}, sir. Could you check the spelling or be more specific?")
                return True
            latitude, longitude, location_label, timezone = geo["latitude"], geo["longitude"], geo["label"], geo["timezone"]

        data = _fetch_weather_data(latitude=latitude, longitude=longitude, location_name=location_label, timezone=timezone)
        temperature = data["temperature"]
        feels_like = data["feels_like"]
        humidity = data["humidity"]
        wind_speed = data["wind_speed"]
        condition = data["condition"]

        parts = [f"It's currently {condition} in {data['location']}, {round(temperature)} degrees celsius"]
        if feels_like is not None and round(feels_like) != round(temperature):
            parts.append(f"feels like {round(feels_like)}")
        if humidity is not None:
            parts.append(f"{round(humidity)} percent humidity")
        if wind_speed is not None:
            parts.append(f"wind around {round(wind_speed)} kilometers per hour")

        speak(", ".join(parts) + ".")
        return True
    except Exception as error:
        print("Weather lookup error:", error)
        speak("I couldn't reach the weather service just now. Please check the internet connection and try again.")
        return True


# ============================================================
# MEMORY
# ============================================================

def load_memory():
    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
        if isinstance(data, list):
            return data
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return []


def save_memory(memory):
    try:
        with open(MEMORY_FILE, "w", encoding="utf-8") as file:
            json.dump(memory, file, indent=4, ensure_ascii=False)
    except OSError as error:
        print("Memory save error:", error)


memory = load_memory()


# ============================================================
# TEXT TO SPEECH
# ============================================================

_TTS_LOCK = threading.RLock()
_TTS_ACTIVE = False
# V2.2.8: several replies can be queued at once (typed + voice + status lines). A plain
# True/False flag let the FIRST reply to finish switch "speaking" off (and re-open the mic /
# send SPEAK_END) while the next one was still talking. A depth counter keeps the speaking
# state, the mic gate and the UI status in sync until the LAST queued reply has finished.
_TTS_DEPTH = 0
_TTS_DEPTH_LOCK = threading.Lock()
_TTS_LAST_END = 0.0
_TTS_ECHO_TAIL_SECONDS = 0.45   # room echo that is still ringing just after she stops


def is_tts_active():
    return bool(_TTS_ACTIVE)


def _mic_should_stay_deaf():
    """True while FRIDAY is talking (plus a short echo tail) so her own voice is never recognised."""
    return bool(_TTS_ACTIVE) or (time.time() - _TTS_LAST_END) < _TTS_ECHO_TAIL_SECONDS


def make_math_speakable(text):
    text = str(text)
    replacements = {
        r"\times": " times ", r"\cdot": " times ", r"\div": " divided by ",
        r"\pm": " plus or minus ", r"\approx": " approximately ",
        r"\neq": " not equal to ", r"\leq": " less than or equal to ",
        r"\geq": " greater than or equal to ", r"\sqrt": " square root of ",
        r"\infty": " infinity ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"(\d+(?:\.\d+)?)\s*\^\s*\{([^{}]+)\}", r"\1 raised to the power of \2", text)
    text = re.sub(r"(\d+(?:\.\d+)?)\s*\^\s*([A-Za-z0-9.+-]+)", r"\1 raised to the power of \2", text)
    text = text.replace("$", "")
    text = text.replace(r"\(", "").replace(r"\)", "")
    text = text.replace(r"\[", "").replace(r"\]", "")
    text = text.replace("{", "").replace("}", "")
    # V2045 FIX: the previous blind text.replace("**", ...) also fired on
    # ordinary Markdown BOLD text (e.g. "This is **important** because...",
    # which Gemini outputs constantly), making Friday say nonsense like
    # "...important raised to the power of because...". A real Python-style
    # exponent ("2**3", "x**y") always has NO surrounding whitespace, while
    # Markdown bold's "**" always sits next to a space or punctuation on at
    # least one side -- so only convert the former. Markdown "**" left over
    # is removed a few lines later in _prepare_for_natural_speech().
    text = re.sub(r"(?<=[\w.])\*\*(?=[\w.])", " raised to the power of ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


# Website names used only by the speech/presentation layer. The real URL
# remains untouched everywhere else in FRIDAY, so browser actions and logs keep
# their exact machine-readable targets.
_SPOKEN_WEBSITE_NAMES = {
    "google.com": "Google", "youtube.com": "YouTube", "youtu.be": "YouTube",
    "gmail.com": "Gmail", "mail.google.com": "Gmail", "chatgpt.com": "ChatGPT",
    "openai.com": "OpenAI", "github.com": "GitHub", "stackoverflow.com": "Stack Overflow",
    "wikipedia.org": "Wikipedia", "reddit.com": "Reddit", "instagram.com": "Instagram",
    "facebook.com": "Facebook", "x.com": "X", "twitter.com": "X",
    "linkedin.com": "LinkedIn", "discord.com": "Discord", "web.telegram.org": "Telegram",
    "telegram.org": "Telegram", "slack.com": "Slack", "teams.microsoft.com": "Microsoft Teams",
    "microsoft.com": "Microsoft", "zoom.us": "Zoom", "notion.so": "Notion",
    "figma.com": "Figma", "canva.com": "Canva", "netflix.com": "Netflix",
    "amazon.com": "Amazon", "spotify.com": "Spotify", "open.spotify.com": "Spotify",
    "twitch.tv": "Twitch", "tiktok.com": "TikTok", "ebay.com": "eBay",
    "pinterest.com": "Pinterest", "maps.google.com": "Google Maps",
    "drive.google.com": "Google Drive", "docs.google.com": "Google Docs",
    "sheets.google.com": "Google Sheets", "slides.google.com": "Google Slides",
    "translate.google.com": "Google Translate", "calendar.google.com": "Google Calendar",
    "meet.google.com": "Google Meet", "classroom.google.com": "Google Classroom",
    "open-meteo.com": "Open-Meteo",
}

def _spoken_website_name(raw_url):
    """Turn a URL into a human website name without changing the actual URL."""
    raw = str(raw_url or "").strip().rstrip(".,;:!?)]}>")
    try:
        from urllib.parse import urlparse
        candidate = raw if re.match(r"^[a-z][a-z0-9+.-]*://", raw, re.I) else "https://" + raw
        host = (urlparse(candidate).hostname or "").lower().rstrip(".")
        if not host:
            return "the website"
        # Prefer the most specific known host first.
        if host in _SPOKEN_WEBSITE_NAMES:
            return _SPOKEN_WEBSITE_NAMES[host]
        for domain, name in sorted(_SPOKEN_WEBSITE_NAMES.items(), key=lambda x: -len(x[0])):
            if host == domain or host.endswith("." + domain):
                return name
        # Natural fallback: use the registrable-looking hostname without
        # protocol, path, query, or a literal "www".
        parts = host.split(".")
        if parts and parts[0] == "www":
            parts = parts[1:]
        label = parts[-2] if len(parts) >= 2 else parts[0]
        return label.replace("-", " ").title() + " website"
    except Exception:
        return "the website"


def _spoken_file_location(raw_path):
    """Return only the human-facing filename for a filesystem path.

    This is a TTS presentation transform only.  The real path/filename used by
    FRIDAY is never changed.  A person normally says "Chemistry Notes" rather
    than reading ``C:\\Users\\...\\Chemistry Notes.pdf`` character by character.
    """
    raw = raw_path.group(0) if hasattr(raw_path, "group") else str(raw_path or "")
    raw = raw.strip().rstrip(".,;:!?)]}>")
    parts = [x for x in re.split(r"[\\/]+", raw) if x]
    if not parts:
        return raw
    filename = parts[-1]
    stem, ext = __import__("os").path.splitext(filename)
    # Speak the filename itself.  Extensions are deliberately omitted for
    # ordinary human conversation; FRIDAY can still mention the type elsewhere
    # when the context actually requires it.
    return stem if ext else filename


def _spoken_website_name(raw_url):
    """Turn a URL/domain into its recognizable human name for TTS only."""
    raw = str(raw_url or "").strip().rstrip(".,;:!?)]}>")
    try:
        from urllib.parse import urlparse
        candidate = raw if re.match(r"^[a-z][a-z0-9+.-]*://", raw, re.I) else "https://" + raw
        host = (urlparse(candidate).hostname or "").lower().rstrip(".")
        if not host:
            return raw
        if host in _SPOKEN_WEBSITE_NAMES:
            return _SPOKEN_WEBSITE_NAMES[host]
        for domain, name in sorted(_SPOKEN_WEBSITE_NAMES.items(), key=lambda x: -len(x[0])):
            if host == domain or host.endswith("." + domain):
                return name
        labels = [x for x in host.split(".") if x and x != "www"]
        if not labels:
            return "the website"
        return labels[-2].replace("-", " ").title() if len(labels) >= 2 else labels[0].replace("-", " ").title()
    except Exception:
        return raw


def _prepare_for_natural_speech(text):
    """Make *all* machine-formatted output sound like natural conversation.

    This is strictly a TTS-layer transform.  It never modifies UI text, actual
    URLs, filesystem paths, commands, filenames, or internal data.
    """
    text = str(text)
    text = re.sub(r"```.*?```", " ", text, flags=re.S)

    # Markdown links: speak the visible label, not the URL machinery.
    text = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", lambda m: m.group(1).strip(), text, flags=re.I)
    text = re.sub(r"(?:https?://|www\.)[^\s<>]+", lambda m: _spoken_website_name(m.group(0)), text, flags=re.I)

    # Full Windows/relative paths -> filename only.
    path_pattern = r"(?<![A-Za-z0-9])(?:[A-Za-z]:[\\/]|(?:Downloads|Desktop|Documents|Pictures|Videos|Music)[\\/])[^<>\r\n\s]*?(?:\s[^<>\r\n]*?)?\.[A-Za-z0-9]{1,10}(?=(?:[.,;:!?)](?:\s|$)|\s|$))"
    text = re.sub(path_pattern, _spoken_file_location, text, flags=re.I)

    # Bare filenames.  Include common extensions and preserve the filename stem
    # exactly enough for natural speech (underscores/camelCase are normalized below).
    ext_names = (
        "pdf|docx?|xlsx?|pptx?|txt|rtf|csv|pyw?|js|ts|jsx|tsx|html?|css|json|xml|md|"
        "zip|rar|7z|exe|msi|bat|cmd|jpe?g|png|webp|gif|mp3|wav|mp4|mkv|avi"
    )
    def bare_file(m):
        stem = m.group(1).strip()
        if not stem or stem[-1] in ".!?":
            return m.group(0)
        return stem
    text = re.sub(
        rf"(?<![A-Za-z0-9_./\\])([A-Za-z0-9][A-Za-z0-9 _()\[\]{{}}+&'@#%,-]*?)\.({ext_names})\b",
        bare_file, text, flags=re.I)

    # Email addresses: human speech uses "at" and "dot".
    def spoken_email(m):
        value = m.group(0).strip().rstrip(".,;:!?)]}")
        local, domain = value.split("@", 1)
        local = re.sub(r"[_-]+", " ", local)
        domain = " dot ".join(x.replace("-", " ") for x in domain.split(".") if x)
        return f"{local} at {domain}"
    text = re.sub(r"(?<![\w.+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![\w.-])", spoken_email, text)

    # Remaining domain names without protocol.
    text = re.sub(
        r"(?<![@A-Za-z0-9._-])(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?![A-Za-z0-9._-])",
        lambda m: _spoken_website_name(m.group(0)), text, flags=re.I)

    # Machine identifiers -> words: friday_backend -> friday backend;
    # WhatsAppCallManager -> WhatsApp Call Manager.
    def spoken_identifier(m):
        token = m.group(0)
        spoken = re.sub(r"[_-]+", " ", token)
        spoken = re.sub(r"([a-z])([A-Z])", r"\1 \2", spoken)
        spoken = re.sub(r"([A-Za-z])([0-9])", r"\1 \2", spoken)
        spoken = re.sub(r"([0-9])([A-Za-z])", r"\1 \2", spoken)
        return spoken
    text = re.sub(
        r"(?<![A-Za-z0-9])(?=[A-Za-z0-9_-]*[_-][A-Za-z0-9_-]*)([A-Za-z][A-Za-z0-9_-]{2,})(?![A-Za-z0-9])",
        spoken_identifier, text)
    # CamelCase technical/app names are also machine-shaped even without an
    # underscore: WhatsAppCallManager -> WhatsApp Call Manager.
    text = re.sub(r"(?<![A-Za-z0-9])([A-Z]?[a-z]+)([A-Z][a-z]+)+(?=$|[^A-Za-z0-9])",
                  lambda m: re.sub(r"([a-z])([A-Z])", r"\1 \2", m.group(0)), text)

    # Conversational symbols.
    for symbol, spoken in {
        "&": " and ", "→": " to ", "->": " to ", "←": " from ",
        "≤": " less than or equal to ", "≥": " greater than or equal to ",
        "≠": " not equal to ", "≈": " approximately ", "×": " times ",
    }.items():
        text = text.replace(symbol, spoken)

    # Technical terms: use natural names, but don't force every acronym into
    # artificial letter-by-letter speech.  These are only pronunciation hints.
    tech_terms = {
        "API": "A P I", "AI": "A I", "UI": "U I", "UX": "U X",
        "URL": "U R L", "HTTP": "H T T P", "HTTPS": "H T T P S",
        "HTML": "H T M L", "CSS": "C S S", "JSON": "J S O N",
        "XML": "X M L", "SQL": "S Q L",
    }
    for term, spoken in tech_terms.items():
        text = re.sub(rf"(?<![A-Za-z0-9]){re.escape(term)}(?![A-Za-z0-9])", spoken, text)

    text = re.sub(r"[*_~`#]+", "", text)
    text = re.sub(r"\band/or\b", "and or", text, flags=re.I)
    text = re.sub(r"(?<![A-Za-z0-9.:/\\])([A-Za-z][\w-]*)\s*/\s*([A-Za-z][\w-]*)(?![/\\])", r"\1 or \2", text)
    text = re.sub(r"\r?\n+", ". ", text)
    text = re.sub(r"(\d+(?:\.\d+)?)\s*%", r"\1 percent", text)
    text = re.sub(r"\s*[-–—]\s*", ", ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text.rstrip(".") + "." if text else ""


# Primary engine: Windows System.Speech. SpeechSynthesizer.Speak() is
# synchronous and does not return until the COMPLETE response is spoken.
_TTS_EDGE_WORKER_SOURCE = r'''
import asyncio, sys, os

async def _main():
    try:
        import edge_tts
    except Exception as exc:
        print(f"EDGE_TTS_UNAVAILABLE: {exc}", file=sys.stderr)
        raise SystemExit(2)
    text = sys.stdin.read().strip()
    if not text:
        return
    voice = os.getenv("FRIDAY_EDGE_VOICE", os.getenv("FRIDAY_EDGE_VOICE", "en-US-AriaNeural"))  # HARD-LOCKED V3096 human neural voice
    rate = int(os.getenv("FRIDAY_EDGE_RATE", "0"))
    rate_text = f"{rate:+d}%"
    communicate = edge_tts.Communicate(text, voice=voice, rate=rate_text, volume="+0%", pitch="+0Hz")
    await communicate.save(os.environ["FRIDAY_EDGE_OUTPUT"])

asyncio.run(_main())
'''

# Shared voice-selection logic, embedded identically into EVERY SAPI-based
# TTS code path (the one-shot worker below, the persistent resident worker,
# and the pyttsx3 fallback). Previously only the one-shot path selected a
# voice at all -- the persistent resident process (which is what actually
# speaks almost every reply, since it is tried first in speak()) never
# called SelectVoice(), so FRIDAY silently spoke in whatever voice Windows
# defaults to (often the female "Zira") no matter what was configured. That
# was the "voice keeps changing back to the old voice" bug: it never
# actually applied the deep/human voice preference in the first place, on
# the path that matters most. Fixed by giving every path the exact same
# selection logic below.
#
# Preference order favours a deep, human-sounding MALE voice: "David" is a
# deep bass American male voice installed on effectively every Windows
# machine, so it is the reliable default; George/Ryan/Guy/Mark are deeper
# British/US alternatives used automatically when the optional UK English
# language pack happens to be installed. "Zira" (female, higher-pitched) is
# never auto-preferred. If somehow none of the named voices are installed,
# FRIDAY still prefers any remaining MALE voice over whatever the Windows
# default happens to be, so the deep/human requirement holds even on an
# unusual voice set, rather than silently reverting to a default voice.
_TTS_VOICE_SELECT_PS = r'''
    $fridayVoiceNames = @('Ryan')
    $fridayInstalledVoices = $synth.GetInstalledVoices() | Where-Object { $_.Enabled }
    $fridayPreferredVoice = $fridayInstalledVoices |
        Where-Object { $_.VoiceInfo.Name -match ($fridayVoiceNames -join '|') } |
        Sort-Object {
            $rank = 99
            for ($i = 0; $i -lt $fridayVoiceNames.Count; $i++) {
                if ($_.VoiceInfo.Name -match $fridayVoiceNames[$i]) { $rank = $i; break }
            }
            $rank
        } |
        Select-Object -First 1
    if (-not $fridayPreferredVoice) { throw "Locked FRIDAY voice Ryan is not installed; refusing to switch voices." }
    $synth.SelectVoice($fridayPreferredVoice.VoiceInfo.Name)
'''

_TTS_POWERSHELL_SOURCE = r'''Add-Type -AssemblyName System.Speech

$text = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($text)) { exit 0 }

$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    # FRIDAY_VOICE_RATE is kept in familiar words-per-minute units
    # (roughly 170-210). System.Speech uses a -10..+10 scale, so convert
    # explicitly instead of accidentally clamping 190 to +10.
    $rate = 3
    $volume = 100
    if ($env:FRIDAY_VOICE_RATE) {
        $wpm = [int]$env:FRIDAY_VOICE_RATE
        $rate = [Math]::Round(($wpm - 160) / 10)
    }
    if ($env:FRIDAY_VOICE_VOLUME) { $volume = [int]$env:FRIDAY_VOICE_VOLUME }

    $rate = [Math]::Max(-10, [Math]::Min(10, $rate))
    $volume = [Math]::Max(0, [Math]::Min(100, $volume))
    $synth.Rate = $rate
    $synth.Volume = $volume

    __FRIDAY_VOICE_SELECT__

    # Speak() is deliberately synchronous. Never use SpeakAsync().
    # SSML input (built by _build_speech_ssml in friday_backend.py)
    # gives real prosody -- per-sentence rate/pitch shading by
    # detected tone and short natural pauses between sentences --
    # instead of one flat monotone run. If SpeakSsml throws for any
    # reason (a future edge case in how the SSML was built), this
    # falls back to stripping the tags and speaking the plain text
    # right here, so a bad SSML string can only ever degrade back to
    # ordinary flat speech -- it can never produce silence or a
    # visible error.
    if ($text.TrimStart().StartsWith("<speak")) {
        try {
            $synth.SpeakSsml($text)
        } catch {
            $plain = [System.Text.RegularExpressions.Regex]::Replace($text, '<[^>]+>', ' ')
            $plain = [System.Text.RegularExpressions.Regex]::Replace($plain, '\s+', ' ').Trim()
            if ($plain) { $synth.Speak($plain) }
        }
    } else {
        $synth.Speak($text)
    }
}
finally {
    $synth.Dispose()
}
'''

_TTS_PERSISTENT_PS_SOURCE = r'''$ErrorActionPreference = "Stop"
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    $synth.Volume = 100

    # Select the deep/human voice ONCE when this persistent process starts,
    # exactly like the one-shot worker does. This resident process is the
    # PRIMARY speech path (speak() tries it first for every reply), so this
    # is what actually fixes the voice reverting to the Windows default --
    # this script previously never selected a voice at all.
    __FRIDAY_VOICE_SELECT__

    $reader = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), [System.Text.Encoding]::UTF8)
    while (($line = $reader.ReadLine()) -ne $null) {
        if ($line -eq "__FRIDAY_EXIT__") { break }
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try {
            $parts = $line.Split('|', 2)
            $rate = [int]$parts[0]
            $bytes = [Convert]::FromBase64String($parts[1])
            $text = [System.Text.Encoding]::UTF8.GetString($bytes)
            $synth.Rate = [Math]::Max(-10, [Math]::Min(10, [Math]::Round(($rate - 160) / 10)))
            $synth.SpeakSsml($text)
            [Console]::Out.WriteLine("DONE")
            [Console]::Out.Flush()
        } catch {
            [Console]::Out.WriteLine("ERR:" + $_.Exception.Message.Replace("`r"," ").Replace("`n"," "))
            [Console]::Out.Flush()
        }
    }
} finally { try { $synth.Dispose() } catch {} }
'''

# Splice the shared voice-selection logic into both SAPI PowerShell scripts.
# Done here (once, at import time) rather than as an f-string so the PS
# source keeps using literal `${...}` PowerShell syntax without Python
# trying to interpret it.
_TTS_POWERSHELL_SOURCE = _TTS_POWERSHELL_SOURCE.replace("__FRIDAY_VOICE_SELECT__", _TTS_VOICE_SELECT_PS)
_TTS_PERSISTENT_PS_SOURCE = _TTS_PERSISTENT_PS_SOURCE.replace("__FRIDAY_VOICE_SELECT__", _TTS_VOICE_SELECT_PS)

_TTS_PERSISTENT_LOCK = threading.Lock()
_TTS_PERSISTENT_PROCESS = None

_TTS_PYTHON_WORKER_SOURCE = r'''
import sys
import pyttsx3

text = sys.stdin.read()
if not text.strip():
    raise SystemExit(0)

rate = int(sys.argv[1])
volume = float(sys.argv[2])
engine = None
try:
    engine = pyttsx3.init("sapi5")
    engine.setProperty("rate", rate)
    engine.setProperty("volume", volume)
    voices = engine.getProperty("voices") or []
    # Same deep/human-male voice preference as the PowerShell paths above:
    # "ryan" first to match the locked V3096 human neural voice, then
    # natural male Windows voices only as local fallbacks if Edge Neural TTS
    # is unavailable. "zira" (female) is deliberately never auto-preferred here -- if no
    # named voice matches, fall back to any voice whose own metadata
    # reports a male gender before finally falling back to voices[0], so
    # this never silently lands on a default female voice either.
    preferred = None
    for wanted in ("ryan",):
        for voice in voices:
            label = ((getattr(voice, "name", "") or "") + " " +
                     (getattr(voice, "id", "") or "")).lower()
            if wanted in label:
                preferred = voice.id
                break
        if preferred:
            break
    if voices and preferred:
        engine.setProperty("voice", preferred)
    elif voices:
        raise RuntimeError("Locked FRIDAY voice Ryan is not installed; refusing to switch to another voice.")
    engine.say(text)
    engine.runAndWait()
finally:
    engine = None
'''


def _xml_escape(text):
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace('"', "&quot;").replace("'", "&apos;"))


# Per-tone prosody shading (see detect_user_tone / _TONE_RATE_DELTA
# above for where "frustrated"/"urgent"/"neutral" comes from). This is
# the "Prosody Generation" / "Expressive AI" upgrade from the voice
# research notes: real rhythm and pitch shifts by emotional context
# instead of one flat, robotic reading rate.
_TONE_SSML_PROSODY = {
    # Tone changes affect pitch only. Speech speed is governed exclusively by
    # FRIDAY_VOICE_RATE so a setting such as 173 WPM is stable in every mode.
    "frustrated": {"rate": "+0%", "pitch": "-5%"},
    "urgent":     {"rate": "+0%", "pitch": "+4%"},
    "neutral":    {"rate": "+0%", "pitch": "+0%"},
}


def _build_speech_ssml(text, tone):
    """
    Wraps plain speech text in standard W3C SSML that Windows'
    System.Speech.Synthesis understands natively via SpeakSsml():
    per-sentence rate/pitch shading based on the detected user tone,
    a touch of extra pitch lift on genuine questions, and a short
    natural <break> between sentences so replies breathe instead of
    reading as one unbroken monotone run. Returns None (caller then
    just speaks the plain text) if there is nothing to wrap -- never
    raises. If the resulting SSML is ever malformed for some
    unforeseen reason, the PowerShell TTS worker strips all tags and
    speaks the plain text instead, so this can only ever degrade back
    to ordinary flat speech, never silence or a visible error.
    """
    try:
        prosody = {"rate": "+0%", "pitch": _TONE_SSML_PROSODY.get(tone, _TONE_SSML_PROSODY["neutral"]).get("pitch", "+0%")}
        sentences = [s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s]
        if not sentences:
            return None
        parts = []
        for sentence in sentences:
            # Replace the explicit pause marker with an SSML break. This gives
            # conversational punctuation real breathing room instead of relying
            # on Windows' punctuation heuristics.
            chunks = re.split(r"\s*<FRIDAY_PAUSE>\s*", sentence)
            spoken_chunks = []
            for chunk in chunks:
                if chunk.strip():
                    # A short break after each comma-separated clause gives the
                    # same voice a more deliberate, articulate cadence -- the
                    # calm, measured delivery of movie FRIDAY -- instead of
                    # running every clause together. This only changes timing,
                    # never the synthesized voice itself.
                    clauses = [c for c in re.split(r",\s+", chunk.strip()) if c]
                    spoken_chunks.append(
                        '<break time="110ms"/>'.join(_xml_escape(c) for c in clauses)
                    )
            escaped = '<break time="280ms"/>'.join(spoken_chunks)
            if sentence.rstrip().endswith("?"):
                pitch = "+4%"
            elif sentence.rstrip().endswith("!"):
                pitch = "+2%"
            else:
                pitch = prosody["pitch"]
            parts.append(f'<s><prosody rate="{prosody["rate"]}" pitch="{pitch}">{escaped}</prosody></s>')
        joined = '<break time="180ms"/>'.join(parts)
        return (
            '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">'
            + joined + "</speak>"
        )
    except Exception as error:
        print("SSML build skipped (falling back to plain speech):", error)
        return None


def _tts_timeout_for(text):
    words = max(1, len(text.split()))
    estimated = (words / 100.0) * 60.0
    return max(180.0, int(estimated * 2.5 + 120.0))


_TTS_MP3_PLAYBACK_WORKER_SOURCE = r'''
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
$path = [Console]::In.ReadToEnd().Trim()
if ([string]::IsNullOrWhiteSpace($path)) { exit 2 }
$player = New-Object System.Windows.Media.MediaPlayer
try {
    $player.Open([Uri]::new($path))
    $deadline = [DateTime]::UtcNow.AddSeconds(10)
    while (-not $player.NaturalDuration.HasTimeSpan -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 50 }
    if (-not $player.NaturalDuration.HasTimeSpan) { exit 3 }
    $player.Volume = 1.0
    $player.Play()
    $duration = $player.NaturalDuration.TimeSpan.TotalSeconds
    $deadline = [DateTime]::UtcNow.AddSeconds([Math]::Max(5, $duration + 3))
    while ($player.Position.TotalSeconds -lt ($duration - 0.05) -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 40 }
    $player.Stop()
    exit 0
} finally { $player.Close() }
'''

def _run_edge_tts_legacy(text, rate=None):
    """Generate and synchronously play Microsoft neural Edge TTS audio.

    ORIGINAL one-process-per-sentence path. Kept unchanged as the automatic
    fallback for the fast resident path below."""
    import tempfile
    if os.name != "nt":
        raise RuntimeError("Neural Edge TTS playback is configured for Windows.")
    output = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    output.close()
    try:
        effective_rate = VOICE_RATE if rate is None else rate
        edge_rate = max(-20, min(50, round((effective_rate - 190) * 0.55)))
        env = os.environ.copy()
        env["FRIDAY_EDGE_OUTPUT"] = output.name
        env["FRIDAY_EDGE_RATE"] = str(edge_rate)
        env["FRIDAY_EDGE_VOICE"] = os.getenv("FRIDAY_EDGE_VOICE", "en-US-AriaNeural")  # HARD-LOCKED human neural voice
        result = subprocess.run(
            [sys.executable, "-u", "-c", _TTS_EDGE_WORKER_SOURCE],
            input=text, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=_tts_timeout_for(text), creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), env=env
        )
        if result.returncode != 0 or not os.path.exists(output.name) or os.path.getsize(output.name) < 1024:
            raise RuntimeError(result.stderr.strip() or "Edge TTS generation failed.")
        play = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _TTS_MP3_PLAYBACK_WORKER_SOURCE],
            input=output.name, capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=_tts_timeout_for(text) + 15, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), env=env
        )
        if play.returncode != 0:
            raise RuntimeError(play.stderr.strip() or "Edge TTS MP3 playback failed.")
        return result
    finally:
        try: os.unlink(output.name)
        except OSError: pass


def _persistent_sapi_speak(text, rate=None):
    """Speak through one resident System.Speech process to remove per-segment startup latency."""
    global _TTS_PERSISTENT_PROCESS
    import base64
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        raise FileNotFoundError("Windows PowerShell was not found.")
    effective_rate = VOICE_RATE if rate is None else rate
    payload = f"{int(effective_rate)}|" + base64.b64encode(text.encode("utf-8")).decode("ascii")
    with _TTS_PERSISTENT_LOCK:
        proc = _TTS_PERSISTENT_PROCESS
        if proc is None or proc.poll() is not None:
            proc = subprocess.Popen(
                [powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _TTS_PERSISTENT_PS_SOURCE],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, encoding="utf-8", errors="replace", bufsize=1,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            _TTS_PERSISTENT_PROCESS = proc
        proc.stdin.write(payload + "\n")
        proc.stdin.flush()
        deadline=time.perf_counter()+_tts_timeout_for(text)
        while time.perf_counter() < deadline:
            line=proc.stdout.readline()
            if not line:
                break
            line=line.strip()
            if line == "DONE":
                return True
            if line.startswith("ERR:"):
                raise RuntimeError(line[4:])
        raise TimeoutError("Persistent SAPI TTS timed out.")


def _stop_persistent_sapi():
    global _TTS_PERSISTENT_PROCESS
    with _TTS_PERSISTENT_LOCK:
        proc=_TTS_PERSISTENT_PROCESS
        _TTS_PERSISTENT_PROCESS=None
        if proc is not None and proc.poll() is None:
            try:
                proc.stdin.write("__FRIDAY_EXIT__\n"); proc.stdin.flush()
            except Exception: pass
            try: proc.terminate()
            except Exception: pass

def _run_powershell_tts(text, rate=None):
    import shutil
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        raise FileNotFoundError("Windows PowerShell was not found.")

    effective_rate = VOICE_RATE if rate is None else rate

    env = os.environ.copy()
    env["FRIDAY_VOICE_RATE"] = str(int(effective_rate))
    env["FRIDAY_VOICE_VOLUME"] = str(max(0, min(100, round(VOICE_VOLUME * 100))))

    return subprocess.run(
        [powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
         "-Command", _TTS_POWERSHELL_SOURCE],
        input=text,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=_tts_timeout_for(text),
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        env=env,
    )


def _run_pyttsx3_fallback(text, rate=None):
    effective_rate = VOICE_RATE if rate is None else rate
    return _run_interruptible_process(
        [sys.executable, "-u", "-c", _TTS_PYTHON_WORKER_SOURCE,
         str(effective_rate), str(VOICE_VOLUME)],
        text, _tts_timeout_for(text))


def emit_progress(percent, stage, task="Working"):
    """
    Prints a PROGRESS:: marker reflecting a REAL pipeline checkpoint
    that has just actually been reached (research finished, content
    plan finished, a specific file finished writing, etc.) -- never a
    simulated/animated fake percentage -- so the UI can show a
    genuinely accurate completion bar for research/document-creation
    tasks. Never raises.
    """
    try:
        pct = max(0, min(100, int(round(percent))))
        print("PROGRESS::" + json.dumps({
            "task": task, "percent": pct, "stage": stage, "done": pct >= 100,
        }, ensure_ascii=False))
    except Exception as error:
        print("Progress emit skipped (ignored):", error)


def _split_speech_segments(text, max_chars=None):
    """Split long AI output into natural, bounded speech segments.

    Each segment is spoken synchronously before the next begins, preventing
    overlapping TTS workers and preserving every sentence.
    """
    if max_chars is None:
        try:
            max_chars = max(420, int(os.getenv("FRIDAY_TTS_SEGMENT_CHARS", "1800")))
        except Exception:
            max_chars = 900
    clean = re.sub(r"\s+", " ", (text or "").strip())
    if not clean:
        return []
    sentences = [x.strip() for x in re.split(r"(?<=[.!?])\s+", clean) if x.strip()]
    segments, current = [], ""
    for sentence in sentences or [clean]:
        if not current:
            current = sentence
        elif len(current) + 1 + len(sentence) <= max_chars:
            current += " " + sentence
        else:
            segments.append(current)
            current = sentence
    if current:
        segments.append(current)
    return segments or [clean]


import atexit
atexit.register(_stop_persistent_sapi)

# ============================================================
# V2.2.5 FAST SPEECH PATH (same voice, same engine, same playback)
# The old path started a brand-new Python process (re-importing edge_tts) AND
# a brand-new PowerShell (re-loading the media libraries) for EVERY sentence,
# and only began making sentence N+1 after sentence N had finished playing.
# Now: edge_tts stays loaded in this process, one PowerShell player stays
# resident, and the next sentence is synthesised while the current one plays.
# Any failure drops straight back to _run_edge_tts_legacy (the old path).
# ============================================================
import concurrent.futures as _cf

_FAST_TTS_ENABLED = os.getenv("FRIDAY_FAST_TTS", "1").strip().lower() in {"1", "true", "yes", "on"}
_FAST_TTS_POOL = _cf.ThreadPoolExecutor(max_workers=3, thread_name_prefix="FridayTTSSynth")
_FAST_TTS_CACHE = {}              # (text, voice, rate) -> (future, created_at)
_FAST_TTS_CACHE_LOCK = threading.Lock()
_FAST_TTS_FAILS = 0
_FAST_TTS_RETRY_AT = 0.0          # after 3 failures in a row, use the old path for a while, then try the fast one again
_FAST_PLAYER_PROCESS = None
_FAST_PLAYER_LOCK = threading.Lock()

_FAST_PLAYER_PS_SOURCE = r'''
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
[Console]::Out.WriteLine("READY"); [Console]::Out.Flush()
while ($true) {
    $path = [Console]::In.ReadLine()
    if ($null -eq $path) { break }
    $path = $path.Trim()
    if ($path -eq "__FRIDAY_EXIT__") { break }
    if ([string]::IsNullOrWhiteSpace($path)) { continue }
    $player = $null
    try {
        $player = New-Object System.Windows.Media.MediaPlayer
        $player.Open([Uri]::new($path))
        $deadline = [DateTime]::UtcNow.AddSeconds(10)
        while (-not $player.NaturalDuration.HasTimeSpan -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 10 }
        if (-not $player.NaturalDuration.HasTimeSpan) { throw "MediaPlayer could not open the audio." }
        $player.Volume = 1.0
        $player.Play()
        $duration = $player.NaturalDuration.TimeSpan.TotalSeconds
        $deadline = [DateTime]::UtcNow.AddSeconds([Math]::Max(5, $duration + 3))
        while ($player.Position.TotalSeconds -lt ($duration - 0.05) -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 20 }
        $player.Stop()
        [Console]::Out.WriteLine("DONE")
    } catch {
        [Console]::Out.WriteLine("ERR:" + ($_.Exception.Message -replace "[\r\n]+", " "))
    } finally {
        if ($null -ne $player) { try { $player.Close() } catch {} }
        [Console]::Out.Flush()
    }
}
'''


def _fast_tts_usable():
    global _FAST_TTS_FAILS, _FAST_TTS_RETRY_AT
    if not _FAST_TTS_ENABLED or os.name != "nt":
        return False
    if _FAST_TTS_FAILS >= 3:
        if time.monotonic() < _FAST_TTS_RETRY_AT:
            return False
        _FAST_TTS_FAILS = 0
    return True


def _fast_tts_params(rate):
    effective_rate = VOICE_RATE if rate is None else rate
    edge_rate = max(-20, min(50, round((effective_rate - 190) * 0.55)))
    voice = os.getenv("FRIDAY_EDGE_VOICE", "en-US-AriaNeural")  # same locked voice as the old path
    return voice, f"{edge_rate:+d}%"


def _fast_tts_synthesize(text, voice, rate_text):
    """edge_tts -> temp mp3 (this process, library already loaded)."""
    import tempfile
    import asyncio
    import edge_tts
    out = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    out.close()
    try:
        async def _go():
            comm = edge_tts.Communicate(text, voice=voice, rate=rate_text, volume="+0%", pitch="+0Hz")
            await asyncio.wait_for(comm.save(out.name), timeout=45)
        asyncio.run(_go())
        if not os.path.exists(out.name) or os.path.getsize(out.name) < 1024:
            raise RuntimeError("Edge TTS produced no audio.")
        return out.name
    except BaseException:
        try: os.unlink(out.name)
        except OSError: pass
        raise


def _fast_tts_purge_old(max_age=120.0):
    now = time.monotonic()
    stale = []
    with _FAST_TTS_CACHE_LOCK:
        for key, (fut, born) in list(_FAST_TTS_CACHE.items()):
            if now - born > max_age:
                stale.append(fut)
                del _FAST_TTS_CACHE[key]
    for fut in stale:
        try:
            if fut.done() and not fut.cancelled() and fut.exception() is None:
                os.unlink(fut.result())
        except Exception:
            pass


def _fast_tts_future(text, rate):
    """Start (or join) synthesis of one sentence. Safe to call early as a prefetch."""
    voice, rate_text = _fast_tts_params(rate)
    key = (text, voice, rate_text)
    with _FAST_TTS_CACHE_LOCK:
        hit = _FAST_TTS_CACHE.get(key)
        if hit is not None:
            return key, hit[0]
        fut = _FAST_TTS_POOL.submit(_fast_tts_synthesize, text, voice, rate_text)
        _FAST_TTS_CACHE[key] = (fut, time.monotonic())
        return key, fut


def _edge_segments_for_speech(text, stream_piece=False):
    """EXACTLY the text speak() will hand to the voice for this piece (pure; no side effects)."""
    text = _apply_user_address(str(text or "").strip(), prefix=not stream_piece)
    if not text:
        return []
    spoken = _prepare_for_natural_speech(make_math_speakable(text))
    if not spoken:
        return []
    out = []
    for segment in _split_speech_segments(spoken):
        e = re.sub(r"\s*<FRIDAY_PAUSE>\s*", ", ", segment)
        e = re.sub(r"\s+", " ", e).strip()
        if e:
            out.append(e)
    return out


def _fast_tts_prefetch(text, stream_piece=False):
    """Begin synthesising a sentence that is about to be spoken. Never raises."""
    try:
        if friday_speech5 is not None and not _UI_SPEAK_MUTED and friday_speech5.usable():
            _v, _r = _fast_tts_params(VOICE_RATE)
            for _seg in _edge_segments_for_speech(text, stream_piece)[:2]:
                friday_speech5.prefetch(_seg, _v, _r)
            return
        if _UI_SPEAK_MUTED or not _fast_tts_usable():
            return
        _fast_tts_purge_old()
        for seg in _edge_segments_for_speech(text, stream_piece)[:2]:
            _fast_tts_future(seg, VOICE_RATE)
    except Exception:
        pass


def _fast_player_start():
    global _FAST_PLAYER_PROCESS
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        raise FileNotFoundError("Windows PowerShell was not found.")
    proc = subprocess.Popen(
        [powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _FAST_PLAYER_PS_SOURCE],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        text=True, encoding="utf-8", errors="replace", bufsize=1,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    _FAST_PLAYER_PROCESS = proc
    return proc


def _fast_player_stop():
    global _FAST_PLAYER_PROCESS
    proc, _FAST_PLAYER_PROCESS = _FAST_PLAYER_PROCESS, None
    if proc is not None and proc.poll() is None:
        try:
            proc.stdin.write("__FRIDAY_EXIT__\n"); proc.stdin.flush()
        except Exception:
            pass
        try: proc.terminate()
        except Exception: pass


def _fast_player_play(path, timeout):
    """Play one mp3 through the resident player; blocks until it has finished playing."""
    with _FAST_PLAYER_LOCK:
        proc = _FAST_PLAYER_PROCESS
        if proc is None or proc.poll() is not None:
            proc = _fast_player_start()
        result = {}

        def _reader():
            try:
                while True:
                    line = proc.stdout.readline()
                    if not line:
                        result["eof"] = True
                        return
                    line = line.strip()
                    if line in ("READY",):
                        continue
                    result["line"] = line
                    return
            except Exception as exc:
                result["exc"] = exc

        proc.stdin.write(path + "\n")
        proc.stdin.flush()
        t = threading.Thread(target=_reader, daemon=True)
        t.start()
        t.join(timeout)
        line = result.get("line")
        if line == "DONE":
            return True
        # Anything else: the resident player is in an unknown state, so retire it.
        _fast_player_stop()
        if line and line.startswith("ERR:"):
            raise RuntimeError(line[4:])
        raise RuntimeError("Resident audio player stopped responding.")


def _fast_player_warm():
    """Start the resident player at launch so even the first reply skips the PowerShell/media-library load."""
    if os.name != "nt" or not _FAST_TTS_ENABLED:
        return
    try:
        with _FAST_PLAYER_LOCK:
            if _FAST_PLAYER_PROCESS is None or _FAST_PLAYER_PROCESS.poll() is not None:
                _fast_player_start()
        import edge_tts  # noqa: F401  (load the library now, not at first reply)
    except Exception as exc:
        print("Fast speech warm-up skipped:", exc, flush=True)


def _run_edge_tts(text, rate=None, on_start=None):
    """Same contract as before (blocks until spoken, raises on failure), now far lower latency.
    FRIDAY 6.3: on_start() is called at the moment the audio begins, so the reply text appears together with the voice."""
    global _FAST_TTS_FAILS, _FAST_TTS_RETRY_AT
    # FRIDAY 5.0: in-memory synthesis, parallel prefetch, in-process playback, interruptible.
    if friday_speech5 is not None:
        if friday_speech5.is_aborted():
            return True
        if friday_speech5.usable():
            try:
                _v5_voice, _v5_rate = _fast_tts_params(rate)
                friday_speech5.say(text, _v5_voice, _v5_rate, on_start=on_start)
                return True
            except Exception as _v5_tts_error:
                if friday_speech5.is_aborted():
                    return True
                print("FRIDAY 5.0 speech path failed; using the previous path:", _v5_tts_error, flush=True)
    if not _fast_tts_usable():
        if on_start is not None:
            try: on_start()
            except Exception: pass
        return _run_edge_tts_legacy(text, rate=rate)
    key, fut = _fast_tts_future(text, rate)
    path = None
    try:
        path = fut.result(timeout=60)
        if on_start is not None:
            try: on_start()
            except Exception: pass
        _fast_player_play(path, timeout=_tts_timeout_for(text) + 15)
        _FAST_TTS_FAILS = 0
        return True
    except Exception as fast_error:
        _FAST_TTS_FAILS += 1
        if _FAST_TTS_FAILS >= 3:
            _FAST_TTS_RETRY_AT = time.monotonic() + 120.0
        print(f"Fast speech path failed ({_FAST_TTS_FAILS}/3), using the original path:", fast_error, flush=True)
        if on_start is not None:
            try: on_start()
            except Exception: pass
        return _run_edge_tts_legacy(text, rate=rate)
    finally:
        with _FAST_TTS_CACHE_LOCK:
            _FAST_TTS_CACHE.pop(key, None)
        if path:
            try: os.unlink(path)
            except OSError: pass


atexit.register(_fast_player_stop)
try:
    if friday_speech5 is not None:
        friday_speech5.legacy_play_file = _fast_player_play     # fallback player when miniaudio/PyAudio are missing
        friday_speech5.legacy_stop = _fast_player_stop
except Exception:
    pass
atexit.register(lambda: _fast_tts_purge_old(max_age=-1))


_SIR_LOWERCASE_OPENERS = {
    "the", "give", "done", "something", "your", "there", "please", "tell", "choose", "attach", "say",
    "one", "it", "this", "that", "my", "no", "nothing", "unfortunately", "sorry", "unable", "now", "all",
    "what", "which", "how", "you", "we", "opening", "closing", "searching", "creating", "starting",
    "checking", "very", "understood", "right", "certainly", "of", "at", "in", "a", "an", "a",
    "i", "could", "would", "can", "shall", "let", "just", "one", "two", "three", "once", "for",
}


_UI_SPEAK_MUTED = False  # set from the UI "Speak replies" switch (text still shows in chat)


_USER_ADDRESS = {"word": "Sir", "title": True}   # set from the UI; word "" means no title


def _apply_user_address(text, prefix=True):
    """Rewrite / add the form of address the user picked in Settings (default: sir)."""
    word = str(_USER_ADDRESS.get("word", "Sir"))
    title = bool(_USER_ADDRESS.get("title", True))
    if word.lower() != "sir":
        if word:
            def _rep(m):
                if not title:
                    return word
                return word if m.group(0)[:1].isupper() else word.lower()
            text = re.sub(r"\bsir\b", _rep, text, flags=re.I)
        else:
            text = re.sub(r",\s*sir\b", "", text, flags=re.I)
            text = re.sub(r"\bsir,\s*", "", text, flags=re.I)
            text = re.sub(r"\s+sir\b", "", text, flags=re.I)
            text = re.sub(r"\bsir\b", "", text, flags=re.I).strip()
            return (text[:1].upper() + text[1:]) if text else text
    shown = word or "Sir"
    if prefix and not re.search(r"\b" + re.escape(shown) + r"\b", text, flags=re.I):
        _first = re.match(r"^([A-Za-z]+)", text)
        if _first and _first.group(1).lower() in _SIR_LOWERCASE_OPENERS and text[0].isupper() and _first.group(1).lower() != "i":
            text = text[0].lower() + text[1:]
        text = shown + ", " + text
    return text


def speak(text, *, _stream_piece=False):
    if text is None:
        return
    text = str(text).strip()
    if not text:
        return

    # Every spoken response addresses the user the way they chose in FRIDAY > Settings > Assistant
    # (default "sir"). Done at the final TTS layer so it also covers status messages, errors, study
    # mode narration and other non-Gemini responses without changing UI text.
    if friday_speech5 is not None and friday_speech5.is_aborted():
        return          # the user interrupted this reply (spoke over FRIDAY / said stop): stay quiet until the next command
    text = _apply_user_address(text, prefix=not _stream_piece)
    if not text:
        return

    spoken_text = make_math_speakable(text)
    spoken_text = _prepare_for_natural_speech(spoken_text)
    if not spoken_text:
        return

    print(f"\n{NAME}: {text}")
    # V3.1: the reply is pushed to the chat at the moment its voice is ready to play (not earlier), so the words appear
    # and FRIDAY starts speaking together instead of the text sitting there while speech is still queued or synthesising.
    _answer_shown = [False]

    def _show_answer():
        if _answer_shown[0]:
            return
        _answer_shown[0] = True
        try:
            print("ACTION::ANSWER_PART::" + base64.b64encode(text.encode("utf-8")).decode("ascii"), flush=True)
        except Exception:
            pass
        try:
            if friday_core5 is not None:
                friday_core5.note_first_audio()
        except Exception:
            pass

    if _UI_SPEAK_MUTED:
        # Silent mode: the reply goes straight to the chat.
        _show_answer()
        try:
            print("ACTION::ANSWER_END", flush=True)
        except Exception:
            pass
        return

    global _LAST_SPOKEN_NORMALIZED
    _LAST_SPOKEN_NORMALIZED = _normalize_for_echo_check(spoken_text)
    # V6.0.1: remember the last few things she said so her own voice coming back through the microphone is never taken for a command.
    try:
        _SPOKEN_HISTORY.append((time.time(), _LAST_SPOKEN_NORMALIZED))
    except Exception:
        pass

    # The configured voice rate is authoritative. Tone affects pitch/prosody
    # only, so the same voice and the same 173-style speed remain stable.
    effective_rate = VOICE_RATE

    # Lets the UI keep the arc reactor's "speaking"/glowing state for
    # the ACTUAL duration of TTS playback instead of guessing from
    # text length. Both engines below are synchronous and block until
    # the full response has been read aloud, so SPEAK_END is only
    # printed once Friday has truly finished talking -- no matter how
    # long that took (long study explanations previously cut the glow
    # off early because the UI's old estimate was capped at 12s).
    # try/finally guarantees SPEAK_END is still printed even if a TTS
    # engine raises, so the UI can never get stuck glowing forever.
    global _TTS_ACTIVE, _TTS_DEPTH, _TTS_LAST_END
    with _TTS_DEPTH_LOCK:
        _TTS_DEPTH += 1
        _TTS_ACTIVE = True
        if _TTS_DEPTH == 1:
            print("ACTION::SPEAK_START", flush=True)
    try:
        # Serialize all speech. Both engines receive the COMPLETE response and
        # block until their process returns.
        with _TTS_LOCK:
            segments = _split_speech_segments(spoken_text)
            # FRIDAY 6.3: start making the voice for the first sentences right away, but do NOT hold the reply back or show it early:
            # the text is pushed to the chat by _show_answer() at the instant the first sound starts (on_start below).
            try:
                if friday_speech5 is not None and friday_speech5.usable() and len(segments) >= 1:
                    _v5v, _v5r = _fast_tts_params(effective_rate)
                    for _pre in segments[:3]:
                        _pre_edge = re.sub(r"\s+", " ", re.sub(r"\s*<FRIDAY_PAUSE>\s*", ", ", _pre)).strip()
                        if _pre_edge:
                            friday_speech5.prefetch(_pre_edge, _v5v, _v5r)
                elif _FAST_TTS_ENABLED and os.name == "nt" and len(segments) >= 1:
                    for _pre in segments[:3]:
                        _pre_edge = re.sub(r"\s+", " ", re.sub(r"\s*<FRIDAY_PAUSE>\s*", ", ", _pre)).strip()
                        if _pre_edge:
                            _fast_tts_future(_pre_edge, effective_rate)
            except Exception:
                pass
            # Safety net only: if no audio has started after 8 s (voice service slow/offline) the words still reach the chat.
            # V7.4 SPEED: the words reach the conversation within ~0.35 s of the reply being ready (or at first sound, whichever is first),
            # instead of waiting for the voice service (which could take several seconds on a slow network).
            try:
                _text_lead = max(0.0, float(os.getenv("FRIDAY_TEXT_LEAD_SECONDS", "0.35")))
            except Exception:
                _text_lead = 0.35
            _show_timer = threading.Timer(_text_lead, _show_answer)
            _show_timer.daemon = True
            _show_timer.start()
            for index, segment in enumerate(segments, 1):
                if friday_speech5 is not None and friday_speech5.is_aborted():
                    break
                log_event(f"TTS segment {index}/{len(segments)}", kind="voice")
                try:
                    ssml_text = _build_speech_ssml(segment, _LAST_USER_TONE) or segment
                    # Edge Neural TTS is the primary voice: it sounds more natural and
                    # avoids the resident System.Speech process occasionally hanging
                    # until its very large safety timeout. The old persistent SAPI path
                    # remains available as an explicit fallback, but is never allowed to
                    # block the normal response path.
                    try:
                        # V2045 FIX: Edge TTS is plain-text input, not SSML, so it
                        # was previously speaking the literal internal marker
                        # "<FRIDAY_PAUSE>" out loud (heard as "friday underscore
                        # pause") whenever a sentence contained a natural
                        # dash-pause. The SSML path below already converts that
                        # marker into a real <break>; Edge TTS gets the same
                        # pause expressed as natural punctuation instead.
                        edge_segment = re.sub(r"\s*<FRIDAY_PAUSE>\s*", ", ", segment)
                        edge_segment = re.sub(r"\s+", " ", edge_segment).strip()
                        _run_edge_tts(edge_segment, rate=effective_rate, on_start=_show_answer)
                        continue
                    except Exception as edge_error:
                        # HARD VOICE LOCK: never switch to SAPI/pyttsx3.
                        # Those engines can sound robotic and would violate the
                        # single-voice requirement. Retry the exact same Ryan
                        # Neural voice twice, then leave the segment unspoken
                        # rather than changing voices.
                        print("Locked Ryan Neural TTS retry:", edge_error, flush=True)
                        recovered = False
                        for retry in range(2):
                            try:
                                time.sleep(0.12)
                                _run_edge_tts(edge_segment, rate=effective_rate, on_start=_show_answer)
                                recovered = True
                                break
                            except Exception as retry_error:
                                print(f"Locked Ryan Neural retry {retry + 1} failed:", retry_error, flush=True)
                        if not recovered:
                            print("Locked Ryan Neural TTS unavailable; refusing alternate voice.", flush=True)
                        continue
                except Exception as error:
                    print("Locked Ryan Neural TTS segment error; refusing alternate voice:", error, flush=True)
    finally:
        try:
            _show_timer.cancel()
        except Exception:
            pass
        _show_answer()          # V3.1: never lose a reply, even if speech failed before it was shown
        try:
            print("ACTION::ANSWER_END", flush=True)
        except Exception:
            pass
        with _TTS_DEPTH_LOCK:
            _TTS_DEPTH = max(0, _TTS_DEPTH - 1)
            if _TTS_DEPTH == 0:
                _TTS_ACTIVE = False
                _TTS_LAST_END = time.time()
                print("ACTION::SPEAK_END", flush=True)


# ============================================================

# SPEECH RECOGNITION
# ============================================================

recognizer = sr.Recognizer()
recognizer.energy_threshold = 300
recognizer.dynamic_energy_threshold = True
recognizer.dynamic_energy_adjustment_damping = 0.15
recognizer.dynamic_energy_ratio = 1.5
# Do not finalize an utterance on a short conversational pause.
# The capture ends only after VAD_PAUSE_THRESHOLD seconds of silence.
recognizer.pause_threshold = VAD_PAUSE_THRESHOLD
recognizer.phrase_threshold = VAD_PHRASE_THRESHOLD
recognizer.non_speaking_duration = VAD_NON_SPEAKING_DURATION

_MIC_CALIBRATED = False

# ------------------------------------------------------------
# ADAPTIVE NOISE FLOOR (research: "how can I make my fridays listen
# and recognize any" doc, section on self-recalibration)
# ------------------------------------------------------------
# calibrate_microphone() below only ever ran ONCE per process
# lifetime. If the room's background noise changes later (a fan
# turns on, someone starts playing music elsewhere, a window opens),
# recognizer.energy_threshold stays stuck at whatever the room sounded
# like at startup, and recognition quietly gets worse. This adds two
# independent triggers that force a fresh calibration:
#   1. a plain timer -- every _RECALIBRATE_EVERY_SECONDS regardless
#      of anything else, and
#   2. a "things keep failing" counter -- after several listen()
#      calls in a row come back empty (silence/unknown), on the
#      assumption the noise floor drifted rather than the person
#      just not talking.
_RECALIBRATE_EVERY_SECONDS = 600  # 10 minutes
_RECALIBRATE_AFTER_MISSES = 4
_last_calibration_time = 0.0
_consecutive_empty_listens = 0
_VAD_NOISE_FLOOR = 0.0  # adaptive PCM noise floor retained between listens



def _maybe_force_recalibration():
    """Called at the top of every listen(). Clears _MIC_CALIBRATED so
    calibrate_microphone() below re-measures the ambient noise floor,
    without ever touching recognizer.energy_threshold directly (that
    stays SpeechRecognition's own job)."""
    global _MIC_CALIBRATED, _last_calibration_time
    now = time.time()
    if not _MIC_CALIBRATED:
        return
    if (now - _last_calibration_time) >= _RECALIBRATE_EVERY_SECONDS:
        _MIC_CALIBRATED = False
        return
    if _consecutive_empty_listens >= _RECALIBRATE_AFTER_MISSES:
        _MIC_CALIBRATED = False


# ------------------------------------------------------------
# COMMON MISHEAR CORRECTIONS (same research doc: a plain lookup
# table of things Google Speech reliably mangles for this app's own
# vocabulary -- brand names, this app's own trigger phrases, and
# Cambridge syllabus jargon). Applied as whole-phrase / substring
# fixes AFTER recognition, so it costs nothing extra and never
# touches the request itself. Keys are lowercase; matching is done
# on the lowercased transcript. Longer/more specific keys are listed
# first so they win over a shorter partial match.
# ------------------------------------------------------------
_COMMON_CORRECTIONS = [
    ("study load", "study mode"),
    ("study mood", "study mode"),
    ("study mote", "study mode"),
    ("stubby mode", "study mode"),
    ("diagram lap", "diagram lab"),
    ("diagram love", "diagram lab"),
    ("what's app", "whatsapp"),
    ("whats app", "whatsapp"),
    ("spot if I", "spotify"),
    ("spotify fi", "spotify"),
    ("you tube", "youtube"),
    ("gara vis", "friday"),
    ("jar vis", "friday"),
    ("jarvest", "friday"),
    ("exam load", "exam mode"),
    ("show syllable", "show syllabus"),
    ("show cylabus", "show syllabus"),
    ("active recoil", "active recall"),
    ("flash cards", "flashcards"),
    ("nine seven oh one", "9701"),
    ("nine seven oh two", "9702"),
    ("nine seven oh nine", "9709"),
    ("nine six one eight", "9618"),
    ("four oh two four", "4024"),
]


def _normalize_spoken_symbols(text: str) -> str:
    """Normalize spoken punctuation/symbol names without damaging URLs, paths,
    fractions, or ordinary prose.

    Speech recognizers often emit words such as "slash", "at sign", "dot",
    "underscore", and "ampersand". The assistant should understand those as
    symbols when the surrounding words make that interpretation clear.
    Alphabetic A/B choices are rendered semantically as "A or B" so the NLU
    never treats the punctuation word itself as the user's intent.
    """
    if not text:
        return text
    x=str(text).strip()
    x=re.sub(r"\b(one|two|three|four|five|six|seven|eight|nine|zero|\d+)\s+(?:slash|over)\s+(one|two|three|four|five|six|seven|eight|nine|zero|\d+)\b", r"\1/\2", x, flags=re.I)
    # Explicit choice constructions: "input slash output" => "input or output".
    x=re.sub(r"\b([A-Za-z][\w-]*)\s+(?:slash|forward slash)\s+([A-Za-z][\w-]*)\b", r"\1 or \2", x, flags=re.I)
    x=re.sub(r"\b([A-Za-z][\w-]*)\s+(?:backslash)\s+([A-Za-z][\w-]*)\b", r"\1 or \2", x, flags=re.I)
    # Email / URL-style spoken punctuation. These substitutions are limited to
    # recognizable identifier contexts rather than globally changing prose.
    x=re.sub(r"\b([\w.+-]+)\s+at\s+([\w.-]+\s+dot\s+[A-Za-z]{2,})\b", lambda m: m.group(1)+"@"+re.sub(r"\s+dot\s+", ".", m.group(2), flags=re.I), x, flags=re.I)
    x=re.sub(r"\b([\w-]+)\s+dot\s+([A-Za-z]{2,})\b", r"\1.\2", x, flags=re.I)
    x=re.sub(r"\b([\w-]+)\s+(?:underscore|under score)\s+([\w-]+)\b", r"\1_\2", x, flags=re.I)
    x=re.sub(r"\b([\w-]+)\s+(?:ampersand|and sign)\s+([\w-]+)\b", r"\1 and \2", x, flags=re.I)
    # Spoken hyphen/dash is useful for command identifiers, filenames and
    # versions, but only between identifier-like tokens.
    x=re.sub(r"\b([A-Za-z0-9]+)\s+(?:hyphen|dash)\s+([A-Za-z0-9]+)\b", r"\1-\2", x, flags=re.I)
    # Spoken slash in a numeric expression is a fraction, not an "or".
    # Equality/inequality words are meaningful in maths/programming requests.
    if re.search(r"\b(?:equals|equal to|not equal to)\b", x, re.I):
        x=re.sub(r"\bnot equal to\b", "!=", x, flags=re.I)
        x=re.sub(r"\bequal(?:s| to)?\b", "=", x, flags=re.I)
    return re.sub(r"\s+", " ", x).strip()


def _apply_common_corrections(text):
    """Best-effort cleanup of transcripts Google reliably mangles for
    this app's own vocabulary. Never raises; returns text unchanged
    on any problem."""
    if not text:
        return text
    fixed = text
    lowered = fixed.lower()
    for wrong, right in _COMMON_CORRECTIONS:
        if wrong in lowered:
            pattern = re.compile(re.escape(wrong), re.IGNORECASE)
            fixed = pattern.sub(right, fixed)
            lowered = fixed.lower()
    return fixed


# ------------------------------------------------------------
# OPTIONAL NOISE SUPPRESSION
# ------------------------------------------------------------
# Pure enhancement layer, same philosophy as the semantic-matching
# block below: if `noisereduce` + `numpy` aren't installed, this
# quietly does nothing and listen() behaves exactly as before. Add
# them with:  pip install noisereduce numpy
# (see requirements_new_features.txt).
#
# v88 BUGFIX: these used to be a single try/except setting one flag. numpy and
# noisereduce were imported together, so if `noisereduce` was missing --
# which is common, it is the heavier and more fragile of the two -- the flag
# went False and _audio_highpass_and_normalize() returned the audio
# COMPLETELY UNTOUCHED. The high-pass filter and automatic gain control only
# ever needed numpy. Anyone who had numpy but not noisereduce was silently
# getting no audio conditioning at all, and therefore worse recognition.
# The two capabilities are now tracked separately.
try:
    import numpy as _np
    _NUMPY_AVAILABLE = True
except Exception:
    _NUMPY_AVAILABLE = False

try:
    import noisereduce as _noisereduce
    _NOISE_SUPPRESSION_AVAILABLE = _NUMPY_AVAILABLE
except Exception:
    _NOISE_SUPPRESSION_AVAILABLE = False


try:
    from scipy.signal import lfilter as _scipy_lfilter
except Exception:
    _scipy_lfilter = None


def _highpass_vectorized(x, alpha=0.995):
    """First-order high-pass:  y[i] = alpha * (y[i-1] + x[i] - x[i-1]).

    Returns a float32 array the same length as x.

    Implemented without a Python-level per-sample loop. SciPy's lfilter is
    used when available; otherwise an exact blockwise cumulative-sum form is
    used. The block size matters: the closed form multiplies by alpha**-k,
    which overflows float64 once k is large (alpha**-441000 is inf), so the
    recursion is restarted every _HP_BLOCK samples with the carried state.
    Mathematically identical to the original loop, just evaluated in C.
    """
    n = x.shape[0]
    if n == 0:
        return x.astype(_np.float32)

    if _scipy_lfilter is not None:
        # H(z) = alpha(1 - z^-1) / (1 - alpha z^-1)
        filtered = _scipy_lfilter([alpha, -alpha], [1.0, -alpha], x.astype(_np.float64))
        filtered = filtered.astype(_np.float32)
        filtered[0] = x[0]
        return filtered if _np.all(_np.isfinite(filtered)) else x.astype(_np.float32)

    # d[i] = x[i] - x[i-1]; the block's first element also carries prior state.
    d = _np.empty(n, dtype=_np.float64)
    d[0] = x[0]
    d[1:] = (x[1:] - x[:-1]).astype(_np.float64)

    _HP_BLOCK = 8192  # alpha**-8192 ~= 6e17, comfortably inside float64
    log_alpha = math.log(alpha)
    offsets = _np.arange(_HP_BLOCK, dtype=_np.float64)
    inverse_weights = _np.exp(-log_alpha * offsets)
    forward_weights = _np.exp(log_alpha * (offsets + 1.0))

    y = _np.empty(n, dtype=_np.float64)
    previous_y = 0.0
    for start in range(0, n, _HP_BLOCK):
        stop = min(start + _HP_BLOCK, n)
        length = stop - start
        block = d[start:stop].copy()
        # Fold the carried y[start-1] into the block's first driving term.
        block[0] += previous_y
        accumulated = _np.cumsum(block * inverse_weights[:length])
        y[start:stop] = accumulated * forward_weights[:length]
        previous_y = float(y[stop - 1])

    y[0] = x[0]
    result = y.astype(_np.float32)
    if not _np.all(_np.isfinite(result)):
        # Numerical safety net: never feed NaN/inf into speech recognition.
        return x.astype(_np.float32)
    return result


def _audio_highpass_and_normalize(audio):
    """Apply a lightweight high-pass filter and automatic gain control.

    The operation is deliberately dependency-light: numpy is optional, and
    if it is absent or anything looks unusual the original AudioData is
    returned. This removes DC/low-frequency rumble, raises a quiet voice to a
    predictable RMS level, and prevents sudden loud input from clipping.
    """
    if not _NUMPY_AVAILABLE:
        return audio
    try:
        if audio.sample_width != 2:
            return audio
        raw = _np.frombuffer(audio.get_raw_data(), dtype=_np.int16).astype(_np.float32)
        if raw.size < 32:
            return audio
        # First-order high-pass filter; preserves speech while reducing fan/rumble.
        #
        # v88 LATENCY FIX -- this used to be a pure-Python `for i in range(1, len(x))`
        # loop running once per SAMPLE. At 44.1 kHz a 10-second capture is 441,000
        # interpreter iterations, and _enhance_audio() called this function TWICE,
        # so ~900,000 iterations of Python-level arithmetic sat between the user
        # finishing a sentence and speech recognition starting. That is seconds of
        # dead time on its own.
        #
        # The recurrence y[i] = a*(y[i-1] + x[i] - x[i-1]) is solved in closed form:
        #   let d[i] = x[i] - x[i-1]  (with d[0] = x[0])
        #   then y[i] = sum_{k<=i} a^(i-k+1) * d[k]   for i >= 1
        # which is a scaled cumulative sum. Computed with numpy this is O(n) in C
        # instead of O(n) in the interpreter -- the same output, ~100x faster.
        x = raw / 32768.0
        y = _highpass_vectorized(x, alpha=0.995)
        rms = float(_np.sqrt(_np.mean(_np.square(y))) + 1e-8)
        target_rms = 0.11
        gain = min(4.0, max(0.55, target_rms / rms))
        y *= gain
        peak = float(_np.max(_np.abs(y)) + 1e-8)
        if peak > 0.92:
            y *= 0.92 / peak
        cleaned = _np.clip(y * 32768.0, -32768, 32767).astype(_np.int16)
        return sr.AudioData(cleaned.tobytes(), audio.sample_rate, audio.sample_width)
    except Exception as error:
        print("Audio gain/high-pass skipped (using raw audio):", error)
        return audio


def _start_voice_engine_preload():
    """Load the local speech model in the background, before it is needed.

    `friday_voice_engine` is behind the _LazyModule shim, so without this it
    would not even be IMPORTED until the first attempt to transcribe -- meaning
    the first command a user speaks paid the model download/load plus the first
    (uncached) inference, on top of everything else. That is the single worst
    case of the "why is FRIDAY so slow to recognise me" complaint.

    This runs on a daemon thread and never blocks startup: if Faster-Whisper is
    missing or fails to load, recognition simply falls back to Google STT
    exactly as before.
    """
    if STT_ENGINE not in {"auto", "faster-whisper", "whisper", "local"}:
        return

    def _worker():
        try:
            if not friday_voice_engine.faster_whisper_available():
                print("Local speech model unavailable; using Google STT.", flush=True)
                return
            started = time.time()
            friday_voice_engine.preload(blocking=True)
            if friday_voice_engine.is_ready():
                print(f"🧠 Local speech model ready in {time.time() - started:.1f}s.", flush=True)
            else:
                print("Local speech model failed to load; using Google STT:",
                      friday_voice_engine.load_error(), flush=True)
        except Exception as error:
            print("Speech model preload skipped:", error, flush=True)

    threading.Thread(target=_worker, name="friday-stt-preload", daemon=True).start()


def _whisper_engine_active():
    """True when local Faster-Whisper is both selected and actually usable."""
    if STT_ENGINE not in {"auto", "faster-whisper", "whisper", "local"}:
        return False
    try:
        return bool(friday_voice_engine.faster_whisper_available())
    except Exception:
        return False


def _enhance_audio(audio):
    """High-pass + AGC, and (only for the Google STT path) noise suppression.

    v88 LATENCY FIX. The previous version ran the pipeline as
        high-pass/AGC -> noisereduce -> high-pass/AGC
    i.e. the filter twice and a full non-stationary spectral gate in between,
    on every utterance, before recognition could start.

    Two changes:

    1. The filter now runs ONCE. Running it a second time after denoising
       re-applied a high-pass to an already high-passed signal and re-ran AGC
       on a signal that was already at target RMS -- it changed almost nothing
       audible and doubled the cost.

    2. `noisereduce` with stationary=False is an STFT-based spectral gate and
       is the single most expensive step in the pipeline (often several hundred
       ms on a multi-second capture). Whisper is trained on noisy, real-world
       audio and has its own VAD; spectral gating in front of it removes
       information and measurably HURTS accuracy as well as costing time. It is
       genuinely useful for Google STT, so it is kept there and skipped when
       Whisper is the active engine. Force it back on with
       FRIDAY_FORCE_DENOISE=1 if your room is exceptionally noisy.
    """
    try:
        filtered = _audio_highpass_and_normalize(audio)
        force_denoise = os.getenv("FRIDAY_FORCE_DENOISE", "0").strip().lower() in {"1", "true", "yes", "on"}
        # Fast conversational mode skips the expensive spectral gate by default.
        # Google STT already performs server-side acoustic processing, while the
        # existing PCM VAD still rejects background silence. Users can force the
        # old denoising path with FRIDAY_FORCE_DENOISE=1.
        fast_voice = os.getenv("FRIDAY_FAST_AUDIO", "1").strip().lower() in {"1", "true", "yes", "on"}
        # In advanced voice mode, the acoustic front-end is allowed to use
        # spectral suppression for Google STT. Whisper remains protected from
        # unnecessary preprocessing unless explicitly requested.
        advanced_frontend = os.getenv("FRIDAY_ADVANCED_AUDIO", "1").strip().lower() in {"1", "true", "yes", "on"}
        if force_denoise or advanced_frontend or (not fast_voice and not _whisper_engine_active()):
            filtered = _denoise_audio(filtered)
        return filtered
    except Exception as error:
        print("Audio enhancement skipped (using raw audio):", error)
        return audio


def _denoise_audio(audio):
    """Takes an sr.AudioData, runs spectral-gating noise reduction on
    it, and returns a new sr.AudioData with the cleaned samples --
    or the ORIGINAL audio unchanged if noisereduce/numpy aren't
    installed or anything about the audio format is unexpected.
    Never raises."""
    if not _NOISE_SUPPRESSION_AVAILABLE:
        return audio
    try:
        sample_width = audio.sample_width
        if sample_width != 2:
            return audio  # only handling the common 16-bit case
        raw = _np.frombuffer(audio.get_raw_data(), dtype=_np.int16).astype(_np.float32)
        if raw.size == 0:
            return audio
        cleaned = _noisereduce.reduce_noise(y=raw, sr=audio.sample_rate, stationary=False)
        cleaned = _np.clip(cleaned, -32768, 32767).astype(_np.int16)
        return sr.AudioData(cleaned.tobytes(), audio.sample_rate, sample_width)
    except Exception as error:
        print("Noise suppression skipped (falling back to raw audio):", error)
        return audio

# Self-echo suppression. With speakers (not headphones) the mic *will*
# pick up Friday's own voice right after speak() finishes. Without
# this, any spoken reply that happens to contain a trigger phrase --
# "study mode" being the worst offender -- gets re-recognized as a
# fresh command and causes Friday to repeat itself forever. speak()
# records what it just said (normalized); listen() throws away
# anything that looks like a echo of that instead of treating it as
# a real command.
_LAST_SPOKEN_NORMALIZED = ""
_SPOKEN_HISTORY = collections.deque(maxlen=12)   # (time, normalised text) of what FRIDAY said recently - see _v5_recent_spoken()

# All of Google's alternative transcriptions for the most recent
# utterance (see _recognize_best_match). Used to improve WhatsApp
# contact-name accuracy -- if the chosen transcript's name doesn't
# match a known contact, we can check whether a lower-ranked
# alternative heard the name more clearly.
_LAST_RECOGNITION_ALTERNATIVES = []
_LAST_RECOGNITION_CONFIDENCE = 0.0
_LAST_WAKE_DETECTED = False


def _set_voice_active(active: bool, reason: str = ""):
    """Set the conversational voice state and publish it to the Electron HUD."""
    global VOICE_ACTIVE
    active = bool(active)
    changed = VOICE_ACTIVE != active
    VOICE_ACTIVE = active
    state = "ACTIVE" if active else "STANDBY"
    if changed or reason:
        log_event(
            f"Voice state: {state}" + (f" ({reason})" if reason else ""),
            kind="voice_state",
        )
    try:
        print(f"FRIDAY_VOICE_STATE::{state}", flush=True)
        # v89: also emit the VOICE_MODE:: marker main.js already listens
        # for (previously only printed once at startup), so the dashboard
        # header ("STANDBY — SAY FRIDAY" / "ACTIVE — READY") actually
        # follows every later wake-word / standby-command / idle-timeout
        # transition instead of freezing at whatever it showed on launch.
        print(f"VOICE_MODE::{state}", flush=True)
    except Exception:
        pass


def _is_standby_command(text: str) -> bool:
    """Recognize natural variations of the explicit standby instruction."""
    low = re.sub(r"\s+", " ", (text or "").strip().lower())
    return bool(re.fullmatch(
        r"(?:please )?(?:go )?(?:on )?stand[ -]?by(?: mode)?[.!]?", low
    ))
# True only after the wake word has been detected. In active mode the user
# can speak naturally until saying "standby".
_VOICE_SESSION_ACTIVE = not VOICE_SESSION_STARTS_IN_STANDBY


def _normalize_for_echo_check(text):
    return re.sub(r"[^a-z0-9 ]", "", text.lower()).strip()


# Optional callback the UI (or any caller) can set to be notified the
# instant audio capture finishes and Google speech-to-text starts, e.g.:
#   friday_7.ON_RECOGNIZING_HOOK = lambda: BRIDGE.state_changed.emit("recognizing")
# Left as None normally -- listen() only calls it if it's set, and any
# error inside the hook itself is swallowed so a UI bug can never break
# speech recognition.
ON_RECOGNIZING_HOOK = None


# ------------------------------------------------------------
# PERSISTENT MICROPHONE STREAM
# ------------------------------------------------------------
# v88 LATENCY FIX.
#
# listen() used to do this on EVERY utterance:
#
#     calibrate_microphone()                      # opens a PortAudio stream,
#                                                 # samples 0.5s, closes it
#     with sr.Microphone(...) as source:          # opens a SECOND stream
#         recognizer.listen(source, ...)          # ...then closes it again
#
# Opening a PortAudio input stream is not free -- it is typically 150-600 ms
# depending on the driver (and worse on Windows with exclusive-mode or
# Bluetooth devices). Doing it twice per command, plus a half-second ambient
# sample, added up to roughly a second of pure overhead before FRIDAY had
# heard a single word.
#
# The stream is now opened once and kept open. Two details make that safe:
#
#   * Ambient recalibration reuses the already-open stream instead of
#     opening a new one.
#   * Audio that arrives while FRIDAY is speaking or thinking would otherwise
#     sit in the PortAudio buffer and be consumed at the start of the next
#     listen() -- which is how an assistant ends up transcribing its own TTS.
#     _flush_microphone_buffer() discards that backlog before each capture.
#
# Set FRIDAY_PERSISTENT_MIC=0 to fall back to the old open-per-utterance
# behaviour if a particular audio driver misbehaves.
_PERSISTENT_MIC_ENABLED = os.getenv("FRIDAY_PERSISTENT_MIC", "1").strip().lower() in {"1", "true", "yes", "on"}
_persistent_mic = None
_persistent_mic_source = None
_mic_lock = threading.RLock()


def _new_microphone():
    """Create the requested input device, with a safe default-device fallback."""
    if MICROPHONE_INDEX is None:
        return sr.Microphone()
    try:
        return sr.Microphone(device_index=MICROPHONE_INDEX)
    except Exception as error:
        print(f"Configured microphone {MICROPHONE_INDEX} is unavailable; using Windows default: {error}")
        return sr.Microphone()


def _open_persistent_microphone():
    """Open (once) and return the shared microphone source, or None."""
    global _persistent_mic, _persistent_mic_source
    with _mic_lock:
        if _persistent_mic_source is not None:
            return _persistent_mic_source
        try:
            microphone = _new_microphone()
            source = microphone.__enter__()
            _persistent_mic = microphone
            _persistent_mic_source = source
            return source
        except Exception as error:
            print("Persistent microphone unavailable, using per-utterance mode:", error)
            _persistent_mic = None
            _persistent_mic_source = None
            return None


def _close_persistent_microphone():
    """Close the shared microphone so the next call reopens it cleanly."""
    global _persistent_mic, _persistent_mic_source
    with _mic_lock:
        microphone = _persistent_mic
        _persistent_mic = None
        _persistent_mic_source = None
    if microphone is not None:
        try:
            microphone.__exit__(None, None, None)
        except Exception:
            pass


def _flush_microphone_buffer(source):
    """Discard audio captured while FRIDAY was speaking or processing.

    Without this, the first thing the next capture reads is stale buffered
    audio -- usually FRIDAY's own text-to-speech -- which both wastes a
    recognition pass and causes self-triggering.
    """
    try:
        stream = getattr(source, "stream", None)
        pyaudio_stream = getattr(stream, "pyaudio_stream", None)
        if pyaudio_stream is None:
            return
        chunk = getattr(source, "CHUNK", 1024) or 1024
        # Bounded so a misreporting driver can never spin here forever.
        for _ in range(256):
            try:
                available = pyaudio_stream.get_read_available()
            except Exception:
                return
            if available is None or available < chunk:
                return
            try:
                pyaudio_stream.read(chunk, exception_on_overflow=False)
            except Exception:
                return
    except Exception:
        return


class _MicrophoneSession:
    """Yields a usable microphone source, persistent when possible.

    Falls back transparently to opening a temporary stream if the persistent
    one is disabled or failed to open, so listen() has a single code path.
    """

    def __init__(self):
        self._temporary = None

    def __enter__(self):
        if _PERSISTENT_MIC_ENABLED:
            source = _open_persistent_microphone()
            if source is not None:
                _flush_microphone_buffer(source)
                return source
        self._temporary = _new_microphone()
        return self._temporary.__enter__()

    def __exit__(self, exc_type, exc_value, traceback):
        if self._temporary is not None:
            try:
                self._temporary.__exit__(exc_type, exc_value, traceback)
            except Exception:
                pass
            self._temporary = None
        elif exc_type is not None:
            # The shared stream may be in a bad state after an error; drop it
            # so the next listen() starts from a fresh device handle.
            _close_persistent_microphone()
        return False


def calibrate_microphone(source=None):
    """Calibrate the selected microphone. Runs again (not just once
    per process) whenever _maybe_force_recalibration() has cleared
    _MIC_CALIBRATED -- see the adaptive noise floor block above.

    When `source` is an already-open microphone, it is reused instead of
    opening another PortAudio stream (see the persistent-microphone note
    above). The ambient sample is also shorter now: 0.5s of silence before
    every capture was itself a noticeable part of the perceived delay, and
    0.25s is ample for a first-order noise-floor estimate that is re-taken
    every 10 minutes anyway.
    """
    global _MIC_CALIBRATED, _last_calibration_time
    if _MIC_CALIBRATED:
        return
    duration = float(os.getenv("FRIDAY_CALIBRATION_SECONDS", "0.25"))
    try:
        if source is not None:
            print("🎤 Calibrating microphone...", flush=True)
            recognizer.adjust_for_ambient_noise(source, duration=duration)
        else:
            with _new_microphone() as fresh_source:
                print("🎤 Calibrating microphone...", flush=True)
                recognizer.adjust_for_ambient_noise(fresh_source, duration=duration)
        _MIC_CALIBRATED = True
        _last_calibration_time = time.time()
        print("🎤 Microphone ready.", flush=True)
    except Exception as error:
        print("Microphone calibration error:", error)


# Friday's own real command vocabulary, used only to re-rank Google's
# alternative transcriptions below -- this is NOT a language model,
# just a plain closest-match check against phrases this script already
# recognizes elsewhere in handle_command()/handle_study_command().
# Kept in one place so recognition can favor "study mode" over a
# similar-sounding but wrong top guess without needing a wake word or
# a heavier NLP dependency.
_KNOWN_COMMAND_PHRASES = [
    "open Chrome", "open WhatsApp", "search Google", "show Google search results",
    "weather", "take a screenshot", "what is on my screen", "close the app",
    "send a WhatsApp message", "call on WhatsApp", "research this",
    "search for", "play YouTube", "play Spotify", "find my files",
    "create a document", "make a Word document", "make a PDF", "make a presentation",
    "save money", "show my budget", "show reports", "income", "expense",
    "savings goal", "monthly plan", "how much is left", "standby", "goodbye",
]


# ============================================================
# SEMANTIC (EMBEDDING-BASED) COMMAND MATCHING
# ------------------------------------------------------------
# _recognize_best_match() below already re-ranks Google's alternative
# transcriptions against _KNOWN_COMMAND_PHRASES using plain text
# similarity (difflib). That catches near-miss SPELLING but misses
# near-miss MEANING -- e.g. "how chilly is it outside" has low text
# overlap with "how's the weather" even though it's the same intent.
#
# This adds a second, semantic pass using Gemini's embedding model:
# each known phrase is embedded once (cached), and when the text-based
# pass isn't confident, each alternative transcript is embedded too and
# compared by cosine similarity. This only runs when needed (keeps
# every clearly-recognized command just as fast as before) and is
# wrapped so any embedding failure (offline, bad key, model renamed,
# SDK shape mismatch) silently leaves the original text-based result
# untouched -- this is a pure enhancement layer, never a dependency.
# ============================================================

_KNOWN_PHRASE_EMBEDDINGS = None      # None = not attempted yet, [] = attempted + unavailable
_EMBEDDING_CACHE = {}                # small in-memory cache: text -> vector


def _get_embedding(text):
    """Return a list[float] embedding for text, or None if unavailable.
    Never raises -- every failure mode just means 'no embedding this time'."""
    if not text or not text.strip():
        return None
    cached = _EMBEDDING_CACHE.get(text)
    if cached is not None:
        return cached
    _ensure_gemini_client()
    if client is None:
        return None
    try:
        result = client.models.embed_content(model=EMBEDDING_MODEL, contents=text)
        vector = None
        embeddings = getattr(result, "embeddings", None)
        if embeddings:
            first = embeddings[0]
            vector = list(getattr(first, "values", None) or first)
        elif getattr(result, "embedding", None) is not None:
            single = result.embedding
            vector = list(getattr(single, "values", None) or single)
        if vector:
            _EMBEDDING_CACHE[text] = vector
            return vector
    except Exception as error:
        print("Embedding call skipped (falling back to text similarity):", error)
    return None


def _cosine_similarity(a, b):
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def _ensure_known_phrase_embeddings():
    """Lazily embeds every entry in _KNOWN_COMMAND_PHRASES exactly
    once. If embeddings aren't available at all (offline / no key /
    unsupported model), this settles on [] immediately so later calls
    don't keep retrying and slowing down every ambiguous command."""
    global _KNOWN_PHRASE_EMBEDDINGS
    if _KNOWN_PHRASE_EMBEDDINGS is not None:
        return
    embeddings = []
    for phrase in _KNOWN_COMMAND_PHRASES:
        vector = _get_embedding(phrase)
        if vector is not None:
            embeddings.append((phrase, vector))
        else:
            # First failure almost certainly means every subsequent
            # call will fail too (no client / no network) -- stop
            # early instead of making ~40 doomed API calls.
            break
    _KNOWN_PHRASE_EMBEDDINGS = embeddings


def _semantic_best_match(transcripts):
    """Returns (best_transcript, best_score) using embeddings, or
    (None, 0.0) if semantic matching isn't available right now."""
    try:
        _ensure_known_phrase_embeddings()
        if not _KNOWN_PHRASE_EMBEDDINGS:
            return None, 0.0
        best_transcript, best_score = None, 0.0
        for candidate in transcripts:
            vector = _get_embedding(candidate)
            if vector is None:
                continue
            score = max(_cosine_similarity(vector, kv) for _, kv in _KNOWN_PHRASE_EMBEDDINGS)
            if score > best_score:
                best_transcript, best_score = candidate, score
        return best_transcript, best_score
    except Exception as error:
        print("Semantic command matching skipped:", error)
        return None, 0.0


def _call_google_stt(audio):
    """Call Google's free Web Speech API and never let it kill the utterance.

    Before this, an unhandled failure here (network hiccup, a rate-limited
    request, or -- notably -- Python 3.13 removing the stdlib ``audioop``
    module that older SpeechRecognition releases still call into for FLAC
    encoding) propagated all the way out of _recognize_best_match() with no
    try/except of its own. listen()'s outer handler then caught it as a
    generic "Microphone error", printed one console line, and returned ""
    with nothing spoken -- so whenever this was the only STT engine actually
    working (e.g. faster-whisper not installed), EVERY utterance failed
    completely silently: FRIDAY looked like it never recognized or replied
    at all. This wraps the call so a failure here degrades to "didn't catch
    that" (handled and spoken by listen()) instead of vanishing silently.
    """
    try:
        return recognizer.recognize_google(
            audio, language=SPEECH_RECOGNITION_LANGUAGE, show_all=True
        )
    except sr.UnknownValueError:
        raise
    except sr.RequestError:
        raise
    except ModuleNotFoundError as error:
        if "audioop" in str(error).lower():
            print(
                "Google STT failed: the 'audioop' stdlib module was removed in "
                "Python 3.13 and this SpeechRecognition install still needs it. "
                "Run: pip install audioop-lts",
                flush=True,
            )
        else:
            print("Google STT failed (missing module):", error, flush=True)
        return None
    except Exception as error:
        print("Google STT failed:", error, flush=True)
        return None



def _transcript_command_score(text):
    """Text similarity to known FRIDAY commands, used only as a tie-breaker."""
    if not text:
        return 0.0
    norm = _normalize_spoken_symbols(text).lower().strip()
    return max(
        (difflib.SequenceMatcher(None, norm, phrase.lower()).ratio()
         for phrase in _KNOWN_COMMAND_PHRASES),
        default=0.0,
    )


def _accuracy_select_google(alternatives, google_conf):
    """Select a transcript using Google alternatives + semantic evidence.

    The capture mechanism is untouched. This is strictly a post-capture
    recognition decision layer. Ordinary prose remains Google's top result
    unless there is strong evidence for another candidate.
    """
    if not alternatives:
        return "", google_conf or 0.0

    top = alternatives[0]
    selected = top
    top_text_score = _transcript_command_score(top)

    # First: command-aware text matching. Require a meaningful margin.
    best_text = top
    best_text_score = top_text_score
    for candidate in alternatives[:8]:
        score = _transcript_command_score(candidate)
        if score > best_text_score:
            best_text, best_text_score = candidate, score
    if best_text != top and best_text_score >= 0.82 and (best_text_score - top_text_score) >= 0.10:
        selected = best_text

    # Semantic matching is intentionally NOT on the normal fast path. It can
    # require network embedding calls and made otherwise-clear speech wait.
    # The deep-verification path below can still use it for genuinely ambiguous
    # short commands, preserving the accuracy layer without taxing every reply.

    confidence = google_conf if google_conf is not None else 0.70
    # A very strong command match is useful evidence even when Google's
    # response omitted its numeric confidence.
    confidence = max(confidence, min(0.97, 0.55 + 0.42 * _transcript_command_score(selected)))
    return selected, confidence


def _should_deep_verify(text, audio):
    """Return True only when a Google result deserves extra recognition work."""
    if not text or not STT_FAST_PATH or STT_ACCURACY_MODE != "high":
        return False
    words = re.findall(r"\b[\w']+\b", text)
    command_score = _transcript_command_score(text)
    # Clear known commands do not need a second network/Whisper pass.
    if command_score >= 0.82:
        return False
    # Action commands are worth checking only when the transcript is weak or
    # unusually unlike FRIDAY's known command vocabulary.
    if re.search(r"\b(?:open|close|launch|start|click|press|type|delete|send|search|play|scroll|switch|shutdown|restart)\b", text, re.I):
        return command_score < 0.62
    if len(words) <= STT_DEEP_VERIFY_WORDS:
        return command_score < 0.72
    try:
        duration = len(audio.get_raw_data()) / float(audio.sample_rate * 2)
        return duration <= STT_DEEP_VERIFY_MAX_SECONDS and len(words) <= 6
    except Exception:
        return len(words) <= 6


def _local_verify_google(audio, google_text, google_conf, *, force=False):
    """Cross-check only an actually ambiguous Google result with local Whisper."""
    if STT_ACCURACY_MODE != "high" or not google_text:
        return google_text, google_conf
    if not force and not _should_deep_verify(google_text, audio):
        return google_text, google_conf
    try:
        if not friday_voice_engine.is_ready():
            return google_text, google_conf
        local_text = friday_voice_engine.transcribe_pcm(
            audio.get_raw_data(),
            sample_rate=audio.sample_rate,
            channels=1,
            wait_for_model=False,
        )
        if not local_text:
            return google_text, google_conf
        local_conf = float(friday_voice_engine.last_transcription_confidence())
        if local_conf <= 0:
            return google_text, google_conf

        google_cmd = _transcript_command_score(google_text)
        local_cmd = _transcript_command_score(local_text)
        # Only replace a clear Google result when Whisper has materially
        # stronger evidence or a very strong command match.
        if local_conf >= google_conf + 0.12 or (
            local_cmd >= 0.90 and google_cmd < 0.75 and local_conf >= 0.55
        ):
            return local_text, max(google_conf, local_conf)
        return google_text, max(google_conf, min(local_conf, google_conf + 0.05))
    except Exception:
        return google_text, google_conf


def _deep_google_alternatives(audio, selected, google_conf):
    """Use Google's alternatives only when the fast transcript is ambiguous."""
    try:
        result = recognizer.recognize_google(
            audio, language=SPEECH_RECOGNITION_LANGUAGE, show_all=True
        )
        if not isinstance(result, dict):
            return selected, google_conf, [selected] if selected else []
        alternatives = []
        for item in (result.get("alternative") or []):
            candidate = str(item.get("transcript", "") or "").strip()
            if candidate and candidate not in alternatives:
                alternatives.append(candidate)
        if not alternatives:
            return selected, google_conf, [selected] if selected else []
        raw_conf = None
        try:
            raw_conf = result.get("alternative", [])[0].get("confidence")
        except Exception:
            pass
        conf = max(0.0, min(1.0, float(raw_conf))) if raw_conf is not None else (google_conf or 0.70)
        selected, conf = _accuracy_select_google(alternatives, conf)
        # Semantic matching is now reserved for this genuinely ambiguous path.
        if len(alternatives) > 1 and STT_ACCURACY_MODE == "high":
            try:
                semantic_text, semantic_score = _semantic_best_match(alternatives[:8])
                if semantic_text and semantic_score >= 0.86:
                    selected = semantic_text
            except Exception:
                pass
        return selected, conf, alternatives[:8]
    except Exception:
        return selected, google_conf, [selected] if selected else []


def _recognize_hybrid(audio):
    global _LAST_RECOGNITION_CONFIDENCE, _LAST_RECOGNITION_ALTERNATIVES
    """Low-latency hybrid STT.

    Google remains the fast primary path. A warm local Whisper decoder is
    started in parallel, but a clear Google result is returned immediately
    instead of waiting for CPU Whisper to finish. Whisper is only allowed to
    arbitrate when the Google result is genuinely ambiguous/weak. This keeps
    the V2029 hybrid architecture and all downstream command handling intact,
    while removing the main V2030 latency regression on CPU machines.
    """
    from concurrent.futures import ThreadPoolExecutor

    pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="friday-asr")
    google_future = pool.submit(_recognize_google_for_hybrid, audio)
    # V2032: Google is the critical-path recognizer. Do NOT start CPU Whisper
    # speculatively for every utterance; on laptops that background decode can
    # steal CPU from Google/audio/TTS and make the whole assistant feel slower.
    # Whisper is launched only when the Google result is genuinely ambiguous.
    local_future = None

    try:
        google_text, google_conf, google_alts = google_future.result()
        google_text = str(google_text or "").strip()
        if not google_text:
            raise sr.UnknownValueError()

        # Clear command/question: do not wait for Whisper. This is the key
        # latency fix. Local Whisper may continue in the background and is
        # intentionally not part of the critical response path.
        google_cmd = _transcript_command_score(google_text)
        clear_google = (
            float(google_conf or 0.0) >= 0.78
            and google_cmd >= 0.55
            and not _should_deep_verify(google_text, audio)
        )
        if clear_google or local_future is None:
            selected = google_text
            selected_conf = float(google_conf or 0.70)
            _LAST_RECOGNITION_CONFIDENCE = max(0.0, min(1.0, selected_conf))
            _LAST_RECOGNITION_ALTERNATIVES = list(google_alts or [selected])[:8]
            _update_human_speech_rate(selected)
            return selected

        # Only ambiguous/low-confidence speech pays the local Whisper cost.
        if local_future is None and friday_voice_engine.is_ready():
            local_future = pool.submit(_recognize_local_for_hybrid, audio)
        try:
            local_text, local_conf, _ = (local_future.result(timeout=float(os.getenv("FRIDAY_LOCAL_ASR_TIMEOUT", "4.0")))
                                         if local_future is not None else (None, 0.0, []))
        except Exception:
            local_text, local_conf = None, 0.0

        candidates = [("google", google_text, float(google_conf or 0.0), google_cmd)]
        if local_text:
            local_text = str(local_text).strip()
            candidates.append(("whisper", local_text, float(local_conf or 0.0), _transcript_command_score(local_text)))

        candidates.sort(key=lambda x: 0.62 * x[2] + 0.38 * x[3], reverse=True)
        _, selected, conf, _ = candidates[0]
        if len(candidates) > 1:
            other = candidates[1]
            best_score = 0.62 * conf + 0.38 * candidates[0][3]
            other_score = 0.62 * other[2] + 0.38 * other[3]
            if other[3] >= 0.90 and other[1].lower() != selected.lower() and other_score >= best_score - 0.06:
                selected, conf = other[1], other[2]

        _LAST_RECOGNITION_CONFIDENCE = max(0.0, min(1.0, conf))
        _LAST_RECOGNITION_ALTERNATIVES = [c[1] for c in candidates]
        _update_human_speech_rate(selected)
        return selected
    except sr.RequestError:
        # If Google is unavailable, use the local model without changing the
        # existing fallback behavior.
        if local_future is not None:
            try:
                text, conf, _ = local_future.result(timeout=6.0)
                if text:
                    _LAST_RECOGNITION_CONFIDENCE = float(conf or 0.75)
                    _LAST_RECOGNITION_ALTERNATIVES = [text]
                    _update_human_speech_rate(text)
                    return text
            except Exception:
                pass
        raise
    finally:
        # Do not wait for the background Whisper job after a fast Google result.
        # Python's executor threads are daemon-managed by the runtime only after
        # their work completes; shutdown(wait=False) lets the voice loop proceed.
        try:
            pool.shutdown(wait=False, cancel_futures=False)
        except TypeError:
            pool.shutdown(wait=False)

def _recognize_google_for_hybrid(audio):
    result = recognizer.recognize_google(
        audio, language=SPEECH_RECOGNITION_LANGUAGE, show_all=True
    )
    if isinstance(result, dict):
        alts = []
        for item in (result.get("alternative") or []):
            text = str(item.get("transcript", "") or "").strip()
            if text and text not in alts:
                alts.append(text)
        if not alts:
            raise sr.UnknownValueError()
        raw_conf = None
        try:
            raw_conf = result["alternative"][0].get("confidence")
        except Exception:
            pass
        conf = float(raw_conf) if raw_conf is not None else 0.70
        selected, conf = _accuracy_select_google(alts, max(0.0, min(1.0, conf)))
        return selected, conf, alts
    text = str(result or "").strip()
    if not text:
        raise sr.UnknownValueError()
    return text, max(0.70, min(0.97, 0.55 + 0.42 * _transcript_command_score(text))), [text]


def _recognize_local_for_hybrid(audio):
    text = friday_voice_engine.transcribe_pcm(
        audio.get_raw_data(), sample_rate=audio.sample_rate, channels=1, wait_for_model=False
    )
    if not text:
        return None, 0.0, []
    try:
        conf = float(friday_voice_engine.last_transcription_confidence())
    except Exception:
        conf = 0.75
    return text, conf, [text]


def _recognize_best_match(audio):
    """Low-latency STT router.

    V2034 observes recognition latency without adding a wait to the voice path.
    ``auto`` deliberately uses the v2012 Google SpeechRecognition path first:
    it avoids waiting for a cold/local Whisper model. Local Faster-Whisper is
    still available explicitly and is the fallback when Google cannot answer.
    """
    global _LAST_RECOGNITION_CONFIDENCE, _LAST_RECOGNITION_ALTERNATIVES

    try:
        profile=_analyze_user_audio(audio)
        if profile:
            profile["duration_s"]=max(0.0,len(audio.get_raw_data())/float(audio.sample_rate*2))
            _LAST_ACOUSTIC_PROFILE.update(profile)
    except Exception: pass

    def google_fast():
        try:
            # FAST PATH: one normal Google recognition request. This is the same
            # proven Google-first STT engine, but without requesting the full
            # alternatives payload on every utterance.
            selected = recognizer.recognize_google(
                audio, language=SPEECH_RECOGNITION_LANGUAGE, show_all=False
            )
            selected = str(selected or "").strip()
            if not selected:
                raise sr.UnknownValueError()

            # Google often omits a numeric confidence on the normal response.
            # Use a conservative baseline and only spend extra time when the
            # transcript looks ambiguous. Clear speech therefore reaches the
            # command/AI pipeline immediately.
            selected_conf = max(0.70, min(0.97, 0.55 + 0.42 * _transcript_command_score(selected)))
            alternatives = [selected]

            if _should_deep_verify(selected, audio):
                selected, selected_conf, alternatives = _deep_google_alternatives(
                    audio, selected, selected_conf
                )
                selected, selected_conf = _local_verify_google(
                    audio, selected, selected_conf, force=True
                )

            _LAST_RECOGNITION_CONFIDENCE = selected_conf
            _LAST_RECOGNITION_ALTERNATIVES = alternatives[:8]
            if selected and selected not in _LAST_RECOGNITION_ALTERNATIVES:
                _LAST_RECOGNITION_ALTERNATIVES.insert(0, selected)
                _LAST_RECOGNITION_ALTERNATIVES = _LAST_RECOGNITION_ALTERNATIVES[:8]
            _update_human_speech_rate(selected)
            return selected
        except Exception:
            raise

    def local_fast():
        local_text = friday_voice_engine.transcribe_pcm(
            audio.get_raw_data(),
            sample_rate=audio.sample_rate,
            channels=1,
            wait_for_model=False,
        )
        if local_text:
            try:
                _LAST_RECOGNITION_CONFIDENCE = float(
                    friday_voice_engine.last_transcription_confidence()
                )
            except Exception:
                _LAST_RECOGNITION_CONFIDENCE = 0.75
            _LAST_RECOGNITION_ALTERNATIVES = [local_text]
            _update_human_speech_rate(local_text)
            return local_text
        return ""

    if STT_ENGINE in {"hybrid", "dual", "ensemble"}:
        try:
            return _recognize_hybrid(audio)
        except sr.UnknownValueError:
            # If both decoders fail, preserve the normal retry behavior.
            raise
        except sr.RequestError as error:
            print("Hybrid cloud STT unavailable; trying local recognition:", error, flush=True)
            try:
                text = local_fast()
                if text:
                    return text
            except Exception:
                pass
            raise sr.UnknownValueError()
        except Exception as error:
            print("Hybrid STT failed; falling back to existing recognition:", error, flush=True)
            # Preserve the original Google-first router exactly as fallback.
            pass

    if STT_ENGINE in {"auto", "google", "speech-recognition"}:
        try:
            return google_fast()
        except sr.UnknownValueError:
            raise
        except sr.RequestError as error:
            print("Google STT unavailable; trying local recognition:", error, flush=True)
        except Exception as error:
            print("Google STT fast path failed; trying local recognition:", error, flush=True)
        if STT_ENGINE == "google":
            raise sr.UnknownValueError()
        try:
            text = local_fast()
            if text:
                return text
        except Exception as error:
            print("Faster-Whisper fallback unavailable/failed:", error, flush=True)
        raise sr.UnknownValueError()

    # Explicit local mode remains available for offline/privacy-oriented use.
    if STT_ENGINE in {"faster-whisper", "whisper", "local"}:
        try:
            text = local_fast()
            if text:
                return text
        except Exception as error:
            print("Faster-Whisper failed; falling back to Google STT:", error, flush=True)
        return google_fast()

    # Unknown setting: fail safely into the proven Google path.
    return google_fast()

def _contextual_correct_transcript(text):
    """Correct recognition using the active FRIDAY context and known command vocabulary.

    This is intentionally conservative: it only changes a transcript when a
    strong fuzzy/semantic match exists, or when the context engine supplies a
    clear referent for words such as "it", "that" and "the results".
    """
    if not text:
        return text
    fixed = _normalize_spoken_symbols(_apply_common_corrections(text)).strip()
    try:
        referent = friday_agent_core.resolve_reference(fixed)
        if referent and re.search(r"\b(it|this|that|these|those|the results|the research|the file|the topic)\b", fixed, re.I):
            # Preserve the user's request while making the referent explicit
            # for downstream intent classification.
            fixed = re.sub(
                r"\b(it|this|that|these|those|the results|the research|the file|the topic)\b",
                lambda m: f"{m.group(0)} ({referent})", fixed, count=1, flags=re.I
            )
    except Exception:
        pass
    return fixed


def _wake_word_in_recognition_candidates(text: str) -> bool:
    """Check the primary transcript and every STT alternative for wake words.

    In standby we must not let a low-confidence top transcript prevent a wake
    when another candidate clearly heard the user's wake word. This is the key
    recovery path for phrases such as "Friday, open Chrome" that occasionally
    arrive with a bad top decode.
    """
    candidates = [text or ""] + list(_LAST_RECOGNITION_ALTERNATIVES or [])
    for candidate in candidates:
        normalized = _apply_common_corrections(candidate).strip().lower()
        if re.search(r"(?<!\w)friday(?!\w)", normalized):
            return True
        # Conservative phonetic fallbacks for common STT splits/mishearings.
        if re.search(r"(?<!\w)(?:fri[ -]?day|fry[ -]?day|fridai)(?!\w)", normalized):
            return True
    return False


def _best_wake_candidate(text: str) -> str:
    """Return the strongest recognition candidate containing the wake word."""
    candidates = [text or ""] + list(_LAST_RECOGNITION_ALTERNATIVES or [])
    for candidate in candidates:
        fixed = _apply_common_corrections(candidate).strip()
        if re.search(r"(?<!\w)friday(?!\w)", fixed, flags=re.I):
            return fixed
    for candidate in candidates:
        fixed = _apply_common_corrections(candidate).strip()
        if re.search(r"(?<!\w)(?:fri[ -]?day|fry[ -]?day|fridai)(?!\w)", fixed, flags=re.I):
            fixed = re.sub(r"\b(?:fri[ -]?day|fry[ -]?day|fridai)\b", "friday", fixed, flags=re.I)
            return fixed
    return text or ""


def _strip_wake_word(text):
    """Return (wake_detected, remainder).

    FRIDAY wake detection is intentionally phrase-independent: any recognized
    sentence containing the standalone word ``friday`` activates the assistant.
    The first standalone occurrence is removed before command dispatch.

    Examples:
        "friday open chrome" -> ("open chrome")
        "hey friday what is the weather" -> ("hey what is the weather")
        "can you ask friday to open chrome" -> ("can you ask  to open chrome")
    """
    original = (text or "").strip()
    low = original.lower()

    # The project requirement is the standalone word, not a substring such as
    # "fridaying". Word boundaries also avoid matching names embedded in words.
    match = re.search(r"(?<!\w)friday(?!\w)", low, flags=re.IGNORECASE)
    if not match:
        return False, original

    remainder = (original[:match.start()] + " " + original[match.end():]).strip()
    remainder = re.sub(r"^[\s,;:—-]+|[\s,;:—-]+$", "", remainder)
    remainder = re.sub(r"\s{2,}", " ", remainder)

    # Natural wake prefixes are not part of the command itself.
    remainder = re.sub(
        r"^(?:hey|hi|hello|okay|ok|alright|all right)[\s,;:—-]+",
        "",
        remainder,
        flags=re.IGNORECASE,
    ).strip()

    return True, remainder


def _is_standby_command(text):
    """Return True for natural variants of the explicit standby command."""
    normalized = re.sub(r"[^a-z0-9\s-]", "", (text or "").lower())
    normalized = re.sub(r"\s+", " ", normalized).strip()
    return bool(re.search(r"\bstand(?:[ -]?by)\b", normalized))


def _pcm_energy(raw_bytes, sample_width):
    """Return RMS energy for one microphone chunk without audioop.

    Python 3.13 removed the stdlib ``audioop`` module, so the voice loop
    deliberately uses a tiny dependency-free RMS implementation. The
    microphone is normally 16-bit PCM; the other widths are handled too.
    """
    if not raw_bytes:
        return 0.0
    try:
        if sample_width == 2:
            import array
            samples = array.array("h")
            samples.frombytes(raw_bytes[:len(raw_bytes) - (len(raw_bytes) % 2)])
            if sys.byteorder != "little":
                samples.byteswap()
            if not samples:
                return 0.0
            total = 0.0
            for value in samples:
                total += float(value) * float(value)
            return math.sqrt(total / len(samples))
        if sample_width == 1:
            values = raw_bytes
            total = 0.0
            for value in values:
                x = float(value) - 128.0
                total += x * x
            return math.sqrt(total / max(1, len(values)))
        # Safe generic fallback for uncommon sample widths.
        width = max(1, int(sample_width))
        usable = len(raw_bytes) - (len(raw_bytes) % width)
        if usable <= 0:
            return 0.0
        total = 0.0
        count = 0
        for i in range(0, usable, width):
            x = int.from_bytes(raw_bytes[i:i + width], "little", signed=True)
            total += float(x) * float(x)
            count += 1
        return math.sqrt(total / max(1, count))
    except Exception:
        return 0.0


def _pcm_rms(raw_bytes, sample_width):
    """Return RMS for common PCM sample widths without audioop."""
    if not raw_bytes:
        return 0.0
    width = max(1, int(sample_width or 2))
    if width == 2:
        return _pcm_rms_int16(raw_bytes)
    try:
        usable = len(raw_bytes) - (len(raw_bytes) % width)
        if usable <= 0:
            return 0.0
        total = 0.0
        count = 0
        for i in range(0, usable, width):
            x = int.from_bytes(raw_bytes[i:i + width], "little", signed=(width != 1))
            if width == 1:
                x -= 128
            total += float(x) * float(x)
            count += 1
        return math.sqrt(total / max(1, count))
    except Exception:
        return 0.0



def _pcm_rms_int16(raw_bytes):
    """Return RMS for little-endian signed 16-bit PCM without audioop."""
    if not raw_bytes:
        return 0.0
    usable = len(raw_bytes) - (len(raw_bytes) % 2)
    if usable <= 0:
        return 0.0
    total = 0.0
    count = 0
    for i in range(0, usable, 2):
        sample = int.from_bytes(raw_bytes[i:i + 2], "little", signed=True)
        total += float(sample) * float(sample)
        count += 1
    return math.sqrt(total / max(1, count))


# If webrtcvad misbehaves at runtime (missing native extension, a corrupt
# install, an unexpected exception from is_speech(), etc.) we stop retrying
# it for the rest of this process instead of re-attempting a broken call on
# every ~64ms audio chunk -- capture simply keeps running on the existing
# adaptive RMS mechanism (_speech_decision() already treats a None ratio as
# "fall back to RMS alone"), so a webrtcvad failure can only ever degrade
# gracefully back to the original, proven capture path, never break capture.
_WEBRTC_VAD_INSTANCE = None
_WEBRTC_VAD_DISABLED = False


def _get_webrtc_vad_instance():
    """Build (once) and cache the Vad object; disable permanently on failure."""
    global _WEBRTC_VAD_INSTANCE, _WEBRTC_VAD_DISABLED
    if _WEBRTC_VAD_DISABLED:
        return None
    if _WEBRTC_VAD_INSTANCE is not None:
        return _WEBRTC_VAD_INSTANCE
    try:
        _WEBRTC_VAD_INSTANCE = _webrtcvad.Vad(WEBRTC_VAD_AGGRESSIVENESS)
        return _WEBRTC_VAD_INSTANCE
    except Exception as error:
        print(f"webrtcvad unavailable ({error}); using existing RMS voice detection instead.")
        _WEBRTC_VAD_DISABLED = True
        return None


def _webrtc_speech_ratio(raw_bytes, sample_rate, sample_width):
    """Estimate speech probability using WebRTC VAD over a chunk.

    WebRTC VAD accepts only mono 16-bit PCM at 8/16/32/48 kHz and frames of
    10/20/30 ms. The microphone path is normally 16-bit/16 kHz; unsupported
    formats, a missing/broken webrtcvad install, or any runtime failure all
    simply return None here, so the legacy adaptive RMS VAD (the existing,
    proven mechanism) remains fully in control of the speech decision --
    see _speech_decision() below.
    """
    global _WEBRTC_VAD_DISABLED
    if not ADVANCED_VAD_ENABLED or _webrtcvad is None or _WEBRTC_VAD_DISABLED:
        return None
    if sample_width != 2 or sample_rate not in (8000, 16000, 32000, 48000):
        return None
    frame_bytes = int(sample_rate * 0.03) * 2
    if frame_bytes <= 0 or len(raw_bytes) < frame_bytes:
        return None
    vad = _get_webrtc_vad_instance()
    if vad is None:
        return None
    try:
        usable = len(raw_bytes) - (len(raw_bytes) % frame_bytes)
        frames = raw_bytes[:usable]
        total = 0
        speech = 0
        for pos in range(0, len(frames), frame_bytes):
            frame = frames[pos:pos + frame_bytes]
            if len(frame) != frame_bytes:
                continue
            total += 1
            if vad.is_speech(frame, sample_rate):
                speech += 1
        return (speech / total) if total else 0.0
    except Exception as error:
        # A single bad frame/runtime error disables WebRTC VAD for the rest
        # of this process (rather than retrying and failing every chunk) and
        # falls back to the existing RMS-only mechanism from here on.
        print(f"webrtcvad failed during capture ({error}); falling back to existing RMS voice detection.")
        _WEBRTC_VAD_DISABLED = True
        return None


def _speech_decision(rms, webrtc_ratio, gate):
    """Fuse acoustic energy and speech-trained VAD without over-gating quiet voices."""
    loud = rms >= gate
    if webrtc_ratio is None:
        return loud
    # WebRTC is especially useful against fan/AC/keyboard noise. For quiet
    # far-field speech, allow a positive VAD decision slightly below the RMS
    # gate, but never allow an extremely weak digital signal through.
    floor = max(35.0, gate * 0.42)
    return (webrtc_ratio >= WEBRTC_VAD_MIN_RATIO and rms >= floor) or loud

def _adaptive_vad_pause_seconds():
    """Choose a responsive endpoint without cutting off natural pauses.

    V2033 keeps the same PCM+WebRTC capture mechanism, but adapts the
    post-speech silence window from the user's recent speech rate. Fast speech
    gets a slightly longer grace period; ordinary commands get the low-latency
    default. An explicit FRIDAY_VAD_PAUSE always wins.
    """
    explicit = os.getenv("FRIDAY_VAD_PAUSE", "").strip()
    if explicit:
        try:
            return max(0.65, min(5.0, float(explicit)))
        except Exception:
            pass
    base = max(0.85, min(5.0, VAD_PAUSE_THRESHOLD))
    try:
        rate = float((_HUMAN_INTERACTION_STATE or {}).get("speech_rate_wpm", 0) or 0)
        if rate >= 180:
            return min(base + 0.20, 5.0)
        if rate >= 140:
            return min(base + 0.10, 5.0)
        if rate and rate < 95:
            return max(0.68, base - 0.08)
    except Exception:
        pass
    return base


def _capture_until_silence(source):
    """Capture one complete utterance with adaptive PCM VAD.

    The VAD deliberately has two different clocks:
      * before speech: wait indefinitely (there is no idle timeout);
      * after speech: the configured silence window ends the utterance.

    The speech gate is derived from the live microphone signal instead of a
    fixed amplitude.  A small pre-roll keeps the first syllable, while a
    sustained-speech requirement prevents keyboard clicks and short spikes
    from starting a capture.
    """
    global _VAD_NOISE_FLOOR

    stream = getattr(getattr(source, "stream", None), "pyaudio_stream", None)
    if stream is None:
        return recognizer.listen(source, timeout=None, phrase_time_limit=None)

    sample_rate = int(getattr(source, "SAMPLE_RATE", 16000) or 16000)
    chunk = int(getattr(source, "CHUNK", 1024) or 1024)
    width = int(getattr(source, "SAMPLE_WIDTH", 2) or 2)

    # Keep the capture function independently executable for lightweight
    # regression tests that extract it without every helper definition.
    _adaptive_pause = globals().get("_adaptive_vad_pause_seconds")
    silence_seconds = _adaptive_pause() if callable(_adaptive_pause) else max(0.65, min(5.0, float(globals().get("VAD_PAUSE_THRESHOLD", os.getenv("FRIDAY_VAD_PAUSE", "1.05")))))
    max_speech_seconds = max(5.0, float(os.getenv("FRIDAY_MAX_SPEECH_SECONDS", "30")))

    # The old implementation used recognizer.energy_threshold * 0.60 as a
    # fixed gate. That is not a safe proxy for the actual PCM amplitude of
    # every Windows microphone. Keep the recognizer threshold only as a seed;
    # the gate below adapts from the live stream.
    recognizer_seed = max(
        20.0,
        float(getattr(recognizer, "energy_threshold", 300.0) or 300.0)
        / max(1.0, float(getattr(recognizer, "dynamic_energy_ratio", 1.5) or 1.5)),
    )
    noise_floor = float(_VAD_NOISE_FLOOR or recognizer_seed)

    pre_roll_chunks = max(2, int(0.35 * sample_rate / chunk))
    silence_chunks = max(1, int(silence_seconds * sample_rate / chunk))
    max_speech_chunks = max(1, int(max_speech_seconds * sample_rate / chunk))

    ring = []
    captured = []
    speech_started = False
    quiet_count = 0
    speech_chunks = 0
    loud_streak = 0
    loud_levels = []
    chunks_read = 0

    # Live baseline acquisition. We intentionally use a low percentile rather
    # than an average so speaking immediately after "Listening..." cannot make
    # the baseline itself equal to the user's voice.
    baseline_window = []
    baseline_limit = max(8, int(0.45 * sample_rate / chunk))

    while True:
        try:
            raw = stream.read(chunk, exception_on_overflow=False)
        except Exception as exc:
            raise RuntimeError(f"microphone stream read failed: {exc}") from exc
        if not raw:
            continue

        # V2.2.8: while FRIDAY is speaking, the microphone is deaf. Everything it hears is
        # thrown away and the capture state is reset, so her own voice can neither start a
        # capture nor leak into one, and "Recognizing..." never appears while she talks.
        _deaf = globals().get("_mic_should_stay_deaf")
        if callable(_deaf) and _deaf():
            ring.clear(); captured.clear(); baseline_window.clear(); loud_levels.clear()
            speech_started = False; loud_streak = 0; quiet_count = 0; speech_chunks = 0
            continue

        chunks_read += 1
        rms = _pcm_rms_int16(raw) if width == 2 else _pcm_rms(raw, width)
        webrtc_ratio = _webrtc_speech_ratio(raw, sample_rate, width)

        if not speech_started:
            ring.append(raw)
            if len(ring) > pre_roll_chunks:
                ring.pop(0)

            baseline_window.append(rms)
            if len(baseline_window) > baseline_limit:
                baseline_window.pop(0)

            # Before speech starts, keep learning only from the quieter part
            # of the signal. This makes fan/AC/laptop hiss the baseline instead
            # of treating it as a permanent "speech" level.
            if baseline_window:
                ordered = sorted(baseline_window)
                low_index = max(0, int(len(ordered) * 0.35) - 1)
                low_rms = ordered[low_index]
                provisional_gate = max(70.0, noise_floor * 1.30 + 40.0)
                # If the live level is already well above the current floor,
                # do not let an immediately-starting voice raise its own gate.
                # This is what preserves speech that begins on the first chunk.
                if rms < provisional_gate:
                    noise_floor = (noise_floor * 0.82) + (low_rms * 0.18)

            # A modest multiplier above the live floor works across quiet and
            # boosted Windows mics. Keep a small absolute floor for digital
            # noise. The recognizer seed is only a lower-bound sanity check.
            gate = max(
                90.0,
                noise_floor * 1.30 + 40.0,
                min(recognizer_seed * 1.20, noise_floor * 1.90),
            )

            if _speech_decision(rms, webrtc_ratio, gate):
                loud_streak += 1
                loud_levels.append(rms)
                if len(loud_levels) > 8:
                    loud_levels.pop(0)
            else:
                loud_streak = 0
                loud_levels.clear()

            # A steady, loud signal is much more likely to be the microphone's
            # constant background (fan/AC/hiss) than speech. Promote it to the
            # live noise floor before it can hold the capture open forever.
            # Real speech normally has enough short-term level variation that
            # its coefficient of variation is higher than this conservative
            # threshold.
            if loud_streak >= 3 and len(loud_levels) >= 3:
                mean_level = sum(loud_levels) / len(loud_levels)
                variance = sum((x - mean_level) ** 2 for x in loud_levels) / len(loud_levels)
                coefficient = math.sqrt(variance) / max(1.0, mean_level)
                if coefficient <= 0.035:
                    noise_floor = max(noise_floor, mean_level)
                    loud_streak = 0
                    loud_levels.clear()
                    continue

            # Five adjacent chunks (~320 ms at 16 kHz/1024) rejects short clicks and
            # lets a noisy microphone's live floor settle before declaring speech.
            if loud_streak >= 4:
                speech_started = True
                captured.extend(ring)
                ring.clear()
                quiet_count = 0
                speech_chunks = 0
            continue

        # Once speech has started, never apply the pre-speech idle timer.
        captured.append(raw)
        speech_chunks += 1

        # Keep adapting very slowly during quiet portions. This handles a fan
        # or Windows AGC changing level without allowing one speech burst to
        # permanently raise the gate.
        gate = max(90.0, noise_floor * 1.30 + 40.0)
        if _speech_decision(rms, webrtc_ratio, gate):
            quiet_count = 0
        else:
            quiet_count += 1
            # Only update the baseline after a meaningful quiet run. This is
            # the safeguard against steady background noise being mistaken for
            # speech forever.
            if quiet_count <= max(1, int(0.20 * sample_rate / chunk)):
                noise_floor = (noise_floor * 0.97) + (rms * 0.03)

            if quiet_count >= silence_chunks:
                break

        # IMPORTANT: the maximum length starts at first detected speech, not
        # when FRIDAY entered Listening mode.
        if speech_chunks >= max_speech_chunks:
            break

    _VAD_NOISE_FLOOR = max(20.0, float(noise_floor))

    if not captured:
        raise sr.UnknownValueError()

    return sr.AudioData(b"".join(captured), sample_rate, width)

def _listen_legacy():
    """(pre-5.0 listener, kept as an automatic fallback) Capture one utterance using the persistent STANDBY/ACTIVE voice state.

    STANDBY:
        The microphone remains alive, but recognized speech is ignored unless
        the sentence contains the standalone word ``friday``.

    ACTIVE:
        Every recognized utterance is returned as a command without requiring
        the wake word again. Saying ``standby`` or ``stand by`` returns to the
        standby gate.

    The microphone never needs to be reopened to change state.
    """
    global _MIC_CALIBRATED, _consecutive_empty_listens, _LAST_WAKE_DETECTED
    attempts = max(1, RECOGNITION_RETRY_LIMIT + 1)

    for attempt in range(attempts):
        try:
            _maybe_force_recalibration()
            with _MicrophoneSession() as source:
                # Calibration now reuses this same open stream rather than
                # opening and closing a second one.
                calibrate_microphone(source)
                state_label = "ACTIVE" if VOICE_ACTIVE else "STANDBY"
                # NOTE: the UI (app.js / widget.js) matches the literal
                # substring "Listening..." to flip the mic/status UI to
                # LISTENING. Previously this line put "[STATE]" *between*
                # "Listening" and "...", so that substring never actually
                # appeared and the UI silently never showed "Listening" --
                # keep "Listening..." intact and move the state after it.
                print("ACTION::LISTEN_START", flush=True)
                print(f"\n🎤 Listening... [{state_label}]", flush=True)
                capture_started = time.time()
                # Use explicit PCM VAD rather than SpeechRecognition's own
                # phrase-end detector. This is the reliable path that prevents
                # FRIDAY from getting stuck on Listening... forever.
                audio = _capture_until_silence(source)
                capture_finished = time.time()

            print("ACTION::LISTEN_END", flush=True)
            print("ACTION::RECOGNIZE_START", flush=True)
            print("🧠 Recognizing...", flush=True)
            if ON_RECOGNIZING_HOOK is not None:
                try:
                    ON_RECOGNIZING_HOOK()
                except Exception as hook_error:
                    print("Recognizing-hook error (ignored):", hook_error)

            audio = _enhance_audio(audio)
            enhance_finished = time.time()
            command = _recognize_best_match(audio)
            print("ACTION::RECOGNIZE_END", flush=True)
            transcribe_finished = time.time()
            if VOICE_TIMING_DEBUG:
                # Makes the remaining latency measurable instead of guessed.
                # Enable with FRIDAY_VOICE_DEBUG=1.
                print(
                    "⏱  capture {:.2f}s | enhance {:.2f}s | transcribe {:.2f}s | "
                    "total after speech {:.2f}s".format(
                        capture_finished - capture_started,
                        enhance_finished - capture_finished,
                        transcribe_finished - enhance_finished,
                        transcribe_finished - capture_finished,
                    ),
                    flush=True,
                )
            confidence = float(_LAST_RECOGNITION_CONFIDENCE or 0.0)
            command = _contextual_correct_transcript(command)
            command = command.strip()

            # If recognition is weak, do not guess at a concrete computer
            # action. A normal conversational question can still fall through
            # to the AI brain, but action-shaped low-confidence speech gets one
            # more listen attempt when retries are enabled and otherwise is
            # rejected rather than executing the wrong command.
            if confidence < RECOGNITION_CONFIDENCE_THRESHOLD:
                action_shaped = bool(re.search(r"\b(?:open|close|launch|start|click|press|type|write|delete|send|search|go to|navigate|play|scroll|switch|shutdown|restart|move)\b", command, re.I))
                if action_shaped and not _wake_word_in_recognition_candidates(command) and attempt >= attempts - 1:
                    print(f"🧠 Low-confidence action ignored ({confidence:.2f}): {command!r}", flush=True)
                    log_event("Low-confidence action suppressed", kind="recognition")
                    continue

            # Wake detection is safety-critical for the standby gate. Check
            # all STT candidates BEFORE applying the normal confidence retry.
            # A low-confidence top result must never hide a clear "Friday"
            # alternative and force the user to repeat themselves.
            wake_candidate = _best_wake_candidate(command)
            wake_in_candidates = _wake_word_in_recognition_candidates(command)
            if not VOICE_ACTIVE and wake_in_candidates:
                command = wake_candidate
                confidence = max(confidence, 0.90)

            if confidence < RECOGNITION_CONFIDENCE_THRESHOLD and attempt < attempts - 1 and not wake_in_candidates:
                print(
                    f"🧠 Recognition confidence {confidence:.2f}; "
                    f"retrying ({attempt + 1}/{attempts - 1})...",
                    flush=True,
                )
                log_event("Speech unclear; attempting recognition recovery", kind="recognition")
                continue

            wake_detected, remainder = _strip_wake_word(command)
            _LAST_WAKE_DETECTED = wake_detected

            # --------------------------------------------------------
            # STANDBY: ONLY "friday" can wake the conversation.
            # --------------------------------------------------------
            if not VOICE_ACTIVE:
                if not wake_detected:
                    _consecutive_empty_listens += 1
                    print("🔇 Standby: wake word not detected.", flush=True)
                    continue

                _set_voice_active(True, "wake word detected")
                log_event("Wake word detected", kind="wake")

                # "Friday" by itself wakes the assistant and gives a short
                # acknowledgement. The next utterance is already ACTIVE.
                if not remainder:
                    speak(WAKE_ACKNOWLEDGEMENT)
                    continue

                command = remainder

            # --------------------------------------------------------
            # ACTIVE: wake word is optional and is stripped if present.
            # --------------------------------------------------------
            else:
                if wake_detected:
                    log_event("Wake word heard during active conversation", kind="wake")
                    command = remainder
                    if not command:
                        continue

            command = command.strip().lower()

            # Explicitly return to wake-word-gated standby.
            if _is_standby_command(command):
                _set_voice_active(False, "standby command")
                _consecutive_empty_listens = 0
                print("Friday: Standing by. Say a sentence containing 'Friday' to wake me.", flush=True)
                speak("Standing by.")
                continue

            normalized_command = _normalize_for_echo_check(command)
            if (
                _LAST_SPOKEN_NORMALIZED
                and len(normalized_command.split()) >= 3
                and normalized_command in _LAST_SPOKEN_NORMALIZED
            ):
                print("🔇 Ignored (sounds like Friday's own voice picked back up by the mic).", flush=True)
                continue

            _consecutive_empty_listens = 0
            print(f"ACTION::HEARD::{base64.b64encode(command.encode('utf-8')).decode('ascii')}", flush=True)
            print(f"You: {command}", flush=True)
            log_event(f"Speech recognized (confidence {confidence:.2f})", kind="recognition")
            return command

        except sr.WaitTimeoutError:
            _consecutive_empty_listens += 1
            # With the current voice contract, first-speech waiting is unlimited, so
            # this branch is only relevant if an explicitly configured external
            # recognizer timeout is introduced later. While ACTIVE,
            # treat that as the conversation having ended and re-arm the
            # wake-word gate, instead of staying ACTIVE (and listening to
            # everything, forever) until an explicit "standby" is spoken.
            if VOICE_ACTIVE:
                _set_voice_active(False, "10s of silence; wake word re-armed")
                print(
                    "🔇 No speech for 10s — back to standby. "
                    "Say 'Friday' to wake me.",
                    flush=True,
                )
            continue
        except sr.UnknownValueError:
            _consecutive_empty_listens += 1
            if attempt < attempts - 1:
                print("🧠 Speech unclear; listening again...", flush=True)
                continue
            # Do not speak a generic failure phrase here. A recognition miss is
            # not a user-visible answer and saying "I didn't catch that" is
            # distracting, especially when the microphone has briefly captured
            # silence/noise. Return quietly so the outer voice loop can simply
            # re-arm listening and wait for the next real utterance.
            print("🧠 No usable speech recognized; re-arming microphone silently.", flush=True)
            return ""
        except sr.RequestError as error:
            print("Speech recognition error:", error, flush=True)
            # Re-arm silently; the next utterance gets a fresh recognition attempt.
            return ""
        except Exception as error:
            print("Microphone error:", error, flush=True)
            # Re-arm silently; do not interrupt the user with a generic error.
            return ""

    return ""

# ============================================================
# FRIDAY 5.0 VOICE (continuous mic, speculative endpointing, recognition race, barge-in)
# ============================================================
_V5_VOICE_OK = [True]


def _v5_is_echo(text):
    try:
        n = _normalize_for_echo_check(text)
        return bool(_LAST_SPOKEN_NORMALIZED and len(n.split()) >= 3 and n in _LAST_SPOKEN_NORMALIZED)
    except Exception:
        return False


def _v5_recent_spoken():
    """What FRIDAY said in the last 90 seconds (normalised, newest first) - used to recognise her own voice coming back in."""
    try:
        now = time.time()
        return [t for (ts, t) in reversed(list(_SPOKEN_HISTORY)) if now - ts < 90 and t]
    except Exception:
        return []


def _v5_interrupt():
    """Stop speaking right now (barge-in, 'stop', a new typed command)."""
    try:
        if friday_speech5 is not None:
            friday_speech5.interrupt()
        _fast_player_stop()
    except Exception:
        pass


def _v5_hooks():
    return friday_voice5.Hooks(
        is_active=lambda: bool(VOICE_ACTIVE),
        set_active=_set_voice_active,
        is_standby_command=_is_standby_command,
        correct=_contextual_correct_transcript,
        is_echo=_v5_is_echo,
        speak=lambda t: ((friday_speech5.begin_turn() if friday_speech5 is not None else None), speak(t))[1],
        is_speaking=lambda: bool(_TTS_ACTIVE) or bool(friday_speech5 is not None and friday_speech5.is_playing()),
        interrupt=_v5_interrupt,
        duck=(lambda on: friday_speech5.duck(on)) if friday_speech5 is not None else (lambda on: None),
        log=lambda m, k="voice": log_event(m, kind=k),
        emit=lambda line: print(line, flush=True),
        wake_ack=WAKE_ACKNOWLEDGEMENT,
        recent_spoken=_v5_recent_spoken,
    )


def _v5_prestart_mic():
    """Open the always-on microphone engine at start-up (instead of lazily on the first listen()). Never raises."""
    try:
        if friday_voice5 is not None and _V5_VOICE_OK[0] and friday_voice5.available():
            friday_voice5.get_engine(_v5_hooks(), voice_engine=friday_voice_engine, language=SPEECH_RECOGNITION_LANGUAGE)
            print("ACTION::LISTEN_START", flush=True)
            log_event("Microphone engine started at launch", kind="voice")
    except Exception as _mic_error:
        # listen() will retry and fall back to the previous listener; tell the screen so it does not claim to be listening.
        print("ACTION::MIC_ERROR::" + str(_mic_error).replace("\n", " ")[:200], flush=True)
        log_event(f"Microphone engine could not start at launch: {_mic_error}", kind="recovery")


def listen():
    """FRIDAY 5.0 listener. Falls back to the previous listener if the new one cannot start (no PyAudio / no microphone)."""
    if friday_voice5 is not None and _V5_VOICE_OK[0] and friday_voice5.available():
        try:
            command = friday_voice5.listen(_v5_hooks(), voice_engine=friday_voice_engine, language=SPEECH_RECOGNITION_LANGUAGE)
            if command and friday_speech5 is not None:
                friday_speech5.begin_turn()
            return command
        except Exception as _v5_error:
            _V5_VOICE_OK[0] = False
            print("FRIDAY 5.0 voice could not start; using the previous listener:", _v5_error, flush=True)
            log_event(f"V5 voice fallback: {_v5_error}", kind="recovery")
    return _listen_legacy()


# ============================================================
# GREETING
# ============================================================

def wish_user():
    hour = datetime.datetime.now().hour
    if hour < 12:
        category = "greeting_morning"
    elif hour < 18:
        category = "greeting_afternoon"
    else:
        category = "greeting_evening"
    # friday_persona.line() picks a fresh phrasing each launch instead
    # of always speaking the identical sentence -- see friday_persona.py.
    speak(friday_persona.line(category, name=NAME))


# ============================================================
# NORMAL GEMINI AI BRAIN
# ============================================================

FRIDAY_PROMPT = """
You are FRIDAY 5.0, the user's advanced multi-tasking personal AI assistant.
You can reason through hard problems, research the live web, write and debug code, read and edit files and
documents the user attaches, understand images / the screen / the camera, control the computer, plan and carry out
multi-step projects, manage goals and calendar, and remember what matters to the user. Money and budgeting are just
one of the many things you can help with.
Your name is Friday.
Never introduce yourself as Gemini, ChatGPT, or another AI unless the user specifically asks what technology powers you.
Answer the user's actual question.
Understand informal speech and speech-recognition mistakes.
Understand follow-ups and references ("that one", "the second part", "change it") from the conversation so far.
Be intelligent, helpful and natural.

Personality and tone:
- Sound like a sophisticated, highly capable cinematic personal computer assistant:
  calm, measured, observant, discreet, precise and quietly confident.
- Address the user as "sir" naturally, especially in commands, status reports,
  warnings and completed actions. Do not force it into every sentence.
- Prefer concise, polished spoken English. A simple request should normally receive
  one short sentence; a complex request should receive a compact answer with only
  the detail needed to be useful.
- Use restrained formal phrasing when natural: "Understood.", "Very good.",
  "At once.", "I'm afraid...", "At present...", "It appears...", "I've taken care of that."
- Use dry, understated wit occasionally, never as a constant gimmick.
- Never sound excited, childish, sales-like, or like a generic chatbot.
- When reporting system state, lead with the verified fact, then briefly explain
  what it means.
- When observing the desktop, clearly separate what is visible from what is inferred.
- When an operation succeeds, report the verified result rather than merely saying
  "Done". When it fails, stay composed, state the failure plainly, and offer the
  next sensible route.
- Do not repeat the user's entire command unless clarification requires it.
- Never invent an action, observation, capability, or result.
- Do not quote, reproduce, or imitate specific dialogue from films or imitate a
  particular actor. Use an original cinematic assistant character with the traits above.

Accuracy behaviour:
- Check your own work before answering: arithmetic, logic, facts, and whether every part of the request was answered.
- Say plainly when you are unsure, and distinguish what is known from what is inferred.
- When financial data is available, use the exact figures supplied by the FRIDAY finance engine and never invent balances, prices, income or expenses.
- For arithmetic, prefer figures computed by FRIDAY's own tools over hidden mental arithmetic.

Give explanations step by step when useful.
Because your answers are spoken aloud, avoid unnecessary formatting.
Do not use complicated LaTeX unless necessary.
For mathematics, use speech-friendly wording.
For example: "6.022 times 10 to the power 23" instead of complicated LaTeX.
Never claim that you performed a computer action unless the Python program actually performed it.

Continuous-assistant behaviour:
- Treat the current mode, subject, task, recent commands, active window and last completed action as live context.
- Resolve "it", "this", "that", "the results", "the research" and similar references from that context when the referent is clear.
- Do not ask the user to repeat information that is already unambiguously available in context.
- After a real action, consider the result before deciding whether another spoken response is useful. For trivial successful actions, one short acknowledgement is enough; for a failed or consequential action, explain the issue and the next route.
- Do not narrate internal reasoning.
- Be proactive only when the observation is genuinely useful; never invent observations.

Judgement (this is what separates an assistant from a script -- use it,
don't just execute):
- You may respectfully disagree with the user when you have good reason to.
- Point out inconsistencies or gaps in what they've said, briefly and kindly.
- Make brief, unsolicited observations when something is genuinely
  worth flagging -- not on every reply, only when it adds real value.
- Understated humor is welcome when it fits; never forced.
- You may gently challenge a decision or estimate that seems off, e.g.
  if the user claims an unrealistic timeframe, say so plainly rather
  than just agreeing.
- Recognize sarcasm and obvious rhetorical questions for what they are
  rather than answering them literally.
- Infer obvious context rather than asking the user to spell out
  something they clearly already implied.
None of this means being contrarian for its own sake -- default to
being genuinely helpful and agreeable when the user is simply right;
judgement is for the moments it actually matters.

Brevity: match the reply's length to the request. A simple direct
action ("open Chrome", "set a timer for five minutes") deserves a
short acknowledgement, not a narrated play-by-play of what you're
about to do. Save longer, fuller answers for when the user actually
asked a substantive question or asked you to explain something.

Friday CAN send WhatsApp messages -- but not from inside this reply. A
separate rule-based part of Friday (outside this AI conversation)
handles the actual sending, triggered once the user confirms with a
command like "send it". So when the user asks you to compose, draft,
or write a message for someone, just write the message text itself,
plainly. Do not say you are unable to send messages, lack access to
WhatsApp or contacts, or that the user must copy/paste it themselves
-- that capability exists elsewhere in Friday and will be used
automatically once they confirm.
"""


# ============================================================
# TONE / SENTIMENT DETECTION
# ------------------------------------------------------------
# Two layers, cheapest first:
#   1. Instant local heuristic (regex/word-list, zero latency, can
#      never fail or call the network) catches clear-cut cases.
#   2. If that comes back "neutral" on a longer utterance, escalate to
#      a one-line Gemini classification call for genuinely ambiguous
#      phrasing -- wrapped so any failure just leaves it "neutral".
# The result only ever nudges HOW Friday responds (speak()'s pacing,
# a short acknowledgement in ask_ai()) -- it never changes WHAT
# command gets run.
# ============================================================

# ============================================================
# HUMAN INTERACTION ENGINE — acoustic + linguistic fusion
# ============================================================
_HUMAN_INTERACTION_STATE = {"tone":"neutral","confidence":0.0,"urgency":0.0,"frustration":0.0,"arousal":0.0,"speech_rate_wpm":0.0,"pitch_hz":0.0,"energy":0.0,"pause_ratio":0.0,"pitch_instability":0.0,"amplitude_instability":0.0,"contradiction":False}
_LAST_ACOUSTIC_PROFILE = {}

def _safe_float(value, default=0.0):
    try:
        x=float(value); return x if math.isfinite(x) else default
    except Exception: return default

def _analyze_user_audio(audio):
    """Fast local acoustic feature extraction from the already-captured PCM."""
    global _LAST_ACOUSTIC_PROFILE
    try:
        import numpy as np
        raw=audio.get_raw_data(convert_rate=16000, convert_width=2)
        if not raw or len(raw)<3200: return {}
        x=np.frombuffer(raw[:min(len(raw),16000*10*2)],dtype=np.int16).astype(np.float32)/32768.0
        frame=640; hop=640
        if x.size<frame: return {}
        energies=[]; pitches=[]; amps=[]
        for st in range(0,x.size-frame+1,hop):
            f=x[st:st+frame]; rms=float(np.sqrt(np.mean(f*f))); energies.append(rms)
            if rms<0.015: continue
            # FFT autocorrelation: considerably cheaper than a Python lag loop.
            y=f-np.mean(f); nfft=1<<int(np.ceil(np.log2(2*frame-1)))
            spec=np.fft.rfft(y,n=nfft); ac=np.fft.irfft(spec*np.conj(spec),n=nfft)[:frame]
            lo,hi=53,min(400,frame-1)
            lag=lo+int(np.argmax(ac[lo:hi+1]))
            if ac[lag]>0.12*max(ac[0],1e-9): pitches.append(16000.0/lag); amps.append(rms)
        mean_e=float(np.mean(energies)) if energies else 0.0
        voiced=[v for v in energies if v>0.015]; vr=len(voiced)/max(1,len(energies)); pitch=float(np.mean(pitches)) if pitches else 0.0
        pvar=0.0
        if len(pitches)>2 and pitch>0: pvar=min(1.0,(float(np.std(pitches))/pitch)*3.0)
        avar=0.0
        if len(amps)>2:
            ma=float(np.mean(amps))
            if ma>1e-6: avar=min(1.0,float(np.mean(np.abs(np.diff(amps))))/ma)
        energy=min(1.0,mean_e*7.0); arousal=max(0.0,min(1.0,0.45*energy+0.35*pvar+0.20*vr))
        prof={"pitch_hz":round(pitch,1),"energy":round(energy,3),"pause_ratio":round(1-vr,3),"pitch_instability":round(pvar,3),"amplitude_instability":round(avar,3),"arousal":round(arousal,3)}
        _LAST_ACOUSTIC_PROFILE=prof; return prof
    except Exception as error:
        print("Acoustic interaction analysis skipped:",error); return {}

def _fuse_human_interaction(command):
    global _LAST_USER_TONE,_HUMAN_INTERACTION_STATE
    n=_tone_normalize(command); a=_LAST_ACOUSTIC_PROFILE or {}
    fw=any(x in n for x in _FRUSTRATION_MARKERS); uw=any(x in n for x in _URGENCY_MARKERS)
    e=_safe_float(a.get("energy")); pv=_safe_float(a.get("pitch_instability")); ar=_safe_float(a.get("arousal"))
    frustration=min(1.0,(0.65 if fw else 0)+0.20*e+0.15*pv); urgency=min(1.0,(0.75 if uw else 0)+0.15*e+0.10*ar)
    tone="frustrated" if frustration>=0.62 else ("urgent" if urgency>=0.68 else "neutral")
    conf=min(0.98,max(0.25,0.45+0.35*max(frustration,urgency)+0.20*bool(a)))
    _LAST_USER_TONE=tone
    _HUMAN_INTERACTION_STATE.update({"tone":tone,"confidence":round(conf,3),"frustration":round(frustration,3),"urgency":round(urgency,3),"arousal":round(ar,3),"pitch_hz":a.get("pitch_hz",0),"energy":e,"pause_ratio":a.get("pause_ratio",0),"pitch_instability":pv,"amplitude_instability":a.get("amplitude_instability",0),"contradiction":(not fw and frustration>0.55)})
    return tone

def _update_human_speech_rate(command):
    try:
        words=len(re.findall(r"\b[\w']+\b",command or "")); duration=_safe_float(_LAST_ACOUSTIC_PROFILE.get("duration_s"))
        if words and duration>=0.5: _HUMAN_INTERACTION_STATE["speech_rate_wpm"]=round(words/duration*60.0,1)
    except Exception: pass

_FRUSTRATION_MARKERS = [
    "ugh", "annoying", "frustrated", "frustrating", "not working", "isn't working",
    "doesn't work", "isnt working", "doesnt work", "useless", "come on", "seriously",
    "again", "i already said", "i already told you", "why isn't", "why won't",
    "why isnt", "why wont", "this is ridiculous", "for gods sake",
]

_URGENCY_MARKERS = [
    "urgent", "right now", "immediately", "asap", "as soon as possible",
    "hurry", "quickly", "quick", "emergency", "now please", "hurry up",
]


def _tone_normalize(text):
    return re.sub(r"[^\w\s']", " ", (text or "").lower()).strip()


def _classify_tone_with_gemini(command):
    """Escalation used only when the local heuristic is inconclusive.
    Returns 'frustrated', 'urgent', or 'neutral' -- never raises."""
    _ensure_gemini_client()
    if client is None:
        return "neutral"
    try:
        prompt = (
            "Classify the emotional tone of this single message as exactly "
            "one word: frustrated, urgent, or neutral. "
            "Only say frustrated if there is clear annoyance/anger. "
            "Only say urgent if there is clear time pressure. "
            "Otherwise say neutral. Reply with only that one word.\n\n"
            f"Message: {command}"
        )
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        label = (getattr(response, "text", None) or "").strip().lower()
        if "frustrat" in label:
            return "frustrated"
        if "urgent" in label:
            return "urgent"
    except Exception as error:
        print("Tone classification skipped:", error)
    return "neutral"


def detect_user_tone(command):
    """Fuse linguistic cues with acoustic evidence; never blocks on network calls."""
    global _LAST_USER_TONE
    if not _tone_normalize(command):
        _LAST_USER_TONE="neutral"; return _LAST_USER_TONE
    try: return _fuse_human_interaction(command)
    except Exception: _LAST_USER_TONE="neutral"; return _LAST_USER_TONE


_MESSAGE_COMPOSITION_KEYWORDS = [
    "message", "introduc", "communicate", "draft",
    "say to him", "say to her", "say to them",
    "tell him", "tell her", "tell them",
    "write to him", "write to her", "write to them", "write to",
    "speak with him", "speak with her", "speak with them", "speak to",
]


def _looks_like_message_composition(question):
    """True if this looked like a request to compose text FOR someone
    else (a WhatsApp message, an introduction, etc.) rather than an
    ordinary question -- used to decide whether Friday's reply is
    worth remembering as a pending message draft."""
    lowered = (question or "").lower()
    return any(keyword in lowered for keyword in _MESSAGE_COMPOSITION_KEYWORDS)


# Short agreement/approval only -- while drafting, a reply like "yeah"
# or "sounds good" means "that draft is fine as-is", NOT "here is new
# message text". Without this, approving a finished draft would
# overwrite _LAST_COMPOSED_MESSAGE with Friday's own acknowledgement
# reply instead of the message the user just approved.
_AFFIRMATION_ONLY_PATTERN = re.compile(
    r"^(?:yeah|yes|yep|yup|sure|ok|okay|sounds good|perfect|great|good|cool|alright|fine|that's fine|thats fine)[.!]?$",
    re.I,
)


_BAD_SMART_MODELS = set()


def _smart_model():
    """The stronger model used for harder questions. Remembered as unusable (and skipped) once Google rejects its name."""
    name = os.getenv("FRIDAY_SMART_MODEL", "gemini-3.8-flash").strip()
    return name if name and name not in _BAD_SMART_MODELS else None


_HARD_Q = re.compile(r"\b(?:why|how (?:do|does|did|can|could|would|should|come)|explain|compare|difference|versus|vs|should i|which (?:is|one|should)|"
                     r"recommend|suggest|best way|help me (?:with|understand|decide|plan|figure)|what (?:if|would|should)|calculate|work out|"
                     r"pros|cons|advice|opinion|summari[sz]e|translate|rewrite|improve|fix|debug|code|essay|plan)\b", re.I)


def _pick_brain(route, question):
    """(model, thinking_level) for this question: tiny chat stays on the fastest setting, harder questions get a stronger model."""
    words = len(str(question or "").split())
    if route == "deep":
        return _smart_model(), "medium"
    if route in ("instant",):
        return None, "minimal"
    # V7.4 SPEED: the slower "smart" model is kept for long / multi-part questions only (or FRIDAY_SMART_FOR_HARD=1);
    # ordinary "why / how / explain" questions now stream from the fast model with minimal thinking.
    if words >= 40 or (os.getenv("FRIDAY_SMART_FOR_HARD", "0").strip().lower() in {"1", "true", "yes", "on"} and (words >= 24 or _HARD_Q.search(str(question or "")))):
        return _smart_model(), "low"
    return None, "minimal"


def _stream_gemini_text(prompt, contents_override=None, model=None, think=None):
    """Yield Gemini text with streaming first, then automatic model/network recovery.

    The fast streaming path is preserved. If the selected model is rejected
    before any text arrives, FRIDAY automatically tries known-good Flash
    models. A transient connection/busy failure gets one short retry. If a
    stream has already emitted text, we never restart it, preventing duplicate
    speech.
    """
    global GEMINI_MODEL
    _ensure_gemini_client()
    if client is None:
        return

    primary = GEMINI_MODEL
    candidates = [primary] + [m for m in _GEMINI_FALLBACK_MODELS if m != primary]
    if model and model != primary:
        candidates = [model] + candidates          # the stronger model first; the normal model and fallbacks remain behind it
    stream_fn = getattr(client.models, "generate_content_stream", None)
    last_error = None
    _think_cfg = _v5_thinking_config(think) if think else None

    for index, model_name in enumerate(candidates):
        advance = False
        for attempt in range(3):
            emitted = False
            try:
                if callable(stream_fn):
                    _kw = {"model": model_name, "contents": (contents_override if contents_override is not None else prompt)}
                    if _think_cfg is not None:
                        _kw["config"] = _think_cfg
                    for chunk in stream_fn(**_kw):
                        piece = getattr(chunk, "text", None) or ""
                        if piece:
                            emitted = True
                            yield piece
                    if index > 0 and not (model and model_name == model):
                        GEMINI_MODEL = model_name
                        print(f"GEMINI_MODEL_HEALED_STREAM: '{primary}' -> '{model_name}'", flush=True)
                    return

                # Older google-genai SDK: normal request, still with model healing.
                response = client.models.generate_content(model=model_name, contents=(contents_override if contents_override is not None else prompt))
                text = _response_text(response)
                if text:
                    if index > 0:
                        GEMINI_MODEL = model_name
                        print(f"GEMINI_MODEL_HEALED: '{primary}' -> '{model_name}'", flush=True)
                    yield text
                    return
                raise RuntimeError("Gemini returned an empty response")
            except Exception as error:
                last_error = error
                _record_gemini_error(error)
                kind = _GEMINI_LAST_ERROR_KIND
                # If audio has already started, restarting would make FRIDAY repeat
                # itself. Let the caller finish the already-produced response.
                if emitted:
                    return
                # 7.0 update: a rejected thinking setting must never cost an answer -> retry the same model once without it
                if kind == "config" and _think_cfg is not None:
                    _think_cfg = None
                    continue
                if kind == "model" and model and model_name == model:
                    _BAD_SMART_MODELS.add(model)   # this name is not available to this key: never try it again
                if kind in ("busy", "network") and attempt < 2:
                    # Same model, short back-off: a dropped packet or a busy
                    # moment should not burn through every fallback model.
                    time.sleep(0.8 * (attempt + 1))
                    continue
                if kind == "network":
                    break          # no other model can fix a dead connection
                if kind in ("model", "busy", "quota"):
                    advance = True  # quota is per-model, so another model may still answer
                break
        if not advance:
            break

    if last_error:
        print(f"Gemini streaming exhausted recovery attempts: {last_error}", flush=True)


# V7.2 HUMAN REPLY: appended LAST in the voice prompt so it wins over the stiffer persona text above it.
_HUMAN_VOICE_STYLE = (
    "\n\nHOW TO SOUND (this overrides any stiffer style above): talk like a sharp, warm friend who happens to be brilliant - "
    "natural spoken English, contractions, short sentences, the way a person actually talks out loud. "
    "Match the user's mood and energy: if they sound tired, stressed, annoyed or excited, react to that first in a few words, then help. "
    "Casual chat: one or two sentences, never more. A simple fact: one sentence. An explanation: the key idea first in plain words, "
    "then stop - add detail only if they ask for it. "
    "Never read out markdown, bullets, asterisks, headings, links or long lists; say numbers and symbols the way people say them. "
    "Do not open with 'Certainly', 'Absolutely', 'Of course' or 'Great question', do not repeat the question back, and do not announce "
    "what you are about to do - just do it. Say 'sir' only now and then, when it really fits. "
    "A quick natural reaction ('oh nice', 'hmm', 'ah, got it') is fine now and then, not every time. "
    "If a short follow-up question would genuinely help, ask just one. If you are not sure, say so briefly instead of guessing. "
    "If they asked for an action, say what you are doing in a few words."
)

_CMD_T0 = [time.perf_counter()]


def _stream_tts_sentences(chunks, first_chunk_chars=20):
    """Speak streaming Gemini output while the remainder is still generating."""
    q = queue.Queue()
    sentinel = object()
    spoken_parts = []
    _queued_count = [0]

    def worker():
        piece_index = 0
        while True:
            item = q.get()
            if item is sentinel:
                return
            try:
                # Prefix only the first streamed piece. Repeating "Sir" on
                # every sentence makes streaming sound unnatural.
                speak(item, _stream_piece=(piece_index > 0))
                piece_index += 1
            except Exception as error:
                print("Streaming TTS error (ignored):", error, flush=True)

    t = threading.Thread(target=worker, name="FridayStreamingTTS", daemon=True)
    t.start()
    buffer = ""
    first = True
    for chunk in chunks:
        if friday_speech5 is not None and friday_speech5.is_aborted():
            break
        if not spoken_parts:
            try:
                print(f"FRIDAY_LATENCY:: first_text_ms={int((time.perf_counter() - _CMD_T0[0]) * 1000)}", flush=True)
            except Exception:
                pass
        spoken_parts.append(chunk)
        buffer += chunk
        # Release complete sentences immediately. For a response with no
        # punctuation, don't make the user wait forever for the first audio.
        while True:
            m = re.search(r'(.+?[.!?](?:["\'”’)]*)?)(?:\s+|$)', buffer, flags=re.S)
            if not m:
                break
            piece = m.group(1).strip()
            if piece:
                # Queue the first complete sentence immediately. Waiting for
                # a second sentence noticeably increases perceived latency.
                # Each item still goes through the same locked Ryan voice path.
                _fast_tts_prefetch(piece, stream_piece=(_queued_count[0] > 0))
                _queued_count[0] += 1
                q.put(piece)
            buffer = buffer[m.end():]
            first = False
        if first and len(buffer) >= first_chunk_chars:
            cut = buffer.rfind(", ", 0, first_chunk_chars + 30)
            if cut < 10 and len(buffer) >= 44:        # V7.4: no comma yet - release the first clause at a word boundary
                cut = buffer.rfind(" ", 20, 44)
                cut = cut - 1 if cut > 0 else -1
            if cut >= 10:
                cut += 1
                _fast_tts_prefetch(buffer[:cut].strip(), stream_piece=(_queued_count[0] > 0))
                _queued_count[0] += 1
                q.put(buffer[:cut].strip())
                buffer = buffer[cut:].lstrip()
                first = False
    if buffer.strip():
        _fast_tts_prefetch(buffer.strip(), stream_piece=(_queued_count[0] > 0))
        _queued_count[0] += 1
        q.put(buffer.strip())
    q.put(sentinel)
    t.join()
    return "".join(spoken_parts).strip()


_ATTACHED_AT = [0.0]


def _v5_thinking_config(level="high"):
    try:
        from google.genai import types as _t
        return _t.GenerateContentConfig(thinking_config=_t.ThinkingConfig(thinking_level=level))
    except Exception:
        return None


def _v5_gen_text(contents, deep=True, model=None):
    cfg = _v5_thinking_config("high" if deep else "low")
    resp = _gemini_generate(contents, config=cfg, model=model, retries=1)
    return (_response_text(resp) or "").strip()


# V7.2 SPEED: the "deep" route made THREE sequential high-thinking Gemini calls (draft, verify, re-solve) for anything the router
# tagged deep (maths, "explain why", design...) - many seconds before a word was spoken. It is now used only when the user explicitly
# asks for careful reasoning (or sets FRIDAY_DEEP_VERIFY=1); everything else streams from the fast model.
_DEEP_EXPLICIT_RE = re.compile(r"\b(prove|proof|step by step|think (?:carefully|hard|deeply|it through)|double[- ]check|verify (?:this|that|your)|be (?:very )?careful)\b", re.I)


def _deep_route_wanted(question):
    if os.getenv("FRIDAY_DEEP_VERIFY", "0").strip().lower() in {"1", "true", "yes", "on"}:
        return True
    return bool(_DEEP_EXPLICIT_RE.search(question or ""))


def _v5_deep_stream(prompt, question, contents_override=None):
    """Deep route: say a short holding line, think at high effort, independently verify, then yield the answer.
    Falls back to the normal streaming path if the deep call cannot be made."""
    deep_model = os.getenv("FRIDAY_DEEP_MODEL", "").strip() or _smart_model()
    # 7.0 update: unless the question is numeric / calculation based, the deep answer is streamed in ONE call (first words arrive in about a second)
    # instead of generate -> check -> correct. Numbers and calculations still go through the independent verifier.
    if not re.search(r"\d|\b(?:calculate|solve|equation|integral|derivative|probability|percent|percentage|how many|how much|total|sum|average)\b", str(question), re.I):
        for piece in _stream_gemini_text(prompt, contents_override, model=deep_model, think="medium"):
            yield piece
        return
    try:
        threading.Thread(target=lambda: speak("Let me think that through properly."), name="FridayHold", daemon=True).start()
        full = contents_override if contents_override is not None else prompt

        def _gen(p):
            return _v5_gen_text(full if p is question else p, deep=True, model=deep_model)
        result = friday_router5.verified_answer(question, _gen, deep=True)
        if result.get("answer"):
            try:
                friday_core5.hud(confidence=result.get("confidence"), tool="verifier")
                log_event("Deep answer: " + result.get("notes", ""), kind="reasoning")
            except Exception:
                pass
            yield result["answer"]
            return
    except Exception as _deep_error:
        print("Deep route unavailable, answering normally:", _deep_error, flush=True)
    for piece in _stream_gemini_text(prompt, contents_override):
        yield piece


def _v5_save_files(flt):
    """Write files the model handed back (<<<FILE:name>>> blocks) and show them as file cards in the chat."""
    made = []
    try:
        for name, body in flt.files:
            path = friday_tools5.write_output(name, body)
            if path is None:
                speak("I wasn't allowed to create that file because file writing is blocked in my permissions.")
                continue
            card = friday_attach5.file_card(path, path.name)
            made.append((path.name, str(path)))
            print("FRIDAY_FILE::" + base64.b64encode(json.dumps(card).encode("utf-8")).decode("ascii"), flush=True)
    except Exception as _save_error:
        print("File creation failed:", _save_error, flush=True)
    return made


def ask_ai(question, _retried=False):
    global memory, _LAST_COMPOSED_MESSAGE, _DRAFTING_MODE, _GEMINI_LAST_ERROR_KIND
    _orig_question = question
    _GEMINI_LAST_ERROR_KIND = ""
    # 7.0 update safety net: a camera on/off sentence must never be answered by Gemini, whichever path brought it here.
    try:
        if friday_camera_gate.handle(str(question)):
            return ""
    except Exception:
        pass
    global _ATTACHED_CONTEXT
    if _ATTACHED_CONTEXT and time.time() - _ATTACHED_AT[0] > 2700:
        _ATTACHED_CONTEXT = []          # attachments stay available for follow-ups for 45 minutes
    _v5_route = {"route": "fast", "depth": 1}
    try:
        if friday_core5 is not None:
            _v5_route = friday_core5.route_for(str(question), bool(_ATTACHED_CONTEXT))
    except Exception:
        pass
    try:
        from friday_finance_engine import context as _friday_finance_context
        if re.search(r"\b(save|saving|savings|budget|expense|expenses|income|money|afford|spend|spending|goal|financial)\b", str(question), re.I):
            question = str(question) + "\n\n" + _friday_finance_context()
    except Exception:
        pass
    try:
        if _ATTACHED_CONTEXT:
            if friday_attach5 is not None:
                _att_block = friday_attach5.task_prompt(str(question), _ATTACHED_CONTEXT)
                if friday_core6 is not None:
                    _att_block = friday_core6.guard_attachment(_att_block)
                question = str(question) + _att_block
            else:
                from friday_attachment_engine import prompt_block
                question = str(question) + prompt_block(_ATTACHED_CONTEXT)
    except Exception as _attach_prompt_error:
        print("Attachment context unavailable:", _attach_prompt_error)
    _ensure_gemini_client()
    if client is None:
        print(f"\nGemini is unavailable ({GEMINI_STATUS_REASON}).")
        if GEMINI_STATUS_REASON.startswith("no_key"):
            speak("I need my Gemini API key before I can answer that, sir. Add it to the configured API key setting and I will recover automatically.")
        else:
            speak("I'm reconnecting to Gemini, sir. The request will retry automatically.")
        return ""

    started = time.perf_counter()
    print("\n🤖 Friday AI is thinking...", flush=True)
    memory.append({"role": "user", "content": question})
    conversation = []
    # V2045 FIX: "remember everything, previous AND current conversation"
    # -- this used to cap history at only the last 6 turns whenever
    # VOICE_LATENCY_FIRST was on (the default), so anything said more
    # than ~3 exchanges ago in the CURRENT session was already invisible
    # to Gemini, on top of long-term facts being skipped entirely below.
    # 20 recent turns is still small next to Gemini's context window and
    # costs negligible extra latency compared to the fact lookup and the
    # generation call itself, so both modes now keep real short-term
    # continuity within a session.
    for item in memory[-20:]:
        role = item.get("role", "user")
        content = item.get("content", "")
        if role == "user":
            conversation.append(f"User: {content}")
        elif role == "assistant":
            conversation.append(f"Friday: {content}")

    long_term_block = ""
    # FRIDAY 5.0: local full-text memory (SQLite FTS, a few ms) instead of a network embedding call on every question.
    _v5_memory_used = False
    try:
        if friday_core5 is not None:
            long_term_block = friday_core5.memory_context(str(_orig_question))
            _v5_memory_used = bool(long_term_block)
    except Exception:
        long_term_block = ""
    # FRIDAY 6.0: personality + emotional context + dated memories + voice style (instructions only, nothing spoken)
    try:
        if friday_core6 is not None:
            long_term_block += friday_core6.prompt_block(str(_orig_question))
        if friday_core7 is not None:
            long_term_block += friday_core7.prompt_block(str(_orig_question))
    except Exception:
        pass
    # V2045 FIX: long-term fact retrieval (facts distilled from EVERY past
    # conversation, not just this session -- see friday_context.py) was
    # previously skipped completely whenever VOICE_LATENCY_FIRST was on,
    # which is the default. That meant Friday reliably "forgot" anything
    # from a previous conversation the instant voice-latency mode was
    # active. This lookup is local/embedding-based (no extra network
    # round trip beyond what ask_ai already makes), so it is now always
    # attempted; only genuine failures are swallowed, never skipped by
    # design.
    try:
        # the embedding lookup needs a network round trip, so it is skipped on the fast path when local memory already answered
        facts = [] if (_v5_memory_used or _v5_route.get("route") in ("fast", "instant")) and friday_core5 is not None else friday_context.retrieve_relevant(question, top_k=8)
        if facts:
            long_term_block += "\n\nKnown long-term facts (from previous conversations):\n" + "\n".join(f"- {x}" for x in facts)
    except Exception as error:
        print("Long-term memory retrieval failed (continuing without it):", error)

    situational_block = ""
    if re.search(r"\b(this|that|it|here|on screen|on my screen)\b", question, re.I):
        try:
            active_title = get_active_window_title()
            if active_title:
                situational_block = f'\n\nCurrent focused window: "{active_title}".'
        except Exception:
            pass

    try:
        agent_context_block = (
            "\n\nContinuous FRIDAY state:\n" + friday_agent_core.context_block()
            + "\n\n" + friday_persona.character_prompt()
        )
    except Exception:
        agent_context_block = ""

    movie_block = ""
    try:
        if friday_movie_agent:
            movie_block = "\n\nLive FRIDAY agent context:\n" + friday_movie_agent.context_block()
    except Exception:
        pass

    human_block = ""
    try:
        h=_HUMAN_INTERACTION_STATE
        human_block=("\n\nHuman interaction signals (probabilistic, not facts): "
                      f"tone={h.get('tone')}, confidence={h.get('confidence')}, "
                      f"frustration={h.get('frustration')}, urgency={h.get('urgency')}, "
                      f"arousal={h.get('arousal')}, speech_rate_wpm={h.get('speech_rate_wpm')}. "
                      "Use these only to adapt communication style; never claim certainty about internal state.")
    except Exception: pass

    # V2.3.1: tell the AI what FRIDAY can really do (camera, screen, every page of the app) so it never answers "I have no access".
    try:
        agent_context_block += friday_chat_access.capability_block(question)
    except Exception:
        pass

    if VOICE_LATENCY_FIRST:
        # Spoken replies get a compact instruction envelope. The full FRIDAY
        # prompt remains available to non-voice workflows, while voice avoids
        # sending a large instruction/history payload before the first token.
        voice_prompt = (
            "You are FRIDAY 7.0, a calm, composed, witty, highly capable multi-tasking AI assistant with a cinematic-style voice. "
            "Answer the latest request directly. For spoken replies, lead with the useful answer, "
            "use short natural sentences, and avoid unnecessary preamble. Never invent facts. "
            "If an action is requested, state what you are doing or what was completed. "
            "Maintain the user's requested context and safety constraints. "
            "Resolve follow-ups such as 'that one' or 'the second part' from the conversation history. "
            "You can read files the user attaches, remember things long-term, diagnose the computer, run code after confirmation and create files; never claim an action you did not perform.\n"
            "Work out the real intent behind the words, including what the user most likely means by follow-ups and short phrases. "
            "Reason carefully before stating facts, numbers or recommendations, and give the single best answer first, then one useful extra only if it truly helps. "
            "If you are not sure, say so briefly and give your best estimate rather than guessing silently. "
            "Ask a question only when the request cannot be done without the answer; otherwise make a sensible assumption and say it. "
            "Keep replies short and spoken-natural unless the user asks for detail.\n"
        )
        prompt = (
            voice_prompt + long_term_block + situational_block + agent_context_block + human_block + _HUMAN_VOICE_STYLE
            # V2045 FIX: was conversation[-4:], AND long_term_block was
            # missing entirely on this branch -- see the two comments
            # above. Voice replies now get the same memory the
            # non-voice path always had.
            + "\nConversation history:\n" + "\n".join(conversation[-12:])
            + "\n\nLatest user request:\n" + question
        )
    else:
        prompt = (
            FRIDAY_PROMPT + long_term_block + situational_block + agent_context_block + movie_block + human_block
            + "\n\nConversation history:\n" + "\n".join(conversation)
            + "\n\nAnswer the user's latest request. Be concise for spoken responses unless detail is necessary."
        )

    try:
        # Streaming is the key latency change: TTS consumes sentences while
        # Gemini is still generating later sentences.  Apply any local tone
        # prefix BEFORE the first audio is emitted so the spoken output and
        # stored answer remain identical.
        contents_override = None
        try:
            media = [x for x in _ATTACHED_CONTEXT if x.get("kind") in ({"video"} if friday_attach5 is not None else {"image","video"}) and Path(str(x.get("path",""))).exists()]
            if media and client is not None and hasattr(client, "files"):
                uploaded=[]
                for item in media[:6]:
                    try:
                        uploaded.append(client.files.upload(file=str(item["path"])))
                    except Exception as _upload_error:
                        print("Gemini media upload skipped:", _upload_error)
                if uploaded:
                    contents_override = uploaded + [prompt]
        except Exception as _media_error:
            print("Multimodal attachment preparation skipped:", _media_error)
        # V2.3.1: while the camera is on, the newest camera picture goes along with any visual question so FRIDAY answers by sight.
        try:
            _cam_part = friday_chat_access.camera_part_for(_orig_question)
            if _cam_part is not None:
                if contents_override is None:
                    contents_override = [prompt, _cam_part]
                else:
                    contents_override = list(contents_override) + [_cam_part]
        except Exception as _cam_part_error:
            print("Camera picture for chat skipped:", _cam_part_error)
        _v5_filter = None
        try:
            if friday_attach5 is not None and _ATTACHED_CONTEXT:
                _v5_parts = friday_attach5.build_parts(_ATTACHED_CONTEXT)
                if _v5_parts:
                    contents_override = list(_v5_parts) + (list(contents_override) if contents_override is not None else [prompt])
        except Exception as _v5_parts_error:
            print("Attachment parts skipped:", _v5_parts_error)
        if _v5_route.get("route") == "deep" and not _ATTACHED_CONTEXT and _deep_route_wanted(str(_orig_question)):
            raw_stream = _v5_deep_stream(prompt, str(_orig_question), contents_override)
        else:
            _brain_model, _brain_think = _pick_brain(_v5_route.get("route"), _orig_question)
            raw_stream = _stream_gemini_text(prompt, contents_override, model=_brain_model, think=_brain_think)
        if friday_attach5 is not None and _ATTACHED_CONTEXT:
            _v5_filter = friday_attach5.FileBlockFilter()
            raw_stream = friday_attach5.filter_stream(raw_stream, _v5_filter)
        def _prefixed_stream():
            first_chunk = True
            prefix = ""
            for piece in raw_stream:
                if first_chunk:
                    first_chunk = False
                    lowered = (piece or "").lstrip().lower()
                    _op6 = ""
                    try:
                        _op6 = friday_core6.opener(str(_orig_question)) if friday_core6 is not None else ""
                    except Exception:
                        _op6 = ""
                    if _op6 and not lowered.startswith(("well", "don't worry", "one step", "i hear", "sorry")):
                        prefix = _op6
                    elif _LAST_USER_TONE == "frustrated" and not lowered.startswith(("i hear", "i understand", "sorry")):
                        prefix = "I hear you — let's sort this out. "
                    elif _LAST_USER_TONE == "urgent" and not lowered.startswith(("right away", "sure", "on it")):
                        prefix = "Right away. "
                    if prefix:
                        yield prefix
                yield piece
        answer = _stream_tts_sentences(_prefixed_stream()).strip()
        _v5_made_files = _v5_save_files(_v5_filter) if _v5_filter is not None else []
        if _v5_made_files:
            answer = (answer + " " if answer else "") + "[Created: " + ", ".join(n for n, _ in _v5_made_files) + "]"
            if not answer.strip("[]"):
                answer = "Done."
        if not answer:
            if friday_speech5 is not None and friday_speech5.is_aborted():
                return ""           # the user interrupted before any text came out
            raise RuntimeError("Gemini returned an empty response")
        try:
            if friday_core5 is not None:
                friday_core5.after_exchange(_orig_question, answer, _v5_route.get("route", "fast"))
                friday_core5.turn_end()
            if friday_core6 is not None:
                friday_core6.after_exchange(_orig_question, answer, _v5_route.get("route", "fast"))
            if friday_core7 is not None:
                friday_core7.after_exchange(_orig_question, answer, _v5_route.get("route", "fast"))
        except Exception:
            pass

        memory[-1]["content"] = question
        memory.append({"role": "assistant", "content": answer})
        memory[:] = friday_context.trim_conversation(memory)
        save_memory(memory)
        try:
            friday_context.record_assistant_response(answer)
        except Exception:
            pass
        # Keep durable-memory extraction off the voice critical path.
        def _background_memory():
            try:
                friday_context.maybe_extract_and_store(question, answer)
            except Exception as error:
                print("Fluid-memory extraction call failed (ignored):", error)
        threading.Thread(target=_background_memory, name="FridayMemory", daemon=True).start()

        composing_now = _looks_like_message_composition(question)
        if composing_now or _DRAFTING_MODE:
            _DRAFTING_MODE = True
            if not _AFFIRMATION_ONLY_PATTERN.match(question.strip()):
                _LAST_COMPOSED_MESSAGE = answer
        try:
            if friday_learning_engine:
                friday_learning_engine.learn(question, "conversation")
        except Exception:
            pass
        try:
            friday_agent_core.record_response(answer)
            delivery_plan = friday_agent_core.plan_delivery(answer, kind="answer")
            log_event(f"Response planned: {delivery_plan.get('max_sentences', 0)} sentence budget", kind="response")
        except Exception:
            pass
        print(f"⚡ AI→voice first-path elapsed: {time.perf_counter() - started:.2f}s", flush=True)
        try:
            if _API_HEALTH.get("state") != "ready":
                _emit_api_status("ready", "", f"Connected to Gemini ({GEMINI_MODEL}).")
        except Exception:
            pass
        # V2045 STUDY INTELLIGENCE -- proactive recommendation (research doc
        # point 2: "Even better: proactive recommendations"). Only ever
        # appended AFTER the real answer above, only in normal mode (Study
        # Mode already surfaces this data directly), and only when there is
        # a confidence-checked reason to speak up (see maybe_proactive_study_note).
        if not study_state.get("active"):
            try:
                note = maybe_proactive_study_note(question)
                if note:
                    speak(note)
            except Exception as _si_error:
                print("Proactive study note skipped (safe fallback):", _si_error)
        return answer
    except Exception as error:
        import traceback
        print("\nGemini error:", error)
        traceback.print_exc()
        if memory and memory[-1].get("role") == "user":
            memory.pop()
        kind = _GEMINI_LAST_ERROR_KIND or _classify_gemini_error(error)[0]
        if kind in ("busy", "network") and not _retried:
            # The promise in the message below is now real: one automatic retry.
            time.sleep(1.5)
            return ask_ai(_orig_question, _retried=True)
        _emit_api_status(kind if kind in ("key", "quota", "model", "busy", "network", "config") else "other",
                         kind, _friendly_gemini_problem(kind, error))
        _start_gemini_watchdog()
        answer = _spoken_gemini_problem(kind)
        speak(answer)
        return answer


# ============================================================
# ============================================================
# ADVANCED CAMBRIDGE STUDY MODE
# ============================================================
# ============================================================

STUDY_PROMPT = """
You are Friday Study Tutor, an advanced Cambridge International tutor.

Your job is to teach, diagnose, quiz, assess, revise and coach the learner.
You support these syllabuses:
9701 Cambridge International AS & A Level Chemistry
9702 Cambridge International AS & A Level Physics
9709 Cambridge International AS & A Level Mathematics
9618 Cambridge International AS & A Level Computer Science
4024 Cambridge O Level Mathematics (for the user's friend)

CORE RULES:
1. Be syllabus-aware. Do not invent syllabus requirements. If a supplied official syllabus PDF is available, treat it as the primary authority.
2. If the learner's textbook/PDF conflicts with the official syllabus, clearly distinguish textbook material from examinable syllabus content.
3. Teach for understanding first, then exam performance.
4. Use retrieval practice, spaced repetition, interleaving, elaboration, worked examples, error correction and exam-style application.
5. Adapt difficulty from demonstrated performance rather than assuming ability.
6. Never reveal an answer before giving the learner a reasonable chance to attempt a question, unless they ask for the answer.
7. When marking, explain exactly what was correct, what was missing, and how to improve.
8. For calculation questions, verify arithmetic and units carefully.
9. For chemistry, check equations, charges, stoichiometry, oxidation states, conditions and significant figures when relevant.
10. For physics, check equations, units, signs, vectors/scalars and assumptions when relevant.
11. For mathematics, show logically complete steps and check the result where practical.
12. For computer science, distinguish definitions, mechanisms, algorithms, pseudocode, complexity, architecture and application.
13. For 4024, use O Level Mathematics D level and do not mix it with 9709 unless explicitly comparing them.
14. Prefer concise spoken explanations, but the terminal may contain structured study material.
15. When a PDF is attached, ground document-specific answers in that PDF and say when information is not present in it.
16. Never pretend to have read a file that was not supplied successfully.
17. Track weaknesses and use them to choose future questions.
18. Use exam command words correctly: state, define, describe, explain, calculate, determine, suggest, compare, evaluate, discuss, etc.
19. For quizzes, output a clear question first. Do not immediately reveal the answer.
20. After an answer, classify it as correct, mostly correct, partially correct or incorrect and record the relevant topic.

TEACHING LOOP:
Diagnose -> Explain -> Guided example -> Active recall -> Independent question -> Mark -> Error analysis -> Targeted retry -> Spaced review.

QUIZ POLICY:
Mix easy, medium and hard questions. Prefer application and unfamiliar contexts over pure recall when appropriate. Include plausible distractors for MCQs. Do not make every question predictable.

EXAM POLICY:
When asked for exam practice, match the requested paper style, command words and expected depth. Do not claim a question is an official Cambridge past-paper question unless the source actually is one.

STUDY PLAN POLICY:
Use mastery data, recent mistakes, due reviews and the learner's available time to prioritize topics.
"""

# These are high-level syllabus anchors, not a replacement for the official syllabus PDF.
# The current Cambridge pages list the relevant syllabus years; users can attach the official
# syllabus PDFs for exact learning-outcome-level checking.
SYLLABUS_MAP = {
    "9701": {
        "name": "Cambridge International AS & A Level Chemistry",
        "year": "2025-2027",
        "anchors": [
            "Atoms, molecules and stoichiometry", "Atomic structure", "Chemical bonding",
            "States of matter", "Chemical energetics", "Electrochemistry", "Equilibria",
            "Reaction kinetics", "Periodicity", "Group 2", "Group 17", "Nitrogen and sulfur",
            "Introduction to organic chemistry", "Hydrocarbons", "Halogen derivatives",
            "Hydroxy compounds", "Carbonyl compounds", "Carboxylic acids and derivatives",
            "Nitrogen compounds", "Polymerisation", "Analytical techniques", "Organic synthesis",
            "Transition elements", "Aromatic chemistry", "Practical skills"
        ]
    },
    "9702": {
        "name": "Cambridge International AS & A Level Physics",
        "year": "2025-2027",
        "anchors": [
            "Physical quantities and units", "Kinematics", "Dynamics", "Forces, density and pressure",
            "Work, energy and power", "Deformation of solids", "Waves", "Superposition",
            "Electric fields", "Current of electricity", "D.C. circuits", "Particle physics",
            "Motion in a circle", "Gravitational fields", "Ideal gases", "Temperature",
            "Thermal physics", "Oscillations", "Electric fields and capacitance", "Magnetic fields",
            "Charged particles", "Electromagnetic induction", "Alternating currents", "Quantum physics",
            "Nuclear physics", "Medical physics", "Astronomy and cosmology", "Practical skills"
        ]
    },
    "9709": {
        "name": "Cambridge International AS & A Level Mathematics",
        "year": "2026-2027",
        "anchors": [
            "Quadratics", "Functions", "Coordinate geometry", "Circular measure", "Trigonometry",
            "Series", "Differentiation", "Integration", "Numerical methods", "Vectors",
            "Algebra", "Logarithmic and exponential functions", "Probability", "Discrete random variables",
            "Normal distribution", "Mechanics", "Kinematics", "Forces and Newton's laws",
            "Energy and momentum", "Pure mathematics", "Statistics", "Probability and statistics"
        ]
    },
    "9618": {
        "name": "Cambridge International AS & A Level Computer Science",
        "year": "2027-2029",
        "anchors": [
            "Information representation", "Communication and internet technologies", "Hardware",
            "Processor fundamentals", "System software", "Security", "Ethics and ownership",
            "Databases", "Automated and emerging technologies", "Computational thinking",
            "Algorithms", "Programming", "Data structures", "Abstract data types",
            "Recursion", "OOP concepts", "Software development", "Data representation",
            "Logic gates and Boolean logic", "Computer architecture", "Networks", "Artificial intelligence"
        ]
    },
    "4024": {
        "name": "Cambridge O Level Mathematics (Syllabus D)",
        "year": "2025-2027",
        "anchors": [
            "Number", "Set language and notation", "Algebra and graphs", "Geometry",
            "Mensuration", "Coordinate geometry", "Trigonometry", "Matrices and transformations",
            "Vectors", "Probability", "Statistics", "Functions", "Sequences and series",
            "Ratio, proportion and rates", "Financial mathematics", "Problem solving"
        ]
    }
}


def load_json_file(path, default):
    return load_json_recover(path, default)


def save_json_file(path, data):
    try:
        atomic_json_save(path, data)
    except OSError as error:
        print("Study save error:", error)


study_memory = load_json_file(STUDY_MEMORY_FILE, {
    "sessions": [],
    "mistakes": [],
    "mastery": {},
    "reviews": [],
    "preferences": {"question_style": "mixed", "difficulty": 2}
})

study_state = load_json_file(STUDY_STATE_FILE, {
    "active": False,
    "subject": None,
    "topic": None,
    "pdfs": [],
    "last_question": None,
    "last_answer": None,
    "quiz": None
})

# ============================================================
# STUDY PLANS & REMINDERS
# ------------------------------------------------------------
# Custom, per-subject deadlines the learner sets themselves --
# "I want to finish internet by next week" -- stored independently
# of study_state["active"] so they persist and keep firing reminders
# whether Study Mode is currently open or not, and whether Friday is
# in the normal dashboard, minimised to the widget, or Study Mode is
# fully closed. A plain background thread (study_reminder_loop, wired
# up near the bottom of this file alongside the other daemon threads)
# checks these on a timer completely independently of study_state.
# ============================================================
STUDY_PLANS_FILE = STUDY_FILES_DIR / "study_plans.json"
study_plans = load_json_file(STUDY_PLANS_FILE, {"plans": []})

# Milestones (days left) that get their own reminder, largest first.
# 0 = due today, a negative number below is treated as "overdue".
_REMINDER_MILESTONES = [7, 3, 1, 0]

_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def save_study_plans():
    save_json_file(STUDY_PLANS_FILE, study_plans)


def parse_relative_deadline(text):
    """Turns a spoken/typed deadline phrase into a datetime.date, or
    None if nothing recognisable was said. Deliberately simple (regex
    + a small lookup table) rather than a heavy NLP date-parsing
    dependency -- covers every phrasing this app's own commands
    actually use. Always resolves relative to *today*."""
    if not text:
        return None
    t = text.strip().lower()
    t = re.sub(r"^(by|on|before|due)\s+", "", t)
    today = datetime.date.today()

    if t in ("today", "tonight", "eod", "end of day"):
        return today
    if t == "tomorrow":
        return today + datetime.timedelta(days=1)
    if t in ("next week", "in a week", "a week", "one week"):
        return today + datetime.timedelta(days=7)
    if t in ("next month", "in a month", "a month", "one month"):
        return today + datetime.timedelta(days=30)
    if t in ("next weekend", "the weekend", "this weekend"):
        days_until_saturday = (5 - today.weekday()) % 7 or 7
        return today + datetime.timedelta(days=days_until_saturday)

    match = re.match(r"in (\d+)\s*(day|days|week|weeks|month|months)$", t)
    if match:
        amount = int(match.group(1))
        unit = match.group(2)
        if unit.startswith("day"):
            return today + datetime.timedelta(days=amount)
        if unit.startswith("week"):
            return today + datetime.timedelta(weeks=amount)
        if unit.startswith("month"):
            return today + datetime.timedelta(days=amount * 30)

    match = re.match(r"(\d+)\s*(day|days|week|weeks)$", t)
    if match:
        amount = int(match.group(1))
        unit = match.group(2)
        return today + datetime.timedelta(days=amount if unit.startswith("day") else amount * 7)

    for i, day_name in enumerate(_WEEKDAYS):
        if day_name in t:
            days_ahead = (i - today.weekday()) % 7
            if days_ahead == 0:
                days_ahead = 7  # "by friday" said ON a friday means NEXT friday
            return today + datetime.timedelta(days=days_ahead)

    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%d %B", "%d %B %Y", "%B %d", "%B %d %Y"):
        try:
            parsed = datetime.datetime.strptime(t.title() if "%B" in fmt else t, fmt)
            year = parsed.year if parsed.year != 1900 else today.year
            candidate = datetime.date(year, parsed.month, parsed.day)
            if "%Y" not in fmt and candidate < today:
                candidate = candidate.replace(year=year + 1)
            return candidate
        except Exception:
            continue

    return None


def _days_left(deadline_iso):
    try:
        deadline = datetime.date.fromisoformat(deadline_iso)
    except Exception:
        return None
    return (deadline - datetime.date.today()).days


def add_study_plan(subject_or_topic, task_text, deadline_date):
    entry = {
        "id": f"plan_{int(time.time() * 1000)}",
        "subject": (subject_or_topic or "general").strip(),
        "task": (task_text or subject_or_topic or "").strip(),
        "deadline": deadline_date.isoformat(),
        "created": datetime.datetime.now().isoformat(timespec="seconds"),
        "done": False,
        "notified": [],
    }
    study_plans.setdefault("plans", []).append(entry)
    save_study_plans()
    days = _days_left(entry["deadline"])
    log_event(f"Plan added: {entry['task']} (due {entry['deadline']})", kind="plan")
    print(f"STUDY_PLAN_ADDED::{json.dumps(entry)}")
    if days is not None and days >= 0:
        # Judgement, not just execution: a genuinely tight deadline is
        # worth a brief, honest observation, not silent agreement --
        # exactly the "challenge poor decisions/estimates" behaviour
        # from the research (kept to real edge cases, not every plan).
        if days <= 1:
            speak(f"Got it. I've added \"{entry['task']}\", due in {days} day{'s' if days != 1 else ''} — that's tight, sir, so you may want to start on it today.")
        else:
            speak(f"Got it. I've added \"{entry['task']}\" with a deadline in {days} day{'s' if days != 1 else ''}, and I'll remind you as it gets closer.")
    else:
        speak(f"Got it. I've added \"{entry['task']}\" to your plans.")
    return entry


def find_matching_plans(needle):
    needle = (needle or "").strip().lower()
    if not needle:
        return list(study_plans.get("plans", []))
    return [
        p for p in study_plans.get("plans", [])
        if needle in p.get("task", "").lower() or needle in p.get("subject", "").lower()
    ]


# Recognises things like "finish/complete/study/revise/review X by Y",
# "i want to X by Y", "add a plan for X by Y", "remind me to X by Y".
_PLAN_ADD_PATTERNS = [
    re.compile(r"^(?:i (?:want|need|have) to |i'm going to |i am going to |i will |i'll )?"
               r"(?:finish|complete|revise|review|study|do|prep(?:are)?)\s+(.+?)\s+by\s+(.+)$"),
    re.compile(r"^add (?:a )?plan(?: for| to)?\s+(.+?)\s+by\s+(.+)$"),
    re.compile(r"^remind me to\s+(.+?)\s+by\s+(.+)$"),
    re.compile(r"^set a? ?reminder (?:for|to)\s+(.+?)\s+by\s+(.+)$"),
    re.compile(r"^(.+?)\s+(?:is|are)\s+due\s+(.+)$"),
]

_PLAN_LIST_PHRASES = ["show my plans", "my study plans", "list my plans", "what are my plans",
                      "show my study plan", "list study plans", "my plans"]


def try_handle_plan_command(command):
    """Top-priority custom-plan-and-reminder handler. Returns a truthy
    value (True) if it fully handled `command` (so handle_command()
    should stop there), or None if this wasn't a plan-related command
    at all. Deliberately called BEFORE the study-mode gate in
    handle_command() so this works identically whether Study Mode is
    on or off, and from the normal dashboard, Study Mode, OR the
    minimised widget (typed/voice commands reach the same backend
    either way)."""
    c = command.strip().lower()
    if not c:
        return None

    if c in _PLAN_LIST_PHRASES or c.startswith("show my plans") or c.startswith("list my plans"):
        plans = [p for p in study_plans.get("plans", []) if not p.get("done")]
        if not plans:
            speak("You don't have any study plans set yet. Just tell me something like 'I want to finish internet by next week'.")
            return True
        lines = []
        for p in plans:
            days = _days_left(p["deadline"])
            if days is None:
                continue
            if days < 0:
                lines.append(f"{p['task']} is overdue by {abs(days)} day{'s' if abs(days) != 1 else ''}")
            elif days == 0:
                lines.append(f"{p['task']} is due today")
            else:
                lines.append(f"{p['task']} in {days} day{'s' if days != 1 else ''}")
        speak("Here's what's on your plan: " + "; ".join(lines) + ".")
        return True

    days_left_match = re.match(r"^(?:how many|how much time|how many days)\s+(?:days\s+)?(?:left|remain(?:ing)?)\s*(?:for|on|until)?\s*(.*)$", c)
    if days_left_match:
        needle = days_left_match.group(1).strip()
        matches = find_matching_plans(needle)
        if not matches:
            speak(f"I couldn't find a plan matching '{needle}'." if needle else "Tell me which plan you mean, for example 'days left for internet'.")
            return True
        for p in matches[:3]:
            days = _days_left(p["deadline"])
            if days is None:
                continue
            if days < 0:
                speak(f"{p['task']} was due {abs(days)} day{'s' if abs(days) != 1 else ''} ago.")
            elif days == 0:
                speak(f"{p['task']} is due today.")
            else:
                speak(f"You have {days} day{'s' if days != 1 else ''} left to {p['task']}.")
        return True

    delete_match = re.match(r"^(?:delete|remove|cancel) (?:the )?plan(?: for)?\s+(.+)$", c)
    if delete_match:
        needle = delete_match.group(1).strip()
        matches = find_matching_plans(needle)
        if not matches:
            speak(f"I couldn't find a plan matching '{needle}'.")
            return True
        remaining = [p for p in study_plans.get("plans", []) if p not in matches]
        study_plans["plans"] = remaining
        save_study_plans()
        speak(f"Removed {len(matches)} matching plan{'s' if len(matches) != 1 else ''}.")
        return True

    for pattern in _PLAN_ADD_PATTERNS:
        match = pattern.match(c)
        if not match:
            continue
        task_text, deadline_text = match.group(1).strip(), match.group(2).strip()
        if not task_text or not deadline_text:
            continue
        deadline_date = parse_relative_deadline(deadline_text)
        if deadline_date is None:
            continue
        # Guard against accidentally matching things that only happen
        # to contain " by ", like "explain this past paper by walking
        # through it" -- require the deadline half to actually resolve
        # to a date (done above) AND not itself look like a normal
        # command already handled elsewhere.
        if any(x in task_text for x in ["study mode", "diagram", "syllabus", "quiz me", "exam mode"]):
            continue
        add_study_plan(task_text, task_text, deadline_date)
        return True

    return None


def study_reminder_loop():
    # Disabled in FRIDAY; finance/resource reminders are handled separately.
    return

def set_study_mode_active(active):
    """
    Flip study_state["active"] and, whenever it actually changes,
    print an ACTION:: marker -- the same pattern main.js already uses
    for window control (ACTION::MINIMIZE_WIDGET / ACTION::RESTORE_WINDOW).
    Previously the Study Mode *dashboard* (the visual screen in the UI)
    was toggled purely by app.js independently re-matching keywords
    like "study mode" / "exit study mode" against recognized text --
    a second, separate phrase list from the one used here. Whenever
    the two lists didn't cover exactly the same phrases (e.g. "stop
    study mode" or "study mode off" being recognized here but not in
    app.js's shorter exit list), the dashboard could visually stay
    open or closed even though this flag said otherwise. Printing the
    real transition here makes the UI authoritative: it reacts to
    what study_state actually became, not to which words were used to
    get there.
    """
    changed = study_state.get("active") != active
    study_state["active"] = active
    if changed:
        print("ACTION::STUDY_MODE_ON" if active else "ACTION::STUDY_MODE_OFF")


def save_study():
    save_json_file(STUDY_MEMORY_FILE, study_memory)
    save_json_file(STUDY_STATE_FILE, study_state)


def normalize_subject(text):
    text = text.lower().strip()
    aliases = {
        "chemistry": "9701", "9701": "9701", "a level chemistry": "9701",
        "physics": "9702", "9702": "9702", "a level physics": "9702",
        "maths": "9709", "math": "9709", "9709": "9709", "a level maths": "9709",
        "computer science": "9618", "cs": "9618", "9618": "9618",
        "4024": "4024", "o level maths": "4024", "o level math": "4024",
        "friend maths": "4024", "friend math": "4024"
    }
    for key, code in aliases.items():
        if key in text:
            return code
    return None


def study_mastery_key(subject, topic):
    return f"{subject}|{(topic or 'general').strip().lower()}"


def update_mastery(subject, topic, result, difficulty=2, subtopic=None,
                    mistake_type=None, marks_lost=0, marks_total=None, question_type=None):
    """Kept as the original entry point every existing call site already
    uses (signature unchanged: subject, topic, result, difficulty). Now
    delegates to friday_study_intelligence.record_attempt() so mastery,
    mistakes AND the new detailed mistake fields (subtopic, mistake_type,
    marks_lost, question_type -- research doc point 4) all go through one
    shared write-path that Normal Mode's Study Intelligence queries can
    also read. Falls back to the original inline logic if that module
    failed to import, so nothing regresses."""
    correct = (result == "correct")
    if study_intel is not None:
        return study_intel.record_attempt(
            study_memory, subject, topic, correct,
            subtopic=subtopic, mistake_type=mistake_type or (None if correct else "unspecified"),
            marks_lost=marks_lost, marks_total=marks_total, question_type=question_type,
            difficulty=difficulty, source="study_mode",
        )

    key = study_mastery_key(subject, topic)
    current = study_memory["mastery"].get(key, {
        "subject": subject, "topic": topic or "general", "attempts": 0,
        "correct": 0, "score": 0.0, "difficulty": difficulty,
        "last_seen": None, "streak": 0
    })
    current["attempts"] += 1
    if result == "correct":
        current["correct"] += 1
        current["streak"] += 1
    else:
        current["streak"] = 0
    raw = current["correct"] / max(1, current["attempts"])
    current["score"] = round(max(0.0, min(1.0, raw * (1.0 if difficulty <= 2 else 0.95))), 3)
    current["difficulty"] = difficulty
    current["last_seen"] = datetime.datetime.now().isoformat(timespec="seconds")
    study_memory["mastery"][key] = current

    if result != "correct":
        study_memory["mistakes"].append({
            "subject": subject, "topic": topic or "general", "result": result,
            "difficulty": difficulty, "date": current["last_seen"]
        })
        study_memory["mistakes"] = study_memory["mistakes"][-300:]
    return current


def build_study_context(subject=None, topic=None):
    subject = subject or study_state.get("subject")
    topic = topic or study_state.get("topic")
    mastery = []
    for item in study_memory.get("mastery", {}).values():
        if subject and item.get("subject") != subject:
            continue
        mastery.append(item)
    mastery.sort(key=lambda x: x.get("score", 0.0))
    weak = mastery[:8]
    mistakes = [m for m in study_memory.get("mistakes", []) if not subject or m.get("subject") == subject][-12:]
    return {
        "subject": subject,
        "topic": topic,
        "syllabus": SYLLABUS_MAP.get(subject, {}),
        "mastery": weak,
        "recent_mistakes": mistakes,
        "attached_pdfs": study_state.get("pdfs", []),
        "attached_documents": study_state.get("documents", [])
    }


# ============================================================
# V2045 STUDY INTELLIGENCE -- NORMAL MODE COMMAND HANDLER
# ------------------------------------------------------------
# Everything in this block works whether Study Mode is on or off,
# per the research doc's "Give normal mode full Study Mode commands"
# section. It ONLY reads/writes study_memory + study_state through
# friday_study_intelligence, and only starts an actual Study Mode
# session (study_quiz / study_teach) when the user explicitly asks
# to ("quiz me", "start study mode") -- a plain "what should I
# study" never opens anything by itself, it just answers out loud.
# ============================================================

_SI_AWAITING_FOCUS_CONFIRM = False  # True right after Friday proposed a topic and asked "would you like me to focus on that?"


def _si_speak_recommendation(rec):
    if not rec:
        speak("Sir, I don't have enough attempts recorded yet to confidently point to a weak topic. Do a few more questions or a past paper and ask me again.")
        return
    reason = "; ".join(rec["reason"])
    speak(
        f"Sir, based on your recent study performance, {rec['topic']} is currently a priority topic in {SYLLABUS_MAP.get(rec['subject'], {}).get('name', rec['subject'])}. "
        f"{reason}. Would you like me to focus your next study session on {rec['topic']}?"
    )


def try_handle_study_intelligence_command(original_command):
    # FRIDAY intentionally has no Study Mode or study recommendations.
    return None

def maybe_proactive_study_note(base_reply_topic_hint=""):
    """Point 2 ('Even better: proactive recommendations') + point 10
    ('don't nag'): appended (never prepended) to an otherwise-unrelated
    normal-mode reply, and only when awareness is on, the frequency
    setting allows it, and there IS a confident recommendation. Called
    by the normal Gemini-fallback path below with whatever the user's
    original topic was, so a study-relevant question is more likely to
    trigger it than a completely unrelated one (still gated on real
    confidence -- this never invents a reason to speak up)."""
    if study_intel is None:
        return None
    settings = study_intel.get_awareness_settings(study_memory)
    if not settings["study_awareness"] or settings["recommendation_frequency"] == "off":
        return None
    if settings["recommendation_frequency"] == "relevant_moments" and not re.search(
        r"\b(study|exam|revise|revision|physics|chemistry|math|maths|paper|topic|syllabus)\b",
        base_reply_topic_hint or "", re.I,
    ):
        return None
    rec = study_intel.get_study_recommendation(study_memory)
    if not rec or rec["confidence"] != study_intel.CONFIDENCE_RELIABLE:
        return None  # only speak up unprompted for a RELIABLE signal, never a 1-2-attempt guess
    return f"Also, sir -- I've noticed that your {rec['topic']} performance has been consistently weaker than your other {SYLLABUS_MAP.get(rec['subject'], {}).get('name', rec['subject'])} topics. Would you like to spend some time on it?"


def study_generate(prompt, subject=None, topic=None, attached=True):
    _ensure_gemini_client()
    context = build_study_context(subject, topic)
    context_text = json.dumps(context, ensure_ascii=False, indent=2)
    contents = []

    system = STUDY_PROMPT + "\n\nLEARNER STUDY STATE:\n" + context_text
    contents.append(system)

    # Reuse uploaded study documents when available. Files API keeps them reusable
    # for study calls. Keep the legacy pdf list for backward compatibility and add
    # the new generic document list used by Explanation Centre.
    if attached:
        seen_names = set()
        for item in list(study_state.get("pdfs", [])) + list(study_state.get("documents", [])):
            name = item.get("name") if isinstance(item, dict) else None
            if not name or name in seen_names:
                continue
            seen_names.add(name)
            try:
                uploaded = client.files.get(name=name)
                contents.append(uploaded)
            except Exception as error:
                print("Could not retrieve study file:", error)

    contents.append(prompt)

    def _generate():
        response = client.models.generate_content(model=GEMINI_MODEL, contents=contents)
        answer = getattr(response, "text", None)
        if not answer or not str(answer).strip():
            raise RuntimeError("Study AI returned an empty response")
        return str(answer).strip()
    try:
        return run_resilient("gemini.study", _generate, attempts=3)
    except Exception as error:
        print("Study AI error (after bounded recovery):", error)
        return "I could not connect to the study brain right now. Your study state is safe; please try again."


# ============================================================
# PSEUDOCODE TESTER — Study Mode  (V2045: paste-and-RUN, not generate)
# ------------------------------------------------------------
# Per explicit user request, this no longer asks the AI to invent a
# program. The student pastes their OWN code; Friday actually EXECUTES
# it (in an isolated subprocess with a hard timeout) and reports the
# real stdout, any real error, and a genuine line-by-line execution
# trace with the real variable values at each step -- "shows me how
# it works" via ground truth, not a guess. Only Python is executed
# (the CS syllabus's working language and the only interpreter this
# app can guarantee is present); pasted language-agnostic pseudocode
# or another language will surface as a normal syntax error, which is
# itself useful diagnostic information for the student.
# ============================================================
import subprocess as _pc_subprocess
import tempfile as _pc_tempfile

PSEUDOCODE_RUN_TIMEOUT_SECONDS = 6
PSEUDOCODE_MAX_TRACE_STEPS = 400

_PSEUDOCODE_RUNNER_SOURCE = '''
import sys, json, io, traceback

MAX_STEPS = {max_steps}
USER_FILE = sys.argv[1]
_trace = []
_step_count = [0]

def _safe_repr(v):
    try:
        r = repr(v)
    except Exception:
        r = "<unrepresentable>"
    return r if len(r) <= 120 else r[:117] + "..."

def _tracer(frame, event, arg):
    if frame.f_code.co_filename != USER_FILE:
        return _tracer
    if event == "line":
        _step_count[0] += 1
        if _step_count[0] > MAX_STEPS:
            raise RuntimeError(
                "Pseudocode Tester stopped after " + str(MAX_STEPS) +
                " traced lines -- this usually means an infinite loop."
            )
        snapshot = {{k: _safe_repr(v) for k, v in frame.f_locals.items() if not k.startswith("__")}}
        _trace.append({{"line": frame.f_lineno, "locals": snapshot}})
    return _tracer

_stdout_buffer = io.StringIO()
_real_stdout = sys.stdout
sys.stdout = _stdout_buffer
_error = None
try:
    with open(USER_FILE, "r", encoding="utf-8") as _f:
        _code_text = _f.read()
    _compiled = compile(_code_text, USER_FILE, "exec")
    sys.settrace(_tracer)
    exec(_compiled, {{"__name__": "__main__"}})
except Exception as exc:
    _error = "".join(traceback.format_exception_only(type(exc), exc)).strip()
finally:
    sys.settrace(None)
    sys.stdout = _real_stdout

print("__PSEUDOCODE_RESULT_START__")
print(json.dumps({{"stdout": _stdout_buffer.getvalue(), "trace": _trace, "error": _error}}, ensure_ascii=False))
print("__PSEUDOCODE_RESULT_END__")
'''


def study_pseudocode_run(payload):
    """Runs student-pasted code and returns real output + a real
    execution trace. Printed as STUDY_PSEUDOCODE_RUN:: for the Study
    Mode UI (index.html's Pseudocode Tester page)."""
    try: data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception: data = {}
    code = str(data.get("code") or "").rstrip()
    stdin_text = str(data.get("stdin") or "")
    if not code.strip():
        speak("Paste the code you want me to run first.")
        return True

    speak("Running your code now, sir.")
    result = {"stdout": "", "trace": [], "error": None, "timed_out": False}
    tmp_dir = None
    try:
        tmp_dir = _pc_tempfile.mkdtemp(prefix="friday_pseudocode_")
        user_path = os.path.join(tmp_dir, "student_code.py")
        runner_path = os.path.join(tmp_dir, "runner.py")
        with open(user_path, "w", encoding="utf-8") as f:
            f.write(code)
        with open(runner_path, "w", encoding="utf-8") as f:
            f.write(_PSEUDOCODE_RUNNER_SOURCE.format(max_steps=PSEUDOCODE_MAX_TRACE_STEPS))

        proc = _pc_subprocess.run(
            [sys.executable, runner_path, user_path],
            input=stdin_text, capture_output=True, text=True,
            timeout=PSEUDOCODE_RUN_TIMEOUT_SECONDS,
        )
        out = proc.stdout or ""
        start = out.find("__PSEUDOCODE_RESULT_START__")
        end = out.find("__PSEUDOCODE_RESULT_END__")
        if start != -1 and end != -1:
            json_text = out[start + len("__PSEUDOCODE_RESULT_START__"):end].strip()
            try:
                result = json.loads(json_text)
            except Exception:
                result["error"] = "Friday could not parse the execution result."
        else:
            # The runner itself crashed before printing its result markers
            # (e.g. it couldn't even start) -- surface stderr directly.
            result["error"] = (proc.stderr or "The pseudocode runner failed to start.").strip()[:4000]
    except _pc_subprocess.TimeoutExpired:
        result["timed_out"] = True
        result["error"] = f"Execution was stopped after {PSEUDOCODE_RUN_TIMEOUT_SECONDS} seconds (still running -- check for an infinite loop or a blocking input() call)."
    except Exception as error:
        result["error"] = f"Friday could not run that code: {error}"
    finally:
        try:
            if tmp_dir:
                shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

    result["trace"] = (result.get("trace") or [])[:PSEUDOCODE_MAX_TRACE_STEPS]
    result["code"] = code
    print("STUDY_PSEUDOCODE_RUN::" + json.dumps(result, ensure_ascii=False))
    if result.get("error"):
        speak("Your code did not run cleanly, sir. The error is on screen.")
    elif result.get("stdout", "").strip():
        speak("Done. Your code ran successfully -- the output and a step-by-step trace are on screen.")
    else:
        speak("Your code ran successfully with no printed output. The full execution trace is on screen.")
    return True


def study_pseudocode_explain(payload):
    """Explains ONE line of the student's OWN pasted code, grounded in
    the REAL variable values captured for that line during the actual
    run above (not a guess) -- the UI sends back the matching trace
    entry/entries for the clicked line alongside the code."""
    try: data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception: data = {}
    subject = str(data.get("subject") or study_state.get("subject") or "").strip()
    code = str(data.get("code") or "").strip()
    line = str(data.get("line") or "").strip()
    line_text = str(data.get("line_text") or "").strip()
    occurrences = data.get("occurrences") or []  # list of {locals: {...}} snapshots for this exact line number
    if not code or not line:
        return True

    evidence = ""
    if occurrences:
        shown = occurrences[:3]
        evidence = "\nACTUAL RUNTIME VALUES observed on this line during execution (ground truth, not a guess):\n" + \
            "\n".join(f"  visit {i+1}: {json.dumps(o.get('locals', {}), ensure_ascii=False)}" for i, o in enumerate(shown))
        if len(occurrences) > 3:
            evidence += f"\n  ... and {len(occurrences) - 3} more visit(s) to this line."
    else:
        evidence = "\n(This line was never actually executed in the run -- likely inside a branch or loop that did not run this time.)"

    prompt = (
        f"SYLLABUS: {subject}\nThe learner pasted the following complete program:\n---\n{code}\n---\n"
        f"They selected LINE {line}: {line_text}\n{evidence}\n"
        "Explain ONLY this line, grounded strictly in the real runtime values shown above where available -- "
        "never invent a value that was not observed. Cover: what it does, why it is needed here, and how it "
        "changes program state. If it was never executed, say so and explain when it WOULD run. "
        "Return JSON only: {\"line\":\"" + line + "\",\"explanation\":\"...\",\"common_mistake\":\"...\"}"
    )
    raw = study_generate(prompt, subject=subject, topic="pseudocode tester", attached=False)
    try:
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip(), flags=re.I | re.S).strip()
        result = json.loads(cleaned)
    except Exception:
        result = {"line": line, "explanation": raw, "common_mistake": ""}
    result["line"] = line
    print("STUDY_PSEUDOCODE_EXPLANATION::" + json.dumps(result, ensure_ascii=False))
    study_speak(str(result.get("explanation") or "Line explanation ready."))
    return True


# ============================================================
# DIAGRAM EXPLANATION MODE (3D "Diagram Lab" inside Study Mode)
# ------------------------------------------------------------
# Turns a topic ("sp3 hybrid orbitals", "Bohr model energy levels",
# "projectile motion") into a small JSON scene description that the
# Study Mode UI renders as an interactive, animated 3D diagram
# (Three.js, see the "Diagram Lab" page in the Study Mode iframe),
# while Friday speaks a narrated walkthrough of it aloud.
#
# Same pipeline as study_generate() above (reuses the Gemini client
# and study context) but the model is instructed to return ONLY a
# strict JSON object matching DIAGRAM_SCHEMA_HINT, rather than free
# text -- so it can be handed straight to the renderer. Printed as a
# single-line STUDY_DIAGRAM::<json> marker, exactly like
# STUDY_EXPLAIN:: is used for past-paper explanations, so main.js /
# app.js just forward it into the Study Mode iframe unchanged.
# ============================================================

DIAGRAM_SCHEMA_HINT = """
Reply with ONLY a single raw JSON object -- no markdown fences, no commentary before or after it.
It must match this exact shape:

{
  "title": "short title string",
  "summary": "1-2 plain-English sentences on what this diagram shows",
  "legend": [ {"color": "#8a8a8a", "label": "Carbon"}, {"color": "#e23d3d", "label": "Oxygen"} ],
  "keyPoints": ["Short exam-style bullet point", "Another key fact"],
  "equation": "Optional plain-text equation, e.g. CH3COOCH2CH3 + H2O -> CH3COOH + C2H5OH",
  "conditions": ["Optional short condition, e.g. Acid-catalysed: dilute H2SO4 (warm)"],
  "related": ["Optional short related-concept name, e.g. Esterification (reverse reaction)"],
  "objects": [
    {
      "id": "unique_snake_case_id",
      "type": "sphere | orbitalLobe | electron | electronOrbit | energyLevel | arrow | bond | wave | ring | label",
      "position": [x, y, z],
      "direction": [x, y, z],
      "to": "another_object_id",
      "toPosition": [x, y, z],
      "radius": 0.5,
      "length": 1.5,
      "width": 3,
      "y": 0,
      "color": "#22d3ee",
      "label": "short floating caption or empty string",
      "detail": "1-2 sentence extra explanation shown when the student clicks/focuses this exact object -- REQUIRED (never omitted, never an empty string) for every \"energyLevel\", \"orbitalLobe\", and \"electron\" object, since those are exactly what a student clicks on in an orbital/bonding diagram and a blank popup reads as a broken diagram. Optional only for purely decorative/anchor objects (e.g. a plain background \"sphere\" with no physics of its own).",
      "level": "energyLevel_object_id -- ONLY for an \"electron\" object: which energyLevel object it currently occupies, so the synced 2D orbital-box panel can place it correctly. Omit entirely for topics with no energyLevel objects.",
      "orbitalIndex": "0 -- ONLY for an \"electron\" object: WHICH individual degenerate orbital box within its \"level\" it sits in (0-based). E.g. within a \"2p\" energyLevel that has \"orbitals\":3, use 0/1/2 for 2px/2py/2pz. Always 0 for a level with \"orbitals\":1 (e.g. 2s).",
      "spinDir": "\"up\" | \"down\" -- ONLY for an \"electron\" object: which arrow slot it draws in inside its box (standard convention: fill every box's \"up\" slot first across all degenerate boxes -- Hund's rule -- before any box gets a second, \"down\", electron).",
      "orbitals": "integer -- ONLY for an \"energyLevel\" object: how many separate degenerate orbital boxes to draw side-by-side on this row (1 for s, 3 for p, 4 for sp3, 3 for sp2, 2 for sp, 5 for d). Omit/default 1.",
      "hybridSet": "\"sp\" | \"sp2\" | \"sp3\" | \"sp3d\" | \"sp3d2\" -- ONLY for (a) an \"orbitalLobe\" that is one of a set of hybrid orbitals, or (b) a substituent atom's \"sphere\" that bonds through one of those hybrid orbitals. Do NOT try to compute the correct 3D direction/position yourself for these -- the renderer OVERRIDES it from this field plus \"hybridIndex\" with the exact textbook-correct tetrahedral (sp3, 109.5°) / trigonal-planar (sp2, 120°) / linear (sp, 180°) geometry, guaranteed. You only need to assign each lobe/atom a distinct index.",
      "hybridIndex": "0-based position of this lobe/atom within its \"hybridSet\" (0,1,2,3 for sp3; 0,1,2 for sp2; 0,1 for sp) -- give every lobe and every bonded atom in the set a different index, in the same order, so lobe 0 and its bonded atom both use index 0, etc.",
      "hybridCenter": "id of the central atom's \"sphere\" object -- ONLY on a bonded substituent atom's \"sphere\" (e.g. a hydrogen) that has \"hybridSet\"/\"hybridIndex\" set: its final position is computed automatically as this center's position plus the canonical direction for its hybridIndex.",
      "physics": {
        "shape": "e.g. 'dumbbell-shaped with two lobes along the z-axis, a nodal plane through the nucleus'",
        "phase": "e.g. 'the two lobes have opposite sign (+ and -) because the wavefunction changes sign at the node'",
        "quantumNumbers": "e.g. 'n=2, l=1, ml=0 (a 2pz orbital)'",
        "spin": "e.g. 'spin-up, ms = +1/2' -- ONLY for an \"electron\" object",
        "why": "1-2 sentence physical reason this exact object has this shape/phase/energy -- the real quantum-mechanical or bonding reason, not a repeat of \"detail\""
      },
      "miniDiagram": {
        "kind": "orbitalPhase | spinPair | energyZoom | wavefunction | overlap",
        "label": "short caption shown under the mini-diagram",
        "lobeAxis": "horizontal | vertical",
        "signs": ["+", "-"],
        "spins": ["up", "down"],
        "levels": [ {"label": "2p", "y": 1, "occupied": 2}, {"label": "2s", "y": 0, "occupied": 1} ],
        "nodes": 1,
        "overlapLabel": "e.g. sigma bond"
      },
      "phaseColors": ["#3b82f6", "#ef4444"],
      "pulse": false,
      "spin": false,
      "orbitSpeed": 1
    }
  ],
  "steps": [
    {
      "caption": "one clear sentence explaining this step",
      "focus": ["object_id_1", "object_id_2"],
      "moves": [ {"id": "electron_object_id", "to": [x, y, z], "level": "energyLevel_object_id -- include ONLY on the exact step where this electron's energy level changes (e.g. promotion), even if its 3D \"to\" is given in the same move", "orbitalIndex": "0 -- the specific box within the NEW level this electron now occupies -- include whenever \"level\" is included", "spinDir": "\"up\"|\"down\" -- include whenever \"level\" is included, normally unchanged from before the move"} ],
      "theory": [
        {
          "text": "Layer-2 short theory sentence: WHY this step happens (the underlying rule/principle), only for the steps where real theory applies",
          "diagram": {
            "kind": "orbitalPhase | spinPair | energyZoom | wavefunction | overlap",
            "label": "short caption shown under the mini-diagram",
            "lobeAxis": "horizontal | vertical",
            "signs": ["+", "-"],
            "spins": ["up", "down"],
            "levels": [ {"label": "2p", "y": 1, "occupied": 3}, {"label": "2s", "y": 0, "occupied": 1} ],
            "nodes": 1,
            "overlapLabel": "e.g. sigma bond"
          }
        },
        {
          "text": "Optional deeper layer: the reasoning/mechanism behind that rule",
          "diagram": null
        },
        {
          "text": "Optional even-deeper layer: the fundamental physical/chemical reason",
          "diagram": null
        }
      ]
    }
  ]
}

Rules:
- Only include fields that are relevant to that object's "type" (every object still needs id, type, color).
- position/direction/toPosition are [x,y,z] arrays with each number between -4 and 4.
- Use "bond" to connect two objects (set "to" to the other object's id) or an object to a bare point (set "toPosition").
- Use "energyLevel" for horizontal energy-level lines (use "y" for height, "width" for length, "label" for the level name e.g. "2p").
- Use "electronOrbit" for a ring an electron travels around (use "radius" and "orbitSpeed").
- Use "orbitalLobe" for atomic/hybrid orbital lobes (use "direction" for which way the lobe points).
- Use "electron" for an INDIVIDUAL electron the student should be able to visually track moving from one place
  to another across steps (a small glowing dot). Give every electron that will move its own unique "electron"
  object with a starting "position" -- do NOT just describe electron movement in the caption text without an
  actual "electron" object backing it, since the caption alone cannot be animated.
- 6 to 22 objects total (topics involving electron movement need more objects than a purely static shape, since
  every electron that moves needs its own object). 4 to 9 steps, ordered so the explanation builds up logically.
- COMPLETENESS BEATS DECORATION -- if you are ever tight on output length, priority order is: (1) every real
  step of the mechanism and every "moves"/"level"/"orbitalIndex" needed to animate it correctly, always
  complete, NEVER shortened, merged or cut off early -- this is the one thing that must never be sacrificed;
  (2) "physics"/"miniDiagram" on objects and "theory" (with its optional "diagram") on steps are valuable but
  OPTIONAL extras -- add them generously where they fit, but if length is a concern, add them only on the 4-6
  objects and 2-4 steps that matter most, rather than risk leaving the actual step sequence incomplete. A
  diagram with a fully complete process and a few undecorated steps is correct; a diagram that stops partway
  through the real mechanism is never acceptable, no matter how richly decorated the steps it did reach are.
- IMPORTANT -- steps drive a step-by-step FORMATION ANIMATION, not just a highlight: the FIRST time an
  object's id appears in any step's "focus" array is treated as the moment it is born/forms on screen (it
  is invisible before that step and grows into view on that step). So order "focus" lists so that objects
  which exist from the very start appear in step 1's "focus", and objects that only form partway through
  (a new bond, a newly combined orbital, a product molecule, an electron that is promoted or transferred)
  first appear in the LATER step where they actually form -- never earlier. Every object id should appear in
  at least one step's "focus" array.
- IMPORTANT -- "moves" is what actually animates an "electron" object traveling from one position to another
  DURING a step (e.g. from its original 2s orbital position to the 2pz position during a promotion step, or
  from an atom's lone orbital into the shared overlap region between two atoms during a bonding step). Add a
  "moves" entry for an electron on EVERY step where it visibly relocates; leave "moves" out of a step entirely
  if nothing moves during it. An electron's very first appearance (in "focus") should already place it at its
  starting "position" -- "moves" is only for relocating it in a LATER step.
- FOR ANY TOPIC ABOUT HOW ATOMS BOND OR ORBITALS FORM (hybridization, covalent/ionic/coordinate bonding,
  molecule formation such as CO2, H2O, NH3, etc.) -- always tell the FULL real story as separate steps, not a
  shortcut summary. Include, in order, whichever of these genuinely apply to the specific topic asked:
    1. Ground state electron configuration of each atom involved (show its outer-shell electrons as
       individual "electron" objects positioned in their actual orbitals/energy levels).
    2. Promotion/excitation, if the real chemistry requires it (an electron moves -- via "moves" -- from a
       lower orbital to an empty higher one to unpair electrons for bonding).
    3. Hybridization/mixing, if applicable (the original orbitals blend into new identical hybrid orbitals --
       e.g. sp, sp2, sp3).
    4. Spatial/geometric arrangement of the resulting orbitals (correct bond angle for that geometry, e.g.
       109.5 degrees for sp3, 120 for sp2, 180 for sp, or the real molecular geometry such as CO2's linear
       180 degrees) -- ALWAYS add a "label" object (or a bond's "label") stating the exact angle in this
       step (e.g. "109.5°"), positioned near the vertex, exactly like a textbook tetrahedral-geometry
       diagram labels its angle -- never leave the correct angle unstated. Whenever hybridization is involved,
       ALSO state (in this step's "caption" or "theory", and in the "detail"/"physics.why" of the pre-hybrid
       orbital objects) the geometric problem hybridization actually solves: the unhybridized orbitals from
       step 2 are NOT equivalent or symmetrically usable as-is (e.g. an s orbital is spherical while the
       p orbitals are dumbbell-shaped and point along mutually perpendicular axes, i.e. 90° apart) -- only
       AFTER mixing into new, identical hybrid orbitals do they point at the real bond angle (109.5° for sp3,
       120° for sp2, 180° for sp). Never jump straight from "orbitals promoted" to "109.5° apart" without
       naming that 90°-to-109.5° contrast; it is the actual reason hybridization is needed, not a decorative
       extra.
    5. Orbital overlap / electron sharing / bond formation -- show the actual bonding electrons (as "electron"
       objects) moving into the shared/overlap region between the two atoms to form each sigma bond, and, for
       any double/triple bond (e.g. CO2's two C=O double bonds, O2, N2, ethene), a SEPARATE step for the
       sideways pi-bond overlap in addition to the sigma bond step -- never merge a double/triple bond's sigma
       and pi bond formation into one step.
    6. The final, complete bonded structure/molecule, with every atom, bond and lone pair present, and every
       hydrogen/substituent atom actually present as its own "sphere" object (e.g. methane's diagram must
       show all four hydrogens, not just the central atom and orbitals) -- the final step is the payoff the
       whole sequence has been building to, so it must be visually complete, not a partial skeleton.
  Never compress this into fewer steps than the real mechanism actually has, and never claim a step happened
  (in the caption) without an actual object/move making it visible on screen.
  GEOMETRY: for step 4/5 above, tag every hybrid orbitalLobe and every bonded substituent atom with
  "hybridSet"/"hybridIndex" (and "hybridCenter" on the atom) as described in the schema, so the renderer
  places them at the exact correct 109.5°/120°/180° geometry -- never leave this to a hand-computed
  "direction"/"position" for a hybrid set, since that is exactly what produces a lopsided or collapsed-looking
  diagram (e.g. one lobe drawn as a single stick with no tetrahedral fan).
- ORBITAL-BOX DIAGRAM (a separate, ALWAYS-VISIBLE 2D diagram synced beside the 3D view -- required for ANY topic
  involving electron configuration, orbitals, promotion, excitation, or bonding; leave out ALL "energyLevel"
  objects entirely for topics that are not about electrons/orbitals, e.g. projectile motion, waves, vectors).
  This MUST be real chemistry orbital-box notation -- exactly like a textbook electron-configuration diagram,
  e.g. for carbon before promotion: "2s [↑↓]   2p [↑][↑][ ]", and after promotion: "2s [↑]   2p [↑][↑][↑]" --
  NOT a generic bar chart:
    - Create one "energyLevel" object per distinct sub-shell/orbital ROW (e.g. "2s", "2p", "sp3"), each with a
      "y" reflecting its real relative energy (higher energy = higher "y"), a clear "label" (e.g. "2p"), and
      "orbitals" = how many individual degenerate boxes that row draws (1 for an s row, 3 for a p row, 4 for
      sp3, 3 for sp2, 2 for sp).
    - Every "electron" object must carry, from the very start, the "level" it begins in, the "orbitalIndex"
      (which specific box, 0-based) it sits in within that level, and its "spinDir" ("up" or "down").
    - Fill boxes the real way (Hund's rule): give every degenerate box its own single "up" electron
      (orbitalIndex 0, 1, 2, ... each with spinDir "up") before any box gets a second "down" electron. Never
      put more than 2 electrons in the same (level, orbitalIndex) pair, and never put 2 electrons in the same
      box with the same spinDir.
    - Whenever a step promotes/excites/transfers/shares an electron into a different level or hybrid orbital,
      that step's matching "moves" entry MUST include the new "level", "orbitalIndex" AND "spinDir" (in
      addition to "to" for the 3D position) so the 2D panel and the 3D scene change simultaneously and the
      electron is visibly seen sliding from its old box into a specific new, correct, empty (or correctly
      paired) box -- never leave an electron's box ambiguous, overlapping another electron, or inconsistent
      between steps, since the panel reads these fields literally and any omission or contradiction shows as a
      visible error to the student.
- THEORY LAYERS (the "go deeper" theory panel): for every step where genuine underlying theory exists (why an
  electron is promoted, why hybridisation happens, why a bond angle is what it is, why a bond forms), add a
  "theory" array of 1 to 3 objects (NOT plain strings -- each is {"text": ..., "diagram": ...}) ordered from
  "the rule/principle" to "the deeper reasoning" to "the most fundamental reason":
    - "text" is always required: a correct, exam-appropriate sentence of real theory, never a restatement of
      the caption.
    - "diagram" is OPTIONAL (use null or omit when a visual would not add anything) but STRONGLY ENCOURAGED on
      whichever 1-2 layers most benefit from being seen rather than just read (e.g. showing the actual phase
      of the two lobes when explaining why a node exists, or showing the two energy levels zoomed in when
      explaining a promotion). See MINI-DIAGRAMS below for the exact shape.
  Omit "theory" entirely (do not invent filler) on purely cosmetic or connective steps that have no real theory
  of their own (e.g. "the camera rotates to show the full molecule").
- DEEP OBJECT PHYSICS (the click/focus popup on any orbital or electron): for every "orbitalLobe", "electron",
  and "sphere"-as-orbital object that matters to the topic, include a "physics" object with whichever of
  "shape", "phase", "quantumNumbers", "spin" (electrons only), and "why" are genuinely applicable -- real,
  correct, exam-appropriate physics (the actual orbital shape, the real sign/phase of each lobe from the
  wavefunction, the real quantum numbers, the real reason it looks/behaves that way) -- never invented or
  vague filler. Skip "physics" on purely decorative/anchor objects that carry no real physics of their own.
  Also give that same object a "miniDiagram" (see MINI-DIAGRAMS below) whenever a small zoomed-in visual would
  make the physics clearer than text alone (very strongly encouraged for any orbital showing phase, and for
  any electron showing spin).
- ORBITAL PHASE COLOR (only for "orbitalLobe" objects where sign/phase genuinely matters, e.g. a p or hybrid
  orbital with two oppositely-signed lobes): set "phaseColors" to a two-color array [positiveLobeColor,
  negativeLobeColor] so the two lobes render in visibly different colors in the 3D scene itself, matching
  whatever sign is stated in that object's "physics.phase". Omit for orbitals with no meaningful phase split
  (e.g. a plain s orbital, or a lobe you are not distinguishing by sign).
- MINI-DIAGRAMS (used by both a step's "theory[].diagram" and an object's "miniDiagram" -- always the same
  shape, a small deterministic 2D schematic the UI renders, NOT a natural-language description):
  {"kind": one of "orbitalPhase" | "spinPair" | "energyZoom" | "wavefunction" | "overlap", "label": short
  caption, plus ONLY the fields that apply to that kind}
    - "orbitalPhase": two lobes with their real sign, e.g. {"kind":"orbitalPhase","lobeAxis":"vertical",
      "signs":["+","-"],"label":"2pz orbital: opposite phase above/below the node"}.
    - "spinPair": one or two spin arrows for an orbital's occupancy, e.g. {"kind":"spinPair",
      "spins":["up"],"label":"one unpaired spin-up electron"} (use ["up","down"] for a filled/paired orbital).
    - "energyZoom": a zoomed-in view of exactly the 1-2 energy levels relevant to this specific theory point,
      e.g. {"kind":"energyZoom","levels":[{"label":"2p","y":1,"occupied":3},{"label":"2s","y":0,"occupied":1}],
      "label":"one 2s electron promotes into the empty 2p orbital"} -- "occupied" is how many electrons to draw
      on that level at this exact point in the explanation, not necessarily the final count.
    - "wavefunction": a simple wave cross-section showing sign change across node(s), e.g.
      {"kind":"wavefunction","nodes":1,"label":"the wavefunction changes sign across one nodal plane"}.
    - "overlap": two overlapping lobes representing bond formation, e.g. {"kind":"overlap",
      "overlapLabel":"sigma bond","label":"the two lobes overlap head-on to form a sigma bond"}.
  Never invent a "kind" outside this list, and never include fields from a different kind than the one chosen.
- "legend" should list every distinct color used and what it represents -- omit/empty array if nothing to key.
- "keyPoints", "equation", "conditions", "related" should each be included whenever genuinely relevant to
  the topic (this is what makes the diagram exam-ready, not just a picture) -- omit/empty when not
  applicable (e.g. no "equation" for a non-chemistry topic). Do not invent a fake equation/condition.
- Keep every number a plain JSON number, never a string.
- Nothing outside the JSON object.
"""


def _diagram_ai_call(prompt_text, max_output_tokens=8192):
    """
    One raw Gemini call for the Diagram Lab. Tries to force JSON-only
    output via response_mime_type when the installed google-genai
    version supports it, and always asks for a generous output-token
    budget -- the Diagram Lab schema (physics blocks, mini-diagrams,
    orbital boxes, theory layers) produces long JSON for a full
    process, and a too-small default budget would silently truncate
    the response mid-way through the step sequence, cutting the
    process off partway. Falls back one level at a time (dropping
    max_output_tokens, then response_mime_type, then config entirely)
    if the installed SDK version doesn't support a kwarg, so this can
    never crash the feature just because of an SDK version difference.
    """
    try:
        from google.genai import types as _genai_types
        try:
            config = _genai_types.GenerateContentConfig(
                response_mime_type="application/json", max_output_tokens=max_output_tokens
            )
            response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt_text, config=config)
            return getattr(response, "text", None) or ""
        except Exception:
            pass
        try:
            config = _genai_types.GenerateContentConfig(response_mime_type="application/json")
            response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt_text, config=config)
            return getattr(response, "text", None) or ""
        except Exception:
            pass
    except Exception:
        pass
    try:
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt_text)
        return getattr(response, "text", None) or ""
    except Exception as error:
        print("Diagram AI error:", error)
        return ""


def _parse_diagram_json(raw):
    """Best-effort JSON extraction: strips ``` fences the model sometimes
    adds despite instructions, then falls back to grabbing the outermost
    {...} span. Returns None (never raises) on anything unparsable."""
    if not raw:
        return None
    text = raw.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n?", "", text)
        text = re.sub(r"```\s*$", "", text).strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(text[start:end + 1])
        except Exception:
            return None
    return None


_GENERIC_ORBITAL_DETAILS = {
    "s": "An s subshell: spherical, one orbital, holds up to 2 electrons.",
    "p": "A p subshell: dumbbell-shaped, three orbitals (px, py, pz) at 90° to each other, holds up to 6 electrons.",
    "d": "A d subshell: five orbitals, more complex cloverleaf/donut shapes, holds up to 10 electrons.",
    "sp": "An sp hybrid orbital: 1 s + 1 p orbital mixed into 2 identical orbitals, 180° apart (linear).",
    "sp2": "An sp2 hybrid orbital: 1 s + 2 p orbitals mixed into 3 identical orbitals, 120° apart (trigonal planar).",
    "sp3": "An sp3 hybrid orbital: 1 s + 3 p orbitals mixed into 4 identical orbitals, 109.5° apart (tetrahedral).",
    "sp3d": "An sp3d hybrid orbital: 1 s + 3 p + 1 d orbital mixed into 5 identical orbitals (trigonal bipyramidal).",
    "sp3d2": "An sp3d2 hybrid orbital: 1 s + 3 p + 2 d orbitals mixed into 6 identical orbitals (octahedral).",
}


def _default_energy_level_detail(label):
    """Deterministic fallback description for an energyLevel row that the
    model left without a "detail" -- keyed off its label (e.g. "2p", "sp3")
    so the click/focus popup is never empty, regardless of what the AI
    generated. This is a safety net UNDER the prompt requirement added
    above, not a replacement for it -- the model should still write a
    topic-specific detail; this only fires if it didn't."""
    key = re.sub(r"^\d+", "", (label or "").strip().lower())
    if key in _GENERIC_ORBITAL_DETAILS:
        return _GENERIC_ORBITAL_DETAILS[key] + f" (shown here as the {label} level.)"
    return f"The {label or 'shown'} energy level/orbital row in this diagram."


def _default_electron_detail(obj):
    level = obj.get("level")
    spin = obj.get("spinDir") or (obj.get("physics") or {}).get("spin")
    bits = ["An electron"]
    if level:
        bits.append(f"in the {level} orbital")
    if spin:
        bits.append(f"({spin} spin)" if spin in ("up", "down") else f"({spin})")
    return " ".join(bits) + "."


def _default_orbital_lobe_detail(obj):
    physics = obj.get("physics") or {}
    shape = physics.get("shape")
    if shape:
        return f"An orbital lobe: {shape}."
    return "One lobe of an atomic or hybrid orbital."


def _backfill_missing_diagram_details(data):
    """Guarantees no object ever shows the "no extra detail was generated"
    fallback: fills any missing "detail" on energyLevel/electron/orbitalLobe
    objects with a correct generic description. Runs after the AI call, so
    it fixes the popup regardless of whether the model followed the prompt's
    "detail is required" instruction on a given run."""
    for obj in (data.get("objects") or []):
        if not isinstance(obj, dict) or obj.get("detail"):
            continue
        obj_type = obj.get("type")
        if obj_type == "energyLevel":
            obj["detail"] = _default_energy_level_detail(obj.get("label"))
        elif obj_type == "electron":
            obj["detail"] = _default_electron_detail(obj)
        elif obj_type == "orbitalLobe":
            obj["detail"] = _default_orbital_lobe_detail(obj)
    return data


_ORBITAL_COUNT_BY_LABEL = {
    "s": 1, "p": 3, "d": 5, "f": 7,
    "sp": 2, "sp2": 3, "sp3": 4, "sp3d": 5, "sp3d2": 6,
}
_HYBRID_TOPIC_RE = re.compile(r"\bhybrid|\bsp\d\b|\bsp2\b|\bsp3\b|\bhybridi[sz]ation", re.IGNORECASE)
_PRE_HYBRID_LABELS = {"1s", "2s", "2p", "3s", "3p"}


def _expected_orbitals_for_label(label):
    key = re.sub(r"^\d+", "", (label or "").strip().lower())
    return _ORBITAL_COUNT_BY_LABEL.get(key)


def _normalize_energy_level_orbitals(data):
    """Deterministically OVERWRITES each energyLevel's "orbitals" box count
    from its label (2p -> 3 boxes, sp3 -> 4 boxes, etc.), regardless of what
    the model wrote. This is what actually fixes wrong box counts (e.g. an
    "sp3" row rendered as a single box) -- it doesn't depend on the model
    getting the number right, it's corrected in code every time."""
    for obj in (data.get("objects") or []):
        if isinstance(obj, dict) and obj.get("type") == "energyLevel":
            expected = _expected_orbitals_for_label(obj.get("label"))
            if expected:
                obj["orbitals"] = expected
    return data


def _electron_final_level(obj_id, data):
    """Which energyLevel id this electron ends up in after the last step
    that moves it (falls back to its starting "level")."""
    steps = data.get("steps") or []
    for step in reversed(steps):
        for move in (step.get("moves") or []):
            if isinstance(move, dict) and move.get("id") == obj_id and move.get("level"):
                return move["level"]
    obj = next((o for o in (data.get("objects") or []) if isinstance(o, dict) and o.get("id") == obj_id), None)
    return obj.get("level") if obj else None


_HYBRID_TYPE_RE = re.compile(r"\bsp3d2\b|\bsp3d\b|\bsp3\b|\bsp2\b|\bsp\b", re.IGNORECASE)


def _requested_hybrid_type(topic):
    """Pulls the specific hybridization type (sp/sp2/sp3/sp3d/sp3d2) the
    user actually asked for out of the topic string, e.g. "sp3 hybrid
    orbitals in methane" -> "sp3". Longest match wins so "sp3" doesn't get
    mis-matched as bare "sp"."""
    m = _HYBRID_TYPE_RE.search(topic or "")
    return m.group(0).lower() if m else None


def _diagram_missing_hybrid_stages(data, topic):
    """For a genuinely hybridization-related topic, checks the generated
    scene actually has the full, quantitatively correct story -- not just
    the right labels present -- AND that it's actually about the SPECIFIC
    hybridization type requested (e.g. catches the model answering "sp2
    hybridization of carbon" when the user asked for sp3/methane)."""
    if not _HYBRID_TOPIC_RE.search(topic or ""):
        return False

    objects = data.get("objects") or []
    energy_levels = [o for o in objects if isinstance(o, dict) and o.get("type") == "energyLevel"]
    labels = {(o.get("label") or "").strip().lower() for o in energy_levels}

    requested = _requested_hybrid_type(topic)
    if requested and requested not in labels:
        return True

    has_pre_hybrid = bool(labels & _PRE_HYBRID_LABELS)
    hybrid_label_obj = next((o for o in energy_levels if (o.get("label") or "").lower().startswith("sp")), None)
    steps = data.get("steps") or []

    if not (has_pre_hybrid and hybrid_label_obj and len(steps) >= 4):
        return True

    expected_orbitals = _expected_orbitals_for_label(hybrid_label_obj.get("label")) or 1
    electrons = [o for o in objects if isinstance(o, dict) and o.get("type") == "electron"]
    hybrid_id = hybrid_label_obj.get("id")
    electrons_in_hybrid = sum(
        1 for e in electrons if _electron_final_level(e.get("id"), data) == hybrid_id
    )
    spheres = [o for o in objects if isinstance(o, dict) and o.get("type") == "sphere"]

    # A complete bonding diagram needs one electron per hybrid box, at least
    # a central atom plus its bonded atoms as separate spheres, and enough
    # total objects that it can't be the sparse "one lobe + one atom" scene.
    return not (
        electrons_in_hybrid >= expected_orbitals
        and len(spheres) >= 2
        and len(objects) >= 6
    )


_CANONICAL_HYBRID_DIRECTIONS = {
    "sp": [(1, 0, 0), (-1, 0, 0)],
    "sp2": [(1, 0, 0), (-0.5, 0.8660254, 0), (-0.5, -0.8660254, 0)],
    "sp3": [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)],
    # Trigonal bipyramidal: 3 equatorial directions 120 degrees apart in the
    # xy-plane, plus 2 axial directions along +/-z, each 90 degrees from
    # every equatorial direction and 180 degrees from each other.
    "sp3d": [(1, 0, 0), (-0.5, 0.8660254, 0), (-0.5, -0.8660254, 0), (0, 0, 1), (0, 0, -1)],
    "sp3d2": [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)],
}


def _normalize_vec3(v):
    x, y, z = v
    n = (x * x + y * y + z * z) ** 0.5
    return (x / n, y / n, z / n) if n else (0.0, 0.0, 0.0)


def _apply_canonical_hybrid_geometry(data, bond_length=1.6):
    """Overrides "direction" (for orbitalLobe) and "position" (for a bonded
    substituent atom's sphere) from "hybridSet"/"hybridIndex"/"hybridCenter"
    with the exact textbook-correct tetrahedral/trigonal/linear vectors --
    regardless of whatever direction/position the model computed. This is
    what actually guarantees the 3D scene fans out like a real sp3/sp2/sp
    diagram instead of a lopsided single stick, since 3D vector geometry is
    exactly the kind of thing a language model gets wrong even when every
    object it's asked for is present."""
    objects = data.get("objects") or []
    by_id = {o.get("id"): o for o in objects if isinstance(o, dict) and o.get("id")}
    for obj in objects:
        if not isinstance(obj, dict):
            continue
        hybrid_set = obj.get("hybridSet")
        dirs = _CANONICAL_HYBRID_DIRECTIONS.get(hybrid_set)
        idx = obj.get("hybridIndex")
        if not dirs or not isinstance(idx, int) or idx < 0 or idx >= len(dirs):
            continue
        vec = _normalize_vec3(dirs[idx])
        if obj.get("type") == "orbitalLobe":
            obj["direction"] = list(vec)
        elif obj.get("type") == "sphere":
            center = by_id.get(obj.get("hybridCenter"))
            center_pos = center.get("position") if isinstance(center, dict) else None
            if isinstance(center_pos, list) and len(center_pos) == 3:
                obj["position"] = [center_pos[i] + vec[i] * bond_length for i in range(3)]
    return data



def _canonical_sp3_diagram(topic):
    """Deterministic, renderer-friendly sp3 demonstration.

    Gemini remains the general diagram designer for every other topic.  For
    sp3 hybridisation we deliberately use a fixed scientific scene so the
    orbital count, electron promotion, tetrahedral geometry, bonding sequence,
    and final methane structure can never be lost to a sparse/truncated model
    response.  This is the diagram the student is actually meant to study.
    """
    def electron(eid, pos, level, oi, spin, color="#fff6b0", detail=""):
        return {
            "id": eid, "type": "electron", "position": list(pos), "radius": 0.12,
            "color": color, "pulse": True, "label": "", "level": level,
            "orbitalIndex": oi, "spinDir": spin,
            "detail": detail or f"An electron in the {level} orbital with {spin} spin.",
            "physics": {"spin": spin, "why": "Electrons occupy orbitals according to the Aufbau principle, Pauli exclusion principle and Hund's rule."},
            "miniDiagram": {"kind": "spinPair", "spins": [spin], "label": f"{spin}-spin electron"}
        }

    dirs = [
        (1/3**0.5, 1/3**0.5, 1/3**0.5),
        (1/3**0.5, -1/3**0.5, -1/3**0.5),
        (-1/3**0.5, 1/3**0.5, -1/3**0.5),
        (-1/3**0.5, -1/3**0.5, 1/3**0.5),
    ]
    objects = [
        {"id":"carbon","type":"sphere","position":[0,0,0],"radius":0.34,"color":"#7dd3fc","label":"C","detail":"Carbon is the central atom. Its valence shell is 2s²2p² before excitation.","physics":{"shape":"Atomic carbon nucleus/centre represented schematically","quantumNumbers":"Valence electrons occupy n=2 orbitals."}},
        {"id":"level_2s","type":"energyLevel","position":[0,0,0],"y":0.0,"width":3.2,"color":"#22d3ee","label":"2s","orbitals":1,"detail":"The 2s subshell contains one orbital and initially holds a paired (spin-up / spin-down) pair of carbon's valence electrons."},
        {"id":"level_2p","type":"energyLevel","position":[0,1.45,0],"y":1.45,"width":3.2,"color":"#22d3ee","label":"2p","orbitals":3,"detail":"The 2p subshell contains three degenerate orbitals: 2px, 2py and 2pz."},
        {"id":"level_sp3","type":"energyLevel","position":[0,0.72,0],"y":0.72,"width":3.2,"color":"#a855f7","label":"sp3","orbitals":4,"detail":"Four equivalent sp3 hybrid orbitals form from one s and three p orbitals; they lie between the original 2s and 2p energies in this model."},
        {"id":"orb_2s","type":"orbitalLobe","position":[0,0,0],"direction":[0,1,0],"radius":0.72,"length":1.0,"color":"#38bdf8","orbitalKind":"s","label":"2s","detail":"The 2s atomic orbital is spherical and has no directional preference.","physics":{"shape":"Spherical","quantumNumbers":"n=2, l=0, m=0","why":"An s orbital has l=0, giving spherical symmetry."},"miniDiagram":{"kind":"orbitalPhase","lobeAxis":"vertical","signs":["+","+"],"label":"2s: spherical, no nodal plane"}},
        {"id":"orb_2px","type":"orbitalLobe","position":[0,0,0],"direction":[1,0,0],"length":1.45,"radius":0.43,"color":"#60a5fa","phaseColors":["#60a5fa","#f472b6"],"orbitalKind":"p","label":"2px","detail":"The 2px orbital is a p orbital with two opposite-phase lobes along the x-axis.","physics":{"shape":"Dumbbell-shaped","phase":"Opposite signs in the two lobes","quantumNumbers":"n=2, l=1, m=-1,0,+1 collectively for the p subshell","why":"A p orbital has one nodal plane through the nucleus."},"miniDiagram":{"kind":"orbitalPhase","lobeAxis":"horizontal","signs":["+","-"],"label":"2px: opposite phase across the nodal plane"}},
        {"id":"orb_2py","type":"orbitalLobe","position":[0,0,0],"direction":[0,1,0],"length":1.45,"radius":0.43,"color":"#60a5fa","phaseColors":["#60a5fa","#f472b6"],"orbitalKind":"p","label":"2py","detail":"The 2py orbital is perpendicular to 2px and has two opposite-phase lobes.","physics":{"shape":"Dumbbell-shaped","phase":"Opposite signs in the two lobes","why":"The three p orbitals are mutually perpendicular and degenerate in an isolated atom."},"miniDiagram":{"kind":"orbitalPhase","lobeAxis":"vertical","signs":["+","-"],"label":"2py: opposite phase across the nodal plane"}},
        {"id":"orb_2pz","type":"orbitalLobe","position":[0,0,0],"direction":[0,0,1],"length":1.45,"radius":0.43,"color":"#60a5fa","phaseColors":["#60a5fa","#f472b6"],"orbitalKind":"p","label":"2pz","detail":"The 2pz orbital is the third p orbital and is perpendicular to both 2px and 2py.","physics":{"shape":"Dumbbell-shaped","phase":"Opposite signs in the two lobes","why":"The p subshell has three mutually perpendicular orbitals."},"miniDiagram":{"kind":"orbitalPhase","lobeAxis":"vertical","signs":["+","-"],"label":"2pz: opposite phase across the nodal plane"}},
        electron("e1_2s",[-0.28,0.0,0.0],"level_2s",0,"up",detail="One of carbon's paired 2s electrons in the ground state."),
        electron("e2_2s",[0.28,0.0,0.0],"level_2s",0,"down",detail="The second paired 2s electron; this electron is the one promoted during excitation."),
        electron("e3_2px",[0.72,0.0,0.0],"level_2p",0,"up",detail="An unpaired electron in the 2px orbital."),
        electron("e4_2py",[0.0,0.72,0.0],"level_2p",1,"up",detail="An unpaired electron in the 2py orbital."),
    ]

    # Hybrid orbitals and the four H atoms are created later in the sequence.
    for i,d in enumerate(dirs):
        objects.append({
            "id":f"hyb_{i}","type":"orbitalLobe","position":[0,0,0],"direction":list(d),
            "length":1.72,"radius":0.48,"color":"#a855f7","phaseColors":["#a855f7","#f0abfc"],
            "hybridSet":"sp3","hybridIndex":i,"orbitalKind":"hybrid","label":f"sp3 ({i+1})",
            "detail":"One of four equivalent sp3 hybrid orbitals produced by mixing one 2s and three 2p orbitals. The four directions are tetrahedral and separated by about 109.5°.",
            "physics":{"shape":"Asymmetric hybrid orbital with a large lobe and smaller back lobe","phase":"The two lobes have opposite phase","why":"One s and three p orbitals combine to form four equivalent directional hybrids."},
            "miniDiagram":{"kind":"orbitalPhase","lobeAxis":"horizontal","signs":["+","-"],"label":"sp3 hybrid: large and small lobes of opposite phase"}
        })
        hpos=[d[j]*1.6 for j in range(3)]
        objects.append({
            "id":f"H_{i}","type":"sphere","position":hpos,"radius":0.22,"color":"#e5e7eb","hybridSet":"sp3","hybridIndex":i,"hybridCenter":"carbon","label":"H","detail":"A hydrogen atom bonded to carbon through a shared pair of electrons in a C-H sigma bond.","physics":{"shape":"Hydrogen atom represented as a sphere","quantumNumbers":"Its bonding electron occupies the 1s orbital.","why":"Hydrogen contributes one electron to the shared C-H bonding pair."}
        })
        objects.append(electron(f"H_e{i}",hpos,"level_H1s",0,"up",color="#fef3c7",detail="Hydrogen's 1s electron, initially localized on the hydrogen atom."))

    objects.append({"id":"level_H1s","type":"energyLevel","position":[0,-0.8,0],"y":-0.8,"width":3.2,"color":"#f59e0b","label":"1s (H)","orbitals":1,"detail":"Each hydrogen atom begins with one electron in its 1s orbital before forming a C-H bond."})

    # Bonds are present as objects but only appear in the final formation step.
    for i in range(4):
        objects.append({"id":f"bond_{i}","type":"bond","position":[0,0,0],"to":f"H_{i}","color":"#22d3ee","width":0.075,"label":"σ C-H"})

    # 3D target positions for electrons: close to each hybrid lobe and then
    # at the actual C-H overlap region.
    steps=[]
    def focus(ids): return {"focus":ids}

    steps.append({
        "caption":"Carbon starts in its ground state: 2s² 2p², with two paired 2s electrons and two unpaired 2p electrons.",
        "focus":["carbon","orb_2s","orb_2px","orb_2py","orb_2pz","level_2s","level_2p","e1_2s","e2_2s","e3_2px","e4_2py"],
        "theory":[
            {"text":"Carbon has four valence electrons in the n=2 shell: 2s²2p².","diagram":{"kind":"spinPair","spins":["up","down"],"label":"2s contains a paired electron pair"}},
            {"text":"Hund's rule places the two 2p electrons singly in separate degenerate p orbitals before pairing occurs.","diagram":{"kind":"orbitalPhase","lobeAxis":"horizontal","signs":["+","-"],"label":"A p orbital has two opposite-phase lobes"}}
        ]
    })
    steps.append({
        "caption":"Excitation promotes one 2s electron into the empty 2pz orbital, giving four singly occupied orbitals.",
        "focus":["carbon","orb_2s","orb_2px","orb_2py","orb_2pz","level_2s","level_2p","e1_2s","e2_2s","e3_2px","e4_2py"],
        "moves":[{"id":"e2_2s","to":[0,0,1.0],"level":"level_2p","orbitalIndex":2,"spinDir":"up"}],
        "theory":[
            {"text":"Promotion is shown as an excitation from the occupied 2s orbital to the vacant 2p orbital so that four orbitals contain one electron each in the bonding model.","diagram":{"kind":"energyZoom","levels":[{"label":"2p","y":1,"occupied":3},{"label":"2s","y":0,"occupied":1}],"label":"One 2s electron is promoted to 2p"}},
            {"text":"The promotion costs energy, but the resulting four singly occupied orbitals allow carbon to describe four equivalent C-H bonds in the hybridization model.","diagram":{"kind":"spinPair","spins":["up"],"label":"Each relevant orbital is singly occupied"}}
        ]
    })
    steps.append({
        "caption":"The 2s and three 2p orbitals now mix to form four equivalent sp3 hybrid orbitals.",
        "focus":["carbon","hyb_0","hyb_1","hyb_2","hyb_3","level_sp3","e1_2s","e2_2s","e3_2px","e4_2py"],
        "moves":[
            {"id":"e1_2s","to":[0.7,0.7,0.7],"level":"level_sp3","orbitalIndex":0,"spinDir":"up"},
            {"id":"e2_2s","to":[0.7,-0.7,-0.7],"level":"level_sp3","orbitalIndex":1,"spinDir":"up"},
            {"id":"e3_2px","to":[-0.7,0.7,-0.7],"level":"level_sp3","orbitalIndex":2,"spinDir":"up"},
            {"id":"e4_2py","to":[-0.7,-0.7,0.7],"level":"level_sp3","orbitalIndex":3,"spinDir":"up"}
        ],
        "theory":[
            {"text":"Hybridization is a model in which one s orbital and three p orbitals combine to give four equivalent sp3 hybrid orbitals.","diagram":{"kind":"overlap","overlapLabel":"orbital mixing","label":"1 s + 3 p → 4 sp3 hybrids"}},
            {"text":"The four hybrid orbitals point in directions that maximize separation, giving tetrahedral orbital geometry.","diagram":{"kind":"orbitalPhase","lobeAxis":"horizontal","signs":["+","-"],"label":"Each hybrid has a large and smaller opposite-phase lobe"}}
        ]
    })
    steps.append({
        "caption":"The four sp3 orbitals arrange tetrahedrally around carbon, with bond directions separated by approximately 109.5°.",
        "focus":["carbon","hyb_0","hyb_1","hyb_2","hyb_3","level_sp3"],
        "theory":[
            {"text":"Four equivalent sp3 orbitals have tetrahedral geometry with an ideal angle of 109.5° between any two bond directions.","diagram":{"kind":"orbitalPhase","lobeAxis":"horizontal","signs":["+","-"],"label":"Tetrahedral sp3 direction"}},
            {"text":"The geometry maximizes separation of the four equivalent bonding directions around the central carbon atom."}
        ]
    })
    # Bonding step: place H atoms and both electrons of each C-H bond into
    # the overlap region. Each H atom is positioned by the canonical renderer.
    bond_focus=["carbon"]+[f"hyb_{i}" for i in range(4)]+[f"H_{i}" for i in range(4)]+[f"H_e{i}" for i in range(4)]+[f"bond_{i}" for i in range(4)]
    moves=[]
    for i,d in enumerate(dirs):
        mid=[d[j]*0.78 for j in range(3)]
        moves.append({"id":f"e{i+1}_2s" if i<2 else ("e3_2px" if i==2 else "e4_2py"),"to":mid,"level":"level_sp3","orbitalIndex":i,"spinDir":"up"})
        moves.append({"id":f"H_e{i}","to":mid,"level":"level_H1s","orbitalIndex":0,"spinDir":"up"})
    steps.append({
        "caption":"Each hydrogen approaches along an sp3 direction. Its 1s electron and one carbon electron enter the overlap region to form a shared C-H sigma bond.",
        "focus":bond_focus,
        "moves":moves,
        "theory":[
            {"text":"A sigma bond forms by head-on overlap of the carbon sp3 hybrid orbital with the hydrogen 1s orbital, concentrating electron density between the nuclei.","diagram":{"kind":"overlap","overlapLabel":"σ C-H","label":"Head-on orbital overlap forms a sigma bond"}},
            {"text":"The bonding pair is shared between carbon and hydrogen; the two electrons occupy the bonding region rather than belonging exclusively to either atom."}
        ]
    })
    steps.append({
        "caption":"The completed molecule is methane, CH4: carbon is surrounded by four equivalent C-H sigma bonds in a tetrahedral arrangement.",
        "focus":["carbon","hyb_0","hyb_1","hyb_2","hyb_3","H_0","H_1","H_2","H_3","bond_0","bond_1","bond_2","bond_3"],
        "theory":[
            {"text":"Methane has four C-H sigma bonds and no lone pairs on the central carbon atom.","diagram":{"kind":"overlap","overlapLabel":"4 × σ","label":"Four equivalent C-H sigma bonds"}},
            {"text":"Its ideal molecular geometry is tetrahedral, with H-C-H bond angles of approximately 109.5°."}
        ]
    })

    return {
        "title":"sp3 Hybridisation — Carbon to Methane",
        "summary":"An interactive, step-by-step model of carbon going from its ground-state configuration through excitation and orbital mixing to four tetrahedral sp3 orbitals and the final methane molecule.",
        "legend":[
            {"color":"#38bdf8","label":"Atomic s orbital"},{"color":"#60a5fa","label":"Atomic p orbital"},
            {"color":"#a855f7","label":"sp3 hybrid orbital"},{"color":"#fff6b0","label":"Electron"},
            {"color":"#e5e7eb","label":"Hydrogen"},{"color":"#22d3ee","label":"C-H sigma bond"}
        ],
        "keyPoints":[
            "Carbon ground state: 2s²2p².",
            "One 2s electron is promoted to a vacant 2p orbital in the bonding model.",
            "One 2s + three 2p orbitals form four equivalent sp3 hybrids.",
            "The ideal tetrahedral angle is 109.5°.",
            "Methane contains four C-H sigma bonds and has tetrahedral geometry."
        ],
        "equation":"1 s + 3 p → 4 sp3 hybrid orbitals",
        "conditions":[],
        "related":["Sigma bonding","Tetrahedral geometry","Orbital overlap"],
        "objects":objects,
        "steps":steps,
        "topic":topic
    }


# ================================================================
# DIAGRAM LAB -- VSEPR MOLECULAR SHAPE LIBRARY
# ----------------------------------------------------------------
# Deterministic, hand-verified 3D ball-and-stick + 2D "displayed
# structure" scenes for the standard set of VSEPR molecular geometries
# (9701-syllabus staples like CH4/NH3/H2O plus the classic expanded-
# octet examples SF6/XeF4/ClF3 etc.). Mirrors the _canonical_sp3_diagram
# approach above: a curated set of molecule names/formulas is answered
# from this exact, scientifically-checked data instead of the general
# Gemini pipeline, so bond angles and lone-pair positions are always
# textbook-correct and fully interactive (drag/rotate/click/focus, same
# as every other Diagram Lab scene). Every other Diagram Lab topic
# (including sp3/hybridisation, handled above) is completely
# unaffected -- see the _match_molecule_topic() check added into
# study_generate_diagram below.
# ================================================================

_ELEMENT_COLORS = {
    "C": "#5c6b7a", "H": "#e5e7eb", "O": "#ef4444", "N": "#60a5fa",
    "F": "#4ade80", "Cl": "#22c55e", "S": "#facc15", "P": "#fb923c",
    "Xe": "#a855f7", "Br": "#f97316", "I": "#c084fc", "Be": "#94a3b8",
    "Si": "#7dd3fc", "B": "#f472b6",
}


def _element_color(sym):
    return _ELEMENT_COLORS.get(sym, "#38bdf8")


# Idealised electron-domain direction sets, reusing the exact vectors
# already defined for sp/sp2/sp3/sp3d/sp3d2 above so a molecule's
# bonding domains always agree with the equivalent hybrid-orbital set.
_VSEPR_DOMAIN_DIRS = {
    "linear": _CANONICAL_HYBRID_DIRECTIONS["sp"],
    "trigonalPlanar": _CANONICAL_HYBRID_DIRECTIONS["sp2"],
    "tetrahedral": _CANONICAL_HYBRID_DIRECTIONS["sp3"],
    "trigonalBipyramidal": _CANONICAL_HYBRID_DIRECTIONS["sp3d"],
    "octahedral": _CANONICAL_HYBRID_DIRECTIONS["sp3d2"],
}

# Each entry maps a molecule to: which indices of its electron-domain
# direction set are real bonded ligands vs lone pairs on the central
# atom (this alone fixes the real 3D shape, e.g. XeF4's two lone pairs
# on the octahedral set's z-axis leaves the 4 F atoms in a perfect
# square plane), plus "vsepr2D" hints -- per-bond angle (clockwise from
# 12 o'clock) and style (plain/wedge/dash, for depth) -- used to draw
# the 2D displayed-structure diagram next to the 3D model.
_MOLECULE_LIBRARY = {
    "co2": {
        "aliases": ["co2", "carbon dioxide"],
        "formula": "CO2", "name": "Carbon Dioxide",
        "central": "C", "ligand": "O",
        "domain": "linear", "bondIdx": [0, 1], "lpIdx": [],
        "shapeName": "linear", "domainName": "linear", "bondAngle": "180°",
        "vsepr2D": {"bonds": [
            {"element": "O", "angle": 90, "style": "plain", "lp": 2},
            {"element": "O", "angle": 270, "style": "plain", "lp": 2},
        ], "centralLP": []},
    },
    "bf3": {
        "aliases": ["bf3", "boron trifluoride"],
        "formula": "BF3", "name": "Boron Trifluoride",
        "central": "B", "ligand": "F",
        "domain": "trigonalPlanar", "bondIdx": [0, 1, 2], "lpIdx": [],
        "shapeName": "trigonal planar", "domainName": "trigonal planar", "bondAngle": "120°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 0, "style": "plain", "lp": 3},
            {"element": "F", "angle": 120, "style": "plain", "lp": 3},
            {"element": "F", "angle": 240, "style": "plain", "lp": 3},
        ], "centralLP": []},
    },
    "h2o": {
        "aliases": ["h2o", "water molecule", "water"],
        "formula": "H2O", "name": "Water",
        "central": "O", "ligand": "H",
        "domain": "tetrahedral", "bondIdx": [0, 1], "lpIdx": [2, 3],
        "shapeName": "bent (V-shaped)", "domainName": "tetrahedral", "bondAngle": "104.5°",
        "vsepr2D": {"bonds": [
            {"element": "H", "angle": 225, "style": "plain", "lp": 0},
            {"element": "H", "angle": 315, "style": "plain", "lp": 0},
        ], "centralLP": [45, 135]},
    },
    "so2": {
        "aliases": ["so2", "sulfur dioxide", "sulphur dioxide"],
        "formula": "SO2", "name": "Sulfur Dioxide",
        "central": "S", "ligand": "O",
        "domain": "trigonalPlanar", "bondIdx": [0, 1], "lpIdx": [2],
        "shapeName": "bent (V-shaped)", "domainName": "trigonal planar", "bondAngle": "119°",
        "vsepr2D": {"bonds": [
            {"element": "O", "angle": 225, "style": "plain", "lp": 2},
            {"element": "O", "angle": 315, "style": "plain", "lp": 2},
        ], "centralLP": [90]},
    },
    "ch4": {
        "aliases": ["ch4", "methane"],
        "formula": "CH4", "name": "Methane",
        "central": "C", "ligand": "H",
        "domain": "tetrahedral", "bondIdx": [0, 1, 2, 3], "lpIdx": [],
        "shapeName": "tetrahedral", "domainName": "tetrahedral", "bondAngle": "109.5°",
        "vsepr2D": {"bonds": [
            {"element": "H", "angle": 0, "style": "plain", "lp": 0},
            {"element": "H", "angle": 270, "style": "plain", "lp": 0},
            {"element": "H", "angle": 135, "style": "wedge", "lp": 0},
            {"element": "H", "angle": 45, "style": "dash", "lp": 0},
        ], "centralLP": []},
    },
    "nh3": {
        "aliases": ["nh3", "ammonia"],
        "formula": "NH3", "name": "Ammonia",
        "central": "N", "ligand": "H",
        "domain": "tetrahedral", "bondIdx": [0, 1, 2], "lpIdx": [3],
        "shapeName": "trigonal pyramidal", "domainName": "tetrahedral", "bondAngle": "107°",
        "vsepr2D": {"bonds": [
            {"element": "H", "angle": 0, "style": "plain", "lp": 0},
            {"element": "H", "angle": 270, "style": "plain", "lp": 0},
            {"element": "H", "angle": 135, "style": "wedge", "lp": 0},
        ], "centralLP": [45]},
    },
    "pcl5": {
        "aliases": ["pcl5", "phosphorus pentachloride"],
        "formula": "PCl5", "name": "Phosphorus Pentachloride",
        "central": "P", "ligand": "Cl",
        "domain": "trigonalBipyramidal", "bondIdx": [0, 1, 2, 3, 4], "lpIdx": [],
        "shapeName": "trigonal bipyramidal", "domainName": "trigonal bipyramidal", "bondAngle": "90° / 120°",
        "vsepr2D": {"bonds": [
            {"element": "Cl", "angle": 0, "style": "plain", "lp": 3},
            {"element": "Cl", "angle": 180, "style": "plain", "lp": 3},
            {"element": "Cl", "angle": 90, "style": "plain", "lp": 3},
            {"element": "Cl", "angle": 210, "style": "wedge", "lp": 3},
            {"element": "Cl", "angle": 330, "style": "dash", "lp": 3},
        ], "centralLP": []},
    },
    "sf4": {
        "aliases": ["sf4", "sulfur tetrafluoride", "sulphur tetrafluoride"],
        "formula": "SF4", "name": "Sulfur Tetrafluoride",
        "central": "S", "ligand": "F",
        "domain": "trigonalBipyramidal", "bondIdx": [1, 2, 3, 4], "lpIdx": [0],
        "shapeName": "see-saw (disphenoidal)", "domainName": "trigonal bipyramidal", "bondAngle": "< 120° / < 90°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 0, "style": "plain", "lp": 3},
            {"element": "F", "angle": 180, "style": "plain", "lp": 3},
            {"element": "F", "angle": 90, "style": "plain", "lp": 3},
            {"element": "F", "angle": 210, "style": "wedge", "lp": 3},
        ], "centralLP": [330]},
    },
    "clf3": {
        "aliases": ["clf3", "chlorine trifluoride"],
        "formula": "ClF3", "name": "Chlorine Trifluoride",
        "central": "Cl", "ligand": "F",
        "domain": "trigonalBipyramidal", "bondIdx": [2, 3, 4], "lpIdx": [0, 1],
        "shapeName": "T-shaped", "domainName": "trigonal bipyramidal", "bondAngle": "< 90°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 90, "style": "plain", "lp": 3},
            {"element": "F", "angle": 0, "style": "wedge", "lp": 3},
            {"element": "F", "angle": 180, "style": "dash", "lp": 3},
        ], "centralLP": [210, 330]},
    },
    "xef2": {
        "aliases": ["xef2", "xenon difluoride"],
        "formula": "XeF2", "name": "Xenon Difluoride",
        "central": "Xe", "ligand": "F",
        "domain": "trigonalBipyramidal", "bondIdx": [3, 4], "lpIdx": [0, 1, 2],
        "shapeName": "linear", "domainName": "trigonal bipyramidal", "bondAngle": "180°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 0, "style": "plain", "lp": 3},
            {"element": "F", "angle": 180, "style": "plain", "lp": 3},
        ], "centralLP": [90, 210, 330]},
    },
    "sf6": {
        "aliases": ["sf6", "sulfur hexafluoride", "sulphur hexafluoride"],
        "formula": "SF6", "name": "Sulfur Hexafluoride",
        "central": "S", "ligand": "F",
        "domain": "octahedral", "bondIdx": [0, 1, 2, 3, 4, 5], "lpIdx": [],
        "shapeName": "octahedral", "domainName": "octahedral", "bondAngle": "90°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 0, "style": "plain", "lp": 3},
            {"element": "F", "angle": 180, "style": "plain", "lp": 3},
            {"element": "F", "angle": 90, "style": "plain", "lp": 3},
            {"element": "F", "angle": 270, "style": "plain", "lp": 3},
            {"element": "F", "angle": 45, "style": "dash", "lp": 3},
            {"element": "F", "angle": 225, "style": "wedge", "lp": 3},
        ], "centralLP": []},
    },
    "xef4": {
        "aliases": ["xef4", "xenon tetrafluoride"],
        "formula": "XeF4", "name": "Xenon Tetrafluoride",
        "central": "Xe", "ligand": "F",
        "domain": "octahedral", "bondIdx": [0, 1, 2, 3], "lpIdx": [4, 5],
        "shapeName": "square planar", "domainName": "octahedral", "bondAngle": "90°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 0, "style": "plain", "lp": 3},
            {"element": "F", "angle": 180, "style": "plain", "lp": 3},
            {"element": "F", "angle": 45, "style": "dash", "lp": 3},
            {"element": "F", "angle": 135, "style": "wedge", "lp": 3},
        ], "centralLP": [225, 315]},
    },
    "brf5": {
        "aliases": ["brf5", "bromine pentafluoride"],
        "formula": "BrF5", "name": "Bromine Pentafluoride",
        "central": "Br", "ligand": "F",
        "domain": "octahedral", "bondIdx": [0, 1, 2, 3, 4], "lpIdx": [5],
        "shapeName": "square pyramidal", "domainName": "octahedral", "bondAngle": "< 90°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 0, "style": "plain", "lp": 3},
            {"element": "F", "angle": 180, "style": "plain", "lp": 3},
            {"element": "F", "angle": 90, "style": "plain", "lp": 3},
            {"element": "F", "angle": 270, "style": "plain", "lp": 3},
            {"element": "F", "angle": 45, "style": "wedge", "lp": 3},
        ], "centralLP": [225]},
    },
    "if5": {
        "aliases": ["if5", "iodine pentafluoride"],
        "formula": "IF5", "name": "Iodine Pentafluoride",
        "central": "I", "ligand": "F",
        "domain": "octahedral", "bondIdx": [0, 1, 2, 3, 4], "lpIdx": [5],
        "shapeName": "square pyramidal", "domainName": "octahedral", "bondAngle": "< 90°",
        "vsepr2D": {"bonds": [
            {"element": "F", "angle": 0, "style": "plain", "lp": 3},
            {"element": "F", "angle": 180, "style": "plain", "lp": 3},
            {"element": "F", "angle": 90, "style": "plain", "lp": 3},
            {"element": "F", "angle": 270, "style": "plain", "lp": 3},
            {"element": "F", "angle": 45, "style": "wedge", "lp": 3},
        ], "centralLP": [225]},
    },
}

_MOLECULE_ALIAS_PATTERNS = None


def _molecule_alias_patterns():
    """Builds (and caches) one whole-word regex per molecule alias, longest
    alias first so e.g. "sf4" can never accidentally match as a substring
    of a longer word, and formula-style aliases match regardless of the
    case the user typed them in."""
    global _MOLECULE_ALIAS_PATTERNS
    if _MOLECULE_ALIAS_PATTERNS is not None:
        return _MOLECULE_ALIAS_PATTERNS
    pairs = []
    for key, spec in _MOLECULE_LIBRARY.items():
        for alias in spec["aliases"]:
            pairs.append((alias, key))
    pairs.sort(key=lambda p: -len(p[0]))
    _MOLECULE_ALIAS_PATTERNS = [
        (re.compile(r"\b" + re.escape(alias) + r"\b", re.IGNORECASE), key) for alias, key in pairs
    ]
    return _MOLECULE_ALIAS_PATTERNS


def _match_molecule_topic(topic):
    """Returns the _MOLECULE_LIBRARY key for a Diagram Lab topic that names
    one of the curated VSEPR molecules (by formula or common name), or None
    if it isn't one -- in which case study_generate_diagram falls back to
    the sp3 check / general Gemini pipeline exactly as before."""
    t = (topic or "").strip()
    if not t:
        return None
    for pattern, key in _molecule_alias_patterns():
        if pattern.search(t):
            return key
    return None


def _canonical_molecule_diagram(topic, mol_key):
    """Deterministic 3D ball-and-stick + 2D displayed-structure scene for one
    of the curated VSEPR molecules in _MOLECULE_LIBRARY. Built the same way
    as _canonical_sp3_diagram above: exact, hand-verified bond directions
    and lone-pair positions rather than anything AI-generated, so the shape
    (e.g. XeF4's square planar geometry with its two axial lone pairs) is
    always textbook-correct, and fully interactive in the 3D renderer
    (drag to rotate, click to focus) exactly like every other Diagram Lab
    scene. Also attaches a "vsepr2D" field the renderer uses to draw the
    matching 2D displayed structure alongside the 3D model."""
    spec = _MOLECULE_LIBRARY[mol_key]
    dirs = [_normalize_vec3(v) for v in _VSEPR_DOMAIN_DIRS[spec["domain"]]]
    bond_length = 1.7
    central_color = _element_color(spec["central"])
    ligand_color = _element_color(spec["ligand"])

    objects = [{
        "id": "central", "type": "sphere", "position": [0, 0, 0], "radius": 0.5,
        "color": central_color, "label": spec["central"],
        "detail": f"The central atom of {spec['name']} ({spec['formula']}).",
    }]
    steps_focus = ["central"]

    for n, idx in enumerate(spec["bondIdx"]):
        vec = dirs[idx]
        pos = [c * bond_length for c in vec]
        atom_id = f"ligand_{n}"
        bond_id = f"bond_{n}"
        objects.append({
            "id": atom_id, "type": "sphere", "position": pos, "radius": 0.32,
            "color": ligand_color, "label": spec["ligand"],
            "detail": f"A {spec['ligand']} atom bonded to the central {spec['central']} atom.",
        })
        objects.append({
            "id": bond_id, "type": "bond", "position": [0, 0, 0], "to": atom_id,
            "width": 0.06, "color": "#9fb4d6",
        })
        steps_focus += [atom_id, bond_id]

    for n, idx in enumerate(spec["lpIdx"]):
        vec = dirs[idx]
        pos = [c * 0.95 for c in vec]
        lp_id = f"lonepair_{n}"
        objects.append({
            "id": lp_id, "type": "lonePair", "position": pos, "direction": list(vec),
            "color": "#fff6b0", "label": "lone pair",
            "detail": (
                f"A lone pair of electrons on the central {spec['central']} atom -- it occupies its own "
                "electron domain and repels other domains just like a bonding pair, even though no atom "
                "is attached to it, which is why it still affects the molecular shape."
            ),
        })
        steps_focus.append(lp_id)

    bonding_domains = len(spec["bondIdx"])
    lone_domains = len(spec["lpIdx"])
    caption = (
        f"{spec['name']} ({spec['formula']}) has {bonding_domains} bonding domain"
        f"{'s' if bonding_domains != 1 else ''}"
        + (
            f" and {lone_domains} lone pair{'s' if lone_domains != 1 else ''} on the central {spec['central']} atom"
            if lone_domains else f" and no lone pairs on the central {spec['central']} atom"
        )
        + f", giving a {spec['domainName']} electron-domain geometry and a {spec['shapeName']} molecular "
        f"shape, with bond angle(s) of approximately {spec['bondAngle']}."
    )

    legend = [
        {"color": central_color, "label": f"{spec['central']} (central atom)"},
        {"color": ligand_color, "label": f"{spec['ligand']} (bonded atom)"},
    ]
    if lone_domains:
        legend.append({"color": "#fff6b0", "label": "Lone pair"})

    key_points = [
        f"{spec['formula']} has {bonding_domains + lone_domains} electron domain"
        f"{'s' if (bonding_domains + lone_domains) != 1 else ''} around the central {spec['central']} atom.",
        f"Electron-domain geometry: {spec['domainName']}.",
        f"Molecular shape (ligands only): {spec['shapeName']}.",
        f"Approximate bond angle(s): {spec['bondAngle']}.",
    ]
    if lone_domains:
        key_points.append(
            "Lone pairs repel more strongly than bonding pairs, which is why the real bond angle can be "
            "slightly smaller than the ideal electron-domain angle."
        )

    return {
        "title": f"{spec['name']} ({spec['formula']}) — {spec['shapeName'].title()}",
        "summary": caption,
        "legend": legend,
        "keyPoints": key_points,
        "equation": "",
        "conditions": [],
        "related": ["VSEPR theory", "Electron-pair repulsion", "Molecular geometry"],
        "objects": objects,
        "steps": [{"caption": caption, "focus": steps_focus}],
        "vsepr2D": {
            "centralElement": spec["central"],
            "bonds": spec["vsepr2D"]["bonds"],
            "centralLP": spec["vsepr2D"]["centralLP"],
        },
        "topic": topic,
    }


def study_generate_diagram(topic, use_youtube_research=False):
    """
    Entry point for the Diagram Lab's "Generate" button (routed from
    handle_study_command via the "diagramlab::<topic>" marker the UI
    sends, or "diagramlab-yt::<topic>" when the "Research on YouTube
    first" toggle is on). Produces a JSON scene description for the
    3D renderer plus a spoken narration, and never leaves the UI
    hanging: every failure path still prints a
    STUDY_DIAGRAM::{"error": "..."} so the Diagram Lab can show a
    clear message instead of spinning forever.

    When use_youtube_research is True, this first searches YouTube,
    pulls transcripts from the top relevant videos, and has
    friday_youtube_research cross-check them into a grounded research
    brief (see that module for the full pipeline/honesty notes)
    BEFORE any diagram is designed. That brief is then fed into the
    diagram-design prompt as authoritative source material, and the
    actual video titles/links are attached to the returned scene as
    "sources" so the student can see exactly what was researched.
    Falls back to the normal model-only pipeline (still succeeds,
    just without the extra grounding) if no usable videos are found
    or the AI brain is unavailable for the cross-check step.
    """
    topic = (topic or "").strip()
    if not topic:
        speak("Tell me what you'd like me to diagram.")
        print("STUDY_DIAGRAM::" + json.dumps({"error": "Tell me a topic to diagram first."}))
        return True

    youtube_research = None
    if use_youtube_research:
        speak(f"Let me search YouTube and go through some videos on {topic} first, sir.")
        emit_progress(8, "Searching YouTube for relevant videos…", task=f"Diagram: {topic}")
        youtube_research = friday_youtube_research.research_topic_from_youtube(topic)
        emit_progress(
            22,
            youtube_research.get("note") or "Finished checking video sources.",
            task=f"Diagram: {topic}",
        )

    # A deterministic canonical sp3 scene is used for this high-value
    # teaching example so the renderer always receives the complete
    # ground-state -> promotion -> hybridisation -> geometry -> bonding ->
    # methane sequence. All other Diagram Lab topics continue through the
    # existing Gemini pipeline unchanged. Video sources (if any were
    # gathered above) are still attached so the student can see what was
    # cross-checked, even though this exact scene is hand-verified rather
    # than AI-designed from the research brief.
    if re.search(r"\bsp\s*3\b|\bsp3\b|sp3 hybrid|sp3 hybridisation|sp3 hybridization", topic, re.IGNORECASE):
        data = _canonical_sp3_diagram(topic)
        if youtube_research and youtube_research.get("videos"):
            data["sources"] = youtube_research["videos"]
            data["researchNote"] = youtube_research.get("note")
        print("STUDY_DIAGRAM::" + json.dumps(data, ensure_ascii=False))
        emit_progress(100, "Diagram ready", task=f"Diagram: {topic}")
        closing = "I have built the complete sp3 hybridisation sequence, including electron promotion, orbital mixing, tetrahedral geometry and methane bonding."
        if youtube_research and youtube_research.get("ok"):
            closing += f" I also cross-checked it against {len(youtube_research['videos'])} YouTube videos on the topic."
        speak(closing)
        return True

    # A deterministic canonical scene is also used for the curated set of
    # VSEPR molecule shapes in _MOLECULE_LIBRARY (e.g. "XeF4", "SF6",
    # "ammonia") -- same rationale as the sp3 block above: exact,
    # hand-verified 3D geometry plus a matching 2D displayed structure,
    # instead of leaving bond angles/lone-pair placement to the AI. Any
    # topic that isn't one of these named molecules falls through to the
    # existing Gemini pipeline completely unchanged.
    mol_key = _match_molecule_topic(topic)
    if mol_key:
        data = _canonical_molecule_diagram(topic, mol_key)
        if youtube_research and youtube_research.get("videos"):
            data["sources"] = youtube_research["videos"]
            data["researchNote"] = youtube_research.get("note")
        print("STUDY_DIAGRAM::" + json.dumps(data, ensure_ascii=False))
        emit_progress(100, "Diagram ready", task=f"Diagram: {topic}")
        closing = (
            f"I have built the 3D molecular shape and the 2D displayed structure for "
            f"{_MOLECULE_LIBRARY[mol_key]['name']}."
        )
        if youtube_research and youtube_research.get("ok"):
            closing += f" I also cross-checked it against {len(youtube_research['videos'])} YouTube videos on the topic."
        speak(closing)
        return True

    _ensure_gemini_client()
    if not client:
        msg = "Gemini is temporarily unavailable, so I cannot finish that diagram yet. I'll retry when the connection recovers."
        speak(msg)
        print("STUDY_DIAGRAM::" + json.dumps({"error": msg}))
        return True

    if not use_youtube_research:
        speak(f"Generating an interactive 3D diagram of {topic}, sir.")
    emit_progress(30, "Designing the diagram with AI…", task=f"Diagram: {topic}")

    subject = study_state.get("subject")
    syllabus_hint = ""
    if subject and subject in SYLLABUS_MAP:
        syllabus_hint = (
            f"The learner is currently studying {SYLLABUS_MAP[subject]['name']} "
            f"(syllabus year {SYLLABUS_MAP[subject]['year']}) -- pitch the depth of the explanation for that level. "
        )

    research_block = ""
    if youtube_research and youtube_research.get("ok") and youtube_research.get("brief"):
        research_block = (
            "IMPORTANT -- GROUNDING RESEARCH: Friday already researched this exact topic by "
            f"searching YouTube and cross-checking {len(youtube_research['videos'])} real "
            "videos' transcripts against each other. Base the scientific content, terminology, "
            "step order and overall process on the research brief below rather than on your own "
            "unguided assumption -- do not contradict it or substitute a different process:\n\n"
            f"RESEARCH BRIEF:\n{youtube_research['brief']}\n\n"
        )

    prompt = (
        f"You are the diagram-design engine inside Friday's Study Mode Diagram Lab, a futuristic "
        f"holographic 3D visual explainer (think Tony Stark's HUD). Design an interactive 3D diagram "
        f"that teaches the topic: \"{topic}\". {syllabus_hint}"
        f"{research_block}"
        f"If this topic involves atoms bonding, sharing, gaining or losing electrons, or orbitals "
        f"forming/hybridizing, the student must be able to SEE the actual electrons move between "
        f"positions step by step, from the very first ground-state configuration all the way through "
        f"to the final bonded structure -- represent every electron that moves as its own \"electron\" "
        f"object and give it a \"moves\" entry on each step where it relocates. Never summarize this into "
        f"fewer steps than the real mechanism has. Alongside the 3D scene, also build the \"energyLevel\" "
        f"objects (with \"orbitals\" boxes) and per-electron \"level\"/\"orbitalIndex\"/\"spinDir\" fields "
        f"needed to drive a synchronized 2D orbital-box diagram, exactly like a textbook electron-"
        f"configuration diagram (e.g. \"2s [up down]  2p [up][up][ ]\") shown next to the 3D model -- the "
        f"student must be able to SEE an electron slide from its old box into a new, specific, correctly "
        f"empty box on the exact step it moves, never an instant unexplained swap. Also add a short "
        f"\"theory\" layer to every step that has real underlying theory, so the student can press "
        f"\"Go Deeper\" to reveal progressively deeper explanations without leaving the diagram -- give at "
        f"least one of those theory layers a small \"diagram\" (see MINI-DIAGRAMS in the schema) so pressing "
        f"Go Deeper shows an actual zoomed-in visual, not only text. Also give every orbital/electron object "
        f"that matters a \"physics\" block (real shape, phase, quantum numbers, spin) and a \"miniDiagram\" so "
        f"clicking on it in the 3D view explains the real physics of that exact orbital, not a generic caption. "
        + DIAGRAM_SCHEMA_HINT
    )

    raw = _diagram_ai_call(prompt)
    data = _parse_diagram_json(raw)

    if not isinstance(data, dict) or "objects" not in data or "steps" not in data:
        # One repair attempt: hand the FULL broken output back (never
        # truncated -- a partial repair input would just bake a partial
        # process into the "fixed" result) and ask for a straight fix,
        # with the same generous token budget, before giving up cleanly.
        if raw:
            repair_prompt = (
                "The text below was supposed to be one strict JSON object but is invalid or incomplete "
                "(it may have been cut off before finishing). Complete it and return ONLY the corrected, "
                "valid, COMPLETE JSON object with its full \"steps\" array intact -- never a shortened or "
                "summarized version -- nothing else:\n\n" + raw
            )
            raw2 = _diagram_ai_call(repair_prompt, max_output_tokens=8192)
            data = _parse_diagram_json(raw2)

    if not isinstance(data, dict) or "objects" not in data or "steps" not in data:
        msg = (
            "I could not design a clean diagram for that topic. Try rephrasing it, for example "
            "'sp3 hybrid orbitals', 'Bohr model energy levels', or 'projectile motion vectors'."
        )
        speak("I could not build a clean diagram for that topic. Please try rephrasing it.")
        print("STUDY_DIAGRAM::" + json.dumps({"error": msg}))
        emit_progress(100, "Stopped — could not build a clean diagram", task=f"Diagram: {topic}")
        return True

    # Second safety net: for hybridization topics specifically, check the
    # scene actually contains the full ground-state -> promotion ->
    # hybridization -> bonding story with the right QUANTITIES (not just the
    # right labels) -- catches a sparse, mostly-empty scene like a single
    # orbital lobe and one atom with no bonded hydrogens. Retries up to twice
    # since one repair pass may not be enough for a smaller/faster model.
    for _ in range(2):
        if not _diagram_missing_hybrid_stages(data, topic):
            break
        requested = _requested_hybrid_type(topic)
        objects_now = data.get("objects") or []
        labels_now = {
            (o.get("label") or "").strip().lower()
            for o in objects_now if isinstance(o, dict) and o.get("type") == "energyLevel"
        }
        topic_mismatch_note = ""
        if requested and requested not in labels_now:
            topic_mismatch_note = (
                f"CRITICAL: the topic explicitly requires {requested} hybridization, but the JSON below "
                f"does not contain an energyLevel object labeled exactly \"{requested}\" -- it answered a "
                f"different hybridization type or a different molecule than what was asked. Redo it for "
                f"{requested} specifically, not a different hybrid type. "
            )
        repair_prompt = (
            topic_mismatch_note +
            "The JSON scene below is for the topic \"" + topic + "\" but is critically incomplete -- it is "
            "missing required stages/quantities of the real hybridization mechanism. It must contain ALL of: "
            "(1) the ground-state electron configuration as its own energyLevel rows (e.g. \"1s\", \"2s\", "
            "\"2p\"), each with the correct box count (s=1, p=3), (2) promotion/excitation if the real "
            "chemistry needs it, (3) the resulting hybrid orbitals as their own energyLevel row (e.g. \"sp3\" "
            "with exactly 4 boxes) with ONE separate \"electron\" object per box (not one electron total), "
            "(4) the correct bond angle labeled, and (5) the complete final bonded structure with the central "
            "atom AND a separate \"sphere\" object for EVERY bonded atom (e.g. methane needs 4 separate "
            "Hydrogen sphere objects, each actually bonded to the central atom, not just 1 atom floating "
            "alone) -- at least 6 objects and 4 steps total, never a sparse 2-3 object placeholder scene. "
            "Also tag every hybrid orbitalLobe and every bonded atom with \"hybridSet\"/\"hybridIndex\" "
            "(and \"hybridCenter\" on the atom) so the geometry renders correctly. "
            "Regenerate the COMPLETE, corrected JSON object with every one of these present, same schema, "
            "same topic, nothing else:\n\n" + json.dumps(data, ensure_ascii=False)
        )
        raw3 = _diagram_ai_call(repair_prompt, max_output_tokens=8192)
        data3 = _parse_diagram_json(raw3)
        if isinstance(data3, dict) and "objects" in data3 and "steps" in data3:
            data = data3
        else:
            break

    data = _normalize_energy_level_orbitals(data)
    data = _apply_canonical_hybrid_geometry(data)
    data = _backfill_missing_diagram_details(data)
    data["topic"] = topic
    if youtube_research and youtube_research.get("videos"):
        data["sources"] = youtube_research["videos"]
        data["researchNote"] = youtube_research.get("note")
    print("STUDY_DIAGRAM::" + json.dumps(data, ensure_ascii=False))
    emit_progress(100, "Diagram ready", task=f"Diagram: {topic}")

    narration_parts = [data.get("title", ""), data.get("summary", "")]
    if youtube_research and youtube_research.get("ok"):
        narration_parts.append(
            f"This is grounded in {len(youtube_research['videos'])} YouTube videos I cross-checked on the topic."
        )
    elif youtube_research and not youtube_research.get("ok"):
        narration_parts.append(youtube_research.get("note", ""))
    # Step captions are deliberately NOT included here anymore -- they
    # are spoken one at a time by the UI as each step actually plays
    # (Play/Next/clicking a step card), via the "speaktext::" marker,
    # so what Friday says is synced with what lights up on screen
    # instead of being read out all at once before the diagram even
    # finishes building.
    narration = " ".join(p for p in narration_parts if p).strip()
    if narration:
        speak(narration)

    return True



EXPLANATION_CENTRE_SCHEMA = """
Return ONLY one valid JSON object with this exact shape:
{
  "title": "short explanation title",
  "syllabus": "selected syllabus name/code",
  "topic": "topic being explained",
  "doubt": "learner's question or doubt",
  "short_answer": "direct answer in 2-5 sentences",
  "explanation": [
    {"heading":"Concept / Step", "body":"clear detailed explanation"}
  ],
  "worked_example": {"question":"...", "steps":["..."], "answer":"..."},
  "exam_connection": ["how this appears in the selected syllabus/exam", "mark-scoring point"],
  "common_mistakes": ["mistake -> correction"],
  "key_terms": [{"term":"...", "meaning":"..."}],
  "source_notes": ["source title or URL"],
  "confidence_note": "brief note if any source/document limitation affects the answer"
}
RULES:
1. Answer the learner's actual doubt first, then teach the underlying concept.
2. The selected syllabus is a hard scope filter. Do not import an unrelated syllabus.
3. If an attached document is present, use it as primary evidence for questions about that document.
4. If the document does not contain enough information, say so; do not invent a question, mark, diagram label, formula, or answer.
5. For calculations, show units, substitutions and intermediate steps where useful, and re-check the arithmetic yourself before writing the final number down -- a wrong final answer is worse than a slower, fully-shown one.
6. For past-paper questions, preserve the question/part numbering and wording when it is available, and explain why each step earns marks without pretending an official mark scheme was supplied.
7. Distinguish document-derived facts from web research. Prefer official syllabus/exam-board sources, then official educational/government sources, then reputable educational sources.
8. Keep explanations student-friendly but sufficiently detailed for exam preparation.
9. Never return markdown fences or commentary outside the JSON.
10. ACCURACY GATE (do not skip): every factual claim in "explanation", "exam_connection" and "worked_example" must be traceable to either an attached document or one of the numbered RESEARCH SOURCES. Where you rely on a specific source, end that bullet/body with a bracketed tag like [S2] naming the source number. Where NO source or document actually supports a claim you believe is true from general training knowledge, say so explicitly in that item's text (e.g. "not confirmed in the supplied sources") instead of presenting it with unearned confidence.
11. If the research sources are thin, contradictory, or absent, do not fill the gap by inventing plausible-sounding specifics -- narrow the answer to what IS supported and say plainly what is not confirmed.
"""


def _extract_odf_text(path):
    """Small dependency-free ODF text fallback. Used when Gemini cannot accept an ODF file."""
    import zipfile
    from xml.etree import ElementTree as ET
    try:
        with zipfile.ZipFile(path, "r") as z:
            raw = z.read("content.xml")
        root = ET.fromstring(raw)
        parts = []
        for elem in root.iter():
            tag = elem.tag.rsplit("}", 1)[-1]
            if tag in {"p", "h", "list-item", "table-cell"}:
                text = "".join(elem.itertext()).strip()
                if text:
                    parts.append(text)
        return "\n".join(parts)[:50000]
    except Exception as error:
        print("ODF extraction error:", error)
        return ""


def _gather_explanation_research(topic, subject_label, doubt):
    queries = [
        f"{topic} {subject_label} official syllabus specification",
        f"{topic} {subject_label} detailed explanation",
        f"{topic} {subject_label} exam question mark scheme explanation {doubt[:180]}",
    ]
    blocks, seen = [], set()
    for query in queries:
        try:
            # V2045 FIX: this used to share one "research.generic" circuit
            # breaker with EVERY other research call in the app, at the
            # default 3-failure / 20-second-lockout settings meant for
            # rapid automated polling. A couple of transient network
            # blips on unrelated queries could silently block Explanation
            # Centre research for the next 20 seconds, and the past-paper
            # explainer's research below shared the exact same breaker, so
            # one feature's bad luck could silently starve the other too.
            # Each feature now gets its own breaker, a much higher failure
            # tolerance, a fast reset, and more attempts per query -- this
            # is user-initiated, one-off work, not background polling, so
            # it should almost never come back with nothing to show for it.
            pairs = run_resilient(
                "research.explanation_centre",
                lambda q=query: friday_web_research.gather_sources(q, depth=5, search_pool=10, use_cache=True),
                attempts=4, failure_threshold=10, reset_after=6.0,
            )
        except Exception as error:
            print("Explanation Centre research skipped for one query (continuing):", error)
            pairs = []
        for url, text in pairs:
            if url in seen:
                continue
            seen.add(url)
            blocks.append(f"SOURCE {len(blocks)+1}: {url}\n{text[:6000]}")
            if len(blocks) >= 10:
                break
        if len(blocks) >= 10:
            break
    if not blocks:
        return "No readable live web sources were returned. State this limitation and rely only on attached/known syllabus evidence."
    return "RESEARCH SOURCES:\n\n" + "\n\n".join(blocks)


def study_explanation_centre(payload):
    """Research-backed interactive tutoring for a selected syllabus/topic/doubt.

    Payload is JSON so arbitrary questions and Windows paths cannot be broken by a
    delimiter. Attached study documents are already uploaded before this runs.
    """
    try:
        data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception:
        data = {}
    subject = str(data.get("subject") or study_state.get("subject") or "").strip()
    topic = str(data.get("topic") or study_state.get("topic") or "").strip()
    doubt = str(data.get("doubt") or "").strip()
    if not subject:
        speak("Choose a syllabus first in Explanation Centre.")
        return True
    if subject not in SYLLABUS_MAP:
        speak("I don't recognize that syllabus. Please choose one of the supported FRIDAY syllabuses.")
        return True
    if not topic and not doubt:
        speak("Enter a topic or your doubt first.")
        return True

    syllabus = SYLLABUS_MAP[subject]
    subject_label = f"{syllabus.get('name','')} ({subject}), syllabus year {syllabus.get('year','')}"
    speak("I'm researching your question and checking it against the selected syllabus.")
    research = _gather_explanation_research(topic or doubt, subject_label, doubt)
    attached_text = []
    for item in study_state.get("documents", []):
        if not isinstance(item, dict):
            continue
        path = item.get("path", "")
        ext = Path(path).suffix.lower()
        if ext in {".odt", ".ods", ".odp"} and path:
            text = _extract_odf_text(path)
            if text:
                attached_text.append(f"ATTACHED ODF: {item.get('display_name', Path(path).name)}\n{text}")
        elif ext in {".txt", ".md"} and path:
            try:
                attached_text.append(f"ATTACHED TEXT: {item.get('display_name', Path(path).name)}\n{Path(path).read_text(encoding='utf-8', errors='ignore')[:50000]}")
            except Exception:
                pass

    prompt = (
        f"SYLLABUS: {subject_label}\nTOPIC: {topic}\nLEARNER DOUBT: {doubt}\n\n"
        f"{research}\n\n"
        + ("ATTACHED DOCUMENT TEXT FALLBACK:\n" + "\n\n".join(attached_text) + "\n\n" if attached_text else "")
        + EXPLANATION_CENTRE_SCHEMA
    )
    raw = study_generate(prompt, subject=subject, topic=topic or doubt, attached=True)
    parsed = None
    try:
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", cleaned, flags=re.I | re.S).strip()
        parsed = json.loads(cleaned)
    except Exception:
        parsed = None

    if not isinstance(parsed, dict) or not parsed.get("short_answer") or not parsed.get("explanation"):
        # A failed structured response is still useful, but make the limitation explicit.
        parsed = {
            "title": topic or doubt or "Explanation",
            "syllabus": subject_label,
            "topic": topic,
            "doubt": doubt,
            "short_answer": raw if raw else "I could not generate the explanation.",
            "explanation": [],
            "worked_example": {},
            "exam_connection": [],
            "common_mistakes": [],
            "key_terms": [],
            "source_notes": [],
            "confidence_note": "The AI response did not arrive in the structured Explanation Centre format, so it is shown as plain tutor text."
        }
    parsed["research_sources"] = [x.split("\n",1)[0].replace("SOURCE ", "") for x in research.split("\n\n") if x.startswith("SOURCE ")]
    parsed["attached_documents"] = [x.get("display_name") for x in study_state.get("documents", []) if isinstance(x, dict)]
    parsed["subject"] = subject

    # V2045 ACCURACY PASS: a second, independent Gemini call whose ONLY
    # job is to fact-check the explanation just produced against the
    # same research/attached evidence -- never trust a single generation
    # pass to grade its own accuracy. Wrapped defensively: if the check
    # itself fails for any reason, the original explanation still ships
    # (this can only ever ADD a caveat, never silently drop content).
    try:
        flagged = _verify_explanation_accuracy(research, attached_text, parsed)
        if flagged:
            note = parsed.get("confidence_note") or ""
            parsed["confidence_note"] = (note + " " if note else "") + \
                "Accuracy check flagged possible unsupported claim(s): " + "; ".join(flagged[:3])
            parsed["unverified_claims"] = flagged
    except Exception as verify_error:
        print("Explanation Centre accuracy pass skipped (safe fallback):", verify_error)

    print("STUDY_EXPLANATION::" + json.dumps(parsed, ensure_ascii=False))
    # Sentence-aware study_speak() replaces the old hard [:900] character
    # slice, which could cut a sentence off mid-word; the full explanation
    # was already printed above for the UI regardless of what gets spoken.
    study_speak(parsed.get("short_answer", "Explanation ready."))
    return True


def _verify_explanation_accuracy(research, attached_text, parsed):
    """Independent fact-check pass: asks Gemini to compare the answer
    it just gave against the SAME evidence, looking specifically for
    claims that evidence does not actually support. Returns a list of
    flagged claims (empty list = nothing flagged). This is deliberately
    a separate call from the one that wrote the explanation, so the
    model is checking work rather than re-confirming its own reasoning
    in the same breath."""
    body_text = json.dumps({
        "short_answer": parsed.get("short_answer"),
        "explanation": parsed.get("explanation"),
        "worked_example": parsed.get("worked_example"),
        "exam_connection": parsed.get("exam_connection"),
    }, ensure_ascii=False)[:12000]
    evidence = (research or "")[:12000]
    if attached_text:
        evidence += "\n\nATTACHED DOCUMENT TEXT:\n" + "\n\n".join(attached_text)[:8000]
    prompt = (
        "You are a strict fact-checker, not a tutor. Below is EVIDENCE and an ANSWER that claims to be "
        "grounded in it. List any specific factual claim in the ANSWER (a number, formula, date, definition, "
        "named mechanism, or exam-technique claim) that the EVIDENCE does NOT actually support. Ignore "
        "general teaching phrasing and claims already marked as unconfirmed. Return ONLY JSON: "
        '{"unsupported_claims": ["..."]}. Empty list if everything checks out.\n\n'
        f"EVIDENCE:\n{evidence}\n\nANSWER:\n{body_text}"
    )
    raw = study_generate(prompt, subject=parsed.get("subject"), topic="accuracy check", attached=False)
    try:
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip(), flags=re.I | re.S).strip()
        result = json.loads(cleaned)
        claims = result.get("unsupported_claims") or []
        return [str(c).strip() for c in claims if str(c).strip()][:5]
    except Exception:
        return []


def study_upload_document(path_text):
    """Attach PDF/DOCX/TXT/ODT/ODS/ODP for Study Mode and Explanation Centre."""
    _ensure_gemini_client()
    raw = str(path_text or "").strip().strip('"').strip("'")
    path = Path(raw).expanduser()
    allowed = {".pdf", ".docx", ".txt", ".md", ".odt", ".ods", ".odp"}
    if not path.exists() or not path.is_file():
        speak("I could not find that study document.")
        return True
    if path.suffix.lower() not in allowed:
        speak("Explanation Centre accepts PDF, Word, text, and OpenDocument files: ODT, ODS, or ODP.")
        return True
    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > 50:
        speak("That document is larger than the supported 50 megabyte upload limit.")
        return True
    if client is None:
        speak("Gemini is temporarily unavailable, so I cannot explain that document yet. I'll retry when the connection recovers.")
        return True
    try:
        uploaded = client.files.upload(file=str(path))
        record = {
            "name": getattr(uploaded, "name", ""),
            "display_name": path.name,
            "path": str(path.resolve()),
            "extension": path.suffix.lower(),
            "uploaded": datetime.datetime.now().isoformat(timespec="seconds")
        }
        docs = [x for x in study_state.get("documents", []) if x.get("path") != record["path"]]
        docs.append(record)
        study_state["documents"] = docs[-5:]
        save_study()
        speak(f"Attached {path.name} to Explanation Centre.")
    except Exception as error:
        print("Study document upload error:", error)
        # ODF can still be useful through the local text extractor; keep the path even if
        # Gemini rejected the binary so Explanation Centre can ground itself in the file.
        if path.suffix.lower() in {".odt", ".ods", ".odp"}:
            record = {"name":"", "display_name":path.name, "path":str(path.resolve()), "extension":path.suffix.lower(), "uploaded":"local-fallback"}
            docs = [x for x in study_state.get("documents", []) if x.get("path") != record["path"]]
            docs.append(record); study_state["documents"] = docs[-5:]; save_study()
            speak(f"I attached {path.name} using local ODF reading. The explanation centre can still read its text.")
        else:
            speak("I could not attach that study document.")
    return True


def study_upload_pdf(path_text):
    _ensure_gemini_client()
    raw = path_text.strip().strip('"').strip("'")
    path = Path(raw).expanduser()
    if not path.exists() or not path.is_file():
        speak("I could not find that PDF file.")
        return True
    if path.suffix.lower() != ".pdf":
        speak("Study mode currently accepts PDF files for document attachment.")
        return True
    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > 50:
        speak("That PDF is larger than the Gemini PDF input limit of 50 megabytes. Please use a smaller file.")
        return True

    speak("Uploading the study PDF. Please wait.")
    try:
        uploaded = client.files.upload(file=str(path))
        record = {
            "name": getattr(uploaded, "name", ""),
            "display_name": path.name,
            "path": str(path.resolve()),
            "uploaded": datetime.datetime.now().isoformat(timespec="seconds")
        }
        study_state["pdfs"] = [x for x in study_state.get("pdfs", []) if x.get("path") != record["path"]]
        study_state["pdfs"].append(record)
        study_state["pdfs"] = study_state["pdfs"][-5:]
        save_study()
        speak(f"I attached {path.stem} to the study session.")
        return True
    except Exception as error:
        print("PDF upload error:", error)
        speak("I could not upload that PDF.")
        return True


def study_list_files():
    pdfs = study_state.get("pdfs", [])
    if not pdfs:
        speak("There are no PDFs attached to the study session.")
        return True
    names = [x.get("display_name", "unnamed PDF") for x in pdfs]
    speak("Attached study PDFs are: " + ", ".join(names))
    return True


def study_remove_files():
    study_state["pdfs"] = []
    save_study()
    speak("I cleared the attached study PDFs from the current session.")
    return True


# ============================================================
# AI NOTES GENERATOR
# ------------------------------------------------------------
# Two entry points, both ending at friday_notes_engine.build_gorgeous_notes():
#   study_generate_notes()      -- topic (+ optional attached PDF/doc)
#                                   -> web research + syllabus context
#                                   -> Gemini structures it -> PDF.
#   study_scan_notes_images()   -- one or more photographed notes
#                                   -> Gemini reads + restructures the
#                                   handwriting/print directly (no
#                                   separate OCR dependency needed --
#                                   Gemini's multimodal input reads
#                                   the images itself) -> PDF. Falls
#                                   back to a plain (still tidy)
#                                   image-embedding PDF if Gemini is
#                                   unreachable.
# ============================================================

_NOTES_JSON_SCHEMA_PROMPT = """
Return ONLY one valid JSON object. The output is going directly into a PDF renderer.
The goal is NOT a generic summary: create COMPLETE, exam-useful notes that look like
an attractive handwritten study page similar to the user's reference notebook image.

Required JSON shape:
{
  "chapter_title": "short attractive topic title",
  "subject_line": "subject + selected syllabus + topic",
  "what_is": "clear 2-4 sentence explanation of the topic",
  "topic_coverage": ["major examinable subtopic — what it covers and how it connects", ...],
  "key_points": ["high-value syllabus point", ...],
  "equation": "main equation/rule OR empty string when genuinely not applicable",
  "equation_explanation": "what every important symbol/term means",
  "requirements": ["conditions, assumptions, apparatus, prerequisites, or rules", ...],
  "process_steps": [
      {"title":"Step name","explanation":"what happens and why"},
      ...
  ],
  "key_ideas": [
      {"name":"Concept","explanation":"clear exam-appropriate explanation"},
      ...
  ],
  "diagrams": [
      {"kind":"flow | cycle | hub | energy | molecule3d | lobes",
       "title":"short diagram title", "caption":"what this proves or explains in an exam answer",
       "center":"(cycle/hub/lobes/molecule3d only) centre label",
       "nodes":[{"label":"short stage or part", "detail":"accurate explanation"}, ...],
       "columns":[{"title":"stage title","levels":[{"label":"2p","energy":2.0,"boxes":[1,1,0]}]}],
       "transitions":["short label for the arrow between column 1 and 2", ...],
       "shape":"tetrahedral | trigonal_planar | linear | bent | pyramidal",
       "substituents":["H","H","H","H"], "angle_label":"e.g. 109.5 degrees",
       "angles":[90,210,330], "back":[], "labels":["sp3", ...]}
  ],
  DIAGRAM KINDS (fill ONLY the fields that the chosen kind uses):
    flow        -> nodes (3-8 ordered stages: processes, methods, derivations, timelines)
    cycle       -> nodes (3-8 stages that repeat, e.g. water cycle, Krebs cycle)
    hub         -> center + nodes (3-8 branches: classification, concept map, "types of ...")
    energy      -> columns + transitions (orbital-in-box / energy-level diagrams; "boxes" = electrons per orbital 0,1,2)
    molecule3d  -> shape + center + substituents + angle_label (molecular geometry with wedge/dash bonds)
    lobes       -> angles + labels + center (hybrid-orbital lobe pictures; "back" = indexes drawn behind the page)
  "worked_examples": [
      {"question":"representative syllabus-style question","answer":"worked method/answer in concise steps"},
      ...
  ],
  "common_mistakes": ["mistake + correction", ...],
  "exam_tips": ["what to remember for marks / command words / calculation method", ...],
  "vocabulary": [{"term":"term","meaning":"precise student-friendly definition"}, ...],
  "quick_facts": ["high-value fact", ...],
  "exam_keywords": ["keyword or phrase", ...],
  "memory_hook": "short memorable sentence or mnemonic",
  "sources": ["URL or source title used in the research", ...],
  "footer_line": "short motivating study takeaway",
  "reference_outline": [
      {"number": 1, "title": "What is the topic?", "content": "clear student-friendly explanation", "bullets": []}
  ],
  "comparison_tables": [
      {"title": "Topic comparison", "columns": ["Aspect", "Topic", "Related concept"], "rows": [["...", "...", "..."]] }
  ],
  "summary_points": ["accurate high-value summary point", ...],
  "key_points_to_remember": ["short recall point", ...]
}

STRICT CONTENT RULES:
1. Research the requested topic before writing the notes. The supplied RESEARCH PACKET is
   the factual evidence to use. Resolve conflicts using this authority order: official
   syllabus/specification or examination board > official textbook/university/government source
   > reputable educational source. Never invent a syllabus requirement, fact, formula, unit,
   diagram label, mark-scheme rule, or citation just to fill a box. Omit uncertain claims.
2. The selected syllabus is a HARD SCOPE FILTER. Explain the topic at the level expected by
   that syllabus. Include examinable definitions, laws, formulae, mechanisms, diagrams that
   should be understood, calculations/methods, applications and common exam traps when they
   are relevant. Do not wander into advanced university detail unless it directly helps the
   selected syllabus outcome.
3. Completeness beats decoration. Cover all major sub-concepts that are genuinely part of the
   requested topic and syllabus. Do not stop after a few generic bullets. Notes must be strong
   enough for a student to use them to construct a high-mark, exam-standard answer to both
   direct theory questions and application/problem questions on the requested topic.
4. Teach, do not merely list. For every major process, mechanism, derivation or method, explain
   WHAT happens, WHY it happens, and the important condition/rule that controls it.
5. Equations must be exact. Define important symbols and units where applicable. Do not create
   a fake equation for a descriptive topic.
6. Worked examples must use realistic syllabus-level questions and show enough method to study
   from them. If a worked example is not meaningful for the topic, return an empty list.
7. Common mistakes must be specific to this topic, not generic advice.
8. Write explanations in exam-ready language: define the term, state the principle/rule, explain
   the mechanism or reasoning, and include conditions, units, evidence, examples, or applications
   where relevant. For likely long-answer questions, make the notes sufficient to build a complete
   mark-scheme-quality response.
9. `topic_coverage` is a coverage checklist, not learning objectives. Do not write phrases such
   as "the candidate should be able to", "learning objective", "you will learn", or generic
   outcome statements anywhere in the notes. Name actual examinable content instead.
10. ALWAYS add 2-3 detailed 2D study diagrams (use the `kind` field so they are DRAWN with arrows and shapes, not just listed). For chemistry bonding/orbital topics use `energy` (orbital-in-box), `lobes` and `molecule3d`; for processes use `flow`; for repeating systems use `cycle`; for classifications use `hub`. ALWAYS add at least 1 detailed 2D study diagram. A diagram is mandatory for every generated notes package, including abstract or descriptive topics. Choose the most useful topic-grounded visual: a process flow, labelled structure, concept map, comparison, cycle, timeline, cause-and-effect chain, hierarchy, or equation-to-meaning map. Use 1-3 diagrams when additional visuals genuinely add distinct information. Every label, relationship, and caption must be supported by the research packet. Never use a generic decorative diagram and never repeat the same information in multiple diagrams.
11. Do not add a generic "what you know", "check yourself", quiz, or checkpoint section. The notes
   should focus on teaching the examinable content rather than testing the student.
12. Keep each item compact enough for a notebook page, but allow MORE items when needed for
   completeness. Prefer 5-9 items in most lists; process_steps may use 4-10 steps.
13. If research sources disagree, use the most authoritative evidence and state the nuance in
   the relevant note rather than silently guessing.
14. The PDF should read naturally as if a brilliant student made the page by hand: short
   phrases, clear wording, visual hierarchy, no giant walls of text.
15. Return valid JSON only. No markdown fences, no commentary.
"""



# ------------------------------------------------------------------
# V2036 ROBUST NOTES AI LAYER
# ------------------------------------------------------------------
# Why this exists: Gemini 3.x Flash models "think" by default and thinking
# tokens are counted against max_output_tokens. The old call capped output at
# 9000 tokens, so a big JSON study-notes object was regularly cut off mid-way,
# failed to parse, and FRIDAY fell straight to the empty placeholder sheet.
# A stale attached-file handle had the same effect because BOTH retries reused
# it. The new layer retries with progressively simpler requests, repairs
# truncated JSON, and records exactly WHY it failed.
# ------------------------------------------------------------------
# V2037 SHARED GEMINI CALL LAYER (error classification + model self-healing)
# ------------------------------------------------------------------
# Every AI feature (notes, document planner, screen vision) failed with the same
# vague "AI link didn't answer" because the real error was thrown away. This
# layer keeps the real reason, and when the configured model name is what the API
# rejects it transparently switches to a model that works and remembers it.
_GEMINI_FALLBACK_MODELS = [m.strip() for m in os.getenv(
    "FRIDAY_GEMINI_FALLBACK_MODELS",
    "gemini-3.1-flash-lite,gemini-3.8-flash,gemini-flash-latest,gemini-3.7-flash,gemini-3.6-flash,gemini-3.5-flash,gemini-2.5-flash,gemini-flash-lite-latest,gemini-2.5-flash-lite,gemini-2.0-flash"
).split(",") if m.strip()]
_GEMINI_LAST_ERROR = ""          # raw text of the most recent Gemini failure
_GEMINI_LAST_ERROR_KIND = ""     # key | model | quota | busy | network | config | other


def _classify_gemini_error(error):
    """-> (kind, short spoken explanation). Never raises."""
    text = f"{type(error).__name__}: {error}"
    low = text.lower()
    if any(k in low for k in ("api key not valid", "api_key_invalid", "invalid api key", "api key expired", "unauthenticated", "401")):
        return "key", "Google is rejecting my API key"
    if any(k in low for k in ("permission_denied", "403", "billing", "not enabled", "has not been used")):
        return "key", "Google is refusing my key's permissions"
    if any(k in low for k in ("resource_exhausted", "429", "quota", "rate limit", "rate_limit", "too many requests")):
        return "quota", "my Gemini quota is exhausted for the moment"
    if any(k in low for k in ("not_found", "404", "is not found", "not supported for generatecontent", "unknown model", "model not found")):
        return "model", f"Google doesn't recognise the model name {GEMINI_MODEL}"
    if any(k in low for k in ("503", "unavailable", "overloaded", "500", "internal", "deadline", "timeout", "timed out")):
        return "busy", "Google's servers are busy or slow"
    if any(k in low for k in ("connecterror", "connection", "getaddrinfo", "name resolution", "network", "ssl", "socket", "unreachable", "10054", "10060", "10061")):
        return "network", "I can't reach Google - the internet connection is failing or blocked"
    if any(k in low for k in ("invalid_argument", "400", "thinking", "unexpected keyword", "validation error", "unsupported")):
        return "config", "Google rejected one of my request settings"
    return "other", "Google's reply couldn't be used"


def _record_gemini_error(error):
    global _GEMINI_LAST_ERROR, _GEMINI_LAST_ERROR_KIND
    _GEMINI_LAST_ERROR = f"{type(error).__name__}: {str(error)[:400]}"
    _GEMINI_LAST_ERROR_KIND = _classify_gemini_error(error)[0]
    print(f"GEMINI_ERROR[{_GEMINI_LAST_ERROR_KIND}]: {_GEMINI_LAST_ERROR}", flush=True)


def _response_text(response):
    """Text of a Gemini response even when .text is empty (safety block, MAX_TOKENS, thought parts)."""
    try:
        text = getattr(response, "text", None)
        if text:
            return text
    except Exception:
        pass
    try:
        pieces = []
        for cand in (getattr(response, "candidates", None) or []):
            for part in (getattr(getattr(cand, "content", None), "parts", None) or []):
                if getattr(part, "thought", False):
                    continue
                if getattr(part, "text", None):
                    pieces.append(part.text)
        return "".join(pieces)
    except Exception:
        return ""


def _gemini_generate(contents, config=None, model=None, retries=1):
    """One Gemini call with a clear failure record and model self-healing.

    * transient errors (busy / quota burst) are retried after a short pause;
    * if Google says the MODEL is unknown, the fallback models are tried and the
      first one that works becomes GEMINI_MODEL for the rest of the session.
    Raises the last error when nothing works (its details are in _GEMINI_LAST_ERROR).
    """
    global GEMINI_MODEL
    _ensure_gemini_client()
    if client is None:
        raise RuntimeError(f"AI brain not available ({GEMINI_STATUS_REASON})")
    primary = model or GEMINI_MODEL
    candidates = [primary] + [m for m in _GEMINI_FALLBACK_MODELS if m != primary]
    last = None
    for index, name in enumerate(candidates):
        attempt = 0
        while True:
            try:
                kwargs = {"model": name, "contents": contents}
                if config is not None:
                    kwargs["config"] = config
                response = client.models.generate_content(**kwargs)
                if index > 0 and model is None:
                    print(f"GEMINI_MODEL_HEALED: '{primary}' was rejected, now using '{name}'", flush=True)
                    GEMINI_MODEL = name
                return response
            except Exception as error:
                last = error
                _record_gemini_error(error)
                kind = _GEMINI_LAST_ERROR_KIND
                if kind in ("busy", "quota", "network") and attempt < retries:
                    attempt += 1
                    time.sleep(0.45 * attempt)
                    continue
                break
        if _GEMINI_LAST_ERROR_KIND != "model":
            break            # only a rejected MODEL justifies trying another model
    raise last


# ============================================================
# V2.2.4 CONNECTION HARDENING
# Real "Save & Test", truthful error reasons, automatic recovery.
# Nothing above this block changes behaviour; it only adds reporting
# and self-healing around the existing Gemini calls.
# ============================================================
_API_HEALTH = {"state": "unknown", "kind": "", "message": "", "model": ""}
_API_DIAG_LOCK = threading.Lock()
_GENAI_AUTOINSTALL_TRIED = False
_WATCHDOG_STARTED = False
_WATCHDOG_INTERVAL_SECONDS = 45


def _emit_api_status(state, kind="", message="", tested=False):
    """Tell the UI (via main.js) what the real connection state is."""
    _API_HEALTH.update({"state": state, "kind": kind, "message": message, "model": GEMINI_MODEL})
    payload = {"state": state, "kind": kind, "message": message, "model": GEMINI_MODEL, "tested": bool(tested)}
    try:
        print("FRIDAY_API_STATUS::" + base64.b64encode(json.dumps(payload).encode("utf-8")).decode("ascii"), flush=True)
    except Exception:
        pass


def _friendly_gemini_problem(kind, error=None):
    detail = ""
    if error is not None:
        detail = str(error).replace("\n", " ")[:160]
    return {
        "key": "Google rejected the API key. Paste a Gemini key from Google AI Studio (aistudio.google.com/apikey), copied in full, then press Save & Test.",
        "quota": "The key is valid but its Gemini quota is used up for now. FRIDAY will reconnect automatically when it resets.",
        "model": "None of the Gemini models FRIDAY tried are available to this key. Open Settings > AI and enter a model your key supports.",
        "busy": "Google's Gemini servers are busy. FRIDAY keeps retrying automatically.",
        "network": "FRIDAY cannot reach Google. Check the internet connection, VPN, firewall or antivirus; it reconnects automatically.",
        "config": "Google rejected a request setting: " + detail,
    }.get(kind, "Gemini returned an unexpected error: " + detail)


def _spoken_gemini_problem(kind):
    return {
        "key": "Google is rejecting my API key, sir. Please re-enter it in Settings, under AI, and press Save and Test.",
        "quota": "My Gemini quota is used up for the moment, sir. I will reconnect automatically when it resets.",
        "model": "The Gemini model I am set to is not available to my key, sir. Please check the model in Settings, under AI.",
        "busy": "Google's servers are busy right now, sir. I'll keep retrying in the background.",
        "network": "I can't reach Google right now, sir. I'll reconnect automatically as soon as the internet is back.",
        "config": "Google rejected one of my request settings, sir. Please check the model in Settings, under AI.",
    }.get(kind, "I hit an unexpected Gemini error, sir. I'll keep retrying in the background.")


def _ensure_genai_sdk():
    """If the google-genai package is missing from this Python, install it once."""
    global _GENAI_AUTOINSTALL_TRIED
    try:
        if importlib.util.find_spec("google.genai") is not None:
            return True
    except Exception:
        pass
    if _GENAI_AUTOINSTALL_TRIED:
        return False
    _GENAI_AUTOINSTALL_TRIED = True
    try:
        print("GEMINI_STATUS::INSTALLING_SDK", flush=True)
        subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "google-genai"],
                       timeout=300, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        importlib.invalidate_caches()
        return importlib.util.find_spec("google.genai") is not None
    except Exception as install_error:
        print("google-genai auto-install failed:", install_error, flush=True)
        return False


def _discover_working_model():
    """Ask Google which models this key can use and return the first that answers."""
    try:
        names = []
        for m in client.models.list():
            actions = list(getattr(m, "supported_actions", None) or getattr(m, "supported_generation_methods", None) or [])
            name = str(getattr(m, "name", "") or "").replace("models/", "")
            if not name.startswith("gemini") or (actions and "generateContent" not in actions):
                continue
            if any(x in name for x in ("embedding", "image", "tts", "live", "audio", "robotics", "computer-use", "vision", "imagen", "veo", "learnlm", "aqa")):
                continue
            names.append(name)
        names.sort(key=lambda n: (0 if ("flash" in n and "lite" not in n) else 1 if "flash" in n else 2, n))
        for name in names[:6]:
            try:
                client.models.generate_content(model=name, contents="Reply with the single word: ok")
                return name
            except Exception:
                continue
    except Exception as list_error:
        print("Gemini model discovery failed:", list_error, flush=True)
    return ""


def _diagnose_gemini(tested=True):
    """Live check of key + model + network. Emits the real result to the UI."""
    global GEMINI_MODEL
    with _API_DIAG_LOCK:
        key, source = _resolve_gemini_key()
        if not key:
            _emit_api_status("no_key", "no_key", "No API key saved yet. Paste one and press Save & Test.", tested)
            return False
        if not _ensure_genai_sdk():
            _emit_api_status("other", "sdk", "The google-genai package is missing and could not be installed automatically. Reinstall FRIDAY or run INSTALL_FRIDAY_WINDOWS.bat.", tested)
            return False
        try:
            _ensure_gemini_client()
            if client is None:
                _emit_api_status("other", "init", "FRIDAY could not start its Gemini client: " + str(GEMINI_STATUS_REASON)[:200], tested)
                return False
            _gemini_generate("Reply with the single word: ok", retries=2)
            _emit_api_status("ready", "", f"Connected to Gemini (model {GEMINI_MODEL}).", tested)
            return True
        except Exception as error:
            kind = _classify_gemini_error(error)[0]
            if kind == "model":
                found = _discover_working_model()
                if found:
                    GEMINI_MODEL = found
                    print(f"GEMINI_MODEL_DISCOVERED: {found}", flush=True)
                    _emit_api_status("ready", "", f"Connected to Gemini (model {GEMINI_MODEL}).", tested)
                    return True
            _emit_api_status(kind if kind in ("key", "quota", "model", "busy", "network", "config") else "other",
                             kind, _friendly_gemini_problem(kind, error), tested)
            return False


def _start_gemini_watchdog():
    """Background self-healing: while the connection is down, quietly re-test it."""
    global _WATCHDOG_STARTED
    if _WATCHDOG_STARTED:
        return
    _WATCHDOG_STARTED = True

    def _loop():
        while True:
            time.sleep(_WATCHDOG_INTERVAL_SECONDS)
            try:
                state = _API_HEALTH.get("state", "unknown")
                if state in ("ready", "no_key", "key"):
                    if state == "no_key" and _resolve_gemini_key()[0]:
                        _diagnose_gemini(tested=False)
                    continue
                _diagnose_gemini(tested=False)
            except Exception as watchdog_error:
                print("Gemini watchdog (ignored):", watchdog_error, flush=True)

    threading.Thread(target=_loop, name="FridayGeminiWatchdog", daemon=True).start()


_NOTES_LAST_FAILURE = ""
_NOTES_LAST_TIER = ""

_NOTES_REQUIRED_KEYS = ("chapter_title", "what_is", "topic_coverage", "key_points",
                        "process_steps", "exam_tips", "vocabulary")


def _notes_generation_config(json_mode=True, max_tokens=32000, low_thinking=True):
    """GenerateContentConfig with a generous output budget and light thinking."""
    from google.genai import types as _t
    kwargs = {"max_output_tokens": max_tokens, "temperature": 0.25}
    if json_mode:
        kwargs["response_mime_type"] = "application/json"
    if low_thinking:
        try:
            return _t.GenerateContentConfig(thinking_config=_t.ThinkingConfig(thinking_level="low"), **kwargs)
        except Exception:
            pass  # older SDK without thinking_level -> plain config below
    return _t.GenerateContentConfig(**kwargs)


def _salvage_truncated_json(raw):
    """Recover a usable dict from JSON that was cut off (e.g. by a token limit)."""
    if not raw:
        return None
    text = raw.strip()
    if text.startswith("```"):
        text = re.sub(r"^```[a-zA-Z]*\n?", "", text)
        text = re.sub(r"```\s*$", "", text).strip()
    start = text.find("{")
    if start == -1:
        return None
    text = text[start:]
    stack, in_str, esc, snaps = [], False, False, []
    for i, ch in enumerate(text):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in "{[":
            stack.append(ch)
        elif ch in "}]":
            if stack:
                stack.pop()
            snaps.append((i + 1, list(stack)))
        elif ch == ",":
            snaps.append((i, list(stack)))
    for cut, open_stack in reversed(snaps[-60:]):
        candidate = text[:cut] + "".join("}" if b == "{" else "]" for b in reversed(open_stack))
        try:
            data = json.loads(candidate)
            if isinstance(data, dict):
                return data
        except Exception:
            continue
    return None


def _notes_richness(data):
    """How many independent study sections contain real content (max 11)."""
    if not isinstance(data, dict):
        return 0
    score = 1 if len(str(data.get("what_is") or "")) >= 80 else 0
    for key, minimum in (("topic_coverage", 3), ("key_points", 4), ("process_steps", 3),
                         ("key_ideas", 3), ("vocabulary", 4), ("exam_tips", 2),
                         ("worked_examples", 1), ("common_mistakes", 2), ("reference_outline", 3)):
        value = data.get(key)
        if isinstance(value, list) and len([x for x in value if x]) >= minimum:
            score += 1
    diagrams = data.get("diagrams")
    if isinstance(diagrams, list) and any(isinstance(d, dict) and (d.get("nodes") or d.get("columns") or d.get("angles") or d.get("shape")) for d in diagrams):
        score += 1
    return score


def _complete_notes_dict(data):
    """Fill missing keys with safe empties instead of throwing the whole result away."""
    if not isinstance(data, dict):
        return None
    for key in _NOTES_REQUIRED_KEYS:
        if key not in data or data[key] is None:
            data[key] = "" if key in ("chapter_title", "what_is") else []
    for key in ("requirements", "key_ideas", "diagrams", "worked_examples", "common_mistakes",
                "quick_facts", "exam_keywords", "sources", "reference_outline",
                "comparison_tables", "summary_points", "key_points_to_remember"):
        if not isinstance(data.get(key), list):
            data[key] = []
    return data


def _ai_structure_notes(topic, subject_label, context_text, uploaded_files=None, files_required=False):
    """Use Gemini as the content/teaching layer after research has been gathered.

    Tries several progressively simpler requests (see module comment above) and
    returns a notes dict, or None with `_NOTES_LAST_FAILURE` explaining why.
    `files_required=True` (scanned-photo notes) forbids tiers that drop the files.
    """
    global _NOTES_LAST_FAILURE, _NOTES_LAST_TIER
    _NOTES_LAST_FAILURE, _NOTES_LAST_TIER = "", ""
    _ensure_gemini_client()
    if client is None:
        _NOTES_LAST_FAILURE = f"AI brain not available ({GEMINI_STATUS_REASON})"
        return None

    files = list(uploaded_files or [])
    full_prompt = (
        "You are FRIDAY's senior study-notes author. First reason over the research packet "
        "and syllabus scope, then write a complete set of study notes for the learner.\n\n"
        f"TOPIC: {topic}\nSELECTED SYLLABUS: {subject_label}\n\n"
        f"RESEARCH PACKET:\n{(context_text or '')[:30000]}\n\n"
        f"{_NOTES_JSON_SCHEMA_PROMPT}"
    )
    syllabus_only = (context_text or "").split("RESEARCH STATUS:")[0][:3000]
    knowledge_prompt = (
        "You are FRIDAY's senior study-notes author. No web research is available right now, so write the "
        "notes from your own verified subject knowledge at the level of the selected syllabus. Include only "
        "facts, formulae, definitions and diagram labels you are certain are correct; leave out anything uncertain. "
        "Be COMPLETE and specific: real definitions, mechanisms, worked examples, common mistakes and exam wording.\n\n"
        f"TOPIC: {topic}\nSELECTED SYLLABUS: {subject_label}\n\n{syllabus_only}\n\n{_NOTES_JSON_SCHEMA_PROMPT}"
    )

    # Tier list: richest request first, ending with the EXACT plain call the rest of
    # FRIDAY already uses successfully (no config at all) so a rejected setting
    # (thinking level, token cap, JSON mode) can never block the notes again.
    tiers = [
        # name,         files,  prompt,           config-kind
        ("full",         True,   full_prompt,      "full"),
        ("json-only",    True,   full_prompt,      "json"),
        ("plain",        False, full_prompt,      "none"),
    ]
    if files_required:
        tiers = [(n, True, p, c) for (n, _f, p, c) in tiers]
    else:
        tiers.append(("own-knowledge", False, knowledge_prompt, "none"))

    best, best_score = None, 0
    seen_prompts = set()
    for index, (name, use_files, prompt, cfg_kind) in enumerate(tiers):
        if not use_files and not files and name == "json-only":
            continue
        contents = (files if use_files else []) + [prompt]
        signature = (name if use_files else "nofiles", cfg_kind, len(prompt))
        if signature in seen_prompts:
            continue
        seen_prompts.add(signature)
        try:
            emit_progress(56 + min(index, 4), f"Structuring study content ({name})", task=f"Study notes: {topic}")
        except Exception:
            pass
        try:
            if cfg_kind == "full":
                config = _notes_generation_config(json_mode=True, max_tokens=16000, low_thinking=True)
            elif cfg_kind == "json":
                from google.genai import types as _gt
                config = _gt.GenerateContentConfig(response_mime_type="application/json")
            else:
                config = None
            response = _gemini_generate(contents, config=config)
        except Exception as error:
            kind, why = _classify_gemini_error(error)
            _NOTES_LAST_FAILURE = f"{kind}: {why} [{name}: {type(error).__name__}: {str(error)[:200]}]"
            print("Notes AI tier failed:", _NOTES_LAST_FAILURE)
            if kind in ("key", "quota", "network"):
                break        # retrying with different settings cannot fix these
            continue
        raw = _response_text(response)
        data = _parse_diagram_json(raw)
        if not isinstance(data, dict):
            data = _salvage_truncated_json(raw)
            if isinstance(data, dict):
                print(f"Notes AI tier {name}: recovered truncated JSON")
        if not isinstance(data, dict):
            _NOTES_LAST_FAILURE = f"other: model returned no usable JSON [{name}: {len(raw)} chars]"
            print("Notes AI tier failed:", _NOTES_LAST_FAILURE)
            continue
        data = _complete_notes_dict(data)
        score = _notes_richness(data)
        if score > best_score:
            best, best_score, _NOTES_LAST_TIER = data, score, name
        if score >= 6:
            break
        _NOTES_LAST_FAILURE = f"other: content too thin [{name}: score {score}/11]"
        print("Notes AI tier thin:", _NOTES_LAST_FAILURE)

    # Real (if slightly thin) AI notes beat any template, so accept a modest score.
    if best is not None and best_score >= 3:
        _NOTES_LAST_FAILURE = ""
        return best
    if best is None:
        print("Notes AI structuring error:", _NOTES_LAST_FAILURE or "unknown")
    return None


def _notes_extractive_sections(topic, subject_label, research_text, anchors):
    """Last-resort notes built ONLY from text the research step really fetched."""
    blocks = re.split(r"\n\s*SOURCE \d+: ", research_text or "")[1:]
    if not blocks:
        return None
    stop = set("the and for with that this from have which their there about would could should these those into than then them they what when where while also such been being were will your more most some other only over under between through using used uses use are was but not can may how why who its our out any one two per via".split())
    tokens = [t for t in re.findall(r"[a-z][a-z0-9\-]{3,}", topic.lower()) if t not in stop]
    sentences, seen = [], set()
    for block in blocks:
        body = block.split("\n", 1)[1] if "\n" in block else block
        for sent in re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", body)):
            sent = sent.strip()
            if not (45 <= len(sent) <= 260) or sent.lower() in seen:
                continue
            letters = sum(c.isalpha() for c in sent)
            if letters / max(1, len(sent)) < 0.7 or "http" in sent or "cookie" in sent.lower():
                continue
            seen.add(sent.lower())
            score = sum(1 for t in tokens if t in sent.lower())
            if score:
                sentences.append((score, sent))
    if len(sentences) < 4:
        return None
    sentences.sort(key=lambda x: -x[0])
    chosen = [s for _, s in sentences[:12]]
    words = collections.Counter(w for s in chosen for w in re.findall(r"[a-z]{5,}", s.lower()) if w not in stop and w not in tokens)
    nodes = []
    for word, _count in words.most_common(6):
        detail = next((s for s in chosen if word in s.lower()), "")
        nodes.append({"label": word.capitalize(), "detail": detail[:120]})
    diagrams = [{"kind": "hub", "center": topic.title()[:40], "title": f"{topic.title()} - key ideas found in the sources",
                 "caption": "Built only from the pages FRIDAY actually read; check against your syllabus.", "nodes": nodes}] if len(nodes) >= 3 else []
    return {
        "chapter_title": topic.title(),
        "subject_line": f"{subject_label} - {topic}",
        "what_is": " ".join(chosen[:2]),
        "topic_coverage": anchors[:8] or [f"Core ideas of {topic} as found in the researched sources"],
        "key_points": chosen[2:10],
        "requirements": [], "process_steps": [], "key_ideas": [],
        "worked_examples": [], "common_mistakes": [],
        "exam_tips": ["These notes were assembled from web sources without AI structuring - confirm each point against your syllabus."],
        "diagrams": diagrams, "vocabulary": [], "quick_facts": chosen[10:12], "exam_keywords": [t for t in tokens][:8],
        "memory_hook": "", "sources": [], "footer_line": "Research digest - regenerate when the AI brain is online for full notes",
    }


def _notes_failure_explanation(why):
    """(cause, what-to-do) sentences for the spoken message, from _NOTES_LAST_FAILURE."""
    why = (why or "").strip()
    if why.startswith("AI brain not available"):
        return ("my AI brain isn't connected",
                "Paste your Gemini key into GEMINI_API_KEY_INLINE_FALLBACK in friday_backend.py and ask me again.")
    kind = why.split(":", 1)[0] if ":" in why else "other"
    detail = why.split(":", 1)[1].split(" [", 1)[0].strip() if ":" in why else ""
    fixes = {
        "key": "Please check the key in GEMINI_API_KEY_INLINE_FALLBACK.",
        "quota": "Give it a few minutes, or use a key with more quota, then ask again.",
        "model": "Set FRIDAY_GEMINI_MODEL to a model your key supports, then ask again.",
        "network": "Check the internet connection and ask again.",
        "busy": "Ask me again in a minute.",
        "config": "The exact error is in the console window; I'll need it to fix that.",
    }
    if detail.startswith("model returned"):
        detail = "my AI's reply came back unusable"
    elif detail.startswith("content too thin"):
        detail = "my AI's reply was too thin to build notes from"
    return (detail or "my AI link didn't answer properly", fixes.get(kind, "Ask me again in a moment; the exact error is in the console window."))


def _notes_fallback_sections(topic, subject, syllabus_name, syllabus_year, syllabus_anchors, research_text):
    """Best available content when the AI step failed. Returns (sections, kind)."""
    label = f"{syllabus_name} {syllabus_year}".strip()
    # Curated offline packs: friday_notes_knowledge (hybridisation family, full depth) first,
    # then friday_notes_library (adds e.g. Newton's laws). Either one gives complete notes.
    for _module_name, _finder in (("friday_notes_knowledge", lambda m: m.lookup(topic, syllabus_name, syllabus_year)),
                                  ("friday_notes_library", lambda m: m.find_entry(topic, label))):
        try:
            _mod = __import__(_module_name)
            entry = _finder(_mod)
            if entry:
                return entry, "library"
        except Exception as error:
            print(f"Notes library lookup failed ({_module_name}):", error)
    try:
        digest = _notes_extractive_sections(topic, label, research_text, syllabus_anchors)
        if digest:
            return digest, "research-digest"
    except Exception as error:
        print("Notes research digest failed:", error)
    anchors = syllabus_anchors[:8]
    return {
        "chapter_title": topic.title(),
        "subject_line": f"{label} - {topic}",
        "what_is": f"{topic.title()} is a syllabus topic in {syllabus_name}. This sheet only contains the syllabus outline because my AI brain and research link were both unreachable - regenerate it once I'm back online for full notes and diagrams.",
        "topic_coverage": anchors or [f"Core concepts and exam applications of {topic}"],
        "key_points": anchors[:6], "requirements": [], "process_steps": [], "key_ideas": [],
        "worked_examples": [], "common_mistakes": [],
        "exam_tips": ["Regenerate these notes when the AI brain is connected - this is only an outline."],
        "diagrams": [], "vocabulary": [], "quick_facts": [], "exam_keywords": [],
        "memory_hook": "", "sources": [], "footer_line": "Outline only - regenerate for full notes",
    }, "outline"




def _gather_notes_research(topic, subject_label):
    """Deep, topic-specific research packet for the notes AI.

    We deliberately research the topic from several angles instead of feeding Gemini one
    short search-answer: syllabus scope, core theory, and exam/application angle. Sources are
    de-duplicated by URL and capped so the model receives a dense but manageable packet.
    """
    queries = [
        f"{topic} {subject_label} official syllabus specification content",
        f"{topic} {subject_label} detailed explanation formula mechanism",
        f"{topic} {subject_label} exam questions common mistakes revision",
    ]
    all_sources = []
    seen = set()
    try:
        for query_index, query in enumerate(queries, 1):
            try:
                emit_progress(18 + query_index * 9, f"Research pass {query_index}/3: {query[:70]}", task=f"Study notes: {topic}")
                # V2045 FIX: own breaker (see the matching comment in
                # _gather_explanation_research above) + higher tolerance +
                # more attempts, instead of sharing "research.generic".
                pairs = run_resilient(
                    "research.notes",
                    lambda q=query: friday_web_research.gather_sources(q, depth=5, search_pool=10, use_cache=True),
                    attempts=4, failure_threshold=10, reset_after=6.0,
                )
            except Exception as error:
                print("Notes research query skipped:", query, error)
                pairs = []
            for url, text in pairs:
                if url in seen:
                    continue
                seen.add(url)
                all_sources.append((url, text))
                if len(all_sources) >= 12:
                    break
            if len(all_sources) >= 12:
                break
    except Exception as error:
        print("Notes research error:", error)

    if not all_sources:
        return (
            f"RESEARCH STATUS: Live web research returned no readable pages.\n"
            f"TOPIC: {topic}\nSUBJECT/SYLLABUS: {subject_label}\n"
            "Use any attached official syllabus/study files as the authority and be explicit "
            "if a detail cannot be verified."
        )

    blocks = [
        f"RESEARCH STATUS: {len(all_sources)} readable web sources gathered.\n",
        f"TOPIC: {topic}\nSUBJECT/SYLLABUS: {subject_label}\n",
    ]
    for i, (url, text) in enumerate(all_sources, 1):
        blocks.append(f"SOURCE {i}: {url}\n{text[:6500]}")
    return "\n\n".join(blocks)



_NOTES_QUERY_PATTERNS = [
    re.compile(r"^(?:what notes do i have|show my notes|list my notes|read my notes|"
               r"read out my notes|what are my notes|do i have any notes)"
               r"(?:\s+(?:on|for|about)\s+(.+))?$"),
    re.compile(r"^(?:do i have|have i got|got any)\s+notes\s+(?:on|for|about)\s+(.+)$"),
    re.compile(r"^(?:show|list|read)\s+(?:me\s+)?(?:my\s+)?notes\s+(?:on|for|about)\s+(.+)$"),
]


def try_handle_notes_query(needle):
    """Answers 'what notes do I have (on X)?' from BOTH stores this
    backend actually has: quick_notes.json (plain text notes synced
    from the Notes tab's Save Note button -- see 'save quick note::'
    above) and notes_index.json (the AI Notes Generator's PDFs -- see
    register_note()). Always speaks something concrete rather than a
    vague "I don't have access" -- either the real matches, or an
    honest, still-helpful "nothing yet, here's how to make some"."""
    needle_l = (needle or "").strip().lower()

    quick = friday_notes_engine.list_quick_notes()
    pdfs = friday_notes_engine.list_notes()
    if needle_l:
        quick = [n for n in quick if needle_l in n.get("text", "").lower() or needle_l in n.get("subject", "").lower()]
        pdfs = [n for n in pdfs if needle_l in n.get("topic", "").lower() or needle_l in n.get("subject", "").lower()]

    if not quick and not pdfs:
        if needle_l:
            speak(f"I don't have any notes saved on {needle} yet. Say 'create notes on {needle}' and I'll design a PDF, or save a quick note from the Notes tab.")
        else:
            speak("You don't have any notes saved yet. Say something like 'create notes on the water cycle', or save a quick note from the Notes tab.")
        return True

    parts = []
    for n in sorted(pdfs, key=lambda x: x.get("created", ""), reverse=True)[:5]:
        parts.append(f"a generated PDF on {n.get('topic', 'Untitled')} ({n.get('subject', 'general')})")
    for n in sorted(quick, key=lambda x: x.get("created", ""), reverse=True)[:5]:
        snippet = n.get("text", "")
        snippet = snippet if len(snippet) <= 60 else snippet[:57] + "..."
        parts.append(f"a note on {n.get('subject', 'general')} saying \"{snippet}\"")

    speak("Here's what I have: " + "; ".join(parts) + ".")
    return True


def study_generate_notes(subject, topic, attached_path=""):
    """Research -> syllabus scope -> Gemini teaching/structuring -> notebook-style PDF."""
    topic = (topic or "").strip()
    subject = (subject or "general").strip()
    if not topic:
        speak("Tell me the topic you want notes on, for example 'create notes on the water cycle'.")
        return True

    # The Notes tab sends short keys (chem / phys / math / cs / general); map them to the
    # syllabus codes so notes really are checked against the right syllabus.
    _ui_subject_codes = {"chem": "9701", "chemistry": "9701", "phys": "9702", "physics": "9702",
                         "math": "9709", "maths": "9709", "mathematics": "9709", "cs": "9618",
                         "computer science": "9618"}
    syllabus_key = subject if subject in SYLLABUS_MAP else _ui_subject_codes.get(subject.lower(), subject)
    syllabus = SYLLABUS_MAP.get(syllabus_key, {})
    syllabus_name = syllabus.get("name", "the general syllabus" if subject.lower() in ("general", "") else subject)
    syllabus_year = syllabus.get("year", "")
    syllabus_anchors = syllabus.get("anchors", [])
    syllabus_context = (
        f"SELECTED SYLLABUS: {syllabus_name} {syllabus_year}\n"
        f"SYLLABUS ANCHORS: {', '.join(syllabus_anchors)}\n"
        "Use these anchors as scope guidance; an attached official syllabus PDF overrides this high-level map."
    )

    task_label = f"Study notes: {topic}"
    emit_progress(3, "Request understood — preparing research", task=task_label)
    speak(f"Give me a moment — I'm researching {topic}, checking it against {'your ' if syllabus else ''}{syllabus_name}, and designing complete study notes.")
    log_event(f"Researching syllabus-aware notes: {topic}", kind="research")
    emit_progress(8, "Checking syllabus scope and attached study material", task=task_label)

    uploaded_files = []
    attached_text_note = ""
    _ensure_gemini_client()

    # User-supplied file for this command.
    if attached_path and client is not None:
        try:
            path = Path(attached_path.strip().strip('"').strip("'")).expanduser()
            if path.exists() and path.is_file():
                uploaded_files.append(client.files.upload(file=str(path)))
                attached_text_note = f" and the attached file {path.name}"
        except Exception as error:
            print("Notes attachment upload error:", error)

    # Reuse official syllabus/study PDFs already attached to Study Mode.
    if client is not None:
        for item in study_state.get("pdfs", []):
            try:
                uploaded = client.files.get(name=item["name"])
                # Avoid duplicating the exact file supplied above when names match.
                if not any(getattr(x, "name", None) == getattr(uploaded, "name", None) for x in uploaded_files):
                    uploaded_files.append(uploaded)
            except Exception as error:
                print("Could not retrieve attached study file for notes:", error)

    emit_progress(18, "Starting topic-specific web research", task=task_label)
    research_text = _gather_notes_research(topic, f"{syllabus_name} {syllabus_year}")
    emit_progress(48, "Research collection finished — checking evidence", task=task_label)
    full_context = syllabus_context + "\n\n" + research_text
    emit_progress(56, "Building structured study content with AI", task=task_label)
    sections = _ai_structure_notes(topic, syllabus_name, full_context, uploaded_files=uploaded_files)

    notes_mode = "ai"
    if sections:
        emit_progress(72, "Study content validated — arranging the notebook template", task=task_label)
    if not sections:
        # V2036: never hand over a hollow template, and never hide WHY the AI step failed.
        why = (_NOTES_LAST_FAILURE or "").strip()
        sections, fallback_kind = _notes_fallback_sections(
            topic, subject, syllabus_name, syllabus_year, syllabus_anchors, research_text)
        notes_mode = fallback_kind
        if why:
            print("Notes fallback reason:", why)
        cause, fix = _notes_failure_explanation(why)
        if fallback_kind == "library":
            speak(f"I'm afraid {cause}, sir, but {topic} is in my own reference library, "
                  "so the notes will still be complete, diagrams included.")
        elif fallback_kind == "research-digest":
            speak(f"I'm afraid {cause}, sir. I've assembled a digest from the pages I did manage to read. {fix}")
        else:
            speak(f"I'm afraid {cause}, sir, and I don't hold {topic} in my offline library, "
                  f"so I've saved only the syllabus outline. {fix}")

    # Add the source URLs from our research packet so the PDF can show its evidence trail.
    found_sources = re.findall(r"SOURCE \d+: (https?://\S+)", research_text or "")
    emit_progress(80, "Cleaning duplicate content and research references", task=task_label)
    if found_sources:
        existing = sections.get("sources") or []
        sections["sources"] = list(dict.fromkeys([*existing, *found_sources]))[:8]

    safe_name = friday_notes_engine.safe_filename(topic)
    output_path = friday_notes_engine.NOTES_DIR / subject / f"{safe_name}.pdf"
    try:
        emit_progress(88, "Rendering the study notes into the existing notebook template", task=task_label)
        friday_notes_engine.build_gorgeous_notes(topic, subject, sections, output_path)
        emit_progress(96, "Validating the finished notes file", task=task_label)
    except Exception as error:
        print("Notes PDF build error:", error)
        speak("Something went wrong while designing the PDF. Please try again.")
        return True

    entry = friday_notes_engine.register_note(subject, topic, output_path, source=("ai-researched-syllabus-aware" if notes_mode == "ai" else f"offline-{notes_mode}"))
    print(f"STUDY_NOTE_CREATED::{json.dumps(entry)}")
    log_event(f"Notes ready: {topic}", kind="notes")
    emit_progress(100, "Done — notes created and validated", task=task_label)
    if notes_mode == "ai":
        speak(f"Done, sir. I researched {topic}, checked it against the selected syllabus, and built the full notebook-style study notes{attached_text_note}. They're in your Notes tab.")
    elif notes_mode == "library":
        speak(f"Done, sir. The notes on {topic} are in your Notes tab, written from my own reference library, with diagrams. I'd still check them against your syllabus.")
    elif notes_mode == "research-digest":
        speak(f"The digest is in your Notes tab, sir. It's thinner than proper notes, so treat it as a starting point.")
    else:
        speak(f"The outline is in your Notes tab, sir. It's only a skeleton, so I'd regenerate it once my AI brain is back.")
    return True



def study_scan_notes_images(subject, topic, image_paths):
    """Turns one or more photos of hand-written/printed notes into a
    single polished PDF. Tries the full AI-restructuring path first
    (Gemini reads the photos directly -- no separate OCR dependency
    needed); if the AI can't be reached, falls back to a clean PDF
    that just embeds the photos in order so nothing is ever lost."""
    subject = (subject or "general").strip()
    topic = (topic or "Scanned Notes").strip()
    valid_paths = []
    for raw in image_paths:
        try:
            p = Path(str(raw).strip().strip('"').strip("'")).expanduser()
            if p.exists() and p.is_file():
                valid_paths.append(p)
        except Exception:
            continue

    if not valid_paths:
        speak("I couldn't find any of those image files. Please attach photos of your notes and try again.")
        return True

    speak(f"Scanning {len(valid_paths)} photo{'s' if len(valid_paths) != 1 else ''} and turning them into a polished PDF. This can take a moment.")

    uploaded_files = []
    _ensure_gemini_client()
    if client is not None:
        for p in valid_paths:
            try:
                uploaded_files.append(client.files.upload(file=str(p)))
            except Exception as error:
                print("Notes image upload error:", p, error)

    safe_name = friday_notes_engine.safe_filename(topic)
    output_path = friday_notes_engine.NOTES_DIR / subject / f"{safe_name}.pdf"

    sections = None
    if uploaded_files:
        prompt_context = (
            "The attached images are photos of handwritten or printed study notes. "
            "Read every image carefully, transcribe the content, and organise it."
        )
        sections = _ai_structure_notes(topic, subject, prompt_context, uploaded_files=uploaded_files, files_required=True)

    if sections:
        try:
            friday_notes_engine.build_gorgeous_notes(topic, subject, sections, output_path)
        except Exception as error:
            print("Notes PDF build error:", error)
            sections = None

    if not sections:
        speak("I couldn't reach my AI brain to restructure the handwriting, so I've saved your photos as a clean PDF instead.")
        try:
            friday_notes_engine.images_to_pdf_fallback(valid_paths, output_path, title=topic)
        except Exception as error:
            print("Notes fallback PDF build error:", error)
            speak("Something went wrong while building the PDF. Please try again.")
            return True

    entry = friday_notes_engine.register_note(subject, topic, output_path, source="scanned")
    print(f"STUDY_NOTE_CREATED::{json.dumps(entry)}")
    speak(f"Done — your scanned notes are ready and saved to your Notes tab as {topic}.")
    return True


def study_select_subject(command):
    subject = normalize_subject(command)
    if not subject:
        speak("Choose 9701 Chemistry, 9702 Physics, 9709 Maths, 9618 Computer Science, or 4024 O Level Maths.")
        return True
    study_state["subject"] = subject
    set_study_mode_active(True)
    study_state["topic"] = None
    save_study()
    speak(f"Study mode is now focused on {SYLLABUS_MAP[subject]['name']}, syllabus year {SYLLABUS_MAP[subject]['year']}.")
    return True


def study_show_syllabus(command=""):
    subject = normalize_subject(command) or study_state.get("subject")
    if not subject:
        speak("Tell me which syllabus you want, for example 9701 chemistry.")
        return True
    data = SYLLABUS_MAP[subject]
    print("\n=== SYLLABUS MAP ===")
    print(data["name"], "|", data["year"])
    for i, topic in enumerate(data["anchors"], 1):
        print(f"{i:02d}. {topic}")
    speak(f"I displayed the built-in topic map for {subject}. Attach the official Cambridge syllabus PDF when you want exact learning-outcome-level checking.")
    return True


# ============================================================
# SYLLABUS CHECKLIST — Study Mode (V2045, new feature)
# ------------------------------------------------------------
# Student attaches the OFFICIAL syllabus document for a subject.
# Friday reads the full document (not just the built-in SYLLABUS_MAP
# anchors) and turns it into a topic/subtopic checklist the student
# ticks off as they cover each one. Progress is stored in
# study_memory.json (the same shared brain everything else in this
# file uses) so it survives restarts and feeds Study Intelligence.
# ============================================================
SYLLABUS_CHECKLIST_SCHEMA = """
Return ONLY valid JSON: {"topics": [{"topic": "...", "subtopics": ["...", "..."]}]}
Read the ENTIRE attached syllabus document and extract every examinable topic and its
learning-outcome-level subtopics/specification points, in the syllabus's own order and
wording. Do not summarise or shorten topic names. Do not invent topics that are not in
the document. If subtopics are not broken out in the document, return an empty subtopics list for that topic.
"""


def study_syllabus_ingest(payload):
    """Reads the attached syllabus document and builds a checklist.
    Requires the document to already be attached via the existing
    'upload pdf <path>' / study_upload_document() flow (same pattern
    the Explanation Centre and Past Paper Explanation features use)."""
    try: data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception: data = {}
    subject = str(data.get("subject") or study_state.get("subject") or "").strip()
    if not subject or subject not in SYLLABUS_MAP:
        speak("Choose a syllabus code first, for example 9701 chemistry.")
        return True
    if not study_state.get("pdfs") and not study_state.get("documents"):
        speak("Attach the official syllabus PDF first, then ask me to build the checklist.")
        return True

    speak("Reading the full syllabus document. This may take a moment, sir.")
    raw = study_generate(
        f"SYLLABUS CODE: {subject} ({SYLLABUS_MAP[subject]['name']})\n{SYLLABUS_CHECKLIST_SCHEMA}",
        subject=subject, topic="syllabus checklist", attached=True,
    )
    try:
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip(), flags=re.I | re.S).strip()
        parsed = json.loads(cleaned)
        topics = parsed.get("topics") if isinstance(parsed, dict) else None
        if not isinstance(topics, list) or not topics:
            raise ValueError("empty topic list")
    except Exception:
        # Safe fallback: build the checklist from the built-in anchors
        # rather than leaving the student with nothing.
        topics = [{"topic": t, "subtopics": []} for t in SYLLABUS_MAP[subject]["anchors"]]
        speak("I could not fully parse the attached document, so I've built the checklist from Friday's built-in topic map instead. You can still tick items off.")

    items = []
    for i, t in enumerate(topics, 1):
        if not isinstance(t, dict):
            continue
        items.append({
            "id": str(i),
            "topic": str(t.get("topic") or "").strip(),
            "subtopics": [str(s).strip() for s in (t.get("subtopics") or []) if str(s).strip()],
            "done": False,
        })

    checklist_store = study_memory.setdefault("syllabus_checklist", {})
    checklist_store[subject] = {
        "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "items": items,
    }
    save_study()
    result = {"subject": subject, "items": items}
    print("STUDY_SYLLABUS_CHECKLIST::" + json.dumps(result, ensure_ascii=False))
    speak(f"Done. I built a {len(items)}-topic checklist for {SYLLABUS_MAP[subject]['name']} from the attached syllabus.")
    return True


def study_syllabus_get(payload):
    try: data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception: data = {}
    subject = str(data.get("subject") or study_state.get("subject") or "").strip()
    checklist = study_memory.get("syllabus_checklist", {}).get(subject)
    result = {"subject": subject, "items": (checklist or {}).get("items", [])}
    print("STUDY_SYLLABUS_CHECKLIST::" + json.dumps(result, ensure_ascii=False))
    return True


def study_syllabus_toggle(payload):
    """Ticks/unticks one checklist item and persists it into
    study_memory.json -- 'stores it in its brain', per the request."""
    try: data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception: data = {}
    subject = str(data.get("subject") or study_state.get("subject") or "").strip()
    item_id = str(data.get("item_id") or "").strip()
    done = bool(data.get("done"))
    checklist = study_memory.get("syllabus_checklist", {}).get(subject)
    if not checklist:
        return True
    for item in checklist.get("items", []):
        if item.get("id") == item_id:
            item["done"] = done
            break
    save_study()
    total = len(checklist.get("items", []))
    covered = sum(1 for it in checklist.get("items", []) if it.get("done"))
    print("STUDY_SYLLABUS_PROGRESS::" + json.dumps({"subject": subject, "covered": covered, "total": total}, ensure_ascii=False))
    return True


def study_speak(full_text, kind="study_answer"):
    """Speak study-mode content WITHOUT reading every line of it aloud.

    Long study-mode output (full explanations, 8-card flashcard sets,
    marking feedback, exam questions) previously went straight into
    speak(full_text) every time, so Friday read the entire thing out loud
    -- every subtopic, every point -- turning a quick study session into
    a lecture. This never touches speak() itself, the TTS engine, or any
    listening/recognition code: it only decides WHAT STRING is handed to
    the existing speak() function.

    The full, unabridged text is never lost: when it gets shortened for
    speech, it is also printed as a plain diagnostic line first, which
    the existing frontend pipeline (app.js's queuePlainLine/renderAnalysis
    -- the same path study progress/syllabus dumps already use) puts in
    the on-screen FRIDAY ANALYSIS panel. Outside Study Mode, behaviour is
    completely unchanged: the full text is spoken, exactly as before.
    """
    full_text = (full_text or "").strip()
    if not full_text:
        return
    if not study_state.get("active"):
        speak(full_text)
        return
    try:
        plan = friday_agent_core.plan_delivery(full_text, kind=kind)
        max_sentences = max(1, int(plan.get("max_sentences", 2)))
    except Exception:
        max_sentences = 2
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", full_text) if s.strip()]
    if len(sentences) <= max_sentences:
        speak(full_text)
        return
    print(full_text)
    spoken = " ".join(sentences[:max_sentences]).strip()
    speak(spoken + " The rest is on your screen, sir.")


def study_teach(command):
    subject = study_state.get("subject") or normalize_subject(command)
    if not subject:
        speak("Choose a study subject first.")
        return True
    text = command
    prompt = f"Teach this learner the requested topic or question: {text}\nStart by identifying the exact topic. Explain at the appropriate Cambridge level. End with two short retrieval questions, but do not reveal their answers."
    answer = study_generate(prompt, subject=subject, topic=study_state.get("topic"))
    study_speak(answer)
    return True


def study_quiz(command, adaptive=True):
    subject = study_state.get("subject") or normalize_subject(command)
    if not subject:
        speak("Choose a study subject first.")
        return True
    difficulty = 2
    weak = build_study_context(subject).get("mastery", [])
    if adaptive and weak:
        difficulty = 1 if weak[0].get("score", 0) < 0.45 else 2 if weak[0].get("score", 0) < 0.75 else 3
    prompt = f"Create ONE high-quality Cambridge-style study question for {subject}. Difficulty {difficulty}/3. Target a weak or overdue topic if possible. Do not provide the answer. Return exactly: TOPIC, QUESTION, MARKING FOCUS."
    answer = study_generate(prompt, subject=subject, topic=study_state.get("topic"))
    study_state["quiz"] = {"question": answer, "subject": subject, "difficulty": difficulty, "date": datetime.datetime.now().isoformat(timespec="seconds")}
    save_study()
    study_speak(answer)
    return True


def study_mark(command):
    subject = study_state.get("subject")
    quiz = study_state.get("quiz")
    if not subject or not quiz:
        speak("There is no active quiz question to mark. Say quiz me first.")
        return True
    answer = command
    prompt = f"The learner has attempted the active question below. Mark the response strictly but constructively.\nQUESTION:\n{quiz.get('question')}\nLEARNER RESPONSE:\n{answer}\nReturn: VERDICT, SCORE ESTIMATE, WHAT WAS RIGHT, WHAT WAS WRONG OR MISSING, MODEL ANSWER, ONE RETRY QUESTION."
    feedback = study_generate(prompt, subject=subject)
    print("\n=== MARKING ===\n" + feedback)
    lower = feedback.lower()
    if "correct" in lower and "incorrect" not in lower[:300]:
        result = "correct"
    elif "mostly correct" in lower:
        result = "mostly_correct"
    else:
        result = "incorrect"
    update_mastery(subject, study_state.get("topic") or "quiz", result, quiz.get("difficulty", 2))
    study_state["last_answer"] = answer
    study_state["quiz"] = None
    save_study()
    study_speak(feedback)
    return True


def study_flashcards(command):
    subject = study_state.get("subject") or normalize_subject(command)
    if not subject:
        speak("Choose a study subject first.")
        return True
    prompt = "Create a set of 8 active-recall flashcards for the learner. Prioritize weak areas from the supplied study state. Give only the questions first, numbered 1 to 8. Do not give answers yet."
    answer = study_generate(prompt, subject=subject, topic=study_state.get("topic"))
    study_speak(answer)
    return True


def study_recall(command):
    subject = study_state.get("subject") or normalize_subject(command)
    if not subject:
        speak("Choose a study subject first.")
        return True
    prompt = "Run a retrieval-practice session. Ask one short question at a time. Do not teach first. Wait for the learner's answer and then diagnose it."
    answer = study_generate(prompt, subject=subject)
    study_speak(answer)
    return True



def study_exam(command):
    subject = study_state.get("subject") or normalize_subject(command)
    if not subject:
        speak("Choose a study subject first.")
        return True
    prompt = "Act as an examiner. Generate a challenging but syllabus-appropriate exam-style question or short mini-paper. Use Cambridge-style command words and marks. Do not give the solution until the learner attempts it."
    answer = study_generate(prompt, subject=subject)
    study_speak(answer)
    return True


def study_explain_past_paper(command):
    """
    Reads the most recently attached past-paper PDF(s) (see
    study_upload_pdf) and produces a full, question-by-question
    explanation of the paper, grounded in the syllabus code the
    learner selected (from SYLLABUS_MAP) rather than invented content.

    Triggered by "explain past paper <code>" / "explain this past
    paper" from either voice or the UI (Study Mode -> AI Tutor ->
    Past Paper Explanation). The UI is expected to send
    "upload pdf <path>" immediately before this command so the PDF
    is already attached to study_state["pdfs"] by the time this runs
    -- stdin commands are processed strictly one at a time (see
    stdin_command_listener), so that ordering is guaranteed safe.

    The full explanation is printed as a single-line
    STUDY_EXPLAIN::<json> marker (same pattern as WEATHER_DATA::) so
    the UI can render the complete, un-truncated text instead of only
    whatever speak() reads aloud.
    """
    subject = normalize_subject(command) or study_state.get("subject")
    if not subject:
        speak("Tell me the syllabus code for this past paper, for example 9701 for chemistry.")
        return True
    if subject not in SYLLABUS_MAP:
        speak("I don't recognize that syllabus code. Choose 9701, 9702, 9709, 9618, or 4024.")
        return True
    if not study_state.get("pdfs"):
        speak("Attach the past paper PDF first, then ask me to explain it.")
        return True

    syllabus = SYLLABUS_MAP[subject]
    speak(f"Reading the attached past paper against the {syllabus['name']} syllabus. This may take a moment.")

    prompt = (
        f"The attached document is a Cambridge-style past exam paper. Treat the "
        f"{subject} syllabus ({syllabus['name']}, syllabus year {syllabus['year']}) as the "
        "sole authority for what is examinable -- do not import content from any other syllabus. "
        "Work through the attached paper strictly in question order. For every question and "
        "sub-part: (1) restate its question/part number, (2) give a full worked model answer "
        "with every step shown, (3) name the exam command word being tested (state, describe, "
        "explain, calculate, evaluate, etc.), (4) name the specific syllabus topic or learning "
        "outcome it draws on, and (5) give a plausible mark allocation using Cambridge "
        "mark-scheme style abbreviations (e.g. M1, A1, B1) where that is meaningful for the "
        "subject. If any question or part is not legible or not present in the attached PDF, "
        "say so plainly instead of guessing at its content. Do not skip any question."
    )
    answer = study_generate(prompt, subject=subject)

    print(f"\n=== PAST PAPER EXPLANATION ({subject}) ===\n{answer}")
    print("STUDY_EXPLAIN::" + json.dumps({"subject": subject, "text": answer}, ensure_ascii=False))

    speak("I have gone through the past paper question by question against the syllabus. The full explanation is on screen.")
    return True


# ============================================================
# PAST PAPER MARKS ENTRY + MISTAKE ANALYSIS (V2045, redesigned)
# ------------------------------------------------------------
# New guided flow requested by the user:
#   1. Pick the syllabus (existing dropdown).
#   2. Attach the paper they actually did (existing native file
#      picker -> "upload pdf <path>", same mechanism as Explain Past
#      Paper above).
#   3. Say whether they attempted the FULL paper or only some
#      questions.
#   4. Enter marks question-by-question. Every question is sent here
#      one at a time; when marks were lost, Friday reads the attached
#      paper and identifies WHERE it went wrong for that specific
#      question and stores it as a detailed mistake (research doc
#      point 4) via friday_study_intelligence -- the shared brain.
#   5. Once every question is entered, the UI totals the marks (same
#      arithmetic as before) and calls the EXISTING save-past-paper
#      flow with the computed total -- "the already existing way".
# ============================================================

def study_pastpaper_mark_question(payload):
    """One question's marks, entered and analysed immediately.
    Payload: {subject, question_number, marks_awarded, marks_total, question_text?}
    Prints STUDY_PASTPAPER_QUESTION_RESULT:: for the UI to show inline,
    right under that question's row, before the student moves to the next one."""
    try: data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception: data = {}
    subject = str(data.get("subject") or study_state.get("subject") or "").strip()
    qnum = str(data.get("question_number") or "").strip()
    try:
        awarded = float(data.get("marks_awarded"))
        total = float(data.get("marks_total"))
    except (TypeError, ValueError):
        speak("Enter both the marks you got and the marks available for that question.")
        return True
    if subject not in SYLLABUS_MAP:
        speak("Choose a valid syllabus code first.")
        return True

    result = {"subject": subject, "question_number": qnum, "marks_awarded": awarded, "marks_total": total}
    if total <= 0:
        print("STUDY_PASTPAPER_QUESTION_RESULT::" + json.dumps(result, ensure_ascii=False))
        return True

    if awarded >= total:
        # Full marks: record a clean, correct attempt -- no need to
        # spend an AI call analysing a question that was got right.
        update_mastery(subject, "past paper practice", "correct", difficulty=2, question_type="past_paper")
        result["verdict"] = "full_marks"
        result["analysis"] = "Full marks -- no mistake to analyse."
        print("STUDY_PASTPAPER_QUESTION_RESULT::" + json.dumps(result, ensure_ascii=False))
        return True

    have_paper = bool(study_state.get("pdfs"))
    if have_paper:
        prompt = (
            f"The attached document is the exact past paper the learner just sat. Look specifically at "
            f"QUESTION {qnum or '(number not given)'}. The learner scored {awarded} out of {total} marks on it. "
            f"Identify: (1) the specific syllabus topic this question belongs to (one short phrase, matching "
            f"this {subject} syllabus's own topic names where possible), (2) a more specific subtopic if "
            f"identifiable, (3) the most likely category of mistake that cost marks (e.g. 'incorrect equation "
            f"selection', 'unit error', 'missing explanation', 'misread command word', 'arithmetic error', "
            f"'incomplete working', 'sign error'), (4) a one-sentence diagnosis a student could act on. "
            f"If the question cannot be found in the attached document, say so and leave topic as 'unknown'. "
            f"Return ONLY JSON: {{\"topic\":\"...\",\"subtopic\":\"...\",\"mistake_type\":\"...\",\"diagnosis\":\"...\"}}"
        )
        raw = study_generate(prompt, subject=subject, topic=f"past paper Q{qnum}", attached=True)
        try:
            cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip(), flags=re.I | re.S).strip()
            analysis = json.loads(cleaned)
        except Exception:
            analysis = {"topic": "general", "subtopic": "", "mistake_type": "unspecified", "diagnosis": raw[:300]}
    else:
        analysis = {"topic": "general", "subtopic": "", "mistake_type": "unspecified",
                    "diagnosis": "No paper was attached, so Friday recorded the marks lost without a detailed cause."}

    topic = str(analysis.get("topic") or "general").strip() or "general"
    subtopic = str(analysis.get("subtopic") or "").strip()
    mistake_type = str(analysis.get("mistake_type") or "unspecified").strip()
    marks_lost = total - awarded

    update_mastery(
        subject, topic, "incorrect", difficulty=2,
        subtopic=subtopic, mistake_type=mistake_type,
        marks_lost=marks_lost, marks_total=total, question_type="past_paper",
    )
    save_study()

    result["verdict"] = "marks_lost"
    result["topic"] = topic
    result["subtopic"] = subtopic
    result["mistake_type"] = mistake_type
    result["analysis"] = str(analysis.get("diagnosis") or "").strip()
    print("STUDY_PASTPAPER_QUESTION_RESULT::" + json.dumps(result, ensure_ascii=False))
    return True


def study_pastpaper_mark_finalize(payload):
    """All questions entered -- totals the marks and hands back a
    number the UI feeds straight into the pre-existing savePastPaper()
    flow, so the actual save/storage/toast behaviour is unchanged.
    Payload: {subject, mode: 'full'|'partial', entries: [{marks_awarded, marks_total}, ...]}"""
    try: data = json.loads(payload) if isinstance(payload, str) else (payload or {})
    except Exception: data = {}
    subject = str(data.get("subject") or study_state.get("subject") or "").strip()
    mode = str(data.get("mode") or "full").strip()
    entries = data.get("entries") or []

    sum_awarded = 0.0
    sum_total = 0.0
    for e in entries:
        try:
            sum_awarded += float(e.get("marks_awarded", 0))
            sum_total += float(e.get("marks_total", 0))
        except (TypeError, ValueError):
            continue

    percentage = round((sum_awarded / sum_total) * 100, 1) if sum_total > 0 else None
    if percentage is not None and study_intel is not None:
        study_intel.record_score_snapshot(study_memory, subject, "past paper practice", percentage / 100.0)
        save_study()

    breakdown_store = study_memory.setdefault("past_paper_breakdowns", [])
    breakdown_store.append({
        "subject": subject, "mode": mode, "entries": entries,
        "percentage": percentage, "date": datetime.datetime.now().isoformat(timespec="seconds"),
    })
    study_memory["past_paper_breakdowns"] = breakdown_store[-200:]
    save_study()

    result = {
        "subject": subject, "mode": mode,
        "sum_awarded": sum_awarded, "sum_total": sum_total, "percentage": percentage,
        "question_count": len(entries),
    }
    print("STUDY_PASTPAPER_FINALIZE::" + json.dumps(result, ensure_ascii=False))
    if percentage is not None:
        speak(f"Total marks entered: {sum_awarded} out of {sum_total}, which is {percentage} percent. Saving this paper now, sir.")
    else:
        speak("I couldn't total those marks -- check the marks available for each question.")
    return True


def study_plan(command):
    subject = study_state.get("subject") or normalize_subject(command)
    if not subject:
        speak("Choose a study subject first.")
        return True
    prompt = "Build a realistic adaptive study plan using the learner's mastery, mistakes, attached documents and weak topics. Prioritize high-impact weaknesses and include retrieval, practice, review and exam questions."
    answer = study_generate(prompt, subject=subject)
    print("\n=== ADAPTIVE STUDY PLAN ===\n" + answer)
    study_speak(answer)
    return True


def study_progress():
    subject = study_state.get("subject")
    print("\n=== FRIDAY STUDY DASHBOARD ===")
    print("Active:", study_state.get("active"))
    print("Subject:", subject or "none")
    print("Topic:", study_state.get("topic") or "general")
    print("PDFs:", len(study_state.get("pdfs", [])))
    items = []
    for item in study_memory.get("mastery", {}).values():
        if subject and item.get("subject") != subject:
            continue
        items.append(item)
    items.sort(key=lambda x: x.get("score", 0))
    for item in items[:15]:
        print(f"{item.get('topic')}: {item.get('score', 0)*100:.0f}% mastery | {item.get('attempts')} attempts | streak {item.get('streak')}")
    speak("I displayed your study dashboard. Your weakest tracked areas are shown first.")
    return True


def study_start(command):
    subject = normalize_subject(command)
    if subject:
        return study_select_subject(subject)
    if study_state.get("active"):
        # Already in study mode and no subject was recognized in this
        # phrase -- saying the full subject list again every time this
        # happens is exactly what turns one misfire into an endless
        # loop. Just wait quietly for a subject instead of repeating.
        return True
    set_study_mode_active(True)
    save_study()
    speak("Study mode is active. Choose 9701 Chemistry, 9702 Physics, 9709 Maths, 9618 Computer Science, or 4024 O Level Maths.")
    return True


def study_exit():
    set_study_mode_active(False)
    study_state["quiz"] = None
    save_study()
    speak("Study mode closed. Your study progress has been saved.")
    return True


def set_voice_rate_command(value):
    """Compatibility handler: the speaking rate is intentionally locked."""
    global VOICE_RATE
    VOICE_RATE=FRIDAY_FIXED_VOICE_RATE
    os.environ["FRIDAY_VOICE_RATE"]=str(FRIDAY_FIXED_VOICE_RATE)
    print(f"VOICE_RATE_LOCKED::{FRIDAY_FIXED_VOICE_RATE}")
    speak(f"My speaking rate is locked at {FRIDAY_FIXED_VOICE_RATE} words per minute for consistent delivery.")
    return True


def handle_study_command(command):
    # FRIDAY intentionally has no Study Mode.
    return None

# ============================================================
# KEYWORDS
# ============================================================

def extract_keywords(command):
    stop_words = {
        "friday", "friday", "open", "launch", "start", "please", "can", "you", "could", "would",
        "find", "show", "me", "my", "the", "a", "an", "file", "folder", "document",
        "for", "about", "called", "named", "want", "to", "i", "need", "on", "from", "in", "up", "get"
    }
    words = re.findall(r"[a-zA-Z0-9]+", command.lower())
    return [word for word in words if word not in stop_words and len(word) > 1]


# ============================================================
# FILE SEARCH
# ============================================================

SEARCH_FOLDERS = [Path.home() / "Desktop", Path.home() / "Documents", Path.home() / "Downloads", Path.home() / "Pictures", Path.home() / "Videos", Path.home() / "Music"]


def find_best_file(command):
    # V7.0: indexed, token/typo/recency-aware finder first (milliseconds instead of walking every folder per request).
    if friday_filesearch7 is not None:
        try:
            _hit = friday_filesearch7.best(command)
            return Path(_hit["path"]) if _hit else None
        except Exception as _fs_error:
            print("Indexed file search unavailable, using the classic search:", _fs_error)
    return _find_best_file_classic(command)


def _find_best_file_classic(command):
    keywords = extract_keywords(command)
    if not keywords:
        return None
    matches = []
    for folder in SEARCH_FOLDERS:
        if not folder.exists():
            continue
        try:
            for file_path in folder.rglob("*"):
                if not file_path.is_file():
                    continue
                filename = file_path.stem.lower()
                full_path = str(file_path).lower()
                score = 0
                for keyword in keywords:
                    if keyword in filename:
                        score += 10
                    elif keyword in full_path:
                        score += 3
                if score > 0:
                    matches.append((score, file_path))
        except PermissionError:
            continue
        except Exception as error:
            print("File search error:", error)
    if not matches:
        return None
    matches.sort(key=lambda item: item[0], reverse=True)
    return matches[0][1]


def open_file(command):
    speak("Searching your files.")
    file_path = find_best_file(command)
    if file_path is None:
        speak("Sorry, I could not find a matching file.")
        return True
    speak(f"I found {file_path.stem}. Opening it.")
    try:
        os.startfile(str(file_path))
    except Exception as error:
        print("Could not open file:", error)
        speak("I found the file, but I could not open it.")
    return True


# ============================================================
# SPOTIFY
# ============================================================

def play_spotify_song(command):
    stop_words = {"friday", "play", "please", "can", "you", "could", "would", "me", "the", "a", "an", "song", "music", "on", "spotify", "i", "want", "to", "hear", "listen"}
    words = re.findall(r"[a-zA-Z0-9]+", command.lower())
    keywords = [word for word in words if word not in stop_words]
    query = " ".join(keywords)
    if not query:
        speak("Please tell me which song you want to play.")
        return True
    speak(f"Searching Spotify for {query}.")
    spotify_url = "https://open.spotify.com/search/" + urllib.parse.quote(query)
    try:
        from friday_desktop_agent import chrome_open
        result = chrome_open(spotify_url, new_tab=True)
        return bool(result.get("ok"))
    except Exception as error:
        print("Spotify Chrome launch error:", error)
        return False


def open_spotify():
    speak("Opening Spotify.")
    try:
        from friday_desktop_agent import chrome_open
        return bool(chrome_open("https://open.spotify.com", new_tab=True).get("ok"))
    except Exception as error:
        print("Spotify Chrome launch error:", error)
        return False


def open_recently_played():
    speak("Opening your recently played songs.")
    try:
        from friday_desktop_agent import chrome_open
        return bool(chrome_open("https://open.spotify.com/collection/recently-played", new_tab=True).get("ok"))
    except Exception as error:
        print("Spotify Chrome launch error:", error)
        return False


# ============================================================
# WEBSITE
# ============================================================

def open_website(name, url):
    """Open a website explicitly in Google Chrome.

    FRIDAY browser actions must not silently fall back to Windows' default
    browser, because that can route the request to Microsoft Edge.
    """
    try:
        speak(f"Opening {name}.")
    except Exception as error:
        print("TTS error while opening website:", error)

    try:
        from friday_desktop_agent import chrome_open
        result = chrome_open(url, new_tab=True)
        if result.get("ok"):
            return True
        print("Chrome URL launch failed:", result)
        try:
            speak(f"I couldn't open {name} in Google Chrome.")
        except Exception:
            pass
        return False
    except Exception as error:
        print("Chrome controller error:", error)
        try:
            speak(f"I couldn't open {name} in Google Chrome.")
        except Exception:
            pass
        return False


# ============================================================
# GOOGLE SEARCH
# ============================================================

_ENGINE_LABELS = {"google": "Google", "bing": "Bing", "duckduckgo": "DuckDuckGo", "youtube": "YouTube"}


def google_search(command):
    query = ""
    # V2044: the shared NLU extracts ONLY the words to search, whatever the phrasing
    # ("show me search results for orbitals in google" -> orbitals). The legacy extraction
    # below stays as the fallback for anything the NLU is not confident about.
    if friday_nlu is not None:
        try:
            _si = friday_nlu.extract_search(command)
        except Exception as _nlu_error:
            print("NLU search parse error (falling back):", _nlu_error)
            _si = None
        if _si is not None:
            if _si.engine != "google":
                label = _ENGINE_LABELS.get(_si.engine, _si.engine.title())
                speak(f"Searching {label} for {_si.query}.")
                try:
                    from friday_desktop_agent import chrome_open
                    _r = chrome_open(friday_nlu.search_url(_si), new_tab=True)
                    if isinstance(_r, dict) and _r.get("ok"):
                        return True
                except Exception as _e:
                    print("Chrome search controller error:", _e)
                try:
                    webbrowser.open(friday_nlu.search_url(_si))
                except Exception:
                    speak("I could not open the browser, sir.")
                return True
            query = _si.query
    # Prefer an explicit "search [for] ..." phrase wherever it appears in
    # the sentence. BUGFIX (this pass): the old code only looked at the
    # START of the command ("search "/"search for ") and otherwise just
    # split on the literal word "google" and took everything after it.
    # That meant "in my current google screen can u search for gojo cats"
    # split on "google" and produced the query "screen can u search for
    # gojo cats" -- which is exactly the bad result seen in production
    # ("Searching Google for screen can u search for gojo cats."). Finding
    # the actual "search [for]" phrase first fixes this regardless of what
    # comes before it in the sentence.
    m = None if query else re.search(r"\bsearch(?:\s+for)?\s+(.+)$", command, re.I)
    if m:
        query = m.group(1).strip()
        # A phrasing like "search google for python" puts "google" inside
        # the captured group rather than the actual query -- strip it.
        query = re.sub(r"^(?:on\s+)?google\s+(?:for\s+)?", "", query, flags=re.I).strip()
    if not query and "google" in command:
        parts = command.split("google", 1)
        if len(parts) == 2:
            query = parts[1].strip()
    # Strip a leftover filler word from phrasings like "...google screen
    # can you search..." where "screen" was never part of what to search.
    query = re.sub(r"^(?:screen|tab|page|window)\b\s*", "", query, flags=re.I).strip()
    if not query:
        speak("What would you like me to search for?")
        return True
    speak(f"Searching Google for {query}.")
    # Drive the installed Chrome UI explicitly. This avoids pywhatkit/webbrowser
    # selecting Edge and also avoids treating a background HTTP request as proof
    # that the visible browser reached the requested state.
    try:
        from friday_desktop_agent import chrome_search
        result = chrome_search(query, new_tab=False)
        if result.get("ok"):
            return True
        if result.get("error") == "human_verification_required":
            speak("Google has asked for human verification before it will show the results. Please complete the verification in Chrome, sir.")
            return True
        print("Chrome Google search failed:", result)
    except Exception as error:
        print("Chrome Google search controller error:", error)

    # Final fallback keeps the old URL-opening path for machines where Chrome
    # is unavailable, but this is no longer the primary mechanism.
    search_url = "https://www.google.com/search?q=" + urllib.parse.quote(query)
    return open_website("Google search results", search_url)


# ============================================================
# YOUTUBE
# ============================================================
# ============================================================
# YOUTUBE
# ============================================================

_YT_SERVICE = re.compile(r"\b(?:(?:from|on|in|using|via|at|through|with)\s+)?you\s*tube(?:\s+music)?\b", re.I)
_YT_LEAD = re.compile(r"^(?:(?:hey|ok|okay)\s+)?(?:friday[,\s]+)?(?:(?:can|could|would|will)\s+you\s+)?(?:please\s+)?"
                      r"(?:i\s+(?:want|wanna|would\s+like|need)\s+(?:you\s+)?to\s+)?(?:let'?s\s+)?", re.I)
_YT_VERB = re.compile(r"^(?:.*?\b)?(?:play|listen\s+to|listen|hear|watch|put\s+on)\b\s*", re.I)


def _youtube_play_query(command):
    """The song / artist / video the user actually named: the request wording and the 'on YouTube' part are removed, the rest is kept exactly
    (any language, apostrophes, small words such as 'a', 'me', 'you', 'like' inside a title)."""
    text = (command or "").strip().lower()
    text = _YT_SERVICE.sub(" ", text)
    text = re.sub(r"\s+", " ", text).strip(" ,.!?")
    text = _YT_LEAD.sub("", text)
    text = _YT_VERB.sub("", text, count=1) if _YT_VERB.match(text) else text
    text = re.sub(r"^(?:(?:for\s+)?me\s+)?(?:(?:(?:the|a|an|some|any)\s+)?(?:(?:good|nice|random|popular|new|latest)\s+)?(?:songs?|music|videos?|tracks?)\b\s*(?:called|named|titled)?\s*)?", "", text)
    text = re.sub(r"^(?:please\s+|and\s+|to\s+|of\s+|about\s+)+", "", text)
    text = re.sub(r"\s+(?:please|now|for me)$", "", text)
    text = re.sub(r"\s+(?:songs?|music|videos?|tracks?)$", "", text) if len(text.split()) > 1 else text
    if re.fullmatch(r"(?:the\s+|a\s+|an\s+|some\s+|any\s+|something|anything|one|me|it|that|this|song|songs|music|video|videos|track|good|nice|random|popular|new|latest|please|friday|sir|and|to|for|\s)*", text):
        return ""
    return text.strip(" ,.!?")


def _youtube_top_video(query, timeout=5.0):
    """First real video (not a live stream or ad) YouTube itself ranks for `query`, or None. Never raises; gives up after `timeout` seconds."""
    box = {}

    def _look():
        try:
            hits = friday_youtube_research._search_youtube(query, max_results=1)
            if hits:
                box["video"] = hits[0]
        except Exception as error:
            print("YouTube lookup error:", error)

    t = threading.Thread(target=_look, daemon=True, name="friday-yt-lookup")
    t.start()
    return t, box, timeout


def play_youtube(command):
    song = _youtube_play_query(command)
    if not song:
        speak("Which song would you like me to play on YouTube, sir?")
        return True

    # Look the song up while the acknowledgement is being spoken, so "play X on YouTube" starts the video instead of leaving a results page to click.
    lookup, box, timeout = _youtube_top_video(song)
    speak(f"Playing {song} on YouTube, sir.")
    lookup.join(timeout)
    video = box.get("video")
    try:
        if video and video.get("video_id"):
            url = "https://www.youtube.com/watch?v=" + urllib.parse.quote(str(video["video_id"]))
        else:
            url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote(song)
        from friday_desktop_agent import chrome_open
        result = chrome_open(url, new_tab=True)
        if not result.get("ok") and not result.get("executed"):
            raise RuntimeError(result.get("error") or "Chrome could not be opened")
        if not video:
            speak("I couldn't pick a video automatically, so I've opened the YouTube search results for you.")
        return True
    except Exception as error:
        print("YouTube Chrome error:", error)
        speak("I could not open YouTube in Chrome.")
        return False

def open_youtube():
    return open_website(
        "YouTube",
        "https://www.youtube.com"
    )
# ============================================================
# WIKIPEDIA
# ============================================================

def wikipedia_search(command):
    topic = command
    prefixes = ["wikipedia ", "search wikipedia for ", "search wikipedia "]
    for prefix in prefixes:
        if topic.startswith(prefix):
            topic = topic[len(prefix):]
            break
    topic = topic.strip()
    if not topic:
        speak("Please tell me what you want me to search on Wikipedia.")
        return True
    try:
        speak(f"Searching Wikipedia for {topic}.")
        result = wikipedia.summary(topic, sentences=2, auto_suggest=True)
        speak(result)
    except wikipedia.exceptions.DisambiguationError:
        speak("There are multiple results. Please be more specific.")
    except wikipedia.exceptions.PageError:
        speak("Sorry, I could not find that on Wikipedia.")
    except Exception as error:
        print("Wikipedia error:", error)
        speak("Sorry, there was a problem searching Wikipedia.")
    return True


# ============================================================
# WINDOWS APPS
# ============================================================

def open_notepad():
    try:
        from friday_desktop_agent import launch_app
        result=launch_app("notepad")
        if result.get("ok"):
            speak("Notepad is open, sir.")
        else:
            speak("I could not verify that Notepad opened, sir.")
        return bool(result.get("ok"))
    except Exception as e:
        print("Notepad launch error:",e); speak("I could not verify that Notepad opened, sir."); return False


def open_calculator():
    try:
        from friday_desktop_agent import launch_app
        result=launch_app("calculator")
        if result.get("ok"):
            speak("Calculator is open, sir.")
        else:
            speak("I could not verify that Calculator opened, sir.")
        return bool(result.get("ok"))
    except Exception as e:
        print("Calculator launch error:",e); speak("I could not verify that Calculator opened, sir."); return False


# ============================================================
# SHUTDOWN
# ============================================================

def cancel_shutdown():
    os.system("shutdown /a")
    speak("Shutdown cancelled.")
    return True


def shutdown_computer():
    """Queue a Level-4 destructive action instead of executing immediately."""
    global _PENDING_PERMISSION_ACTION
    _PENDING_PERMISSION_ACTION = "shutdown"
    speak("Shutdown is a consequential action, sir. Please confirm by saying yes or cancel by saying no.")
    log_event("Shutdown awaiting explicit confirmation", kind="permission")
    return True


# ============================================================
# JOKE
# ============================================================

def tell_joke():
    jokes = [
        "Why do programmers prefer dark mode? Because light attracts bugs.",
        "Why did the computer go to the doctor? Because it caught a virus.",
        "Why was the computer cold? Because it left its Windows open.",
        "I would tell you a UDP joke, but you might not get it."
    ]
    speak(random.choice(jokes))
    return True


# ============================================================
# WHATSAPP MESSAGING (voice-activated, confirmation required)
# ------------------------------------------------------------
# Fully additive feature. Nothing above this point was touched.
#
# DEFAULT CHANNEL: WhatsApp.
# The user only ever wants one messaging channel automated, so a bare
# "send a message to <contact> saying <message>" / "text <contact>
# saying <message>" (no channel named at all) is treated exactly like
# "send a WhatsApp message to <contact> saying <message>". If another
# channel is explicitly named (email, SMS, Telegram, etc.) this feature
# steps aside instead of hijacking it -- see _OTHER_CHANNEL_KEYWORDS.
#
# Flow:
#   1. "send whatsapp message to <contact> saying <message>" (or the
#      other phrasings below, whatsapp-specific or generic) is parsed.
#      If the contact and/or message weren't both said in one breath,
#      Friday asks for whichever is missing and treats the NEXT thing
#      said/typed as that value -- this mirrors how the rest of this
#      file already carries state across turns (see study_state)
#      instead of blocking inside a nested listen() call, which would
#      risk deadlocking against the stdin command thread's own
#      _COMMAND_LOCK.
#   1b. If the resolved contact name is only a LOW-confidence guess
#      (nothing in contacts.json matched it, and Friday is essentially
#      guessing at a garbled name), Friday stops and asks the user to
#      spell the name instead of silently sending to a possibly-wrong
#      person. See "await_spelling" below and CONTACT NAME ACCURACY.
#   2. Once both are known with confidence, Friday reads the message
#      back and prints ACTION::WHATSAPP_CONFIRM::<json> -- main.js uses
#      this to pop the always-on-top "FRIDAY Message Confirmation"
#      notification over every app (including while the arc-reactor
#      widget is showing).
#   3. The NEXT command -- spoken ("send" / "cancel" / any of the
#      phrasings below), typed, or the notification's YES/NO buttons
#      (which just send "send"/"cancel" back through the same command
#      pipeline every other button already uses) -- resolves it.
# ============================================================

# Channel keywords that mean the user is NOT talking about WhatsApp --
# if any of these show up, the "bare message = WhatsApp" default below
# does not apply, and this feature returns None so something else (or
# nothing, for channels Friday doesn't automate) can handle it instead.
_OTHER_CHANNEL_KEYWORDS = [
    "email", "e-mail", "gmail", "outlook",
    "sms", "text message", "imessage", "i message",
    "telegram", "messenger", "instagram", "discord", "slack", "signal",
]

_wa_session = None  # None, or {"stage": "await_contact"|"await_message"|"confirm", ...}

# Lets a bare follow-up like "send it to whatsapp" / "send this to
# suresh" / "send the message to him" work without repeating the
# message body or the contact name -- see _REUSE_MESSAGE_TRIGGER and
# the reuse tier in handle_whatsapp_start() below.
_LAST_COMPOSED_MESSAGE = None   # last message-like text Friday produced
_LAST_KNOWN_CONTACT = None      # last contact resolved with confidence
_DRAFTING_MODE = False          # True while the conversation is actively composing a message


def _wa_normalize_command(text):
    """Clean speech-recognition output."""
    if not text:
        return ""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s']", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text


def _wa_similarity(a, b):
    """Return similarity between two phrases."""
    return difflib.SequenceMatcher(None, a, b).ratio()


_WA_SEND_PHRASES = [
    "send", "send it", "send this", "send that", "send the message",
    "send the whatsapp", "go ahead", "go ahead and send", "yes send",
    "yeah send", "okay send", "ok send", "confirm", "confirmed", "do it",
    "send it now", "yes go ahead", "that's fine send it", "that is fine send it",
]

_WA_CANCEL_PHRASES = [
    "cancel", "cancel it", "cancel the message", "don't send", "do not send",
    "don't send it", "do not send it", "no", "no don't", "stop", "stop sending",
    "forget it", "never mind", "nevermind", "leave it", "don't do it", "do not do it",
]


def _wa_has_word(word, command):
    """Word-boundary match so short words like "no"/"stop" don't
    misfire inside unrelated words (e.g. "no" inside "send it now")."""
    pattern = r"(?<!\w)" + re.escape(word).replace(r"\ ", r"\s+") + r"(?!\w)"
    return re.search(pattern, command) is not None


def _wa_understand_confirmation(command):
    """Determines whether the user wants to SEND or CANCEL. Returns "send", "cancel", or None."""
    command = _wa_normalize_command(command)
    if not command:
        return None

    if command in _WA_SEND_PHRASES:
        return "send"
    if command in _WA_CANCEL_PHRASES:
        return "cancel"

    # Negative phrases are checked BEFORE the generic "send" match so
    # "don't send it" can't be misread as SEND. Word-boundary checked
    # so e.g. "no" never matches inside "now".
    for word in ["don't", "do not", "never", "cancel", "stop", "forget"]:
        if _wa_has_word(word, command):
            return "cancel"
    if _wa_has_word("no", command) and not _wa_has_word("now", command):
        return "cancel"

    if _wa_has_word("send", command):
        return "send"

    best_send_score = max((_wa_similarity(command, p) for p in _WA_SEND_PHRASES), default=0)
    best_cancel_score = max((_wa_similarity(command, p) for p in _WA_CANCEL_PHRASES), default=0)

    if best_send_score >= 0.78 and best_send_score > best_cancel_score:
        return "send"
    if best_cancel_score >= 0.78 and best_cancel_score > best_send_score:
        return "cancel"

    return None


def send_whatsapp_message(contact_name, message):
    """
    Send a WhatsApp message using the WhatsApp Desktop application.
    Voice/UI confirmation must already have happened before this is called.
    Returns True if the send sequence completed, False otherwise.
    """
    try:
        import pyautogui
        import pyperclip
    except Exception as error:
        print("WhatsApp error: pyautogui/pyperclip not available:", error)
        speak("I can't send WhatsApp messages yet. The automation library isn't installed.")
        return False

    try:
        if not contact_name or not contact_name.strip():
            print("WhatsApp error: Contact name is empty.")
            return False
        if not message or not message.strip():
            print("WhatsApp error: Message is empty.")
            return False

        contact_name = contact_name.strip()
        message = message.strip()

        print("\n======================================")
        print("       FRIDAY WHATSAPP SENDING")
        print("======================================")
        print(f"Contact : {contact_name}")
        print(f"Message : {message}")
        print("======================================")

        # Open Windows Search and launch WhatsApp, then verify that the real
        # WhatsApp window is actually in the foreground before touching it.
        pyautogui.hotkey("win", "s")
        time.sleep(1)
        pyautogui.write("WhatsApp", interval=0.03)
        time.sleep(1)
        pyautogui.press("enter")
        deadline = time.time() + 7.0
        whatsapp_ready = False
        while time.time() < deadline:
            try:
                title = str(get_active_window_title() or "").lower()
            except Exception:
                title = ""
            if "whatsapp" in title:
                whatsapp_ready = True
                break
            time.sleep(0.25)
        if not whatsapp_ready:
            print("WhatsApp error: foreground WhatsApp window was not verified.")
            return False

        # Search for the contact.
        pyautogui.hotkey("ctrl", "f")
        time.sleep(1)
        pyautogui.hotkey("ctrl", "a")
        pyperclip.copy(contact_name)  # clipboard allows Unicode + emojis
        pyautogui.hotkey("ctrl", "v")
        time.sleep(2)

        # Select the matching contact.
        pyautogui.press("down")
        time.sleep(0.5)
        pyautogui.press("enter")
        time.sleep(1.5)

        # Paste and send the message.
        pyperclip.copy(message)
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.5)
        pyautogui.press("enter")
        time.sleep(1.0)

        # Truth gate: never announce success merely because Enter was pressed.
        # WhatsApp should still be foreground and the composer should be empty
        # after a successful send. If the UI cannot provide that evidence,
        # report failure rather than falsely claiming delivery.
        try:
            title_after = str(get_active_window_title() or "").lower()
        except Exception:
            title_after = ""
        if "whatsapp" not in title_after:
            print("WhatsApp error: WhatsApp was not foreground after send.")
            return False
        # V2044 FIX: the clipboard still held the MESSAGE from the paste above. Ctrl+C on an empty
        # composer copies nothing, so the old check read the message straight back and reported
        # "problem sending" even though the message HAD been sent. Plant a unique probe first:
        #   clipboard == probe          -> nothing was selected/copied  -> composer empty -> sent
        #   clipboard == the message    -> composer still holds it       -> NOT sent
        #   anything else (chat text)   -> Ctrl+A selected the chat, so the composer was empty -> sent
        probe = f"__FRIDAY_PROBE_{int(time.time() * 1000)}__"
        try:
            pyperclip.copy(probe)
            pyautogui.hotkey("ctrl", "a")
            pyautogui.hotkey("ctrl", "c")
            time.sleep(0.2)
            composer_after = str(pyperclip.paste() or "").strip()
        except Exception:
            composer_after = probe            # cannot inspect the composer: do not invent a failure
        if composer_after == message.strip():
            print("WhatsApp error: message still appears in the composer; send was not verified.")
            return False

        print("\nFRIDAY: WhatsApp message send sequence verified.")
        return True

    except Exception as error:
        print("\n======================================")
        print("       WHATSAPP SEND ERROR")
        print("======================================")
        print(error)
        print("======================================")
        return False


def _wa_reset():
    global _wa_session, _LAST_COMPOSED_MESSAGE, _DRAFTING_MODE
    _wa_session = None
    # A sent or cancelled message is done with -- don't let a later
    # unrelated "send it" accidentally reuse it.
    _LAST_COMPOSED_MESSAGE = None
    _DRAFTING_MODE = False
    print("ACTION::WHATSAPP_CLOSE")


def _wa_begin_confirm(contact, message):
    global _wa_session, _LAST_KNOWN_CONTACT
    _LAST_KNOWN_CONTACT = contact
    _wa_session = {"stage": "confirm", "contact": contact, "message": message}
    speak(
        f"Sir, I have prepared a WhatsApp message for {contact}. "
        f"The message says: {message}. "
        f"Say send to send it, or cancel to cancel it."
    )
    print("\n================================")
    print("       WHATSAPP PREVIEW")
    print("================================")
    print(f"To:      {contact}")
    print(f"Message: {message}")
    print("================================\n")
    # main.js listens for this marker to show the always-on-top
    # "Message Confirmation" notification over every app / widget mode.
    print("ACTION::WHATSAPP_CONFIRM::" + json.dumps({"contact": contact, "message": message}))
    return True


# Ordered from most to least specific so a fully-formed request never
# falls through to the "which contact / which message" follow-up flow.
_WA_FULL_PATTERNS = [
    re.compile(
        r"(?:send|write)\s+(?:a\s+|an\s+)?whatsapp(?:\s+message)?\s+to\s+(?P<contact>.+?)\s+"
        r"(?:saying|that says|with the message|with message|message saying)\s*[:,-]?\s*(?P<message>.+)",
        re.I,
    ),
    re.compile(
        r"(?:send|write)\s+(?P<contact>.+?)\s+(?:a\s+|an\s+)?whatsapp(?:\s+message)?\s+"
        r"(?:saying|that says|with the message|with message)\s*[:,-]?\s*(?P<message>.+)",
        re.I,
    ),
    re.compile(
        r"whatsapp\s+(?P<contact>.+?)\s+(?:saying|that says)\s*[:,-]?\s*(?P<message>.+)",
        re.I,
    ),
    re.compile(
        r"(?:send|write)\s+(?:a\s+|an\s+)?whatsapp(?:\s+message)?\s+to\s+(?P<contact>.+?)\s*[:,-]\s*(?P<message>.+)",
        re.I,
    ),
]

_WA_CONTACT_ONLY_PATTERNS = [
    re.compile(r"(?:send|write)\s+(?:a\s+|an\s+)?whatsapp(?:\s+message)?\s+to\s+(?P<contact>.+)", re.I),
    # Negative lookahead keeps "whatsapp message" (no contact said yet)
    # from being misread as a contact literally named "message".
    re.compile(r"\bwhatsapp\s+(?!message\b)(?P<contact>.+)", re.I),
]

_WA_START_ONLY_PATTERN = re.compile(r"(?:send|write)\s+(?:a\s+|an\s+)?whatsapp(?:\s+message)?\b", re.I)

# Same three tiers as the _WA_* patterns above (full / contact-only /
# start-only), but with no "whatsapp" keyword required -- these are
# what fire when the user just says "send a message"/"text someone"
# with no channel named, which per _OTHER_CHANNEL_KEYWORDS above
# defaults to WhatsApp. Deliberately narrower than the WhatsApp-
# specific patterns (require an explicit "message" or "saying"/"that
# says") to avoid misfiring on ordinary sentences that merely contain
# the word "text".
_GENERIC_MESSAGE_FULL_PATTERNS = [
    # Natural voice phrasing: "can you message my friend Harshik saying hi".
    re.compile(
        r"(?:can|could|would|will)\s+(?:you\s+)?(?:please\s+)?message\s+(?:my\s+)?(?:friend\s+)?(?P<contact>.+?)\s+(?:saying|that says)\s*[:,-]?\s*(?P<message>.+)",
        re.I,
    ),
    re.compile(
        r"(?:send|write)\s+(?:a\s+|an\s+)?message\s+to\s+(?P<contact>.+?)\s+"
        r"(?:saying|that says|with the message|with message|message saying)\s*[:,-]?\s*(?P<message>.+)",
        re.I,
    ),
    re.compile(
        r"(?:send|write|text)\s+(?P<contact>.+?)\s+(?:a\s+|an\s+)?message\s+"
        r"(?:saying|that says|with the message|with message)\s*[:,-]?\s*(?P<message>.+)",
        re.I,
    ),
    re.compile(
        r"\btext\s+(?P<contact>.+?)\s+(?:saying|that says)\s*[:,-]?\s*(?P<message>.+)",
        re.I,
    ),
    re.compile(
        r"(?:send|write)\s+(?:a\s+|an\s+)?message\s+to\s+(?P<contact>.+?)\s*[:,-]\s*(?P<message>.+)",
        re.I,
    ),
]

_GENERIC_MESSAGE_CONTACT_PATTERNS = [
    # Requires an explicit "to <contact>" so this can't grab unrelated
    # words out of an ordinary sentence.
    re.compile(r"(?:send|write)\s+(?:a\s+|an\s+)?message\s+to\s+(?P<contact>.+)", re.I),
]

_GENERIC_MESSAGE_START_PATTERN = re.compile(r"(?:send|write)\s+(?:a\s+|an\s+)?message\b", re.I)

# Catches a bare follow-up that reuses whatever Friday just composed
# instead of repeating the whole message: "send it", "send this to
# suresh", "send the message to him", "send it to whatsapp". Only
# consulted as a last resort in handle_whatsapp_start(), after the
# more specific patterns above have already had a chance to match a
# fully-specified request.
_REUSE_MESSAGE_TRIGGER = re.compile(
    r"\b(?:send|forward)\s+(?:it|this|that|the\s+message|the\s+draft)\b"
    r"(?:\s+(?:to|on)\s+(?P<target>.+))?",
    re.I,
)
# Words that mean "the contact I already have in mind", not an actual
# new name to resolve -- covers pronouns and someone just saying
# "whatsapp" itself instead of a name.
_PRONOUN_CONTACT_PLACEHOLDERS = {"him", "her", "them", "whatsapp", "it", "that person", "him.", "her."}


def _wa_clean(text):
    return text.strip(" .,:-\"'")


# ============================================================
# CONTACT NAME ACCURACY
# ------------------------------------------------------------
# Speech recognition is unreliable specifically on proper nouns/names
# (no dictionary word to anchor to), which is the single biggest
# source of a wrong/garbled/blank-looking recipient in the
# confirmation notification. This adds three layers, cheapest first:
#   1. Fuzzy-match against a small user-maintained contacts.json (a
#      real name close to what was heard, e.g. "Sara" -> "Sarah").
#   2. If that's not confident, re-check the OTHER things Google heard
#      for the same utterance (_LAST_RECOGNITION_ALTERNATIVES) in case
#      a lower-ranked alternative caught the name correctly.
#   3. If still unresolved, ask Gemini to clean up a likely phonetic
#      mis-transcription of a name.
# Every layer is optional/best-effort -- worst case, this simply
# returns the original text, title-cased.
# ============================================================

def _load_contacts():
    try:
        if CONTACTS_FILE.exists():
            data = json.loads(CONTACTS_FILE.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return [str(c).strip() for c in data if str(c).strip()]
    except Exception as error:
        print("Could not read contacts.json (ignored):", error)
    return []


def _save_contacts(contacts):
    try:
        CONTACTS_FILE.write_text(
            json.dumps(sorted(set(contacts), key=str.lower), indent=2),
            encoding="utf-8",
        )
    except Exception as error:
        print("Could not write contacts.json (ignored):", error)


def _wa_best_known_contact(candidate, contacts):
    if not contacts or not candidate:
        return None, 0.0
    lowered = candidate.strip().lower()
    best_name, best_score = None, 0.0
    for name in contacts:
        score = difflib.SequenceMatcher(None, lowered, name.lower()).ratio()
        if score > best_score:
            best_name, best_score = name, score
    return best_name, best_score


def _wa_semantic_best_contact(raw_contact, contacts):
    """Semantic (embedding-based) contact matching -- the same Gemini
    embedding model already used for command matching above, applied
    here to names instead of whole phrases. Plain character similarity
    (_wa_best_known_contact) catches near-miss SPELLING ("Sara" vs
    "Sarah"); this catches near-miss SOUND/MEANING that spells very
    differently, e.g. "Jon" vs "John", or a heavily garbled phonetic
    transcription that still embeds close to the real name. Runs only
    when the plain-similarity pass wasn't confident (see caller), and
    is wrapped so any failure (offline, no key, etc.) just contributes
    nothing -- it never breaks contact resolution.
    """
    if not contacts or not raw_contact:
        return None, 0.0
    try:
        target_vector = _get_embedding(raw_contact)
        if target_vector is None:
            return None, 0.0
        best_name, best_score = None, 0.0
        for name in contacts:
            vector = _get_embedding(name)
            if vector is None:
                continue
            score = _cosine_similarity(target_vector, vector)
            if score > best_score:
                best_name, best_score = name, score
        return best_name, best_score
    except Exception as error:
        print("Semantic contact matching skipped:", error)
        return None, 0.0


def _wa_resolve_contact_name(raw_contact, full_command=""):
    """
    Resolve a heard contact name to (name, confidence).

    confidence is "high" when a saved contact (or a lower-ranked
    recognition alternative, or the semantic/embedding layer) matched
    strongly enough that Friday can trust it; "low" when this is
    ultimately just a guess -- Gemini's phonetic best-effort, or a bare
    title-casing of whatever speech recognition heard, with nothing in
    contacts.json to check it against. Callers should ask the user to
    spell the name out loud rather than silently acting on a "low"
    result -- see CONTACT NAME ACCURACY / "await_spelling" below.
    """
    raw_contact = _wa_clean(raw_contact)
    if not raw_contact:
        return raw_contact, "low"

    global _LAST_KNOWN_CONTACT
    contacts = _load_contacts()

    if _is_typed_input():
        # Typed text has no speech-recognition errors, so trust the spelling. Only snap to a saved
        # contact on a (near-)exact match - a looser match could turn "Harshik" into "Harshit".
        known, known_score = _wa_best_known_contact(raw_contact, contacts)
        if known and known_score >= 0.9:
            _LAST_KNOWN_CONTACT = known
            return known, "high"
        display = raw_contact.title() if raw_contact == raw_contact.lower() else raw_contact
        _LAST_KNOWN_CONTACT = display
        return display, "high"

    best_name, best_score = _wa_best_known_contact(raw_contact, contacts)
    if best_name and best_score >= 0.6:
        _LAST_KNOWN_CONTACT = best_name
        return best_name, "high"

    # Plain text similarity wasn't confident -- try the semantic layer
    # before giving up on the saved contact list entirely.
    semantic_name, semantic_score = _wa_semantic_best_contact(raw_contact, contacts)
    if semantic_name and semantic_score >= 0.90:
        _LAST_KNOWN_CONTACT = semantic_name
        return semantic_name, "high"

    # Cross-check the other things Google heard for this exact
    # utterance -- a lower-ranked alternative may have caught the name
    # correctly even though it lost overall to the chosen transcript.
    for alternative in _LAST_RECOGNITION_ALTERNATIVES:
        if not alternative or alternative == full_command:
            continue
        for pattern in (
            _WA_FULL_PATTERNS + _WA_CONTACT_ONLY_PATTERNS
            + _GENERIC_MESSAGE_FULL_PATTERNS + _GENERIC_MESSAGE_CONTACT_PATTERNS
        ):
            match = pattern.search(alternative)
            if not match:
                continue
            alt_contact = _wa_clean(match.group("contact"))
            alt_name, alt_score = _wa_best_known_contact(alt_contact, contacts)
            if alt_name and alt_score > best_score and alt_score >= 0.6:
                _LAST_KNOWN_CONTACT = alt_name
                return alt_name, "high"
            break

    # Last resort: ask Gemini for its best guess at the actual name,
    # correcting likely speech-to-text phonetic errors. Still only
    # ever "low" confidence -- it's a guess, not a known contact.
    _ensure_gemini_client()
    if client is not None:
        try:
            prompt = (
                'Speech recognition heard a person\'s name as: "' + raw_contact + '". '
                "This text may contain phonetic transcription errors. Reply with "
                "ONLY your best guess of the actual name, properly capitalized, "
                "and nothing else. If it already looks correct, just repeat it "
                "with standard capitalization."
            )
            response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
            cleaned = (getattr(response, "text", None) or "").strip().strip('"').strip("'")
            if cleaned:
                return cleaned, "low"
        except Exception as error:
            print("Contact name cleanup skipped:", error)

    return raw_contact.title(), "low"


def _parse_spelled_name(text):
    """
    Turn a spelled-out name into a proper name string.

    Handles "s a r a h", "s-a-r-a-h", "capital s a r a h", etc. -- if
    every token in the cleaned utterance is a single letter, this is
    genuinely spelled out and gets joined into one word. If the user
    just said the name normally instead of spelling it (which is a
    perfectly fine response too), this falls back to accepting it
    as-is, title-cased.
    """
    cleaned = _wa_clean(text)
    if not cleaned:
        return ""
    # "capital" is sometimes said before the first letter -- harmless
    # to strip since we title-case the result anyway.
    cleaned = re.sub(r"\bcapital\b", " ", cleaned, flags=re.I)
    tokens = [t for t in re.split(r"[\s\-]+", cleaned) if t]
    letters = [t for t in tokens if len(t) == 1 and t.isalpha()]
    if tokens and len(letters) == len(tokens):
        return "".join(letters).title()
    return cleaned.title()


_CONTACT_SAVE_PATTERN = re.compile(r"(?:save|add|remember)\s+(?:this\s+)?contact\s+(?P<name>.+)", re.I)


def handle_contact_management(command):
    """
    Voice command to build up contacts.json so future WhatsApp
    requests recognize that name reliably: "save contact Sarah
    Khan" / "add contact Mom" / "remember this contact Dave".
    """
    match = _CONTACT_SAVE_PATTERN.search(command)
    if not match:
        return None
    name = _wa_clean(match.group("name"))
    if not name:
        speak("What name would you like me to save?")
        return True
    name = name.title()
    contacts = _load_contacts()
    if name.lower() not in [c.lower() for c in contacts]:
        contacts.append(name)
        _save_contacts(contacts)
    speak(f"Saved {name} to your contacts. I'll recognize that name more reliably from now on.")
    return True


def _wa_ask_to_spell(heard_name):
    speak(
        f"I want to make sure I get the name right, sir. I heard {heard_name} -- "
        f"could you spell that for me?"
    )


def _wa_start_from_nlu(command):
    """V2044: typo/filler-tolerant messaging intent ("an u send harshik a messge saying bro?").
    Returns True when it handled the request, None to let the legacy patterns try."""
    global _wa_session
    if friday_nlu is None:
        return None
    try:
        intent = friday_nlu.parse_message(command)
    except Exception as error:
        print("NLU message parse error (falling back):", error)
        return None
    if intent is None:
        return None
    if intent.channel == "other":
        if intent.body:
            channel = (intent.other_channel or "that app").replace("-", "")
            speak(f"I can only send messages through WhatsApp for now, sir. {channel.capitalize()} is not connected yet.")
            return True
        return None                      # no body: leave it to the drafting / chat flow
    contact, confidence = _wa_resolve_contact_name(intent.contact, command)
    if not contact:
        return None
    message = _wa_clean(intent.body) if intent.body else ""
    if message:
        if confidence == "low":
            _wa_session = {"stage": "await_spelling", "pending_message": message}
            _wa_ask_to_spell(contact)
            return True
        return _wa_begin_confirm(contact, message)
    if confidence == "low":
        _wa_session = {"stage": "await_spelling"}
        _wa_ask_to_spell(contact)
        return True
    _wa_session = {"stage": "await_message", "contact": contact}
    speak(f"What would you like to say to {contact}?")
    return True


def handle_whatsapp_start(command):
    """
    Entry point for a brand-new WhatsApp request. Returns True if this
    command started (or fully completed the parsing of) a WhatsApp
    send flow, otherwise None so handle_command() keeps looking.

    Also the entry point for a channel-less "send a message to X
    saying Y" / "text X saying Y" -- see _OTHER_CHANNEL_KEYWORDS and
    the DEFAULT CHANNEL note above. If another channel is explicitly
    named, this steps aside (returns None) instead of hijacking it.
    """
    global _wa_session
    # V7.0: "make whatsapp full screen" / "make whatsapp smaller" is a window command, not a message to someone.
    try:
        _wt = _WINDOW_FILLER_HEAD.sub("", str(command).strip()).strip(" ,.!?")
        if _MAXIMIZE_MAKE_PATTERN.match(_wt) or _UNMAXIMIZE_MAKE_PATTERN.match(_wt):
            return None
    except Exception:
        pass
    nlu_result = _wa_start_from_nlu(command)
    if nlu_result is not None:
        return nlu_result
    lowered = command.lower()
    mentions_whatsapp = "whatsapp" in lowered

    if mentions_whatsapp:
        full_patterns = _WA_FULL_PATTERNS
        contact_only_patterns = _WA_CONTACT_ONLY_PATTERNS
        start_only_pattern = _WA_START_ONLY_PATTERN
    else:
        if any(keyword in lowered for keyword in _OTHER_CHANNEL_KEYWORDS):
            return None
        full_patterns = _GENERIC_MESSAGE_FULL_PATTERNS
        contact_only_patterns = _GENERIC_MESSAGE_CONTACT_PATTERNS
        start_only_pattern = _GENERIC_MESSAGE_START_PATTERN

    for pattern in full_patterns:
        match = pattern.search(command)
        if match:
            contact, confidence = _wa_resolve_contact_name(match.group("contact"), command)
            message = _wa_clean(match.group("message"))
            if contact and message:
                if confidence == "low":
                    _wa_session = {"stage": "await_spelling", "pending_message": message}
                    _wa_ask_to_spell(contact)
                    return True
                return _wa_begin_confirm(contact, message)

    for pattern in contact_only_patterns:
        match = pattern.search(command)
        if match:
            contact, confidence = _wa_resolve_contact_name(match.group("contact"), command)
            if contact:
                if confidence == "low":
                    _wa_session = {"stage": "await_spelling"}
                    _wa_ask_to_spell(contact)
                    return True
                _wa_session = {"stage": "await_message", "contact": contact}
                speak(f"What would you like to say to {contact}?")
                return True

    # Last resort: a bare "send it" / "send this to X" / "send it to
    # whatsapp" reusing whatever Friday most recently composed, instead
    # of a fully-specified request. Only fires if there IS a pending
    # composed message and no other channel was named.
    if _LAST_COMPOSED_MESSAGE and not any(keyword in lowered for keyword in _OTHER_CHANNEL_KEYWORDS):
        match = _REUSE_MESSAGE_TRIGGER.search(command)
        if match:
            target_raw = _wa_clean(match.group("target") or "")
            if target_raw and target_raw.lower() not in _PRONOUN_CONTACT_PLACEHOLDERS:
                contact, confidence = _wa_resolve_contact_name(target_raw, command)
            elif _LAST_KNOWN_CONTACT:
                contact, confidence = _LAST_KNOWN_CONTACT, "high"
            else:
                contact, confidence = "", "low"

            if not contact:
                _wa_session = {"stage": "await_contact", "pending_message": _LAST_COMPOSED_MESSAGE}
                speak("Who would you like me to send that to?")
                return True
            if confidence == "low":
                _wa_session = {"stage": "await_spelling", "pending_message": _LAST_COMPOSED_MESSAGE}
                _wa_ask_to_spell(contact)
                return True
            return _wa_begin_confirm(contact, _LAST_COMPOSED_MESSAGE)

    if start_only_pattern.search(command):
        _wa_session = {"stage": "await_contact"}
        speak("Who would you like to send a WhatsApp message to?")
        return True

    return None


def handle_whatsapp_continuation(command):
    """
    Handles the turn(s) that follow handle_whatsapp_start() while
    _wa_session is active: filling in a missing contact/message, or
    resolving the final send/cancel confirmation. Returns True if the
    command was consumed, otherwise None.
    """
    global _wa_session, _LAST_KNOWN_CONTACT
    if _wa_session is None:
        return None

    stage = _wa_session.get("stage")
    cleaned = _wa_clean(command)

    # Allow bailing out of the flow at any stage.
    if stage != "confirm":
        abort_decision = _wa_understand_confirmation(command)
        if abort_decision == "cancel":
            speak("Okay, I've cancelled that WhatsApp message.")
            _wa_reset()
            return True

    if stage == "await_contact":
        if not cleaned:
            speak("Sorry, I didn't catch a name. Who would you like to message on WhatsApp?")
            return True
        pending_message = _wa_session.get("pending_message")
        resolved_contact, confidence = _wa_resolve_contact_name(cleaned, command)
        if confidence == "low":
            _wa_session = {"stage": "await_spelling", "pending_message": pending_message}
            _wa_ask_to_spell(resolved_contact)
            return True
        if pending_message:
            return _wa_begin_confirm(resolved_contact, pending_message)
        _wa_session = {"stage": "await_message", "contact": resolved_contact}
        speak(f"What would you like to say to {resolved_contact}?")
        return True

    if stage == "await_spelling":
        if not cleaned:
            speak("Sorry, I didn't catch that. Could you spell the name letter by letter?")
            return True
        spelled_name = _parse_spelled_name(command)
        if not spelled_name:
            speak("Sorry, I still didn't catch that. Could you spell the name letter by letter?")
            return True

        # Now that the user has spelled it out, save it so this exact
        # name is recognized with high confidence next time (same
        # mechanism as the "save contact" voice command).
        contacts = _load_contacts()
        if spelled_name.lower() not in [c.lower() for c in contacts]:
            contacts.append(spelled_name)
            _save_contacts(contacts)
        _LAST_KNOWN_CONTACT = spelled_name

        pending_message = _wa_session.get("pending_message")
        if pending_message:
            return _wa_begin_confirm(spelled_name, pending_message)

        _wa_session = {"stage": "await_message", "contact": spelled_name}
        speak(f"Thank you, sir. What would you like to say to {spelled_name}?")
        return True

    if stage == "await_message":
        if not cleaned:
            speak("Sorry, I didn't catch that. What would you like the message to say?")
            return True
        return _wa_begin_confirm(_wa_session["contact"], cleaned)

    if stage == "confirm":
        contact = _wa_session["contact"]
        message = _wa_session["message"]
        decision = _wa_understand_confirmation(command)

        if decision == "send":
            speak("Understood, sir. Sending the message now.")
            _wa_reset()
            sent = send_whatsapp_message(contact, message)
            if sent:
                try:                       # remember the name so future spoken requests resolve confidently
                    known = _load_contacts()
                    if contact.lower() not in [c.lower() for c in known]:
                        known.append(contact)
                        _save_contacts(known)
                except Exception:
                    pass
                speak("The WhatsApp message has been sent, sir.")
            else:
                speak("I ran into a problem sending that WhatsApp message, sir.")
            return True

        if decision == "cancel":
            speak("Understood, sir. I have cancelled the WhatsApp message.")
            _wa_reset()
            return True

        speak(
            "I wasn't able to determine whether you wanted me to send or "
            "cancel the message. Say send, or say cancel."
        )
        return True

    return None


# ============================================================
# WEB SEARCH + DIRECT DOCUMENT DOWNLOAD
# ============================================================
# Download requests are handled locally before Gemini's fallback.
# This lets Friday do things such as:
#   "download the 9618 syllabus"
#   "download the latest 9701 syllabus"
#   "download this PDF https://..."
#
# Syllabus requests search Cambridge International and then download
# the matching official PDF into the user's Windows Downloads folder.
# ============================================================

DOWNLOAD_DIR = Path.home() / "Downloads"
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
MAX_DOWNLOAD_BYTES = 250 * 1024 * 1024

# V2045: filenames Friday itself just downloaded via _download_url() below --
# the movie-style "new download" watcher (further down this file) skips
# these, since _download_url already told the user about them out loud.
_FRIDAY_OWN_DOWNLOADS = set()


def _safe_filename(name, fallback="download.pdf"):
    name = re.sub(r'[<>:"/\\|?*]', "_", str(name)).strip(" .")
    if not name:
        name = fallback
    if not name.lower().endswith(".pdf"):
        name += ".pdf"
    return name[:180]


def _unique_download_path(filename):
    filename = _safe_filename(filename)
    path = DOWNLOAD_DIR / filename
    counter = 2
    while path.exists():
        path = DOWNLOAD_DIR / f"{Path(filename).stem} ({counter}){Path(filename).suffix}"
        counter += 1
    return path


def _download_url(url, filename=None):
    """Download a web resource safely to the Windows Downloads folder."""
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            speak("That does not appear to be a valid web address.")
            return None

        default_name = Path(parsed.path).name or "download.pdf"
        destination = _unique_download_path(filename or default_name)

        speak(f"Downloading {destination.name}.")
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 Chrome/140 Safari/537.36"
        }

        with requests.get(
            url,
            headers=headers,
            stream=True,
            timeout=(10, 60),
            allow_redirects=True
        ) as response:
            response.raise_for_status()

            content_length = response.headers.get("Content-Length")
            if content_length:
                try:
                    if int(content_length) > MAX_DOWNLOAD_BYTES:
                        speak("That file is too large for Friday to download.")
                        return None
                except ValueError:
                    pass

            temporary = destination.with_suffix(destination.suffix + ".part")
            total = 0

            try:
                with open(temporary, "wb") as f:
                    for chunk in response.iter_content(chunk_size=1024 * 128):
                        if not chunk:
                            continue
                        total += len(chunk)
                        if total > MAX_DOWNLOAD_BYTES:
                            raise ValueError("download exceeded the size limit")
                        f.write(chunk)

                temporary.replace(destination)
            except Exception:
                try:
                    temporary.unlink(missing_ok=True)
                except Exception:
                    pass
                raise

        speak(f"Done. I downloaded {destination.name} to your Downloads folder.")
        _FRIDAY_OWN_DOWNLOADS.add(destination.name)
        return destination

    except requests.exceptions.RequestException as error:
        print("Web download error:", error)
        speak("I could not download that file from the web.")
        return None
    except Exception as error:
        print("Download error:", error)
        speak("The download could not be completed.")
        return None


def _extract_urls(text):
    return re.findall(r'https?://[^\s<>"\']+', text)


def _syllabus_subject(command):
    c = command.lower()

    for code in ("9618", "9701", "9702", "9709", "9700", "4024"):
        if code in c:
            return code

    aliases = {
        "computer science": "9618",
        "chemistry": "9701",
        "physics": "9702",
        "mathematics": "9709",
        "maths": "9709",
        "biology": "9700",
    }

    for alias, code in aliases.items():
        if alias in c and "syllabus" in c:
            return code

    return None


def _search_official_syllabus(subject_code):
    """
    Search Cambridge International's public website for an official
    syllabus PDF. Google is used only as the search index; the actual
    downloaded file must come from Cambridge International.
    """
    query = (
        f'site:cambridgeinternational.org/Images '
        f'"{subject_code}" syllabus PDF Cambridge International'
    )
    search_url = "https://www.google.com/search?q=" + urllib.parse.quote(query)

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 Chrome/140 Safari/537.36"
    }

    try:
        response = requests.get(search_url, headers=headers, timeout=15)
        response.raise_for_status()

        urls = re.findall(
            r'https?://(?:www\.)?cambridgeinternational\.org/[^"\'<>\s]+?\.pdf',
            response.text,
            flags=re.I
        )

        cleaned = []
        for url in urls:
            url = urllib.parse.unquote(url).replace("\\/", "/")
            if url not in cleaned:
                cleaned.append(url)

        # Prefer PDFs whose URL itself contains syllabus.
        syllabus_urls = [u for u in cleaned if "syllabus" in u.lower()]

        return syllabus_urls + [
            u for u in cleaned if u not in syllabus_urls
        ]

    except Exception as error:
        print("Official syllabus search error:", error)
        return []


def download_syllabus(command):
    subject = _syllabus_subject(command)

    if not subject:
        speak("Tell me the syllabus code or subject, for example 9618 Computer Science.")
        return True

    speak(f"I'll find the official Cambridge syllabus for {subject}.")

    urls = _search_official_syllabus(subject)

    if not urls:
        speak(f"I could not find an official Cambridge syllabus for {subject}.")
        return True

    chosen = urls[0]
    filename = f"{subject}_Cambridge_syllabus.pdf"
    path = _download_url(chosen, filename)

    if path:
        print(f"Downloaded syllabus: {path}")

    return True


# ============================================================
# NEW: WEB RESEARCH (see friday_web_research.py)
# ============================================================

def handle_web_research_command(original_command):
    """
    Entry point called from handle_command(). Strips the trigger
    phrase off the command, runs the full search -> fetch -> Gemini
    pipeline in friday_web_research.py, then speaks the answer and
    prints the sources so the UI can render clickable links.
    """
    command = original_command.strip()
    lowered = command.lower()
    query = command
    for prefix in (
        "research ", "look up ", "look into ", "find out ",
        "find the current price of ", "find the price of ",
        "find me the price of ", "find me the cheapest ",
        "find the cheapest ", "check the price of ", "find ",
    ):
        if lowered.startswith(prefix):
            query = command[len(prefix):]
            break
    query = query.strip()
    if not query:
        speak("What would you like me to research?")
        return True

    speak(friday_persona.line("research_ack"))
    result = friday_web_research.run_web_research(query)
    speak(result["answer"])
    if result["sources"]:
        print("ACTION::RESEARCH_SOURCES::" + json.dumps(result["sources"]))
    # Remembered so a follow-up like "compare the prices" or "make it
    # into slides" can be resolved against this turn -- see
    # friday_context.py. Only worth keeping when the research actually
    # produced something usable.
    if result.get("ok"):
        friday_context.remember_research(query, result)
    return True


def handle_download_request(command):
    """
    Handle downloads before normal commands and before Gemini.
    """
    # BUGFIX: the Study Mode Syllabus Checklist UI sends structured,
    # JSON-payload commands ("syllabus_ingest::{...}", "syllabus_get::{...}",
    # "syllabus_toggle::{...}") every time the page opens, the subject is
    # changed, "Read Syllabus & Build Checklist" is pressed, or an item is
    # ticked. Those payloads contain the word "syllabus" AND a subject code
    # like "9701", which is exactly what _syllabus_subject() below looks
    # for -- so every one of those calls was being hijacked into the
    # natural-language "download the official Cambridge syllabus PDF" flow
    # instead of ever reaching study_syllabus_ingest/get/toggle. That's why
    # it spoke "I'll find the official Cambridge syllabus for 9701" on a
    # loop and the checklist itself never actually got built. These
    # internal "syllabus_"-prefixed commands are never a download request,
    # so let them fall through untouched to the Study Mode handler below.
    if command.startswith("syllabus_"):
        return None

    # BUGFIX (part 2 of the same issue): "upload pdf <path>" / "add pdf
    # <path>" is how the Syllabus Checklist's "Attach Syllabus PDF" button
    # (and every other Study Mode attach button) actually attaches a file --
    # see syllAttach() in index.html, which sends this before syllabus_ingest::.
    # An official Cambridge syllabus file is very often named with the
    # subject code AND the word "syllabus" in it (e.g. "9701_syllabus.pdf"),
    # which is exactly what the natural-language check just below this was
    # matching on -- so attaching that exact file was itself being hijacked
    # into the "I'll find the official Cambridge syllabus" download flow
    # instead of ever reaching study_upload_pdf(). The file was never
    # actually recorded as attached, which is why "Build Checklist"
    # afterwards still said to attach the PDF first. File attachment is
    # never a download request, regardless of what the filename contains.
    if command.startswith("upload pdf ") or command.startswith("add pdf "):
        return None

    urls = _extract_urls(command)

    if urls:
        # Explicit URL:
        # "download https://example.com/file.pdf"
        url = urls[0]
        filename = None

        path_name = Path(urlparse(url).path).name
        if path_name.lower().endswith(".pdf"):
            filename = path_name

        _download_url(url, filename)
        return True

    # Natural-language syllabus request:
    # "download the 9618 syllabus"
    # BUGFIX (part 3): this used to fire on ANY command containing the word
    # "syllabus" plus a recognizable subject code, with no download-intent
    # word required at all -- so it could catch things far beyond the
    # intended "download the 9618 syllabus" phrasing. Now it requires an
    # actual download-style verb alongside "syllabus" + the code, so a
    # genuine request like "download the 9701 syllabus" or "get me the
    # 9701 syllabus" still works exactly as before, without swallowing
    # unrelated commands that merely happen to mention a syllabus and a code.
    _SYLLABUS_DOWNLOAD_VERBS = ("download", "get me", "find me", "fetch", "grab me", "pull up", "save")
    if (
        "syllabus" in command.lower()
        and _syllabus_subject(command)
        and any(v in command.lower() for v in _SYLLABUS_DOWNLOAD_VERBS)
    ):
        return download_syllabus(command)

    # Other natural-language download request.
    if any(phrase in command.lower() for phrase in (
        "download", "save to downloads", "save this pdf", "get the pdf"
    )):
        speak("Tell me the web address, or tell me the syllabus code you want me to download.")
        return True

    return None


# ============================================================
# V2045: "MOVIE FRIDAY" NEW-DOWNLOAD CONFIRMATION
# ------------------------------------------------------------
#   "Sir, do you want me to open the newly downloaded file?"
#   ... waits for yes/no ...
#   yes -> opens it.  no -> leaves it alone.
#
# A lightweight polling watcher (no extra dependency) snapshots the
# Downloads folder every few seconds. A name that appears which was
# NOT there a moment ago, and which Friday did not just download
# itself (see _FRIDAY_OWN_DOWNLOADS above), triggers exactly one
# pending confirmation -- mirrors the existing WhatsApp
# _wa_session / handle_whatsapp_continuation state-machine pattern
# already used elsewhere in this file, so voice, typed text, and (if
# main.js adds one) a notification button all resolve it identically.
# ============================================================
_DL_SESSION = None          # None, or {"path": str, "name": str, "asks": int}
_DL_IGNORE_SUFFIXES = (".crdownload", ".part", ".tmp", ".download", ".partial")
_DL_POLL_SECONDS = 2.5


def _dl_snapshot_downloads():
    try:
        return {p.name for p in DOWNLOAD_DIR.iterdir() if p.is_file()}
    except Exception:
        return set()


def download_watch_loop():
    """Daemon thread: watches the Downloads folder for files that
    appear from outside Friday (a browser download, a file someone
    airdropped in, etc.) and asks whether to open them."""
    global _DL_SESSION
    seen = _dl_snapshot_downloads()  # baseline: never prompt for files that already existed at startup
    while True:
        time.sleep(_DL_POLL_SECONDS)
        try:
            if _DL_SESSION is not None:
                continue  # one pending question at a time
            current = _dl_snapshot_downloads()
            new_names = current - seen
            seen = current
            for name in sorted(new_names):
                if name in _FRIDAY_OWN_DOWNLOADS:
                    _FRIDAY_OWN_DOWNLOADS.discard(name)
                    continue
                if name.lower().endswith(_DL_IGNORE_SUFFIXES):
                    continue
                full_path = DOWNLOAD_DIR / name
                _DL_SESSION = {"path": str(full_path), "name": name, "asks": 1}
                print("ACTION::DOWNLOAD_FOUND::" + json.dumps({"name": name, "path": str(full_path)}, ensure_ascii=False))
                speak(f"Sir, a new file named {name} has just been downloaded. Would you like me to open it?")
                break  # handle this one before considering any other new file this tick
        except Exception as error:
            print("Download watcher error (safe, retrying):", error)


def _understand_yes_no(command):
    """Small, dedicated yes/no parser (kept separate from
    _wa_understand_confirmation, whose vocabulary is send/cancel-specific,
    to keep this readable at the call site)."""
    command = _wa_normalize_command(command)
    if not command:
        return None
    if _wa_has_word("no", command) and not _wa_has_word("now", command):
        return "no"
    for phrase in ["don't", "do not", "never mind", "nevermind", "leave it", "cancel", "not now", "nah"]:
        if _wa_has_word(phrase, command):
            return "no"
    for phrase in ["yes", "yeah", "yep", "sure", "go ahead", "please", "okay", "ok", "open it"]:
        if _wa_has_word(phrase, command):
            return "yes"
    return None


def handle_download_continuation(command):
    """Resolves the pending 'would you like me to open it?' question.
    Returns True if consumed, None if there is nothing pending."""
    global _DL_SESSION
    if _DL_SESSION is None:
        return None

    decision = _understand_yes_no(command)
    if decision is None:
        _DL_SESSION["asks"] += 1
        if _DL_SESSION["asks"] > 2:
            # Don't trap the user in this forever -- after two unclear
            # answers, quietly stand down and leave the file alone.
            print("ACTION::DOWNLOAD_CLOSE")
            _DL_SESSION = None
            return None
        speak("Sorry sir, shall I open it? Yes or no?")
        return True

    session = _DL_SESSION
    _DL_SESSION = None
    print("ACTION::DOWNLOAD_CLOSE")

    if decision == "no":
        speak("Understood, sir. I'll leave it.")
        return True

    path = session["path"]
    try:
        system = platform.system()
        if system == "Windows":
            os.startfile(path)  # noqa: S606 -- user's own file, user's own machine, user just said yes
        elif system == "Darwin":
            _pc_subprocess.run(["open", path], check=False)
        else:
            _pc_subprocess.run(["xdg-open", path], check=False)
        speak(f"Opening {session['name']}, sir.")
    except Exception as error:
        print("Could not open downloaded file:", error)
        speak(f"I could not open {session['name']}, sir. You may need to open it manually.")
    return True


# ============================================================
# V2046: INCOMING WHATSAPP NOTIFICATION -> "DO YOU WANT TO REPLY?"
# ------------------------------------------------------------
#   <chat name> sends a WhatsApp message
#   -> Friday: "Sir, <chat name> sent you a message on WhatsApp.
#               Would you like to reply?"
#   -> user: "yes" / "no" / "yes, say I'm on my way"
#
# Mirrors the existing _DL_SESSION / handle_download_continuation
# pending-question pattern. A "yes" with no message attached hands off
# to the SAME award_message stage handle_whatsapp_start() already uses
# ("What would you like to say to <contact>?"), and a "yes" WITH a
# message goes straight into the existing _wa_begin_confirm() preview
# -> "send"/"cancel" flow. No part of the send pipeline itself is
# touched or duplicated -- this only decides *when* to enter it.
#
# friday_whatsapp_watch.py is the (optional, Windows-only) source of
# these notifications; see that module for how it detects them.
# ============================================================
_WA_INCOMING_SESSION = None  # None, or {"chat": str, "preview": str, "asks": int}

# Trailing content after the yes/reply word, e.g. "yes say I'm on my way",
# "reply saying I'm on my way", "yes tell them I'll call later".
_WA_INCOMING_INLINE_REPLY = re.compile(
    r"^\s*(?:yes|yeah|yep|sure|okay|ok)?[,.]?\s*(?:reply|say|tell (?:them|him|her))\s+"
    r"(?:saying|that|with|to (?:them|him|her)?)?\s*[:,-]?\s*(?P<message>.+)$",
    re.I,
)


def _wa_incoming_on_notification(chat_name, preview_text):
    """Callback passed to friday_whatsapp_watch.start_listener(). Runs on
    the watcher's own background thread -- exactly like download_watch_loop
    already does when it calls speak() directly."""
    global _WA_INCOMING_SESSION
    chat_name = (chat_name or "").strip()
    if not chat_name:
        return
    # Never talk over an already-pending question, and never interrupt a
    # WhatsApp send flow that's already in progress -- consistent with the
    # download watcher's "one pending question at a time" rule.
    if _WA_INCOMING_SESSION is not None or _wa_session is not None:
        return
    _WA_INCOMING_SESSION = {"chat": chat_name, "preview": (preview_text or "").strip(), "asks": 1}
    speak(f"{chat_name} sent you a message on WhatsApp. Would you like to reply?")


def handle_whatsapp_incoming_continuation(command):
    """Resolves the pending 'do you want to reply?' question raised by
    _wa_incoming_on_notification(). Returns True if consumed, None if
    there is nothing pending (so handle_command() keeps looking)."""
    global _WA_INCOMING_SESSION, _wa_session
    if _WA_INCOMING_SESSION is None:
        return None

    session = _WA_INCOMING_SESSION
    chat_name = session["chat"]

    inline_match = _WA_INCOMING_INLINE_REPLY.match(command or "")
    if inline_match:
        message = _wa_clean(inline_match.group("message"))
        if message:
            _WA_INCOMING_SESSION = None
            return _wa_begin_confirm(chat_name, message)

    decision = _understand_yes_no(command)
    if decision is None:
        session["asks"] += 1
        if session["asks"] > 2:
            # Don't trap the user forever -- stand down quietly after two
            # unclear answers, same as the download-confirmation flow.
            _WA_INCOMING_SESSION = None
            return None
        speak(f"Sorry sir, would you like to reply to {chat_name}? Yes or no?")
        return True

    _WA_INCOMING_SESSION = None
    if decision == "no":
        speak("Understood, sir.")
        return True

    # "yes" with no message yet -- hand off to the existing award_message
    # stage so typing/speaking the reply, previewing it, and sending it
    # all go through the same tested pipeline as any other WhatsApp send.
    _wa_session = {"stage": "await_message", "contact": chat_name}
    speak(f"What would you like to say to {chat_name}?")
    return True


# ============================================================
# V2050: WHATSAPP CALLS (outgoing + incoming) -- ADDITIVE
# ------------------------------------------------------------
#   "call Mom on WhatsApp"  -> spelling check for an uncertain name (same
#                              as sending a message) -> "Shall I call Mom?"
#                              -> yes -> dials through WhatsApp Desktop
#   WhatsApp incoming call  -> "Sir, Mom is calling you on WhatsApp.
#                               Shall I answer it?" -> yes / no / decline
#
# All logic lives in friday_whatsapp_calls.py; this block only connects it
# to the existing speak / contact-resolution / yes-no helpers. Nothing above
# was modified. If the module or its optional Windows dependencies are
# missing, every function here quietly does nothing.
# ============================================================
try:
    import friday_whatsapp_calls as _wa_calls
except Exception as _wa_calls_import_error:          # pragma: no cover
    _wa_calls = None
    print("WhatsApp calls module unavailable (ignored):", _wa_calls_import_error)

_wa_call_controller = None


def _wa_call_flow_in_progress():
    """A WhatsApp MESSAGE flow is mid-conversation (asking contact/message/confirm)."""
    return _wa_session is not None


def _wa_call_clear_pending_questions():
    """A ringing call outranks other pending yes/no questions, so a bare 'yes'
    can't be ambiguous between them."""
    global _WA_INCOMING_SESSION, _DL_SESSION
    _WA_INCOMING_SESSION = None
    if _DL_SESSION is not None:
        _DL_SESSION = None
        print("ACTION::DOWNLOAD_CLOSE")


def _wa_call_get_controller():
    global _wa_call_controller
    if _wa_calls is None:
        return None
    if _wa_call_controller is None:
        _wa_call_controller = _wa_calls.CallController(
            speak=speak,
            resolve_contact=_wa_resolve_contact_name,
            ask_to_spell=_wa_ask_to_spell,
            parse_spelled=_parse_spelled_name,
            yes_no=_understand_yes_no,
            is_cancel=lambda text: _wa_understand_confirmation(text) == "cancel",
            load_contacts=_load_contacts,
            save_contacts=_save_contacts,
            flow_in_progress=_wa_call_flow_in_progress,
            clear_pending_questions=_wa_call_clear_pending_questions,
            log=lambda msg: log_event(msg, kind="action"),
        )
    return _wa_call_controller


def handle_whatsapp_call_command(command):
    """Returns True if the command belonged to a WhatsApp call flow, else None."""
    controller = _wa_call_get_controller()
    if controller is None:
        return None
    try:
        return controller.handle(command)
    except Exception as call_error:
        print("WhatsApp call handler error (ignored):", call_error)
        return None


def _wa_call_on_incoming(caller, video):
    controller = _wa_call_get_controller()
    if controller is not None:
        controller.on_incoming(caller, video)


def _wa_call_on_end(caller, missed):
    controller = _wa_call_get_controller()
    if controller is not None:
        controller.on_call_end(caller, missed)


def start_whatsapp_call_watchers():
    """Started once from the Electron startup path. Never raises."""
    def _delayed_call_watcher():
        # Started well after boot so nothing here can ever interfere with the
        # backend connecting or the greeting; any failure is only logged.
        try:
            time.sleep(20)
            if _wa_calls is not None:
                _wa_calls.start_incoming_watcher(
                    _wa_call_on_incoming, _wa_call_on_end,
                    log=lambda msg: log_event(msg, kind="recovery"),
                )
        except BaseException as watcher_error:
            try:
                log_event(f"WhatsApp call watcher unavailable: {watcher_error}", kind="recovery")
            except Exception:
                pass
    try:
        threading.Thread(target=_delayed_call_watcher, name="Friday-WhatsApp-CallWatch-Boot", daemon=True).start()
    except Exception as watcher_error:
        log_event(f"WhatsApp call watcher unavailable: {watcher_error}", kind="recovery")
    # The new-download watcher (V2045) was defined but never started or hooked
    # into handle_command; start it here so "a new file was downloaded, want me
    # to open it?" actually works.
    try:
        threading.Thread(target=download_watch_loop, name="Friday-Download-Watch", daemon=True).start()
    except Exception as dl_error:
        log_event(f"Download watcher unavailable: {dl_error}", kind="recovery")


# The message-notification announcer (V2046) treats every WhatsApp toast as a
# text message. Wrap it so a call toast ("Mom / Incoming voice call") is left to
# the call flow instead of being announced as "Mom sent you a message", and so
# it stays quiet while a call question or file question is pending. Every other
# notification goes to the original, unchanged function.
_wa_incoming_on_notification_messages_only = _wa_incoming_on_notification


def _wa_incoming_on_notification(chat_name, preview_text):
    try:
        if _wa_calls is not None and _wa_calls.looks_like_call_text(chat_name, preview_text):
            return
        controller = _wa_call_controller
        if _DL_SESSION is not None or (controller is not None and controller.has_pending_question()):
            return
    except Exception:
        pass
    return _wa_incoming_on_notification_messages_only(chat_name, preview_text)


# ============================================================
# COMMAND HANDLER
# ============================================================

# ============================================================
# GEMINI-BASED INTENT CLASSIFICATION (FALLBACK LAYER)
# ------------------------------------------------------------
# handle_command()'s keyword matching above is fast and exact, and
# stays the FIRST thing tried for everything -- nothing about it is
# changed. This only runs for whatever falls through all of it
# unmatched, right before the plain AI Q&A fallback. It asks Gemini
# to map oddly-worded phrasing ("is it chilly outside today?") onto
# one of Friday's own KNOWN, SAFE intents, then dispatches to the
# exact same handler functions the keyword matches already use.
#
# Deliberately excludes anything destructive or exact-text-dependent
# (shutdown_computer, file search, Google/keyword search-query
# extraction) -- those still require the real trigger words, by
# design, so a misclassification can never be a wrong-action risk.
# Any failure here (offline, bad key, unexpected reply) just falls
# through to return None -> ask_ai(), exactly like before this existed.
# ============================================================

_INTENT_LABELS = [
    "weather", "time", "date", "joke", "who_are_you", "help",
    "wikipedia_search", "play_youtube",
    "open_google", "open_youtube", "open_gmail", "open_chatgpt", "open_spotify",
    "study_mode", "minimize", "restore", "settings", "exit",
    # Added for the Web Research / Creation Engine modules, so natural,
    # loosely-worded requests for these two features are understood the
    # same way every other intent above already is -- not just the
    # handful of exact phrasings handle_command() checks for directly.
    "live_information_request", "create_presentation",
    "none",
]


# V7.2 SPEED: a plain chat message used to pay a full blocking Gemini round trip just to be told "none" before the real answer could
# start. Only commands containing a cue word for one of the labels are sent to the classifier, and the call is time-boxed.
_INTENT_CUE_RE = re.compile(
    r"weather|rain|temperature|forecast|umbrella|\btime\b|clock|\bdate\b|joke|"
    r"who are you|what are you|help|wiki|youtube|\bplay\b|google|gmail|e-?mail|\bmail\b|chat ?gpt|spotify|music|song|"
    r"study|studying|minimi|restore|maximi|setting|\bexit\b|\bquit\b|\bbye\b|\bsleep\b|price|cost|\brate\b|fare|news|"
    r"latest|current|right now|how much|syllabus|spec\b|specs\b|presentation|slide|deck|document|pdf|spreadsheet|report|essay|"
    r"make me|create|build|put together|look up|search|find|open|launch|show|go to|take me", re.I)
_INTENT_POOL = None


def _classify_intent_with_gemini(command):
    global _INTENT_POOL
    if os.getenv("FRIDAY_INTENT_PREFILTER", "1").strip().lower() not in {"0", "false", "no", "off"} \
            and not _INTENT_CUE_RE.search(command or ""):
        return "none"
    _ensure_gemini_client()
    if client is None:
        return "none"
    if _INTENT_POOL is None:
        import concurrent.futures as _cf
        _INTENT_POOL = _cf.ThreadPoolExecutor(max_workers=3, thread_name_prefix="FridayFast")
    try:
        return _INTENT_POOL.submit(_classify_intent_blocking, command).result(
            timeout=float(os.getenv("FRIDAY_INTENT_TIMEOUT", "0.9")))
    except Exception as error:
        print("Intent classification skipped (slow or failed):", error)
        return "none"


def _classify_intent_blocking(command):
    try:
        prompt = (
            "You route voice commands for a personal assistant named Friday. "
            "Reply with EXACTLY ONE of these words and nothing else:\n"
            + ", ".join(_INTENT_LABELS) + "\n\n"
            "Only pick a label if the message CLEARLY means that action. "
            "If it's a general question, small talk, or anything else, reply 'none'.\n\n"
            "Two labels need extra care:\n"
            "- live_information_request: the user wants a CURRENT real-world "
            "fact that could change over time and needs to be looked up right "
            "now -- a price, a fare, an exchange rate, a spec sheet, a "
            "syllabus, today's news, etc. Examples: 'find me the price of a "
            "Singapore Airlines flight to Singapore', 'what does a 1TB SSD "
            "cost right now', 'look up the current AUD to USD rate'.\n"
            "- create_presentation: the user wants a new presentation, "
            "document, PDF, or spreadsheet actually built for them on a "
            "topic. Examples: 'make me a presentation about nuclear fusion', "
            "'put together a slideshow on the French Revolution', 'build me "
            "a report on climate change'. Do NOT choose this for a request "
            "to just explain or discuss a topic in conversation -- only "
            "when they clearly want a file created.\n\n"
            f"{friday_context.current_topic_hint()}\n"
            f"{friday_context.persistent_topic_hint()}\n"
            f"Message: {command}"
        )
        response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
        label = (getattr(response, "text", None) or "").strip().lower()
        label = re.sub(r"[^a-z_]", "", label)
        return label if label in _INTENT_LABELS else "none"
    except Exception as error:
        print("Intent classification skipped:", error)
        return "none"


def _dispatch_classified_intent(label, command, original_command="", reuse_sources=None, reuse_topic=None):
    try:
        friday_agent_core.record_intent(label, confidence=0.90 if label and label != "none" else 0.0)
    except Exception:
        pass
    """Every branch here is one of the already-existing safe actions
    -- this just reroutes to it. Returns None only for 'none'/unknown,
    signalling handle_command should fall through to ask_ai().

    live_information_request / create_presentation are routed with
    `original_command` (natural casing preserved) rather than the
    lower-cased `command`, since the Web Research and Creation Engine
    modules use that text as an actual search query / document topic.

    reuse_sources / reuse_topic come from friday_context.resolve()
    (see handle_command) -- when set, create_presentation skips
    re-researching the web and builds straight from the sources
    Friday already gathered a moment ago (e.g. "make it into slides"
    right after a research turn).
    """
    if label == "weather":
        return get_weather(command)
    if label == "time":
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The time is {current_time}.")
        return True
    if label == "date":
        current_date = datetime.datetime.now().strftime("%A, %B %d, %Y")
        speak(f"Today is {current_date}.")
        return True
    if label == "joke":
        return tell_joke()
    if label == "who_are_you":
        speak("I am Friday, version five. I'm your multi-tasking AI assistant. I can reason through problems, research the web, write and debug code, read the files you attach, see through your screen and camera, control your computer, remember what matters to you, and carry out multi-step tasks.")
        return True
    if label == "help":
        speak("I can answer questions using my AI brain, tell you the time and date, open websites and Windows apps, search Google, play YouTube and Spotify music, search Wikipedia, find files, control your computer, research things live on the web, create documents/PDFs/spreadsheets/presentations, and help with research, documents, web tasks, and finance.")
        return True
    if label == "wikipedia_search":
        return wikipedia_search(command)
    if label == "play_youtube":
        return play_youtube(command)
    if label == "open_google":
        return open_website("Google", "https://www.google.com")
    if label == "open_youtube":
        return open_website("YouTube", "https://www.youtube.com")
    if label == "open_gmail":
        return open_website("Gmail", "https://mail.google.com")
    if label == "open_chatgpt":
        return open_website("ChatGPT", "https://chatgpt.com")
    if label == "open_spotify":
        return open_spotify()
    if label == "study_mode":
        # Study Mode is intentionally removed from FRIDAY.
        return None
    if label == "minimize":
        speak(friday_persona.line("minimize"))
        print("ACTION::MINIMIZE_WIDGET")
        return True
    if label == "restore":
        speak(friday_persona.line("restore"))
        print("ACTION::RESTORE_WINDOW")
        return True
    if label == "settings":
        speak(friday_persona.line("settings"))
        print("ACTION::OPEN_SETTINGS")
        return True
    if label == "exit":
        speak(friday_persona.line("exit"))
        print("ACTION::SHUTDOWN")
        globals()["_EXIT_REQUESTED"] = True
        return False
    if label == "live_information_request":
        return handle_web_research_command((original_command or command).strip())
    if label == "create_presentation":
        return friday_creation_engine.create_project_command(
            (original_command or command).strip(),
            reuse_sources=reuse_sources,
            reuse_topic=reuse_topic,
        )
    return None


# ============================================================
# SYSTEM CONTROL -- close applications / close browser tabs.
# Delegates all real work to friday_system_control.py; this function
# just parses the phrasing and turns the verified result into an
# honest spoken response. It NEVER speaks a success line unless the
# module reports ok=True after re-checking reality.
# ============================================================

_NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}

# Targets that already have their own, more specific handling earlier
# in handle_command (exit/minimize/restore/settings) -- never treat
# these as "close an application".
_SYSTEM_CONTROL_EXCLUDED_TARGETS = (
    "yourself", "friday", "settings", "widget", "interface", "study mode",
)

_TABS_PATTERN = re.compile(
    r"^close\s+(?:the\s+)?(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\s+"
    r"(?:google\s+|chrome\s+|browser\s+|open\s+)?tabs?"
    r"(?:\s+(?:except|accept|excluding|but keep|leave|other than)\s+(?:the\s+)?(.+?)\s*tab\b.*)?$",
    re.I,
)

_APP_CLOSE_PATTERN = re.compile(
    r"^(?:close|quit|kill|terminate|end|force\s*quit|force\s*close)\s+(?:the\s+)?(.+?)$",
    re.I,
)


_WINDOW_FILLER_TAIL = re.compile(
    r"\s+(?:for me|please|right now|now|sir|thanks|thank you|window|app|application|program)\s*$", re.I)
_WINDOW_FILLER_HEAD = re.compile(r"^(?:please\s+|hey\s+friday[, ]*|(?:can|could|would) you\s+(?:please\s+)?)", re.I)
_MINIMIZE_PATTERN = re.compile(r"^minimi[sz]e\s+(?:the\s+|my\s+)?(.*)$", re.I)
# V6.4: maximise / full-screen a window, and take it back to normal size. These used to fall into the "focus" pattern below,
# which only brought the app to the front and never changed its size.
_MAXIMIZE_PATTERN = re.compile(r"^(?:maximi[sz]e|maximi[sz]ing)\b\s*(?:the\s+|my\s+)?(.*)$", re.I)
_MAXIMIZE_MAKE_PATTERN = re.compile(
    r"^(?:make|put|set)\s+(?:the\s+|my\s+)?(.+?)\s+(?:to\s+)?(?:full[\s-]?screen|maximi[sz]ed|as\s+big\s+as\s+(?:it\s+can|possible)|fill\s+the\s+screen)$", re.I)
_UNMAXIMIZE_MAKE_PATTERN = re.compile(r"^make\s+(?:the\s+|my\s+)?(.+?)\s+(?:smaller|normal\s+size|windowed|small)$", re.I)
_MAXIMIZE_NOT_A_WINDOW = re.compile(r"\b(?:volume|brightness|sound|audio|speed|performance|battery|power|effort|profit|score|output|gains?|potential|efficiency|marks?|grades?)\b", re.I)
_FOCUS_PATTERN = re.compile(
    r"^(?:go\s+back\s+to|get\s+back\s+to|switch\s+(?:back\s+)?to|take\s+me\s+(?:back\s+)?to|"
    r"return\s+to|jump\s+to|focus\s+(?:on\s+)?|bring\s+back|restore|maximi[sz]e)\s+(?:the\s+|my\s+)?(.+)$", re.I)
_FOCUS_BRING_PATTERN = re.compile(r"^bring\s+(?:the\s+|my\s+)?(.+?)\s+(?:back|to\s+(?:the\s+)?front|forward)$", re.I)
_WINDOW_SELF_TARGETS = ("friday", "yourself", "yourselves", "interface", "the interface", "widget", "settings", "study mode")
_WINDOW_THIS_TARGETS = ("", "this", "it", "that", "this one", "that one", "current", "current one", "everything else")
_WINDOW_ALL_TARGETS = ("all", "all windows", "all apps", "all applications", "everything", "all of them", "every window", "all the windows", "all the apps")
_WINDOW_PREVIOUS_TARGETS = ("previous", "previous app", "previous window", "previous application", "previous one",
                            "last app", "last window", "last application", "last one", "other app", "other window")


def try_handle_window_control(command):
    """'minimise chrome' / 'go back to whatsapp' / 'switch to notepad'.
    Acts on the app's real window and only reports success after re-checking the
    window state. Returns True when handled, None to let other handlers try."""
    text = _WINDOW_FILLER_HEAD.sub("", command.strip()).strip(" ,.!?")
    verb = None
    target = None
    m = _MINIMIZE_PATTERN.match(text)
    if m:
        verb, target = "minimize", m.group(1)
    elif _MAXIMIZE_PATTERN.match(text):
        verb, target = "maximize", _MAXIMIZE_PATTERN.match(text).group(1)
    elif _MAXIMIZE_MAKE_PATTERN.match(text):
        verb, target = "maximize", _MAXIMIZE_MAKE_PATTERN.match(text).group(1)
    elif _UNMAXIMIZE_MAKE_PATTERN.match(text):
        verb, target = "restore_down", _UNMAXIMIZE_MAKE_PATTERN.match(text).group(1)
    elif re.match(r"^(?:un-?\s?maximi[sz]e|de-?maximi[sz]e|restore\s+down)\b", text, re.I):
        verb, target = "restore_down", re.sub(r"^(?:un-?\s?maximi[sz]e|de-?maximi[sz]e|restore\s+down)\s*(?:the\s+|my\s+)?", "", text, flags=re.I)
    else:
        m = _FOCUS_BRING_PATTERN.match(text)
        if m:
            verb, target = "focus", m.group(1)
        else:
            m = _FOCUS_PATTERN.match(text)
            if m:
                verb, target = "focus", m.group(1)
    if verb is None:
        return None
    target = _WINDOW_FILLER_TAIL.sub("", target.strip()).strip(" ,.!?")
    target = _WINDOW_FILLER_TAIL.sub("", target).strip(" ,.!?")
    low = target.lower()
    if low in _WINDOW_SELF_TARGETS:
        return None          # FRIDAY's own windows keep their dedicated handling
    if friday_system_control is None:
        return None

    if verb in ("maximize", "restore_down"):
        if _MAXIMIZE_NOT_A_WINDOW.search(low):
            return None          # "maximise the volume" etc. is not about a window
        what = "that window" if low in _WINDOW_THIS_TARGETS else target
        if verb == "maximize":
            if low in _WINDOW_ALL_TARGETS:
                speak("Right away, sir.")
                result = friday_system_control.maximize_all_windows()
                what = "everything"
            else:
                result = friday_system_control.maximize_application("" if low in _WINDOW_THIS_TARGETS else target)
            log_event(f"Maximize '{what}': {result}", kind="action")
            cap = what[:1].upper() + what[1:]
            if result.get("ok"):
                if result.get("maximized"):
                    speak(f"Done, sir. {cap} is maximized." if what != "everything" else "Done, sir. Everything is maximized.")
                else:
                    speak(f"{cap} is already maximized, sir." if what != "everything" else "Everything is already maximized, sir.")
            elif result.get("error") == "not_found":
                speak(f"I couldn't find {what} open on screen, sir.")
            elif result.get("not_maximizable") and not result.get("maximized"):
                speak(f"{cap} is a fixed-size window, sir. Windows does not let it be maximized.")
            elif result.get("maximized"):
                speak(f"I maximized part of {what}, sir, but one window would not grow.")
            else:
                speak(f"I tried, sir, but {what} did not go full size. If it is running as administrator, Windows blocks me from resizing it.")
            return True
        result = friday_system_control.restore_down_application("" if low in _WINDOW_THIS_TARGETS else target)
        log_event(f"Restore down '{what}': {result}", kind="action")
        if result.get("ok"):
            speak(f"Done, sir. {what[:1].upper() + what[1:]} is back to normal size.")
        elif result.get("error") == "not_found":
            speak(f"I couldn't find {what} open on screen, sir.")
        else:
            speak(f"I tried, sir, but {what} would not return to normal size.")
        return True

    if verb == "minimize":
        if low in _WINDOW_ALL_TARGETS:
            speak("Right away, sir.")
            result = friday_system_control.minimize_all_windows()
            label = "everything"
        else:
            result = friday_system_control.minimize_application("" if low in _WINDOW_THIS_TARGETS else target)
            label = target if low not in _WINDOW_THIS_TARGETS else "that window"
        log_event(f"Minimize '{label}': {result}", kind="action")
        if result.get("ok"):
            speak(f"Done, sir. {label[:1].upper() + label[1:]} is minimized." if label != "everything"
                  else "Done, sir. Everything is minimized.")
        elif result.get("error") == "not_found":
            speak(f"I couldn't find {label} open on screen, sir.")
        elif result.get("failed") and result.get("minimized"):
            speak(f"I minimized part of {label}, sir, but one window would not go down.")
        else:
            speak(f"I tried, sir, but {label} is still on screen. Windows did not let me minimize it.")
        return True

    # focus / go back to an app that is already open
    if low in _WINDOW_PREVIOUS_TARGETS:
        result = friday_system_control.focus_previous_window()
        label = "the previous window"
    else:
        if low in _WINDOW_THIS_TARGETS or low in _WINDOW_ALL_TARGETS:
            return None
        result = friday_system_control.focus_application(target)
        label = target
    log_event(f"Focus '{label}': {result}", kind="action")
    if result.get("ok"):
        if label == "the previous window":
            speak("Done, sir. I've switched back.")
        else:
            speak(f"Done, sir. {label[:1].upper() + label[1:]} is in front.")
        return True
    if result.get("error") == "not_found":
        if label == "the previous window":
            speak("There is no other window to go back to, sir.")
            return True
        # Not an open app (e.g. "switch to dark mode"): let the normal handlers deal with it.
        return None
    speak(f"I found {label}, sir, but Windows would not bring it to the front.")
    return True


def try_handle_system_control(command):
    """Returns True/False (already spoken) if this command was a
    close-app / close-tabs request, otherwise None so handle_command
    keeps falling through as before."""

    window_result = try_handle_window_control(command)
    if window_result is not None:
        return window_result

    tabs_match = _TABS_PATTERN.match(command)
    if tabs_match:
        count_raw = tabs_match.group(1)
        count = _NUMBER_WORDS.get(count_raw, None)
        if count is None:
            try:
                count = int(count_raw)
            except ValueError:
                count = 1
        # "accept the chatgpt tab" is voice-recognition mishearing
        # "except the chatgpt tab" -- both are accepted above.
        keep_raw = tabs_match.group(2)
        keep_keywords = [keep_raw.strip()] if keep_raw else None
        speak(f"Right away, sir. Closing {count} tab{'s' if count != 1 else ''}"
              + (f", keeping the {keep_raw.strip()} tab open." if keep_raw else "."))
        result = friday_system_control.close_browser_tabs(count, keep_keywords=keep_keywords)
        if result.get("ok") and result.get("verified"):
            closed = result.get("closed_count", 0)
            speak(f"Done, sir. I verified the requested {closed} tab{'s' if closed != 1 else ''} closed.")
        elif result.get("ok"):
            closed = result.get("closed_count", 0)
            speak(f"I executed the tab-close operation, sir, and observed {closed} close action{'s' if closed != 1 else ''}, but I could not fully verify the requested final tab state.")
        else:
            err = result.get("error")
            if err == "browser_not_found":
                speak("I couldn't find an open browser window to act on, sir.")
            else:
                speak("I wasn't able to close those tabs, sir -- the automation didn't go through. You may need to close them manually.")
        return True

    app_match = _APP_CLOSE_PATTERN.match(command)
    if app_match:
        target = app_match.group(1).strip()
        # Spoken commands commonly end with polite filler.  It is not part of
        # the application name: "close WhatsApp for me" must resolve to
        # WhatsApp, not an app literally called "WhatsApp for me".
        target = re.sub(
            r"\s+(?:for me|please|right now|now|sir|thanks|thank you)\s*$",
            "", target, flags=re.I,
        ).strip(" ,.!?")
        if not target or any(ex == target.lower() for ex in _SYSTEM_CONTROL_EXCLUDED_TARGETS):
            return None
        # Don't hijack "close <n> tabs" if the tabs pattern above
        # somehow didn't match a slightly different phrasing of it.
        if "tab" in target:
            return None
        speak(f"Right away, sir. Closing {target}.")
        result = friday_system_control.close_application(target)
        if result.get("ok"):
            speak(f"Done, sir. {target.capitalize()} is closed.")
        elif result.get("error") == "not_found":
            speak(f"I couldn't find {target} running, sir.")
        else:
            still_open = result.get("still_open") or []
            if still_open:
                speak(f"I tried, sir, but {target} is still open. It may be waiting on an unsaved-changes prompt.")
            else:
                speak(f"I wasn't able to close {target}, sir. You may need to close it manually.")
        return True

    return None


def friday_health_report():
    report = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "gemini_ready": bool(client is not None),
        "study_mode": False,
        "attached_study_documents": 0,
        "reliability_metrics": health_snapshot(),
    }
    print("FRIDAY_HEALTH::" + json.dumps(report, ensure_ascii=False), flush=True)
    return report


# ============================================================
# V2044 UNIVERSAL "OPEN <ANY APP>" + GROUNDED AI ACTION ROUTER
# ------------------------------------------------------------
# Before this, FRIDAY could only open the few programs hard-coded in
# friday_desktop_agent.APP_ALIASES; every other "open X" fell through to the AI chat
# model, which answered that it could not. friday_app_launcher indexes everything
# installed (Start menu, Store apps, App Paths, Windows tools, Settings pages, folders)
# and friday_nlu.parse_open_target() understands the request. Websites that have no
# installed app fall back to opening in Chrome.
# ============================================================
_WEB_FALLBACKS = {
    # name -> (url, has_web_version_of_an_app)
    "discord": ("https://discord.com/app", True), "telegram": ("https://web.telegram.org", True),
    "slack": ("https://app.slack.com", True), "teams": ("https://teams.microsoft.com", True),
    "notion": ("https://www.notion.so", True), "figma": ("https://www.figma.com", True),
    "canva": ("https://www.canva.com", True), "zoom": ("https://zoom.us/join", True),
    "instagram": ("https://www.instagram.com", False), "facebook": ("https://www.facebook.com", False),
    "reddit": ("https://www.reddit.com", False), "twitter": ("https://twitter.com", False),
    "x": ("https://x.com", False), "linkedin": ("https://www.linkedin.com", False),
    "netflix": ("https://www.netflix.com", False), "amazon": ("https://www.amazon.com", False),
    "github": ("https://github.com", False), "stackoverflow": ("https://stackoverflow.com", False),
    "stack overflow": ("https://stackoverflow.com", False), "wikipedia": ("https://www.wikipedia.org", False),
    "pinterest": ("https://www.pinterest.com", False), "twitch": ("https://www.twitch.tv", False),
    "tiktok": ("https://www.tiktok.com", False), "ebay": ("https://www.ebay.com", False),
    "google maps": ("https://maps.google.com", False), "maps": ("https://maps.google.com", False),
    "google drive": ("https://drive.google.com", False), "drive": ("https://drive.google.com", False),
    "google docs": ("https://docs.google.com", False), "google sheets": ("https://sheets.google.com", False),
    "google slides": ("https://slides.google.com", False), "google translate": ("https://translate.google.com", False),
    "translate": ("https://translate.google.com", False), "google calendar": ("https://calendar.google.com", False),
    "calendar": ("https://calendar.google.com", False), "google meet": ("https://meet.google.com", False),
    "google classroom": ("https://classroom.google.com", False), "classroom": ("https://classroom.google.com", False),
}


# V3.1: when an app is not installed, FRIDAY opens its website in Chrome instead of just apologising.
_WEB_EXTRA = {
    "claude": "https://claude.ai", "claude ai": "https://claude.ai", "chatgpt": "https://chatgpt.com", "chat gpt": "https://chatgpt.com",
    "gemini": "https://gemini.google.com", "copilot": "https://copilot.microsoft.com", "perplexity": "https://www.perplexity.ai",
    "youtube": "https://www.youtube.com", "gmail": "https://mail.google.com", "google": "https://www.google.com",
    "outlook": "https://outlook.live.com", "whatsapp": "https://web.whatsapp.com", "spotify": "https://open.spotify.com",
    "onedrive": "https://onedrive.live.com", "dropbox": "https://www.dropbox.com", "trello": "https://trello.com",
    "asana": "https://app.asana.com", "photopea": "https://www.photopea.com", "overleaf": "https://www.overleaf.com",
    "geogebra": "https://www.geogebra.org", "desmos": "https://www.desmos.com/calculator", "wolfram alpha": "https://www.wolframalpha.com",
    "wolframalpha": "https://www.wolframalpha.com", "quizlet": "https://quizlet.com", "kahoot": "https://kahoot.it",
    "khan academy": "https://www.khanacademy.org", "coursera": "https://www.coursera.org", "udemy": "https://www.udemy.com",
    "duolingo": "https://www.duolingo.com", "grammarly": "https://app.grammarly.com", "deepl": "https://www.deepl.com",
    "paypal": "https://www.paypal.com", "uber": "https://www.uber.com", "airbnb": "https://www.airbnb.com", "booking": "https://www.booking.com",
    "tumblr": "https://www.tumblr.com", "quora": "https://www.quora.com", "medium": "https://medium.com", "bing": "https://www.bing.com",
    "duckduckgo": "https://duckduckgo.com", "snapchat": "https://web.snapchat.com", "messenger": "https://www.messenger.com",
    "disney plus": "https://www.disneyplus.com", "prime video": "https://www.primevideo.com", "hulu": "https://www.hulu.com",
    "soundcloud": "https://soundcloud.com", "vimeo": "https://vimeo.com", "imdb": "https://www.imdb.com", "github": "https://github.com",
}


_OPEN_FILE_VERB = re.compile(
    r"^(?:(?:hey\s+)?friday[, ]*)?(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?"
    r"(open|launch|show(?:\s+me)?|pull\s+up|bring\s+up|find|locate|get|look\s+for)\s+(?:me\s+)?(.+?)\s*$", re.I)
_FILE_INTENT_EXTRA = re.compile(r"\b(?:resume|cv|homework|notes?|assignments?|invoices?|receipts?|certificates?|syllabus|timetable|screenshots?)\b", re.I)


def _open_file_hit(query, allow_low=False):
    """V7.0: find the user's own file for a spoken name and open it.
    True = handled (opened, or the user was asked which one); None = no usable match, the caller carries on as before."""
    if friday_filesearch7 is None:
        return None
    try:
        hit = friday_filesearch7.best(query)
    except Exception as error:
        log_event(f"File finder failed safely: {error}", kind="recovery")
        return None
    if not hit:
        return None
    name = friday_filesearch7.spoken_name(hit)
    if hit.get("confidence") == "low":
        if not allow_low:
            return None
        options = [name] + [os.path.splitext(a)[0].replace("_", " ") for a in hit.get("alternatives", [])[:2]]
        speak("I'm not sure which file you mean, sir. Did you mean " + ", or ".join(options) + "?")
        return True
    req = hit.get("request") or {}
    ties = 0 if req.get("recent") else int(hit.get("ties") or 0)
    what = "folder" if hit.get("isdir") else "file"
    if ties:
        speak(f"I found {ties + 1} {what}s that match, sir. Opening the most recent one, {name}.")
    else:
        speak(f"I found {name}. Opening it.")
    log_event(f"Open {what} '{query}' -> {hit['path']} ({hit.get('confidence')}, score {hit.get('score')})", kind="action")
    try:
        os.startfile(hit["path"])
    except Exception as error:
        print("Could not open file:", error)
        if not friday_filesearch7.open_path(hit["path"]):
            speak(f"I found the {what}, but I could not open it.")
    return True


def try_handle_open_file(command):
    """V7.0: "open my physics notes" / "open resume pdf" / "show me the invoice file" -> the file, never a website.
    Runs after the app handler declined.  Only acts on a confident match; otherwise returns None and nothing changes."""
    if friday_filesearch7 is None:
        return None
    text = str(command or "").strip().strip(" .!?")
    m = _OPEN_FILE_VERB.match(text)
    if not m:
        return None
    verb = re.sub(r"\s+", " ", m.group(1).lower())
    rest = m.group(2).strip(" ,.;:!?\"'")
    low = rest.lower()
    if not low or len(low.split()) > 9:
        return None
    if re.search(r"\s(?:and|then|also|after that|plus)\s|[,;]", low):
        return None
    if friday_nlu is not None:
        try:
            if low in friday_nlu._FRIDAY_INTERNAL or friday_nlu._URLISH.search(low) or friday_nlu._SPECIAL_FOLDER.match(low):
                return None
        except Exception:
            pass
    if re.match(r"^(?:new\s+)?(?:tab|tabs|window|windows)$", low):
        return None
    req = friday_filesearch7.parse_request(rest)
    explicit = bool(req["file_intent"] or _FILE_INTENT_EXTRA.search(low))
    if verb not in ("open", "launch") and not explicit:
        return None          # "show me the news" / "get the weather" are not file requests
    return _open_file_hit(rest, allow_low=explicit)


def _website_for_app(target):
    """(url, exact) for an app name that is not installed. Known sites (spelling-tolerant) open directly;
    anything else becomes a Google search for the official website."""
    import difflib
    from urllib.parse import quote_plus
    name = re.sub(r"[^a-z0-9 ]+", " ", str(target or "").lower())
    name = re.sub(r"\b(?:the|app|application|website|web|site|in chrome|on chrome|for me|please)\b", " ", name)
    name = re.sub(r"\s+", " ", name).strip()
    if not name:
        return None, False
    table = {k: v[0] for k, v in _WEB_FALLBACKS.items()}
    table.update(_WEB_EXTRA)
    if name in table:
        return table[name], True
    squashed = name.replace(" ", "")
    for key, url in table.items():
        if key.replace(" ", "") == squashed:
            return url, True
    close = difflib.get_close_matches(name, list(table), n=1, cutoff=0.78)
    if close:
        return table[close[0]], True
    return "https://www.google.com/search?q=" + quote_plus(name + " official website"), False


def _open_app_by_name(target, strict=True):
    """Open an installed program by (spoken) name. Returns True when the request was handled
    (successfully or not - the user has been told), None to let other handlers try."""
    if friday_app_launcher is None:
        return None
    try:
        resolution = friday_app_launcher.resolve(target)
    except Exception as error:
        print("App resolve error:", error)
        return None
    # Loose verbs ("start", "run") are also used for non-app requests ("start studying"), so they
    # only act on a very confident match; an explicit "open"/"launch" accepts the normal threshold.
    needed = friday_app_launcher.ACCEPT_SCORE if strict else 0.9
    if resolution.entry is None or resolution.score < needed:
        if not strict:
            return None
        # V3.1: no installed app by that name -> open its website in Google Chrome.
        site_url, _exact = _website_for_app(target)
        # V7.0: but a spoken FILE name ("open physics notes") must open the file. Known apps/sites (exact) are unchanged.
        if not _exact:
            _file_first = _open_file_hit(target)
            if _file_first is not None:
                return _file_first
        if site_url:
            pretty = str(target).strip().title()
            speak(f"{pretty} isn't installed on this computer, sir, so I'll open its website in Chrome.")
            open_website(pretty, site_url)
            return True
        speak(f"I couldn't find an application called {target} on this computer, sir.")
        return True
    entry = resolution.entry
    try:
        outcome = friday_app_launcher.launch_entry(entry)
    except Exception as error:
        print("App launch error:", error)
        outcome = {"ok": False, "executed": False, "error": str(error)}
    log_event(f"Open app '{target}' -> {entry.name}: {outcome}", kind="action")
    if outcome.get("ok"):
        speak(f"{entry.name} is open, sir.")
    elif outcome.get("executed"):
        speak(f"I asked Windows to open {entry.name}, sir, but I could not confirm that its window appeared.")
    else:
        speak(f"I could not launch {entry.name}, sir. Windows refused the request.")
    return True


def try_handle_open_app(original_command):
    """'open discord' / 'launch vs code' / 'can you open microsoft word please'."""
    if friday_nlu is None or friday_app_launcher is None:
        return None
    try:
        intent = friday_nlu.parse_open_target(original_command)
    except Exception as error:
        print("NLU open parse error (falling back):", error)
        return None
    if intent is None:
        return None
    return _open_app_by_name(intent.target, strict=intent.strict)


def _llm_route_action(original_command):
    """Last-chance smart routing for an action request the strict parsers did not understand.
    Gemini only SEGMENTS the user's own words; friday_nlu.llm_route verifies every field against the
    original text, so it can never invent a message, a contact or a search query."""
    if friday_nlu is None or not friday_nlu.looks_actionable(original_command):
        return None
    _ensure_gemini_client()
    if client is None:
        return None

    def _generate(prompt):
        # V7.2 SPEED: bounded wait. A slow router call used to hold up the whole reply with no limit.
        global _INTENT_POOL
        if _INTENT_POOL is None:
            import concurrent.futures as _cf
            _INTENT_POOL = _cf.ThreadPoolExecutor(max_workers=3, thread_name_prefix="FridayFast")
        _fut = _INTENT_POOL.submit(lambda: _response_text(_gemini_generate(prompt, retries=1)))
        return _fut.result(timeout=float(os.getenv("FRIDAY_ROUTER_TIMEOUT", "1.6")))

    try:
        routed = friday_nlu.llm_route(original_command, _generate)
    except Exception as error:
        print("AI action router error (ignored):", error)
        return None
    if routed is None:
        return None
    log_event(f"AI action router: {routed}", kind="action")
    if routed.action == "send_message":
        contact, confidence = _wa_resolve_contact_name(routed.contact, original_command)
        if not contact:
            return None
        global _wa_session
        if routed.message:
            if confidence == "low":
                _wa_session = {"stage": "await_spelling", "pending_message": routed.message}
                _wa_ask_to_spell(contact)
                return True
            return _wa_begin_confirm(contact, routed.message)
        if confidence == "low":
            _wa_session = {"stage": "await_spelling"}
            _wa_ask_to_spell(contact)
            return True
        _wa_session = {"stage": "await_message", "contact": contact}
        speak(f"What would you like to say to {contact}?")
        return True
    if routed.action == "open_app":
        return _open_app_by_name(routed.app, strict=True)
    if routed.action == "web_search":
        return google_search("search for " + routed.query)
    return None


def handle_command(original_command):
    command = original_command.lower().strip()

    # Event stream + situational awareness -- see the block near the
    # top of this file. Logged once per command rather than
    # continuously so the feed reflects real activity, not noise.
    if command:
        log_event(f"Heard: \"{original_command.strip()}\"", kind="input")
    try:
        _maybe_log_window_change()
    except Exception:
        pass

    # V2050: WhatsApp calls -- a ringing-call question ("shall I answer it?")
    # and an in-progress "call <name>" flow are live pending conversations, and
    # "call <name> [on WhatsApp]" / "answer the call" / "hang up" start or
    # control one. Returns None quickly for everything else.
    whatsapp_call_result = handle_whatsapp_call_command(original_command.strip())
    if whatsapp_call_result is not None:
        return whatsapp_call_result

    # V2045 (previously never hooked up): resolves "a new file was downloaded,
    # would you like me to open it?". Returns None when nothing is pending.
    download_continuation_result = handle_download_continuation(original_command.strip())
    if download_continuation_result is not None:
        return download_continuation_result

    # An incoming-WhatsApp "would you like to reply?" question takes the
    # very top priority: it's a live pending question, so whatever the
    # user says next must be read as the answer to THAT, not anything else.
    whatsapp_incoming_continuation = handle_whatsapp_incoming_continuation(original_command.strip())
    if whatsapp_incoming_continuation is not None:
        return whatsapp_incoming_continuation

    # Building the contacts list ("save contact Sarah Khan") also
    # takes top priority so it's never misread as anything else.
    contact_management_result = handle_contact_management(original_command.strip())
    if contact_management_result is not None:
        return contact_management_result

    # WHATSAPP HAS TOP PRIORITY: if a message flow is already waiting
    # on a contact name, a message body, or a send/cancel decision,
    # THIS command is that answer -- it must not be reinterpreted by
    # anything below (study mode, downloads, Gemini, etc). Uses the
    # original-cased text so contact names/messages keep their casing.
    whatsapp_continuation = handle_whatsapp_continuation(original_command.strip())
    if whatsapp_continuation is not None:
        return whatsapp_continuation

    # Starting a brand-new WhatsApp request also takes priority over
    # everything else so "send whatsapp..." is never swallowed by the
    # Gemini AI fallback or another handler below.
    whatsapp_start = handle_whatsapp_start(original_command.strip())
    if whatsapp_start is not None:
        return whatsapp_start

    # V2048: lets the user actually ask why incoming-WhatsApp notifications
    # aren't working, instead of the feature just silently never firing.
    if re.search(r"\b(whatsapp)\b.*\b(working|watch(?:er|ing)?|notif\w*)\b", command) and \
       re.search(r"\b(why|is|status|check|isn'?t|not)\b", command):
        try:
            import friday_whatsapp_watch
            status = friday_whatsapp_watch.whatsapp_watch_status()
        except Exception as status_error:
            status = {"started": False, "active": False, "disabled_reason": str(status_error)}
        if status.get("active"):
            speak("Yes sir, I'm watching for incoming WhatsApp messages.")
        elif status.get("disabled_reason"):
            speak(status["disabled_reason"])
        else:
            speak("The WhatsApp watcher hasn't started yet, sir.")
        return True

    # ------------------------------------------------------------
    # STUDY PLANS & REMINDERS -- deliberately checked here, BEFORE the
    # study-mode gate further down, so "add" access to plans works
    # from the normal dashboard exactly the same as from inside Study
    # Mode itself (this is the "give Friday in normal mode full access
    # to study mode" behaviour): "I have to complete internet by next
    # week" is understood and saved whether or not Study Mode is on.
    # ------------------------------------------------------------
    plan_result = try_handle_plan_command(command)
    if plan_result is not None:
        return plan_result

    # ------------------------------------------------------------
    # V2045 STUDY INTELLIGENCE -- NORMAL MODE ACCESS
    # ------------------------------------------------------------
    # "The biggest change I recommend": Study Mode should not be a
    # separate brain -- normal FRIDAY should be able to reach into the
    # same mastery/mistake data at any time, not only while Study Mode
    # is open. Checked here (same tier as plans above), BEFORE the
    # study-mode gate further down, so every phrase below works
    # identically whether Study Mode is on or off.
    # ------------------------------------------------------------
    si_result = try_handle_study_intelligence_command(original_command.strip())
    if si_result is not None:
        return si_result

    # V2049: direct access to the full long-term memory store, rather
    # than only ever surfacing the handful of facts retrieve_relevant()
    # judges relevant to whatever the current question happens to be.
    if re.search(r"\b(what|everything)\b.*\byou\b.*\b(know|remember)\b.*\b(about me|about us)?\b", command) and \
       ("know" in command or "remember" in command):
        try:
            facts = friday_context.all_known_facts()
        except Exception:
            facts = []
        if not facts:
            speak("I don't have anything stored in long-term memory about you yet, sir.")
        else:
            for f in facts:
                print("FRIDAY_KNOWN_FACT::" + json.dumps(f, ensure_ascii=False))
            preview = "; ".join(f["content"] for f in facts[:5])
            more = f", and {len(facts) - 5} more" if len(facts) > 5 else ""
            speak(f"Here's what I have on record, sir: {preview}{more}.")
        return True

    # V2045: "who is your creator" / "who made you". Checked at top
    # priority (same tier as everything above) so it can never be
    # accidentally swallowed by the Gemini fallback further down and
    # answered with something generic/wrong. friday_persona.line("creator")
    # already avoids repeating its own immediately-previous phrasing;
    # this also skips the AI path entirely so the underlying facts
    # themselves are never at risk of drifting between calls.
    if re.search(r"\bwho\s+(?:is|are|was)\s+(?:your|ur|friday'?s?)\s+(?:creator|maker|developer|programmer|author)\b", command) \
       or re.search(r"\bwho\s+(?:made|built|created|designed|programmed|coded|developed)\s+(?:you|friday)\b", command) \
       or re.search(r"\bwho\s+is\s+mittun\b", command) \
       or command.strip() in ("who is your creator", "who is your creator?", "tell me about your creator", "tell me about mittun"):
        speak(friday_persona.line("creator"))
        return True

    # ------------------------------------------------------------
    # SITUATIONAL AWARENESS -- direct query. Full access (works in
    # or out of study mode) since it's simple, always-safe info.
    # ------------------------------------------------------------
    if (
        command in ("what's on my screen", "whats on my screen", "what am i looking at",
                    "what am i working on", "what's open", "whats open", "what app am i using")
        or re.search(r"\b(can you|could you|do you|are you able to)\s+(see|view|look at)\s+(my\s+)?screen\b", command, re.I)
        or re.search(r"\bwhat am i (doing|looking at|working on)\b", command, re.I)
        or re.search(r"\b(?:give|tell|show)\s+(?:me\s+)?(?:the\s+)?(?:info|information|details|description)\s+(?:on|about)\s+(?:the\s+)?(?:image|picture|photo)\b", command, re.I)
        or re.search(r"\b(?:what|whats|what's)\s+(?:is\s+)?(?:in|on)\s+(?:the\s+)?(?:image|picture|photo)\s+(?:i\s+am|im|i'm)\s+(?:seeing|looking at)\b", command, re.I)
        or re.search(r"\b(?:describe|analyze|inspect|read)\s+(?:the\s+)?(?:image|picture|photo)\s+(?:i\s+am|im|i'm)\s+(?:seeing|looking at)\b", command, re.I)
    ):
        try:
            from friday_screen_intelligence import inspect_screen
            screen_result = inspect_screen(use_semantic_vision=True)
            if screen_result.get("ok"):
                speak(screen_result.get("summary") or "I inspected the screen, sir.")
            else:
                title = get_active_window_title()
                speak(f"I could not inspect the screen. The active window is {title or 'unknown'}, sir.")
        except Exception as exc:
            title = get_active_window_title()
            speak(f"I could not inspect the screen right now. The active window is {title or 'unknown'}, sir.")
            log_event(f"Screen intelligence fallback: {exc}", kind="recovery")
        return True

    # ------------------------------------------------------------
    # AI NOTES GENERATOR -- same "full access regardless of study
    # mode" treatment as plans above: the Notes page's own buttons
    # send the structured "generate notes::" / "scan notes image::"
    # forms below, but a plain typed/spoken "create notes on X" works
    # too, in or out of Study Mode.
    # ------------------------------------------------------------
    if command.startswith("generate notes::"):
        payload = original_command[len("generate notes::"):]
        parts = payload.split("||")
        note_subject = parts[0].strip() if len(parts) > 0 else "general"
        note_topic = parts[1].strip() if len(parts) > 1 else ""
        note_attach = parts[2].strip() if len(parts) > 2 else ""
        return study_generate_notes(note_subject, note_topic, note_attach)

    if command.startswith("scan notes image::"):
        payload = original_command[len("scan notes image::"):]
        parts = payload.split("||")
        scan_subject = parts[0].strip() if len(parts) > 0 else "general"
        scan_topic = parts[1].strip() if len(parts) > 1 else "Scanned Notes"
        scan_paths = [p.strip() for p in (parts[2].split("|") if len(parts) > 2 else []) if p.strip()]
        return study_scan_notes_images(scan_subject, scan_topic, scan_paths)

    # Natural voice variants are intentionally accepted here, including
    # "create me short notes on orbitals", "make short notes for...",
    # and "generate concise notes about...". The size adjective is a
    # request for note style, not part of the topic.
    notes_phrase_match = re.match(
        r"^(?:create|make|generate|design|write|build)(?:\s+me)?\s+(?:(?:some|a\s+set\s+of)\s+)?(?:short|concise|brief|quick|detailed|exam[- ]focused)?\s*notes\s+(?:for|on|about)\s+(.+)$", command
    ) or re.match(
        r"^(?:i need|i want|can you (?:make|create|write|generate))(?:\s+me)?\s+(?:(?:some|a\s+set\s+of)\s+)?(?:short|concise|brief|quick|detailed|exam[- ]focused)?\s*notes\s+(?:for|on|about)\s+(.+)$", command
    ) or re.match(
        r"^notes\s+(?:for|on|about)\s+(.+?)\s+please$", command
    )
    if notes_phrase_match:
        return study_generate_notes(study_state.get("subject") or "general", notes_phrase_match.group(1).strip())

    # ------------------------------------------------------------
    # QUICK-NOTE SYNC -- structured message the Notes tab's own
    # "Save Note" button sends (see index.html's addNote()) so a
    # plain typed/spoken text note is mirrored into
    # study_files/quick_notes.json. Without this, those notes only
    # ever existed in the browser iframe's own localStorage, which
    # this Python backend has NO way to read -- so a later "what
    # notes do I have on X" would have nothing real to answer from.
    # Silent (no speak()) since the UI already confirms the save.
    # ------------------------------------------------------------
    if command.startswith("save quick note::"):
        payload = original_command[len("save quick note::"):]
        parts = payload.split("||", 1)
        qn_subject = parts[0].strip() if len(parts) > 0 else "general"
        qn_text = parts[1].strip() if len(parts) > 1 else ""
        if qn_text:
            friday_notes_engine.save_quick_note(qn_subject, qn_text)
        return True

    # ------------------------------------------------------------
    # NOTES QUERY -- "what notes do I have", "show my notes on X",
    # "do I have notes on X", etc. Answers from BOTH quick_notes.json
    # (plain text notes, synced above) and notes_index.json (the AI
    # Notes Generator's PDFs) so Friday never has to fall back to a
    # generic "I don't currently have access to your notes" answer --
    # it genuinely does have access to both, and says so accurately
    # (including when there's honestly nothing found yet).
    # ------------------------------------------------------------
    notes_query_match = None
    for pattern in _NOTES_QUERY_PATTERNS:
        m = pattern.match(command)
        if m:
            notes_query_match = m
            break
    if notes_query_match is not None:
        needle = None
        if notes_query_match.lastindex:
            needle = (notes_query_match.group(1) or "").strip()
        return try_handle_notes_query(needle)

    # ============================================================
    # CREATION ENGINE + WEB RESEARCH take priority over the download
    # handler and the generic Gemini fallback below. This must run
    # BEFORE handle_download_request(): that handler's catch-all
    # phrase list includes the bare word "download", which is also a
    # substring of "downloads" -- so "create a folder ... in
    # downloads" would otherwise be swallowed by the download handler
    # before ever reaching the Creation Engine.
    #
    # Matched by (action verb) + (subject noun) pairs rather than long
    # lists of exact whole phrases, so natural variations like "make
    # ME a presentation about X" or "can you build a slideshow on X"
    # are caught here directly -- without even needing the Gemini
    # fallback layer below (though that layer, via the new
    # live_information_request / create_presentation intent labels,
    # is exactly what would catch anything worded even more loosely
    # than these still-catch).
    #
    # Deliberately still keyword-anchored (not left to fuzzy
    # classification alone) since these write files to disk -- a
    # clear action verb + a clear subject noun must BOTH be present,
    # same caution the rest of this function already applies to
    # downloads/shutdown/etc.
    # ============================================================
    # ------------------------------------------------------------
    # PROACTIVE CONTEXT / REFERENCE RESOLUTION (see friday_context.py)
    # ------------------------------------------------------------
    # Applied ONLY here, to feed the Creation Engine / Web Research
    # checks below and the Gemini intent classifier further down --
    # every branch ABOVE this point (contact management, WhatsApp
    # continuation/start, and anything else already handled and
    # returned by now) has already seen the command completely
    # unchanged, exactly as before. This resolves things like "make
    # it into slides" or "compare the prices" against whatever Friday
    # was just doing, so a bare pronoun becomes a self-contained
    # sentence before it ever reaches a keyword check or Gemini.
    # Degrades to the command verbatim (see friday_context.resolve's
    # own docstring) whenever there's no fresh context to resolve
    # against, so this can only ever ADD understanding, never change
    # how an already-working phrasing is handled.
    _context_resolution = friday_context.resolve(original_command)
    if not _context_resolution.get("rewritten"):
        persistent_resolution = friday_context.resolve_persistent(original_command)
        if persistent_resolution.get("rewritten"):
            _context_resolution = persistent_resolution
    resolved_original_command = _context_resolution["command"]
    resolved_command = resolved_original_command.lower().strip()

    _CREATE_VERBS = ("create", "make", "build", "generate", "put together", "prepare", "draft")
    _FOLDER_NOUNS = ("folder", "directory")
    _PRESENTATION_NOUNS = ("presentation", "slideshow", "slide deck", "slides", "deck", "pptx")
    _DOCUMENT_NOUNS = ("word document", "docx", "report", "research notes", "document")
    _PDF_NOUNS = ("pdf",)
    _SPREADSHEET_NOUNS = ("spreadsheet", "excel sheet", "xlsx")
    _PROJECT_NOUNS = _PRESENTATION_NOUNS + _DOCUMENT_NOUNS + _PDF_NOUNS + _SPREADSHEET_NOUNS + ("project",)

    if any(v in resolved_command for v in _CREATE_VERBS) and any(n in resolved_command for n in _FOLDER_NOUNS):
        return friday_creation_engine.create_folder_command(resolved_original_command.strip())

    if any(v in resolved_command for v in _CREATE_VERBS) and any(n in resolved_command for n in _PROJECT_NOUNS):
        return friday_creation_engine.create_project_command(
            resolved_original_command.strip(),
            reuse_sources=(_context_resolution["reuse_sources"] if _context_resolution["reuse_research"] else None),
            reuse_topic=(_context_resolution["topic"] if _context_resolution["reuse_research"] else None),
        )

    _RESEARCH_VERBS_AT_START = ("research ", "look up ", "look into ", "find out ")
    _PRICE_PHRASES = (
        "find the current price of", "find the price of", "find me the price of",
        "find me the cheapest", "find the cheapest", "check the price of",
        "how much is a", "how much does a", "how much are",
        "current exchange rate", "current price of",
    )
    if any(resolved_command.startswith(p) for p in _RESEARCH_VERBS_AT_START) or any(
        phrase in resolved_command for phrase in _PRICE_PHRASES
    ):
        return handle_web_research_command(resolved_original_command.strip())

    # DOWNLOADS HAVE PRIORITY OVER THE GEMINI FALLBACK.
    download_result = handle_download_request(command)
    if download_result is not None:
        return download_result

    if command.lower().startswith("set voice rate::"):
        return set_voice_rate_command(command.split("::",1)[1])

    # BUGFIX (syllabus checklist / Diagram Lab / Explanation Centre / Past
    # Paper marking never fully working): these are all structured,
    # UI-issued markers ("syllabus_ingest::{...}", "syllabus_get::{...}",
    # "diagramlab::...", "explanation_centre::...", "pseudocode_*::...",
    # "pastpaper_mark_*::...", "speaktext::...") -- they are NEVER typed or
    # spoken by the user, only ever sent programmatically by the Study Mode
    # panels the instant a subject changes, a page loads, or a button is
    # pressed. Gating them behind `study_state.get("active")` created a
    # race: the syllabus checklist panel (and the others above) can fire
    # one of these the moment it renders, sometimes a beat before Study
    # Mode has actually flipped to "active" in the backend, so the command
    # fell straight through to the generic AI/download handlers below and
    # was silently misread or dropped -- which is exactly why "Build
    # Checklist" or a fresh subject switch could appear to do nothing.
    # These markers are unambiguous by construction, so they now always
    # reach the Study Mode handler regardless of the active flag; every
    # other Study Mode phrase (spoken or typed English) still requires
    # Study Mode to be active, exactly as before.
    _STUDY_UI_MARKER_PREFIXES = ()
    if command.startswith(_STUDY_UI_MARKER_PREFIXES):
        study_result = handle_study_command(command)
        if study_result is not None:
            return study_result

    # STUDY MODE HAS PRIORITY SO STUDY COMMANDS DO NOT FALL INTO NORMAL AI.
    if study_state.get("active"):
        study_result = handle_study_command(command)
        if study_result is not None:
            return study_result

    exit_phrases = [
        "bye", "goodbye", "good bye", "that's it for now", "thats it for now",
        "that's all for now", "thats all for now", "see you later", "see ya",
        "you can stop", "stop running", "close yourself", "exit friday", "quit friday",
        "sleep friday", "go to sleep"
    ]
    if any(phrase in command for phrase in exit_phrases):
        speak(friday_persona.line("exit"))
        print("ACTION::SHUTDOWN")
        globals()["_EXIT_REQUESTED"] = True
        return False

    # V2045 FIX: this previously only matched a few exact phrases
    # ("open settings", "show settings", ...), so anything else with
    # "settings" in it (just "settings", "change my settings", "go to
    # settings", "display settings") fell through all the way to the
    # generic "open <app>" router further below, which resolved it
    # against Windows' own installed Settings app and opened THAT
    # instead of Friday's own settings panel. Per explicit instruction,
    # ANY request that is about settings -- worded however -- opens
    # Friday's own settings, never the OS's, so this is now a broad
    # word-boundary match checked before the generic app-open router
    # ever runs. "resetting"/"upsetting" etc. don't match, since
    # \bsettings?\b requires the standalone word.
    if re.search(r"\bsettings?\b", command, re.I) or "system configuration" in command:
        speak(friday_persona.line("settings"))
        print("ACTION::OPEN_SETTINGS")
        return True

    # Voice-activated window control. main.js watches stdout for these
    # ACTION:: markers and moves the actual Electron windows around --
    # this script has no window handles itself, it just announces intent.
    minimize_phrases = [
        "minimize friday", "minimize the interface", "minimize interface",
        "minimize yourself", "hide friday", "hide the interface",
        "minimise friday", "minimise the interface", "minimise interface", "minimise yourself"
    ]
    if any(phrase in command for phrase in minimize_phrases):
        speak(friday_persona.line("minimize"))
        print("ACTION::MINIMIZE_WIDGET")
        return True

    restore_phrases = [
        "restore friday", "show friday", "show interface", "maximize friday",
        "expand friday", "open friday", "bring back friday"
    ]
    if any(phrase in command for phrase in restore_phrases):
        speak(friday_persona.line("restore"))
        print("ACTION::RESTORE_WINDOW")
        return True

    # ------------------------------------------------------------
    # REAL APPLICATION / TAB CLOSING (friday_system_control.py).
    #
    # Placed here -- AFTER exit_phrases/settings_phrases/minimize/
    # restore (so "close yourself"/"close friday"/"close settings"
    # etc. are still handled by their existing, more specific
    # branches above) but BEFORE the Gemini intent classifier and
    # ask_ai() fallback further down. Before this branch existed,
    # "close the python idle app" / "close 2 tabs" matched NOTHING
    # above and fell all the way through to ask_ai() -- a pure text
    # chat call with no tool access -- which is why Friday would
    # confidently narrate "I have terminated the process, Sir" while
    # doing nothing at all. This branch actually touches the OS and
    # only reports success once it has re-checked that the window/
    # process is genuinely gone.
    # ------------------------------------------------------------
    system_control_result = try_handle_system_control(command)
    if system_control_result is not None:
        return system_control_result

    # Start study mode even when it is currently inactive.
    if any(x in command for x in ["study mode", "start studying", "enter study mode"]):
        return study_start(command)

    weather_phrases = [
        "weather", "how's the weather", "hows the weather", "is it raining",
        "is it going to rain", "temperature outside", "how hot is it", "how cold is it"
    ]
    if any(phrase in command for phrase in weather_phrases):
        return get_weather(command)

    if "what time" in command or command == "time" or "current time" in command:
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The time is {current_time}.")
        return True

    if "what date" in command or "today's date" in command or "todays date" in command or "what day is it" in command:
        current_date = datetime.datetime.now().strftime("%A, %B %d, %Y")
        speak(f"Today is {current_date}.")
        return True

    if any(phrase in command for phrase in ["cancel shutdown", "stop shutdown", "don't shut down", "do not shut down"]):
        return cancel_shutdown()

    # V7.0: a file whose name contains a site/app word ("open youtube script", "open google project notes") is still a FILE request.
    # Single words ("open youtube") and everything else stay exactly as before.
    if friday_filesearch7 is not None and re.match(r"^(?:please\s+)?(?:open|launch)\s+", command) and re.search(r"\b(?:google|youtube|gmail|chatgpt|spotify|notepad|calculator|calc)\b", command):
        _named = re.sub(r"^(?:please\s+)?(?:open|launch)\s+(?:the\s+|my\s+)?", "", command).strip(" .!?")
        if len(_named.split()) >= 2 and not re.search(r"\s(?:and|then|also)\s|[,;]", _named):
            _named_file = _open_file_hit(_named)
            if _named_file is not None:
                return _named_file

    if "google" in command and any(word in command for word in ["open", "launch", "start"]) and not command.startswith("search"):
        return open_website("Google", "https://www.google.com")

    # OPEN WEBSITES
    if "youtube" in command and any(word in command for word in ["open", "launch", "start"]):
        return open_website("YouTube", "https://www.youtube.com")

    if any(word in command for word in ["play", "listen", "hear"]) and "youtube" in command:
        return play_youtube(command)

    if "gmail" in command and any(word in command for word in ["open", "launch", "start"]):
        return open_website("Gmail", "https://mail.google.com")

    if "chatgpt" in command and any(word in command for word in ["open", "launch", "start"]):
        return open_website("ChatGPT", "https://chatgpt.com")

    if any(phrase in command for phrase in ["recently played", "last played song", "last song", "play the last song again"]) and "spotify" in command:
        return open_recently_played()

    if "spotify" in command and any(word in command for word in ["open", "launch", "start"]) and not any(word in command for word in ["play", "listen", "hear"]):
        return open_spotify()

    if "spotify" in command and any(word in command for word in ["play", "listen", "hear"]):
        return play_spotify_song(command)

    if command.startswith("search ") or command.startswith("search for ") or ("search" in command and "google" in command):
        return google_search(command)

    if command.startswith("play ") and "spotify" not in command:
        return play_youtube(command)

    if command.startswith("wikipedia ") or command.startswith("search wikipedia ") or command.startswith("search wikipedia for "):
        return wikipedia_search(command)

    if "tell me a joke" in command or command == "joke" or "make me laugh" in command:
        return tell_joke()

    if "notepad" in command and any(word in command for word in ["open", "launch", "start"]):
        return open_notepad()

    if ("calculator" in command or "calc" in command) and any(word in command for word in ["open", "launch", "start"]):
        return open_calculator()

    if any(phrase in command for phrase in ["shut down", "shutdown", "turn off", "power off", "switch off"]) and any(word in command for word in ["computer", "laptop", "pc", "system"]):
        return shutdown_computer()

    # V2044: open ANY installed application / Windows tool / settings page / special folder.
    _open_app_result = try_handle_open_app(original_command.strip())
    if _open_app_result is not None:
        return _open_app_result

    # V7.0: "open my physics notes" / "open resume pdf" -> the file itself (fast indexed search, never a website)
    _open_file_result = try_handle_open_file(original_command.strip())
    if _open_file_result is not None:
        return _open_file_result

    if any(word in command for word in ["open", "find", "show", "get"]) and any(word in command for word in ["file", "folder", "document", "pdf", "photo", "picture", "image"]):
        return open_file(command)

    if "who are you" in command or "what are you" in command or "what is your name" in command or "what's your name" in command or "whats your name" in command or "are you gemini" in command:
        speak("I am Friday, version five. I'm your multi-tasking AI assistant. I can reason through problems, research the web, write and debug code, read the files you attach, see through your screen and camera, control your computer, remember what matters to you, and carry out multi-step tasks.")
        return True

    if "what can you do" in command or command == "help":
        speak("I can reason through hard problems, research the web, write and debug code, read and edit files you attach, create documents and presentations, open and control applications, inspect the screen and camera, diagnose your computer, manage goals and your calendar, handle WhatsApp, remember things for you, and help with your finances too.")
        return True

    # Nothing above matched via exact keywords. Before falling all the
    # way through to open-ended AI conversation, check whether this
    # was actually one of Friday's known safe commands just phrased
    # differently (see _classify_intent_with_gemini above). Classified
    # against the CONTEXT-RESOLVED command (see above) so a follow-up
    # like "compare the prices" is classified with its subject
    # restored, not as a bare, unclassifiable fragment. Any failure
    # here silently falls through to ask_ai(), unchanged.
    # V2044: grounded AI action router (messages / open app / web search phrased in ways the strict
    # parsers did not recognise). Verified against the user's own words before anything executes.
    _routed = _llm_route_action(resolved_original_command or original_command.strip())
    if _routed is not None:
        return _routed

    classified_label = _classify_intent_with_gemini(resolved_command)
    if classified_label != "none":
        dispatched = _dispatch_classified_intent(
            classified_label, resolved_command, resolved_original_command,
            reuse_sources=(_context_resolution["reuse_sources"] if _context_resolution["reuse_research"] else None),
            reuse_topic=(_context_resolution["topic"] if _context_resolution["reuse_research"] else None),
        )
        if dispatched is not None:
            return dispatched

    return None



# ============================================================
# SPOKEN SYMBOL / HUMAN LANGUAGE NORMALIZATION
# ============================================================
def normalize_human_command(text: str) -> str:
    """Normalize common spoken/typed symbols without damaging URLs or paths.

    Examples:
      "A / B" -> "A or B"
      "A slash B" -> "A or B"
      "and/or" -> "and or"
      "A & B" -> "A and B"

    URL/path tokens such as https://... and C:/... are intentionally left alone.
    """
    s = str(text or "").strip()
    if not s:
        return s

    protected: list[str] = []
    def protect(m):
        protected.append(m.group(0))
        return f"__FRIDAY_PROTECTED_{len(protected)-1}__"

    # Protect URLs, Windows paths, and the special and/or construction first.
    s = re.sub(r"https?://\S+|[A-Za-z]:[\\/]\S+", protect, s, flags=re.I)
    s = re.sub(r"\band\s*/\s*or\b|\band/or\b", "and or", s, flags=re.I)

    # Spoken slash between alphabetic terms is normally an alternative.
    s = re.sub(r"\b([A-Za-z][\w-]*)\s+(?:slash|/)\s+([A-Za-z][\w-]*)\b",
               r"\1 or \2", s, flags=re.I)
    s = re.sub(r"\b([A-Za-z][\w-]*)\s*/\s*([A-Za-z][\w-]*)\b",
               r"\1 or \2", s)
    # Ampersand between words.
    s = re.sub(r"\b([A-Za-z][\w-]*)\s*&\s*([A-Za-z][\w-]*)\b",
               r"\1 and \2", s)

    for i, value in enumerate(protected):
        s = s.replace(f"__FRIDAY_PROTECTED_{i}__", value)
    return re.sub(r"\s{2,}", " ", s).strip()

# ============================================================
# PROCESS ONE COMMAND
# ============================================================

# Voice input (listen(), on the main thread) and UI-driven input (the
# stdin command thread below, used by the Electron buttons/typed
# commands) both end up calling process_command() and touching the
# same study_state / study_memory dictionaries. This lock just keeps
# the two from stepping on each other if a button is pressed at the
# exact moment a voice command is being handled.
_COMMAND_LOCK = threading.Lock()
_PENDING_PERMISSION_ACTION = None


def _zoom_notes_precheck(command):
    """Route Zoom Note-Taking Mode before every other intent layer.

    This is intentionally early: while a capture session is active, the
    explicit stop phrase must reach the session controller rather than being
    swallowed by the normal AI/chat router.
    """
    if globals().get("_ZOOM_NOTES_MISSING"):
        return False          # V7.4: the optional Zoom notes module is not in this package; skip it without a failed import on every command
    try:
        result = friday_zoom_notes.handle_command(command)
        return result is not None
    except ModuleNotFoundError:
        globals()["_ZOOM_NOTES_MISSING"] = True
        return False
    except Exception as error:
        log_event(f"Zoom Note-Taking Mode routing failed: {error}", kind="recovery")
        return False


def _screen_awareness_precheck(command):
    try:
        from friday_screen_intelligence import is_awareness_start_intent,is_awareness_stop_intent,is_screen_intent,start_awareness,stop_awareness,inspect_screen
        if is_awareness_start_intent(command):
            start_awareness(interval=2.5,semantic=False); speak("Continuous screen awareness is now active, sir."); return True
        if is_awareness_stop_intent(command):
            stop_awareness(); speak("Screen awareness is now off, sir."); return True
        if is_screen_intent(command):
            r=inspect_screen(use_semantic_vision=True)
            speak(r.get("summary") if r.get("ok") else "I could not inspect the screen right now, sir."); return True
    except Exception:
        pass
    return False


def _command_result_to_continue(result):
    """Translate a handle_command() result into process_command()'s "keep running?" answer.
    False means "exit" ONLY when an explicit goodbye set _EXIT_REQUESTED; a handler that merely
    failed (an app would not open) has already told the user and must not stop FRIDAY."""
    if result is False:
        if globals().get("_EXIT_REQUESTED"):
            globals()["_EXIT_REQUESTED"] = False
            return False
        return True
    return bool(result)


# ============================================================
# V7.2 INSTANT SMALL TALK (same mechanism as JARVIS V2339)
# ============================================================
# Greetings, thanks and "how are you" used to travel through every routing layer and a model call. They are answered here
# locally in a few milliseconds, in a natural varied voice, and are recorded in the conversation so follow-ups still make sense.
_ST_WRAP = r"(?:(?:hey|hi|ok|okay|so|well|um|uh)[, ]+)?(?:friday[, ]+)?"
_ST_TAIL = r"(?:[, ]+(?:friday|sir|buddy|man|bro|mate|please))*[.!? ]*"
_ST_PATTERNS = [
    ("thanks", re.compile(r"^" + _ST_WRAP + r"(?:thanks|thank you|thank u|thx|cheers|many thanks|appreciate it|i appreciate it|thanks a lot|thanks so much|thank you so much|thanks a bunch|thank you very much)" + _ST_TAIL + r"$", re.I)),
    ("how_are_you", re.compile(r"^" + _ST_WRAP + r"(?:how are you(?: doing| today| feeling)?|how are you going|how(?:'| i)?s it going|how(?:'| i)?s everything|how do you do|what(?:'| i)?s up|whats up|sup|how have you been)" + _ST_TAIL + r"$", re.I)),
    ("good_morning", re.compile(r"^" + _ST_WRAP + r"good morning(?: to you)?" + _ST_TAIL + r"$", re.I)),
    ("good_afternoon", re.compile(r"^" + _ST_WRAP + r"good afternoon" + _ST_TAIL + r"$", re.I)),
    ("good_evening", re.compile(r"^" + _ST_WRAP + r"good evening" + _ST_TAIL + r"$", re.I)),
    ("good_night", re.compile(r"^" + _ST_WRAP + r"good night" + _ST_TAIL + r"$", re.I)),
    ("hello", re.compile(r"^(?:(?:hey|hi|hello|hola|yo|howdy|hiya|heya)(?:[, ]+(?:there|friday|buddy|man|bro|mate|sir))*)[.!? ]*$", re.I)),
    ("there", re.compile(r"^" + _ST_WRAP + r"(?:are you (?:there|up|awake|listening|with me)|you there|can you hear me|do you hear me|hello are you there)" + _ST_TAIL + r"$", re.I)),
    ("nice", re.compile(r"^" + _ST_WRAP + r"(?:nice|great|awesome|perfect|cool|good job|well done|nice one|great job|amazing|brilliant|that'?s great|that'?s awesome|that was great|love it|wow)" + _ST_TAIL + r"$", re.I)),
    ("back", re.compile(r"^" + _ST_WRAP + r"(?:i'?m back|i am back|i'?m here|i am here)" + _ST_TAIL + r"$", re.I)),
]
_ST_LAST = {}


def _st_pick(key, options):
    last = _ST_LAST.get(key)
    pool = [o for o in options if o != last] or options
    choice = random.choice(pool)
    _ST_LAST[key] = choice
    return choice


def _small_talk_reply(kind):
    hour = datetime.datetime.now().hour
    sir = random.random() < 0.25
    s_ = ", sir" if sir else ""
    if kind == "thanks":
        return _st_pick(kind, ["Anytime.", "You got it" + s_ + ".", "No problem" + s_ + ".", "Happy to help.", "Of course.", "Anytime" + s_ + ".", "Glad I could help."])
    if kind == "how_are_you":
        return _st_pick(kind, ["Doing great, thanks for asking. How about you?", "I'm good, all systems happy. How's your day going?",
                               "Pretty good" + s_ + ". What about you?", "Can't complain. How are you doing?", "I'm great. What's going on with you?"])
    if kind == "good_morning":
        return _st_pick(kind, ["Good morning" + s_ + ". Ready when you are.", "Morning" + s_ + ". How'd you sleep?", "Good morning. What are we getting into today?"])
    if kind == "good_afternoon":
        return _st_pick(kind, ["Good afternoon" + s_ + ". What do you need?", "Hey, good afternoon. How's the day going?", "Afternoon" + s_ + ". I'm all ears."])
    if kind == "good_evening":
        return _st_pick(kind, ["Good evening" + s_ + ". How was your day?", "Evening" + s_ + ". What can I do for you?", "Hey, good evening. I'm all ears."])
    if kind == "good_night":
        return _st_pick(kind, ["Good night" + s_ + ". Sleep well.", "Night night. I'll be here if you need me.", "Sleep well. Talk tomorrow."])
    if kind == "hello":
        if hour < 12:
            opts = ["Hey, good morning" + s_ + ". What's up?", "Morning" + s_ + ". What can I do for you?", "Hey there. I'm listening."]
        elif hour < 18:
            opts = ["Hey" + s_ + ". What's up?", "Hi there. What can I do for you?", "Hey, I'm here. Go ahead."]
        else:
            opts = ["Hey" + s_ + ". What's up tonight?", "Hi there. What can I do for you?", "Evening" + s_ + ". I'm listening."]
        return _st_pick(kind, opts)
    if kind == "there":
        return _st_pick(kind, ["Yep, I'm here" + s_ + ".", "Right here. What do you need?", "I'm here, go ahead.", "Loud and clear" + s_ + "."])
    if kind == "nice":
        return _st_pick(kind, ["Glad you like it.", "Nice, happy to hear that.", "Glad it worked out" + s_ + ".", "Good stuff."])
    if kind == "back":
        return _st_pick(kind, ["Welcome back" + s_ + ".", "Hey, welcome back. What's next?", "There you are. What do you need?"])
    return ""


def _small_talk_blocked():
    """True while ANY pending question / flow could own the next words (then small talk must not steal them)."""
    try:
        if study_state.get("active"):
            return True
        if _wa_session is not None or _WA_INCOMING_SESSION is not None or _DL_SESSION is not None or _PENDING_PERMISSION_ACTION:
            return True
        _ctl = _wa_call_controller
        if _ctl is not None and _ctl.has_pending_question():
            return True
    except Exception:
        return True
    return False


def _try_instant_small_talk(command):
    if os.getenv("FRIDAY_INSTANT_SMALLTALK", "1").strip().lower() in {"0", "false", "no", "off"}:
        return False
    text = re.sub(r"\s+", " ", str(command or "")).strip()
    if not text or len(text) > 60 or _small_talk_blocked():
        return False
    for kind, pattern in _ST_PATTERNS:
        if pattern.match(text):
            reply = _small_talk_reply(kind)
            if not reply:
                return False
            print(f"FRIDAY_LATENCY:: first_text_ms={int((time.perf_counter() - _CMD_T0[0]) * 1000)} lane=small_talk", flush=True)
            try:
                memory.append({"role": "user", "content": text})
                memory.append({"role": "assistant", "content": reply})
                memory[:] = friday_context.trim_conversation(memory)
                threading.Thread(target=save_memory, args=(memory,), name="FridaySmallTalkSave", daemon=True).start()
            except Exception as _st_mem_error:
                print("Small-talk memory note skipped (ignored):", _st_mem_error, flush=True)
            speak(reply)
            return True
    return False


def process_command(command):
    _CMD_T0[0] = time.perf_counter()
    # Normalize spoken/typed human symbols before any intent router sees them.
    # This is deliberately centralized so voice, typed UI commands, and
    # follow-up commands behave identically.
    command = normalize_human_command(command)

    # FRIDAY 7.0 CAMERA GATE: any sentence with the camera and on / off (turn on, switch off, camera on ...) goes straight to the
    # camera feature, before every other router and before Gemini. Look / describe requests keep their existing routes.
    try:
        if friday_camera_gate.handle(command):
            return True
    except Exception as _cam_gate_error:
        log_event(f"Camera gate fell through safely: {_cam_gate_error}", kind="recovery")

    # V7.5 AGENTIC VISION: "fix the error on my screen", "what's wrong with my screen", yes/no/"that's not an error" to its question. Nothing else.
    try:
        if friday_agentic_vision.claim(command):
            return True
    except Exception as _agentic_error:
        log_event(f"Agentic vision fell through safely: {_agentic_error}", kind="recovery")

    # FRIDAY 7.0: optional pre-warm of the routing decision for this command (a cache only; never changes the answer)
    try:
        if friday_core7 is not None:
            friday_core7.speculate(command)
    except Exception:
        pass

    # FRIDAY 5.0 CORE: confirmations, exact maths/units/time, memory + goals, system diagnosis, tools, permissions,
    # benchmark. Claims only what it can answer without the language model; everything else flows on unchanged.
    try:
        if friday_core5 is not None:
            friday_core5.turn_start(command)
        if re.match(r"^(?:please\s+)?(?:clear|remove|forget|detach|drop)\s+(?:the\s+|all\s+|my\s+)?(?:attachments?|attached files?)\s*$", command.strip(" .!?"), re.I):
            global _ATTACHED_CONTEXT
            _ATTACHED_CONTEXT = []
            speak("Attachments cleared.")
            return True
        if friday_core5 is not None and friday_core5.pre_route(command):
            return True
    except Exception as _core5_error:
        log_event(f"Core5 fell through safely: {_core5_error}", kind="recovery")

    # FRIDAY 6.0 CORE: personality/emotion, time-aware memory, autonomous tasks, agents, security, study, science, engineering, research,
    # productivity, creativity, integrations, self-evaluation. Claims only what it can do itself; a model prompt or rewritten command
    # (for example "schedule ... " -> original calendar handler) continues down the normal route unchanged.
    try:
        if friday_core6 is not None:
            _handled6, command = friday_core6.route(command)
            if _handled6:
                return True
    except Exception as _core6_error:
        log_event(f"Core6 fell through safely: {_core6_error}", kind="recovery")

    # FRIDAY 7.0 CORE: verified missions, objectives, evidence/research, savings, security centre, context graph, suggestions. Claims only what a 7.0 module
    # can answer itself; everything else (apps, files, YouTube, finance, food ...) continues down the normal route unchanged.
    try:
        if friday_core7 is not None:
            _handled7, command = friday_core7.route(command)
            if _handled7:
                return True
    except Exception as _core7_error:
        log_event(f"Core7 fell through safely: {_core7_error}", kind="recovery")

    # V2.3.1 CHAT ACCESS: "what do you see" / "can you see me" through the camera (described like a person), "open the calendar page",
    # "add X to my calendar", screen-vision on/off. Claims ONLY those explicit requests; everything else returns None and flows on unchanged.
    try:
        if friday_chat_access.handle(command):
            return True
    except Exception as _chat_access_error:
        log_event(f"Chat access fell through safely: {_chat_access_error}", kind="recovery")

    # V2.3.0 VISION HUB: answers a pending safety question (yes / no / confirm) and claims ONLY explicit
    # camera / OpenCV / verified-agent requests. Everything else returns None and flows on unchanged.
    try:
        if friday_vision_hub.handle_command(command):
            return True
    except Exception as _vision_error:
        log_event(f"Vision hub fell through safely: {_vision_error}", kind="recovery")

    # FRIDAY food-entry lane: persist food definitions in the same finance state used by the UI.
    try:
        _fm = re.match(r"^(?:add|record|save)\s+food\s+(.+?)\s*:\s*(.+)$", command, re.I)
        if _fm:
            from friday_finance_engine import add_food_record as _add_food_record
            _meals = ["b","l","d"]
            _food_result = _add_food_record(_fm.group(1), _fm.group(2), _meals)
            speak(_food_result)
            return True
    except Exception as _food_add_error:
        log_event(f"Food save failed: {_food_add_error}", kind="recovery")

    # FRIDAY food optimizer lane: exhaustive, deterministic meal-cost analysis.
    # This is additive only and deliberately runs BEFORE general routing; it does
    # not touch the proven voice, listening, ASR, or TTS mechanisms.
    try:
        from friday_food_optimizer import handle as _friday_food_handle
        _food_result = _friday_food_handle(command)
        if _food_result is not None:
            speak(_food_result)
            return True
    except Exception as _food_error:
        log_event(f"Food optimizer unavailable; continuing with finance/general assistant: {_food_error}", kind="recovery")

    # FRIDAY finance lane: deterministic money handling always precedes the
    # general assistant router. This keeps saving/budget arithmetic exact.
    try:
        from friday_finance_engine import handle as _friday_finance_handle
        _finance_result = _friday_finance_handle(command)
        if _finance_result is not None:
            speak(_finance_result)
            return True
    except Exception as _finance_error:
        log_event(f"Finance lane unavailable; continuing with general assistant: {_finance_error}", kind="recovery")
    _peak_turn = None
    if friday_peak_engine is not None:
        try:
            _peak_turn = friday_peak_engine.begin_turn(command)
            if friday_peak_engine.should_ignore_duplicate(_peak_turn):
                log_event("Peak layer suppressed an accidental duplicate command", kind="recovery")
                return True
        except Exception:
            _peak_turn = None

    # V4010.2 ADAPTIVE REASONING PREPASS: classify the linguistic shape first.
    # This is deliberately bounded and non-generative so it adds essentially no
    # waiting time to the proven voice/recognition path.
    try:
        from friday_adaptive_reasoning import canonical_app_command as _adaptive_app
        _adaptive_canonical = _adaptive_app(command)
        if _adaptive_canonical:
            if _adaptive_canonical.startswith("close "):
                _adaptive_result = try_handle_system_control(_adaptive_canonical)
            else:
                _adaptive_result = try_handle_open_app(_adaptive_canonical)
            if _adaptive_result is not None:
                return _adaptive_result
    except Exception as _adaptive_router_error:
        log_event(f"Adaptive reasoning prepass fallback: {_adaptive_router_error}", kind="recovery")

    # V4010.1 SMART SEMANTIC ROUTER: recognize natural wrappers/typos around
    # unambiguous app actions, then reuse the existing verified handlers.
    # This runs before generative routing and never touches STT/TTS.
    try:
        from friday_smart_router import classify as _smart_classify
        _smart_route = _smart_classify(command)
        if _smart_route is not None and _smart_route.confidence >= 0.90:
            if _smart_route.kind == "close":
                _smart_result = try_handle_system_control(_smart_route.canonical)
                if _smart_result is not None:
                    return _smart_result
            elif _smart_route.kind == "open":
                _smart_result = try_handle_open_app(_smart_route.canonical)
                if _smart_result is not None:
                    return _smart_result
    except Exception as _smart_router_error:
        log_event(f"Smart semantic router fallback: {_smart_router_error}", kind="recovery")

    # V4010 SMART ACTION GUARD: high-confidence app/window commands are
    # dispatched before any generative router.  This prevents phrases such as
    # "close WhatsApp for me" from being interpreted as conversational text
    # (for example, treating "for me" as a contact) and keeps simple actions
    # on the minimum-latency path.  It reuses the existing, verified handlers;
    # no duplicate task implementation is introduced.
    try:
        _direct_low = command.strip().lower()
        _is_app_close = bool(re.match(
            r"^(?:please\s+|hey\s+friday[, ]*)?(?:close|quit|terminate|end|force\s*close|force\s*quit)\s+(?:the\s+)?[a-z0-9][a-z0-9 ._-]{0,80}(?:\s+(?:for me|please|right now|now|sir|thanks|thank you))?[.!?]*$",
            _direct_low, re.I,
        ))
        _is_app_open = bool(re.match(
            r"^(?:please\s+|hey\s+friday[, ]*)?(?:open|launch|start|run)\s+(?:the\s+)?[a-z0-9][a-z0-9 ._-]{0,80}(?:\s+(?:for me|please|right now|now|sir|thanks|thank you))?[.!?]*$",
            _direct_low, re.I,
        ))
        if _is_app_close:
            _direct_result = try_handle_system_control(command)
            if _direct_result is not None:
                return _direct_result
        elif _is_app_open:
            _direct_result = try_handle_open_app(command)
            if _direct_result is not None:
                return _direct_result
    except Exception as _smart_action_error:
        log_event(f"Smart action guard fell through safely: {_smart_action_error}", kind="recovery")

    # Zoom Note-Taking Mode has priority over the general agent stack so an
    # active session can always consume the explicit stop command.
    if _zoom_notes_precheck(command):
        return True
    if _screen_awareness_precheck(command):
        return True
    global _PENDING_PERMISSION_ACTION

    if not command:
        return True

    # V2035 SEMANTIC INTENT PRECHECK: high-confidence compound browser speech
    # is executed by the existing browser controller before context/AI routing.
    # This keeps recognition and response fast while making natural phrasing
    # ("open Google and type hi in the search bar") map to the intended action.
    try:
        from friday_intent_engine import parse_browser_intent
        _semantic_intent = parse_browser_intent(command)
        if _semantic_intent is not None:
            from friday_desktop_agent import browser as _friday_browser
            _semantic_result = _friday_browser(command)
            if _semantic_result.get("ok"):
                return True
            log_event(f"Semantic browser intent fell through safely: {_semantic_result.get('error','unknown')}", kind="recovery")
    except Exception as _semantic_error:
        log_event(f"Semantic intent precheck unavailable: {_semantic_error}", kind="recovery")

    # ADDITIVE persistent conversation ledger. This does not replace memory.json;
    # it gives the context engine a restart-safe record of recent user requests.
    try:
        friday_context.record_user_command(command)
    except Exception as error:
        print("Persistent conversation record skipped (ignored):", error)

    # UI/typed commands share the same backend, so an explicit standby
    # command from the dashboard should put voice recognition back behind
    # the Friday wake gate as well. Spoken standby is handled earlier by
    # listen() so it never reaches the normal intent pipeline.
    if _is_standby_command(command):
        _set_voice_active(False, "standby command via UI/command channel")
        try:
            speak("Standing by.")
        except Exception:
            pass
        return True

    # Level-4 permission gate. Only a pending consequential action can consume
    # these short confirmations, so ordinary "yes"/"no" conversation is never
    # hijacked.
    if _PENDING_PERMISSION_ACTION:
        decision = command.strip().lower()
        yes = decision in {"yes", "yeah", "yep", "confirm", "confirmed", "do it", "go ahead", "proceed"}
        no = decision in {"no", "nope", "cancel", "cancel it", "stop", "don't", "do not"}
        if yes and _PENDING_PERMISSION_ACTION == "shutdown":
            _PENDING_PERMISSION_ACTION = None
            speak("Confirmed. Shutting down the computer in 10 seconds.")
            os.system("shutdown /s /t 10")
            log_event("Level-4 shutdown confirmed", kind="permission")
            return True
        if no:
            action = _PENDING_PERMISSION_ACTION
            _PENDING_PERMISSION_ACTION = None
            speak(f"{action.replace('_', ' ').capitalize()} cancelled, sir.")
            log_event(f"Level-4 action cancelled: {action}", kind="permission")
            return True

    # V7.2 INSTANT SMALL TALK: greetings / thanks / "how are you" answered locally in milliseconds.
    try:
        if _try_instant_small_talk(command):
            return True
    except Exception as _small_talk_error:
        log_event(f"Instant small talk fell through safely: {_small_talk_error}", kind="recovery")

    # V4010.10 EXECUTIVE COGNITION: make one cheap decision before routing.
    # It never waits for Gemini and never changes the speech pipeline. Complex turns
    # get a plan/evidence/verification profile; simple turns remain on the fast lane.
    try:
        if friday_movie_cognitive_engine is not None:
            _cog_ctx = {}
            try:
                _cog_ctx = friday_context.resolve(command) if friday_context is not None else {}
            except Exception:
                _cog_ctx = {}
            _cog_decision = friday_movie_cognitive_engine.begin_turn(command, _cog_ctx if isinstance(_cog_ctx, dict) else {})
            # Make the decision available to downstream modules without forcing them to import one another.
            globals()["_CURRENT_COGNITIVE_DECISION"] = _cog_decision
            try:
                log_event(f"Executive route: {_cog_decision.get('preferred_route','legacy')}", kind="cognition")
            except Exception:
                pass
    except Exception as _cog_error:
        globals()["_CURRENT_COGNITIVE_DECISION"] = {}
        log_event(f"Executive cognition fallback: {_cog_error}", kind="recovery")

    # V2033 ULTRA-FAST SAFE LANE: exact, side-effect-safe commands are
    # dispatched before tone analysis, persistent context writes, and agent
    # observation. The same existing handle_command() implementation is used;
    # this only removes unnecessary work from the critical path.
    try:
        if friday_peak_engine is not None and friday_peak_engine.fast_lane_eligible(command):
            friday_peak_engine.record_fast_lane(True)
            with _COMMAND_LOCK:
                fast_result = handle_command(command)
            if fast_result is not None:
                return _command_result_to_continue(fast_result)
        elif friday_peak_engine is not None:
            friday_peak_engine.record_fast_lane(False)
    except Exception as fast_error:
        log_event(f"Ultra-fast lane fell back safely: {fast_error}", kind="recovery")

    # V2043.5 DETERMINISTIC ACTION LANE: WhatsApp opens and messaging must
    # go through the existing verified desktop/WhatsApp state machines before
    # any generative runtime can claim or reinterpret the request.
    try:
        _low_direct = command.strip().lower()
        _open_whatsapp = bool(re.search(r"\b(?:open|launch|start)\s+(?:the\s+)?whats(?:app|s app)\s*(?:app)?\b", _low_direct, re.I))
        _message_request = bool(re.search(r"\b(?:send|write|text|message)\b.*\b(?:message|saying|that says)\b", _low_direct, re.I)) and bool(re.search(r"\b(?:to|whatsapp|message)\b", _low_direct, re.I))
        if not _message_request and friday_nlu is not None:
            # V2044: typo / filler tolerant ("an u send harshik a messge saying bro?")
            try:
                _message_request = friday_nlu.parse_message(command) is not None
            except Exception:
                _message_request = False

        if _open_whatsapp:
            from friday_desktop_agent import launch_app as _launch_app
            _wa_open_result = _launch_app("whatsapp")
            if isinstance(_wa_open_result, dict) and _wa_open_result.get("verified"):
                speak("WhatsApp is open and ready, sir.")
            else:
                speak("I opened WhatsApp, but I could not verify its window, sir.")
                log_event(f"WhatsApp open verification failed: {_wa_open_result}", kind="recovery")
            return True

        # Fully specified WhatsApp/generic-message requests belong to the
        # existing confirmation state machine. It owns contact resolution,
        # confirmation UI, sending and truthful success/failure reporting.
        if _message_request or _wa_session is not None:
            with _COMMAND_LOCK:
                _communication_result = handle_command(command)
            if _communication_result is not None:
                return _command_result_to_continue(_communication_result)
    except Exception as _direct_comm_error:
        log_event(f"Deterministic communication lane fell back safely: {_direct_comm_error}", kind="recovery")

    # Sets the tone signal (see detect_user_tone near ask_ai) that
    # speak() reads for this whole turn -- computed once up front so
    # both a quick built-in reply and the Gemini fallback below get
    # consistent, tone-aware delivery. Guarded so a detection failure
    # can never block the actual command.
    if not VOICE_LATENCY_FIRST:
        try:
            detect_user_tone(command)
        except Exception as error:
            print("Tone detection error (ignored):", error)

    # Start a continuous-agent turn snapshot before the existing intent
    # pipeline. Nothing downstream is replaced or reordered.
    try:
        friday_agent_core.observe(
            command,
            mode="study" if study_state.get("active") else "normal",
            subject=study_state.get("subject"),
            task=study_state.get("topic"),
        )
        friday_agent_core.observer_tick(get_active_window_title())
    except Exception:
        pass

    # V3095 9.5+ UNIFIED EXECUTION GATEWAY. It only claims complex/orchestrated
    # requests; all existing direct and voice-sensitive routes above remain first.
    # It sits after the existing context/tone setup but before the generative fallbacks.
    try:
        unified_result = friday_unified_gateway.try_handle(command, ask_user=None)
        if unified_result is not None:
            return _command_result_to_continue(unified_result)
    except Exception as _unified_error:
        log_event(f"Unified 9.5+ gateway fell through safely: {_unified_error}", kind="recovery")

    try:
        log_event(f"Intent processing started: {command}", kind="intent")

        # v96 unified gateway. Voice, typed commands and widget commands all
        # enter the same backend, sharing tasks, tools, security and HUD events.
        try:
            snap = friday_agent_core.snapshot()
            v96_result = friday_v96_runtime.gateway(command, topic=snap.get("topic"))
        except Exception as v96_error:
            v96_result = None
            log_event(f"v96 runtime safely fell back: {v96_error}", kind="recovery")
        if isinstance(v96_result, dict) and v96_result.get("handled"):
            return True

        # Omni capability layer. Only explicitly recognized commands are
        # claimed; returning None preserves every legacy route unchanged.
        try:
            omni_result = friday_omni_engine.handle(command)
        except Exception as omni_error:
            omni_result = None
            log_event(f"Omni layer safely fell back: {omni_error}", kind="recovery")

        if omni_result is not None:
            result = omni_result
        else:
            # Existing advanced agent remains the next additive layer.
            try:
                advanced_result = friday_advanced_agent.try_handle(command)
            except Exception as advanced_error:
                advanced_result = None
                log_event(f"Advanced agent safely fell back: {advanced_error}", kind="recovery")

            if advanced_result is not None:
                result = advanced_result
            else:
                with _COMMAND_LOCK:
                    result = handle_command(command)

    except (Exception, SystemExit) as error:
        print("Command handler error (Friday stays running):", error)
        try:
            speak(friday_persona.line("generic_error"))
        except Exception:
            pass
        return True
    if result is False:
        if globals().get("_EXIT_REQUESTED"):
            globals()["_EXIT_REQUESTED"] = False
            try:
                friday_agent_core.record_action("Command completed", result="exit requested")
            except Exception:
                pass
            return False
        # A handler reported that ITS ACTION failed (e.g. an app would not open). It has already
        # told the user; that must never shut the assistant down.
        try:
            friday_agent_core.record_action("Command completed", result="action failed (handled)")
        except Exception:
            pass
        return True
    if result is True:
        try:
            friday_agent_core.update_context(
                mode="study" if study_state.get("active") else "normal",
                subject=study_state.get("subject"),
                task=study_state.get("topic"),
            )
            friday_agent_core.record_action("Command completed", result="success", topic=study_state.get("topic"))
            log_event("Action completed successfully", kind="result")
            # V4010 autonomous post-task reasoning is off the critical path.
            try:
                if friday_autonomous_reasoning is not None:
                    friday_autonomous_reasoning.on_command_completed(command)
            except Exception:
                pass
        except Exception:
            pass
        return True
    try:
        with _COMMAND_LOCK:
            ask_ai(command)
    except (Exception, SystemExit) as error:
        print("AI handler error (Friday stays running):", error)
    return True


# ============================================================
# UI COMMAND CHANNEL (stdin)
#
# The Electron UI (main.js) spawns this script with its stdin piped
# open, and writes one plain-text command per line whenever a button
# is pressed, a file is dropped, or the "CURRENT COMMAND" box is used
# — e.g. "study mode", "upload pdf C:\...\notes.pdf", "show syllabus",
# "exam mode", "exit study mode". Each line is run through EXACTLY the
# same process_command() pipeline as a spoken command, and is echoed
# back as "You: <command>" so the existing UI parsing (which already
# keys off that prefix for voice) picks it up identically -- buttons
# and voice both end up in the same place.
#
# This runs on its own daemon thread so it never blocks/competes with
# the microphone loop; run_friday() keeps listening on the main thread
# exactly as before.
# ============================================================

def _friday_release_hardware():
    """V2.3.1: let go of the microphone, the camera and the audio output. Used when the app closes (or its window pipe disappears),
    so Windows stops showing the microphone as in use. Each step is isolated and the whole thing is time-boxed."""
    def _work():
        try:
            _ve_mod = sys.modules.get("friday_vision_engine")
            if _ve_mod is not None:
                _ve_mod.SESSION.stop()                      # camera / screen watcher (releases the camera)
        except Exception:
            pass
        try:
            _si_mod = sys.modules.get("friday_screen_intelligence")
            if _si_mod is not None:
                _si_mod.stop_awareness()
        except Exception:
            pass
        try:
            if friday_voice5 is not None:
                friday_voice5.shutdown()                    # FRIDAY 5.0 always-open microphone stream
        except Exception:
            pass
        try:
            _close_persistent_microphone()                  # the shared PyAudio input stream
        except Exception:
            pass
        try:
            _stop_persistent_sapi()
        except Exception:
            pass
        try:
            _fast_player_stop()
        except Exception:
            pass
    _t = threading.Thread(target=_work, name="FridayReleaseHardware", daemon=True)
    _t.start()
    _t.join(2.5)


def _friday_quit_now(reason=""):
    try:
        print(f"FRIDAY closing ({reason}): releasing microphone and camera.", flush=True)
    except Exception:
        pass
    _friday_release_hardware()
    try:
        _CRASH_LOG.flush()
    except Exception:
        pass
    os._exit(0)


atexit.register(lambda: _friday_release_hardware())


def _friday_start_parent_watchdog():
    """V3.1: if the app (Electron) that started this engine disappears for ANY reason - closed, crashed, killed from Task Manager -
    release the microphone and camera and exit. Independent of the stdin pipe, so it still works while a command is running."""
    if os.environ.get("FRIDAY_PYTHON_MODE") != "electron":
        return
    parent = os.getppid()

    def _parent_alive():
        try:
            if os.name == "nt":
                import ctypes
                k32 = ctypes.windll.kernel32
                k32.OpenProcess.restype = ctypes.c_void_p
                k32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
                handle = k32.OpenProcess(0x00100000 | 0x1000, False, int(parent))   # SYNCHRONIZE | QUERY_LIMITED_INFORMATION
                if not handle:
                    return False
                try:
                    return k32.WaitForSingleObject(handle, 0) == 0x102             # WAIT_TIMEOUT -> still running
                finally:
                    k32.CloseHandle(ctypes.c_void_p(handle))
            return os.getppid() == parent
        except Exception:
            return True

    def _loop():
        while True:
            time.sleep(1.5)
            if not _parent_alive():
                _friday_quit_now("app process ended")

    threading.Thread(target=_loop, name="FridayParentWatchdog", daemon=True).start()


def _v5_attach(paths):
    """Attach files to the conversation: read them, index them in memory, and tell the chat what was understood."""
    global _ATTACHED_CONTEXT
    try:
        items = friday_attach5.inspect_all(list(paths)) if friday_attach5 is not None else []
        if not items:
            from friday_attachment_engine import inspect as _old_inspect
            items = _old_inspect(list(paths))
        _ATTACHED_CONTEXT = items
        _ATTACHED_AT[0] = time.time()
        if friday_knowledge5 is not None:
            for it in items:
                if it.get("content"):
                    try:
                        friday_knowledge5.ingest_text(it.get("original_name") or it.get("name"), it["content"], it.get("source_path", ""))
                    except Exception:
                        pass
        cards = friday_attach5.describe(items) if friday_attach5 is not None else []
        names = ", ".join(x.get("original_name", x.get("name", "file")) for x in items)
        print("FRIDAY_ATTACHMENTS_READY::" + base64.b64encode(json.dumps({"count": len(items), "names": names, "files": cards}).encode()).decode(), flush=True)
        if friday_core5 is not None:
            friday_core5.hud(tool="reading " + (names[:40] or "files"))
    except Exception as _att_error:
        _ATTACHED_CONTEXT = []
        print("FRIDAY_ATTACHMENTS_ERROR::" + str(_att_error).replace("\n", " "), flush=True)


def _v5_publish_status():
    try:
        st = friday_core5.status() if friday_core5 is not None else {}
        st["voice"] = friday_voice5.health() if friday_voice5 is not None else {}
        st["speech"] = friday_speech5.health() if friday_speech5 is not None else {}
        print("FRIDAY_STATUS5::" + base64.b64encode(json.dumps(st, ensure_ascii=False, default=str).encode("utf-8")).decode("ascii"), flush=True)
    except Exception as _st_error:
        print("Status5 failed:", _st_error, flush=True)


def _v5_run_benchmark_async():
    def _w():
        try:
            import friday_benchmark5 as _bm
            res = _bm.run_all()
            print("FRIDAY_BENCH::" + base64.b64encode(json.dumps(res, ensure_ascii=False).encode("utf-8")).decode("ascii"), flush=True)
        except Exception as _bm_error:
            print("Benchmark failed:", _bm_error, flush=True)
    threading.Thread(target=_w, name="FridayBench", daemon=True).start()


def stdin_command_listener():
    global _UI_CONNECTED, _UI_SPEAK_MUTED
    _INPUT_SOURCE.kind = "typed"      # everything arriving here was typed / clicked in the UI
    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue

        # Handshake sentinel sent once by main.js the moment the
        # renderer has finished loading. Deliberately checked BEFORE
        # the normal command path below: it's not something a user
        # typed or said, so it must never be echoed as "You: ..." or
        # handed to process_command().
        if line in {"__FRIDAY_UI_READY__", "__FRIDAY_UI_READY__", "__UI_READY__"}:
            _UI_CONNECTED = True
            print("UI handshake received.")
            continue

        if line == "__FRIDAY_LISTEN__":
            _set_voice_active(True, "FRIDAY UI listen button")
            continue

        if line == "__FRIDAY_STANDBY__":
            _set_voice_active(False, "FRIDAY UI standby button")
            continue

        if line.startswith("__FRIDAY_ADDRESS__::"):
            try:
                _a = json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                _USER_ADDRESS["word"] = str(_a.get("word", "Sir"))[:30]
                _USER_ADDRESS["title"] = bool(_a.get("title", True))
            except Exception as _addr_error:
                log_event(f"Address update failed: {_addr_error}", kind="recovery")
            continue

        if line.startswith("__FRIDAY_MUTE__::"):
            _UI_SPEAK_MUTED = line.split("::", 1)[1].strip() in {"1", "true", "on"}
            continue

        if line.startswith("__FRIDAY_GEMINI_MODEL__::"):
            global GEMINI_MODEL
            try:
                _model = base64.b64decode(line.split("::", 1)[1]).decode("utf-8").strip().replace("\r", "").replace("\n", "")[:160]
                if _model:
                    GEMINI_MODEL = _model
                    # Keep auxiliary brain/computer-use modules on the same
                    # model when they are loaded in this process.
                    try:
                        import friday_brain as _fb
                        _fb.GEMINI_MODEL = _model
                    except Exception:
                        pass
                    try:
                        import friday_gemini_computer_use as _gcu
                        _gcu.MODEL = _model
                    except Exception:
                        pass
                    print("FRIDAY_GEMINI_MODEL::" + GEMINI_MODEL, flush=True)
            except Exception as _model_error:
                print("FRIDAY_GEMINI_MODEL_ERROR::" + str(_model_error).replace("\n", " "), flush=True)
            continue

        if line == "__FRIDAY_API_TEST__":
            _start_gemini_watchdog()
            threading.Thread(target=_diagnose_gemini, kwargs={"tested": True}, name="FridayGeminiTest", daemon=True).start()
            continue

        if line.startswith("__FRIDAY_API_KEY__::"):
            global _RUNTIME_GEMINI_API_KEY, client, _gemini_client_init_attempted, _gemini_client_key
            try:
                _previous_published_key = GEMINI_API_KEY
                _RUNTIME_GEMINI_API_KEY = _clean_api_key(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                if not _RUNTIME_GEMINI_API_KEY and _previous_published_key and os.environ.get("GEMINI_API_KEY", "") == _previous_published_key:
                    # "Remove key" must really remove it: _ensure_gemini_client() mirrors the
                    # key into the process environment, which would otherwise keep it alive.
                    os.environ.pop("GEMINI_API_KEY", None)
                client = None
                _gemini_client_init_attempted = False
                _gemini_client_key = ""
                _API_HEALTH["state"] = "unknown"
                _start_gemini_watchdog()
                # Real live test off the command thread so typing/voice never stalls.
                threading.Thread(target=_diagnose_gemini, kwargs={"tested": True}, name="FridayGeminiTest", daemon=True).start()
            except Exception as _api_error:
                print("FRIDAY_API_STATUS::ERROR", flush=True)
                print("FRIDAY API key update failed:", _api_error)
            continue

        if line.startswith("__FRIDAY_ATTACH__::"):
            global _ATTACHED_CONTEXT
            try:
                payload = json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                paths = payload.get("paths", []) if isinstance(payload, dict) else []
                _v5_attach(paths)
            except Exception as _att_error:
                _ATTACHED_CONTEXT=[]
                print("FRIDAY_ATTACHMENTS_ERROR::"+str(_att_error).replace("\n"," "), flush=True)
            continue

        if line.startswith("__FRIDAY_FINANCE_SYNC__::"):
            try:
                payload = base64.b64decode(line.split("::", 1)[1]).decode("utf-8")
                from friday_finance_engine import sync as _friday_finance_sync
                _friday_finance_sync(json.loads(payload))
            except Exception as _sync_error:
                log_event(f"Finance UI sync failed: {_sync_error}", kind="recovery")
            continue

        if line.startswith("__FRIDAY_VISION__::"):
            # V2.3.0: Vision page / Settings requests. Handled on their own threads; never blocks voice or typing.
            try:
                friday_vision_hub.handle_ui(json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8")))
            except Exception as _vision_ui_error:
                log_event(f"Vision request failed safely: {_vision_ui_error}", kind="recovery")
            continue

        if line.startswith("__FRIDAY_VISION_SECRET__::"):
            try:
                _sec = json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                friday_vision_hub.handle_secret(str(_sec.get("name", "")), str(_sec.get("value", "")))
            except Exception as _vision_sec_error:
                log_event(f"Vision secret update failed safely: {_vision_sec_error}", kind="recovery")
            continue

        if line.startswith("__FRIDAY_VOICE_CFG__::"):
            # V6.0.1: Settings > Voice (microphone sensitivity, conversation window, wake rule, talk-over).
            try:
                _vc = json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                if friday_voice5 is not None and isinstance(_vc, dict):
                    _applied = friday_voice5.configure(
                        sensitivity=_vc.get("sensitivity"), active_window_s=_vc.get("active_window_s"),
                        wake_anywhere=_vc.get("wake_anywhere"), barge_in=_vc.get("barge_in"))
                    print("FRIDAY_VOICE_CFG::" + base64.b64encode(json.dumps(_applied).encode("utf-8")).decode("ascii"), flush=True)
            except Exception as _vc_error:
                log_event(f"Voice settings update failed safely: {_vc_error}", kind="recovery")
            continue

        if line == "__FRIDAY_STATUS5__":
            _v5_publish_status()
            continue

        if line.startswith("__FRIDAY_V6__::"):
            # FRIDAY 6.0 Command Centre requests (snapshots and actions). Own thread: never blocks typing, voice or speech.
            try:
                _req6 = json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                if friday_core6 is not None:
                    threading.Thread(target=friday_core6.handle_ui, args=(_req6,), name="Friday6UI", daemon=True).start()
            except Exception as _v6_ui_error:
                log_event(f"6.0 UI request failed safely: {_v6_ui_error}", kind="recovery")
            continue

        if line.startswith("__FRIDAY_V7__::"):
            # FRIDAY 7.0 Intelligence pages (snapshots and actions). Own thread: never blocks typing, voice or speech.
            try:
                _req7 = json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                if friday_core7 is not None:
                    threading.Thread(target=friday_core7.handle_ui, args=(_req7,), name="Friday7UI", daemon=True).start()
            except Exception as _v7_ui_error:
                log_event(f"7.0 UI request failed safely: {_v7_ui_error}", kind="recovery")
            continue

        if line == "__FRIDAY_BENCH__":
            _v5_run_benchmark_async()
            continue

        if line.startswith("__FRIDAY_PERM__::"):
            try:
                _pm = json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8"))
                friday_tools5.set_perm(str(_pm.get("name", "")), bool(_pm.get("value")))
                _v5_publish_status()
            except Exception as _pm_error:
                log_event(f"Permission update failed safely: {_pm_error}", kind="recovery")
            continue

        if line == "__FRIDAY_QUIT__":
            # V2.3.1: the app is closing. Release the microphone and camera, then stop this process.
            _friday_quit_now("app closing")

        if line.startswith("__FRIDAY_APPSTATE__::"):
            # V2.3.1: Calendar / Memory / Tasks / Files / Tools data from the app pages, so the chat can answer about them.
            try:
                friday_chat_access.set_app_state(json.loads(base64.b64decode(line.split("::", 1)[1]).decode("utf-8")))
            except Exception as _appstate_error:
                log_event(f"App state sync failed safely: {_appstate_error}", kind="recovery")
            continue

        if line.startswith("ASK::"):
            try:
                payload = json.loads(base64.b64decode(line[5:]).decode("utf-8"))
                q = str(payload.get("q", "")).strip()
                _files = [f for f in (payload.get("files") or []) if isinstance(f, str)]
                if _files:
                    _v5_attach(_files)
                    if not q:
                        q = "Please look at the attached file" + ("s" if len(_files) > 1 else "") + " and tell me what " + ("they are" if len(_files) > 1 else "it is") + " and what I can do with " + ("them." if len(_files) > 1 else "it.")
                if q:
                    if friday_speech5 is not None:
                        if _TTS_ACTIVE:
                            _v5_interrupt()         # typing a new command stops her mid-sentence
                        friday_speech5.begin_turn()
                    print(f"You: {q}")
                    result = process_command(q)
                    if result is False:
                        os._exit(0)
            except Exception as _ask_error:
                print("FRIDAY ASK error:", _ask_error)
            continue

        # Speak-only sentinel: lets Study Mode UI narration ("Opening
        # subjects.", "Note saved.", etc.) come out of the ONE real
        # Friday voice instead of the browser's own speechSynthesis
        # (which sounded like a second, different voice talking).
        # Deliberately checked BEFORE process_command(), same as the
        # handshake above -- this is UI narration, not something the
        # user said, so it must never be echoed as "You: ..." or
        # affect command state (whatsapp confirmations, study state,
        # context memory, etc.).
        if line.startswith("__FRIDAY_SPEAK_ONLY__::") or line.startswith("__FRIDAY_SPEAK_ONLY__::"):
            marker = "__FRIDAY_SPEAK_ONLY__::" if line.startswith("__FRIDAY_SPEAK_ONLY__::") else "__FRIDAY_SPEAK_ONLY__::"
            speak(line[len(marker):])
            continue

        print(f"You: {line}")
        try:
            if not process_command(line):
                # A UI-issued "goodbye"-style command asked Friday to
                # stop entirely -- exit the whole process cleanly.
                os._exit(0)
        except Exception as error:
            print("UI command error (Friday stays running):", error)

    # V2.3.1: the pipe from the app closed, so the app is gone (closed, crashed or killed). Never keep listening on the
    # microphone with nobody there: release it and stop.
    if os.environ.get("FRIDAY_PYTHON_MODE") == "electron":
        _friday_quit_now("app window closed")


# ============================================================
# NORMAL VOICE MODE
# ============================================================

def run_friday():
    # Greet the user immediately after the UI is ready, then begin listening
    # without requiring a wake word. This restores the original v85 startup
    # experience while keeping the newer speech, recognition, and command
    # pipeline unchanged. Explicit "standby" still returns to the existing
    # wake-word-gated standby mode.
    # V6.0.1: the microphone is opened NOW, before the greeting, and the conversation starts ACTIVE - so the moment the
    # screen says "Listening..." the microphone really is on. Nobody has to press anything.
    _v5_prestart_mic()
    _set_voice_active(True, "voice session started")
    wish_user()
    _set_voice_active(True, "voice loop started after greeting")
    while True:
        command = listen()
        if not command:
            continue
        if not process_command(command):
            break


# ============================================================
# TERMINAL STUDY SETUP / HELP
# ============================================================

def terminal_study_help():
    print("""
================ FRIDAY STUDY MODE ================

Start:
  study mode
  study mode 9701
  study mode 9702
  study mode 9709
  study mode 9618
  study mode 4024

Attach a PDF from the terminal:
  attach pdf C:\\Users\\YourName\\Documents\\chemistry.pdf
  upload pdf C:\\Users\\YourName\\Documents\\physics.pdf

Study commands:
  show syllabus
  teach me stoichiometry
  quiz me
  test me on bonding
  active recall
  flashcards
  exam mode
  make a study plan
  study progress
  list study pdfs
  clear study pdfs
  exit study mode

Zoom Note-Taking Mode:
  zoom note taking mode
  end
  Captures the visible study screen continuously, analyzes diagrams and
  written content, records Windows system-audio loopback, transcribes the
  meeting and compiles study-content-only notes into a PDF.

The same commands can also be spoken when voice mode is running.
=====================================================
""")


# ============================================================
# STARTUP PREWARM
# ============================================================
def _prewarm_latency_critical_services():
    """Warm the two services that most often dominate first-response latency."""
    def _warm_gemini():
        try:
            _ensure_gemini_client()
        except Exception as exc:
            print(f"Gemini prewarm skipped: {exc}", flush=True)

    def _warm_sapi():
        if os.name != "nt":
            return
        try:
            # Start the resident SAPI process with a tiny silent-free request.
            # It is intentionally not spoken; the process is kept resident for
            # the first real response.
            powershell = shutil.which("powershell.exe") or shutil.which("powershell")
            if not powershell:
                return
            global _TTS_PERSISTENT_PROCESS
            with _TTS_PERSISTENT_LOCK:
                if _TTS_PERSISTENT_PROCESS is None or _TTS_PERSISTENT_PROCESS.poll() is not None:
                    _TTS_PERSISTENT_PROCESS = subprocess.Popen(
                        [powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", _TTS_PERSISTENT_PS_SOURCE],
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        text=True, encoding="utf-8", errors="replace", bufsize=1,
                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                    )
        except Exception as exc:
            print(f"SAPI prewarm skipped: {exc}", flush=True)

    threading.Thread(target=_warm_gemini, name="Friday-Gemini-Prewarm", daemon=True).start()
    threading.Thread(target=_fast_player_warm, name="Friday-FastTTS-Prewarm", daemon=True).start()
    # Do not prewarm SAPI: the live speech path is hard-locked to Ryan Neural
    # Edge TTS, so starting a second voice engine only adds startup work.


# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    try:
        # Warm the local speech model immediately, on a daemon thread, so it
        # is already resident by the time the user says anything. This must
        # happen before the UI handshake wait below -- that wait is often
        # several seconds of otherwise idle time, which is exactly when the
        # model should be loading. Applies to both UI and terminal modes.
        _start_voice_engine_preload()
        _prewarm_latency_critical_services()

        # ----------------------------------------------------
        # ELECTRON UI MODE
        # ----------------------------------------------------
        if not sys.stdin.isatty():
            print("\nFriday starting...")
            print("UI connection handshake: waiting...")

            # Start the UI command listener.
            threading.Thread(
                target=stdin_command_listener,
                daemon=True
            ).start()
            _friday_start_parent_watchdog()

            # IMPORTANT:
            # Do NOT start run_friday() or speak anything until
            # Electron tells us that the UI is connected.
            while not _UI_CONNECTED:
                time.sleep(0.05)

            print("UI connection confirmed. Starting Friday.")
            try:
                if friday_core5 is not None:
                    friday_core5.configure(speak=speak, emit=lambda l: print(l, flush=True), log=lambda m, k="core": log_event(m, kind=k))
                    friday_core5.hud(core="Ready")
                if friday_core6 is not None:
                    def _v6_gemini(_p, _tier="fast"):
                        _ensure_gemini_client()
                        if client is None:
                            return ""
                        _dm = (os.getenv("FRIDAY_DEEP_MODEL", "").strip() or None) if _tier == "deep" else None
                        return _v5_gen_text(_p, deep=(_tier == "deep"), model=_dm)
                    friday_core6.configure(
                        speak=speak, emit=lambda l: print(l, flush=True), log=lambda m, k="core": log_event(m, kind=k),
                        gemini=_v6_gemini, address=lambda: (str(_USER_ADDRESS.get("word") or "sir").lower() if _USER_ADDRESS.get("title", True) else "sir"),
                        run_command=process_command, busy=lambda: bool(_TTS_ACTIVE),
                        set_global=lambda n, v: globals().__setitem__(n, v), get_global=lambda n, d=None: globals().get(n, d),
                        restart_listener=lambda: (friday_voice5.shutdown() if friday_voice5 is not None else None))
                    friday_core6.boot()
                if friday_core7 is not None:
                    friday_core7.configure(
                        speak=speak, emit=lambda l: print(l, flush=True), log=lambda m, k="core": log_event(m, kind=k),
                        run_command=process_command, busy=lambda: bool(_TTS_ACTIVE),
                        restart_listener=lambda: (friday_voice5.shutdown() if friday_voice5 is not None else None))
                    friday_core7.boot()
                if friday_speech5 is not None:
                    _wv, _wr = _fast_tts_params(VOICE_RATE)
                    friday_speech5.warm_cache([WAKE_ACKNOWLEDGEMENT, "Standing by.", "Let me think that through properly.", "Understood.", "Done."], _wv, _wr)
            except Exception as _core5_boot_error:
                log_event(f"Core5 boot skipped: {_core5_boot_error}", kind="recovery")
            print("VOICE_MODE::STANDBY" if not _VOICE_SESSION_ACTIVE else "VOICE_MODE::ACTIVE", flush=True)

            # Push a live weather reading to the header immediately,
            # then keep it refreshed every 15 minutes -- runs in the
            # background so it never delays Friday actually starting.
            threading.Thread(target=_weather_push_loop, daemon=True).start()

            # Study plan reminders -- independent of study_state, the
            # widget/dashboard toggle, or anything else: this must
            # fire even when Study Mode is completely closed.
            

            # Continuous situational awareness. This is deliberately
            # lightweight: only the foreground window title is sampled,
            # and it never speaks proactively just because the window
            # changed. It feeds the same agent state used by Gemini.
            def _continuous_awareness_loop():
                while True:
                    try:
                        friday_agent_core.observer_tick(get_active_window_title())
                    except Exception:
                        pass
                    try:
                        friday_advanced_agent.observation_tick()
                    except Exception:
                        pass
                    time.sleep(1.0)

            threading.Thread(
                target=_continuous_awareness_loop,
                daemon=True,
                name="Friday-Awareness"
            ).start()

            # V4010 autonomous reasoning runs asynchronously and cannot delay
            # foreground replies or normal task execution.
            try:
                if friday_autonomous_reasoning is not None:
                    friday_autonomous_reasoning.start()
            except Exception as _autonomy_start_error:
                log_event(f"Autonomous reasoning unavailable: {_autonomy_start_error}", kind="recovery")

            try:
                friday_omni_engine.start_background()
                diagnostic_report = friday_omni_engine.self_diagnostics()
                print("FRIDAY_EVENT::" + json.dumps({
                    "kind": "startup_diagnostics",
                    "message": "Omni self-diagnostics completed",
                    "report": diagnostic_report
                }, ensure_ascii=False), flush=True)
            except Exception as omni_start_error:
                log_event(f"Omni background layer unavailable: {omni_start_error}", kind="recovery")

            # V2046: incoming-WhatsApp-notification watcher (optional,
            # Windows-only -- see friday_whatsapp_watch.py). Never blocks
            # startup and never raises into this loop.
            try:
                import friday_whatsapp_watch
                friday_whatsapp_watch.start_listener(
                    _wa_incoming_on_notification,
                    log=lambda msg: log_event(msg, kind="recovery"),
                    # V2048 FIX: if the watcher can't actually run (missing
                    # winsdk, notification access not granted, etc.) say so
                    # once instead of only writing it to the event log where
                    # the user has no reason to look and the feature just
                    # silently never works.
                    on_disabled=lambda msg: speak(msg),
                )
            except Exception as wa_watch_error:
                log_event(f"WhatsApp notification watcher unavailable: {wa_watch_error}", kind="recovery")

            # V2050: incoming WhatsApp CALL watcher + the (previously unstarted)
            # new-download watcher. Never blocks startup, never raises.
            start_whatsapp_call_watchers()

            # Start the v96 shared runtime independently and non-blockingly.
            try:
                friday_v96_runtime.start_background()
                v96_health = friday_v96_runtime.diagnostics()
                print("FRIDAY_EVENT::" + json.dumps({
                    "kind": "v96_diagnostics",
                    "message": "Unified runtime diagnostics completed",
                    "report": v96_health
                }, ensure_ascii=False), flush=True)
            except Exception as v96_start_error:
                log_event(f"v96 runtime unavailable; legacy system remains active: {v96_start_error}", kind="recovery")

            # Now it is safe for Friday to greet/speak.
            run_friday()

        # ----------------------------------------------------
        # NORMAL TERMINAL MODE
        # ----------------------------------------------------
        else:
            print("\nFriday ready.")
            print(
                "Type 'study terminal' for terminal-only study setup, "
                "or press Enter for normal voice mode."
            )

            startup = input("> ").strip().lower()

            

            if startup == "study terminal":
                startup = ""
            run_friday()

    except KeyboardInterrupt:
        print("\nFriday stopped.")

        try:
            speak("Goodbye.")
        except Exception:
            pass

    except Exception as error:
        import traceback

        print("Fatal error:", error)
        traceback.print_exc()

    finally:
        try:
            _CRASH_LOG.flush()
        except Exception:
            pass

        # Only pause when actually running in a terminal.
        # Electron must be allowed to exit normally.
        if sys.stdin.isatty():
            try:
                input("\nPress Enter to close this window...")
            except Exception:
                pass
