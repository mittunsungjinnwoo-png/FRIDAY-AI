# FRIDAY 7.0 - New UI

The interface has been completely redesigned (new Home, Settings & Features, widget and customization). Read **`FRIDAY_V70_NEW_UI_CHANGES.md`**.

---

# FRIDAY 7.0

New in this 7.0 update: camera on/off sentences always go to the camera feature (never Gemini), faster replies, smarter answers. **Read `FRIDAY_V70_UPDATE_CHANGES.md`.**

---

# FRIDAY 7.0

New in 7.0: verified missions (plan → run → independently check → revise → honest report), long-term objectives with milestones, a unified context graph, evidence-based research, savings intelligence, a security & recovery centre, health monitoring with a low-RAM light mode, calm proactive suggestions, plus fixes to file opening, maximising windows, closing FRIDAY without closing your apps, and YouTube song playback. **Read `FRIDAY_V70_CHANGES.md`.**

---


New in 6.0: personality + emotional intelligence, time-aware memory, autonomous tasks, multi-agent coordination, security + audit, hybrid model routing, engineering / science / research / study / productivity / creative tools, integrations + plugins, continuous self-evaluation and a 13-tab Command Centre. See **FRIDAY_V60_CHANGES.md** for exactly what was added and its limits. Self-test: `python FRIDAY_TEST_V60.py`.

---

# FRIDAY 7.0 — Advanced Multi-Task AI Assistant

FRIDAY 7.0 is a fast, voice-first, multi-tasking assistant: reasoning router with verified answers, long-term memory and goals, a personal knowledge base, tool use with permissions, file/image/PDF/audio attachments in chat, low-latency speech in and out, and a live HUD. Finance is just one of the many things she can help with.

**Read `FRIDAY_V50_CHANGES.md` for everything new, the settings switches, and how to run the self-benchmark** (say "run benchmark").

## What is included

- New always-open listening engine with speculative endpointing, a recognition race (local Whisper vs Google), barge-in and wake-word handling.
- New streaming speech engine (in-memory synthesis, prefetch, cache, instant interrupt).
- Router: instant local answers (maths, units, time), fast, deep (verified), research, agent.
- Memory, knowledge base and goals (SQLite), system diagnosis, safe code sandbox, permissions and audit log.
- Attach any file in chat (button, drag-and-drop or paste); FRIDAY reads it, does the task and returns results as file cards.
- The full FRIDAY-native stack: research, documents, browser and Windows control, screen and camera vision, WhatsApp, finance and meal planning.

## Install

1. Make sure Python 3.13 is installed.
2. Run `INSTALL_FRIDAY_WINDOWS.bat`.
3. Put your Gemini API key in `gemini_key.txt` if you want the full Gemini reasoning/research layer.
4. Run `START_FRIDAY.bat`.

If Python 3.13 is installed somewhere custom, set `FRIDAY_PYTHON` to its full `python.exe` path before starting.

## Finance commands

Examples:
- `income salary 250000`
- `expense rent 50000`
- `monthly plan groceries 30000`
- `goal laptop 150000`
- `show reports`
- `how much do I have left this month?`
- `can I afford 50000?`
- `help me save money`

FRIDAY's original meal planner remains available from the UI.

## Architecture

`friday_backend.py` is the active unified backend. The FRIDAY-native modules remain under their original `friday_*` names because they form one interoperating architecture. `friday_launcher.py` provides the fast Electron boot handshake.

Original FRIDAY files are preserved in `legacy_friday/` so no original file is discarded.

## Data

FRIDAY finance data is stored in `friday_data/finance.json`. General FRIDAY memory remains in `friday_data/memory.json`.


## Meal quantities (no cost estimates)
FRIDAY works out how much of every ingredient you need - per day and for the week - by averaging every breakfast x lunch x dinner combination you tick, plus the coffee/tea/milk you enter. It does not estimate grocery cost: you enter your own grocery budget in the Monthly Plan. Ask: "what ingredients do I need this week?" or "how much do I need on Monday?".

## Voice, typed commands and the widget (V2101)
FRIDAY uses the same listening / recognising / speaking pipeline as JARVIS: the Python backend owns the microphone loop and answers every utterance itself; the screen only displays it. Typed commands (chat box, Quick Input, widget panel) go to the same single `process_command()`. When FRIDAY is minimised to the widget, move the pointer beside the reactor to open the command panel.
