"""FRIDAY Intelligence Hub v2040 MAX.

General-purpose intelligence layer for research, planning, memory, documents,
computer work and verification. Domain-neutral: FRIDAY is not a debate coach.

IMPORTANT: this module deliberately contains no microphone, VAD, ASR,
recognition, or TTS code.
"""
from __future__ import annotations
import hashlib, math, re, time, statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

VERSION = "2040.0-MAX"

_RISK_PATTERNS = {
    "destructive": re.compile(r"\b(delete|remove|wipe|format|destroy|erase|kill|terminate)\b", re.I),
    "power": re.compile(r"\b(shutdown|shut down|restart|reboot|power off)\b", re.I),
    "financial": re.compile(r"\b(pay|purchase|buy|order|transfer|bank|money|checkout)\b", re.I),
    "communication": re.compile(r"\b(send|message|email|whatsapp|post|publish)\b", re.I),
    "system_change": re.compile(r"\b(install|uninstall|change settings|registry|driver|firewall)\b", re.I),
    "code_execution": re.compile(r"\b(run|execute|shell|command prompt|powershell|script)\b", re.I),
}
_RESEARCH = re.compile(r"\b(research|investigate|compare|verify|source|evidence|latest|current|study|analy[sz]e|find out|look up)\b", re.I)
_CREATE = re.compile(r"\b(create|make|generate|build|write|draft|export|pdf|docx|pptx|presentation|report|notes|spreadsheet|xlsx)\b", re.I)
_COMPUTER = re.compile(r"\b(open|launch|click|type|scroll|browser|computer|screen|screenshot|desktop)\b", re.I)
_MEMORY = re.compile(r"\b(note|remember|recall|memory|forget|plan|schedule|remind|task)\b", re.I)

_TRUSTED_TLDS = {"gov", "edu", "ac.uk", "gov.uk"}
_HIGH_SIGNAL_DOMAINS = {
    "who.int", "nih.gov", "nasa.gov", "nist.gov", "cdc.gov", "fda.gov",
    "nature.com", "science.org", "ieee.org", "acm.org", "wikipedia.org",
}


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]{2,}", (text or "").lower())


def _domain(url: str) -> str:
    try:
        host = urlparse(str(url)).netloc.lower().split(":")[0]
        return host[4:] if host.startswith("www.") else host
    except Exception:
        return "unknown"


def _domain_family(domain: str) -> str:
    parts = [p for p in domain.split(".") if p]
    return ".".join(parts[-2:]) if len(parts) >= 2 else domain


def risk_assessment(command: str) -> dict[str, Any]:
    c = command or ""
    hits = [name for name, pattern in _RISK_PATTERNS.items() if pattern.search(c)]
    level = "critical" if any(x in hits for x in ("destructive", "financial", "power")) else (
        "high" if hits else "normal"
    )
    return {
        "level": level,
        "categories": hits,
        "requires_confirmation": bool(hits),
        "reversible_preference": level in {"high", "critical"},
        "principle": "verify-before-commit" if hits else "verify-before-claim",
    }


def analyze_request(command: str) -> dict[str, Any]:
    c = (command or "").strip()
    words = len(_tokens(c))
    clauses = len(re.findall(r"\b(?:and then|then|after that|also|as well as|while|followed by|once|after)\b", c, re.I))
    objectives = len(re.findall(r"\b(?:and|then|also|plus|followed by|after that)\b", c, re.I)) + 1
    intents: list[str] = []
    if _RESEARCH.search(c): intents.append("research")
    if _CREATE.search(c): intents.append("creation")
    if _COMPUTER.search(c): intents.append("computer")
    if _MEMORY.search(c): intents.append("memory")
    if not intents: intents = ["conversation"]
    ambiguity = 0.0
    if words < 4: ambiguity += .25
    if re.search(r"\b(it|that|this|there|them|something|somewhere)\b", c, re.I): ambiguity += .2
    if objectives > 3: ambiguity += .12
    complexity = min(1.0, 0.06 + words / 105 + clauses * .11 + max(0, len(intents)-1)*.1)
    risk = risk_assessment(c)
    return {
        "version": VERSION, "command": c, "intents": intents,
        "complexity": round(complexity, 3), "ambiguity": round(min(1, ambiguity), 3),
        "risk": risk["level"], "risk_detail": risk,
        "objective_count": objectives, "requires_verification": complexity >= .25 or bool(_RESEARCH.search(c) or _CREATE.search(c) or risk["categories"]),
        "deliverable": "artifact" if _CREATE.search(c) else "answer",
        "planning_depth": 4 if complexity >= .7 else 3 if complexity >= .4 else 2,
    }


def build_execution_blueprint(command: str) -> dict[str, Any]:
    a = analyze_request(command)
    phases = ["understand", "plan"]
    if "research" in a["intents"]: phases += ["retrieve", "cross_check", "synthesize"]
    if "computer" in a["intents"]: phases += ["act", "observe"]
    if "creation" in a["intents"]: phases += ["construct", "inspect"]
    if "memory" in a["intents"]: phases += ["persist", "retrieve_check"]
    phases += ["verify", "respond"]
    return {
        "version": VERSION, "objective": command, "phases": list(dict.fromkeys(phases)),
        "parallelizable": [p for p in ("retrieve", "cross_check") if p in phases],
        "gates": ["scope", "risk", "evidence", "postcondition"],
        "stop_conditions": ["unsafe_confirmation_missing", "critical_verification_failure", "contradiction_unresolved"],
        "quality_targets": {
            "no_unverified_success_claim": True,
            "source_diversity": 2 if "research" in a["intents"] else 0,
            "artifact_integrity": "structural" if "creation" in a["intents"] else "none",
        },
        "analysis": a,
    }


def source_assessment(source: dict[str, Any] | str) -> dict[str, Any]:
    x = {"url": source} if isinstance(source, str) else (source or {})
    url = str(x.get("url") or "")
    domain = _domain(url)
    text = str(x.get("text") or x.get("snippet") or "")
    title = str(x.get("title") or "")
    score = 0.15
    reasons = []
    if domain in _HIGH_SIGNAL_DOMAINS:
        score += .45; reasons.append("high-signal-domain")
    if any(domain.endswith("." + t) or domain == t for t in _TRUSTED_TLDS):
        score += .3; reasons.append("institutional-domain")
    if len(text) >= 500: score += .15; reasons.append("substantive-material")
    if len(title) >= 10: score += .05
    if re.search(r"press release|opinion|blog|forum|reddit|social media", (title+" "+text), re.I):
        score -= .12; reasons.append("secondary-or-opinion-signal")
    return {"domain": domain, "score": round(max(0, min(1, score)), 3), "reasons": reasons}


def audit_research(result: dict[str, Any]) -> dict[str, Any]:
    sources = result.get("sources") or result.get("_raw_sources") or []
    rows = [({"url": s} if isinstance(s, str) else s) for s in sources if isinstance(s, (str, dict))]
    assessments = [source_assessment(s) for s in rows]
    domains = [_domain(x.get("url", "")) for x in rows if x.get("url")]
    families = {_domain_family(d) for d in domains if d != "unknown"}
    texts = [str(x.get("text") or x.get("snippet") or x.get("title") or "") for x in rows]
    combined = " ".join(texts)
    years = [int(y) for y in re.findall(r"\b(20\d{2})\b", combined) if 2000 <= int(y) <= 2100]
    mean_signal = statistics.mean([x["score"] for x in assessments]) if assessments else 0
    claim_lines = [re.sub(r"\s+", " ", line).strip() for line in combined.split(".") if len(line.strip()) > 35]
    return {
        "source_count": len(rows), "unique_domains": len(set(domains)), "domains": sorted(set(domains))[:30],
        "domain_families": sorted(families)[:30], "source_diversity": round(min(1, len(families)/4), 2),
        "mean_source_signal": round(mean_signal, 3), "max_source_signal": round(max([x["score"] for x in assessments], default=0), 3),
        "years_observed": sorted(set(years))[-12:],
        "freshness_signal": round(min(1, max(years)-2020)/6, 2) if years else None,
        "needs_corroboration": len(families) < 2 and bool(rows),
        "has_material": bool(combined.strip()), "claim_candidate_count": min(100, len(claim_lines)),
        "source_assessments": assessments[:30],
        "limitations": ["URL/date metadata may be incomplete", "heuristic source scoring is not a substitute for human/source judgment"],
    }


def _extract_doc_text(path: Path) -> str:
    try:
        suffix = path.suffix.lower()
        if suffix in {".txt", ".md", ".json", ".py"}:
            return path.read_text(encoding="utf-8", errors="ignore")
        if suffix == ".docx":
            from docx import Document
            d = Document(str(path)); return "\n".join([p.text for p in d.paragraphs] + [c.text for t in d.tables for r in t.rows for c in r.cells])
        if suffix == ".pdf":
            from pypdf import PdfReader
            return "\n".join((p.extract_text() or "") for p in PdfReader(str(path)).pages)
        if suffix == ".xlsx":
            from openpyxl import load_workbook
            wb = load_workbook(str(path), read_only=True, data_only=True)
            out=[]
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True): out.append(" ".join(str(v) for v in row if v is not None))
            wb.close(); return "\n".join(out)
        if suffix == ".pptx":
            from pptx import Presentation
            prs=Presentation(str(path)); return "\n".join(shape.text for s in prs.slides for shape in s.shapes if hasattr(shape,"text"))
    except Exception:
        return ""
    return ""


def audit_artifacts(files: list[str] | None) -> dict[str, Any]:
    checks=[]
    for raw in files or []:
        p=Path(raw); exists=p.exists() and p.is_file(); size=p.stat().st_size if exists else 0
        readable=False; structural=False; text_signal=0
        if exists and size:
            try:
                p.open("rb").read(32); readable=True
                text=_extract_doc_text(p)
                structural=bool(text.strip()) if p.suffix.lower() in {".docx",".pdf",".xlsx",".pptx"} else True
                text_signal=min(1, len(text)/1000) if text else 0
            except Exception: pass
        checks.append({"path":str(p),"exists":exists,"size":size,"extension":p.suffix.lower(),
                       "sha256":hashlib.sha256(p.read_bytes()).hexdigest() if exists and size < 50_000_000 else None,
                       "readable":readable,"structurally_readable":structural,"content_signal":round(text_signal,3),
                       "ok":bool(exists and size and readable and structural)})
    return {"files":checks,"all_ok":all(x["ok"] for x in checks) if checks else False,"count":len(checks),
            "integrity": "verified" if checks and all(x["ok"] for x in checks) else "incomplete"}


def contradiction_scan(text: str) -> list[dict[str,str]]:
    lines=[re.sub(r"\s+"," ",x).strip() for x in str(text or "").splitlines() if x.strip()]
    out=[]
    numeric=defaultdict(list)
    for line in lines:
        for m in re.finditer(r"\b(\d+(?:\.\d+)?)\s*(%|percent|years?|km|kg|million|billion)?\b",line,re.I):
            numeric[m.group(0).lower()].append(line[:220])
    for token, rows in numeric.items():
        if len(rows)>1: out.append({"token":token,"detail":"Repeated quantitative claim; context/source cross-check recommended.","examples":" | ".join(rows[:3])})
    # Direct polarity conflicts are useful triage signals, not proof of contradiction.
    for key in ("increases", "decreases", "higher", "lower", "more", "less", "causes", "prevents"):
        pos=[x for x in lines if re.search(rf"\b{key}\b",x,re.I)]
        if len(pos)>1: out.append({"token":key,"detail":"Repeated directional claim; compare subjects, populations and conditions."})
    return out[:30]


def memory_key(text: str) -> str:
    normalized=re.sub(r"\W+"," ",(text or "").lower()).strip()
    return hashlib.sha256(normalized.encode()).hexdigest()[:24]


def memory_importance(text: str, metadata: dict[str, Any] | None = None) -> float:
    m=metadata or {}; score=.2
    score += min(.25, len(_tokens(text))/80)
    if m.get("status") in {"completed", "verified"}: score += .2
    if m.get("task_id"): score += .1
    if re.search(r"\b(preference|decision|goal|project|constraint|important|deadline)\b", text, re.I): score += .25
    return round(min(1, score),3)


def verification_plan(command: str) -> list[str]:
    a=analyze_request(command); p=["confirm intended operation and scope", "check postcondition before claiming success"]
    if a["ambiguity"] > .3: p += ["resolve or conservatively interpret ambiguous references"]
    if "research" in a["intents"]: p += ["cross-check independent sources", "separate sourced facts from inference", "retain provenance and limitations", "scan for conflicting claims"]
    if "creation" in a["intents"]: p += ["verify requested files exist and are non-empty", "structurally inspect generated output"]
    if "computer" in a["intents"]: p += ["verify visible post-action state", "avoid claiming action from intent alone"]
    if "memory" in a["intents"]: p += ["confirm memory write/retrieval result"]
    if a["risk"] != "normal": p += ["obtain explicit confirmation before consequential commit"]
    return list(dict.fromkeys(p))


def quality_summary(command: str, research: dict[str,Any] | None=None, files: list[str] | None=None) -> dict[str,Any]:
    report={"hub_version":VERSION,"request":analyze_request(command),"blueprint":build_execution_blueprint(command),"verification_plan":verification_plan(command),"timestamp":time.time()}
    if research is not None: report["research_audit"]=audit_research(research)
    if files is not None: report["artifact_audit"]=audit_artifacts(files)
    return report
