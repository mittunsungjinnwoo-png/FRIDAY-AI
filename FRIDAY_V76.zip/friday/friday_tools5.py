"""FRIDAY 5.0 tool intelligence, permissions and audit log.

FRIDAY decides which tool to use (nobody has to name it):

    "why is my laptop hot?"  ->  system monitor -> CPU / RAM / processes / temperature / battery -> diagnosis

Every tool has a risk level.  `safe` tools (read-only) run at once.  `confirm` tools (write / run code / delete)
need an explicit "yes" and can be revoked ("revoke file writing").  Every call is written to an audit log with
secrets redacted; suggesting is always separate from executing.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional

HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("FRIDAY_DATA") or (HERE / "friday_data"))
AUDIT_FILE = DATA_DIR / "audit5.jsonl"
PERM_FILE = DATA_DIR / "permissions5.json"
OUTPUT_DIR = DATA_DIR / "outputs"
_lock = threading.Lock()

_SECRET = re.compile(r"(AIza[0-9A-Za-z_\-]{20,}|sk-[A-Za-z0-9_\-]{16,}|(?i:password|passcode|api[ _-]?key|secret|token)\s*[=:]\s*\S+)")


def redact(text: str) -> str:
    return _SECRET.sub("[redacted]", str(text))


# ---------------------------------------------------------------- permissions
DEFAULT_PERMS = {"read_files": True, "write_files": True, "run_code": True, "system_info": True, "delete_files": False}


def perms() -> Dict[str, bool]:
    try:
        d = json.loads(PERM_FILE.read_text(encoding="utf-8"))
        return {**DEFAULT_PERMS, **{k: bool(v) for k, v in d.items() if k in DEFAULT_PERMS}}
    except Exception:
        return dict(DEFAULT_PERMS)


def set_perm(name: str, value: bool):
    p = perms()
    if name in p:
        p[name] = bool(value)
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        PERM_FILE.write_text(json.dumps(p, indent=2), encoding="utf-8")
        audit("permission", f"{name}={'granted' if value else 'revoked'}", "ok")


_PERM_WORDS = {"file writing": "write_files", "writing files": "write_files", "file creation": "write_files", "creating files": "write_files",
               "code running": "run_code", "running code": "run_code", "code execution": "run_code", "file reading": "read_files",
               "reading files": "read_files", "system info": "system_info", "system monitoring": "system_info", "deleting files": "delete_files",
               "file deletion": "delete_files"}


def handle_permission_command(text: str) -> Optional[str]:
    low = (text or "").lower().strip(" .!?")
    m = re.match(r"^(revoke|disable|turn off|deny|allow|grant|enable|turn on)\s+(?:your\s+)?(?:permission (?:for|to)\s+)?(.+)$", low)
    if not m:
        if re.match(r"^(?:show|list|what are)\s+(?:my\s+|your\s+)?permissions$", low):
            return "Permissions. " + ". ".join(f"{k.replace('_', ' ')}: {'allowed' if v else 'blocked'}" for k, v in perms().items()) + "."
        return None
    verb, what = m.group(1), m.group(2).strip()
    for words, key in _PERM_WORDS.items():
        if words in what:
            on = verb in {"allow", "grant", "enable", "turn on"}
            set_perm(key, on)
            return f"{words.capitalize()} is now {'allowed' if on else 'blocked'}."
    return None


# ---------------------------------------------------------------- audit
def audit(tool: str, detail: str, result: str = "ok"):
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        rec = {"t": time.strftime("%Y-%m-%d %H:%M:%S"), "tool": tool, "detail": redact(detail)[:400], "result": result}
        with _lock:
            with AUDIT_FILE.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def recent_audit(n: int = 10) -> List[dict]:
    try:
        lines = AUDIT_FILE.read_text(encoding="utf-8").splitlines()[-n:]
        return [json.loads(x) for x in lines]
    except Exception:
        return []


# ---------------------------------------------------------------- pending confirmation
_pending: Dict[str, object] = {"desc": None, "fn": None, "t": 0.0}


def request_confirmation(description: str, fn: Callable[[], str]) -> str:
    _pending.update(desc=description, fn=fn, t=time.time())
    audit("confirm-requested", description)
    return f"I'm ready to {description}. Shall I go ahead?"


def has_pending() -> bool:
    return bool(_pending["fn"]) and time.time() - float(_pending["t"]) < 120


def answer_confirmation(text: str) -> Optional[str]:
    """Returns the spoken result when the reply was a yes/no to a pending action, else None."""
    if not has_pending():
        _pending.update(desc=None, fn=None)
        return None
    low = (text or "").lower().strip(" .!?,")
    if re.match(r"^(?:yes|yeah|yep|sure|go ahead|do it|confirm|proceed|please do|okay|ok|affirmative|yes please)\b", low):
        fn, desc = _pending["fn"], _pending["desc"]
        _pending.update(desc=None, fn=None)
        try:
            out = fn()
            audit("confirmed", str(desc), "ok")
            return out
        except Exception as exc:
            audit("confirmed", str(desc), f"failed: {exc}")
            return f"That failed: {exc}"
    if re.match(r"^(?:no|nope|don'?t|cancel|stop|never ?mind|negative|abort)\b", low):
        audit("declined", str(_pending["desc"]))
        _pending.update(desc=None, fn=None)
        return "Understood. I have not done it."
    return None


# ---------------------------------------------------------------- system diagnostics
def system_snapshot() -> dict:
    import psutil  # type: ignore
    snap = {"cpu": psutil.cpu_percent(interval=0.4), "cores": psutil.cpu_count(logical=True)}
    vm = psutil.virtual_memory()
    snap["ram_percent"], snap["ram_used_gb"], snap["ram_total_gb"] = vm.percent, round(vm.used / 1e9, 1), round(vm.total / 1e9, 1)
    try:
        du = psutil.disk_usage(os.path.abspath(os.sep))
        snap["disk_percent"], snap["disk_free_gb"] = du.percent, round(du.free / 1e9, 1)
    except Exception:
        pass
    try:
        b = psutil.sensors_battery()
        if b:
            snap["battery"], snap["plugged"] = round(b.percent), bool(b.power_plugged)
    except Exception:
        pass
    try:
        temps = psutil.sensors_temperatures() if hasattr(psutil, "sensors_temperatures") else {}
        vals = [t.current for arr in temps.values() for t in arr if t.current]
        if vals:
            snap["temp_c"] = round(max(vals))
    except Exception:
        pass
    procs = []
    for p in psutil.process_iter(["name", "cpu_percent", "memory_percent"]):
        try:
            p.cpu_percent(None)
            procs.append(p)
        except Exception:
            pass
    time.sleep(0.35)
    rows = []
    for p in procs:
        try:
            rows.append((p.cpu_percent(None) / max(1, snap["cores"]), p.info.get("memory_percent") or 0, p.info.get("name") or "?"))
        except Exception:
            pass
    agg: Dict[str, List[float]] = {}
    for c, m, n in rows:
        a = agg.setdefault(n, [0.0, 0.0])
        a[0] += c
        a[1] += m
    snap["top_cpu"] = sorted(((n, round(v[0], 1)) for n, v in agg.items() if n.lower() not in {"system idle process", "idle"}), key=lambda x: -x[1])[:4]
    snap["top_ram"] = sorted(((n, round(v[1], 1)) for n, v in agg.items()), key=lambda x: -x[1])[:3]
    return snap


def diagnose(question: str, snap: Optional[dict] = None) -> str:
    """Rule-based diagnosis from real measurements (no model call, so it is instant and cannot invent numbers)."""
    if not perms()["system_info"]:
        return "System monitoring is blocked in my permissions."
    try:
        s = snap or system_snapshot()
    except Exception as exc:
        audit("system_monitor", question, f"failed: {exc}")
        return "I couldn't read the system sensors on this machine."
    audit("system_monitor", question, "ok")
    q = (question or "").lower()
    facts, findings, advice = [], [], []
    facts.append(f"CPU is at {s['cpu']:.0f} percent")
    facts.append(f"memory {s['ram_percent']:.0f} percent used ({s['ram_used_gb']} of {s['ram_total_gb']} gigabytes)")
    if "temp_c" in s:
        facts.append(f"hottest sensor reads {s['temp_c']} degrees")
    if "battery" in s:
        facts.append(f"battery {s['battery']} percent{', charging' if s.get('plugged') else ', on battery'}")
    top = [(n, c) for n, c in s.get("top_cpu", []) if c >= 5]
    if s["cpu"] >= 70:
        findings.append("the processor is heavily loaded")
        if top:
            findings.append("the main consumer is " + top[0][0] + f" at about {top[0][1]:.0f} percent")
            advice.append(f"close or restart {top[0][0]} if you don't need it")
    if s["ram_percent"] >= 85:
        findings.append("memory is nearly full, which makes everything slow")
        if s.get("top_ram"):
            advice.append(f"{s['top_ram'][0][0]} is using the most memory")
    if s.get("temp_c", 0) >= 85:
        findings.append("the machine is running hot")
        advice.append("check the vents and fans, and avoid soft surfaces such as a bed")
    if s.get("disk_percent", 0) >= 92:
        findings.append(f"the disk is {s['disk_percent']:.0f} percent full")
        advice.append("free some disk space")
    if s.get("battery", 100) <= 15 and not s.get("plugged"):
        findings.append("the battery is very low")
    if not findings:
        findings.append("nothing looks wrong right now")
        if any(w in q for w in ("hot", "heat", "warm", "slow", "lag", "fan")):
            advice.append("if the problem comes and goes, ask me again while it is happening so I can catch it")
    out = "I checked the system. " + ", ".join(facts) + ". " + ". ".join(x.capitalize() for x in findings) + "."
    if advice:
        out += " Suggestion: " + "; ".join(advice) + "."
    return out


# ---------------------------------------------------------------- code sandbox
def run_python(code: str, timeout: float = 10.0) -> dict:
    """Run Python in a separate process with a temp working directory and a hard timeout.  Not a security
    boundary against malicious code - it is only ever called after the user confirmed."""
    if not perms()["run_code"]:
        return {"ok": False, "error": "Running code is blocked in my permissions."}
    d = tempfile.mkdtemp(prefix="friday_run_")
    f = Path(d) / "main.py"
    f.write_text(code, encoding="utf-8")
    t0 = time.time()
    try:
        r = subprocess.run([sys.executable, "-I", str(f)], cwd=d, capture_output=True, text=True, timeout=timeout,
                           env={"PATH": os.environ.get("PATH", ""), "PYTHONIOENCODING": "utf-8", "SYSTEMROOT": os.environ.get("SYSTEMROOT", "")})
        res = {"ok": r.returncode == 0, "stdout": r.stdout[-4000:], "stderr": r.stderr[-2000:], "code": r.returncode, "seconds": round(time.time() - t0, 2)}
    except subprocess.TimeoutExpired:
        res = {"ok": False, "stdout": "", "stderr": f"Stopped after {timeout:.0f} seconds (timeout).", "code": -1, "seconds": timeout}
    except Exception as exc:
        res = {"ok": False, "stdout": "", "stderr": str(exc), "code": -1, "seconds": 0}
    audit("run_python", code[:160].replace("\n", " "), "ok" if res["ok"] else "error")
    return res


def check_python_syntax(code: str) -> Optional[str]:
    try:
        compile(code, "<attached>", "exec")
        return None
    except SyntaxError as e:
        return f"line {e.lineno}: {e.msg}"


# ---------------------------------------------------------------- files
def _safe_name(n: str) -> str:
    return re.sub(r"[^A-Za-z0-9._ -]", "_", Path(n).name)[:120] or "file.txt"


def write_output(name: str, content: str) -> Optional[Path]:
    """Create a file in FRIDAY's outputs folder (never overwrites: adds a counter)."""
    if not perms()["write_files"]:
        return None
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    p = OUTPUT_DIR / _safe_name(name)
    i = 1
    while p.exists():
        p = OUTPUT_DIR / f"{p.stem.rsplit(' (', 1)[0]} ({i}){p.suffix}"
        i += 1
    p.write_text(content, encoding="utf-8")
    audit("write_file", str(p), "ok")
    return p


def search_files(query: str, roots: Optional[List[str]] = None, limit: int = 8) -> List[str]:
    if not perms()["read_files"]:
        return []
    roots = roots or [str(Path.home() / d) for d in ("Documents", "Desktop", "Downloads")] + [str(HERE)]
    toks = [t for t in re.findall(r"[a-z0-9]+", query.lower()) if len(t) > 1]
    out = []
    for r in roots:
        if not os.path.isdir(r):
            continue
        for dp, dn, fn in os.walk(r):
            dn[:] = [d for d in dn if d not in {"node_modules", ".git", "__pycache__", "AppData"}]
            for f in fn:
                if toks and all(t in f.lower() for t in toks):
                    out.append(os.path.join(dp, f))
                    if len(out) >= limit:
                        audit("search_files", query, f"{len(out)} found")
                        return out
    audit("search_files", query, f"{len(out)} found")
    return out


def analyze_folder(folder: str) -> str:
    if not perms()["read_files"]:
        return "Reading files is blocked in my permissions."
    p = Path(folder)
    if not p.is_dir():
        return "I can't find that folder."
    counts: Dict[str, int] = {}
    total = size = 0
    biggest = []
    for f in p.rglob("*"):
        if any(x in f.parts for x in ("node_modules", ".git", "__pycache__")):
            continue
        if f.is_file():
            total += 1
            s = f.stat().st_size
            size += s
            counts[f.suffix.lower() or "(none)"] = counts.get(f.suffix.lower() or "(none)", 0) + 1
            biggest.append((s, f.name))
            if total >= 20000:
                break
    top = sorted(counts.items(), key=lambda x: -x[1])[:4]
    biggest.sort(reverse=True)
    audit("analyze_folder", folder, "ok")
    return (f"{p.name} holds {total} files, {size / 1e6:.1f} megabytes. Mostly " + ", ".join(f"{n} {e}" for e, n in top) +
            (f". Largest is {biggest[0][1]}." if biggest else "."))


# ---------------------------------------------------------------- command entry
def handle(command: str) -> Optional[str]:
    """Tool commands that need no language model."""
    t = (command or "").strip()
    low = t.lower().strip(" .!?")
    r = handle_permission_command(t)
    if r:
        return r
    if re.search(r"\b(?:why is|why's|find why|figure out why|diagnose|check)\b.*\b(?:laptop|pc|computer|system|machine|cpu|fan|battery|memory|ram|slow|hot|lagging|overheat)", low) or \
            re.match(r"^(?:system (?:status|health|check)|how(?:'s| is) (?:my|the) (?:system|pc|computer|laptop))\b", low) or \
            re.match(r"^(?:check|run) (?:a )?system (?:check|diagnostics?|health)", low) or "getting hot" in low or "overheating" in low:
        return diagnose(t)
    m = re.match(r"^(?:analy[sz]e|inspect|summari[sz]e|go through)\s+(?:my\s+|the\s+)?folder\s+(.+)$", t, re.I)
    if m:
        return analyze_folder(m.group(1).strip().strip('"'))
    m = re.match(r"^(?:find|search for|locate)\s+(?:the\s+|my\s+)?file(?:s)?\s+(?:called\s+|named\s+)?(.+)$", t, re.I)
    if m:
        hits = search_files(m.group(1))
        return ("I found " + ("; ".join(os.path.basename(h) + " in " + os.path.basename(os.path.dirname(h)) for h in hits[:3])) + (f" and {len(hits) - 3} more" if len(hits) > 3 else "") + ".") if hits else "I couldn't find a matching file."
    if re.match(r"^(?:show|read)\s+(?:the\s+|my\s+)?(?:audit|action)\s+log$", low):
        rows = recent_audit(5)
        return ("Recent actions. " + ". ".join(f"{r['tool']}: {r['detail'][:60]}, {r['result']}" for r in rows) + ".") if rows else "The action log is empty."
    return None


def tool_list() -> List[dict]:
    p = perms()
    return [
        {"name": "System monitor", "risk": "safe", "enabled": p["system_info"]},
        {"name": "Read & search files", "risk": "safe", "enabled": p["read_files"]},
        {"name": "Create files", "risk": "confirm", "enabled": p["write_files"]},
        {"name": "Run code", "risk": "confirm", "enabled": p["run_code"]},
        {"name": "Delete files", "risk": "confirm", "enabled": p["delete_files"]},
    ]
