/* FRIDAY 7.0 - new HUD interface controller (Home screen, header, footer, right column, effects).
   Loaded after the original page script and the other friday_*.js files. It re-uses every existing function
   (cmd, msg, listen, state, mod, toast, X, S ...) and only replaces how they are shown.
   The Settings & Features hub lives in friday_hub8.js. */
(function () {
  'use strict';
  const T = window.Theme, B = window.fridayBridge || null;
  const $ = s => document.querySelector(s), $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
  const E = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const F8 = window.F8 = { A: {}, hub: null };
  const p2 = n => String(n).padStart(2, '0');
  const DAY3 = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], MON3 = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const ymd = d => (d || new Date()).getFullYear() + '-' + p2((d || new Date()).getMonth() + 1) + '-' + p2((d || new Date()).getDate());
  const rem = () => parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
  function fmt12(t, pad) { const m = /^(\d{1,2}):(\d{2})/.exec(t || ''); if (!m) return t || ''; let h = +m[1]; const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12; return (pad ? p2(h) : h) + ':' + m[2] + ' ' + ap; }
  const nowT = () => { const d = new Date(); return p2(d.getHours()) + ':' + p2(d.getMinutes()); };
  F8.E = E; F8.p2 = p2; F8.ymd = ymd; F8.fmt12 = fmt12; F8.DAY3 = DAY3; F8.rem = rem;

  /* ================================================================ icons */
  const I8 = {
    home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5h13V10"/><path d="M10 19.5v-5h4v5"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M8.5 21h7"/>',
    camera: '<path d="M4 8.5h3l1.5-2.5h7L17 8.5h3a1 1 0 0 1 1 1V18a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9.5a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
    send: '<path d="M3.5 11.5 20.5 3.5l-6 17-3-7z"/><path d="M11.5 13.5 20 4"/>',
    clip: '<path d="M20 11.5l-8 8a5 5 0 0 1-7-7l8.5-8.5a3.3 3.3 0 0 1 4.7 4.7L9.7 17.2a1.7 1.7 0 0 1-2.4-2.4l7.8-7.8"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    calgrid: '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4M8 14h2M12 14h2M8 17h2M12 17h2"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    brain: '<path d="M9 4.5a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 3 4.5 3 3 0 0 0 5 1.5V5.5a2.5 2.5 0 0 0-3-1z"/><path d="M15 4.5a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-3 4.5 3 3 0 0 1-5 1.5"/><path d="M9 9h1.5M13.5 9H15M9 13h1.5M13.5 13H15"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3.2"/>',
    db: '<ellipse cx="12" cy="6" rx="7.5" ry="3"/><path d="M4.5 6v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3V6M4.5 12v6c0 1.7 3.4 3 7.5 3s7.5-1.3 7.5-3v-6"/>',
    bolt: '<path d="M13 2.5 5 13.5h6l-1 8 8-11h-6z"/>',
    brush: '<path d="M18.5 3.5l2 2L11 15l-2.5-.5L8 12z"/><path d="M8 14c-2.5 0-4 1.5-4 4.5 0 1 .2 1.5.2 1.5s.5.2 1.5.2c3 0 4.5-1.5 4.5-4"/>',
    wallet: '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18M16 14.5h2"/>',
    folder: '<path d="M3 6.5h6l2 2.5h10v10.5H3z"/>',
    folderopen: '<path d="M3 7a1 1 0 0 1 1-1h5l2 2.5h8a1 1 0 0 1 1 1V18a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z"/><path d="M3 11h18"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M20.5 20.5 16 16"/>',
    back: '<path d="M15 5l-7 7 7 7"/>', chev: '<path d="M9 5l7 7-7 7"/>',
    power: '<path d="M12 3v9"/><path d="M6.5 6.5a8 8 0 1 0 11 0"/>',
    exit: '<path d="M10 4H5.5A1.5 1.5 0 0 0 4 5.5v13A1.5 1.5 0 0 0 5.5 20H10"/><path d="M14 8l4 4-4 4M18 12H9"/>',
    focus: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><path d="M12 3.5V6M12 18v2.5M3.5 12H6M18 12h2.5"/>',
    shot: '<path d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16"/><circle cx="12" cy="12" r="3"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14.5-4M4 4v4h4M4 13a8 8 0 0 0 14.5 4M20 20v-4h-4"/>',
    wifi: '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.7 16a5 5 0 0 1 6.6 0"/><circle cx="12" cy="19.2" r="1"/>',
    pulse: '<path d="M2 12h3.5l2-6 3.5 12 3-9 1.8 3H22"/>',
    bars: '<path d="M4 10v4M8 6v12M12 3v18M16 7v10M20 10v4"/>',
    shield: '<path d="M12 3l7.5 3v5.5c0 4.5-3.2 8-7.5 9.5-4.3-1.5-7.5-5-7.5-9.5V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
    bell: '<path d="M6 16.5h12l-1.6-2.4V10a4.4 4.4 0 0 0-8.8 0v4.1zM10 19.5h4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', x: '<path d="M6 6l12 12M18 6L6 18"/>', min: '<path d="M5 12h14"/>', widget: '<rect x="3.5" y="5" width="17" height="14" rx="2"/><rect x="11" y="11" width="7" height="5" rx="1"/>', max: '<rect x="5.5" y="5.5" width="13" height="13" rx="1"/>',
    tasks: '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M8.5 12.2l2.5 2.5 4.5-5"/>',
    plan: '<path d="M9 4h6v3H9z"/><rect x="5.5" y="5.5" width="13" height="15" rx="2"/><path d="M9 14l2.2 2.2L15 12"/>',
    study: '<path d="M2.5 9.5L12 5l9.5 4.5L12 14z"/><path d="M6.5 11.8v4.2c1.5 1.6 3.4 2.4 5.5 2.4s4-.8 5.5-2.4v-4.2"/>',
    memcheck: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 12.5l2.4 2.4 4.6-5"/>',
    users: '<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="12" cy="10.5" r="2.2"/><path d="M8 17c.8-2 2.2-3 4-3s3.2 1 4 3"/>',
    stopwatch: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9v4l2.5 1.5M9.5 3h5M12 3v2.5"/>',
    face: '<circle cx="12" cy="12" r="8.5"/><path d="M9 10v1M15 10v1M8.8 14.5c1 1.4 2.1 2 3.2 2s2.2-.6 3.2-2"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12.5l9 5 9-5"/><path d="M3 17l9 5 9-5"/>',
    cpu: '<rect x="7" y="7" width="10" height="10" rx="1.5"/><path d="M9 3v4M15 3v4M9 17v4M15 17v4M3 9h4M3 15h4M17 9h4M17 15h4"/>',
    user: '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20.5c1-4 4-6 7.5-6s6.5 2 7.5 6"/>',
    chat: '<path d="M4 5.5h16v11H9.5L5 20.5v-4H4z"/>', trash: '<path d="M4 7h16M9 7V4.5h6V7M6.5 7l1 13h9l1-13"/>', pen: '<path d="M4 20l1-4.5L16.5 4 20 7.5 8.5 19z"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="1.5"/>', play: '<path d="M7 4.5v15l12-7.5z"/>', pause: '<path d="M8 5v14M16 5v14"/>',
    rec: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.6" fill="currentColor"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>',
    sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM18.5 16l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8z"/>',
    sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
    download: '<path d="M12 4v11M7.5 10.5L12 15l4.5-4.5M5 19.5h14"/>', upload: '<path d="M12 15V4M7.5 8.5L12 4l4.5 4.5M5 19.5h14"/>',
    link: '<path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3M14 9l2 2"/>',
    lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.1"/>',
    wave: '<path d="M3 12h2M7 7v10M11 4v16M15 8v8M19 11v2"/>',
    grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
    list: '<path d="M8.5 6.5H20M8.5 12H20M8.5 17.5H20M4 6.5h.1M4 12h.1M4 17.5h.1"/>',
    target: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
    reactor: '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4.5"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/>',
    tv: '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 20h8M12 17v3"/>',
    speaker: '<path d="M4 9.5v5h3.5L12.5 19V5L7.5 9.5z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
    book: '<path d="M5 4.5h10a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h10"/>'
  };
  const svg = (n, c) => '<svg class="i8' + (c ? ' ' + c : '') + '" viewBox="0 0 24 24">' + (I8[n] || '') + '</svg>';
  F8.I8 = I8; F8.svg = svg;

  /* FRIDAY mark + wordmark drawn as SVG (no font download needed) */
  let uidN = 0;
  function logoSvg(cls) {
    const id = 'lg' + (++uidN), d = T.LOGO_D;
    return '<svg class="' + (cls || '') + '" viewBox="0 0 100 100"><defs><linearGradient id="' + id + 'a" x1="0" y1="0" x2=".45" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" style="stop-color:var(--a2)"/></linearGradient><linearGradient id="' + id + 'b" x1=".4" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--a2)"/><stop offset="1" style="stop-color:var(--a3)"/></linearGradient></defs>' +
      '<path d="' + d[0] + '" fill="url(#' + id + 'a)"/><path d="' + d[1] + '" fill="url(#' + id + 'b)"/><path d="' + d[2] + '" style="fill:var(--a2)"/><path d="' + d[3] + '" fill="#fff"/></svg>';
  }
  const GL = { F: 'M3 25V3h18M3 14h15', R: 'M3 25V3h13.5a5.6 5.6 0 0 1 0 11.2H3M14.5 14.2L21.5 25', I: 'M3 3v22', D: 'M3 3h11a8 8 0 0 1 8 8v6a8 8 0 0 1-8 8H3z', A: 'M2 25L12 3l10 22M5.8 17.5h12.4', Y: 'M2 3l10 12L22 3M12 15v10' };
  function wordmark(cls, sw) {
    const id = 'wm' + (++uidN), off = { F: 0, R: 38, I: 76, D: 96, A: 134, Y: 172 };
    return '<svg class="' + (cls || '') + '" viewBox="0 0 196 29"><defs><linearGradient id="' + id + '" gradientUnits="userSpaceOnUse" x1="0" y1="3" x2="0" y2="25"><stop offset="0" stop-color="#fff"/><stop offset="1" style="stop-color:color-mix(in srgb,var(--a2) 70%,#fff)"/></linearGradient></defs><g transform="translate(0,2)" fill="none" stroke="url(#' + id + ')" stroke-width="' + (sw || 3.4) + '" stroke-linecap="round" stroke-linejoin="round">' +
      Object.keys(GL).map(k => '<path transform="translate(' + off[k] + ',0)" d="' + GL[k] + '"/>').join('') + '</g></svg>';
  }
  F8.logoSvg = logoSvg; F8.wordmark = wordmark;

  /* decorative gear avatar next to the greeting */
  function gearAvatar() {
    const pts = [], n = 8, Ro = 17, Ri = 13.2;
    for (let i = 0; i < n; i++) { const a0 = i / n * 6.2832, w = .17, a = [a0 - w * 1.5, a0 - w, a0 + w, a0 + w * 1.5]; pts.push([Ri, a[0]], [Ro, a[1]], [Ro, a[2]], [Ri, a[3]]); }
    const d = pts.map((p, i) => (i ? 'L' : 'M') + (50 + Math.cos(p[1]) * p[0]).toFixed(1) + ' ' + (50 + Math.sin(p[1]) * p[0]).toFixed(1)).join('') + 'Z M50 41a9 9 0 1 0 .01 0z';
    return '<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="47" fill="none" style="stroke:var(--a)" stroke-opacity=".55" stroke-width="1.4"/><g class="r1"><circle cx="50" cy="50" r="42" fill="none" style="stroke:var(--a2)" stroke-width="3.4" stroke-dasharray="40 14 62 14 40 14 62 14"/></g><g class="r2"><circle cx="50" cy="50" r="35" fill="none" style="stroke:var(--a)" stroke-width="1.4" stroke-dasharray="3 6"/></g><circle cx="50" cy="50" r="31" fill="#00112e" style="stroke:var(--a)" stroke-opacity=".6" stroke-width="1.2"/><path d="' + d + '" fill-rule="evenodd" style="fill:var(--a2)"/></svg>';
  }
  /* neon ring used behind the Settings card icons */
  F8.ring = function (c) { return '<svg class="rg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="47" fill="none" stroke="' + c + '" stroke-opacity=".28" stroke-width="1.2"/><g class="sp"><path d="M50 3a47 47 0 0 1 40 22" fill="none" stroke="' + c + '" stroke-width="3.2" stroke-linecap="round"/><path d="M97 50a47 47 0 0 1-22 40" fill="none" stroke="' + c + '" stroke-width="1.6" stroke-linecap="round" stroke-opacity=".7"/><path d="M50 97a47 47 0 0 1-40-22" fill="none" stroke="' + c + '" stroke-width="3.2" stroke-linecap="round"/><path d="M3 50A47 47 0 0 1 25 10" fill="none" stroke="' + c + '" stroke-width="1.6" stroke-linecap="round" stroke-opacity=".7"/></g></svg>'; };

  /* ================================================================ state helpers */
  const PG = F8.PG = { page: 'home', cat: null, tab: null };
  const setHTML = (el, h) => { if (el && el.__h !== h) { el.__h = h; el.innerHTML = h; } };
  function stText() { return ($('#st') && $('#st').textContent) || ''; }
  function uiState() {
    const t = stText();
    if (/^Speaking/.test(t)) return 'speaking';
    if (/^Recognizing/.test(t)) return 'recognizing';
    if (/^(Thinking|Working|Searching)/.test(t) || /%$/.test(t)) return 'thinking';
    if (/^Listening/.test(t)) return 'listening';
    return 'idle';
  }
  const camOn = () => { try { const s = window.FridayVision && window.FridayVision.state && window.FridayVision.state.session; return !!(s && s.running && s.kind === 'camera'); } catch (e) { return false; } };
  const online = () => navigator.onLine !== false;
  const engineUp = () => (B ? !!BS.ready : false);

  /* ================================================================ activity feed */
  const ACTV = [];
  function act(tx, icon, cls) {
    if (ACTV[0] && ACTV[0].tx === tx && Date.now() - ACTV[0].t < 4000) return;
    ACTV.unshift({ t: Date.now(), tx, icon: icon || 'check', cls: cls || '' }); ACTV.length = Math.min(ACTV.length, 40); renderLive();
  }
  F8.act = act;
  function renderLive() {
    const el = $('#liveBox'); if (!el) return;
    const base = [
      { tx: engineUp() ? 'FRIDAY is ready' : (B ? 'FRIDAY is starting...' : 'FRIDAY preview is ready'), icon: 'mic', cls: '', t: Date.now() },
      { tx: (typeof micOk !== 'undefined' && micOk === false) ? 'Microphone unavailable' : (typeof vmode !== 'undefined' && vmode === 'standby' && B) ? 'Voice standby (say “Friday”)' : 'Voice recognition active', icon: 'plus', cls: 'g', t: Date.now() },
      { tx: 'No new notifications', icon: 'check', cls: 'b', t: Date.now() }
    ];
    const rows = ACTV.slice(0, 3);
    for (let i = rows.length; i < 3; i++) rows.push(base[i - 0] || base[2]);
    const tm = t => fmt12(p2(new Date(t).getHours()) + ':' + p2(new Date(t).getMinutes()), true);
    setHTML(el, rows.map(r => '<div class="lv">' + (r.cls ? '<i class="dotc ' + r.cls + '">' + svg(r.icon === 'plus' ? 'plus' : 'check') + '</i>' : svg(r.icon)) + '<span class="tx" title="' + E(r.tx) + '">' + E(r.tx) + '</span><time>' + tm(r.t) + '</time></div>').join(''));
  }

  /* ================================================================ data: tasks + schedule */
  function seedData() {
    const today = ymd(), all = [0, 1, 2, 3, 4, 5, 6];
    if (!Array.isArray(X.todo)) {
      X.todo = [['Finish 9702 Momentum Notes', '10:00', 1], ['Study 9701 Bonding (Past Papers)', '12:00', 1], ['Work on FRIDAY UI Update', '15:00', 1], ['Gym / Football', '18:00', 0], ['Read AI Research Paper', '20:00', 0]]
        .map((r, i) => ({ id: uid() + i, n: r[0], t: r[1], days: all.slice(), d: '', done: r[2] ? { [today]: 1 } : {} }));
    }
    if (!Array.isArray(X.sched)) {
      X.sched = [{ id: uid() + 11, n: 'Maths Tuition', days: [2], s: '15:00', e: '19:00', ic: 'users' }, { id: uid() + 12, n: 'Physics Tuition (Online)', days: [3], s: '11:00', e: '13:00', ic: 'stopwatch' }, { id: uid() + 13, n: 'Chemistry Tuition', days: [6], s: '11:00', e: '13:30', ic: 'face' }];
    }
    if (!X.mode) X.mode = 'productivity';
    if (!Array.isArray(X.todo) || !Array.isArray(X.sched)) return;
  }
  const taskOn = (k, d) => { d = d || new Date(); return k.days && k.days.length ? k.days.indexOf(d.getDay()) >= 0 : k.d === ymd(d); };
  function todayList() {
    const d = new Date(), key = ymd(d), out = [];
    (X.todo || []).forEach(k => { if (taskOn(k, d)) out.push({ id: k.id, n: k.n, t: k.t, done: !!(k.done && k.done[key]), kind: 'todo' }); });
    (X.cal || []).forEach(c => { if (c.d === key) out.push({ id: c.id, n: c.n, t: c.t, done: !!c.done, kind: 'cal' }); });
    return out.sort((a, b) => (a.t || '').localeCompare(b.t || ''));
  }
  F8.todayList = todayList;
  function nextSched(limit) {
    const now = new Date(), items = [];
    (X.sched || []).forEach(s => {
      for (let o = 0; o < 8; o++) {
        const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + o);
        if (s.days.indexOf(d.getDay()) < 0) continue;
        const [eh, em] = (s.e || s.s || '00:00').split(':').map(Number), end = new Date(d.getFullYear(), d.getMonth(), d.getDate(), eh, em);
        if (end < now) continue;
        const [sh, sm] = s.s.split(':').map(Number), st = new Date(d.getFullYear(), d.getMonth(), d.getDate(), sh, sm);
        items.push({ id: s.id, n: s.n, at: st.getTime(), label: DAY3[d.getDay()] + ' ' + fmt12(s.s) + (s.e ? ' - ' + fmt12(s.e) : ''), ic: s.ic || 'users', kind: 'sched', soon: st - now < 2 * 3600e3 && st > now - 1 });
        break;
      }
    });
    (X.cal || []).forEach(c => {
      if (c.done || !c.d) return; const [hh, mm] = (c.t || '09:00').split(':').map(Number), p = c.d.split('-').map(Number), at = new Date(p[0], p[1] - 1, p[2], hh, mm);
      if (at.getTime() < now.getTime() - 3600e3 || at - now > 8 * 86400e3) return;
      items.push({ id: c.id, n: c.n, at: at.getTime(), label: DAY3[at.getDay()] + ' ' + fmt12(c.t), ic: 'calendar', kind: 'cal' });
    });
    return items.sort((a, b) => a.at - b.at).slice(0, limit || 3);
  }
  F8.nextSched = nextSched;
  const SCH_IC = ['users', 'stopwatch', 'face', 'calendar', 'book', 'cpu'];

  /* ================================================================ home panels */
  function renderTasks() {
    const el = $('#pTasks'); if (!el) return;
    const L = todayList(), dn = L.filter(x => x.done).length;
    setHTML(el, '<h4 class="ph"><span class="tk">' + svg('check') + '</span>Today’s Tasks<span class="cnt">' + svg('check') + dn + '/' + L.length + '</span></h4>' +
      '<ul class="tl">' + (L.length ? L.map(x => '<li class="tr ' + (x.done ? 'dn' : '') + (x.kind === 'cal' ? ' ev' : '') + '" data-a="taskTog" data-k="' + x.kind + '" data-id="' + x.id + '" title="Click to mark done / not done"><span class="cb">' + svg('check') + '</span><span class="tx">' + E(x.n) + '</span><time>' + (x.t ? fmt12(x.t, true) : '') + '</time></li>').join('') : '<li class="nothing">Nothing planned for today. Use <b>View All</b> to add tasks.</li>') + '</ul>' +
      '<button class="more" data-a="openTasks">View All</button>');
  }
  function renderSched() {
    const el = $('#pSched'); if (!el) return;
    const L = nextSched(3);
    setHTML(el, '<h4 class="ph">' + svg('calgrid') + 'Upcoming Schedule</h4><ul class="sc">' + (L.length ? L.map(x => '<li class="sr8' + (x.soon ? ' soon' : '') + '" data-a="openSched" title="Open the schedule">' + svg(x.ic) + '<div><b>' + E(x.n) + '</b><small>' + E(x.label) + '</small></div></li>').join('') : '<li class="nothing">No upcoming classes or events. Use <b>View Calendar</b> to add some.</li>') + '</ul><button class="more" data-a="openSched">View Calendar</button>');
  }
  function modelName() {
    let m = (window.__fridayModel || (window.__fridayApiLast && window.__fridayApiLast.model) || 'gemini-3.1-flash-lite');
    m = String(m).replace(/^models\//, '').replace(/[-_]+/g, ' ').replace(/\b([a-z])/g, c => c.toUpperCase());
    return m.replace(/(\d) (\d)/g, '$1.$2').replace(/Gemini/, 'Gemini');
  }
  function renderTiles() {
    const el = $('#tiles'); if (!el) return;
    const st = (window._st5 && window._st5.knowledge) || {}, memN = Math.max(X.mem.length, st.memories || 0), cam = camOn();
    let wf = 0; if (typeof lst !== 'undefined' && lst) wf++; if (cam) wf++; if (X.tasks.some(k => k.st === 'run')) wf++; if (FOCUS.on) wf++;
    const ai = !B ? ['Offline preview', 'warn', 'Preview'] : BS.gem ? ['Needs API key', 'warn', 'Add key'] : BS.ready ? [null, '', 'Online'] : ['Starting', 'warn', 'Starting'];
    const T4 = [
      ['ai', 'AI', 'brain', modelName(), ai[2], ai[1] || '', '', 'go:ai'],
      ['vision', 'Vision', 'eye', 'Camera Ready', cam ? 'Live Feed Active' : 'Feed Standby', cam ? '' : 'off', 'cyan', 'go:vision'],
      ['memory', 'Memory', 'db', memN + ' Memor' + (memN === 1 ? 'y' : 'ies') + ' Loaded', 'Quick Access', 'vi dia', 'violet', 'go:mem'],
      ['auto', 'Automation', 'gear', wf + ' Active Workflow' + (wf === 1 ? '' : 's'), wf ? 'Running' : 'Idle', wf ? 'cy dia' : 'off dia', '', 'go:auto']
    ];
    setHTML(el, T4.map(t => '<button class="hud clk tile ' + (t[6] === 'cyan' ? 'teal' : t[6]) + '" data-a="' + t[7] + '" title="Open ' + t[1] + '"><div class="tt"><span class="ti">' + svg(t[2]) + '</span><span class="tn">' + t[1] + '</span></div><span class="t1">' + E(t[3] || modelName()) + '</span><span class="t2 ' + t[5] + '">' + E(t[4]) + '</span></button>').join(''));
  }
  function renderGreet() {
    const g = T.greeting(), p = T.profile(), lead = g.lead + ',';
    if ($('#gLead')) $('#gLead').textContent = lead;
    const nm = p.name || ''; if ($('#gName')) setHTML($('#gName'), E(nm || T.cfg.assistant.name) + (p.badge ? '<em>' + E(p.badge) + '</em>' : ''));
    if ($('#gSub')) $('#gSub').textContent = p.ask || 'What shall we do today?';
    const c = T.cfg;
    if ($('#hTag')) $('#hTag').textContent = c.assistant.tagline || 'Your Productivity Companion';
    if ($('#hq1')) { $('#hq1').textContent = c.home.head1 || ''; $('#hq2').textContent = c.home.head2 || ''; }
    if ($('#fName')) $('#fName').textContent = c.assistant.name || 'FRIDAY';
    if ($('#qtext')) $('#qtext').textContent = c.home.card || '';
    document.title = c.assistant.name || 'FRIDAY';
  }

  /* ================================================================ right column */
  function statusRows() {
    const cam = camOn(), up = engineUp(), mic = (typeof micOk !== 'undefined' && micOk === false) ? ['Unavailable', 'bad'] : (!B ? ['Preview', 'off'] : (typeof vmode !== 'undefined' && vmode === 'standby') ? ['Standby', 'off'] : (typeof lst !== 'undefined' && lst) ? ['Active', ''] : ['Starting', 'warn']);
    return {
      core: !B ? ['Preview', 'warn'] : up ? ['Online', ''] : ['Starting', 'warn'],
      camera: cam ? ['Live', ''] : (B ? ['Ready', ''] : ['Off', 'off']),
      mic, memory: ['Normal', ''], net: online() ? ['Connected', ''] : ['Offline', 'bad'],
      voice: !B ? ['Preview', 'off'] : up ? ['Online', ''] : ['Starting', 'warn'],
      cam2: cam ? ['On', ''] : ['Off', ''],
      ai: !B ? ['Offline', 'off'] : BS.gem ? ['Needs key', 'warn'] : up ? ['Connected', ''] : ['Starting', 'warn'],
      mem2: ['Active', ''],
      auto: (X.tasks.some(k => k.st === 'run') || FOCUS.on) ? ['Running', ''] : ['Ready', '']
    };
  }
  function buildRight() {
    const rc = $('#rcol'); if (!rc || rc.__built) return; rc.__built = 1;
    rc.innerHTML =
      '<div id="rHome"><div class="hud pn" id="pStatus"></div><div class="hud pn" id="pActions"></div><div class="hud pn" id="pLive"><h4 class="lnk" data-a="actLog">' + svg('pulse', 'hi') + 'Live Activity</h4><div class="lvbox" id="liveBox"></div></div></div>' +
      '<div id="rSet"><div class="hud avf" id="avf" data-a="go:home" title="Back to FRIDAY"><canvas id="avC"></canvas><div class="ftab"><span id="avName">FRIDAY</span></div></div><div class="hud pn sm" id="pStatus2"></div><div class="hud pn sm" id="pQA2"></div><button class="hud exs red" data-a="exitSettings">' + svg('exit') + '<div><b>EXIT SETTINGS</b><small>Back to FRIDAY</small></div></button><div class="escn">Press Esc to exit</div></div>';
    T.reactor($('#avC'), { type: 'logo', scale: 340, getBoost: () => (typeof boost !== 'undefined' ? boost : 1), getState: uiState });
  }
  function renderRight() {
    buildRight();
    const s = statusRows(), R = (ic, n, v) => '<div class="srow" data-a="status">' + svg(ic) + '<span>' + n + '</span><em class="' + v[1] + '">' + v[0] + '</em></div>';
    setHTML($('#pStatus'), '<h4 class="lnk" data-a="status">' + svg('bars', 'hi') + 'System Status' + svg('chev', 'chv') + '</h4>' + R('cpu', 'FRIDAY Core', s.core) + R('camera', 'Camera', s.camera) + R('mic', 'Microphone', s.mic) + R('shield', 'Memory', s.memory) + R('wifi', 'Internet', s.net));
    const QA = (ic, t, sub, a, fill) => '<button class="qa" data-a="' + a + '"><span class="qi ' + (fill ? 'fill' : '') + '">' + svg(ic) + '</span><span class="qt">' + t + (sub ? '<small>' + sub + '</small>' : '') + '</span>' + svg('chev', 'chv') + '</button>';
    setHTML($('#pActions'), '<h4>' + svg('shot', 'hi') + 'Quick Actions</h4>' + QA('folderopen', 'Open File Explorer', '', 'qaFiles', 1) + QA('focus', 'Start Focus Mode', FOCUS.on ? 'Focus on · ' + focusLeft() : 'Block distractions', 'qaFocus') + QA('shot', 'Capture Screen', 'Screenshot / Record', 'qaCapture') + QA('gear', 'Open Settings', 'Configure FRIDAY', 'go:settings'));
    renderLive();
    const RI = (ic, n, v) => '<div class="srow" data-a="status"><span class="ri2">' + svg(ic) + '</span><span>' + n + '</span><em class="' + v[1] + '">' + v[0] + '</em></div>';
    setHTML($('#pStatus2'), '<h4>' + svg('sliders', 'hi') + 'System Status</h4>' + RI('mic', 'Voice Engine', s.voice) + RI('camera', 'Camera', s.cam2) + RI('brain', 'AI Model', s.ai) + RI('db', 'Memory', s.mem2) + RI('bolt', 'Automation', s.auto));
    const Q2 = (ic, t, a) => '<button class="qa" data-a="' + a + '"><span class="ri2">' + svg(ic) + '</span><span class="qt">' + t + '</span>' + svg('chev', 'chv') + '</button>';
    setHTML($('#pQA2'), '<h4>' + svg('focus', 'hi') + 'Quick Actions</h4>' + Q2('gear', 'Open Task Manager', 'openTasks') + Q2('focus', FOCUS.on ? 'Focus Mode · ' + focusLeft() : 'Start Focus Mode', 'qaFocus') + Q2('shot', 'Capture Screen', 'qaCapture') + Q2('refresh', 'Check Updates', 'checkUpd'));
    if ($('#avName')) $('#avName').textContent = T.cfg.assistant.name || 'FRIDAY';
    const stop = $('#pLive h4'); if (stop && !stop.querySelector('.stop')) stop.insertAdjacentHTML('beforeend', '<button class="stop" data-a="eStop" title="Emergency stop: halt all running tasks">' + svg('stop') + '</button>');
  }

  /* ================================================================ header / footer / nav */
  const WX_ICO = {
    sun: '<circle cx="24" cy="24" r="8" fill="#ffc94a" stroke="none"/><g stroke="#ffc94a" stroke-width="2.4" stroke-linecap="round"><path d="M24 6v5M24 37v5M6 24h5M37 24h5M11.3 11.3l3.5 3.5M33.2 33.2l3.5 3.5M11.3 36.7l3.5-3.5M33.2 14.8l3.5-3.5"/></g>',
    part: '<g stroke="#ffc94a" stroke-width="2.4" stroke-linecap="round"><path d="M17 5v4M6.5 11.5l3 3M3 22h4M27.5 11.5l-3 3"/></g><circle cx="17" cy="21" r="6.5" fill="#ffc94a" stroke="none"/><path d="M15 38h20a7 7 0 0 0 .6-14 9 9 0 0 0-17-1.5A7.5 7.5 0 0 0 15 38z" fill="#cfe6ff" stroke="#8cc4ff" stroke-width="1.2"/>',
    cloud: '<path d="M13 37h22a8 8 0 0 0 .8-16 10.5 10.5 0 0 0-20-2A8.5 8.5 0 0 0 13 37z" fill="#cfe6ff" stroke="#8cc4ff" stroke-width="1.2"/>',
    rain: '<path d="M13 31h22a8 8 0 0 0 .8-16 10.5 10.5 0 0 0-20-2A8.5 8.5 0 0 0 13 31z" fill="#a9c8ee" stroke="#7aa9e0" stroke-width="1.2"/><g stroke="#52b4ff" stroke-width="2.4" stroke-linecap="round"><path d="M16 36l-2 5M24 36l-2 5M32 36l-2 5"/></g>',
    storm: '<path d="M13 30h22a8 8 0 0 0 .8-16 10.5 10.5 0 0 0-20-2A8.5 8.5 0 0 0 13 30z" fill="#8aa4c8" stroke="#6e8ab4" stroke-width="1.2"/><path d="M25 31l-5 8h5l-2 6 8-9h-5z" fill="#ffc94a" stroke="none"/>',
    snow: '<path d="M13 30h22a8 8 0 0 0 .8-16 10.5 10.5 0 0 0-20-2A8.5 8.5 0 0 0 13 30z" fill="#dbe8f8" stroke="#b6cbe8" stroke-width="1.2"/><g fill="#fff"><circle cx="16" cy="37" r="2"/><circle cx="25" cy="40" r="2"/><circle cx="33" cy="37" r="2"/></g>'
  };
  function wxKind(c) { c = String(c || '').toLowerCase(); return /thunder|storm/.test(c) ? 'storm' : /snow|sleet/.test(c) ? 'snow' : /rain|drizzle|shower/.test(c) ? 'rain' : /part|few|scatter|broken/.test(c) ? 'part' : /cloud|overcast|fog|mist|haze/.test(c) ? 'cloud' : 'sun'; }
  function renderWx() {
    const el = $('#wx'); if (!el) return; const w = S.w || {};
    setHTML(el, '<svg class="wi" viewBox="0 0 48 48">' + WX_ICO[wxKind(w.c)] + '</svg><span class="wt"><b>' + E(w.t) + '°C</b><small>' + E(w.c) + '</small></span><span class="wl">' + svg('target').replace(/<circle[^>]*\/><circle[^>]*\/><circle[^>]*\/>/, '<path d="M12 21s6-5.6 6-10a6 6 0 1 0-12 0c0 4.4 6 10 6 10z"/><circle cx="12" cy="11" r="2"/>') + E(String(w.p || '').split(',')[0]) + '</span>');
  }
  window.wx = renderWx;
  function tickClock() {
    const d = new Date(); if ($('#cDate')) $('#cDate').textContent = DAY3[d.getDay()] + ', ' + d.getDate() + ' ' + MON3[d.getMonth()] + ' ' + d.getFullYear();
    if ($('#cTime')) $('#cTime').textContent = fmt12(p2(d.getHours()) + ':' + p2(d.getMinutes()), true);
  }
  function buildChrome() {
    $('#hLogo').innerHTML = logoSvg(); $('#hWm').innerHTML = wordmark('', 4.2);
    $('#sbT').innerHTML = svg('back');
    $('#hWifi').innerHTML = svg('wifi'); $('#pill').insertAdjacentHTML('afterbegin', svg('mic')); $('#hGear').innerHTML = svg('gear');
    $('#w0').innerHTML = svg('widget'); $('#w1').innerHTML = svg('min'); $('#w2').innerHTML = svg('max'); $('#w3').innerHTML = svg('x');
    $('#nav').innerHTML = '<button data-a="go:home" data-nav="home">' + svg('home') + '<span>Home</span>' + svg('chev', 'chv') + '</button><button data-a="go:settings" data-nav="settings">' + svg('gear') + '<span>Settings &amp; Features</span>' + svg('chev', 'chv') + '</button>';
    $('#plate').innerHTML = wordmark('', 3.6);
    $('#gAv').innerHTML = gearAvatar();
    $('#mic').innerHTML = svg('mic'); $('#clip').innerHTML = svg('clip'); $('#camB').innerHTML = svg('camera'); $('#sd').innerHTML = svg('send');
    $('#chips8').innerHTML = [['plan', 'plan', 'Plan my day'], ['camera', 'camera', 'Open Camera'], ['study', 'study', 'Study Mode'], ['memcheck', 'mem', 'Check Memory']].map(c => '<button class="hud clk chip8" data-a="chip:' + c[1] + '">' + svg(c[0]) + c[2] + '</button>').join('');
    $('#chTitle').innerHTML = svg('chat') + 'Conversation'; $('#chX').innerHTML = svg('x'); $('#chClr').innerHTML = svg('trash'); $('#chatT').innerHTML = svg('chat') + 'Conversation<b id="chN">0</b>';
    $('#exitB').innerHTML = svg('power') + '<b>EXIT</b><kbd>Esc</kbd>';
    $('#sideLand').innerHTML = landscape();
    const wl = $('#wvL'), wr = $('#wvR'); let w = ''; for (let i = 0; i < 22; i++) w += '<i></i>'; wl.innerHTML = w; wr.innerHTML = w;
    T.reactor($('#favC'), { type: 'logo', scale: 330, getBoost: () => (typeof boost !== 'undefined' ? boost : 1), getState: uiState });
  }
  function landscape() {
    let stars = ''; for (let i = 0; i < 26; i++) { const x = (i * 83) % 220, y = (i * 47) % 150; stars += '<circle cx="' + x + '" cy="' + y + '" r="' + (i % 5 ? .6 : 1.1) + '" fill="#9fd3ff" opacity="' + (.35 + (i % 4) * .15) + '"/>'; }
    return '<svg class="land" viewBox="0 0 220 330" preserveAspectRatio="xMidYMax slice"><defs><linearGradient id="lsk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#000" stop-opacity="0"/><stop offset=".6" style="stop-color:var(--a)" stop-opacity=".16"/><stop offset="1" style="stop-color:var(--a3)" stop-opacity=".3"/></linearGradient><linearGradient id="lrv" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--a2)"/><stop offset="1" style="stop-color:var(--a3)"/></linearGradient></defs>' +
      '<rect width="220" height="330" fill="url(#lsk)"/>' + stars +
      '<path d="M0 235 L30 205 L52 222 L88 178 L118 212 L150 190 L186 225 L220 205 V330 H0Z" fill="#020b25" stroke="var(--a)" stroke-opacity=".45" stroke-width=".8"/>' +
      '<path d="M0 262 L38 238 L70 258 L112 226 L148 252 L186 236 L220 256 V330 H0Z" fill="#010820" stroke="var(--a2)" stroke-opacity=".35" stroke-width=".7"/>' +
      '<path d="M96 330 C80 300 128 292 108 270 C92 254 122 246 112 232" fill="none" stroke="url(#lrv)" stroke-width="5" stroke-linecap="round" opacity=".9" style="filter:drop-shadow(0 0 4px var(--a))"/>' +
      '<path d="M96 330 C80 300 128 292 108 270 C92 254 122 246 112 232" fill="none" stroke="#fff" stroke-width="1.2" stroke-linecap="round" opacity=".6"/></svg>';
  }
  function setNav() {
    $$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.nav === (PG.page === 'home' ? 'home' : 'settings')));
    document.body.dataset.page = PG.page === 'home' ? 'home' : 'settings';
  }
  function footText() {
    const t = stText();
    if (!B) return 'PREVIEW MODE <b>•</b> OPEN THE DESKTOP APP TO TALK';
    if (!BS.ready) return 'STARTING SYSTEMS <b>•</b> ONE MOMENT';
    if (typeof micOk !== 'undefined' && micOk === false) return 'MICROPHONE UNAVAILABLE <b>•</b> CHECK YOUR MIC SETTINGS';
    if (/^Speaking/.test(t)) return 'FRIDAY IS SPEAKING';
    if (/^Recognizing/.test(t)) return 'RECOGNIZING <b>•</b> ONE MOMENT';
    if (/^(Thinking|Working|Searching)/.test(t) || /%$/.test(t)) return 'THINKING <b>•</b> WORKING ON IT';
    if (typeof vmode !== 'undefined' && vmode === 'standby') return 'STANDBY <b>•</b> SAY “FRIDAY” TO WAKE ME';
    return 'SYSTEMS ONLINE <b>•</b> READY WHEN YOU ARE';
  }
  /* V7.2: a visible status chip in the header: Thinking / Speaking / Listening / Hearing you / Standby (was hidden in a screen-reader-only element) */
  function chipState() {
    const t = stText(), s = uiState();
    if (s === 'speaking') return ['speaking', 'Speaking'];
    if (s === 'thinking') return ['thinking', 'Thinking'];
    if (s === 'recognizing') return ['listening', 'Hearing you'];
    if (!B) return ['idle', 'Preview'];
    if (!BS.ready) return ['idle', 'Starting'];
    if (typeof micOk !== 'undefined' && micOk === false) return ['off', 'Mic off'];
    if (typeof vmode !== 'undefined' && vmode === 'standby') return ['standby', 'Standby'];
    return ['listening', /^Listening for/.test(t) ? 'Say \u201cFriday\u201d' : 'Listening'];
  }
  function renderChip() {
    const c = $('#stChip'); if (!c) return;
    const r = chipState(); if (c.dataset.s !== r[0]) c.dataset.s = r[0];
    const b = c.querySelector('b'); if (b && b.textContent !== r[1]) b.textContent = r[1];
  }
  function renderFoot() { setHTML($('#sysTx'), footText()); renderChip(); }

  /* waveform in the footer follows the state */
  let wvT = 0, wvLast = 0;
  function waveLoop(now) {
    requestAnimationFrame(waveLoop);
    if (now - wvLast < 70 || document.hidden) return; wvLast = now; wvT += .22;
    const s = uiState(), amp = s === 'speaking' ? 1 : s === 'recognizing' ? .8 : s === 'thinking' ? .55 : s === 'listening' ? .38 : .22;
    ['#wvL', '#wvR'].forEach((sel, side) => { const bars = $(sel) && $(sel).children; if (!bars) return; const n = bars.length; for (let i = 0; i < n; i++) { const k = side ? n - 1 - i : i, env = Math.sin(k / (n - 1) * Math.PI) * .75 + .25, v = (Math.sin(wvT * 1.6 + k * .9) + Math.sin(wvT * .7 + k * 1.7) * .8 + 1.8) / 3.6; bars[i].style.height = Math.max(.14, (.1 + v * env * amp * 1.45)) * 1.7 + 'rem'; } });
  }

  /* ================================================================ actions */
  const A = F8.A;
  function askFriday(short, full) {
    if (!B) { msg(short, 1); X.m.cmds++; return localCmd(short); }
    msg(short, 1); X.m.cmds++; think(); lastT = performance.now(); B.sendCommand(full || short);
  }
  F8.askFriday = askFriday;
  A.go = el => { const w = (el.dataset.a || '').split(':')[1]; if (w === 'home') view('Home'); else if (w === 'settings') view('Settings'); else if (w === 'ai') view('Settings', 'conn'); else view(({ vision: 'Vision', mem: 'Memory', auto: 'Tasks' })[w] || 'Settings'); snd('nav'); };
  A.taskTog = el => {
    const id = el.dataset.id, key = ymd();
    if (el.dataset.k === 'cal') { const c = X.cal.find(x => x.id == id); if (c) { c.done = c.done ? 0 : 1; sx(); } return; }
    const k = X.todo.find(x => x.id == id); if (!k) return; k.done = k.done || {}; if (k.done[key]) delete k.done[key]; else { k.done[key] = 1; act('Task done: ' + k.n, 'check', 'g'); } sx(); snd('ok');
  };
  A.openTasks = () => view('Tasks', 'tasks'); A.openSched = () => view('Tasks', 'sched');
  A.chip = el => {
    const w = el.dataset.a.split(':')[1];
    if (w === 'plan') { const L = todayList(), S3 = nextSched(5); askFriday('Plan my day', 'Plan my day for me. Today is ' + new Date().toDateString() + '. My tasks today: ' + (L.length ? L.map(x => (x.t ? fmt12(x.t) + ' ' : '') + x.n + (x.done ? ' (done)' : '')).join('; ') : 'none yet') + '. My upcoming schedule: ' + (S3.length ? S3.map(x => x.n + ' ' + x.label).join('; ') : 'nothing') + '. Suggest a sensible order and breaks, short and practical.'); }
    else if (w === 'camera') A.camera();
    else if (w === 'study') askFriday('Study mode', 'study mode');
    else if (w === 'mem') view('Memory');
  };
  A.camera = () => {
    if (!B || !window.FridayVision) { toast('The camera is available in the FRIDAY desktop app'); view('Vision'); return; }
    if (camOn()) { view('Vision'); return; }
    window.FridayVision.call('camera_start', { preview: true, speak: false }).then(r => { if (r && r.ok === false) toast(r.error || 'Could not open the camera'); else act('Camera opened', 'camera', 'b'); renderAll(); });
    view('Vision'); toast('Opening the camera...');
  };
  A.qaFiles = () => { if (!B) return toast('File Explorer opens from the FRIDAY desktop app'); B.sendCommand('open file explorer'); act('Opening File Explorer', 'folderopen', 'b'); toast('Opening File Explorer...'); };
  A.qaCapture = () => {
    mod('Capture Screen', '<p class="note">Take a picture of your screen, or record a short clip.</p><div class="grid g2"><button class="cd" data-a="shot"><span class="ci">' + svg('shot') + '</span><div><b>Screenshot</b><small>FRIDAY captures your screen</small></div></button><button class="cd" data-a="rec"><span class="ci">' + svg('rec') + '</span><div><b>Record screen</b><small>Saves a video you can keep</small></div></button></div>');
  };
  A.shot = () => { closeM(); if (!B) return toast('Screenshots need the FRIDAY desktop app'); B.sendCommand('take a screenshot'); act('Screenshot requested', 'shot', 'b'); toast('Capturing your screen...'); };
  let REC = null;
  A.rec = async () => {
    closeM();
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) throw new Error('not supported');
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false }), chunks = [];
      const mr = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9') ? 'video/webm;codecs=vp9' : 'video/webm' });
      mr.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
      mr.onstop = () => { stream.getTracks().forEach(t => t.stop()); const blob = new Blob(chunks, { type: 'video/webm' }), a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'FRIDAY_recording_' + ymd() + '_' + p2(new Date().getHours()) + p2(new Date().getMinutes()) + '.webm'; document.body.appendChild(a); a.click(); a.remove(); REC = null; const rb = $('#recbar'); if (rb) rb.remove(); act('Screen recording saved', 'rec', 'g'); toast('Recording saved'); };
      stream.getVideoTracks()[0].addEventListener('ended', () => { if (mr.state !== 'inactive') mr.stop(); });
      mr.start(); REC = mr;
      const bar = document.createElement('button'); bar.id = 'recbar'; bar.className = 'hud'; bar.style.cssText = 'position:fixed;top:5.4rem;left:50%;transform:translateX(-50%);z-index:60;padding:.5rem 1.1rem;color:#fff;display:flex;gap:.6rem;align-items:center;--c1:#ff3b6e;--c2:#ff8aa8'; bar.innerHTML = '<i style="width:.7rem;height:.7rem;border-radius:50%;background:#ff3b6e;box-shadow:0 0 .6rem #ff3b6e;animation:blink 1s infinite"></i>Recording — click to stop';
      bar.onclick = () => { if (REC && REC.state !== 'inactive') REC.stop(); }; document.body.appendChild(bar);
      act('Screen recording started', 'rec', 'b');
    } catch (e) { toast('Screen recording is not available here. Use Screenshot instead.'); }
  };
  A.status = () => {
    const s = statusRows(), r = (n, v) => '<div class="li"><span>' + n + '</span><span class="' + (v[1] === 'bad' ? 'bad' : v[1] === 'warn' ? '' : 'ok') + '">' + v[0] + '</span></div>';
    mod('System Status', r('FRIDAY Core', s.core) + r('Voice Engine', s.voice) + r('Camera', s.camera) + r('Microphone', s.mic) + r('AI Model (' + modelName() + ')', s.ai) + r('Memory (' + X.mem.length + ' saved)', s.memory) + r('Internet', s.net) + '<div class="row" style="margin-top:.9rem"><button class="btn" data-a="checkUpd">Check updates</button><button class="btn g" onclick="closeM()">Close</button></div>');
  };
  A.actLog = () => { mod('Recent activity', (ACTV.length ? '<table><tr><th>Time</th><th>Event</th></tr>' + ACTV.slice(0, 25).map(a => '<tr><td>' + fmt12(p2(new Date(a.t).getHours()) + ':' + p2(new Date(a.t).getMinutes()), true) + '</td><td style="text-align:left">' + E(a.tx) + '</td></tr>').join('') + '</table>' : '<p class="note">Nothing has happened yet this session.</p>') + '<h4>Action log</h4>' + auditHTML(15)); };
  A.eStop = () => { const b = document.getElementById('f6stop'); if (b) { b.click(); toast('Emergency stop sent'); } else if (B && B.v6) { B.v6({ op: 'emergency_stop' }); toast('Emergency stop sent'); } else toast('Nothing is running'); };
  A.checkUpd = () => {
    const v = '7.0', ok = B ? (BS.ready ? 'Online' : 'Starting') : 'Preview (not connected)';
    mod('Check Updates', '<div class="li"><span>FRIDAY version</span><b>' + v + '</b></div><div class="li"><span>Reasoning engine</span><span class="' + (B && BS.ready ? 'ok' : '') + '">' + ok + '</span></div><div class="li"><span>AI model</span><span>' + E(modelName()) + '</span></div><div class="li"><span>Internet</span><span class="' + (online() ? 'ok' : 'bad') + '">' + (online() ? 'Connected' : 'Offline') + '</span></div><p class="note">FRIDAY is installed from the package you received, so new versions arrive as a new package. You are running the latest build of the interface (v7.0, HUD design).</p><div class="row"><button class="btn" onclick="closeM()">OK</button></div>');
  };
  A.exitSettings = () => view('Home');
  A.stopRec = () => { if (REC && REC.state !== 'inactive') REC.stop(); };

  /* ---- focus mode ---- */
  const FOCUS = F8.FOCUS = { on: false, dur: 25, end: 0, left: 25 * 60, paused: false, timer: 0 };
  const focusLeft = () => { const s = Math.max(0, Math.round(FOCUS.left)); return p2(Math.floor(s / 60)) + ':' + p2(s % 60); };
  function focusView() {
    const f = $('#focus .fbox'); if (!f) return;
    const C = 2 * Math.PI * 82, frac = FOCUS.dur ? Math.max(0, FOCUS.left) / (FOCUS.dur * 60) : 0;
    if (!FOCUS.on) {
      f.innerHTML = '<h3>Focus Mode</h3><p>Distractions off. Notifications are quiet until the timer ends.</p><div class="row" style="justify-content:center;margin:1rem 0">' + [15, 25, 45, 60].map(m => '<button class="chip ' + (FOCUS.dur === m ? 'on' : '') + '" data-a="fDur" data-m="' + m + '">' + m + ' min</button>').join('') + '</div><div class="fr"><button class="btn" data-a="fStart">Start focusing</button><button class="btn g" data-a="fClose">Cancel</button></div>'; return;
    }
    f.innerHTML = '<div class="ring"><svg viewBox="0 0 180 180"><circle cx="90" cy="90" r="82" fill="none" style="stroke:var(--a)" stroke-opacity=".2" stroke-width="5"/><circle cx="90" cy="90" r="82" fill="none" style="stroke:var(--a2)" stroke-width="5" stroke-linecap="round" stroke-dasharray="' + C + '" stroke-dashoffset="' + (C * (1 - frac)) + '" /></svg><b>' + focusLeft() + '</b></div><h3>' + (FOCUS.paused ? 'Paused' : 'Stay with it') + '</h3><p>Notifications are muted. Take one task at a time.</p><div class="fr"><button class="btn g" data-a="fPause">' + (FOCUS.paused ? 'Resume' : 'Pause') + '</button><button class="btn danger" data-a="fEnd">End focus</button></div>';
  }
  function focusTick() {
    if (!FOCUS.on || FOCUS.paused) return; FOCUS.left = Math.max(0, (FOCUS.end - Date.now()) / 1000);
    if (FOCUS.left <= 0) { focusStop(true); return; } if ($('#focus .ring')) focusView(); renderRight();
  }
  A.qaFocus = () => { if (FOCUS.on) { document.body.dataset.focus = 'on'; focusView(); } else { document.body.dataset.focus = 'on'; focusView(); } };
  A.fDur = el => { FOCUS.dur = +el.dataset.m; FOCUS.left = FOCUS.dur * 60; focusView(); };
  A.fStart = () => { FOCUS.on = true; FOCUS.paused = false; FOCUS.left = FOCUS.dur * 60; FOCUS.end = Date.now() + FOCUS.left * 1000; clearInterval(FOCUS.timer); FOCUS.timer = setInterval(focusTick, 1000); act('Focus mode started (' + FOCUS.dur + ' min)', 'focus', 'b'); focusView(); renderAll(); };
  A.fPause = () => { if (FOCUS.paused) { FOCUS.paused = false; FOCUS.end = Date.now() + FOCUS.left * 1000; } else { FOCUS.paused = true; FOCUS.left = (FOCUS.end - Date.now()) / 1000; } focusView(); };
  A.fClose = () => { document.body.dataset.focus = 'off'; };
  A.fEnd = () => focusStop(false);
  function focusStop(done) {
    clearInterval(FOCUS.timer); FOCUS.on = false; FOCUS.paused = false; document.body.dataset.focus = 'off';
    act(done ? 'Focus session complete' : 'Focus mode ended', 'focus', done ? 'g' : 'b'); renderAll();
    if (done) { toastRaw('Focus session complete. Well done.'); try { if (B && B.speak) B.speak('Focus session complete. Well done.'); } catch (e) { } snd('ok'); }
  }
  const _toast = window.toast;
  function toastRaw(t) { _toast(t); }
  window.toast = function (t) { if (FOCUS.on && !/focus|error|fail|could not|unavailable/i.test(String(t))) return; return _toast(t); };

  /* ---- exit ---- */
  A.exitApp = () => {
    mod('Exit FRIDAY?', '<p>FRIDAY will stop listening and close.</p><div class="row" style="justify-content:flex-end;margin-top:1rem"><button class="btn g" onclick="closeM()">Stay</button><button class="btn g" data-a="toStandby">Standby</button><button class="btn danger" data-a="doExit">Exit FRIDAY</button></div>');
  };
  A.toStandby = () => { closeM(); document.body.classList.add('sb'); if (B) B.standby(); };
  A.doExit = () => { closeM(); if (B) B.close(); else { toast('Close the browser tab to exit the preview'); } };
  A.widget = () => { if (B) B.enterWidget(); else toast('The desktop widget is available in the FRIDAY desktop app'); };

  /* delegated clicks */
  document.addEventListener('click', e => {
    const el = e.target.closest('[data-a]'); if (!el) return;
    const k = el.dataset.a.split(':')[0], fn = A[k]; if (!fn) return;
    e.stopPropagation(); try { fn(el, e); } catch (x) { console.error('[ui8]', k, x); }
  }, true);

  /* ================================================================ chat drawer */
  let chatSeen = 0;
  function chatState() {
    const n = $$('#msgs .mr').length;
    document.body.dataset.chatHas = n ? 'on' : 'off';
    if ($('#chN')) $('#chN').textContent = Math.min(99, n);
  }
  function chatOpen(on) { document.body.dataset.chatOpen = on ? 'on' : 'off'; if (on) { chatState(); const m = $('#msgs'); m.scrollTop = 1e9; } }
  F8.chatOpen = chatOpen;
  $('#chX').onclick = () => chatOpen(false); $('#chatT').onclick = () => chatOpen(true);
  $('#chClr').onclick = () => { $('#msgs').innerHTML = ''; chatState(); chatOpen(false); };
  const _msg = window.msg;
  window.msg = function (t, u) {
    const b = _msg(t, u);
    chatState();
    const mode = T.cfg.home.chat;
    if (mode !== 'manual') { if (PG.page !== 'home') { /* keep the user where they are; the chat button shows a count */ } else chatOpen(true); }
    return b;
  };

  /* ================================================================ routing */
  function showHome() { PG.page = 'home'; V = 'Home'; setNav(); renderAll(); }
  F8.showHome = showHome;
  window.view = function (v, tab) {
    if (v === 'Chat') { v = 'Home'; setTimeout(() => $('#ti').focus(), 50); }
    try { closeM(); } catch (e) { }
    $('#homev').style.display = ''; $('#view').style.display = '';
    $('#bell').style.display = 'none';
    if (!v || v === 'Home') { showHome(); return; }
    if (F8.hub) F8.hub.openPage(v, tab); else { PG.page = 'settings'; setNav(); }
  };
  window.render = function () { if (PG.page === 'home') renderAll(); else if (F8.hub) F8.hub.render(); };
  window.renderSide = function () { renderAll(); };
  F8.setNav = setNav; F8.renderRight = renderRight;

  function renderAll() {
    renderGreet(); renderTasks(); renderSched(); renderTiles(); renderRight(); renderFoot(); renderWx();
    $('#mic').classList.toggle('on', !!(typeof lst !== 'undefined' && lst && typeof spk !== 'undefined' && !spk));
    document.body.dataset.busy = (uiState() === 'thinking' || X.tasks.some(k => k.st === 'run')) ? 'on' : 'off';
    const h = $('#hWifi'); if (h) h.classList.toggle('on', online()), h.style.opacity = online() ? 1 : .4;
    const pm = $('#pill'); if (pm) { pm.classList.toggle('live', !!(B && BS.ready && typeof lst !== 'undefined' && lst)); pm.classList.toggle('off', typeof vmode !== 'undefined' && vmode === 'standby'); pm.title = 'Voice: ' + (stText() || ''); }
    const n = X.audit.filter(a => a.r === 'fail' || a.r === 'denied').length; if ($('#bd')) { $('#bd').style.display = n ? 'block' : 'none'; $('#bd').textContent = n; }
    if (F8.hub && PG.page === 'settings' && F8.hub.refresh) F8.hub.refresh();
  }
  F8.renderAll = renderAll;

  /* ================================================================ header + misc wiring */
  $('#hGear').onclick = () => view('Settings'); $('#brand').onclick = () => view('Home');
  $('#hWifi').onclick = () => A.status(); $('#wx').onclick = () => openM('weather'); $('#clock').onclick = () => view('Tasks', 'sched');
  $('#gAv').onclick = () => view('Settings'); $('#gT').onclick = () => { view('Settings', 'profile'); };
  $('#camB').onclick = () => A.camera();
  $('#fav').onclick = () => A.widget(); $('#exitB').onclick = () => A.exitApp();
  $('#sbT').onclick = () => { const cur = T.cfg.layout.sidebar; T.set('layout.sidebar', cur === 'full' ? 'icons' : 'full'); };
  $('#ti').addEventListener('focus', () => snd('tick'));
  Theme.subscribe(() => { renderAll(); applyFx(); });

  /* ================================================================ keyboard */
  window.addEventListener('keydown', e => {
    const mod_ = $('#mod').style.display === 'grid' || $('#ap').style.display === 'grid';
    if (e.key === 'Escape') {
      if (mod_) return;                                              /* the original handler closes the dialog */
      const stop = () => { e.preventDefault(); e.stopImmediatePropagation(); };   /* the old handler would close the dialog we just opened */
      if (document.body.dataset.focus === 'on' && !FOCUS.on) { A.fClose(); stop(); return; }
      if (document.body.classList.contains('sb')) return;
      const a = document.activeElement;
      if (a && a.id === 'ti' && a.value) { a.value = ''; stop(); return; }
      if (a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA' || a.tagName === 'SELECT') && a.id !== 'ti') { a.blur(); stop(); return; }
      if (document.body.dataset.chatOpen === 'on' && PG.page === 'home') { chatOpen(false); stop(); return; }
      if (PG.page === 'settings') { if (F8.hub && F8.hub.back) F8.hub.back(); else view('Home'); stop(); return; }
      A.exitApp(); stop();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); if (PG.page !== 'settings') view('Settings'); setTimeout(() => F8.hub && F8.hub.focusSearch(), 30); }
    else if ((e.ctrlKey || e.metaKey) && e.key === ',') { e.preventDefault(); view('Settings'); }
    else if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'w') { e.preventDefault(); A.widget(); }
    else if (e.key === '/' && PG.page === 'home' && !/INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); $('#ti').focus(); }
  }, true);

  /* ================================================================ UI sounds (off by default) */
  let AC = null;
  function snd(kind, force) {
    if (!T.cfg.fx.sound && !force) return;
    try {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)(); const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime;
      const f = { tick: [900, .03], nav: [620, .07], ok: [880, .12] }[kind] || [700, .05];
      o.type = 'sine'; o.frequency.setValueAtTime(f[0], t); if (kind === 'ok') o.frequency.linearRampToValueAtTime(1320, t + f[1]);
      g.gain.setValueAtTime(.0001, t); g.gain.exponentialRampToValueAtTime(.05, t + .008); g.gain.exponentialRampToValueAtTime(.0001, t + f[1] + .05);
      o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + f[1] + .08);
    } catch (e) { }
  }
  F8.snd = snd;
  document.addEventListener('click', e => { if (e.target.closest('button,.srow,.tr')) snd('tick'); }, false);

  /* ================================================================ parallax + effects */
  let px = 0, py = 0, tx = 0, ty = 0;
  $('#main').addEventListener('mousemove', e => { const r = $('#main').getBoundingClientRect(); tx = ((e.clientX - r.left) / r.width - .5) * 2; ty = ((e.clientY - r.top) / r.height - .5) * 2; });
  $('#main').addEventListener('mouseleave', () => { tx = 0; ty = 0; });
  function parLoop() {
    requestAnimationFrame(parLoop);
    if (document.body.dataset.par !== 'on' || !T.cfg.anim || PG.page !== 'home') { if (px || py) { px = py = 0; $('#reactor').style.transform = ''; $('#stage .decor').style.transform = ''; } return; }
    px += (tx - px) * .06; py += (ty - py) * .06;
    $('#reactor').style.transform = 'translate(' + (-px * 7).toFixed(2) + 'px,' + (-py * 5).toFixed(2) + 'px)';
    $('#stage .decor').style.transform = 'translate(' + (px * 9).toFixed(2) + 'px,' + (py * 6).toFixed(2) + 'px)';
  }
  function applyFx() { document.body.style.setProperty('--neon', String(Math.max(0, Math.min(2, (T.cfg.fx.neon == null ? 100 : T.cfg.fx.neon) / 100)))); }

  /* ambient background canvas: drifting dust + optional neon floor grid */
  (function bgfx() {
    const cv = $('#bgfx'), cx = cv.getContext('2d'); let W = 0, H = 0, last = 0, t = 0; const N = 70, ps = [];
    for (let i = 0; i < N; i++) ps.push({ x: Math.random(), y: Math.random(), z: Math.random(), s: .3 + Math.random() });
    function size() { const d = Math.min(1.5, window.devicePixelRatio || 1); W = cv.width = Math.round(innerWidth * d); H = cv.height = Math.round(innerHeight * d); }
    size(); window.addEventListener('resize', size);
    function frame(now) {
      requestAnimationFrame(frame); if (document.hidden || now - last < 40) return; const dt = (now - last) / 1000; last = now; if (T.cfg.anim) t += dt;
      cx.clearRect(0, 0, W, H); const a = T.cfg.accent, a3 = getComputedStyle(document.documentElement).getPropertyValue('--a3').trim() || a;
      if (document.body.dataset.grid === 'on') {
        const hz = H * .62; cx.save(); cx.strokeStyle = a; cx.lineWidth = 1; cx.globalAlpha = .16;
        for (let i = -14; i <= 14; i++) { cx.beginPath(); cx.moveTo(W / 2 + i * W * .02, hz); cx.lineTo(W / 2 + i * W * .17, H); cx.stroke(); }
        for (let j = 0; j < 12; j++) { const f = ((j + (t * .35) % 1) / 12), y = hz + (H - hz) * f * f; cx.globalAlpha = .05 + f * .18; cx.beginPath(); cx.moveTo(0, y); cx.lineTo(W, y); cx.stroke(); } cx.restore();
      }
      for (let i = 0; i < N; i++) { const p = ps[i]; p.y -= dt * .008 * (.4 + p.z) * (T.cfg.anim ? 1 : 0); p.x += Math.sin(t * .3 + i) * dt * .0008; if (p.y < -.02) { p.y = 1.02; p.x = Math.random(); } cx.globalAlpha = .12 + .32 * p.z * (.6 + .4 * Math.sin(t * 1.5 + i)); cx.fillStyle = i % 5 === 0 ? a3 : a; cx.beginPath(); cx.arc(p.x * W, p.y * H, p.s * (.8 + p.z * 1.4), 0, 6.2832); cx.fill(); }
      cx.globalAlpha = 1;
    }
    requestAnimationFrame(frame);
  })();

  /* ================================================================ reactor stage */
  function sizeStage() {
    const m = $('#main'), h = m.clientHeight / rem(), dy = Math.max(0, Math.min(14, (h - 46.35) * .32));
    $('#homev').style.setProperty('--dy', dy.toFixed(2) + 'rem'); return dy;
  }
  let popT = 0, popV = 1;
  function getPop() { const s = uiState(); popT += .06 * (s === 'speaking' ? 2.4 : s === 'recognizing' ? 1.8 : 1); const tgt = s === 'speaking' ? 1 + Math.sin(popT * 4) * .022 : s === 'recognizing' ? 1 + Math.sin(popT * 5) * .014 : 1; popV += (tgt - popV) * .2; return popV; }
  function stageLayout(cv, w, h) {
    const r = rem(), dy = sizeStage(), k = Math.max(.5, (T.cfg.reactor.size || 100) / 100), u = r / 16 * k, cx = w - 26.3 * r, cy = (20.3 + dy) * r;
    return { cx, cy, u, top: cy / u + 40, bottom: (h - cy) / u };
  }
  T.reactor($('#reactor'), { stage: true, layout: stageLayout, getBoost: () => (typeof boost !== 'undefined' ? boost : 1), getPop, getState: uiState });

  /* ================================================================ observers + backend feed */
  if (window.MutationObserver) new MutationObserver(() => { renderFoot(); $('#mic').classList.toggle('on', !!(typeof lst !== 'undefined' && lst && typeof spk !== 'undefined' && !spk)); document.body.dataset.busy = (uiState() === 'thinking' || X.tasks.some(k => k.st === 'run')) ? 'on' : 'off'; renderLive(); }).observe($('#st'), { childList: true, characterData: true, subtree: true });
  window.addEventListener('online', renderAll); window.addEventListener('offline', renderAll);
  window.addEventListener('resize', () => { sizeStage(); });
  if (B && B.onLine) B.onLine(l => {
    if (typeof l !== 'string') return;
    if (l === 'ACTION::LISTEN_START') { act('Voice recognition active', 'plus', 'g'); renderAll(); }
    else if (l.indexOf('ACTION::HEARD::') === 0) { try { act('Heard: “' + decodeURIComponent(escape(atob(l.slice(15)))).slice(0, 60) + '”', 'mic'); } catch (e) { } }
    else if (l === 'ACTION::SPEAK_START') act('FRIDAY is speaking', 'wave');
    else if (l.indexOf('PROGRESS::') === 0) { try { const p = JSON.parse(l.slice(10)); act((p.stage || 'Working') + ' ' + p.percent + '%', 'bolt', 'b'); } catch (e) { } }
    else if (l.indexOf('VISION::') === 0 || l.indexOf('FRIDAY_VISION::') === 0) renderAll();
  });
  if (B && B.onBackendReady) B.onBackendReady(() => { act('FRIDAY is ready', 'mic'); renderAll(); if (B.getApiStatus) B.getApiStatus().then(r => { if (r && r.model) { window.__fridayModel = r.model; renderAll(); } }).catch(() => { }); });
  if (window.FridayVision && window.FridayVision.onEvent) window.FridayVision.onEvent((k) => { if (k === 'session' || k === 'state') renderAll(); });


  /* ================================================================ boot */
  function boot() {
    /* the other scripts inject px-based styles; the HUD stylesheet must come last so it wins */
    const hudLink = document.querySelector('link[href*="friday_hud"]');
    if (hudLink && hudLink.parentNode.lastElementChild !== hudLink) hudLink.parentNode.appendChild(hudLink);
    $('#homev').style.display = ''; $('#view').style.display = '';   /* the original script left inline display values on these */
    seedData(); buildChrome(); applyFx(); setNav(); tickClock(); setInterval(tickClock, 1000); setInterval(() => { renderAll(); }, 60000);
    sizeStage(); renderAll(); requestAnimationFrame(waveLoop); requestAnimationFrame(parLoop);
    chatState(); document.body.dataset.chatOpen = 'off'; document.body.dataset.focus = 'off';
    sx();
    if (T.cfg.fx.boot) {
      const b = document.createElement('div'); b.id = 'boot'; b.innerHTML = '<div>' + logoSvg('lg8').replace('<svg class="lg8"', '<svg class="lg8"') + '<b>INITIALISING FRIDAY</b><i></i></div>'; document.body.appendChild(b);
      setTimeout(() => { b.style.opacity = 0; setTimeout(() => b.remove(), 650); }, 1500);
    }
  }
  boot();
})();
