"""
FRIDAY EXECUTIVE BRAIN
----------------------
Implements the research doc's "4. The Executive Brain" and "Planning -
9.5+" sections: its job "isn't to perform everything. Its job is:
decide what should happen next."

    GOAL -> PLAN -> TASK GRAPH -> DEPENDENCIES -> EXECUTION -> VERIFICATION

and the failure path:

    TRY -> OBSERVE -> SUCCESS? -> yes: continue
                                  no: DIAGNOSE -> REPLAN -> RETRY ->
                                      alternate strategy -> VERIFY

Additive-only: built entirely on the new friday_task_graph and
friday_verifier_layer modules plus the new friday_state_engine, none
of which touch any existing file. The Executive never performs actions
itself -- it calls a `dispatch(task) -> dict` callback supplied by the
caller (normally friday_supervisor.dispatch_task, which is what
actually knows how to reach your real agents). This keeps the planning
logic completely decoupled from "how to click a button" or "how to
call Gemini", matching the doc's layering.
"""

from __future__ import annotations

import time
from typing import Any, Callable, Optional

import friday_state_engine as state
import friday_task_graph as graph
import friday_verifier_layer as verifier

Dispatch = Callable[[dict[str, Any]], dict[str, Any]]


# ---------------------------------------------------------------------------
# Planning: turn a free-text goal into a task graph.
#
# This is intentionally a transparent, editable, rule-based planner (not an
# LLM call) so it has zero network/API-key dependency and its behaviour is
# fully deterministic and testable. Callers with an LLM available (your own
# backend already has Gemini wired up) can pass `plan_override` to substitute
# a smarter, model-generated plan while still getting all the execution /
# verification / retry machinery below for free.
# ---------------------------------------------------------------------------

_RESEARCH_KEYWORDS = ("research", "find information", "find out", "look up", "investigate", "learn about")
_DOCUMENT_KEYWORDS = ("document", "report", "write up", "notes", "summary", "summarize")
_OPEN_APP_KEYWORDS = ("open ", "launch ", "start ")
_STUDY_KEYWORDS = ("study", "revise", "revision", "quiz", "flashcards", "practice questions", "exam")


def _default_plan(goal_text: str) -> list[dict[str, Any]]:
    """Return a list of step specs: {"action", "agent_group", "verification_level", "depends_on_previous"}."""
    text = (goal_text or "").lower()

    if any(k in text for k in _RESEARCH_KEYWORDS) and any(k in text for k in _DOCUMENT_KEYWORDS):
        # "Find the latest info about X and make a document" - the doc's own worked example.
        return [
            {"action": "research_topic", "agent_group": "knowledge", "verification_level": "mechanical_action"},
            {"action": "collect_reliable_sources", "agent_group": "knowledge", "verification_level": "mechanical_action"},
            {"action": "verify_important_claims", "agent_group": "knowledge", "verification_level": "knowledge"},
            {"action": "organize_information", "agent_group": "creation", "verification_level": "semantic"},
            {"action": "generate_document", "agent_group": "creation", "verification_level": "mechanical_file"},
            {"action": "verify_document", "agent_group": "knowledge", "verification_level": "semantic"},
        ]
    if any(k in text for k in _RESEARCH_KEYWORDS):
        return [
            {"action": "research_topic", "agent_group": "knowledge", "verification_level": "mechanical_action"},
            {"action": "collect_reliable_sources", "agent_group": "knowledge", "verification_level": "mechanical_action"},
            {"action": "verify_important_claims", "agent_group": "knowledge", "verification_level": "knowledge"},
            {"action": "synthesize_answer", "agent_group": "knowledge", "verification_level": "semantic"},
        ]
    if any(k in text for k in _STUDY_KEYWORDS):
        return [
            {"action": "identify_topic_and_weak_areas", "agent_group": "knowledge", "verification_level": "semantic"},
            {"action": "retrieve_notes", "agent_group": "knowledge", "verification_level": "mechanical_action"},
            {"action": "generate_explanations", "agent_group": "creation", "verification_level": "semantic"},
            {"action": "generate_questions", "agent_group": "creation", "verification_level": "semantic"},
            {"action": "build_document", "agent_group": "creation", "verification_level": "mechanical_file"},
        ]
    if text.startswith(_OPEN_APP_KEYWORDS) or any(text.startswith(k) for k in _OPEN_APP_KEYWORDS):
        return [
            {"action": "locate_application", "agent_group": "action", "verification_level": "mechanical_action"},
            {"action": "launch_application", "agent_group": "action", "verification_level": "mechanical_action"},
            {"action": "confirm_window_visible", "agent_group": "action", "verification_level": "mechanical_action"},
        ]
    # Generic fallback: the doc's minimal UNDERSTAND -> ACT -> OBSERVE -> VERIFY loop.
    return [
        {"action": "understand_request", "agent_group": "knowledge", "verification_level": "semantic"},
        {"action": "perform_action", "agent_group": "action", "verification_level": "mechanical_action"},
        {"action": "verify_outcome", "agent_group": "knowledge", "verification_level": "semantic"},
    ]


def plan(goal_text: str, *, priority: float = 0.5, plan_override: Optional[list[dict[str, Any]]] = None,
         metadata: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """GOAL -> PLAN -> TASK GRAPH. Returns the created goal record (with task_ids)."""
    goal = graph.create_goal(goal_text, priority=priority, metadata=metadata or {})
    steps = plan_override if plan_override is not None else _default_plan(goal_text)

    previous_id = None
    for step in steps:
        deps = [previous_id] if (previous_id and step.get("depends_on_previous", True)) else []
        task = graph.create_task(
            goal["id"],
            step["action"],
            dependencies=deps,
            priority=priority,
            verification_level=step.get("verification_level", "semantic"),
            agent_group=step.get("agent_group"),
            agent_name=step.get("agent_name"),
            inputs=step.get("inputs") or {"goal_text": goal_text},
        )
        previous_id = task["id"]

    state.upsert_item("goals", goal["id"], description=goal_text, status="PLANNED", task_count=len(steps))
    return graph.get_goal(goal["id"]) or goal


# ---------------------------------------------------------------------------
# Execution: observe -> verify -> diagnose -> replan -> retry loop.
# ---------------------------------------------------------------------------

def _run_verification(task: dict[str, Any], dispatch_result: dict[str, Any]) -> dict[str, Any]:
    level = task.get("verification_level", "semantic")
    criteria = task.get("verification_criteria") or {}
    try:
        if level == "mechanical_file":
            path = dispatch_result.get("path") or criteria.get("path")
            if not path:
                return verifier.make_result("mechanical", verifier.STATUS_UNKNOWN, 0.0, [], "no path to verify")
            return verifier.verify(level, path=path)
        if level == "mechanical_action":
            return verifier.verify(
                level,
                before=dispatch_result.get("before_snapshot"),
                expected_text=criteria.get("expected_text"),
                expected_window=criteria.get("expected_window"),
            )
        if level == "knowledge":
            return verifier.verify(
                level,
                claim=criteria.get("claim") or task.get("action", ""),
                sources=dispatch_result.get("sources", []),
            )
        # default: semantic
        return verifier.verify(
            level,
            requested=criteria.get("requested") or task.get("action", ""),
            achieved_summary=dispatch_result.get("summary", ""),
            judge=criteria.get("judge"),
        )
    except Exception as exc:
        return verifier.make_result(level, verifier.STATUS_UNKNOWN, 0.0, [], f"verification error: {exc}")


def _explain_failure(task: dict[str, Any], attempts_log: list[dict[str, Any]]) -> str:
    """Structured, human-readable failure explanation -- the doc explicitly
    calls out that 'Something went wrong' is not good enough; Friday should
    say what happened at each attempt."""
    if not attempts_log:
        return f"The task '{task.get('action')}' could not be completed and no attempt was recorded."
    parts = []
    for i, attempt in enumerate(attempts_log, 1):
        method = attempt.get("method", f"method {i}")
        reason = attempt.get("reason", "no diagnostic information was available")
        parts.append(f"attempt {i} ({method}) failed because {reason}")
    return f"The task '{task.get('action')}' did not succeed. " + "; then ".join(parts) + "."


def execute_goal(goal_id: str, dispatch: Dispatch, *, ask_user: Optional[Callable[[str], bool]] = None,
                  max_wall_seconds: float = 120.0) -> dict[str, Any]:
    """Drive every ready task in `goal_id` through RUNNING -> OBSERVING ->
    VERIFYING -> COMPLETED, or the failure path FAILED -> DIAGNOSING ->
    REPLANNING -> RETRYING, until the goal is complete, permanently failed,
    or `max_wall_seconds` elapses (safety valve against runaway loops).

    `dispatch(task) -> dict` is supplied by the caller (see
    friday_supervisor.dispatch_task) and is the ONLY place real-world side
    effects happen. Its return dict may include: "summary", "path",
    "before_snapshot", "sources", "method", "error".
    """
    start = time.time()
    task_results: list[dict[str, Any]] = []
    goal = graph.get_goal(goal_id)
    if not goal:
        return {"goal_id": goal_id, "status": "FAILED", "explanation": "unknown goal id", "task_results": []}

    while True:
        if time.time() - start > max_wall_seconds:
            state.upsert_item("goals", goal_id, status="FAILED", reason="wall_clock_timeout")
            return {"goal_id": goal_id, "status": "FAILED",
                     "explanation": "Execution exceeded its time budget and was stopped safely.",
                     "task_results": task_results}

        ready = graph.ready_tasks(goal_id)
        if not ready:
            break  # nothing left runnable: either done, or blocked/failed permanently

        for task in ready:
            task_id = task["id"]
            graph.set_status(task_id, "RUNNING")
            state.upsert_item("tasks", task_id, action=task["action"], status="RUNNING")

            attempts_log: list[dict[str, Any]] = []
            succeeded = False
            verification: dict[str, Any] = {}

            while True:
                try:
                    result = dispatch(task) or {}
                except Exception as exc:
                    result = {"error": str(exc)}

                graph.set_outputs(task_id, result)
                graph.set_status(task_id, "OBSERVING")

                graph.set_status(task_id, "VERIFYING")
                verification = _run_verification(task, result)
                graph.set_verification_result(task_id, verification)

                # A task is treated as successful when either:
                #   (a) verification actively confirms it (STATUS_VERIFIED), or
                #   (b) the agent reported no error AND verification could not
                #       gather any evidence either way (STATUS_UNKNOWN) --
                #       e.g. no screen-capture backend on this machine. That is
                #       "trust the agent, we simply couldn't double-check it",
                #       NOT proof of success -- it is recorded as such in the
                #       goal's own verification summary (see verify_goal).
                # STATUS_UNVERIFIED and STATUS_CONFLICT are always treated as
                # failure and drive the retry/diagnose/replan path below.
                verified_ok = verification.get("status") == verifier.STATUS_VERIFIED
                # 9.5+ trust contract: UNKNOWN is never treated as success.
                # An adapter may, however, provide its own independent verification
                # evidence (for example Windows app-launch verification or file validation).
                agent_verified = bool(result.get("verified")) and bool(result.get("verification") or result.get("evidence"))
                if verified_ok or agent_verified:
                    if agent_verified and verification.get("status") != verifier.STATUS_VERIFIED:
                        verification = verifier.make_result(
                            task.get("verification_level", "semantic"),
                            verifier.STATUS_VERIFIED,
                            max(float(verification.get("confidence", 0.0) or 0.0), 0.88),
                            [result.get("verification") or result.get("evidence")],
                            "adapter supplied independent verification evidence",
                        )
                        graph.set_verification_result(task_id, verification)
                    succeeded = True
                    break

                attempts_log.append({
                    "method": result.get("method", f"attempt {len(attempts_log) + 1}"),
                    "reason": result.get("error") or verification.get("notes") or "the result did not verify",
                })

                if not graph.can_retry(task_id):
                    break

                graph.set_status(task_id, "DIAGNOSING", note=attempts_log[-1]["reason"])
                graph.set_status(task_id, "REPLANNING")
                task = dict(task)
                task["inputs"] = dict(task.get("inputs") or {})
                task["inputs"]["retry_strategy"] = "alternate"
                task["inputs"]["previous_failure"] = attempts_log[-1]["reason"]
                graph.set_status(task_id, "RETRYING")
                # IMPORTANT: RUNNING is what increments the stored attempt
                # counter (see friday_task_graph.set_status). Without this,
                # can_retry() would keep seeing attempts=1 forever and this
                # loop would never terminate on a persistently-failing task.
                graph.set_status(task_id, "RUNNING")

            if succeeded:
                graph.set_status(task_id, "COMPLETED")
                state.upsert_item("tasks", task_id, status="COMPLETED")
            else:
                explanation = _explain_failure(task, attempts_log)
                graph.set_failure_explanation(task_id, explanation)
                graph.set_status(task_id, "FAILED", note=explanation)
                state.upsert_item("tasks", task_id, status="FAILED", explanation=explanation)

            task_results.append({
                "task_id": task_id,
                "action": task["action"],
                "status": verification.get("status", verifier.STATUS_UNKNOWN),
                "confidence": verification.get("confidence", 0.0),
                "explanation": None if succeeded else graph.get_task(task_id).get("failure_explanation"),
            })

    final_goal = graph.get_goal(goal_id)
    goal_status = final_goal.get("status") if final_goal else "FAILED"
    goal_verification = verifier.verify_goal(goal.get("description", ""), task_results)
    state.upsert_item("goals", goal_id, status=goal_status, goal_verification=goal_verification)

    if goal_status == "COMPLETED":
        explanation = f"Goal '{goal.get('description')}' completed: all {len(task_results)} tasks verified."
    else:
        failed = [t for t in task_results if t["status"] != verifier.STATUS_VERIFIED]
        explanation = "; ".join(t.get("explanation") or f"{t['action']} did not verify" for t in failed) or \
            "The goal did not complete and no specific task failure was recorded."

    return {
        "goal_id": goal_id,
        "status": goal_status,
        "confidence": goal_verification.get("confidence", 0.0),
        "explanation": explanation,
        "task_results": task_results,
    }
