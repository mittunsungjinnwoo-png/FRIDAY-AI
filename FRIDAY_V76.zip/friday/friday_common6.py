"""FRIDAY 6.0 shared helpers: data folder, one SQLite file (friday6.db), tokenising, redaction, address, clock.

Nothing here touches the microphone, recognition or speech code.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import sqlite3
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional

HERE = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("FRIDAY_DATA") or (HERE / "friday_data"))
DB_PATH = Path(os.environ.get("FRIDAY_V6_DB") or (DATA_DIR / "friday6.db"))
VERSION = "7.0"
_lock = threading.RLock()
_conn: Optional[sqlite3.Connection] = None
_SCHEMAS: List[str] = []
_cfg: Dict[str, Callable] = {"address": lambda: "sir", "log": lambda m, k="v6": None, "llm": None}

SECRET = re.compile(r"(AIza[0-9A-Za-z_\-]{20,}|sk-[A-Za-z0-9_\-]{16,}|ghp_[A-Za-z0-9]{20,}|\b(?:password|passcode|pin|cvv|api[ _-]?key|secret|token)\b\s*(?:is|=|:)\s*\S+|\b\d{13,19}\b)", re.I)
STOP = set("a an the and or but if then of to in on at for with from by is are was were be been am it its this that these those i me my we our you your he she they them his her their as so do does did not no yes can could would should will shall may might have has had just very really please hey friday what whats when where who why how which about into over under up down out".split())


def configure(**kw):
    _cfg.update({k: v for k, v in kw.items() if v is not None})


def log(msg: str, kind: str = "v6"):
    try:
        _cfg["log"](msg, kind)
    except Exception:
        pass


def address() -> str:
    try:
        a = _cfg["address"]()
        return (a or "sir").strip() or "sir"
    except Exception:
        return "sir"


def llm(prompt: str, **kw) -> str:
    """Model call supplied by the backend (None in tests / offline). Never raises."""
    fn = _cfg.get("llm")
    if not fn:
        return ""
    try:
        return str(fn(prompt, **kw) or "")
    except Exception as exc:
        log(f"llm call failed: {exc}", "recovery")
        return ""


def register_schema(sql: str):
    _SCHEMAS.append(sql)
    if _conn is not None:
        with _lock:
            _conn.executescript(sql)
            _conn.commit()


def db() -> sqlite3.Connection:
    global _conn
    if _conn is not None:
        return _conn
    with _lock:
        if _conn is not None:
            return _conn
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=10)
        c.row_factory = sqlite3.Row
        try:
            c.execute("PRAGMA journal_mode=WAL")
        except Exception:
            pass
        for s in _SCHEMAS:
            c.executescript(s)
        c.commit()
        _conn = c
        return c


def reset_for_tests(path: Path):
    global _conn, DB_PATH
    with _lock:
        if _conn is not None:
            try:
                _conn.close()
            except Exception:
                pass
        _conn = None
        DB_PATH = Path(path)


def q(sql: str, args: Iterable = ()) -> List[sqlite3.Row]:
    with _lock:
        c = db()
        cur = c.execute(sql, tuple(args))
        rows = cur.fetchall()
        c.commit()
        return rows


def x(sql: str, args: Iterable = ()) -> int:
    with _lock:
        c = db()
        cur = c.execute(sql, tuple(args))
        c.commit()
        return int(cur.lastrowid or 0)


def now() -> float:
    return time.time()


def iso(ts: Optional[float] = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time()).strftime("%Y-%m-%d %H:%M")


def day(ts: Optional[float] = None) -> str:
    return datetime.fromtimestamp(ts if ts is not None else time.time()).strftime("%Y-%m-%d")


def redact(text: str) -> str:
    return SECRET.sub("[redacted]", text or "")


def norm(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", (text or "").lower())).strip()


def stem(w: str) -> str:
    for suf in ("ingly", "edly", "ing", "ed", "ies", "es", "s", "ly"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)] + ("y" if suf == "ies" else "")
    return w


SYN_GROUPS = [
    "bug error fault defect crash issue problem failure exception broken",
    "fix repair solve resolve patch correct debug",
    "money cash funds budget finance spending savings saving expense cost price",
    "car vehicle automobile",
    "laptop computer pc machine notebook",
    "happy glad pleased delighted joy",
    "sad unhappy upset down gloomy",
    "angry annoyed frustrated irritated mad furious",
    "tired exhausted sleepy fatigued",
    "meeting call appointment session conference",
    "study revise revision learn learning exam test paper homework",
    "project app application program software build",
    "goal target aim objective plan ambition",
    "doctor physician medic clinic hospital",
    "food meal eat dinner lunch breakfast cooking recipe",
    "buy purchase order acquire",
    "movie film cinema picture",
    "song music track audio tune",
    "friend buddy mate pal",
    "job work career employment office",
    "deadline due duedate cutoff",
    "slow lag laggy delay latency sluggish",
    "fast quick rapid speedy",
]
_SYN: Dict[str, int] = {}
for _i, _g in enumerate(SYN_GROUPS):
    for _w in _g.split():
        _SYN.setdefault(stem(_w), _i)


def tokens(text: str, expand: bool = False) -> List[str]:
    out = [stem(w) for w in norm(text).split() if w not in STOP and len(w) > 1]
    if expand:
        extra = [f"~g{_SYN[w]}" for w in out if w in _SYN]
        out += extra
    return out


def _trigrams(text: str) -> Dict[str, int]:
    t = " " + norm(text) + " "
    d: Dict[str, int] = {}
    for i in range(len(t) - 2):
        g = t[i:i + 3]
        d[g] = d.get(g, 0) + 1
    return d


def similarity(a: str, b: str) -> float:
    """Meaning-aware local similarity: word overlap with stemming and synonym groups blended with trigrams."""
    ta, tb = tokens(a, True), tokens(b, True)
    if not ta or not tb:
        return 0.0
    sa, sb = set(ta), set(tb)
    jac = len(sa & sb) / max(1, len(sa | sb))
    ga, gb = _trigrams(a), _trigrams(b)
    dot = sum(v * gb.get(k, 0) for k, v in ga.items())
    na = math.sqrt(sum(v * v for v in ga.values())) or 1.0
    nb = math.sqrt(sum(v * v for v in gb.values())) or 1.0
    cos = dot / (na * nb)
    cover = len(sa & sb) / max(1, min(len(sa), len(sb)))
    return round(0.45 * cover + 0.30 * jac + 0.25 * cos, 4)


def fingerprint(text: str) -> str:
    return hashlib.sha1(norm(text).encode("utf-8")).hexdigest()[:16]


def jdump(o) -> str:
    return json.dumps(o, ensure_ascii=False)


def jload(s, default=None):
    try:
        return json.loads(s)
    except Exception:
        return default


def clip(text: str, n: int = 240) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text if len(text) <= n else text[: n - 1].rstrip() + "…"


def parse_when(text: str, base: Optional[datetime] = None) -> Optional[float]:
    """Parse 'tomorrow 5pm', 'in 2 hours', 'on 2026-11-30', 'friday at 9', 'at 18:30' -> epoch seconds."""
    from datetime import timedelta
    t = (text or "").lower()
    base = base or datetime.now()
    m = re.search(r"\bin\s+(\d+)\s*(minute|min|hour|hr|day|week)s?\b", t)
    if m:
        n, u = int(m.group(1)), m.group(2)
        delta = {"minute": timedelta(minutes=n), "min": timedelta(minutes=n), "hour": timedelta(hours=n), "hr": timedelta(hours=n),
                 "day": timedelta(days=n), "week": timedelta(weeks=n)}[u]
        return (base + delta).timestamp()
    d = None
    m = re.search(r"\b(20\d\d)-(\d\d)-(\d\d)\b", t)
    if m:
        try:
            d = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            d = None
    if d is None:
        if re.search(r"\btomorrow\b", t):
            d = (base + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        elif re.search(r"\b(today|tonight)\b", t):
            d = base.replace(hour=0, minute=0, second=0, microsecond=0)
        else:
            days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
            for i, name in enumerate(days):
                if re.search(r"\b(?:on |next |this )?" + name + r"\b", t):
                    ahead = (i - base.weekday()) % 7 or 7
                    d = (base + timedelta(days=ahead)).replace(hour=0, minute=0, second=0, microsecond=0)
                    break
    hh, mm = None, 0
    m = re.search(r"\b(?:at\s+)?(\d{1,2})(?::(\d\d))?\s*(am|pm)\b", t) or re.search(r"\bat\s+(\d{1,2})(?::(\d\d))?\b", t)
    if m:
        hh = int(m.group(1))
        mm = int(m.group(2) or 0)
        ap = m.group(3) if m.lastindex and m.lastindex >= 3 else None
        if ap == "pm" and hh < 12:
            hh += 12
        if ap == "am" and hh == 12:
            hh = 0
        if hh > 23 or mm > 59:
            hh = None
    if d is None and hh is None:
        return None
    if d is None:
        d = base.replace(hour=0, minute=0, second=0, microsecond=0)
        cand = d.replace(hour=hh or 0, minute=mm)
        if cand <= base:
            cand += timedelta(days=1)
        return cand.timestamp()
    if hh is None:
        hh = 9
    return d.replace(hour=hh, minute=mm).timestamp()
