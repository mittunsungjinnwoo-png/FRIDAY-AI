/* FRIDAY theme + customisation engine.
   Shared by index.html (dashboard) and widget.html (desktop widget).
   - Theme.cfg        the saved customisation (colours, icons, reactor, widget, layout, address)
   - Theme.set(path, value) / Theme.patch(obj) / Theme.reset()   change + save + apply live
   - Theme.reactor(canvas, opts)   animated arc reactor (8 designs)
   - Theme.addr(text)  rewrites "Sir" in FRIDAY's replies to the address you chose
   Config is cached in localStorage and mirrored to friday_data/ui_config.json by the desktop app,
   which also pushes changes to the widget window so both always match. */
(function (root) {
  'use strict';

  /* ------------------------------------------------------------------ defaults */
  const DEF = {
    v: 2,
    mode: 'dark',                 // dark | light | auto
    accent: '#1ea4ff',
    accent2: 'auto',              // secondary colour (violet parts of the HUD); 'auto' = derived from the accent
    bg: '#000a2a',
    bgStyle: 'glow',              // glow | flat | grid | aurora | stars | scan | nebula
    surface: 'solid',             // solid | glass
    radius: 14,                   // px, main corner radius (legacy pages)
    font: 'hud',
    anim: true,
    glow: 100,                    // % glow on panels
    zoom: 100,                    // % interface size (desktop app)
    icons: { style: 'regular', color: 'auto', tile: 'rounded', size: 19 },
    reactor: { type: 'core', color: 'accent', custom: '#ffcf5a', second: 'auto', secondCustom: '#a66bff', size: 100, speed: 100, glow: 100, show: true,
      rings: 6, ringStyle: 'mixed', dir: 'alt', emblem: 'logo', beam: true, platform: true, particles: true, orbits: true, network: true, react: 100, tilt: true },
    widget: { type: 'panel', opacity: 100, top: true, reactor: 'same' },
    layout: { sidebar: 'full', right: true, panels: { status: true, actions: true, activity: true }, density: 'comfortable', hiddenNav: [] },
    home: { tasks: true, schedule: true, tiles: true, chips: true, quote: true, plate: true, decor: true, chat: 'auto',
      card: 'Better Ideas. Greater Results.', head1: '\u201cSmarter plans.', head2: 'Bigger dreams.\u201d' },
    fx: { scan: false, flow: true, neon: 100, chamfer: 8, parallax: true, sound: false, boot: false, glass: false, grid: false },
    profile: { name: 'Hashik', badge: '\uD83D\uDC51', ask: 'What shall we do today?' },
    addr: { mode: 'sir', name: '', custom: '' },
    assistant: { name: 'FRIDAY', tagline: 'Your Productivity Companion', greet: 'time', sub: 'your advanced AI assistant. What would you like to do today?' }
  };

  const FONTS = {
    hud: ['HUD (Bahnschrift)', '"Bahnschrift SemiCondensed",Bahnschrift,"Segoe UI",system-ui,"DejaVu Sans Condensed",sans-serif'],
    segoe: ['Segoe UI', '"Segoe UI",system-ui,sans-serif'],
    tech: ['Bahnschrift', 'Bahnschrift,"Segoe UI",system-ui,sans-serif'],
    mono: ['Consolas', 'Consolas,"Cascadia Mono","Courier New",monospace'],
    serif: ['Georgia', 'Georgia,"Times New Roman",serif'],
    round: ['Trebuchet', '"Trebuchet MS","Segoe UI",sans-serif'],
    system: ['System', 'system-ui,-apple-system,"Segoe UI",sans-serif']
  };

  const ADDR = {
    sir: { label: 'Sir', word: 'Sir', title: true },
    madam: { label: 'Madam', word: 'Madam', title: true },
    maam: { label: "Ma'am", word: "Ma'am", title: true },
    boss: { label: 'Boss', word: 'Boss', title: true },
    captain: { label: 'Captain', word: 'Captain', title: true },
    name: { label: 'My name', word: '', title: false },
    custom: { label: 'Custom', word: '', title: false },
    none: { label: 'No title', word: '', title: false }
  };

  const RC = (o) => Object.assign({ type: 'core', color: 'accent', custom: '#ffcf5a', second: 'auto', secondCustom: '#a66bff', size: 100, speed: 100, glow: 100, show: true, rings: 6, ringStyle: 'mixed', dir: 'alt', emblem: 'logo', beam: true, platform: true, particles: true, orbits: true, network: true, react: 100, tilt: true }, o || {});
  const PRESETS = {
    stark: { label: 'Hologram Blue', p: {} },
    nebula: { label: 'Violet Nebula', p: { accent: '#a66bff', accent2: '#ff4fd8', bg: '#0a0420', bgStyle: 'nebula', surface: 'glass', reactor: RC({ glow: 125, rings: 7 }) } },
    cyber: { label: 'Neon Cyberpunk', p: { accent: '#ff2ea6', accent2: '#19e0ff', bg: '#10031c', bgStyle: 'grid', reactor: RC({ glow: 130, ringStyle: 'dash', second: 'auto' }), fx: { scan: true, flow: true, neon: 140, chamfer: 10 } } },
    mark7: { label: 'Mark VII', p: { accent: '#ff4a3d', accent2: '#ffc94a', bg: '#12060a', bgStyle: 'glow', reactor: RC({ rings: 5, glow: 120, emblem: 'triangle' }), fx: { neon: 120 } } },
    emerald: { label: 'Emerald Ops', p: { accent: '#1fe0a0', accent2: '#2ab4ff', bg: '#02100c', bgStyle: 'grid', font: 'mono', reactor: RC({ ringStyle: 'ticks', rings: 7 }), fx: { chamfer: 6 } } },
    ice: { label: 'Arctic Ice', p: { accent: '#7ae7ff', accent2: '#b6a7ff', bg: '#02121c', bgStyle: 'stars', reactor: RC({ ringStyle: 'dots', glow: 110 }) } },
    gold: { label: 'Gold Standard', p: { accent: '#ffc23a', accent2: '#ff7a1a', bg: '#0c0904', bgStyle: 'glow', reactor: RC({ emblem: 'orb', rings: 6 }), fx: { neon: 120 } } },
    amber: { label: 'Amber Terminal', p: { accent: '#ffb000', accent2: '#ff6a00', bg: '#0c0800', bgStyle: 'scan', font: 'mono', reactor: RC({ ringStyle: 'ticks', network: false, rings: 4 }), fx: { scan: true, chamfer: 3 } } },
    ghost: { label: 'Ghost Mono', p: { accent: '#e4e4e4', accent2: '#9aa4b8', bg: '#0a0a0a', bgStyle: 'flat', reactor: RC({ glow: 55, particles: false, ringStyle: 'solid' }), fx: { flow: false, neon: 40 } } },
    day: { label: 'Daylight', p: { mode: 'light', accent: '#1467d0', bgStyle: 'flat', reactor: RC({ glow: 60 }), fx: { neon: 30 } } }
  };

  const ACCENTS = ['#1ea4ff', '#00d4ff', '#1fe0a0', '#7ed957', '#ffb000', '#ff7a1a', '#ff4a3d', '#ff2ea6', '#a66bff', '#e4e4e4'];
  const BGS = ['#000a2a', '#030a16', '#000000', '#0a0a0f', '#02100c', '#12060a', '#0a0420', '#0c0800'];

  /* ------------------------------------------------------------------ colour maths */
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function h2r(h) { h = String(h).replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h.slice(0, 6), 16) || 0; return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function r2h(r) { return '#' + r.map(v => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0')).join(''); }
  function mix(a, b, k) { const A = h2r(a), B = h2r(b); return r2h(A.map((v, i) => v + (B[i] - v) * k)); }
  function lum(h) { const [r, g, b] = h2r(h).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * r + .7152 * g + .0722 * b; }
  const light = (c, k) => mix(c, '#ffffff', k), dark = (c, k) => mix(c, '#000000', k);
  function alpha(h, a) { return h + Math.round(clamp(a, 0, 1) * 255).toString(16).padStart(2, '0'); }
  function hue(h, deg) { let [r, g, b] = h2r(h).map(v => v / 255); const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let H = 0, S = 0, L = (mx + mn) / 2; if (mx !== mn) { const d = mx - mn; S = L > .5 ? d / (2 - mx - mn) : d / (mx + mn); H = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; H *= 60; } H = (H + deg + 360) % 360; const f = n => { const k = (n + H / 30) % 12, a = S * Math.min(L, 1 - L); return L - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); }; return r2h([f(0) * 255, f(8) * 255, f(4) * 255]); }

  /* ------------------------------------------------------------------ config */
  function merge(base, over) {
    if (Array.isArray(base)) return Array.isArray(over) ? over.slice() : base.slice();
    if (base && typeof base === 'object') { const o = {}; for (const k in base) o[k] = merge(base[k], over && typeof over === 'object' ? over[k] : undefined); return o; }
    return over === undefined || over === null || (typeof over === 'object') ? base : over;
  }
  const clone = o => JSON.parse(JSON.stringify(o));
  /* v1 configs (old look) are reset to the new look; address, name, widget, zoom and layout choices are kept */
  function migrate(o) {
    if (!o || typeof o !== 'object') return {};
    if ((o.v || 1) >= 2) return o;
    const keep = { v: 2 };
    ['addr', 'assistant', 'zoom', 'widget', 'layout', 'profile'].forEach(k => { if (o[k] !== undefined) keep[k] = o[k]; });
    if (keep.layout) keep.layout = Object.assign({}, keep.layout, { panels: undefined });
    if (keep.assistant && (keep.assistant.tagline === 'Advanced AI Assistant' || !keep.assistant.tagline)) keep.assistant = Object.assign({}, keep.assistant, { tagline: undefined });
    return keep;
  }
  let cfg = clone(DEF);
  try { const raw = root.localStorage.getItem('friday_ui'); if (raw) cfg = merge(DEF, migrate(JSON.parse(raw))); } catch (e) { }
  const subs = [];
  const B = root.fridayBridge || null;

  function getPath(o, p) { return p.split('.').reduce((a, k) => (a == null ? a : a[k]), o); }
  function setPath(o, p, v) { const ks = p.split('.'); let a = o; while (ks.length > 1) a = a[ks.shift()]; a[ks[0]] = v; }

  function save(silent) {
    const txt = JSON.stringify(cfg);
    try { root.localStorage.setItem('friday_ui', txt); } catch (e) { }
    if (B && B.uiSave && !silent) B.uiSave(txt);
  }

  /* ------------------------------------------------------------------ palette */
  function isLight() {
    if (cfg.mode === 'light') return true;
    if (cfg.mode === 'auto') return !!(root.matchMedia && root.matchMedia('(prefers-color-scheme: light)').matches);
    return false;
  }

  function palette() {
    const a = cfg.accent, L = isLight();
    const bg = L ? mix('#ffffff', a, .07) : cfg.bg;
    const bgLight = !L && lum(bg) > .45;                 // user picked a very light "dark" background
    const lt = L || bgLight;
    const v = {};
    v['--a'] = a;
    v['--bg'] = bg;
    if (!lt) {
      v['--t'] = mix('#ffffff', a, .12); v['--m'] = mix(v['--t'], bg, .5);
      v['--a2'] = light(a, .4);
      const k = (x) => mix(bg, a, x);
      Object.assign(v, { '--b': k(.42), '--k2': k(.24), '--k3': k(.5), '--k4': k(.37), '--s0': k(.17), '--s1': k(.2), '--s2': k(.34), '--s3': k(.47), '--s35': k(.53), '--s4': k(.62), '--s5': k(.7), '--s6': k(.6), '--ci': k(.25), '--pill': k(.12), '--hov': k(.25), '--bub': k(.18), '--p': k(.08), '--p2': k(.125), '--p3': k(.013), '--gl': k(.17), '--grid': alpha(a, .07) });
      v['--sbbg'] = alpha(k(.024), .8);
      v['--navt'] = '#ffffff';
    } else {
      v['--t'] = mix('#0b1220', a, .22); v['--m'] = mix(v['--t'], bg, .45);
      v['--a2'] = dark(a, .22);
      const k = (x) => mix(bg, a, x);
      Object.assign(v, { '--b': k(.32), '--k2': k(.22), '--k3': k(.36), '--k4': k(.2), '--s0': k(.07), '--s1': k(.1), '--s2': k(.16), '--s3': k(.5), '--s35': k(.58), '--s4': k(.7), '--s5': k(.82), '--s6': k(.62), '--ci': k(.16), '--pill': k(.06), '--hov': k(.12), '--bub': k(.1), '--p': '#ffffff', '--p2': k(.05), '--p3': '#ffffff', '--gl': k(.1), '--grid': alpha(a, .1) });
      v['--sbbg'] = alpha('#ffffff', .72);
      v['--navt'] = v['--t'];
    }
    v['--bt'] = lum(v['--s4']) > .5 ? '#001018' : '#ffffff';
    v['--ont'] = lum(a) > .5 ? '#001018' : '#ffffff';
    v['--a3'] = (cfg.accent2 && cfg.accent2 !== 'auto') ? cfg.accent2 : hue(a, 70); v['--a3a'] = alpha(v['--a3'], .2);
    v['--a22'] = alpha(a, .13); v['--a44'] = alpha(a, .27); v['--a55'] = alpha(a, .33); v['--a88'] = alpha(a, .53);
    const gl = cfg.glow / 100;
    v['--ins'] = alpha(a, .17 * gl); v['--glw'] = alpha(a, .27 * gl);
    v['--pg'] = alpha(lt ? '#ffffff' : v['--p'], .55);
    v['--wp'] = alpha(lt ? mix(bg, '#ffffff', .6) : mix(bg, a, .06), .94);
    const R = cfg.radius;
    v['--r1'] = R + 'px'; v['--r2'] = Math.max(2, Math.round(R * .85)) + 'px'; v['--r3'] = Math.max(2, Math.round(R * .65)) + 'px'; v['--r4'] = Math.max(2, Math.round(R * .5)) + 'px';
    v['--font'] = (FONTS[cfg.font] || FONTS.segoe)[1];
    const ic = cfg.icons;
    v['--isz'] = ic.size + 'px';
    v['--isw'] = { thin: 1.1, regular: 1.7, bold: 2.5, glow: 1.7, neon: 2.1 }[ic.style] || 1.7;
    v['--ic'] = ic.color === 'white' ? v['--t'] : v['--a2'];
    v['--icn'] = ic.color === 'accent' ? v['--a2'] : ic.color === 'white' ? v['--t'] : 'inherit';
    v['--rsz'] = cfg.reactor.size + 'px';
    v['--neon'] = clamp((cfg.fx.neon == null ? 100 : cfg.fx.neon) / 100, 0, 2);
    v['--ch'] = (clamp(cfg.fx.chamfer == null ? 8 : cfg.fx.chamfer, 0, 16) / 10) + 'rem';
    v._light = lt;
    return v;
  }

  let rainbowEl = null;
  function rainbow(on, L) {
    if (!rainbowEl) { rainbowEl = root.document.createElement('style'); root.document.head.appendChild(rainbowEl); }
    if (!on) { rainbowEl.textContent = ''; return; }
    let css = '';
    for (let i = 0; i < 12; i++) {
      const c = L ? `hsl(${i * 31 + 205} 70% 38%)` : `hsl(${i * 31 + 205} 85% 68%)`;
      css += `nav button:nth-child(${i + 1}) svg{color:${c}!important}`;
      css += `.tl:nth-child(${i + 1}) .ci,.cd:nth-child(${i + 1}) .ci,.srow:nth-child(${i + 2}) .ci{color:${c}!important}`;
    }
    rainbowEl.textContent = css;
  }
  let navEl = null;
  function navRules() {
    if (!navEl) { navEl = root.document.createElement('style'); root.document.head.appendChild(navEl); }
    navEl.textContent = cfg.layout.hiddenNav.map(n => `nav button[data-v="${String(n).replace(/"/g, '')}"]{display:none}`).join('');
  }

  function apply() {
    const d = root.document; if (!d || !d.body) return;
    const v = palette(), st = d.documentElement.style, body = d.body;
    for (const k in v) if (k[0] === '-') st.setProperty(k, String(v[k]));
    body.classList.toggle('lt', !!v._light);
    const ds = body.dataset, L = cfg.layout;
    ds.bgs = cfg.bgStyle; ds.surf = cfg.surface; ds.ic = cfg.icons.style; ds.tile = cfg.icons.tile; ds.dens = L.density;
    ds.sb = L.sidebar; ds.anim = cfg.anim ? 'on' : 'off'; ds.hero = cfg.reactor.show ? 'on' : 'off';
    const anyPanel = L.right && Object.values(L.panels).some(Boolean);
    ds.right = anyPanel ? 'on' : 'off';
    for (const k in L.panels) ds['p' + k[0].toUpperCase() + k.slice(1)] = L.panels[k] ? 'on' : 'off';
    st.setProperty('--colL', L.sidebar === 'full' ? '14.2rem' : L.sidebar === 'icons' ? '4.6rem' : '0rem');
    st.setProperty('--colR', anyPanel ? '22.9rem' : '0rem');
    const F = cfg.fx; ds.scan = F.scan ? 'on' : 'off'; ds.flow = F.flow ? 'on' : 'off'; ds.grid = F.grid ? 'on' : 'off'; ds.par = F.parallax ? 'on' : 'off'; ds.chat = cfg.home.chat;
    ['tasks', 'schedule', 'tiles', 'chips', 'quote', 'plate', 'decor'].forEach(k => { ds['h' + k[0].toUpperCase() + k.slice(1)] = cfg.home[k] ? 'on' : 'off'; });
    if (F.glass && cfg.surface !== 'glass') ds.surf = 'glass';
    ds.wt = cfg.widget.type;
    rainbow(cfg.icons.color === 'rainbow', !!v._light);
    navRules();
    if (B && B.setZoom && !root.__fridayWidget) B.setZoom(cfg.zoom / 100);
    if (root.__fridayWidget) { const r = d.getElementById('root'); if (r) r.style.opacity = cfg.widget.opacity / 100; }
    subs.forEach(f => { try { f(cfg); } catch (e) { console.error(e); } });
  }

  /* ------------------------------------------------------------------ address */
  function addrWord() {
    const a = cfg.addr, m = ADDR[a.mode] || ADDR.sir;
    if (a.mode === 'name') return (a.name || '').trim() || 'Sir';
    if (a.mode === 'custom') return (a.custom || '').trim();
    if (a.mode === 'none') return '';
    return m.word;
  }
  const addrIsTitle = () => (ADDR[cfg.addr.mode] || ADDR.sir).title;
  function addr(t) {
    t = String(t == null ? '' : t);
    const w = addrWord(), title = addrIsTitle();
    if (w.toLowerCase() === 'sir' && addrIsTitle()) return t;
    if (w) return t.replace(/\bsir\b/gi, m => title ? (m[0] === 'S' ? w : w.toLowerCase()) : w);
    t = t.replace(/,\s*sir\b/gi, '').replace(/\bsir,\s*/gi, '').replace(/\s+sir\b/gi, '').replace(/\bsir\b/gi, '').trim();
    return t ? t[0].toUpperCase() + t.slice(1) : t;
  }
  function sendAddress() {
    if (!B || !B.setAddress) return;
    B.setAddress(JSON.stringify({ word: addrWord(), title: addrIsTitle() }));
  }
  function greeting() {
    const h = new Date().getHours(), w = addrWord(), g = cfg.assistant.greet;
    const lead = g === 'welcome' ? 'Welcome back' : g === 'hello' ? 'Hello' : g === 'service' ? 'At your service' : (h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening');
    return { lead, word: w, html: w ? `${lead}, <span>${w.replace(/[<>&]/g, '')}</span>.` : `${lead}.` };
  }

  /* ------------------------------------------------------------------ arc reactor */
  const TAU = Math.PI * 2;
  function reactorColors(rc) {
    const base = rc.color === 'custom' ? rc.custom : cfg.accent;
    const sec = rc.second === 'custom' ? rc.secondCustom : (cfg.accent2 && cfg.accent2 !== 'auto' ? cfg.accent2 : hue(base, 70));
    const k = { sec, mag: mix(sec, '#ff3fd0', .45) };
    if (isLight()) return Object.assign(k, { a: base, lo: dark(base, .3), mid: base, a2: dark(base, .08), hi: dark(base, .18), wh: dark(base, .3), dk: light(base, .86), L: true });
    return Object.assign(k, { a: base, lo: dark(base, .25), mid: light(base, .12), a2: light(base, .4), hi: light(base, .62), wh: light(base, .9), dk: dark(base, .82) });
  }

  function makeDrawer(cx, C, glow) {
    const gl = glow / 100;
    const ring = (R, w, n, gap, rot, col, al) => { cx.save(); cx.rotate(rot); cx.strokeStyle = col; cx.globalAlpha = al; cx.lineWidth = w; const s = TAU / n; for (let i = 0; i < n; i++) { cx.beginPath(); cx.arc(0, 0, R, i * s, i * s + s * (1 - gap)); cx.stroke(); } cx.restore(); };
    const tks = (R, n, l, rot, al, col) => { cx.save(); cx.rotate(rot); cx.strokeStyle = col || C.a2; cx.globalAlpha = al; cx.lineWidth = 1.5; for (let i = 0; i < n; i++) { const a = i / n * TAU, L = i % 5 ? l : l * 1.9; cx.beginPath(); cx.moveTo(Math.cos(a) * R, Math.sin(a) * R); cx.lineTo(Math.cos(a) * (R - L), Math.sin(a) * (R - L)); cx.stroke(); } cx.restore(); };
    const arc = (R, w, a0, len, rot, col) => { cx.save(); cx.rotate(rot); cx.strokeStyle = col; cx.lineWidth = w; cx.lineCap = 'round'; cx.beginPath(); cx.arc(0, 0, R, a0, a0 + len); cx.stroke(); cx.restore(); };
    const circ = (R, w, col, al) => { cx.strokeStyle = col; cx.globalAlpha = al == null ? 1 : al; cx.lineWidth = w; cx.beginPath(); cx.arc(0, 0, R, 0, TAU); cx.stroke(); cx.globalAlpha = 1; };
    const halo = (R, al) => { const g = cx.createRadialGradient(0, 0, R * .1, 0, 0, R); g.addColorStop(0, alpha(C.a, clamp(.2 * al * gl, 0, 1))); g.addColorStop(1, alpha(C.a, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, R, 0, TAU); cx.fill(); };
    const core = (R, pulse) => { const r = R * pulse; const g = cx.createRadialGradient(0, 0, 0, 0, 0, r); g.addColorStop(0, C.L ? light(C.a, .35) : '#ffffff'); g.addColorStop(.25, C.L ? C.a : C.wh); g.addColorStop(.6, alpha(C.a2, .9)); g.addColorStop(1, alpha(C.a, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, r, 0, TAU); cx.fill(); };
    const poly = (n, R, rot) => { cx.beginPath(); for (let i = 0; i <= n; i++) { const a = rot + i / n * TAU; i ? cx.lineTo(Math.cos(a) * R, Math.sin(a) * R) : cx.moveTo(Math.cos(a) * R, Math.sin(a) * R); } cx.closePath(); };
    const glowOn = (b) => { cx.shadowColor = C.a; cx.shadowBlur = (b == null ? 10 : b) * gl; };

    return {
      hud(t) {
        halo(220, 1);
        cx.save(); cx.translate(0, 196); cx.scale(1, .12); const g = cx.createRadialGradient(0, 0, 0, 0, 0, 150); g.addColorStop(0, alpha(C.a, .6 * gl)); g.addColorStop(1, alpha(C.a, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, 150, 0, TAU); cx.fill(); cx.restore();
        glowOn(10);
        circ(172, 2, C.mid, .7);
        tks(170, 120, 7, t * .12, .85, C.a2); ring(156, 5, 60, .35, -t * .22, C.hi, .55); ring(144, 11, 3, .12, t * .3, C.a, .9);
        ring(128, 3, 90, .4, t * .5, C.hi, .8); ring(112, 10, 28, .45, -t * .7, C.mid, .95);
        circ(98, 2, C.lo, 1);
        tks(96, 72, 5, -t * .4, .8, C.a2); ring(84, 4, 12, .5, t * .9, C.a2, .8);
        arc(58, 7, 0, 1.9, t * 1.6, C.wh); arc(58, 7, Math.PI, 1.9, t * 1.6, C.wh); arc(40, 4, .4, 1.3, -t * 2.1, C.hi); arc(40, 4, Math.PI + .4, 1.3, -t * 2.1, C.hi);
        circ(70, 2, C.a, .5);
      },
      stark(t, b) {
        halo(230, 1.2);
        glowOn(14);
        circ(184, 9, C.a, .95); circ(170, 2, C.hi, .8); circ(196, 1.5, C.a2, .4);
        cx.save(); cx.rotate(t * .08);
        for (let i = 0; i < 10; i++) {                       /* ten copper coil blocks */
          const a0 = i / 10 * TAU + .035, a1 = (i + 1) / 10 * TAU - .035;
          cx.beginPath(); cx.arc(0, 0, 148, a0, a1); cx.arc(0, 0, 102, a1, a0, true); cx.closePath();
          const g = cx.createLinearGradient(Math.cos(a0) * 148, Math.sin(a0) * 148, Math.cos(a0) * 102, Math.sin(a0) * 102);
          g.addColorStop(0, alpha(C.a, .55)); g.addColorStop(1, alpha(C.lo, .85));
          cx.fillStyle = g; cx.fill(); cx.lineWidth = 2; cx.strokeStyle = C.hi; cx.globalAlpha = .9; cx.stroke(); cx.globalAlpha = 1;
          cx.beginPath(); cx.arc(0, 0, 125, a0 + .05, a1 - .05); cx.lineWidth = 2; cx.strokeStyle = C.wh; cx.globalAlpha = .35 + .25 * Math.sin(t * 2 * b + i); cx.stroke(); cx.globalAlpha = 1;
        }
        cx.restore();
        circ(94, 7, C.hi, .95); circ(84, 2, C.a2, .6);
        cx.save(); cx.rotate(-t * .25); poly(3, 70, -Math.PI / 2); cx.lineWidth = 8; cx.strokeStyle = C.wh; cx.globalAlpha = .95; cx.lineJoin = 'round'; cx.stroke(); cx.restore();
        cx.save(); cx.rotate(-t * .25 + Math.PI); poly(3, 40, -Math.PI / 2); cx.lineWidth = 3; cx.strokeStyle = C.a2; cx.globalAlpha = .7; cx.stroke(); cx.restore();
        cx.shadowBlur = 0; core(62, 1 + .07 * Math.sin(t * 3 * b));
      },
      orb(t, b) {
        halo(230, 1.4);
        for (let i = 0; i < 3; i++) { const p = ((t * .35 * b + i / 3) % 1); circ(70 + p * 125, 2.5 * (1 - p) + .5, C.a2, (1 - p) * .55); }
        glowOn(16);
        for (let i = 0; i < 3; i++) {                                    /* tilted orbits with satellites */
          cx.save(); cx.rotate(i * Math.PI / 3 + t * (.15 + i * .05)); cx.scale(1, .32);
          cx.strokeStyle = C.a2; cx.globalAlpha = .55; cx.lineWidth = 2.2; cx.beginPath(); cx.arc(0, 0, 150 - i * 12, 0, TAU); cx.stroke();
          const sa = t * (1.2 + i * .5) * (i % 2 ? -1 : 1); cx.globalAlpha = 1; cx.fillStyle = C.wh; cx.beginPath(); cx.arc(Math.cos(sa) * (150 - i * 12), Math.sin(sa) * (150 - i * 12), 7, 0, TAU); cx.fill(); cx.restore();
        }
        cx.shadowBlur = 0; core(78, 1 + .1 * Math.sin(t * 3 * b));
      },
      rings(t) {
        halo(200, .8);
        glowOn(6);
        const defs = [[176, 2, 1, .0, .15, .9], [150, 3, 2, .08, -.3, .85], [124, 2, 6, .3, .5, .8], [98, 4, 3, .15, -.7, .9], [72, 2, 24, .45, 1.1, .85]];
        defs.forEach(([R, w, n, gap, sp, al], i) => { if (n === 1) circ(R, w, C.a2, al); else ring(R, w, n, gap, t * sp, i % 2 ? C.hi : C.a, al); });
        for (let i = 0; i < 3; i++) { const a = t * (.6 + i * .3) + i * 2.1, R = 176 - i * 26; cx.fillStyle = C.wh; cx.beginPath(); cx.arc(Math.cos(a) * R, Math.sin(a) * R, 5, 0, TAU); cx.fill(); }
        cx.fillStyle = C.wh; cx.beginPath(); cx.arc(0, 0, 9, 0, TAU); cx.fill(); circ(22, 2, C.a2, .7);
      },
      hex(t, b) {
        halo(220, 1);
        glowOn(10);
        const hexes = [[176, 3, 0, .12, C.a], [146, 2, 1, -.18, C.hi], [116, 4, 0, .3, C.mid]];
        hexes.forEach(([R, w, dash, sp, col]) => { cx.save(); cx.rotate(t * sp); poly(6, R, 0); cx.lineWidth = w; cx.strokeStyle = col; cx.globalAlpha = .9; if (dash) cx.setLineDash([14, 9]); cx.stroke(); cx.setLineDash([]); cx.restore(); });
        cx.save(); cx.rotate(t * .12); for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; cx.fillStyle = C.wh; cx.beginPath(); cx.arc(Math.cos(a) * 176, Math.sin(a) * 176, 5, 0, TAU); cx.fill(); } cx.restore();
        tks(100, 60, 6, -t * .3, .6, C.a2);
        cx.save(); cx.rotate(-t * .4); poly(6, 74, 0); cx.lineWidth = 2; cx.strokeStyle = C.hi; cx.globalAlpha = .7; cx.stroke(); cx.restore();
        const cell = 26; const cells = [[0, 0]]; for (let i = 0; i < 6; i++) { const a = i / 6 * TAU + Math.PI / 6; cells.push([Math.cos(a) * cell * 1.74, Math.sin(a) * cell * 1.74]); }
        cells.forEach(([x, y], i) => { cx.save(); cx.translate(x, y); poly(6, cell - 3, Math.PI / 6); cx.fillStyle = alpha(C.a2, .15 + .35 * (.5 + .5 * Math.sin(t * 3 * b - i))); cx.fill(); cx.lineWidth = 2; cx.strokeStyle = C.hi; cx.globalAlpha = .9; cx.stroke(); cx.restore(); });
      },
      wave(t, b) {
        halo(220, 1);
        glowOn(8);
        const n = 84, amp = clamp(.18 + (b - 1) * .6, .12, 1);
        circ(86, 2, C.mid, .8); circ(176, 1.5, C.a2, .3);
        cx.lineCap = 'round'; cx.lineWidth = 4.2;
        for (let i = 0; i < n; i++) {
          const a = i / n * TAU + t * .05;
          const v = (Math.sin(i * .55 + t * 5 * b) + Math.sin(i * 1.3 - t * 3.1) * .7 + Math.sin(i * .21 + t * 1.7) * .6) / 2.3;
          const len = 10 + (.5 + .5 * v) * 78 * amp;
          cx.strokeStyle = i % 7 === 0 ? C.wh : C.a2; cx.globalAlpha = .5 + .5 * (len / 90);
          cx.beginPath(); cx.moveTo(Math.cos(a) * 96, Math.sin(a) * 96); cx.lineTo(Math.cos(a) * (96 + len), Math.sin(a) * (96 + len)); cx.stroke();
        }
        cx.globalAlpha = 1; cx.shadowBlur = 0; core(58, .8 + .22 * amp * (.5 + .5 * Math.sin(t * 6 * b)));
      },
      pulse(t, b) {
        halo(210, 1.3);
        const br = 1 + .08 * Math.sin(t * 2.4 * b);
        glowOn(14);
        circ(128 * br, 2.5, C.a2, .55); circ(148, 1.5, C.a, .35);
        arc(128, 5, 0, 1.2, t * 1.1, C.wh); arc(128, 5, Math.PI, 1.2, t * 1.1, C.wh);
        cx.shadowBlur = 0; core(70, br);
      },
      off(t) {
        halo(210, .8); glowOn(8);
        circ(170, 7, C.a, .95); circ(112, 4, C.hi, .8); circ(58, 3, C.a2, .9);
        cx.fillStyle = C.wh; cx.beginPath(); cx.arc(0, 0, 14, 0, TAU); cx.fill();
      }
    };
  }

  /* ================================================================== v8 arc reactor engine
     "core"  : glowing network sphere, FRIDAY emblem, counter-rotating ring stack, tilted orbits,
               light beam + hologram platform (stage mode), particles, voice reactions
     "logo"  : compact avatar reactor (Settings page, footer, small spots)
     Everything is drawn with plain 2D canvas paths - no shadowBlur loops, no images. */
  const GOLD = Math.PI * (3 - Math.sqrt(5));
  const GLOBE = (function () {
    const N = 76, p = [], e = [];
    for (let i = 0; i < N; i++) { const y = 1 - (i + .5) * 2 / N, r = Math.sqrt(1 - y * y), a = i * GOLD; p.push([Math.cos(a) * r, y, Math.sin(a) * r]); }
    for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) { const dx = p[i][0] - p[j][0], dy = p[i][1] - p[j][1], dz = p[i][2] - p[j][2]; if (dx * dx + dy * dy + dz * dz < .34) e.push([i, j]); }
    return { p, e };
  })();
  const LOGO_D = ['M50 5 L5 93 L31 93 L50 52 Z', 'M50 5 L95 93 L69 93 L50 52 Z', 'M39 93 L50 71 L61 93 Z', 'M73 11 L75 18 L82 20 L75 22 L73 29 L71 22 L64 20 L71 18 Z'];
  const LOGO = typeof root.Path2D === 'function' ? LOGO_D.map(d => new root.Path2D(d)) : null;
  const fract = v => v - Math.floor(v);

  function drawLogo(cx, s, C, al) {
    cx.save(); cx.globalAlpha = al == null ? 1 : al;
    if (!LOGO) { cx.beginPath(); cx.moveTo(0, -s / 2); cx.lineTo(s * .46, s / 2); cx.lineTo(-s * .46, s / 2); cx.closePath(); cx.lineWidth = 3; cx.strokeStyle = C.wh; cx.stroke(); cx.restore(); return; }
    cx.scale(s / 100, s / 100); cx.translate(-50, -50);
    const g1 = cx.createLinearGradient(5, 5, 50, 93); g1.addColorStop(0, C.wh); g1.addColorStop(1, C.a2);
    const g2 = cx.createLinearGradient(50, 5, 95, 93); g2.addColorStop(0, C.a2); g2.addColorStop(1, C.sec);
    cx.shadowColor = C.a; cx.shadowBlur = Math.max(4, s * .18);
    cx.fillStyle = g1; cx.fill(LOGO[0]); cx.fillStyle = g2; cx.fill(LOGO[1]); cx.fillStyle = C.a2; cx.fill(LOGO[2]); cx.fillStyle = C.wh; cx.fill(LOGO[3]);
    cx.restore();
  }

  /* ex = { state, lvl (0..1 voice activity), stage (draw beam+platform), top/bottom (design units to canvas edge), pop } */
  function makeCore(cx, C, rc, glow, ex) {
    const gl = glow / 100, Lt = !!C.L, MODE = Lt ? 'source-over' : 'lighter';
    const react = (rc.react == null ? 100 : rc.react) / 100;
    const circ = (R, w, col, al) => { cx.strokeStyle = col; cx.globalAlpha = al == null ? 1 : al; cx.lineWidth = w; cx.beginPath(); cx.arc(0, 0, R, 0, TAU); cx.stroke(); cx.globalAlpha = 1; };
    const glowCirc = (R, w, col, al) => { cx.globalCompositeOperation = MODE; for (let i = 3; i >= 1; i--) circ(R, w * (1 + i * 1.6), col, al * .09 * gl); cx.globalCompositeOperation = 'source-over'; circ(R, w, col, al); };
    const halo = (R, al, col) => { const g = cx.createRadialGradient(0, 0, R * .08, 0, 0, R); g.addColorStop(0, alpha(col || C.a, clamp(.34 * al * gl, 0, 1))); g.addColorStop(.55, alpha(col || C.a, clamp(.1 * al * gl, 0, 1))); g.addColorStop(1, alpha(col || C.a, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, R, 0, TAU); cx.fill(); };
    const ell = (x, y, rx, ry, rot, w, col, al) => { cx.strokeStyle = col; cx.globalAlpha = al; cx.lineWidth = w; cx.beginPath(); cx.ellipse(x, y, rx, ry, rot, 0, TAU); cx.stroke(); cx.globalAlpha = 1; };

    /* ---- one ring of the rotating stack ---- */
    function ringKind(kind, R, p, sp, col, al, n, w) {
      cx.save(); cx.rotate(sp); cx.strokeStyle = col; cx.fillStyle = col; cx.globalAlpha = al; cx.lineWidth = w; cx.lineCap = 'butt';
      if (kind === 'tick') {
        cx.beginPath(); for (let i = 0; i < n; i++) { const a = i / n * TAU, l = i % 6 ? p : p * 1.9; cx.moveTo(Math.cos(a) * R, Math.sin(a) * R); cx.lineTo(Math.cos(a) * (R - l), Math.sin(a) * (R - l)); } cx.lineWidth = Math.min(w, 1.8); cx.stroke();
      } else if (kind === 'dash') {
        const per = TAU * R, seg = per / n; cx.setLineDash([seg * .56, seg * .44]); cx.beginPath(); cx.arc(0, 0, R, 0, TAU); cx.stroke(); cx.setLineDash([]);
      } else if (kind === 'arc') {
        cx.lineCap = 'round'; for (let i = 0; i < n; i++) { const a = i / n * TAU; cx.beginPath(); cx.arc(0, 0, R, a, a + p); cx.stroke(); }
      } else if (kind === 'dot') {
        cx.beginPath(); for (let i = 0; i < n; i++) { const a = i / n * TAU; cx.moveTo(Math.cos(a) * R + w, Math.sin(a) * R); cx.arc(Math.cos(a) * R, Math.sin(a) * R, w, 0, TAU); } cx.fill();
      } else { cx.beginPath(); cx.arc(0, 0, R, 0, TAU); cx.stroke(); }
      cx.restore(); cx.globalAlpha = 1;
    }
    const RING_DEFS = [
      /* R,  kind,  param, speed, colour,  alpha, n,   width */
      [122, 'tick', 6, .55, C.a2, .8, 96, 1.4],
      [133, 'dash', 0, -.8, C.hi, .85, 16, 2.4],
      [147, 'arc', 1.25, .95, C.a2, .8, 3, 3],
      [161, 'dot', 0, -.3, C.a2, .85, 72, 1.3],
      [177, 'dash', 0, .42, C.sec, .85, 46, 1.9],
      [193, 'arc', .42, -.7, C.a2, .8, 5, 2.2],
      [210, 'tick', 4, .16, C.sec, .6, 150, 1.1],
      [228, 'circ', 0, 0, C.a, .35, 1, 1.2]
    ];
    function rings(t) {
      const n = clamp(Math.round(rc.rings == null ? 6 : rc.rings), 1, 8), style = rc.ringStyle || 'mixed', dm = rc.dir || 'alt';
      for (let i = 0; i < n; i++) {
        let [R, kind, p, sp, col, al, cnt, w] = RING_DEFS[i];
        if (style === 'ticks' && kind !== 'tick') { kind = 'tick'; cnt = Math.round(R * .6); p = 5; w = 1.4; }
        else if (style === 'dash' && kind !== 'dash') { kind = 'dash'; cnt = Math.round(R / 4); w = Math.max(1.6, w); }
        else if (style === 'solid' && kind !== 'arc') { kind = 'circ'; cnt = 1; w = Math.max(1.2, w * .6); }
        else if (style === 'dots' && kind !== 'dot') { kind = 'dot'; cnt = Math.round(R * .42); w = 1.4; }
        let dir = Math.sign(sp) || 1; if (dm === 'cw') dir = 1; else if (dm === 'ccw') dir = -1;
        ringKind(kind, R, p, dir * Math.abs(sp) * t * 1.25, col, al, cnt, w);
      }
    }

    /* ---- network sphere ---- */
    function globe(t, R) {
      const ga = t * .3, cy = Math.cos(ga), sy = Math.sin(ga), tx = .42, ct = Math.cos(tx), st = Math.sin(tx), N = GLOBE.p.length, P = new Array(N);
      for (let i = 0; i < N; i++) { const q = GLOBE.p[i], x1 = q[0] * cy + q[2] * sy, z1 = -q[0] * sy + q[2] * cy, y1 = q[1] * ct - z1 * st, z2 = q[1] * st + z1 * ct; P[i] = [x1 * R, y1 * R, z2]; }
      cx.lineWidth = 1; cx.lineCap = 'round';
      cx.beginPath(); GLOBE.e.forEach(([a, b]) => { if (P[a][2] + P[b][2] < 0) { cx.moveTo(P[a][0], P[a][1]); cx.lineTo(P[b][0], P[b][1]); } }); cx.strokeStyle = alpha(C.a2, .13); cx.stroke();
      cx.beginPath(); GLOBE.e.forEach(([a, b]) => { if (P[a][2] + P[b][2] >= 0) { cx.moveTo(P[a][0], P[a][1]); cx.lineTo(P[b][0], P[b][1]); } }); cx.strokeStyle = alpha(C.hi, .42); cx.stroke();
      cx.fillStyle = alpha(C.wh, .9); cx.beginPath(); for (let i = 0; i < N; i++) if (P[i][2] > 0) { cx.moveTo(P[i][0] + 1.4, P[i][1]); cx.arc(P[i][0], P[i][1], 1.4 + P[i][2] * .8, 0, TAU); } cx.fill();
      cx.fillStyle = alpha(C.a2, .35); cx.beginPath(); for (let i = 0; i < N; i++) if (P[i][2] <= 0) { cx.moveTo(P[i][0] + 1, P[i][1]); cx.arc(P[i][0], P[i][1], 1, 0, TAU); } cx.fill();
    }

    /* ---- orbit ellipses with satellites ---- */
    function orbits(t, lv) {
      const defs = [[196, 46, -.38, .9], [176, 38, .52, -1.2], [212, 30, 1.45, .7]];
      defs.forEach(([rx, ry, rot, sp], i) => {
        const r = rot + t * .05 * (i + 1) * (i % 2 ? -1 : 1);
        cx.globalCompositeOperation = MODE; ell(0, 0, rx, ry, r, 1.2, C.a2, .55); cx.globalCompositeOperation = 'source-over';
        for (let k = 0; k < 2; k++) {
          const a = t * sp * 1.4 + k * Math.PI, x = Math.cos(a) * rx, y = Math.sin(a) * ry, c = Math.cos(r), s = Math.sin(r), X = x * c - y * s, Y = x * s + y * c;
          const g = cx.createRadialGradient(X, Y, 0, X, Y, 9); g.addColorStop(0, alpha(C.wh, 1)); g.addColorStop(.35, alpha(C.a2, .8)); g.addColorStop(1, alpha(C.a, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(X, Y, 9, 0, TAU); cx.fill();
        }
      });
    }

    /* ---- sparkles drifting up around the beam ---- */
    function sparks(t, n) {
      const H = (ex.top || 380) + 190;
      for (let i = 0; i < n; i++) {
        const s1 = fract(Math.sin(i * 91.7 + 3.1) * 43758.5), s2 = fract(Math.sin(i * 12.9 + 7.7) * 24634.6), s3 = fract(Math.sin(i * 78.2 + 1.3) * 9234.2);
        const x = (s1 - .5) * 560 + Math.sin(t * .6 + i) * 8, y = 190 - fract(s2 + t * (.012 + s3 * .02) * 5) * H;
        const a = (.25 + .75 * (.5 + .5 * Math.sin(t * 3 + i * 1.7))) * (s3 > .72 ? 1 : .6);
        cx.fillStyle = s3 > .6 ? alpha(C.wh, a) : alpha(s3 > .3 ? C.a2 : C.sec, a);
        const r = .8 + s3 * 1.9; cx.beginPath(); cx.arc(x, y, r, 0, TAU); cx.fill();
      }
    }

    /* ---- stage extras: beam + hologram platform ---- */
    function beam(t, lv) {
      const top = -(ex.top || 400), bot = 142, fl = .88 + .12 * Math.sin(t * 9);
      cx.globalCompositeOperation = MODE;
      let g = cx.createLinearGradient(-78, 0, 78, 0); g.addColorStop(0, alpha(C.a, 0)); g.addColorStop(.5, alpha(C.a2, (.34 + lv * .14) * gl * fl)); g.addColorStop(1, alpha(C.a, 0));
      cx.fillStyle = g; cx.fillRect(-78, top, 156, bot - top);
      g = cx.createLinearGradient(0, top, 0, bot); g.addColorStop(0, alpha(C.a2, 0)); g.addColorStop(.18, alpha(C.a2, .55 * fl)); g.addColorStop(.7, alpha(C.wh, .95 * fl)); g.addColorStop(1, alpha(C.wh, .9));
      cx.fillStyle = g; const w = 2.4 + lv * 1.2; cx.fillRect(-w, top, w * 2, bot - top);
      cx.globalCompositeOperation = 'source-over';
    }
    function platform(t, lv) {
      const y0 = 142, rx0 = 250, q = .215;
      cx.save(); cx.translate(0, y0);
      cx.save(); cx.scale(1, q); let g = cx.createRadialGradient(0, 0, 8, 0, 0, rx0 * 1.3); g.addColorStop(0, alpha(C.a, (.6 + lv * .25) * gl)); g.addColorStop(.45, alpha(C.sec, .2 * gl)); g.addColorStop(1, alpha(C.a, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, rx0 * 1.3, 0, TAU); cx.fill(); cx.restore();
      const edge = (rx, dy, col, al, w) => { cx.save(); cx.translate(0, dy); cx.beginPath(); cx.ellipse(0, 0, rx, rx * q, 0, 0, TAU); cx.strokeStyle = col; cx.globalAlpha = al; cx.lineWidth = w; cx.stroke(); cx.restore(); };
      cx.fillStyle = alpha(C.dk, .55); cx.beginPath(); cx.ellipse(0, 10, rx0, rx0 * q, 0, 0, TAU); cx.fill();
      edge(rx0, 10, C.a, .5, 2); edge(rx0 * .985, 5, C.a2, .35, 1.2);
      cx.fillStyle = alpha(mix(C.dk, C.a, .25), .85); cx.beginPath(); cx.ellipse(0, 0, rx0 * .97, rx0 * .97 * q, 0, 0, TAU); cx.fill();
      const defs = [[.97, 'solid', 1.6, C.a2, .8, 0], [.9, 'dash', 3, C.hi, .85, 1], [.82, 'solid', 1.2, C.sec, .75, 0], [.74, 'dash', 4, C.sec, .85, -1], [.63, 'solid', 5, C.mag, .95, 0], [.53, 'dash', 2.4, C.a2, .9, 1], [.44, 'solid', 2, C.a, .9, 0], [.35, 'dash', 3.2, C.hi, .9, -1], [.26, 'solid', 2.4, C.a2, .85, 0], [.16, 'solid', 3.2, C.wh, .85, 0]];
      defs.forEach(([f, kind, w, col, al, dir], i) => {
        const rx = rx0 * f, ry = rx * q; cx.save();
        if (kind === 'dash') { const per = TAU * Math.sqrt((rx * rx + ry * ry) / 2), seg = per / (10 + i * 5); cx.setLineDash([seg * .62, seg * .38]); cx.lineDashOffset = -t * 30 * dir * (1 + lv); }
        if (f === .63) { cx.globalCompositeOperation = MODE; for (let k = 3; k >= 1; k--) { cx.beginPath(); cx.ellipse(0, 0, rx, ry, 0, 0, TAU); cx.strokeStyle = col; cx.globalAlpha = .1 * k * gl * (1 + lv * .6); cx.lineWidth = w + k * 5; cx.stroke(); } cx.globalCompositeOperation = 'source-over'; }
        cx.beginPath(); cx.ellipse(0, 0, rx, ry, 0, 0, TAU); cx.strokeStyle = col; cx.globalAlpha = al; cx.lineWidth = w; cx.stroke(); cx.restore();
      });
      cx.strokeStyle = alpha(C.a2, .5); cx.lineWidth = 1; cx.beginPath(); const ta = t * .1; for (let i = 0; i < 96; i++) { const a = ta + i / 96 * TAU, c = Math.cos(a), s = Math.sin(a); cx.moveTo(c * rx0 * .905, s * rx0 * q * .905); cx.lineTo(c * rx0 * .965, s * rx0 * q * .965); } cx.stroke();
      cx.globalCompositeOperation = MODE; g = cx.createRadialGradient(0, 0, 0, 0, 0, 90); g.addColorStop(0, alpha(C.wh, .6)); g.addColorStop(1, alpha(C.a, 0)); cx.save(); cx.scale(1, q * 1.6); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, 90, 0, TAU); cx.fill(); cx.restore(); cx.globalCompositeOperation = 'source-over';
      cx.restore();
    }

    /* ---- the sphere group ---- */
    function emblem(t, lv, S) {
      const kind = rc.emblem || 'logo';
      if (kind === 'none') return;
      if (kind === 'orb') { const r = 46 * (1 + .06 * Math.sin(t * 3) + lv * .1); const g = cx.createRadialGradient(0, 0, 0, 0, 0, r); g.addColorStop(0, Lt ? light(C.a, .3) : '#ffffff'); g.addColorStop(.3, alpha(C.wh, .95)); g.addColorStop(.7, alpha(C.a2, .8)); g.addColorStop(1, alpha(C.a, 0)); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, r, 0, TAU); cx.fill(); return; }
      if (kind === 'triangle') { cx.save(); cx.rotate(-t * .4); cx.beginPath(); for (let i = 0; i <= 3; i++) { const a = -Math.PI / 2 + i / 3 * TAU; i ? cx.lineTo(Math.cos(a) * 46, Math.sin(a) * 46) : cx.moveTo(Math.cos(a) * 46, Math.sin(a) * 46); } cx.closePath(); cx.lineWidth = 6; cx.lineJoin = 'round'; cx.strokeStyle = C.wh; cx.shadowColor = C.a; cx.shadowBlur = 12; cx.stroke(); cx.restore(); return; }
      cx.fillStyle = alpha(C.dk, .6); cx.beginPath(); cx.arc(0, 0, 52, 0, TAU); cx.fill();
      glowCirc(52, 2.6, C.a2, .95);
      ringKind('dash', 59, 0, -t * .5, C.hi, .55, 36, 1.4);
      drawLogo(cx, 66 * (1 + lv * .05), C, 1);
    }

    function sphere(t, b, lv) {
      const R = 108;
      cx.globalCompositeOperation = MODE;
      cx.save(); cx.beginPath(); cx.arc(0, 0, R, 0, TAU); cx.clip(); cx.globalCompositeOperation = 'source-over';
      let g = cx.createRadialGradient(0, -14, 12, 0, 0, R); g.addColorStop(0, alpha(mix(C.dk, '#000a2a', .5), .94)); g.addColorStop(.6, alpha(mix(C.a, C.dk, .72), .9)); g.addColorStop(1, alpha(mix(C.a, C.dk, .3), .9)); cx.fillStyle = g; cx.fillRect(-R, -R, R * 2, R * 2);
      if (rc.network !== false) globe(t, R - 5);
      cx.globalCompositeOperation = MODE;
      const g2 = cx.createRadialGradient(0, 0, R * .55, 0, 0, R); g2.addColorStop(0, alpha(C.a, 0)); g2.addColorStop(1, alpha(C.a2, (.55 + lv * .3) * gl)); cx.fillStyle = g2; cx.fillRect(-R, -R, R * 2, R * 2);
      cx.restore(); cx.globalCompositeOperation = 'source-over';
      glowCirc(R, 4.6, C.a2, .98); glowCirc(R + 9, 2.4, C.a, .75); circ(R + 16, 1, C.a2, .5);
      cx.save(); cx.globalCompositeOperation = MODE; ringKind('arc', R - 9, 1.6, t * 1.7, C.wh, .9, 2, 4); ringKind('arc', R - 22, 1, -t * 2.3, C.hi, .8, 2, 2.6); cx.restore();
      circ(R - 14, 1, C.a2, .3);
    }

    return {
      core(t, b) {
        const lv = ex.lvl * react, stage = ex.stage;
        if (stage) { if (rc.platform !== false) platform(t, lv); if (rc.beam !== false) beam(t, lv); }
        halo(330, 1.6 + lv * .6);
        if (rc.particles !== false) sparks(t, stage ? 46 : 14);
        cx.save(); const pop = ex.pop || 1; cx.scale(pop, pop);
        /* listening ripples */
        if (ex.state === 'listening' || ex.state === 'recognizing') for (let i = 0; i < 3; i++) { const p = fract(t * .3 + i / 3); circ(112 + p * 120, 2.2 * (1 - p) + .4, C.a2, (1 - p) * .5 * react); }
        rings(t);
        sphere(t, b, lv);
        if (rc.orbits !== false) orbits(t, lv);
        emblem(t, lv);
        /* recognising: bright scan sweep */
        if (ex.state === 'recognizing') { cx.save(); cx.globalCompositeOperation = MODE; ringKind('arc', 118, 1.1, t * 5, C.wh, .95, 1, 6); ringKind('arc', 118, .5, t * 5 + 2, C.a2, .7, 1, 3); cx.restore(); }
        /* speaking: circular spectrum */
        if (ex.lvl > .05 && (ex.state === 'speaking' || ex.state === 'thinking')) {
          const amp = ex.lvl * react; cx.save(); cx.globalCompositeOperation = MODE; cx.lineCap = 'round'; cx.lineWidth = 3;
          for (let i = 0; i < 72; i++) { const a = i / 72 * TAU + t * .05, v = (Math.sin(i * .6 + t * 6) + Math.sin(i * 1.7 - t * 4) * .7 + Math.sin(i * .23 + t * 2) * .5) / 2.2, len = 3 + (.5 + .5 * v) * 26 * amp; cx.strokeStyle = i % 6 === 0 ? C.wh : C.a2; cx.globalAlpha = .45 + .5 * (len / 30); cx.beginPath(); cx.moveTo(Math.cos(a) * 119, Math.sin(a) * 119); cx.lineTo(Math.cos(a) * (119 + len), Math.sin(a) * (119 + len)); cx.stroke(); }
          cx.restore(); cx.globalAlpha = 1;
        }
        cx.restore();
      },
      logo(t, b) {
        const lv = ex.lvl * react, pop = ex.pop || 1;
        halo(250, 1 + lv * .5);
        cx.save(); cx.scale(pop, pop);
        circ(158, 1.4, C.a2, .55); ringKind('tick', 156, 7, t * .25, C.a2, .75, 120, 1.4);
        ringKind('dash', 138, 0, -t * .5, C.sec, .7, 36, 2);
        cx.save(); cx.globalCompositeOperation = MODE; for (let k = 3; k >= 1; k--) ringKind('arc', 118, 1.45, t * .9, C.a, .1 * k * gl, 3, 10 + k * 5); cx.restore();
        ringKind('arc', 118, 1.45, t * .9, C.a2, .95, 3, 9); ringKind('arc', 118, 1.45, t * .9, C.wh, .8, 3, 3);
        circ(98, 1.5, C.a2, .6);
        let g = cx.createRadialGradient(0, -10, 6, 0, 0, 88); g.addColorStop(0, alpha(mix(C.dk, '#000a2a', .5), .96)); g.addColorStop(1, alpha(mix(C.a, C.dk, .5), .95)); cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, 88, 0, TAU); cx.fill();
        glowCirc(88, 3, C.a2, .95);
        if (lv > .05) for (let i = 0; i < 3; i++) { const p = fract(t * .35 + i / 3); circ(92 + p * 70, 2 * (1 - p), C.a2, (1 - p) * .5); }
        drawLogo(cx, 100 * (1 + lv * .06), C, 1);
        cx.restore();
      },
      stageFx(t, lv) { if (rc.platform !== false) platform(t, lv); if (rc.beam !== false) beam(t, lv); if (rc.particles !== false) sparks(t, 40); }
    };
  }

  const TYPES = [
    ['core', 'Arc Core', 'Network sphere, rotating ring stack, hologram base'],
    ['logo', 'Emblem', 'Compact avatar ring with the FRIDAY mark'],
    ['hud', 'Classic HUD', 'Layered rings and ticks'],
    ['stark', 'Stark Core', 'Chest-reactor coils and triangle'],
    ['orb', 'Orb', 'Glowing sphere with orbits'],
    ['rings', 'Gyro', 'Slim concentric gyroscope'],
    ['hex', 'Hex Grid', 'Hexagon rings and cells'],
    ['wave', 'Voice Wave', 'Circular audio spectrum'],
    ['pulse', 'Pulse', 'Minimal breathing ring'],
    ['off', 'Static', 'Still logo, zero animation']
  ];
  const TYPE_SCALE = { core: 540, logo: 360 };

  /* opts: scale (design size), getBoost(), getPop(), getState(), type (force a design), glow/speed (force), mini,
     stage (draw beam + platform), layout(canvas,w,h) -> {cx,cy,u,top,bottom} for the big Home stage */
  function reactor(canvas, opts) {
    opts = opts || {};
    const cx = canvas.getContext('2d');
    let t = 0, last = 0, stopped = false, lastKey = '', lvl = 0, hidden = false;
    function resize() { const r = canvas.getBoundingClientRect(), d = root.devicePixelRatio || 1; const w = Math.max(2, Math.round(r.width * d)), h = Math.max(2, Math.round(r.height * d)); if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; lastKey = ''; } }
    if (root.ResizeObserver) new root.ResizeObserver(resize).observe(canvas);
    resize();
    const ex = { state: 'idle', lvl: 0, stage: !!opts.stage, top: 380, bottom: 300, pop: 1 };
    const LEGACY_K = .62;
    function frame(now) {
      if (stopped) return;
      if (!canvas.isConnected) { stopped = true; return; }
      root.requestAnimationFrame(frame);
      if (root.document && root.document.hidden) { last = 0; return; }
      if (canvas.offsetParent === null && !root.__fridayWidget) { last = 0; return; }       /* not on screen: skip the drawing work */
      const rc = cfg.reactor;
      let type = opts.type || (root.__fridayWidget && cfg.widget.reactor !== 'same' ? cfg.widget.reactor : rc.type);
      if (!rc.show && !opts.type && !root.__fridayWidget && !opts.stage) type = 'off';
      const dt = last ? Math.min(.05, (now - last) / 1000) : .016; last = now;
      let boost = opts.getBoost ? opts.getBoost() : 1;
      if (T.previewBoost && T.previewBoost.until > Date.now() && !opts.mini) boost = T.previewBoost.v;
      const speed = (opts.speed != null ? opts.speed : rc.speed) / 100 * (cfg.anim ? 1 : .15);
      const still = type === 'off';
      if (!still) t += dt * 60 * .012 * boost * speed;
      let state = opts.getState ? opts.getState() : (boost >= 2 ? 'speaking' : boost >= 1.5 ? 'listening' : 'idle');
      if (T.previewBoost && T.previewBoost.until > Date.now() && !opts.mini) state = T.previewBoost.v >= 2 ? 'speaking' : T.previewBoost.v >= 1.5 ? 'listening' : 'idle';
      const target = state === 'speaking' ? 1 : state === 'recognizing' ? .8 : state === 'listening' ? .5 : state === 'thinking' ? .45 : 0;
      lvl += (target - lvl) * Math.min(1, dt * 5);
      const key = still ? [type, cfg.accent, rc.color, rc.custom, rc.glow, canvas.width, canvas.height, opts.stage].join() : '';
      if (still && key === lastKey && !opts.stage) return;
      lastKey = key;
      const W = canvas.width, H = canvas.height, d = root.devicePixelRatio || 1;
      cx.setTransform(1, 0, 0, 1, 0, 0); cx.clearRect(0, 0, W, H);
      const pop = opts.getPop ? opts.getPop() : 1;
      if (opts.layout) { const Ly = opts.layout(canvas, W / d, H / d); cx.translate(Ly.cx * d, Ly.cy * d); const s = Ly.u * d; cx.scale(s, s); ex.top = Ly.top; ex.bottom = Ly.bottom; }
      else { const sc = typeof opts.scale === 'function' ? opts.scale(type) : opts.scale; const s = Math.min(W, H) / (sc || TYPE_SCALE[type] || 440); cx.translate(W / 2, H / 2); cx.scale(s, s); }
      const C = reactorColors(rc), glow = opts.glow != null ? opts.glow : rc.glow;
      ex.state = state; ex.lvl = lvl; ex.pop = pop; ex.stage = !!opts.stage;
      cx.globalAlpha = 1; cx.shadowBlur = 0; cx.lineCap = 'butt';
      const b = clamp(boost, .5, 4);
      if (type === 'core' || type === 'logo') makeCore(cx, C, rc, glow, ex)[type](t, b);
      else {
        const D = makeDrawer(cx, C, glow);
        if (opts.stage) { makeCore(cx, C, rc, glow, ex).stageFx(t, lvl); cx.scale(LEGACY_K * pop, LEGACY_K * pop); }
        else cx.scale(pop, pop);
        (D[type] || D.hud)(t, b);
      }
      cx.shadowBlur = 0; cx.globalAlpha = 1; cx.globalCompositeOperation = 'source-over';
    }
    root.requestAnimationFrame(frame);
    return { stop() { stopped = true; }, resize };
  }

  /* ------------------------------------------------------------------ public api */
  const T = {
    DEF, FONTS, ADDR, PRESETS, ACCENTS, BGS, TYPES, TYPE_SCALE, drawLogo, LOGO_D,
    get cfg() { return cfg; },
    isLight, mix, light, dark, lum, apply, reactor, addr, addrWord, addrIsTitle, greeting, sendAddress,
    previewBoost: null,
    get(path) { return getPath(cfg, path); },
    set(path, val) { setPath(cfg, path, val); save(); apply(); if (path.indexOf('addr') === 0) sendAddress(); },
    patch(obj) { cfg = merge(cfg, obj); save(); apply(); sendAddress(); },
    preset(key) { const p = PRESETS[key]; if (!p) return; const keep = { addr: cfg.addr, assistant: cfg.assistant, widget: cfg.widget, layout: cfg.layout, zoom: cfg.zoom, profile: cfg.profile, home: cfg.home }; cfg = merge(DEF, Object.assign({}, p.p, keep)); save(); apply(); },
    profile() { const p = cfg.profile || {}, nm = (p.name || '').trim() || ((cfg.addr.mode === 'name' || cfg.addr.mode === 'custom') ? addrWord() : ''); return { name: nm, badge: p.badge || '', ask: (p.ask || '').trim() }; },
    reset() { cfg = clone(DEF); save(); apply(); sendAddress(); },
    exportJSON() { return JSON.stringify(cfg, null, 2); },
    importJSON(txt) { const o = JSON.parse(txt); cfg = merge(DEF, migrate(o)); save(); apply(); sendAddress(); },
    subscribe(f) { subs.push(f); },
    receive(txt) { try { const o = merge(DEF, migrate(JSON.parse(txt))); if (JSON.stringify(o) === JSON.stringify(cfg)) return; cfg = o; save(true); apply(); sendAddress(); } catch (e) { } }
  };
  root.Theme = T;

  /* ------------------------------------------------------------------ boot */
  function boot() {
    apply();
    if (root.matchMedia) { const mq = root.matchMedia('(prefers-color-scheme: light)'); const f = () => { if (cfg.mode === 'auto') apply(); }; mq.addEventListener ? mq.addEventListener('change', f) : mq.addListener && mq.addListener(f); }
    root.addEventListener('storage', e => { if (e.key === 'friday_ui' && e.newValue) T.receive(e.newValue); });
    if (B) {
      if (B.onUiConfig) B.onUiConfig(txt => T.receive(txt));
      if (B.uiLoad) B.uiLoad().then(txt => { if (txt) T.receive(txt); else B.uiSave && B.uiSave(JSON.stringify(cfg)); }).catch(() => { });
    }
  }
  if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', boot); else boot();
})(window);
