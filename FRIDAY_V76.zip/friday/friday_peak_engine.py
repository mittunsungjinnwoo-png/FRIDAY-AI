"""FRIDAY Peak Performance Layer.

This module is intentionally dependency-free and additive. It does not replace
existing FRIDAY routers, memory, voice, UI, study mode, browser automation,
screen intelligence, or TTS. It provides:
- per-turn latency and success telemetry
- lightweight intent confidence scoring
- duplicate-turn protection for accidental microphone/UI repeats
- safe action gating hints for consequential commands
- runtime capability/health snapshots

The layer is deliberately conservative: it never executes an action itself.
"""
from __future__ import annotations
import re, time, threading
from collections import deque, defaultdict
from functools import lru_cache
from typing import Any

_LOCK = threading.RLock()
_STARTED = time.monotonic()
_TURNS = deque(maxlen=200)
_CAPS = {}
_FAST_LANE_HITS = 0
_FAST_LANE_MISSES = 0
_LAST_COMMAND = ""
_LAST_COMMAND_AT = 0.0

_ACTION_WORDS = {
    "open","close","launch","start","stop","click","press","type","write",
    "delete","send","search","navigate","play","scroll","switch","shutdown",
    "restart","install","uninstall","move","rename","download","upload"
}
_HIGH_RISK = re.compile(r"\b(shutdown|restart|delete|uninstall|format|send|purchase|buy)\b", re.I)


@lru_cache(maxsize=256)
def normalize_fast_command(command: str) -> str:
    """Normalize repeated short UI/voice command text without touching routing."""
    return re.sub(r"\s+", " ", str(command or "").strip())


# Exact, side-effect-safe commands eligible for the latency fast lane.
# These are routed to the existing handlers; this layer never implements
# a second copy of the feature logic.
_FAST_LANE_PATTERNS = (
    re.compile(r"^(?:what(?:'s| is) the )?time\??$", re.I),
    re.compile(r"^(?:what(?:'s| is) )?today(?:'s)? date\??$", re.I),
    re.compile(r"^date\??$", re.I),
    re.compile(r"^(?:tell me )?a joke\??$", re.I),
    re.compile(r"^(?:who are you|what are you)\??$", re.I),
    re.compile(r"^help\??$", re.I),
    re.compile(r"^(?:open )?(?:google|youtube|gmail|chatgpt|spotify)\??$", re.I),
    # V4010 SPEED: common app launches are deterministic and can safely skip
    # the higher-level agent/gateway layers. This preserves handle_command()
    # as the single executor while removing avoidable routing latency.
    re.compile(r"^(?:open|launch|start)\s+(?:chrome|edge|firefox|discord|whatsapp|telegram|spotify|steam|notepad|calculator|calc|file explorer|settings)\??$", re.I),
    re.compile(r"^(?:minimize|restore|settings|stand by|standby|exit|quit)\??$", re.I),
)

def fast_lane_eligible(command: str) -> bool:
    text = normalize_fast_command(command)
    if not text or len(text) > 80:
        return False
    # Never fast-lane commands with destructive/external side effects.
    if _HIGH_RISK.search(text):
        return False
    return any(p.fullmatch(text) for p in _FAST_LANE_PATTERNS)

def record_fast_lane(hit: bool) -> None:
    global _FAST_LANE_HITS, _FAST_LANE_MISSES
    with _LOCK:
        if hit:
            _FAST_LANE_HITS += 1
        else:
            _FAST_LANE_MISSES += 1

def register_capabilities(**caps):
    with _LOCK:
        _CAPS.update({str(k): bool(v) for k,v in caps.items()})

def begin_turn(command: str) -> dict:
    global _LAST_COMMAND, _LAST_COMMAND_AT
    now = time.monotonic()
    text = re.sub(r"\s+", " ", str(command or "")).strip()
    with _LOCK:
        duplicate = bool(text and text.casefold() == _LAST_COMMAND.casefold()
                        and now - _LAST_COMMAND_AT < 1.6)
        _LAST_COMMAND, _LAST_COMMAND_AT = text, now
        words = set(re.findall(r"[a-zA-Z]+", text.casefold()))
        action_score = min(1.0, len(words & _ACTION_WORDS) / 2.0)
        risk = bool(_HIGH_RISK.search(text))
        rec = {"command": text, "started": now, "duplicate": duplicate,
               "action_score": action_score, "consequential": risk}
        _TURNS.append(rec)
        return rec

def finish_turn(ok: bool, started: float | None = None):
    elapsed = (time.monotonic() - started) * 1000 if started else 0.0
    with _LOCK:
        if _TURNS:
            _TURNS[-1]["ok"] = bool(ok)
            _TURNS[-1]["latency_ms"] = round(elapsed, 1)
        return round(elapsed, 1)

def should_ignore_duplicate(info: dict) -> bool:
    # Only suppress a very short accidental repeat; long/repeated commands
    # remain executable because intentional repetition is valid.
    return bool(info.get("duplicate") and len(info.get("command","")) <= 80)

def health_snapshot():
    with _LOCK:
        recent = list(_TURNS)
        completed = [x for x in recent if "ok" in x]
        success = sum(1 for x in completed if x["ok"])
        avg = (sum(x.get("latency_ms",0) for x in completed)/len(completed)
               if completed else 0.0)
        return {
            "peak_mode": True,
            "uptime_s": round(time.monotonic()-_STARTED,1),
            "turns": len(recent),
            "success_rate": round(success/len(completed),3) if completed else None,
            "avg_latency_ms": round(avg,1),
            "fast_lane_hits": _FAST_LANE_HITS,
            "fast_lane_misses": _FAST_LANE_MISSES,
            "capabilities": dict(_CAPS),
        }
