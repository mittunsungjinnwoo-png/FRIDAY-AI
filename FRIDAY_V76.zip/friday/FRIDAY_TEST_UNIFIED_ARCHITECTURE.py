"""
TEST_UNIFIED_ARCHITECTURE.py
-----------------------------
Self-contained, dependency-free test of every new module added for the
V3086 unified-architecture upgrade (see INTEGRATION_GUIDE_UNIFIED_ARCHITECTURE.md).

Run with:   python3 TEST_UNIFIED_ARCHITECTURE.py

It registers small STUB agents (no real screen/voice/network access)
so it runs identically on any machine, including this sandbox, and
exercises:

  1. friday_state_engine   - read/write/subscribe
  2. friday_task_graph     - goal/task creation, dependency gating, states
  3. friday_verifier_layer - all four verification levels
  4. friday_memory_layers  - should_remember, record, recall, sensitive-data rejection
  5. friday_perception     - graceful degradation with no hardware backends
  6. friday_executive+friday_supervisor - a full successful goal run
  7. the RETRY / DIAGNOSE / REPLAN path - an agent that fails twice then succeeds
  8. a PERMANENT FAILURE path - an agent that always fails, checking the
     structured (non-generic) failure explanation
  9. friday_proactive_monitor - relevance filtering + a full proactive run
 10. friday_unified_loop     - the whole PERCEIVE..RESPOND cycle end to end

Exits with status 0 and prints "ALL TESTS PASSED" only if every check
succeeds; otherwise it prints which assertion failed and exits 1.
"""

from __future__ import annotations

import sys
import traceback

FAILURES: list[str] = []


def check(label: str, condition: bool) -> None:
    if condition:
        print(f"  [pass] {label}")
    else:
        print(f"  [FAIL] {label}")
        FAILURES.append(label)


def section(title: str) -> None:
    print(f"\n=== {title} ===")


def main() -> None:
    # ------------------------------------------------------------------
    section("1. friday_state_engine")
    import friday_state_engine as state
    state.reset()
    seen = []
    state.subscribe(lambda section_, value: seen.append(section_))
    state.update("environment", active_application="Chrome")
    check("update() persists a field", state.get("environment").get("active_application") == "Chrome")
    check("subscribe() fired", "environment" in seen)
    state.set_permission_tier("delete file", "high_impact")
    check("permission override honoured", state.permission_tier_for("delete file") == "high_impact")
    check("unset permission falls back to default", state.permission_tier_for("open app") == "ask")

    # ------------------------------------------------------------------
    section("2. friday_task_graph")
    import friday_task_graph as graph
    goal = graph.create_goal("test goal")
    t1 = graph.create_task(goal["id"], "step_one")
    t2 = graph.create_task(goal["id"], "step_two", dependencies=[t1["id"]])
    check("t2 not ready before t1 completes", t2["id"] not in [t["id"] for t in graph.ready_tasks(goal["id"])])
    graph.set_status(t1["id"], "RUNNING")
    graph.set_status(t1["id"], "COMPLETED")
    check("t2 becomes ready once t1 completes", t2["id"] in [t["id"] for t in graph.ready_tasks(goal["id"])])
    graph.set_status(t2["id"], "RUNNING")
    graph.set_status(t2["id"], "COMPLETED")
    check("goal auto-completes when all tasks complete", graph.goal_is_complete(goal["id"]))

    # ------------------------------------------------------------------
    section("3. friday_verifier_layer")
    import friday_verifier_layer as verifier
    import tempfile, os as _os
    tmp_path = tempfile.mktemp()
    with open(tmp_path, "w") as fh:
        fh.write("hello world")
    r = verifier.verify("mechanical_file", path=tmp_path)
    check("mechanical_file verifies an existing file", r["status"] == verifier.STATUS_VERIFIED)
    _os.remove(tmp_path)
    r_missing = verifier.verify("mechanical_file", path=tmp_path)
    check("mechanical_file reports unverified for a missing file", r_missing["status"] == verifier.STATUS_UNVERIFIED)

    r_sem = verifier.verify("semantic", requested="open chrome and search cats",
                             achieved_summary="opened chrome, searched for cats")
    check("semantic verify finds high keyword overlap -> verified", r_sem["status"] == verifier.STATUS_VERIFIED)

    r_know_agree = verifier.verify(
        "knowledge", claim="the sky is blue",
        sources=[{"name": "a", "supports": True}, {"name": "b", "supports": True}],
    )
    check("knowledge verify: unanimous sources -> verified", r_know_agree["status"] == verifier.STATUS_VERIFIED)
    r_know_conflict = verifier.verify(
        "knowledge", claim="x",
        sources=[{"name": "a", "supports": True}, {"name": "b", "supports": False}],
    )
    check("knowledge verify: split sources -> conflict", r_know_conflict["status"] == verifier.STATUS_CONFLICT)

    r_goal_ok = verifier.verify_goal("g", [{"status": verifier.STATUS_VERIFIED, "confidence": 0.9}])
    check("goal verify: all sub-results verified -> verified", r_goal_ok["status"] == verifier.STATUS_VERIFIED)
    r_goal_bad = verifier.verify_goal("g", [{"status": verifier.STATUS_UNVERIFIED, "confidence": 0.2}])
    check("goal verify: a failed sub-result -> unverified", r_goal_bad["status"] == verifier.STATUS_UNVERIFIED)

    # ------------------------------------------------------------------
    section("4. friday_memory_layers")
    import friday_memory_layers as memory
    ok, score = memory.should_remember("my password is hunter2")
    check("secrets are never worth remembering", ok is False and score == 0.0)
    rec = memory.record("semantic", "The user's favourite colour is teal.", importance=0.9)
    check("high-importance content is stored", rec is not None)
    trivial = memory.record("working", "ok")
    recalled = memory.recall("semantic", query="favourite colour", top_k=3)
    check("recall finds the stored fact by keyword", any("teal" in r["content"] for r in recalled))

    # ------------------------------------------------------------------
    section("5. friday_perception (no hardware backends present)")
    import friday_perception as perception
    screen = perception.see_screen()
    system = perception.inspect_system()
    check("see_screen() never raises and returns a dict", isinstance(screen, dict))
    check("inspect_system() always reports available", system.get("available") is True)
    missing_file = perception.inspect_file("/definitely/does/not/exist.txt")
    check("inspect_file() reports exists=False for a missing file, no exception", missing_file["exists"] is False)

    # ------------------------------------------------------------------
    section("6. friday_executive + friday_supervisor: happy path")
    import friday_supervisor as supervisor
    import friday_executive as executive

    def stub_action_agent(task):
        return {"summary": f"performed {task['action']}", "method": "stub_action"}

    def stub_knowledge_agent(task):
        return {"summary": f"understood {task['action']}", "method": "stub_knowledge"}

    def stub_creation_agent(task):
        return {"summary": f"created output for {task['action']}", "method": "stub_creation"}

    supervisor.register_agent("action", "stub_action", stub_action_agent)
    supervisor.register_agent("knowledge", "stub_knowledge", stub_knowledge_agent)
    supervisor.register_agent("creation", "stub_creation", stub_creation_agent)

    result = supervisor.run_goal(
        "open notepad and take a note",
        plan_override=[
            {"action": "open notepad", "agent_group": "action", "agent_name": "stub_action", "verification_level": "semantic"},
            {"action": "take a note", "agent_group": "creation", "agent_name": "stub_creation", "verification_level": "semantic"},
        ]
    )
    check("happy-path goal completes", result["status"] == "COMPLETED")
    check("happy-path goal has non-trivial confidence", result["confidence"] > 0.0)
    check("happy-path explanation mentions completion", "completed" in result["explanation"].lower())

    # ------------------------------------------------------------------
    section("7. RETRY / DIAGNOSE / REPLAN path (fails twice, then succeeds)")
    attempt_counter = {"n": 0}

    def flaky_agent(task):
        attempt_counter["n"] += 1
        if attempt_counter["n"] < 3:
            return {"error": f"simulated transient failure #{attempt_counter['n']}", "method": "flaky"}
        return {"summary": "finally worked", "method": "flaky", "verified": True, "verification": {"method": "stub proof"}}

    supervisor.register_agent("action", "flaky", flaky_agent)
    flaky_goal = executive.plan(
        "trigger flaky path",
        plan_override=[{"action": "do_flaky_thing", "agent_group": "action", "agent_name": "flaky",
                         "verification_level": "mechanical_action"}],
    )
    flaky_result = executive.execute_goal(
        flaky_goal["id"],
        dispatch=lambda t: supervisor.dispatch_task(t),
    )
    check("flaky task eventually completes after retries", flaky_result["status"] == "COMPLETED")
    check("flaky agent was actually called more than once", attempt_counter["n"] >= 2)

    # ------------------------------------------------------------------
    section("8. PERMANENT FAILURE path with structured explanation")

    def always_fails_agent(task):
        return {"error": "the target window could not be found", "method": "always_fails"}

    supervisor.register_agent("action", "always_fails", always_fails_agent)
    fail_goal = executive.plan(
        "trigger permanent failure",
        plan_override=[{"action": "do_impossible_thing", "agent_group": "action", "agent_name": "always_fails",
                         "verification_level": "semantic"}],
    )
    fail_result = executive.execute_goal(fail_goal["id"], dispatch=lambda t: supervisor.dispatch_task(t))
    check("permanently failing task ends FAILED, not COMPLETED", fail_result["status"] == "FAILED")
    check("failure explanation is specific, not just 'something went wrong'",
          "window could not be found" in fail_result["explanation"])

    # ------------------------------------------------------------------
    section("9. friday_proactive_monitor")
    import friday_proactive_monitor as proactive
    irrelevant = proactive.emit({"type": "random_noise", "description": "nothing important"})
    check("irrelevant event is not acted on", irrelevant["acted"] is False)

    proactive_report = proactive.on_download_complete("quarterly_report.pdf")
    check("download-complete event is acted on", proactive_report["acted"] is True)

    def deny_everything(question: str) -> bool:
        return False

    supervisor.register_agent("action", "risky", lambda t: {"summary": "deleted stuff", "method": "risky"})
    high_impact_report = proactive.emit(
        {"type": "download_complete", "description": "please delete the temp folder now",
         "goal_text": "delete the temp folder"},
        ask_user=deny_everything,
    )
    # The first task's action text ("delete the temp folder") should classify
    # HIGH_IMPACT and, with ask_user always denying, the task should fail
    # to execute rather than silently deleting anything.
    blocked = any(
        tr.get("status") != verifier.STATUS_VERIFIED
        for tr in high_impact_report.get("result", {}).get("task_results", [])
    )
    check("high-impact proactive action is blocked when ask_user denies it", blocked)

    # ------------------------------------------------------------------
    section("10. friday_unified_loop end-to-end")
    import friday_unified_loop as loop
    cycle = loop.run_cycle(
        command="open notepad and take a note",
        plan_override=[{"action": "open notepad", "agent_group": "action", "agent_name": "stub_action", "verification_level": "semantic"},
                       {"action": "take a note", "agent_group": "creation", "agent_name": "stub_creation", "verification_level": "semantic"}]
    )
    check("unified loop cycle succeeds for a normal command", cycle["success"] is True)
    check("unified loop returns a spoken/displayable summary", isinstance(cycle["summary"], str) and len(cycle["summary"]) > 0)

    health = loop.health()
    check("health() reports registered agents", len(health["registered_agents"].get("action", [])) > 0)

    # ------------------------------------------------------------------
    print()
    if FAILURES:
        print(f"FAILED: {len(FAILURES)} check(s) did not pass:")
        for f in FAILURES:
            print(f"  - {f}")
        sys.exit(1)
    print("ALL TESTS PASSED")
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("UNCAUGHT EXCEPTION DURING TESTS:")
        traceback.print_exc()
        sys.exit(1)
