# FRIDAY V2.3.0 - Vision setup (5 minutes)

## 1. Install (once)
1. Close FRIDAY. Replace your FRIDAY folder with this one (your `friday_data` folder and saved settings are not touched).
2. Open a terminal in the FRIDAY folder and run (use the same Python FRIDAY uses):
   `pip install -r requirements.txt`
   or just start FRIDAY and press **Settings > Vision > Install OpenCV / Upgrade to OpenCV 5**, then restart FRIDAY.
3. (Optional but recommended) Install **Tesseract OCR** (free, "UB-Mannheim" Windows build). FRIDAY finds it automatically; this lets her read text and spot error messages on screen. Without it, verification still uses the window title and visual change.

## 2. Try it (say or type)
- "turn on the camera" / "what do you see through the camera" / "turn off the camera"
- "is there an error on my screen" / "find the Save button on my screen" / "what changed on my screen"
- "turn on screen vision" then "is anything moving"
- attach a picture or video with the paperclip, then "analyse this image" (or "analyse this video")
- "agent: open my chemistry notes" or "open notepad and make sure it opened" - she plans, acts, checks the screen, retries another way if it failed, and tells you honestly if it did not work
- say "yes" / "no" when she asks permission; red actions need "confirm"
- "stop the agent", "run the vision benchmark", "export the evaluation report", "how well are you performing"
The same things are on the new **Vision** page in the sidebar.

## 3. Settings > Vision (everything is a field, no code editing)
Camera number and auto-off, monitor, privacy switches (camera/screenshots to Gemini), detector (optional ONNX model file or download link), sensitivity,
OCR language/path, agent options, safety levels, and the optional cloud server (URL + **access token, stored in Windows secure storage**).
Your Gemini key and model stay in **Settings > AI** exactly as before.

## 4. Keys and things you may need to provide
| Item | Needed? | Where |
|---|---|---|
| Gemini API key | Already set up. Needed for Gemini planning, second opinions and picture descriptions. Without it the agent uses built-in rules and OpenCV-only descriptions | Settings > AI |
| ONNX detector model (e.g. YOLO) | Optional - only for NAMED objects (phone, laptop, cup). Works without it (shapes/colours, faces, people) | Settings > Vision > Object detector |
| Tesseract OCR | Recommended | install, or Settings > Vision > path |
| AWS server + token | Optional - only for the AWS/COOL part | Settings > Vision > Cloud (see cloud/deploy_graviton.md) |

## 5. Privacy defaults
Camera is off until you ask and switches itself off after 15 minutes. Camera pictures never leave your PC unless you tick the box. Screenshots go to Gemini only for visual questions, and you can switch that off.
