# FRIDAY 6.0.1 - no phantom voice, microphone starts by itself, Settings that respond

## What you reported
1. FRIDAY answered "somebody" when you had said nothing.
2. Right after the app opened, the Settings page (and other buttons) did nothing when pressed.
3. The microphone had to be turned on by hand even though the screen said "Listening".

## 1. Phantom voice (friday_voice5.py, friday_backend.py)
Causes found: room noise, clicks and fan hum were passed to the speech recogniser, which "hears" words in noise
(it often repeats its own hint list: "Friday, open, close..."); FRIDAY's own speech was picked up by the mic and
answered as if someone had spoken; and once awake she listened forever.

Fixes (every one has to pass before a sound becomes a command):
- Stricter speech detection: needs a clearly voiced start (5 of 8 frames, 7 of 8 while she is speaking), a minimum
  loudness over the noise floor, a minimum voiced ratio, and a minimum length of 220 ms.
- Hallucination filter: drops sound descriptions "[music]", non-Latin gibberish, repeated phrases, and any text that
  is just the recogniser's own hint list.
- Echo guard: remembers the last things FRIDAY said (90 s) and drops anything that sounds like them; short fragments
  while she is speaking are ignored unless they start with "Friday" or are a stop word.
- Wake word: standby needs "Friday" at the START of a sentence (so "on Friday we are going out" no longer wakes her);
  a bare "Friday" must also be loud and long enough. "Freddy" is no longer treated as "Friday".
- Conversation window: after you wake her she listens for follow-ups for 60 s, then returns to standby by herself.

## 2. Microphone is on by itself (friday_backend.py, index.html)
- The microphone engine opens at launch, before the greeting, and starts in the active state. No click needed.
- The status line says "Starting..." until the microphone is really open, then "Listening...". In standby it says
  `Listening for "Friday"...` (the mic is open in standby too). If the mic cannot open it says "Microphone unavailable"
  instead of pretending. A failsafe asks the engine to start listening 8 s after launch if it has not confirmed.
- The status no longer sticks on "Recognizing..." when a sound is dropped.

## 3. UI and Settings (index.html, friday_chat5.js, friday_settings.js, friday_v6_ui.js, main.js, preload.js)
- Root cause of "buttons do nothing": every time the Settings page drew itself it asked the engine for its status, and
  the answer made the page draw itself again - a loop that rebuilt the page under your mouse. Now the answer refreshes
  only the permissions block, and background updates (saved data, backend state) never rebuild Home, Settings or a page
  you are typing in.
- The FRIDAY 6.0 tool permissions now sit in Settings > General (they used to be stuck under every tab).
- New Settings > Voice tab: sensitivity (Relaxed / Normal / Strict), conversation window (30 s / 1 min / 5 min /
  always listening), wake rule (sentence start / anywhere), and "let me talk over her". Saved on this PC and sent to the
  engine at every start.
- Sliders no longer jump back while you drag them (the saved look was being echoed back to the window that saved it).
- Standby button no longer wakes itself with the same click; the Chat button highlights when selected.
- Vision / AI tabs re-load themselves once the engine finishes starting.

## Knobs (environment variables, optional)
- `FRIDAY_ACTIVE_WINDOW_S` (default 60; 0 = never time out)
- `FRIDAY_MIC_SENSITIVITY` (relaxed / normal / strict)
- `FRIDAY_WAKE_ANYWHERE` (1 = wake word allowed anywhere in a sentence)

## Tests
- `FRIDAY_TEST_V601_NO_PHANTOM_VOICE.py` (new, 33 checks) and `FRIDAY_TEST_V5_VOICE.py` pass.
- Headless browser click-through of every page and Settings tab with a simulated backend: Settings rebuilds 0, clicks 20/20.

## Honest limits
Tested with a simulated microphone and a simulated Electron bridge in a Linux container. It was NOT run with a real
microphone, speakers or the Windows Electron app. If she still reacts to a noisy room, choose Settings > Voice > Strict.
