"""FRIDAY 6.0 productivity and personal management (blueprint section 10).

Local, private and approval-based: calendar, deadlines, daily briefing, project dashboard, meeting prep and notes, email drafting
(opens your mail app - nothing is sent without you), contacts (only what you add), time tracking, searchable activity history,
workflow macros, weekly summary, download organisation (preview first, move only after you approve) and travel itineraries.
Expenses and budgeting continue to use FRIDAY's finance engine ("income / expense / goal / show reports").
"""
from __future__ import annotations

import os
import re
import shutil
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS pr_events(id INTEGER PRIMARY KEY, title TEXT, start REAL, end REAL, place TEXT, notes TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS pr_contacts(id INTEGER PRIMARY KEY, name TEXT UNIQUE, email TEXT, phone TEXT, note TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS pr_time(id INTEGER PRIMARY KEY, label TEXT, start REAL, end REAL);
CREATE TABLE IF NOT EXISTS pr_notes(id INTEGER PRIMARY KEY, meeting TEXT, ts REAL, kind TEXT, text TEXT);
CREATE TABLE IF NOT EXISTS pr_activity(id INTEGER PRIMARY KEY, ts REAL, kind TEXT, text TEXT);
CREATE TABLE IF NOT EXISTS pr_macros(name TEXT PRIMARY KEY, steps TEXT, ts REAL);
""")


def log_activity(kind: str, text: str):
    try:
        C.x("INSERT INTO pr_activity(ts,kind,text) VALUES(?,?,?)", (C.now(), kind, C.clip(C.redact(text), 200)))
    except Exception:
        pass


# ------------------------------------------------------------------ calendar
def add_event(title: str, start: float, minutes: int = 60, place: str = "", notes: str = "") -> int:
    log_activity("calendar", f"added {title}")
    return C.x("INSERT INTO pr_events(title,start,end,place,notes,ts) VALUES(?,?,?,?,?,?)", (C.clip(title, 120), start, start + minutes * 60, place, notes, C.now()))


def events(frm: Optional[float] = None, to: Optional[float] = None) -> List[Dict]:
    frm = frm if frm is not None else C.now() - 3600
    to = to if to is not None else frm + 7 * 86400
    return [dict(r) for r in C.q("SELECT * FROM pr_events WHERE start>=? AND start<? ORDER BY start", (frm, to))]


def conflicts(start: float, end: float) -> List[Dict]:
    return [dict(r) for r in C.q("SELECT * FROM pr_events WHERE start<? AND end>?", (end, start))]


def _day_bounds(d: datetime):
    a = d.replace(hour=0, minute=0, second=0, microsecond=0)
    return a.timestamp(), (a + timedelta(days=1)).timestamp()


def daily_briefing() -> str:
    """Today's schedule, reminders due, deadlines and open tasks."""
    import friday_memory6 as M, friday_tasks6 as T
    a, b = _day_bounds(datetime.now())
    ev = events(a, b)
    try:
        import friday_chat_access as _ca
        st = _ca._state_snapshot()
        today = datetime.now().strftime("%Y-%m-%d")
        for c in (st.get("cal") or []):
            if isinstance(c, dict) and c.get("d") == today and not c.get("done") and not any(C.similarity(str(c.get("n")), e["title"]) > 0.8 for e in ev):
                h, _, mi = str(c.get("t", "09:00")).partition(":")
                ev.append({"title": str(c.get("n")), "start": datetime.now().replace(hour=int(h or 9), minute=int(mi or 0) if mi.isdigit() else 0, second=0, microsecond=0).timestamp()})
        ev.sort(key=lambda e: e["start"])
    except Exception:
        pass
    rem = [r for r in M.list_reminders() if r["due"] < b]
    dl = T.deadlines_due(48)
    q = T.queue()
    parts = [f"Good {'morning' if datetime.now().hour < 12 else ('afternoon' if datetime.now().hour < 18 else 'evening')}, {C.address()}."]
    parts.append(("Today: " + "; ".join(f"{e['title']} at {datetime.fromtimestamp(e['start']).strftime('%H:%M')}" for e in ev[:5]) + ".") if ev else "Nothing on your calendar today.")
    if rem:
        parts.append("Reminders: " + "; ".join(r["text"] for r in rem[:4]) + ".")
    if dl:
        parts.append("Deadlines soon: " + "; ".join(f"{d['goal'][:40]} by {C.iso(d['deadline'])}" for d in dl[:3]) + ".")
    if q:
        parts.append(f"{len(q)} task{'s' if len(q) != 1 else ''} in the queue.")
    return " ".join(parts)


def weekly_summary() -> str:
    since = C.now() - 7 * 86400
    t = C.q("SELECT status, COUNT(*) n FROM tasks6 WHERE created>=? GROUP BY status", (since,)) if C.q("SELECT name FROM sqlite_master WHERE name='tasks6'") else []
    act = C.q("SELECT kind, COUNT(*) n FROM pr_activity WHERE ts>=? GROUP BY kind ORDER BY n DESC", (since,))
    secs = sum((r["end"] or C.now()) - r["start"] for r in C.q("SELECT * FROM pr_time WHERE start>=?", (since,)))
    done = sum(r["n"] for r in t if r["status"] == "done")
    open_ = sum(r["n"] for r in t if r["status"] in ("queued", "running", "partial", "interrupted"))
    return (f"This week: {done} task{'s' if done != 1 else ''} completed, {open_} still open. " + (f"Logged {secs / 3600:.1f} hours of tracked time. " if secs else "")
            + ("Activity: " + ", ".join(f"{r['n']} {r['kind']}" for r in act[:4]) + "." if act else "No other activity recorded."))


# ------------------------------------------------------------------ email drafting (never sent automatically)
def draft_email(to: str, subject: str, body: str, open_client: bool = False) -> Dict:
    from urllib.parse import quote
    link = f"mailto:{quote(to)}?subject={quote(subject)}&body={quote(body)}"
    if open_client:
        try:
            import webbrowser
            webbrowser.open(link)
        except Exception:
            pass
    log_activity("email", f"drafted to {to}: {subject}")
    return {"to": to, "subject": subject, "body": body, "mailto": link}


# ------------------------------------------------------------------ contacts / time / macros
def add_contact(name: str, email: str = "", phone: str = "", note: str = ""):
    C.x("INSERT INTO pr_contacts(name,email,phone,note,ts) VALUES(?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET email=COALESCE(NULLIF(excluded.email,''),email), phone=COALESCE(NULLIF(excluded.phone,''),phone), note=COALESCE(NULLIF(excluded.note,''),note)",
        (name.strip().title(), email, phone, note, C.now()))


def find_contact(name: str) -> Optional[Dict]:
    r = C.q("SELECT * FROM pr_contacts WHERE lower(name) LIKE ?", (f"%{name.strip().lower()}%",))
    return dict(r[0]) if r else None


def timer_start(label: str):
    timer_stop()
    C.x("INSERT INTO pr_time(label,start) VALUES(?,?)", (label, C.now()))


def timer_stop() -> Optional[Dict]:
    r = C.q("SELECT * FROM pr_time WHERE end IS NULL ORDER BY id DESC LIMIT 1")
    if not r:
        return None
    C.x("UPDATE pr_time SET end=? WHERE id=?", (C.now(), r[0]["id"]))
    return {"label": r[0]["label"], "minutes": round((C.now() - r[0]["start"]) / 60, 1)}


def time_report(days: int = 7) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for r in C.q("SELECT * FROM pr_time WHERE start>=?", (C.now() - days * 86400,)):
        out[r["label"]] = out.get(r["label"], 0) + ((r["end"] or C.now()) - r["start"]) / 3600
    return {k: round(v, 2) for k, v in out.items()}


def save_macro(name: str, steps: List[str]):
    C.x("INSERT INTO pr_macros(name,steps,ts) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET steps=excluded.steps, ts=excluded.ts", (name.lower().strip(), C.jdump(steps), C.now()))


def macro(name: str) -> List[str]:
    r = C.q("SELECT steps FROM pr_macros WHERE name=?", (name.lower().strip(),))
    return C.jload(r[0]["steps"], []) if r else []


def history_search(query: str, n: int = 8) -> List[Dict]:
    rows = [dict(r) for r in C.q("SELECT * FROM pr_activity ORDER BY ts DESC LIMIT 800")]
    sc = [(C.similarity(query, r["text"]) + (0.2 if query.lower() in r["text"].lower() else 0), r) for r in rows]
    return [r for s, r in sorted(sc, key=lambda x: -x[0])[:n] if s > 0.15]


# ------------------------------------------------------------------ document / download organisation (preview, then approve)
_KINDS = {"images": {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".heic", ".svg"}, "documents": {".pdf", ".docx", ".doc", ".txt", ".rtf", ".odt", ".md"},
          "spreadsheets": {".xlsx", ".xls", ".csv", ".ods"}, "presentations": {".pptx", ".ppt", ".odp"}, "archives": {".zip", ".rar", ".7z", ".tar", ".gz"},
          "installers": {".exe", ".msi", ".dmg", ".pkg", ".deb"}, "audio": {".mp3", ".wav", ".flac", ".m4a"}, "video": {".mp4", ".mkv", ".mov", ".avi", ".webm"}, "code": {".py", ".js", ".html", ".css", ".java", ".c", ".cpp", ".json"}}


def organise_preview(folder: str) -> Dict:
    p = Path(folder).expanduser()
    if not p.is_dir():
        return {"ok": False, "error": "that folder doesn't exist"}
    moves = []
    for f in p.iterdir():
        if f.is_file() and not f.name.startswith("."):
            kind = next((k for k, ex in _KINDS.items() if f.suffix.lower() in ex), "other")
            moves.append((str(f), str(p / kind.capitalize() / f.name)))
    return {"ok": True, "moves": moves, "folders": sorted({Path(d).parent.name for _, d in moves})}


def organise_apply(moves: List) -> Dict:
    done, log = 0, []
    for src, dst in moves:
        try:
            d = Path(dst)
            d.parent.mkdir(exist_ok=True)
            if d.exists():
                d = d.with_name(d.stem + "_" + time.strftime("%H%M%S") + d.suffix)
            shutil.move(src, str(d))
            log.append((str(d), src)); done += 1
        except Exception:
            pass
    C.x("INSERT INTO pr_activity(ts,kind,text) VALUES(?,?,?)", (C.now(), "organise", C.jdump(log)[:3000]))
    return {"moved": done, "undo": log}


def organise_undo() -> int:
    r = C.q("SELECT text FROM pr_activity WHERE kind='organise' ORDER BY id DESC LIMIT 1")
    n = 0
    for dst, src in (C.jload(r[0]["text"], []) if r else []):
        try:
            shutil.move(dst, src); n += 1
        except Exception:
            pass
    return n


_pending: Dict = {}
say = lambda text: None            # set by friday_core6 so a clash warning can be spoken before the calendar page confirms


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if re.match(r"^(?:daily briefing|morning briefing|brief me|what(?:'s| is) (?:on )?(?:my )?(?:day|schedule) (?:today|like)|what do i have today|my briefing)$", low):
        return daily_briefing()
    if re.match(r"^(?:weekly summary|summary of (?:my |the )?week|what did i (?:do|accomplish|achieve) this week)$", low):
        return weekly_summary()
    m = re.match(r"^(?:add|schedule|put|book|create) (?:an? )?(?:event|meeting|appointment|exam|class|session)?\s*(.+?)\s+(?:on|at|for|tomorrow|today|next|in)\b(.*)$", t, re.I)
    if m and re.search(r"\b(schedule|meeting|appointment|event|book|exam|class)\b", low) and not re.search(r"\b(calendar|agenda)\b", low) and not low.startswith("remind"):
        whole = m.group(1) + " " + low[len(m.group(1)):] if False else t
        when = C.parse_when(t)
        if when is None:
            return "When is it? Say, for example: schedule dentist tomorrow at 4 pm."
        title = re.sub(r"\b(?:add|schedule|put|book|create|to|in|on|my|the|calendar|event|meeting|appointment)\b|\b(?:tomorrow|today|next \w+|at \d{1,2}(?::\d\d)?\s*(?:am|pm)?|\d{1,2}(?::\d\d)?\s*(?:am|pm)|in \d+ \w+|on \w+day|20\d\d-\d\d-\d\d)\b", " ", t, flags=re.I)
        title = re.sub(r"\s+", " ", title).strip(" ,.") or "Event"
        c = conflicts(when, when + 3600)
        add_event(title, when)
        if c:
            say(f"Heads up, {C.address()}: that overlaps with {c[0]['title']}.")
        # mirror into FRIDAY's existing calendar page: the original calendar handler speaks the confirmation
        return "__REWRITE__" + t + " to my calendar"
    # "what's on my calendar" stays with FRIDAY's original calendar reader (it knows the calendar page)
    m = re.match(r"^(?:start|begin) (?:a )?timer (?:for|on)\s+(.+)$|^(?:track|log) time (?:on|for)\s+(.+)$", low)
    if m:
        timer_start(m.group(1) or m.group(2))
        return f"Timing {m.group(1) or m.group(2)}."
    if re.match(r"^(?:stop|end|finish) (?:the )?(?:timer|tracking)$", low):
        r = timer_stop()
        return f"Logged {r['minutes']} minutes on {r['label']}." if r else "No timer is running."
    if re.match(r"^(?:time report|where did my time go|time spent)$", low):
        r = time_report()
        return "No time tracked this week." if not r else "This week: " + ", ".join(f"{k} {v} hours" for k, v in sorted(r.items(), key=lambda kv: -kv[1])[:5]) + "."
    m = re.match(r"^(?:add|save) contact ([\w ]+?)(?: (?:email|e-mail) ([\w\.\-+]+@[\w\.\-]+))?(?: (?:phone|number) ([\d\+\- ]{6,}))?$", t, re.I)
    if m:
        add_contact(m.group(1), m.group(2) or "", m.group(3) or "")
        return f"Saved {m.group(1).title()} to your contacts."
    m = re.match(r"^(?:what(?:'s| is)|find|look up|get) ([\w ]+?)(?:'s)? (?:email|phone|number|contact)(?: details)?$", low)
    if m:
        c = find_contact(m.group(1))
        return f"{c['name']}: " + ", ".join(x for x in (c["email"], c["phone"]) if x) + "." if c else f"I don't have {m.group(1)} in your contacts."
    m = re.match(r"^draft (?:an? )?(?:e-?mail|message) to ([\w\.\-+@ ]+?) (?:about|regarding|saying|asking)\s+(.+)$", t, re.I)
    if m:
        who, topic = m.group(1).strip(), m.group(2)
        c = find_contact(who)
        to = c["email"] if c and c["email"] else (who if "@" in who else "")
        body = C.llm(f"Write a short, polite email to {who} about: {topic}. Sign off with just my first name placeholder [Name]. No subject line.") if C._cfg.get("llm") else ""
        body = body or f"Hi {who.split('@')[0].title()},\n\nI wanted to get in touch about {topic}.\n\nKind regards,\n[Name]"
        d = draft_email(to, C.clip(topic, 60).capitalize(), body, open_client=True)
        return f"I've drafted the email and opened it in your mail app. Nothing is sent until you press send." + ("" if to else " I don't have an address for them, so add it in the To field.")
    m = re.match(r"^(?:prepare|prep) (?:for |me for )?(?:my |the )?(?:meeting|call)(?: with| about| on)? (.+)$", low)
    if m:
        import friday_memory6 as M
        mem = M.search(m.group(1), k=3)
        ev = [e for e in events() if C.similarity(m.group(1), e["title"]) > 0.2]
        out = "Meeting prep: " + (f"scheduled {C.iso(ev[0]['start'])}. " if ev else "")
        out += ("Relevant notes: " + " ".join(h["text"] + "." for h in mem) + " ") if mem else "I have no earlier notes on it. "
        return out + "Suggested agenda: goal of the meeting, open decisions, who does what by when."
    m = re.match(r"^(?:meeting note|note from (?:the )?meeting|action item|decision)[: ]+(.+)$", t, re.I)
    if m:
        kind = "action" if low.startswith("action") else ("decision" if low.startswith("decision") else "note")
        C.x("INSERT INTO pr_notes(meeting,ts,kind,text) VALUES(?,?,?,?)", ("latest", C.now(), kind, C.clip(m.group(1), 300)))
        log_activity("meeting", m.group(1))
        return f"Recorded the {kind}."
    if re.match(r"^(?:summari[sz]e|read back) (?:the |my )?meeting(?: notes)?$", low):
        rows = C.q("SELECT kind,text FROM pr_notes ORDER BY ts DESC LIMIT 12")
        return "No meeting notes yet." if not rows else "From the meeting: " + " ".join(f"{r['kind'].capitalize()}: {r['text']}." for r in rows[::-1])
    m = re.match(r"^(?:save|record|create) (?:a )?(?:workflow|macro|routine) (?:called |named )?([\w ]+?)\s*(?::|\bthat\b|\bto\b)\s*(.+)$", t, re.I)
    if m:
        save_macro(m.group(1), [s.strip() for s in re.split(r"\s*(?:,? then|;|\band then\b)\s*", m.group(2)) if s.strip()])
        return f"Saved the {m.group(1)} routine with {len(macro(m.group(1)))} steps."
    m = re.match(r"^(?:run|do|start) (?:the )?(?:workflow|macro|routine) ([\w ]+)$", low)
    if m:
        st = macro(m.group(1))
        return ("__MACRO__" + "\n".join(st)) if st else f"I don't have a routine called {m.group(1)}."
    m = re.match(r"^(?:search|find in) (?:my )?(?:activity|history)(?: for| about)? (.+)$|^what did i (?:do|ask) (?:about|with|regarding) (.+)$", low)
    if m:
        h = history_search(m.group(1) or m.group(2))
        return "I found nothing in your activity history." if not h else "From your history: " + "; ".join(f"{C.iso(r['ts'])} {r['kind']}: {r['text']}" for r in h[:4]) + "."
    m = re.match(r"^(?:organi[sz]e|tidy|sort) (?:my )?(downloads|desktop|documents)(?: folder)?$|^(?:organi[sz]e|tidy|sort) (?:the )?folder (.+)$", low)
    if m:
        folder = m.group(2) or str(Path.home() / m.group(1).capitalize())
        r = organise_preview(folder)
        if not r["ok"] or not r["moves"]:
            return "There's nothing to organise there." if r["ok"] else "I can't find that folder."
        _pending["org"] = r["moves"]
        return f"I'd sort {len(r['moves'])} files into {', '.join(r['folders'][:6])}. Nothing moves until you say 'confirm organise'. 'undo organise' reverses it afterwards."
    if low == "confirm organise" and "org" in _pending:
        r = organise_apply(_pending.pop("org"))
        return f"Moved {r['moved']} files. Say 'undo organise' to put them back."
    if low == "undo organise":
        return f"Put {organise_undo()} files back."
    m = re.match(r"^(?:plan|build|make) (?:a |an )?(?:(\d+)[- ]day )?(?:trip|itinerary|travel plan)(?: (?:to|for|in))? (.+)$", low)
    if m:
        return "__MODEL__" + f"Plan a {m.group(1) or 3}-day itinerary for {m.group(2)}: day by day, sensible pacing, travel time between places, one rainy-day alternative, and an honest note that opening hours and prices must be checked before going."
    return None


def ui_snapshot() -> Dict:
    return {"briefing": daily_briefing(), "events": [{"title": e["title"], "when": C.iso(e["start"])} for e in events(C.now() - 3600, C.now() + 14 * 86400)[:10]],
            "time": time_report(), "contacts": [r["name"] for r in C.q("SELECT name FROM pr_contacts ORDER BY name LIMIT 20")], "macros": [r["name"] for r in C.q("SELECT name FROM pr_macros")]}
