"""FRIDAY 6.0 memory layer on top of the 5.0 knowledge base (friday_knowledge5 stays untouched).

Adds what the blueprint asks for beyond plain facts:
  * time-aware memory     every item has a date, kind, source, status (confirmed / assumed / superseded) and can be fetched by date or topic
  * semantic search       meaning-aware local search (stemming, synonym groups, trigram similarity) - no network, a few ms
  * memory reliability    duplicate detection, conflict resolution (newer confirmed fact supersedes older, both kept with dates)
  * importance scoring    from wording, repetition and recency
  * project continuity    per-project notes and "where did we leave off"
  * conversation summaries persisted per day
  * knowledge graph       people / concepts / projects / events and the relations between them
  * reminders & follow-ups   only created when the user asks (user-approved)
  * working memory        short-term scratchpad for the current task
  * control               inspect, export, correct, delete, retention, optional encrypted export (needs the `cryptography` package)
"""
from __future__ import annotations

import json
import os
import re
import time
from typing import Dict, List, Optional

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS mem6(id INTEGER PRIMARY KEY, ts REAL, kind TEXT, text TEXT, subject TEXT, source TEXT, status TEXT DEFAULT 'confirmed',
    importance REAL, hits INTEGER DEFAULT 0, last_hit REAL, fp TEXT, replaces INTEGER, project TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS mem6_fp ON mem6(fp);
CREATE TABLE IF NOT EXISTS graph_nodes(id INTEGER PRIMARY KEY, name TEXT UNIQUE, kind TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS graph_edges(id INTEGER PRIMARY KEY, a INTEGER, rel TEXT, b INTEGER, ts REAL, UNIQUE(a,rel,b));
CREATE TABLE IF NOT EXISTS reminders(id INTEGER PRIMARY KEY, ts REAL, due REAL, text TEXT, done INTEGER DEFAULT 0, fired INTEGER DEFAULT 0, repeat TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS summaries(day TEXT PRIMARY KEY, text TEXT, turns INTEGER);
CREATE TABLE IF NOT EXISTS project_notes(id INTEGER PRIMARY KEY, project TEXT, ts REAL, note TEXT, state TEXT DEFAULT 'open');
CREATE TABLE IF NOT EXISTS settings6(k TEXT PRIMARY KEY, v TEXT);
""")

KINDS = ("fact", "preference", "decision", "project", "event", "person", "goal", "lesson")
_working: Dict[str, str] = {}
_turns_today: List[str] = []


def _setting(k: str, default: str = "") -> str:
    r = C.q("SELECT v FROM settings6 WHERE k=?", (k,))
    return r[0]["v"] if r else default


def set_setting(k: str, v: str):
    C.x("INSERT INTO settings6(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))


# ------------------------------------------------------------------ importance + reliability
def importance(text: str, kind: str = "fact", repeated: int = 0) -> float:
    s = {"decision": 0.75, "goal": 0.8, "preference": 0.65, "project": 0.7, "person": 0.6, "lesson": 0.7, "event": 0.5, "fact": 0.5}.get(kind, 0.5)
    if re.search(r"\b(always|never|must|important|remember|deadline|allerg\w*|birthday|exam|password|critical|priority)\b", text, re.I):
        s += 0.15
    s += min(0.15, 0.05 * repeated)
    return round(min(1.0, s), 2)


def _subject(text: str) -> str:
    toks = C.tokens(text)
    return " ".join(toks[:3])


_NEG = re.compile(r"\b(not|no longer|never|don'?t|doesn'?t|isn'?t|stopped|quit|changed|instead|now)\b", re.I)


def add(text: str, kind: str = "fact", source: str = "user", status: str = "confirmed", project: str = "", ts: Optional[float] = None) -> Dict:
    """Store a memory. Returns {"id", "action": added|duplicate|superseded, ...}.  Secrets are never stored."""
    text = (text or "").strip()
    if not text or C.SECRET.search(text):
        return {"id": 0, "action": "refused", "why": "empty or looks like a secret"}
    kind = kind if kind in KINDS else "fact"
    fp = C.fingerprint(text)
    dup = C.q("SELECT id,hits FROM mem6 WHERE fp=? AND status!='superseded'", (fp,))
    if dup:
        C.x("UPDATE mem6 SET hits=hits+1, last_hit=?, importance=MIN(1.0, importance+0.03) WHERE id=?", (C.now(), dup[0]["id"]))
        return {"id": dup[0]["id"], "action": "duplicate"}
    subj = _subject(text)
    old_id = None
    # near-duplicate or conflicting statement about the same subject -> keep the newer one as current, mark the older superseded
    for r in C.q("SELECT id,text,status,source FROM mem6 WHERE kind=? AND status!='superseded' ORDER BY ts DESC LIMIT 400", (kind,)):
        sim = C.similarity(text, r["text"])
        if sim >= 0.86:
            C.x("UPDATE mem6 SET hits=hits+1, last_hit=? WHERE id=?", (C.now(), r["id"]))
            return {"id": r["id"], "action": "duplicate"}
        shared = len(set(C.tokens(text)) & set(C.tokens(r["text"])))
        changed = bool(_NEG.search(text)) and not _NEG.search(r["text"])
        if (sim >= 0.45 or (shared >= 2 and changed)) and (changed or kind in ("preference", "decision", "fact")) and r["source"] != "assumed":
            if status == "confirmed":
                old_id = r["id"]
                C.x("UPDATE mem6 SET status='superseded' WHERE id=?", (old_id,))
            break
    imp = importance(text, kind)
    mid = C.x("INSERT INTO mem6(ts,kind,text,subject,source,status,importance,last_hit,fp,replaces,project) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              (ts or C.now(), kind, C.clip(text, 600), subj, source, status, imp, C.now(), fp, old_id, project))
    try:
        link_text(text)
    except Exception:
        pass
    return {"id": mid, "action": "superseded" if old_id else "added", "replaced": old_id}


def search(query: str, k: int = 5, kinds: Optional[List[str]] = None, since: Optional[float] = None, until: Optional[float] = None,
           include_old: bool = False) -> List[Dict]:
    rows = C.q("SELECT * FROM mem6" + ("" if include_old else " WHERE status!='superseded'") + " ORDER BY ts DESC LIMIT 2000")
    out = []
    for r in rows:
        if kinds and r["kind"] not in kinds:
            continue
        if since and r["ts"] < since:
            continue
        if until and r["ts"] > until:
            continue
        sim = C.similarity(query, r["text"])
        if sim < 0.12:
            continue
        age_days = (C.now() - r["ts"]) / 86400
        score = sim * 1.0 + 0.2 * r["importance"] + 0.05 * min(5, r["hits"]) + max(0.0, 0.1 - age_days * 0.002)
        if r["status"] == "assumed":
            score -= 0.08
        out.append({"score": round(score, 4), **dict(r)})
    out.sort(key=lambda d: -d["score"])
    out = out[:k]
    for d in out:
        C.x("UPDATE mem6 SET hits=hits+1, last_hit=? WHERE id=?", (C.now(), d["id"]))
    return out


def by_date(day: str) -> List[Dict]:
    """Retrieve events by date: 'YYYY-MM-DD'."""
    from datetime import datetime, timedelta
    d0 = datetime.strptime(day, "%Y-%m-%d")
    return [dict(r) for r in C.q("SELECT * FROM mem6 WHERE ts>=? AND ts<? ORDER BY ts", (d0.timestamp(), (d0 + timedelta(days=1)).timestamp()))]


def context_for(question: str, k: int = 4) -> str:
    """Compact block for the model prompt: what is known, when, and how reliable it is (no invented memories)."""
    hits = search(question, k=k)
    if not hits:
        return ""
    lines = []
    for h in hits:
        tag = "" if h["status"] == "confirmed" else " (assumed, unconfirmed)"
        lines.append(f"- [{C.day(h['ts'])}] {h['text']}{tag}")
    return "\n\nWhat FRIDAY has on record (dated; trust confirmed items, treat 'assumed' as unverified, never invent memories):\n" + "\n".join(lines)


def correct(old_hint: str, new_text: str) -> str:
    hit = search(old_hint, k=1, include_old=False)
    if not hit:
        return "I couldn't find a memory like that to correct."
    C.x("UPDATE mem6 SET status='superseded' WHERE id=?", (hit[0]["id"],))
    r = add(new_text, hit[0]["kind"], "user-correction")
    return "Corrected. The earlier version is kept in history, marked as replaced."


def forget(hint: str) -> int:
    n = 0
    for h in search(hint, k=3, include_old=True):
        if h["score"] >= 0.3:
            C.x("DELETE FROM mem6 WHERE id=?", (h["id"],))
            n += 1
    return n


def forget_all() -> int:
    n = len(C.q("SELECT id FROM mem6"))
    for t in ("mem6", "graph_edges", "graph_nodes", "summaries", "project_notes"):
        C.x(f"DELETE FROM {t}")
    return n


def apply_retention(days: int) -> int:
    """Delete memories older than `days` unless importance >= 0.8 (kept) - user-configured retention."""
    cut = C.now() - days * 86400
    rows = C.q("SELECT id FROM mem6 WHERE ts<? AND importance<0.8", (cut,))
    for r in rows:
        C.x("DELETE FROM mem6 WHERE id=?", (r["id"],))
    return len(rows)


def export(path: str = "", encrypt: bool = False) -> str:
    data = {"version": C.VERSION, "exported": C.iso(), "memories": [dict(r) for r in C.q("SELECT * FROM mem6 ORDER BY ts")],
            "graph": graph_dump(), "reminders": [dict(r) for r in C.q("SELECT * FROM reminders")], "summaries": [dict(r) for r in C.q("SELECT * FROM summaries")]}
    raw = json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8")
    p = path or str(C.DATA_DIR / ("memory_export_" + time.strftime("%Y%m%d_%H%M%S") + (".enc" if encrypt else ".json")))
    if encrypt:
        raw = encrypt_bytes(raw)
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    with open(p, "wb") as f:
        f.write(raw)
    return p


def _key():
    from cryptography.fernet import Fernet
    kp = C.DATA_DIR / "memory.key"
    if not kp.exists():
        kp.parent.mkdir(parents=True, exist_ok=True)
        kp.write_bytes(Fernet.generate_key())
        try:
            os.chmod(kp, 0o600)
        except Exception:
            pass
    return Fernet(kp.read_bytes())


def encryption_available() -> bool:
    try:
        import cryptography  # noqa: F401
        return True
    except Exception:
        return False


def encrypt_bytes(b: bytes) -> bytes:
    if not encryption_available():
        raise RuntimeError("Encryption needs the 'cryptography' package (pip install cryptography).")
    return _key().encrypt(b)


def decrypt_bytes(b: bytes) -> bytes:
    return _key().decrypt(b)


# ------------------------------------------------------------------ knowledge graph
def _node(name: str, kind: str = "concept") -> int:
    name = name.strip()[:60]
    r = C.q("SELECT id FROM graph_nodes WHERE name=?", (name,))
    if r:
        return r[0]["id"]
    return C.x("INSERT INTO graph_nodes(name,kind,ts) VALUES(?,?,?)", (name, kind, C.now()))


def relate(a: str, rel: str, b: str, ka: str = "concept", kb: str = "concept"):
    ia, ib = _node(a, ka), _node(b, kb)
    try:
        C.x("INSERT OR IGNORE INTO graph_edges(a,rel,b,ts) VALUES(?,?,?,?)", (ia, rel.strip()[:40], ib, C.now()))
    except Exception:
        pass


_REL_PATTERNS = [
    (re.compile(r"\bmy (friend|brother|sister|mother|mom|father|dad|teacher|colleague|boss|cousin|wife|husband|partner)\s+([A-Z][a-z]+)", re.I), lambda m: (C.address() if False else "user", m.group(1).lower(), m.group(2).title(), "person", "person")),
    (re.compile(r"\b([A-Z][a-z]+) (?:is|was) (?:my )?(friend|brother|sister|teacher|colleague|boss|cousin)\b"), lambda m: ("user", m.group(2).lower(), m.group(1), "person", "person")),
    (re.compile(r"\b(?:i(?:'m| am) (?:working on|building|making)|working on)\s+(?:a |an |the |my )?([A-Za-z0-9 _\-]{3,30}?)(?:[.,;!]|\s+(?:with|for|using|and)\b|$)", re.I), lambda m: ("user", "works on", m.group(1).strip(), "person", "project")),
    (re.compile(r"\b([A-Za-z0-9_\-]{3,30}) (?:uses|depends on|is built (?:with|on)) ([A-Za-z0-9_\-\. ]{2,30}?)(?:[.,;!]|$)", re.I), lambda m: (m.group(1), "uses", m.group(2).strip(), "project", "concept")),
    (re.compile(r"\bi (?:live in|am from|study at|work at|go to)\s+([A-Z][A-Za-z ]{2,30})", re.I), lambda m: ("user", "linked to", m.group(1).strip(), "person", "place")),
]


def link_text(text: str) -> int:
    n = 0
    for pat, fn in _REL_PATTERNS:
        for m in pat.finditer(text):
            a, rel, b, ka, kb = fn(m)
            relate(a, rel, b, ka, kb)
            n += 1
    return n


def graph_dump() -> Dict:
    nodes = [dict(r) for r in C.q("SELECT id,name,kind FROM graph_nodes")]
    names = {n["id"]: n["name"] for n in nodes}
    edges = [{"a": names.get(r["a"]), "rel": r["rel"], "b": names.get(r["b"])} for r in C.q("SELECT a,rel,b FROM graph_edges")]
    return {"nodes": nodes, "edges": edges}


def neighbours(name: str) -> List[str]:
    r = C.q("SELECT id FROM graph_nodes WHERE lower(name)=lower(?)", (name,))
    if not r:
        return []
    i = r[0]["id"]
    out = []
    for e in C.q("SELECT n1.name an, e.rel rel, n2.name bn FROM graph_edges e JOIN graph_nodes n1 ON n1.id=e.a JOIN graph_nodes n2 ON n2.id=e.b WHERE e.a=? OR e.b=?", (i, i)):
        out.append(f"{e['an']} {e['rel']} {e['bn']}")
    return out


# ------------------------------------------------------------------ reminders (user-approved only)
def add_reminder(text: str, due: float, repeat: str = "") -> int:
    return C.x("INSERT INTO reminders(ts,due,text,repeat) VALUES(?,?,?,?)", (C.now(), due, C.clip(text, 200), repeat))


def due_reminders(mark: bool = True) -> List[Dict]:
    rows = [dict(r) for r in C.q("SELECT * FROM reminders WHERE done=0 AND fired=0 AND due<=?", (C.now(),))]
    if mark:
        for r in rows:
            if r["repeat"] == "daily":
                C.x("UPDATE reminders SET due=due+86400 WHERE id=?", (r["id"],))
            elif r["repeat"] == "weekly":
                C.x("UPDATE reminders SET due=due+604800 WHERE id=?", (r["id"],))
            else:
                C.x("UPDATE reminders SET fired=1 WHERE id=?", (r["id"],))
    return rows


def list_reminders() -> List[Dict]:
    return [dict(r) for r in C.q("SELECT * FROM reminders WHERE done=0 AND (fired=0 OR repeat!='') ORDER BY due")]


def complete_reminder(hint: str) -> bool:
    for r in list_reminders():
        if C.similarity(hint, r["text"]) > 0.3 or hint.lower() in r["text"].lower():
            C.x("UPDATE reminders SET done=1 WHERE id=?", (r["id"],))
            return True
    return False


# ------------------------------------------------------------------ projects + summaries + working memory
def project_note(project: str, note: str, state: str = "open") -> int:
    return C.x("INSERT INTO project_notes(project,ts,note,state) VALUES(?,?,?,?)", (project.strip().lower()[:60], C.now(), C.clip(note, 300), state))


def resume_project(project: str) -> str:
    rows = C.q("SELECT * FROM project_notes WHERE project LIKE ? ORDER BY ts DESC LIMIT 8", (f"%{project.strip().lower()}%",))
    if not rows:
        return ""
    open_items = [r["note"] for r in rows if r["state"] == "open"][:4]
    last = rows[0]
    out = f"Last note on {last['project']} was {C.day(last['ts'])}: {last['note']}."
    if open_items:
        out += " Still open: " + "; ".join(open_items) + "."
    return out


def work_set(k: str, v: str):
    _working[k] = C.clip(v, 300)


def work_get() -> Dict[str, str]:
    return dict(_working)


def work_clear():
    _working.clear()


def log_turn(user: str, answer: str):
    _turns_today.append(f"U: {C.clip(user, 120)} | F: {C.clip(answer, 120)}")
    del _turns_today[:-60]
    if len(_turns_today) % 10 == 0:
        save_summary()


def save_summary() -> str:
    if not _turns_today:
        return ""
    s = C.llm("Summarise this conversation in 3 short lines (what was asked, decisions made, open items):\n" + "\n".join(_turns_today[-30:])).strip() if C._cfg.get("llm") else ""
    if not s:
        s = " / ".join(t.split(" | ")[0][3:] for t in _turns_today[-6:])
    C.x("INSERT INTO summaries(day,text,turns) VALUES(?,?,?) ON CONFLICT(day) DO UPDATE SET text=excluded.text, turns=excluded.turns", (C.day(), C.clip(s, 800), len(_turns_today)))
    return s


# ------------------------------------------------------------------ extraction from normal conversation
_EXTRACT = [
    (re.compile(r"\bmy (?:favou?rite [a-z ]+|name|birthday|goal|dream|exam|deadline|hobby|school|college|course)\b.{2,100}", re.I), "fact"),
    (re.compile(r"\bi (?:prefer|like|love|hate|dislike|always|never|usually)\b.{3,100}", re.I), "preference"),
    (re.compile(r"\b(?:we|i) (?:decided|chose|agreed|will use|are going to use|settled on)\b.{3,120}", re.I), "decision"),
    (re.compile(r"\bi(?:'m| am) (?:allergic|learning|studying|preparing for|working on|building)\b.{3,100}", re.I), "fact"),
]


def extract(user_text: str) -> List[int]:
    ids = []
    for pat, kind in _EXTRACT:
        m = pat.search(user_text or "")
        if m and not C.SECRET.search(m.group(0)):
            r = add(m.group(0).strip(" .,"), kind, "conversation", "confirmed")
            if r.get("id"):
                ids.append(r["id"])
    return ids


# ------------------------------------------------------------------ voice / chat commands
def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    m = re.match(r"^(?:please )?remind me (?:to |about |that )?(.+)$", t, re.I)
    if m and not re.search(r"\bby\b", t, re.I):
        body = m.group(1)
        due = C.parse_when(body)
        txt = re.sub(r"\b(?:tomorrow|today|tonight|at \d{1,2}(?::\d\d)?\s*(?:am|pm)?|in \d+ \w+|on \w+day|every (?:day|week))\b", "", body, flags=re.I).strip(" ,.")
        if due is None:
            return "When should I remind you? Say for example: remind me to call mum tomorrow at 5 pm."
        rep = "daily" if re.search(r"\bevery day|daily\b", body, re.I) else ("weekly" if re.search(r"\bevery week|weekly\b", body, re.I) else "")
        add_reminder(txt or body, due, rep)
        return f"Reminder set: {txt or body}, {C.iso(due)}."
    if re.match(r"^(?:what are |show |list )?(?:my )?(?:reminders|follow[- ]?ups)(?: list)?$", low):
        rs = list_reminders()
        return "You have no reminders." if not rs else "Your reminders: " + "; ".join(f"{r['text']} at {C.iso(r['due'])}" for r in rs[:6]) + "."
    m = re.match(r"^(?:mark |complete |finish |done with )(?:reminder )?(.+?)(?: (?:as )?done| complete)?$", low)
    if m and re.search(r"\breminder\b", low):
        return "Marked done." if complete_reminder(m.group(1).replace("reminder", "").strip()) else "I couldn't find that reminder."
    m = re.match(r"^(?:record|log|save|note) (?:a |the )?(decision|lesson|goal|preference|event)[: ]+(.+)$", t, re.I)
    if m:
        r = add(m.group(2).strip(), m.group(1).lower(), "user")
        return {"added": f"Recorded that {m.group(1).lower()}.", "duplicate": "I already have that on record.", "superseded": "Updated. The earlier version is kept in history, marked as replaced.", "refused": "I won't store that - it looks like a secret."}[r["action"]]
    m = re.match(r"^(?:what|anything) (?:do you (?:remember|know)|did (?:i|we) (?:say|decide|discuss)) (?:about|regarding|on) (.+)$", low) or re.match(r"^search (?:my )?memory (?:for|about) (.+)$", low)
    if m:
        hits = search(m.group(1), k=3)
        if not hits:
            return "I have nothing on record about that."
        return "Here's what I have: " + " ".join(f"On {C.day(h['ts'])}: {h['text']}." + (" (not confirmed)" if h["status"] != "confirmed" else "") for h in hits)
    m = re.match(r"^what (?:happened|did we do|did i do|did we talk about) (?:on |last )?(.+)$", low)
    if m:
        w = m.group(1)
        ts = C.parse_when(w + " 9am")
        if "yesterday" in low:
            from datetime import datetime, timedelta
            ts = (datetime.now() - timedelta(days=1)).timestamp()
        if ts:
            day = C.day(ts)
            ev = by_date(day)
            s = C.q("SELECT text FROM summaries WHERE day=?", (day,))
            if not ev and not s:
                return f"I have nothing recorded for {day}."
            return f"On {day}: " + (s[0]["text"] + " " if s else "") + " ".join(e["text"] + "." for e in ev[:4])
    m = re.match(r"^(?:where did we leave off|resume|continue|pick up)(?: with| on)? (?:the )?(.+?)(?: project)?$", low)
    if m:
        r = resume_project(m.group(1))
        return r or f"I have no saved notes for {m.group(1)}."
    m = re.match(r"^(?:note|log) (?:for |on )?(?:the )?(.+?) project[: ]+(.+)$", t, re.I)
    if m:
        project_note(m.group(1), m.group(2))
        return f"Noted on the {m.group(1)} project."
    m = re.match(r"^(?:correct|update) (?:my )?memory[: ]+(.+?)\s*(?:->|=>|to|should be)\s+(.+)$", t, re.I)
    if m:
        return correct(m.group(1), m.group(2))
    m = re.match(r"^(?:set )?(?:memory )?retention (?:to )?(\d+) days$|^delete memories older than (\d+) days$", low)
    if m:
        d = int(m.group(1) or m.group(2))
        set_setting("retention_days", str(d))
        return f"Retention set. {apply_retention(d)} older, low-importance memories were removed."
    if re.match(r"^(?:export|back ?up) (?:my )?memor(?:y|ies)(?: (?:encrypted|securely))?$", low):
        enc = "encrypt" in low or "secure" in low
        try:
            p = export(encrypt=enc)
            return ("Encrypted " if enc else "") + f"memory export saved to {p}."
        except Exception as exc:
            return f"I couldn't export it: {exc}"
    if re.match(r"^(?:forget everything|delete all (?:my )?memor(?:y|ies)|wipe (?:my )?memor(?:y|ies))$", low):
        return "That wipes every memory I hold. Say 'confirm wipe memory' to go ahead."
    if low == "confirm wipe memory":
        return f"Done. {forget_all()} memories erased."
    if re.match(r"^what do you know about (?:my )?(?:knowledge graph|connections|relationships)$|^show (?:my )?knowledge graph$", low):
        g = graph_dump()
        return "Your knowledge graph is empty." if not g["edges"] else "I know: " + "; ".join(f"{e['a']} {e['rel']} {e['b']}" for e in g["edges"][:8]) + "."
    m = re.match(r"^who is (?:my )?(.+)$|^what do you know about (.+)$", low)
    if m:
        n = neighbours((m.group(1) or m.group(2)).title())
        if n:
            return "From my graph: " + "; ".join(n[:6]) + "."
    if re.match(r"^(?:summari[sz]e (?:this|our|the) (?:conversation|chat|session)|conversation summary)$", low):
        return save_summary() or "We haven't said enough yet to summarise."
    return None


def ui_snapshot(query: str = "") -> Dict:
    rows = search(query, k=40, include_old=True) if query.strip() else [dict(r) for r in C.q("SELECT * FROM mem6 ORDER BY ts DESC LIMIT 60")]
    return {"memories": [{"id": r["id"], "date": C.day(r["ts"]), "kind": r["kind"], "text": r["text"], "status": r["status"], "source": r["source"], "importance": r["importance"]} for r in rows],
            "reminders": [{"id": r["id"], "text": r["text"], "due": C.iso(r["due"]), "repeat": r["repeat"]} for r in list_reminders()],
            "graph": graph_dump(), "summaries": [dict(r) for r in C.q("SELECT day,text FROM summaries ORDER BY day DESC LIMIT 7")],
            "working": work_get(), "retention_days": _setting("retention_days", "off"), "encryption": encryption_available()}


def delete_id(mid: int):
    C.x("DELETE FROM mem6 WHERE id=?", (int(mid),))
