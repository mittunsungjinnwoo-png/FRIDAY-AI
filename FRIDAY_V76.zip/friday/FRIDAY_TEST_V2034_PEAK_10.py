import ast
from pathlib import Path
ROOT = Path(__file__).resolve().parent
files = list(ROOT.glob('*.py'))
for path in files:
    ast.parse(path.read_text(encoding='utf-8', errors='ignore'), filename=str(path))
required = [
    'friday_voice_engine.py','friday_backend.py','friday_peak_engine.py',
    'friday_peak_orchestrator.py','friday_quality_governor.py'
]
missing=[x for x in required if not (ROOT/x).exists()]
if missing: raise SystemExit('Missing V2034 files: '+', '.join(missing))
backend=(ROOT/'friday_backend.py').read_text(encoding='utf-8',errors='ignore')
voice=(ROOT/'friday_voice_engine.py').read_text(encoding='utf-8',errors='ignore')
assert 'friday_quality_governor' in backend
assert 'recognize_google' in backend or 'recognize_google' in voice
assert 'faster_whisper' in voice
assert 'def _adaptive_vad_pause_seconds' in backend
print(f'FRIDAY V2034 peak architecture audit: PASS ({len(files)} Python files)')
