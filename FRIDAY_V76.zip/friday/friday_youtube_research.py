"""
FRIDAY YOUTUBE RESEARCH MODULE
==============================
This is what makes "Friday, research sp3 hybridisation on YouTube and
show me the full process" a real pipeline instead of just a diagram
Gemini free-associates from its own memory:

    topic -> search YouTube (several phrasings) -> candidate videos
          -> pull each video's transcript (parallel, best-effort)
          -> Gemini CROSS-CHECKS the transcripts against each other
             and distills an ORIGINAL, grounded "research brief"
             (never copies a video's wording -- see the prompt below)
          -> that brief is handed to the Diagram Lab's existing
             diagram-design prompt as authoritative source material,
             so the 3D scene / energy levels / steps it builds are
             actually grounded in what real educational videos say,
             not just a single ungrounded model guess.

This mirrors friday_web_research.py's shape on purpose (same cache /
thread-pool / "never fabricate, degrade honestly" pattern) but is a
SEPARATE module because YouTube search + transcripts is a genuinely
different pipeline from generic web search + page text.

------------------------------------------------------------
HONEST LIMITS -- please read before relying on this:
------------------------------------------------------------
- No YouTube Data API key is configured, so search works by reading
  YouTube's own public search-results page and picking the embedded
  `ytInitialData` JSON out of the HTML (the same "no paid key needed"
  approach friday_web_research.py already uses for DuckDuckGo). If
  YouTube changes that page's structure, only `_search_youtube()`
  below needs updating.
- Transcripts are pulled via `youtube_transcript_api`, which reads
  YouTube's own caption tracks (auto-generated or uploaded). Many
  videos have captions disabled entirely, and some are region-locked
  -- those videos are just skipped, never faked.
- This module NEVER hands a raw video transcript straight to the
  diagram builder. It always goes through one extra Gemini pass
  first whose entire job is to (a) compare what multiple videos
  actually say, (b) note if they disagree, and (c) write an
  ORIGINAL summary of the real process/mechanism -- so what ends up
  on screen is Friday's own grounded synthesis, not a repackaged
  video.
- If a topic simply has poor YouTube coverage (no usable transcripts
  found), this says so plainly and the caller falls back to the
  existing model-only diagram pipeline -- it will never invent
  videos or pretend research happened when it didn't.
"""

import re
import json
import time
import html
import requests
from urllib.parse import quote_plus
from concurrent.futures import ThreadPoolExecutor, as_completed

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

MAX_VIDEOS = 5                 # how many transcripts we actually keep/use
SEARCH_POOL_PER_QUERY = 8      # candidates pulled per search phrasing
MAX_CHARS_PER_TRANSCRIPT = 4000
REQUEST_TIMEOUT = (8, 15)
FETCH_WORKERS = 5
RESULT_CACHE_TTL = 900         # 15 minutes -- a diagram + a "go deeper"
                                # follow-up on the same topic shouldn't
                                # re-search/re-transcribe from scratch.

# Videos this long or longer are almost never a focused explainer for a
# single concept (full lectures, multi-hour streams) -- they're not
# excluded, just deprioritized implicitly by ranking (search order is
# kept as-is; this constant is here for clarity/tuning, not enforced
# as a hard filter, since a 20-minute video can still be exactly right).
PREFERRED_MAX_SECONDS = 20 * 60

_result_cache = {}   # normalized_topic -> (timestamp, result_dict)


def _normalize(topic):
    return re.sub(r"\s+", " ", (topic or "").strip().lower())


def _cache_get(topic):
    entry = _result_cache.get(_normalize(topic))
    if not entry:
        return None
    ts, result = entry
    if (time.time() - ts) > RESULT_CACHE_TTL:
        _result_cache.pop(_normalize(topic), None)
        return None
    return result


def _cache_set(topic, result):
    _result_cache[_normalize(topic)] = (time.time(), result)


# ============================================================
# SEARCH -- no API key, reads YouTube's own search-results page
# ============================================================

def _search_queries_for(topic):
    """Several honest phrasings of the same topic (mirrors the
    variety a student would actually type into YouTube themselves --
    e.g. the doc's "sp3 hybridisation" / "sp3 hybridization explained"
    / "sp3 orbital animation") so one awkward phrasing doesn't starve
    the research of usable results."""
    topic = topic.strip()
    if not topic:
        return []
    return [
        topic,
        f"{topic} explained",
        f"{topic} animation",
    ]


def _search_youtube(query, max_results=SEARCH_POOL_PER_QUERY):
    """Returns a list of {video_id, title, channel, seconds} dicts for
    `query`, ranked as YouTube itself ranked them. Never raises --
    returns [] on any failure (network, layout change, etc.)."""
    out = []
    try:
        url = "https://www.youtube.com/results?search_query=" + quote_plus(query)
        resp = requests.get(url, headers=_HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        match = re.search(r"var ytInitialData\s*=\s*(\{.*?\});", resp.text, re.DOTALL)
        if not match:
            # YouTube sometimes emits this as `window["ytInitialData"] = {...}`
            match = re.search(r'ytInitialData"\]\s*=\s*(\{.*?\});', resp.text, re.DOTALL)
        if not match:
            return out
        data = json.loads(match.group(1))

        contents = (
            data.get("contents", {})
                .get("twoColumnSearchResultsRenderer", {})
                .get("primaryContents", {})
                .get("sectionListRenderer", {})
                .get("contents", [])
        )
        seen_ids = set()
        for section in contents:
            items = section.get("itemSectionRenderer", {}).get("contents", [])
            for item in items:
                vr = item.get("videoRenderer")
                if not vr or not vr.get("videoId"):
                    continue
                vid = vr["videoId"]
                if vid in seen_ids:
                    continue
                seen_ids.add(vid)
                title_runs = vr.get("title", {}).get("runs", [])
                title = "".join(r.get("text", "") for r in title_runs).strip() or "Untitled video"
                channel_runs = (
                    vr.get("ownerText", {}).get("runs", [])
                    or vr.get("longBylineText", {}).get("runs", [])
                )
                channel = "".join(r.get("text", "") for r in channel_runs).strip()
                length_text = (vr.get("lengthText", {}) or {}).get("simpleText", "")
                # A live stream / premiere has no lengthText -- skip those,
                # they're not a stable, re-fetchable explainer.
                if not length_text:
                    continue
                out.append({
                    "video_id": vid,
                    "title": html.unescape(title),
                    "channel": html.unescape(channel),
                    "length": length_text,
                })
                if len(out) >= max_results:
                    return out
    except Exception as error:
        print(f"YouTube search error ({query}):", error)
    return out


def _dedupe_videos(video_lists):
    """Merges several ranked lists (one per search phrasing), keeping
    first-seen order and dropping duplicate video ids."""
    seen = set()
    merged = []
    for videos in video_lists:
        for v in videos:
            if v["video_id"] in seen:
                continue
            seen.add(v["video_id"])
            merged.append(v)
    return merged


# ============================================================
# TRANSCRIPTS
# ============================================================

def _get_transcript_text(video_id):
    """Best-effort transcript fetch. Returns "" (never raises) if
    captions are disabled, the video is unavailable, or the optional
    `youtube_transcript_api` package isn't installed."""
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
    except ImportError:
        print("youtube_transcript_api is not installed -- run: "
              "pip install youtube-transcript-api")
        return ""
    try:
        try:
            chunks = YouTubeTranscriptApi.get_transcript(video_id, languages=["en", "en-US", "en-GB"])
        except Exception:
            # Fall back to whatever transcript IS available (auto-generated
            # in another language, etc.) rather than giving up outright.
            transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
            transcript = next(iter(transcript_list), None)
            if transcript is None:
                return ""
            chunks = transcript.fetch()
        text = " ".join(c.get("text", "") for c in chunks if c.get("text"))
        text = re.sub(r"\s+", " ", text).strip()
        return text[:MAX_CHARS_PER_TRANSCRIPT]
    except Exception as error:
        print(f"YouTube transcript unavailable ({video_id}):", error)
        return ""


def gather_youtube_sources(topic, depth=MAX_VIDEOS, use_cache=True):
    """
    Search (several phrasings) -> merge/rank -> fetch transcripts in
    parallel -> keep only videos that actually yielded usable text.
    Returns [{video_id, title, channel, url, transcript}, ...],
    ranked, capped at `depth`. Never raises; returns [] if nothing
    usable was found (no fabricated placeholder videos, ever).
    """
    cache_key = f"__yt_sources__{topic}__{depth}"
    if use_cache:
        cached = _cache_get(cache_key)
        if cached is not None:
            return cached

    queries = _search_queries_for(topic)
    if not queries:
        return []

    video_lists = [_search_youtube(q) for q in queries]
    candidates = _dedupe_videos(video_lists)
    if not candidates:
        if use_cache:
            _cache_set(cache_key, [])
        return []

    # Fetch transcripts concurrently, same bounded-pool pattern as
    # friday_web_research.py's gather_sources().
    results = []
    with ThreadPoolExecutor(max_workers=min(FETCH_WORKERS, len(candidates))) as pool:
        future_to_video = {pool.submit(_get_transcript_text, v["video_id"]): v for v in candidates}
        for future in as_completed(future_to_video):
            video = future_to_video[future]
            try:
                transcript = future.result()
            except Exception as error:
                print(f"Transcript task error ({video['video_id']}):", error)
                continue
            if len(transcript) > 200:
                results.append({
                    "video_id": video["video_id"],
                    "title": video["title"],
                    "channel": video["channel"],
                    "url": f"https://www.youtube.com/watch?v={video['video_id']}",
                    "transcript": transcript,
                })

    rank = {v["video_id"]: i for i, v in enumerate(candidates)}
    results.sort(key=lambda r: rank.get(r["video_id"], len(candidates)))
    results = results[:depth]

    if use_cache:
        _cache_set(cache_key, results)
    return results


# ============================================================
# CROSS-CHECK + SYNTHESIS (Gemini)
# ============================================================

def research_topic_from_youtube(topic, use_cache=True):
    """
    Full pipeline. Returns:
        {
          "ok": bool,             # False if no usable videos/transcripts
          "brief": str,           # Friday's own cross-checked synthesis
                                   # of the real process/mechanism, grounded
                                   # in the transcripts -- "" if not ok
          "videos": [ {title, channel, url}, ... ],   # for on-screen
                                   # citation / "based on N videos"
          "note": str,            # short, honest status line for the UI
        }
    Never raises -- always returns a usable dict so the Diagram Lab
    can fall back to its normal model-only pipeline on any failure.
    """
    cache_key = f"__yt_research__{topic}"
    if use_cache:
        cached = _cache_get(cache_key)
        if cached is not None:
            return cached

    videos = gather_youtube_sources(topic, use_cache=use_cache)
    if not videos:
        result = {
            "ok": False,
            "brief": "",
            "videos": [],
            "note": (
                "I couldn't find any YouTube videos on that topic with usable captions, "
                "so I'll build the diagram from what I already know instead."
            ),
        }
        return result

    # Lazy import: friday_backend imports this module, so importing it
    # back at module load time would be circular (same pattern as
    # friday_web_research.run_web_research()).
    import friday_backend
    friday_backend._ensure_gemini_client()
    if friday_backend.client is None:
        result = {
            "ok": False,
            "brief": "",
            "videos": [{"title": v["title"], "channel": v["channel"], "url": v["url"]} for v in videos],
            "note": "I found relevant videos, but my AI brain is unavailable to cross-check them right now.",
        }
        return result

    sources_block = "\n\n".join(
        f"VIDEO {i + 1} -- \"{v['title']}\" ({v['channel']}):\n{v['transcript']}"
        for i, v in enumerate(videos)
    )

    prompt = (
        "You are the research-analyser layer of Friday's Diagram Lab. Below are the "
        f"transcripts of {len(videos)} real YouTube videos that came up when searching for "
        f"the topic: \"{topic}\".\n\n"
        f"{sources_block}\n\n"
        "Your job:\n"
        "1. Compare what these videos actually say. Identify the concepts, steps and "
        "terminology they AGREE on -- that is the reliable core of the process.\n"
        "2. If any video contradicts the others or seems to be about something slightly "
        "different, note that briefly rather than silently picking one.\n"
        "3. Write your OWN original, clear, step-by-step description of the real "
        "process/mechanism this topic describes (ground state, the sequence of what "
        "happens, and the end result, in the right order) -- in your own words. Do not "
        "quote or closely paraphrase any single video's exact phrasing; this must read as "
        "your independent synthesis, not a copy of one source.\n"
        "4. If the videos don't fully cover some standard part of this topic that a "
        "textbook would include, you may fill that gap from established science, but say "
        "so explicitly rather than presenting it as something the videos covered.\n"
        "5. Keep it factual and information-dense (roughly 150-300 words) -- this brief is "
        "handed to a diagram-generation step next, it is not the final answer shown to a "
        "student, so skip any pleasantries.\n\n"
        "Write the brief now, plain text, no headings, no JSON."
    )

    try:
        response = friday_backend.client.models.generate_content(
            model=friday_backend.GEMINI_MODEL, contents=prompt
        )
        brief = (getattr(response, "text", None) or "").strip()
        if not brief:
            raise ValueError("empty Gemini response")
    except Exception as error:
        print("YouTube research synthesis error:", error)
        result = {
            "ok": False,
            "brief": "",
            "videos": [{"title": v["title"], "channel": v["channel"], "url": v["url"]} for v in videos],
            "note": "I found relevant videos, but had trouble cross-checking them just now.",
        }
        return result

    result = {
        "ok": True,
        "brief": brief,
        "videos": [{"title": v["title"], "channel": v["channel"], "url": v["url"]} for v in videos],
        "note": f"Cross-checked {len(videos)} YouTube videos on this topic before building the diagram.",
    }
    if use_cache:
        _cache_set(cache_key, result)
    return result
