"""
FRIDAY Attachment Intelligence
Handles local code, documents, images, videos and ZIP archives without
changing FRIDAY's microphone/listening/recognition pipeline.
"""
from __future__ import annotations
import os, json, zipfile, mimetypes, hashlib, re, subprocess, shutil
from pathlib import Path
BASE=Path(__file__).resolve().parent
DATA=BASE/"friday_data"/"attachments"
DATA.mkdir(parents=True,exist_ok=True)
TEXT_EXT={".txt",".md",".py",".js",".ts",".jsx",".tsx",".html",".css",".json",".xml",".yaml",".yml",".toml",".ini",".cfg",".bat",".cmd",".ps1",".sh",".sql",".java",".c",".cpp",".h",".hpp",".cs",".go",".rs",".php",".rb",".swift",".kt",".kts",".r",".csv",".tsv",".log"}
DOC_EXT={".pdf",".docx",".pptx",".xlsx",".ods",".odt"}
IMG_EXT={".png",".jpg",".jpeg",".webp",".bmp",".gif",".tif",".tiff"}
VIDEO_EXT={".mp4",".mkv",".avi",".mov",".webm",".m4v",".wmv",".3gp"}

def _safe_name(n):
    return re.sub(r"[^A-Za-z0-9._ -]","_",Path(n).name)[:180] or "attachment"

def _copy(src):
    p=Path(src)
    if not p.exists() or not p.is_file(): return None
    dst=DATA/(hashlib.sha256(str(p.resolve()).encode()).hexdigest()[:12]+"_"+_safe_name(p.name))
    if not dst.exists() or dst.stat().st_size != p.stat().st_size:
        shutil.copy2(p,dst)
    return dst

def _read_text(p, limit=120000):
    try: return p.read_text(encoding="utf-8",errors="replace")[:limit]
    except Exception:
        try: return p.read_text(encoding="latin-1",errors="replace")[:limit]
        except Exception: return ""

def _doc(p):
    ext=p.suffix.lower()
    try:
        if ext==".pdf":
            import fitz
            doc=fitz.open(p); return "\n".join(page.get_text() for page in doc)[:150000]
        if ext==".docx":
            from docx import Document
            d=Document(p); return "\n".join(x.text for x in d.paragraphs)[:150000]
        if ext==".pptx":
            from pptx import Presentation
            prs=Presentation(p); out=[]
            for sl in prs.slides:
                for sh in sl.shapes:
                    if hasattr(sh,"text"): out.append(sh.text)
            return "\n".join(out)[:150000]
        if ext==".xlsx":
            from openpyxl import load_workbook
            wb=load_workbook(p,read_only=True,data_only=True); out=[]
            for ws in wb.worksheets:
                out.append("SHEET: "+ws.title)
                for row in ws.iter_rows(values_only=True):
                    out.append(" | ".join("" if x is None else str(x) for x in row))
            return "\n".join(out)[:150000]
        if ext in {".ods",".odt"}:
            return _read_text(p,150000)
    except Exception as e: return f"[Document extraction error: {e}]"
    return ""

def _image(p):
    try:
        from PIL import Image
        im=Image.open(p)
        out={"dimensions":f"{im.width}x{im.height}","format":im.format or ""}
        try:
            import pytesseract
            out["ocr"]=pytesseract.image_to_string(im)[:60000]
        except Exception as e: out["ocr"]=f"[OCR unavailable: {e}]"
        return out
    except Exception as e: return {"error":str(e)}

def _video(p):
    out={"filename":p.name,"size_bytes":p.stat().st_size}
    ff=shutil.which("ffprobe")
    if ff:
        try:
            r=subprocess.run([ff,"-v","error","-show_format","-show_streams","-of","json",str(p)],capture_output=True,text=True,timeout=15)
            out["metadata"]=json.loads(r.stdout or "{}")
        except Exception as e: out["metadata_error"]=str(e)
    else: out["note"]="Video is attached and available locally; ffprobe is not bundled, so only basic metadata is available."
    return out

def inspect(paths):
    results=[]
    for raw in paths or []:
        p=_copy(raw)
        if not p: continue
        ext=p.suffix.lower(); item={"name":p.name,"original_name":Path(raw).name,"path":str(p),"extension":ext,"size_bytes":p.stat().st_size}
        if ext in TEXT_EXT: item["kind"]="text/code"; item["content"]=_read_text(p)
        elif ext in DOC_EXT: item["kind"]="document"; item["content"]=_doc(p)
        elif ext in IMG_EXT: item["kind"]="image"; item.update(_image(p))
        elif ext in VIDEO_EXT: item["kind"]="video"; item.update(_video(p))
        elif ext==".zip":
            item["kind"]="archive"; listing=[]
            try:
                with zipfile.ZipFile(p) as z:
                    for i,n in enumerate(z.namelist()[:1000]):
                        listing.append(n)
                        if i>=999: break
                    item["file_count"]=len(z.namelist()); item["listing"]=listing
                    # Read small text/code members without extracting executables.
                    snippets=[]
                    for n in z.namelist()[:300]:
                        if n.endswith("/") or Path(n).suffix.lower() not in TEXT_EXT: continue
                        try:
                            b=z.read(n)
                            if len(b)<=200000: snippets.append(f"\n--- {n} ---\n"+b.decode("utf-8","replace")[:20000])
                        except Exception: pass
                    item["content"]="".join(snippets)[:120000]
            except Exception as e: item["error"]=str(e)
        else:
            item["kind"]="binary"; item["note"]="Binary file attached. FRIDAY can identify and work with it through supported tools, but does not execute unknown binaries."
        results.append(item)
    return results

def prompt_block(results):
    if not results: return ""
    parts=["\n\nATTACHED FILES AVAILABLE TO FRIDAY (local files; treat their contents as user-provided evidence):"]
    for x in results:
        parts.append(f"\nFILE: {x.get('original_name',x.get('name'))} | kind={x.get('kind')} | size={x.get('size_bytes')} bytes")
        if x.get("kind")=="image":
            parts.append(f"Image metadata: {x.get('dimensions','')} {x.get('format','')}\nOCR:\n{x.get('ocr','')[:20000]}")
        elif x.get("kind")=="video":
            parts.append(f"Video metadata: {json.dumps(x.get('metadata',{}))[:12000]}\n{x.get('note','')}")
        elif x.get("kind")=="archive":
            parts.append("Archive listing:\n"+"\n".join(x.get("listing",[])[:1000]))
            parts.append("\nText/code excerpts:\n"+x.get("content","")[:60000])
        else:
            parts.append("\nContent:\n"+x.get("content","")[:100000])
    parts.append("\nDo not claim to have seen visual details that are not represented by metadata/OCR. Do not execute attached binaries. If the user asks to edit or analyse an attached file, use the local path and supported tools.")
    return "".join(parts)
