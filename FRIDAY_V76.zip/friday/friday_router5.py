"""FRIDAY 5.0 intelligence router.

Fast Brain -> Router -> Deep Brain.  Every request is classified in well under a millisecond:

  instant   answered locally and exactly (maths, unit conversion, time/date) - no network, no model
  fast      one streamed flash-class model call (default; keeps replies quick)
  deep      high-thinking model call followed by an independent check (reasoning, proofs, code, design)
  research  live web research with sources, cross-checked
  agent     multi-step task: plan -> act -> observe -> verify (tools, files, diagnostics)

Also provides generate -> check -> correct (`verified_answer`) with an independent numeric re-check for maths.
"""
from __future__ import annotations

import ast
import math
import operator
import re
import time
from datetime import datetime
from typing import Callable, Dict, Optional

# ------------------------------------------------------------------ safe maths
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.FloorDiv: operator.floordiv,
        ast.USub: operator.neg, ast.UAdd: operator.pos}
_FUNCS = {"sqrt": math.sqrt, "sin": lambda x: math.sin(math.radians(x)), "cos": lambda x: math.cos(math.radians(x)),
          "tan": lambda x: math.tan(math.radians(x)), "log": math.log10, "ln": math.log, "abs": abs, "round": round,
          "factorial": lambda x: math.factorial(int(x)), "floor": math.floor, "ceil": math.ceil}
_CONSTS = {"pi": math.pi, "e": math.e}


def _eval(node):
    if isinstance(node, ast.Expression):
        return _eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        a, b = _eval(node.left), _eval(node.right)
        if isinstance(node.op, ast.Pow) and (abs(b) > 1000 or abs(a) > 1e12):
            raise ValueError("exponent too large")
        return _OPS[type(node.op)](a, b)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.operand))
    if isinstance(node, ast.Name) and node.id in _CONSTS:
        return _CONSTS[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FUNCS and len(node.args) == 1:
        return _FUNCS[node.func.id](_eval(node.args[0]))
    raise ValueError("unsupported expression")


def safe_eval(expr: str) -> float:
    return _eval(ast.parse(expr, mode="eval"))


def fmt_number(x: float) -> str:
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        raise ValueError("not finite")
    if abs(x - round(x)) < 1e-9 and abs(x) < 1e15:
        return f"{int(round(x)):,}".replace(",", "") if abs(x) < 1e6 else f"{int(round(x)):,}"
    return f"{x:,.6f}".rstrip("0").rstrip(".") if abs(x) >= 1e-4 else f"{x:.6g}"


_WORD_NUM = {"zero": 0, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
             "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15, "sixteen": 16, "seventeen": 17,
             "eighteen": 18, "nineteen": 19, "twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70,
             "eighty": 80, "ninety": 90, "hundred": 100, "thousand": 1000}


def _words_to_digits(t: str) -> str:
    def conv(m):
        words = [w for w in re.split(r"[ -]+", m.group(0).strip()) if w in _WORD_NUM]
        total, cur = 0, 0
        for w in words:
            v = _WORD_NUM[w]
            if v == 100:
                cur = max(cur, 1) * 100
            elif v == 1000:
                total += max(cur, 1) * 1000
                cur = 0
            else:
                cur += v
        return str(total + cur)
    pat = r"\b(?:(?:" + "|".join(_WORD_NUM) + r")(?:[ -](?:and )?)?)+\b"
    return re.sub(pat, lambda m: (conv(m) + (" " if m.group(0).endswith((" ", "-")) else "")) if m.group(0).strip() else m.group(0), t)


def math_answer(text: str) -> Optional[str]:
    t = (text or "").lower().strip().rstrip("?.! ")
    t = re.sub(r"^(?:hey |ok |okay )?(?:friday[, ]*)?(?:please )?(?:what(?:'s| is| are)|calculate|compute|work out|how much is|tell me|solve|find)\s+", "", t)
    t = _words_to_digits(t)
    m = re.match(r"^(\d+(?:\.\d+)?)\s*(?:%|percent)\s+of\s+(\d+(?:\.\d+)?)$", t)
    if m:
        return f"{fmt_number(float(m.group(1)) * float(m.group(2)) / 100)}."
    m = re.match(r"^(?:the )?square root of (\d+(?:\.\d+)?)$", t)
    if m:
        return f"{fmt_number(math.sqrt(float(m.group(1))))}."
    m = re.match(r"^(\d+(?:\.\d+)?) (?:squared)$", t)
    if m:
        return f"{fmt_number(float(m.group(1)) ** 2)}."
    t = (t.replace("×", "*").replace("÷", "/").replace("−", "-").replace("^", "**")
         .replace(" multiplied by ", "*").replace(" times ", "*").replace(" x ", "*").replace(" divided by ", "/")
         .replace(" over ", "/").replace(" plus ", "+").replace(" minus ", "-").replace(" to the power of ", "**")
         .replace(" mod ", "%").replace(" modulo ", "%"))
    t = re.sub(r"(?<=\d),(?=\d{3}\b)", "", t)
    if not re.search(r"\d", t) or not re.fullmatch(r"[0-9a-z+\-*/%().,\s*]+", t):
        return None
    if re.search(r"[a-z]", re.sub(r"\b(?:sqrt|sin|cos|tan|log|ln|abs|round|factorial|floor|ceil|pi|e)\b", "", t)):
        return None
    if not re.search(r"[+\-*/%]|\*\*|\b(?:sqrt|sin|cos|tan|log|ln|factorial)\b", t):
        return None
    try:
        return f"{fmt_number(float(safe_eval(t)))}."
    except Exception:
        return None


# ------------------------------------------------------------------ units
_UNITS = {
    ("km", "mi"): 0.621371, ("mi", "km"): 1.609344, ("kg", "lb"): 2.204623, ("lb", "kg"): 0.453592, ("m", "ft"): 3.28084,
    ("ft", "m"): 0.3048, ("cm", "in"): 0.393701, ("in", "cm"): 2.54, ("l", "gal"): 0.264172, ("gal", "l"): 3.785412,
    ("g", "oz"): 0.035274, ("oz", "g"): 28.3495, ("km", "m"): 1000, ("m", "km"): 0.001, ("kg", "g"): 1000, ("g", "kg"): 0.001,
    ("mi", "m"): 1609.344, ("m", "cm"): 100, ("cm", "m"): 0.01, ("mb", "gb"): 0.001, ("gb", "mb"): 1000, ("gb", "tb"): 0.001, ("tb", "gb"): 1000,
}
_ALIAS = {"kilometer": "km", "kilometers": "km", "kilometre": "km", "kilometres": "km", "mile": "mi", "miles": "mi", "kilogram": "kg", "kilograms": "kg",
          "kilos": "kg", "kilo": "kg", "pound": "lb", "pounds": "lb", "lbs": "lb", "meter": "m", "meters": "m", "metre": "m", "metres": "m", "feet": "ft", "foot": "ft",
          "centimeter": "cm", "centimeters": "cm", "centimetres": "cm", "inch": "in", "inches": "in", "liter": "l", "liters": "l", "litre": "l", "litres": "l",
          "gallon": "gal", "gallons": "gal", "gram": "g", "grams": "g", "ounce": "oz", "ounces": "oz", "megabytes": "mb", "gigabytes": "gb", "terabytes": "tb"}


def unit_answer(text: str) -> Optional[str]:
    t = (text or "").lower().strip().rstrip("?.! ")
    m = re.match(r"^(?:convert\s+|what(?:'s| is)\s+|how many\s+)?(-?\d+(?:\.\d+)?)\s*(?:degrees?\s*)?(celsius|fahrenheit|c|f)\s*(?:to|in|into)\s*(?:degrees?\s*)?(celsius|fahrenheit|c|f)$", t)
    if m:
        v, a, b = float(m.group(1)), m.group(2)[0], m.group(3)[0]
        if a == b:
            return None
        r = v * 9 / 5 + 32 if a == "c" else (v - 32) * 5 / 9
        return f"{fmt_number(round(r, 2))} degrees {'Fahrenheit' if b == 'f' else 'Celsius'}."
    m = re.match(r"^(?:convert\s+|what(?:'s| is)\s+|how many\s+)?(-?\d+(?:\.\d+)?)\s*([a-z]+)\s*(?:to|in|into)\s*([a-z]+)$", t)
    if m:
        v = float(m.group(1))
        a, b = _ALIAS.get(m.group(2), m.group(2)), _ALIAS.get(m.group(3), m.group(3))
        f = _UNITS.get((a, b))
        if f:
            return f"{fmt_number(round(v * f, 4))} {m.group(3)}."
    return None


def time_answer(text: str, now: Optional[datetime] = None) -> Optional[str]:
    t = (text or "").lower().strip().rstrip("?.! ")
    now = now or datetime.now()
    if re.match(r"^(?:what(?:'s| is) the time|what time is it|tell me the time|current time|time now|what time is it now)$", t):
        return "It's " + now.strftime("%I:%M %p").lstrip("0") + "."
    if re.match(r"^(?:what(?:'s| is) (?:the )?(?:today'?s )?date(?: today)?|what day is it(?: today)?|what is today'?s date|today'?s date|what(?:'s| is) today)$", t):
        return "It's " + now.strftime("%A, %B ") + str(now.day) + now.strftime(", %Y") + "."
    return None


def instant_answer(text: str) -> Optional[str]:
    for fn in (time_answer, unit_answer, math_answer):
        try:
            r = fn(text)
        except Exception:
            r = None
        if r:
            return r
    return None


# ------------------------------------------------------------------ routing
_RE_RESEARCH = re.compile(r"\b(latest|news|today'?s|current(?:ly)?|right now|this week|this year|price of|prices|stock|weather|score|who (?:is|won)|"
                          r"research|look up|search for|find out|sources?|cross[- ]check|compare .* (?:and|vs)|release date|trending)\b", re.I)
_RE_DEEP = re.compile(r"\b(prove|proof|derive|step by step|explain why|why does|why is|analy[sz]e|evaluate|critique|design|architecture|optimi[sz]e|"
                      r"trade-?offs?|pros and cons|(?:write|create|implement|code) (?:a |an |the )?(?:[a-z+#]+ ){0,2}(?:program|code|script|function|class|algorithm|app|website)|debug|refactor|"
                      r"solve|integral|derivative|equation|probability|algorithm|complexity|strategy|plan (?:a|the|my|out)|essay|compare and contrast|"
                      r"what would happen if|how would you)\b", re.I)
_RE_AGENT = re.compile(r"\b(prepare|set ?up|figure out why|find why|diagnos|troubleshoot|organi[sz]e|clean up|go through|inspect|audit|"
                       r"create (?:a )?(?:project|folder|report|presentation|document|app)|generate (?:a )?(?:report|documentation|demo)|"
                       r"run (?:this|the|my) (?:code|script|program|file)|analy[sz]e (?:my|this|the) (?:folder|project|file|code|screen|pc|computer)|"
                       r"why (?:is|are) my (?:laptop|pc|computer|system|internet|wifi|battery)|my (?:laptop|pc|computer) (?:is|has|keeps)|check my (?:system|pc|computer|laptop))\b", re.I)


def classify(text: str, has_attachments: bool = False) -> Dict:
    t = (text or "").strip()
    words = len(t.split())
    if instant_answer(t) is not None:
        return {"route": "instant", "depth": 0, "why": "exact local answer"}
    if _RE_AGENT.search(t) or (has_attachments and re.search(r"\b(fix|edit|convert|run|execute|test|clean|translate|rewrite|refactor|organi[sz]e|extract|create|make|build|generate)\b", t, re.I)):
        return {"route": "agent", "depth": 2, "why": "multi-step task"}
    if _RE_RESEARCH.search(t):
        return {"route": "research", "depth": 2, "why": "needs current information"}
    if _RE_DEEP.search(t) or words >= 45:
        return {"route": "deep", "depth": 3, "why": "needs careful reasoning"}
    return {"route": "fast", "depth": 1, "why": "conversational"}


# ------------------------------------------------------------------ generate -> check -> correct
_NUM = re.compile(r"-?\d[\d,]*\.?\d*")


def numbers_in(text: str):
    out = []
    for m in _NUM.findall(text or ""):
        try:
            out.append(float(m.replace(",", "")))
        except Exception:
            pass
    return out


def verified_answer(question: str, gen: Callable[[str], str], deep: bool = True) -> Dict:
    """Draft, independently check, and correct if needed. `gen(prompt)->text` is the model call.

    Returns {"answer", "confidence", "checked", "notes"}.  Confidence is conservative: 0.9 when an independent
    solve agrees, 0.75 when the critic found nothing, 0.5 when the critic had to correct, 0.35 when unchecked.
    """
    draft = (gen(question) or "").strip()
    if not draft:
        return {"answer": "", "confidence": 0.0, "checked": False, "notes": "no draft"}
    if not deep:
        return {"answer": draft, "confidence": 0.6, "checked": False, "notes": ""}
    notes = []
    conf = 0.35
    answer = draft
    try:
        critique = (gen(
            "You are a strict independent verifier. Below is a QUESTION and a DRAFT answer.\n"
            "Check the facts, logic, arithmetic and whether every part of the question was answered. "
            "If the draft is fully correct reply with exactly: OK\n"
            "Otherwise reply with: FIX: followed by the complete corrected answer, written in the same spoken style.\n\n"
            f"QUESTION:\n{question}\n\nDRAFT:\n{draft}") or "").strip()
        if critique.upper().startswith("OK"):
            conf, notes = 0.75, ["checked: no problems found"]
        elif critique.upper().startswith("FIX"):
            answer = critique.split(":", 1)[1].strip() if ":" in critique else critique[3:].strip()
            conf, notes = 0.5, ["corrected after verification"]
        else:
            notes.append("verifier reply unclear; keeping draft")
    except Exception as exc:
        notes.append(f"verification skipped: {exc}")
    if re.search(r"\d", question) and re.search(r"[+\-*/^=]|\b(?:solve|calculate|compute|how many|how much|percent|total|average)\b", question, re.I):
        try:
            solo = (gen("Solve this independently. Reply with ONLY the final numeric answer(s), no words.\n\n" + question) or "")
            a, b = numbers_in(answer), numbers_in(solo)
            if a and b and any(abs(x - y) <= max(1e-6, abs(y) * 1e-6) for x in a for y in b):
                conf = max(conf, 0.9)
                notes.append("independent solve agrees")
            elif a and b:
                conf = min(conf, 0.4)
                notes.append("independent solve DISAGREES")
        except Exception:
            pass
    return {"answer": answer, "confidence": conf, "checked": True, "notes": "; ".join(notes)}
