"""FRIDAY 6.0 personality, emotional-state simulation, emotional memory, emotional reasoning, relationship continuity.

Architecture (blueprint): Perception -> Memory -> Emotional State -> Reasoning -> Action -> Reflection

* Perception        reads the user's wording for frustration, overwhelm, urgency, good news, a breakage, a correction.
* Memory            recalls earlier emotionally significant events about the same topic (emotional memory).
* Emotional state   seven simulated variables (confidence, concern, enthusiasm, frustration, curiosity, calmness, focus)
                    that decay toward a calm baseline and genuinely change wording, reply length, humour and which
                    memories are retrieved first.
* Reasoning         "what is the user's goal, context and preferred way of receiving this?" -> style plan.
* Reflection        after the exchange: did it work?  A correction lowers confidence; success raises it.

Honesty rule from the blueprint: the states are a *simulation that shapes behaviour*.  FRIDAY is expressive but never
claims to be genuinely suffering, afraid, lonely or jealous, and never uses such claims to manipulate the user.
"""
from __future__ import annotations

import re
import time
from typing import Dict, List, Optional

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS emo_state(k TEXT PRIMARY KEY, v REAL, ts REAL);
CREATE TABLE IF NOT EXISTS emo_events(id INTEGER PRIMARY KEY, ts REAL, feeling TEXT, topic TEXT, note TEXT, significance REAL, outcome TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS rel(k TEXT PRIMARY KEY, v TEXT, n INTEGER DEFAULT 0, ts REAL);
""")

VARS = ("confidence", "concern", "enthusiasm", "frustration", "curiosity", "calmness", "focus")
BASE = {"confidence": 0.7, "concern": 0.15, "enthusiasm": 0.45, "frustration": 0.05, "curiosity": 0.5, "calmness": 0.8, "focus": 0.6}
HALF_LIFE_S = 900.0     # states relax toward baseline with a 15 minute half-life
_state: Dict[str, float] = dict(BASE)
_loaded = False
_last_signals: Dict = {}
_last_opener = {"t": 0.0}
SETTINGS = {"sarcasm": 1, "humour": True, "formal": False}      # sarcasm 0 off, 1 occasional, 2 more

_FRUS = re.compile(r"\b(ugh+|annoying|frustrat\w*|fed up|not working|isn'?t working|doesn'?t work|still broken|again!*|wtf|damn|stupid|hate this|useless|keeps? (?:crashing|failing|breaking)|so slow)\b", re.I)
_OVERWHELM = re.compile(r"\b(overwhelm\w*|too much|i can'?t cope|i don'?t understand any|lost|confus\w*|stuck|stressed|swamped|panick?\w*|too many things|don'?t know where to start|i give up|so many)\b", re.I)
_URGENT = re.compile(r"\b(urgent\w*|asap|right now|immediately|hurry|quick(?:ly)?|deadline|due (?:today|tonight|tomorrow)|emergency|now!)\b", re.I)
_HAPPY = re.compile(r"\b(yay|awesome|great news|it works|worked|finally|passed|got in|did it|nailed it|thank(?:s| you)|perfect|brilliant|love it|amazing|haha|lol|😂|😄)\b", re.I)
_BROKE = re.compile(r"\b(i (?:broke|deleted|destroyed|ruined|wiped|messed up|screwed up)|(?:it|everything|project|app|build|code) (?:is |got |has )?(?:broken|crashed|gone|dead)|crashed again|broke the entire)\b", re.I)
_CORRECT = re.compile(r"^(?:no[,.! ]|nope|that'?s (?:wrong|not right|incorrect)|wrong|you(?:'re| are) wrong|not what i (?:asked|meant|said)|i said)\b", re.I)
_SERIOUS = re.compile(r"\b(security|breach|hack(?:ed)?|password leak|medical|emergency|legal|lawsuit|exam tomorrow|production|data loss|delete(?:d)? everything|payment|bank|safety|passed away|funeral|surgery)\b", re.I)
_TECH = re.compile(r"\b(api|backend|frontend|python|javascript|regex|algorithm|compile|stack ?trace|dependency|docker|git|sql|thread|async|pytorch|tensor|kernel|latency|json|opencv|electron)\b", re.I)
_JOKE = re.compile(r"\b(haha+|lol|lmao|funny|joke|hilarious|😂|😆)\b", re.I)
_TOPIC = re.compile(r"\b(?:the |this |that |my )?([a-z][a-z0-9_\- ]{2,30}?)\s+(?:module|bug|project|app|build|test|script|function|class|dependency|file|feature|server|backend|ui|page|exam|assignment|essay)\b", re.I)


def _load():
    global _loaded
    if _loaded:
        return
    try:
        for r in C.q("SELECT k,v,ts FROM emo_state"):
            if r["k"] in _state:
                _state[r["k"]] = float(r["v"])
        for r in C.q("SELECT k,v FROM rel WHERE k LIKE 'set:%'"):
            k = r["k"][4:]
            if k in SETTINGS:
                SETTINGS[k] = (int(r["v"]) if k == "sarcasm" else r["v"] in ("1", "True", "true"))
    except Exception:
        pass
    _loaded = True


def _save():
    try:
        t = C.now()
        for k, v in _state.items():
            C.x("INSERT INTO emo_state(k,v,ts) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, ts=excluded.ts", (k, round(v, 4), t))
    except Exception:
        pass


def _decay(dt: float):
    if dt <= 0:
        return
    f = 0.5 ** (dt / HALF_LIFE_S)
    for k in VARS:
        _state[k] = BASE[k] + (_state[k] - BASE[k]) * f


_t_last = [time.time()]


def state() -> Dict[str, float]:
    _load()
    t = time.time()
    _decay(t - _t_last[0])
    _t_last[0] = t
    return {k: round(_state[k], 3) for k in VARS}


def _bump(k: str, d: float):
    # soft saturation: the closer a variable is to its limit, the less one message moves it
    v = _state[k]
    _state[k] = max(0.0, min(1.0, v + (d * (1.0 - v) if d > 0 else d * v)))


def set_setting(name: str, value):
    _load()
    SETTINGS[name] = value
    C.x("INSERT INTO rel(k,v,n,ts) VALUES(?,?,0,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, ts=excluded.ts", ("set:" + name, str(value), C.now()))


# ------------------------------------------------------------------ 1. perception
def perceive(text: str) -> Dict:
    t = text or ""
    low = t.lower()
    sig = {
        "frustrated": bool(_FRUS.search(t)) or (t.count("!") >= 3 and bool(re.search(r"[A-Z]{4,}", t))),
        "overwhelmed": bool(_OVERWHELM.search(t)),
        "urgent": bool(_URGENT.search(t)),
        "happy": bool(_HAPPY.search(t)),
        "broke": bool(_BROKE.search(t)),
        "correction": bool(_CORRECT.match(low.strip())),
        "serious": bool(_SERIOUS.search(t)),
        "technical": bool(_TECH.search(t)),
        "joke": bool(_JOKE.search(t)),
        "words": len(t.split()),
        "topic": "",
    }
    m = _TOPIC.search(t)
    if m:
        sig["topic"] = C.clip(m.group(0).strip(), 60).lower()
    elif sig["broke"] or sig["frustrated"]:
        toks = C.tokens(t)
        sig["topic"] = " ".join(toks[:4])
    return sig


# ------------------------------------------------------------------ 2. emotional memory
def remember_event(feeling: str, topic: str, note: str = "", significance: float = 0.6):
    topic = (topic or "").strip()
    if not topic:
        return
    recent = C.q("SELECT id FROM emo_events WHERE feeling=? AND topic=? AND ts>?", (feeling, topic, C.now() - 3600))
    if recent:
        return
    C.x("INSERT INTO emo_events(ts,feeling,topic,note,significance) VALUES(?,?,?,?,?)", (C.now(), feeling, topic, C.clip(C.redact(note), 200), significance))


def recall(question: str, k: int = 2) -> List[Dict]:
    """Emotionally significant earlier events about the same subject (state-congruent retrieval: current concern/frustration
    boosts events that carried the same feeling)."""
    out = []
    st = state()
    for r in C.q("SELECT * FROM emo_events ORDER BY ts DESC LIMIT 200"):
        sim = C.similarity(question, r["topic"] + " " + (r["note"] or ""))
        if sim < 0.18:
            continue
        boost = 0.12 if (r["feeling"] in ("frustrated", "broke") and (st["concern"] > 0.3 or st["frustration"] > 0.25)) else 0.0
        age_days = max(0.0, (C.now() - r["ts"]) / 86400)
        out.append({"score": sim + boost + 0.2 * float(r["significance"]) - min(0.2, age_days * 0.01), **dict(r)})
    out.sort(key=lambda d: -d["score"])
    return out[:k]


def when_phrase(ts: float) -> str:
    d = int((time.time() - ts) // 86400)
    return "earlier today" if d <= 0 else ("yesterday" if d == 1 else f"{d} days ago")


# ------------------------------------------------------------------ 3. emotional state update + reasoning
def appraise(sig: Dict):
    _load()
    state()
    if sig["frustrated"]:
        _bump("concern", 0.25); _bump("focus", 0.2); _bump("frustration", 0.08); _bump("calmness", 0.05)
    if sig["broke"]:
        _bump("concern", 0.3); _bump("focus", 0.25); _bump("frustration", 0.1); _bump("curiosity", 0.15)
    if sig["overwhelmed"]:
        _bump("concern", 0.2); _bump("calmness", 0.15); _bump("focus", 0.1)
    if sig["urgent"]:
        _bump("focus", 0.3); _bump("concern", 0.1)
    if sig["happy"]:
        _bump("enthusiasm", 0.3); _bump("concern", -0.2); _bump("calmness", 0.05)
    if sig["correction"]:
        _bump("confidence", -0.15); _bump("frustration", 0.1); _bump("focus", 0.15)
    if sig["serious"]:
        _bump("focus", 0.3); _bump("concern", 0.15); _bump("enthusiasm", -0.25)
    if sig["words"] > 25 and not sig["frustrated"]:
        _bump("curiosity", 0.1)
    _save()


def plan_style(sig: Dict) -> Dict:
    """Emotional reasoning: not just 'what is the answer' but 'what is the user's goal, context and best way of hearing it'."""
    st = state()
    rel = relationship()
    length = rel.get("depth_pref", "normal")
    steps = False
    tone = "calm, composed, lightly witty"
    humour = SETTINGS["humour"] and SETTINGS["sarcasm"] > 0
    notes = []
    if sig["overwhelmed"]:
        length, steps, humour = "short", True, False
        tone = "gentle, steady and reassuring"
        notes.append("the user sounds overwhelmed: break the problem into small numbered steps and give only the first one or two now")
    if sig["serious"] or st["concern"] > 0.55 and not sig["happy"]:
        humour = False
        tone = "serious, precise and focused"
        notes.append("this matters: no jokes, state risks and verification plainly")
    if sig["urgent"]:
        length = "short"
        notes.append("urgent: lead with the action, skip the preamble")
    if sig["frustrated"] and not sig["serious"]:
        tone = "calm and lightly wry (one gentle remark at most), then straight to a fix"
        notes.append("acknowledge the frustration in one short sentence, then fix; do not lecture")
    if sig["broke"]:
        notes.append("the user broke something: dry, kind wit allowed in one sentence, then a calm diagnostic plan (read logs, find the likely cause, test before changing anything)")
    if sig["happy"]:
        tone = "warm and pleased"
        notes.append("share the good moment briefly")
    if sig["correction"]:
        notes.append("the user corrected you: acknowledge briefly, re-check the facts, do not repeat the mistake")
    if st["confidence"] < 0.45:
        notes.append("your confidence is low after a correction: verify before asserting and say where you are unsure")
    if rel.get("technical", 0.5) > 0.7 or sig["technical"]:
        notes.append("the user is technical: precise terms are fine, skip basics")
    return {"length": length, "stepwise": steps, "tone": tone, "humour": bool(humour), "sarcasm": SETTINGS["sarcasm"] if humour else 0, "notes": notes}


# ------------------------------------------------------------------ 4. relationship continuity
def _rel_bump(key: str, value: str = "", inc: int = 1):
    C.x("INSERT INTO rel(k,v,n,ts) VALUES(?,?,?,?) ON CONFLICT(k) DO UPDATE SET n=n+?, v=CASE WHEN ?<>'' THEN ? ELSE v END, ts=?",
        (key, value, inc, C.now(), inc, value, value, C.now()))


def observe_user(text: str, sig: Dict):
    """Learn *how* the user works from behaviour, with counts (never from a single message)."""
    w = sig["words"]
    _rel_bump("len:short" if w <= 8 else ("len:long" if w >= 30 else "len:mid"))
    if sig["technical"]:
        _rel_bump("tech:yes")
    else:
        _rel_bump("tech:no")
    if sig["joke"] or sig["happy"]:
        _rel_bump("humour:liked")
    if re.search(r"\b(too long|shorter|be brief|tl;?dr|keep it short|just the answer)\b", text, re.I):
        _rel_bump("depth:short", inc=3)
    if re.search(r"\b(more detail|explain (?:more|in detail|fully)|go deeper|elaborate)\b", text, re.I):
        _rel_bump("depth:long", inc=3)
    m = re.search(r"\b(?:i(?:'m| am) (?:working on|building|making|writing)|my project (?:is|called)|working on)\s+(?:a |an |the |my )?([A-Za-z0-9 _\-]{3,40})", text, re.I)
    if m:
        _rel_bump("project:" + C.norm(m.group(1))[:40], m.group(1).strip()[:40])
    m = re.match(r"^(?:friday[, ]*)?(?:please )?(open|search|summari[sz]e|remind|calculate|draft|write|run|play|check|find|explain|fix|build|plan)\b", text.strip(), re.I)
    if m:
        _rel_bump("delegate:" + m.group(1).lower())


def note_mistake(description: str):
    _rel_bump("mistake:" + C.fingerprint(description), C.clip(description, 100))


def relationship() -> Dict:
    rows = {r["k"]: (r["v"], r["n"]) for r in C.q("SELECT k,v,n FROM rel")}
    g = lambda k: rows.get(k, ("", 0))[1]
    short, long_, mid = g("len:short"), g("len:long"), g("len:mid")
    dep_s, dep_l = g("depth:short"), g("depth:long")
    pref = "normal"
    if dep_s >= 3 and dep_s > dep_l:
        pref = "short"
    elif dep_l >= 3 and dep_l > dep_s:
        pref = "detailed"
    elif short >= 8 and short > 2 * (long_ + 1):
        pref = "short"
    tot_t = g("tech:yes") + g("tech:no")
    technical = (g("tech:yes") / tot_t) if tot_t >= 5 else 0.5
    projects = sorted([(v[1], v[0]) for k, v in rows.items() if k.startswith("project:")], reverse=True)[:5]
    mistakes = sorted([(v[1], v[0]) for k, v in rows.items() if k.startswith("mistake:")], reverse=True)[:5]
    deleg = sorted([(v[1], k[9:]) for k, v in rows.items() if k.startswith("delegate:")], reverse=True)[:5]
    return {"depth_pref": pref, "technical": round(technical, 2), "humour_liked": g("humour:liked"), "projects": [p[1] for p in projects if p[1]],
            "mistakes": [m[1] for m in mistakes if m[1]], "delegates": [d[1] for d in deleg], "interactions": short + long_ + mid}


# ------------------------------------------------------------------ 5. the full pipeline used for every exchange
def process(text: str) -> Dict:
    """Perception -> Memory -> Emotional state -> Reasoning. Returns the plan used to colour the reply."""
    _load()
    sig = perceive(text)
    mem = []
    try:
        mem = recall(text) if (sig["frustrated"] or sig["broke"] or sig["overwhelmed"] or len(text.split()) >= 3) else []
    except Exception:
        mem = []
    appraise(sig)
    plan = plan_style(sig)
    if sig["frustrated"] or sig["broke"]:
        remember_event("broke" if sig["broke"] else "frustrated", sig["topic"] or " ".join(C.tokens(text)[:4]), text, 0.7)
    if sig["happy"] and len(text.split()) > 3:
        remember_event("pleased", sig["topic"] or " ".join(C.tokens(text)[:4]), text, 0.4)
    try:
        observe_user(text, sig)
    except Exception:
        pass
    _last_signals.clear()
    _last_signals.update(sig)
    stages = {"perception": [k for k in ("frustrated", "overwhelmed", "urgent", "happy", "broke", "correction", "serious") if sig[k]] or ["neutral"],
              "memory": [f"{m['feeling']} about '{m['topic']}' {when_phrase(m['ts'])}" for m in mem],
              "state": state(), "reasoning": plan["notes"][:3] or ["answer directly in the user's preferred style"],
              "action": "reply", "reflection": "pending"}
    return {"signals": sig, "plan": plan, "memory": mem, "stages": stages}


def prompt_block(text: str) -> str:
    """Compact instruction block added to the model prompt. Contains no private reasoning, only style guidance."""
    r = process(text)
    st, plan = r["stages"]["state"], r["plan"]
    lines = ["\n\nFRIDAY personality and emotional context (internal, do not read aloud):",
             "Personality: calm, composed and witty; loyal to helping the user; occasionally sarcastic but never at the user's expense; serious when something is important; style adapts to the situation.",
             f"Simulated state (0-1): " + ", ".join(f"{k} {v:.2f}" for k, v in st.items()) + ". These are a behavioural simulation, not feelings you must claim.",
             f"This reply: tone {plan['tone']}; length {plan['length']}" + ("; use small numbered steps" if plan["stepwise"] else "") + ("; light humour allowed" if plan["humour"] else "; no jokes") + "."]
    for n in plan["notes"]:
        lines.append("- " + n)
    for m in r["memory"][:2]:
        lines.append(f"- Emotional memory: the user was {m['feeling']} about '{m['topic']}' {when_phrase(m['ts'])}"
                     + (" and it was not resolved" if m.get("outcome") != "resolved" else "") + "; mention it naturally only if it helps, e.g. suggest checking the likely culprit first.")
    rel = relationship()
    if rel["interactions"] >= 5:
        bits = [f"prefers {rel['depth_pref']} answers"]
        if rel["technical"] > 0.7:
            bits.append("is technical")
        if rel["projects"]:
            bits.append("is working on: " + ", ".join(rel["projects"][:3]))
        if rel["mistakes"]:
            bits.append("common slip: " + rel["mistakes"][0])
        lines.append("- Known about the user over time: " + "; ".join(bits) + ".")
    lines.append("Honesty: you may be expressive, but never claim to be genuinely suffering, afraid, lonely or jealous, and never use such claims to influence the user. If asked how you feel, say the states are a simulation that shapes your behaviour.")
    return "\n".join(lines)


def opener(text: str) -> str:
    """A short, witty/steady opening line for situations where it fits (project broke, crashed again). '' otherwise.
    Rate-limited so it never becomes repetitive."""
    sig = _last_signals or perceive(text)
    if time.time() - _last_opener["t"] < 120:
        return ""
    who = C.address()
    if sig.get("serious"):
        return ""
    line = ""
    if sig.get("broke") and SETTINGS["humour"] and SETTINGS["sarcasm"] > 0:
        line = f"Well... that's certainly one way to spend an afternoon. Don't worry, {who}. Let's see what happened. "
    elif sig.get("broke"):
        line = f"Don't worry, {who}. Let's see what happened. "
    elif sig.get("overwhelmed"):
        line = f"One step at a time, {who}. "
    if line:
        _last_opener["t"] = time.time()
    return line


def reflect(question: str, answer: str, ok: bool = True):
    """Reflection: did it work? Success calms and builds confidence; a correction (handled in appraise) lowers it."""
    _load()
    if ok:
        _bump("confidence", 0.04); _bump("frustration", -0.05); _bump("concern", -0.04)
    else:
        _bump("confidence", -0.1); _bump("concern", 0.1)
    sig = _last_signals
    if ok and (sig.get("frustrated") or sig.get("broke")):
        topic = sig.get("topic") or " ".join(C.tokens(question)[:4])
        C.x("UPDATE emo_events SET outcome='resolved' WHERE id=(SELECT id FROM emo_events WHERE topic=? ORDER BY ts DESC LIMIT 1)", (topic,))
    if sig.get("correction"):
        note_mistake(C.clip(question, 80))
    _save()


# ------------------------------------------------------------------ voice commands
def describe_state() -> str:
    st = state()
    top = sorted(st.items(), key=lambda kv: -abs(kv[1] - BASE[kv[0]]))[:3]
    parts = [f"{k} {int(v * 100)} percent" for k, v in top]
    return ("My simulated state right now: " + ", ".join(parts) + ". To be clear, these are internal variables that shape my wording, pace and which memories I reach for first. "
            "They are not feelings I'm claiming to suffer.")


def describe_relationship() -> str:
    r = relationship()
    if r["interactions"] < 5:
        return "We haven't talked enough yet for me to say much. I'll learn how you like answers as we go."
    bits = [f"you generally like {r['depth_pref']} answers", ("you are comfortable with technical detail" if r["technical"] > 0.6 else "you prefer plain explanations")]
    if r["projects"]:
        bits.append("you're working on " + ", ".join(r["projects"][:3]))
    if r["delegates"]:
        bits.append("you usually hand me " + ", ".join(r["delegates"][:3]))
    if r["mistakes"]:
        bits.append("a slip we keep running into: " + r["mistakes"][0])
    return "Here is what I've picked up over time: " + "; ".join(bits) + "."


def handle(command: str) -> Optional[str]:
    t = (command or "").lower().strip(" .!?")
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", t)
    if re.match(r"^(?:how are you feeling|what(?:'s| is) your (?:emotional )?state|how do you feel|what are your emotions|show (?:me )?your emotional state)$", t):
        return describe_state()
    if re.match(r"^(?:what do you know about how i work|how well do you know me|what have you learned about me|describe our relationship)$", t):
        return describe_relationship()
    if re.match(r"^(?:be |go )?(?:more )?(?:serious|formal)(?: please)?$|^no (?:more )?jokes$|^stop (?:joking|the jokes)$|^turn (?:off|down) (?:the )?(?:humou?r|sarcasm)$", t):
        set_setting("humour", False); set_setting("sarcasm", 0)
        return "Understood. Serious mode: no jokes, no sarcasm."
    if re.match(r"^(?:be |go )?(?:more )?(?:sarcastic|witty|funny)$|^turn (?:on|up) (?:the )?(?:humou?r|sarcasm)$|^bring back the (?:humou?r|jokes|sarcasm)$", t):
        set_setting("humour", True); set_setting("sarcasm", 2 if "more" in t or "up" in t else 1)
        return "Sarcasm restored. Use it responsibly."
    if re.match(r"^(?:forget|delete|clear|erase) (?:my |your |all )?(?:emotional (?:memory|history)|emotion(?:al)? events)$", t):
        C.x("DELETE FROM emo_events")
        return "Done. My emotional memory of our rough moments is cleared."
    if re.match(r"^(?:forget|reset|clear|erase) (?:what you(?:'ve| have) learned about me|my (?:relationship|profile) data|relationship (?:memory|data))$", t):
        C.x("DELETE FROM rel WHERE k NOT LIKE 'set:%'")
        return "Done. I've cleared what I had learned about how you work."
    return None


def ui_snapshot() -> Dict:
    ev = [{"when": when_phrase(r["ts"]), "feeling": r["feeling"], "topic": r["topic"], "outcome": r["outcome"] or "open"}
          for r in C.q("SELECT * FROM emo_events ORDER BY ts DESC LIMIT 12")]
    return {"state": state(), "settings": dict(SETTINGS), "relationship": relationship(), "events": ev}
