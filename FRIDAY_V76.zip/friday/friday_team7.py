"""FRIDAY 7.0 specialist agent team (roadmap #6).

Five specialists - research, coding, finance, document, computer-control - each with a defined role, a fixed tool allow-list and an output
contract.  They run *under the orchestrator's controller*: the controller picks the specialists a goal needs, runs them with bounded
concurrency (at most 2 at once, 1 in light mode, and never more than one model call at a time), and then **reconciles** what they
return: conflicting figures are surfaced and resolved in favour of the deterministic source, never silently averaged.

    plan_team(goal)           which specialists, in what order, and why
    run_team(goal, ...)       run them and reconcile -> {"ok", "results", "conflicts", "reconciled", "text"}
    reconcile(results)        the controller's decision step (also usable on its own)
"""
from __future__ import annotations

import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

AGENTS: Dict[str, Dict] = {
    "research": {"role": "Finds and cross-checks information in sources; never edits files or runs code.",
                 "tools": ["investigate", "web_research", "memory_search"], "needs_model": False, "deterministic": False},
    "coding": {"role": "Inspects, reviews and tests code in isolation; proposes patches but never applies them to production code.",
               "tools": ["repair_inspect", "code_review", "code_map", "run_tests", "verify_build"], "needs_model": False, "deterministic": True},
    "finance": {"role": "Costs, compares and budget-checks using recorded prices; keeps estimates separate from recorded figures.",
                "tools": ["cost_recipe", "compare_costs", "budget_check", "finance_snapshot", "calc"], "needs_model": False, "deterministic": True},
    "document": {"role": "Turns findings into a structured, cited document and saves it where you asked.",
                 "tools": ["synthesize", "save_report", "think"], "needs_model": True, "deterministic": False},
    "computer": {"role": "Operates the PC through supported APIs (apps, files, windows) and checks each action took effect.",
                 "tools": ["computer_act", "capture_verify", "system_info", "analyze_folder"], "needs_model": False, "deterministic": True},
}

_ROLE_RX = {
    "research": re.compile(r"\b(research|investigate|look up|find out|sources?|compare|evidence|fact[- ]check|news|latest)\b", re.I),
    "coding": re.compile(r"\b(code|bug|script|function|repo|project|tests?|refactor|debug|lint|compile|build)\b", re.I),
    "finance": re.compile(r"\b(cost|price|prices|budget|cheap(?:er|est)?|save money|expenses?|income|grocer\w*|ingredients?|recipes?|afford|spend\w*)\b", re.I),
    "document": re.compile(r"\b(report|document|summary|summari[sz]e|write up|notes|essay|brief|save|findings)\b", re.I),
    "computer": re.compile(r"\b(open|close|launch|maximi[sz]e|minimi[sz]e|screenshot|screen|window|folder|desktop|downloads|organi[sz]e|files?)\b", re.I),
}
_ORDER = ["research", "finance", "coding", "computer", "document"]      # document last: it consumes the others
_model_gate = threading.Semaphore(1)
MAX_PARALLEL = 2


def plan_team(goal: str) -> Dict:
    roles = [r for r in _ORDER if _ROLE_RX[r].search(goal)]
    if "document" in roles and len(roles) == 1:
        pass
    if not roles:
        roles = ["research"] if re.search(r"\?|\b(what|why|how|who|when)\b", goal, re.I) else []
    return {"roles": roles, "parallel": [r for r in roles if r != "document"], "final": "document" if "document" in roles else "",
            "why": {r: AGENTS[r]["role"] for r in roles}}


# ------------------------------------------------------------------ specialists
def _tool(agent: str, name: str, args: Dict, timeout: float = 60.0) -> Dict:
    """Run one allow-listed tool through the verification engine (receipts, postconditions, retries)."""
    import friday_orchestrator7 as O
    import friday_verify7 as V
    import friday_policy7 as POL
    if name not in AGENTS[agent]["tools"]:
        return {"ok": False, "error": f"{agent} agent may not use {name}", "output": ""}
    if not O.registry.has(name):
        return {"ok": False, "error": f"{name} is not available", "output": ""}
    dec = POL.decide(name, args, source="user", job=f"team-{agent}")
    if dec["decision"] != "allow":
        return {"ok": False, "error": f"{name} needs permission ({dec['reason']})", "output": "", "needs_approval": dec["decision"] == "ask"}
    e = O.registry.get(name)
    rec = V.execute(e["fn"], args, tool=name, post=e.get("post") or None, job=f"team-{agent}", step=0, idempotent=e.get("idempotent", True), timeout=min(e.get("timeout", 60.0), timeout))
    return {"ok": rec["ok"], "output": rec.get("output", ""), "error": rec.get("error", ""), "receipt": rec.get("id"), "verified": bool(rec.get("verified", rec["ok"])), "path": (rec.get("result") or {}).get("path", "")}


def _numbers(text: str) -> List[Dict]:
    out = []
    for m in re.finditer(r"(?P<label>[A-Za-z][A-Za-z ]{2,40}?)\s*(?:is|are|costs?|=|:|totals?|comes to|about|around)\s*(?:about |around |approximately )?[\$£€₹]?\s*(?P<n>\d[\d,]*(?:\.\d+)?)\s*(?P<unit>%|percent|[A-Za-z]{2,8})?", text or ""):
        try:
            out.append({"label": m.group("label").strip().lower()[-30:], "value": float(m.group("n").replace(",", "")), "unit": (m.group("unit") or "").lower()})
        except Exception:
            continue
    return out[:30]


def run_agent(agent: str, goal: str, context: Optional[Dict] = None, path: str = ".") -> Dict:
    t0 = time.time()
    ctx = context or {}
    res: Dict = {"agent": agent, "ok": False, "output": "", "evidence": [], "claims": [], "error": ""}
    try:
        if agent == "research":
            r = _tool("research", "investigate", {"question": goal}, 90.0)
            if not r["ok"]:
                r = _tool("research", "web_research", {"query": goal}, 90.0)
        elif agent == "coding":
            r = _tool("coding", "repair_inspect", {"path": path}, 60.0)
            if not r["ok"]:
                r = _tool("coding", "code_review", {"path": path}, 60.0)
        elif agent == "finance":
            r = _tool("finance", "cost_recipe", {"text": goal}, 30.0)
            if r["ok"] and re.search(r"\b(cheaper|alternatives?|compare|vs\.?|versus)\b", goal, re.I):
                c = _tool("finance", "compare_costs", {"text": goal, "research": ctx.get("research", "")}, 30.0)
                if c["ok"]:
                    r["output"] += "\n" + c["output"]
            if not r["ok"] and re.search(r"\b(budget|income|expenses?)\b", goal, re.I):
                r = _tool("finance", "finance_snapshot", {}, 30.0)
        elif agent == "computer":
            r = _tool("computer", "computer_act", {"command": goal}, 60.0)
        elif agent == "document":
            body = "\n\n".join(f"[{k}]\n{v}" for k, v in ctx.items() if v)
            r = _tool("document", "synthesize", {"topic": goal, "material": body}, 90.0)
        else:
            r = {"ok": False, "output": "", "error": "unknown agent"}
        res.update({"ok": r["ok"], "output": r.get("output", ""), "error": r.get("error", ""), "path": r.get("path", "")})
        if r.get("receipt"):
            res["evidence"].append({"receipt": r["receipt"], "verified": r.get("verified", False)})
        res["claims"] = _numbers(res["output"])
        res["deterministic"] = AGENTS[agent]["deterministic"]
    except Exception as exc:
        res["error"] = f"{type(exc).__name__}: {exc}"[:200]
    res["seconds"] = round(time.time() - t0, 2)
    return res


# ------------------------------------------------------------------ controller
def reconcile(results: List[Dict]) -> Dict:
    """Compare what the agents said. Same label, different value => conflict. A deterministic, receipt-backed result wins over prose."""
    conflicts, resolved = [], []
    by_label: Dict[str, List[Dict]] = {}
    for r in results:
        for c in r.get("claims", []):
            by_label.setdefault(c["label"], []).append({**c, "agent": r["agent"], "deterministic": r.get("deterministic", False), "verified": any(e.get("verified") for e in r.get("evidence", []))})
    for label, claims in by_label.items():
        vals = sorted({round(c["value"], 4) for c in claims})
        if len(vals) < 2:
            continue
        lo, hi = vals[0], vals[-1]
        if hi == 0 or (hi - lo) / max(abs(hi), 1e-9) < 0.05:
            continue            # within rounding / 5 percent
        det = [c for c in claims if c["deterministic"] and c["verified"]]
        entry = {"label": label, "values": [{"agent": c["agent"], "value": c["value"]} for c in claims]}
        if det and len({round(c["value"], 4) for c in det}) == 1:
            entry["resolution"] = f"used {det[0]['value']:g} from the {det[0]['agent']} agent (calculated and verified), not the figure quoted in prose"
            entry["chosen"] = det[0]["value"]
            resolved.append(entry)
        else:
            entry["resolution"] = "unresolved - I can't tell which is right, so both are shown"
            conflicts.append(entry)
    failed = [r["agent"] for r in results if not r["ok"]]
    verified_n = sum(1 for r in results if any(e.get("verified") for e in r.get("evidence", [])))
    return {"conflicts": conflicts, "resolved": resolved, "failed": failed, "verified_agents": verified_n, "agents": len(results)}


def run_team(goal: str, path: str = ".", agents: Optional[List[str]] = None) -> Dict:
    plan = plan_team(goal) if not agents else {"roles": agents, "parallel": [a for a in agents if a != "document"], "final": "document" if "document" in agents else "", "why": {}}
    if not plan["roles"]:
        return {"ok": False, "text": "None of the specialists applies to that request.", "results": [], "conflicts": [], "plan": plan}
    light = False
    try:
        import friday_health7 as H
        light = H.light_mode()
    except Exception:
        pass
    width = 1 if light else MAX_PARALLEL
    results: List[Dict] = []
    ctx: Dict[str, str] = {}
    # finance may use research text, so research runs first when both are wanted; everything else that is independent runs together
    first = [a for a in plan["parallel"] if a == "research"]
    rest = [a for a in plan["parallel"] if a != "research"]
    for batch in ([first] if first else []) + ([rest] if rest else []):
        if len(batch) == 1:
            r = run_agent(batch[0], goal, ctx, path)
            results.append(r)
        else:
            with ThreadPoolExecutor(max_workers=width, thread_name_prefix="team") as ex:
                futs = [ex.submit(run_agent, a, goal, dict(ctx), path) for a in batch]
                for f in futs:
                    try:
                        results.append(f.result(timeout=150))
                    except Exception as exc:
                        results.append({"agent": "?", "ok": False, "output": "", "error": str(exc)[:120], "evidence": [], "claims": []})
        for r in results:
            if r["ok"] and r["agent"] not in ctx:
                ctx[r["agent"]] = r["output"]
    if plan["final"]:
        if AGENTS["document"]["needs_model"]:
            with _model_gate:
                results.append(run_agent("document", goal, ctx, path))
    rec = reconcile(results)
    ok = bool(results) and all(r["ok"] for r in results) and not rec["conflicts"]
    lines = []
    for r in results:
        lines.append(f"{r['agent'].capitalize()} agent: " + ("done" if r["ok"] else f"did not finish ({r['error'] or 'no result'})") + (" - verified" if any(e.get("verified") for e in r["evidence"]) else ""))
    for c in rec["resolved"]:
        lines.append(f"Reconciled '{c['label']}': {c['resolution']}.")
    for c in rec["conflicts"]:
        lines.append(f"Conflict on '{c['label']}': " + ", ".join(f"{v['agent']} says {v['value']:g}" for v in c["values"]) + " - " + c["resolution"] + ".")
    K.emit("team.done", {"goal": goal, "agents": plan["roles"], "ok": ok})
    return {"ok": ok, "plan": plan, "results": results, "conflicts": rec["conflicts"], "reconciled": rec["resolved"], "text": " ".join(lines), "output": "\n\n".join(r["output"] for r in results if r["output"])[:6000]}


def tool_team_run(a: Dict) -> Dict:
    r = run_team(str(a.get("goal") or a.get("text") or ""), path=str(a.get("path", ".")), agents=a.get("agents"))
    return {"ok": r["ok"] or any(x["ok"] for x in r["results"]), "output": r["text"] + ("\n\n" + r["output"] if r.get("output") else ""), "error": "" if r["ok"] else r["text"][:200]}


def install(registry):
    registry.register("team_run", tool_team_run, risk="safe", desc="run the specialist agent team (research, coding, finance, document, computer) and reconcile their results", timeout=240.0, agent="team")


# ------------------------------------------------------------------ chat
def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    m = re.match(r"^(?:use|ask|run|call|bring in)\s+(?:the\s+|your\s+)?(?:specialist\s+)?(?:agent )?team\s+(?:to|for|on|about)?\s*(.+)$", t) or re.match(r"^(?:team up (?:on|to)|get the agents to)\s+(.+)$", t)
    if m:
        raw = re.sub(r"^(?:use|ask|run|call|bring in)\s+(?:the\s+|your\s+)?(?:specialist\s+)?(?:agent )?team\s+(?:to|for|on|about)?\s*", "", K.strip_wake(command), flags=re.I)
        raw = re.sub(r"^(?:team up (?:on|to)|get the agents to)\s+", "", raw, flags=re.I)
        plan = plan_team(raw or m.group(1))
        if not plan["roles"]:
            return "I don't see a specialist for that. Try research, coding, money, a document, or a computer task."
        try:
            import friday_orchestrator7 as O
            jid = O.submit(raw or m.group(1), plan={"steps": [{"id": 0, "desc": "Run the specialist team: " + ", ".join(plan["roles"]), "tool": "team_run", "args": {"goal": "{goal}"}, "depends": [], "post": {"nonempty": True},
                                                                  "expect": {}, "optional": False, "alternatives": [], "risk": "safe", "status": "pending", "attempts": 0}], "template": "team"}, intent="team")
            return f"Bringing in the {', '.join(plan['roles'])} specialists. I'll reconcile what they find and tell you where they disagree."
        except Exception as exc:
            return f"I couldn't start the team: {exc}"
    if re.match(r"^(?:who(?:'s| is) on (?:your|the) team|what specialists do you have|list (?:your )?(?:agents|specialists))\??$", t):
        return "Specialists: " + "; ".join(f"{a} ({d['role'].split(';')[0].rstrip('.').lower()})" for a, d in AGENTS.items()) + ". I run at most two at once and reconcile their answers."
    return None


def ui_snapshot() -> Dict:
    return {"agents": [{"name": a, "role": d["role"], "tools": d["tools"]} for a, d in AGENTS.items()]}
