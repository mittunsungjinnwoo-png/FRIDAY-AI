# FRIDAY 7.0 — Advanced AI Assistant (standalone)

This build keeps FRIDAY's existing microphone, listening, recognition/VAD and TTS path intact and adds the requested Jarvis-derived capability layers.

## Included

- Existing FRIDAY voice/listen/recognition pipeline preserved.
- Jarvis-derived additive movie-agent, adaptive-learning and apex-intelligence modules.
- Existing FRIDAY autonomy, desktop control, web research, memory, WhatsApp, notes and finance stack retained.
- Study Mode intentionally not added.
- Secure API-key Settings panel using Electron OS secure storage.
- No API key hard-coded into the application.
- Native desktop file picker from the chat Attach button.
- Local attachment intelligence for:
  - source code and text files
  - PDF/DOCX/PPTX/XLSX/ODS/ODT
  - images with OCR when Tesseract is available
  - videos with metadata; supported images/videos are also uploaded to Gemini for multimodal analysis when the user asks FRIDAY to work with them
  - ZIP archives with safe listings and text/code excerpts
- Deterministic finance calculations plus personalized budgeting/savings advice.
- Existing animated HUD/reactor UI preserved.
- Electron packaged with `asar: false` so the Python backend and local state can operate normally.
- First-run private Python bootstrap: the packaged app can download its own embedded Python runtime and dependencies. The user does not manually install Python or Node.js.

## Building the Windows installer

Run `BUILD_WINDOWS.bat` on a Windows development machine with Node.js/npm.

The resulting installer is:
`dist\FRIDAY-Standalone-Setup-2.2.0.exe`

Node.js is a build-time dependency only. The installed FRIDAY application does not require Node.js.

## Important

Gemini/API access still requires internet access and a valid user-provided API key. On a computer without Python, first launch downloads a private Python runtime and installs FRIDAY’s Python dependencies into FRIDAY’s own user-data folder. This first-run setup requires internet access; users do not need to manually install Python, Node.js, or the listed Python packages. The installer is not fully offline/self-contained until those runtime files are included in the installer itself.

The developer environment used to prepare this package cannot download npm packages or cross-compile a Windows Electron binary, so the actual `.exe` must be produced on a Windows build machine using the included build script.


### Gemini model setting
The Settings > AI panel now stores an exact Gemini model ID locally and sends it to the live backend. The default is `gemini-3.1-flash-lite`; users can replace it with any model ID their Gemini API key supports. The model is not hard-coded into the user's key configuration.


## Windows shortcuts
The NSIS installer creates a Desktop shortcut and a Start Menu entry named FRIDAY. The app remains installed after first launch; use either shortcut or the installed executable.


### Windows shortcut persistence
FRIDAY 2.2.3 explicitly creates a per-user Desktop shortcut and a Start Menu shortcut on first packaged launch, in addition to the NSIS installer shortcuts. This prevents the app from disappearing from Windows Search after the first run.
