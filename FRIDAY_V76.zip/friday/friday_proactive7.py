"""FRIDAY 7.0 proactive intelligence (roadmap #28) - suggestions, never surprises.

FRIDAY may notice that something needs attention - an objective close to its deadline, a blocked or stalled objective, a paused mission, a price you track that has gone stale,
an improvement idea she found - and queue a SUGGESTION.  A suggestion is only text plus the exact command she would run; she never runs it herself.  You say "do suggestion 1"
(or tap it) to run it, "dismiss suggestion 1" to drop it (it will not return for a week), "snooze suggestion 1" to hear it later, "stop suggestions" to turn the whole thing off.

Limits you can change in Settings: proactive_enabled, proactive_speak (default off: shown on screen, not spoken), proactive_max_per_day, proactive_min_gap_min, quiet_start/quiet_end.
Suggestions are not surfaced while FRIDAY is speaking or busy, or in light mode (low-RAM protection).  Asking "any suggestions?" always works.
"""
from __future__ import annotations

import re
import time
from typing import Callable, Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS suggestions7(id INTEGER PRIMARY KEY, ts REAL, kind TEXT, key TEXT, text TEXT, command TEXT, prio INTEGER DEFAULT 5, state TEXT DEFAULT 'new', shown_ts REAL, until REAL, acted REAL);
CREATE INDEX IF NOT EXISTS ix_suggestions7_key ON suggestions7(key);
""")

DISMISS_COOLDOWN_S = 7 * 86400
ACCEPT_COOLDOWN_S = 3 * 86400
STALE_DAYS = 7
PRICE_STALE_DAYS = 45
_cfg: Dict = {"run": None}
_last_list: List[int] = []
_list_ts = {"t": 0.0}
LIST_TTL_S = 600.0


def configure(run: Optional[Callable[[str], Optional[str]]] = None):
    if run is not None:
        _cfg["run"] = run


# ------------------------------------------------------------------ quiet hours / limits
def _minutes(hhmm: str, default: int) -> int:
    m = re.match(r"^\s*(\d{1,2}):(\d{2})\s*$", hhmm or "")
    return int(m.group(1)) * 60 + int(m.group(2)) if m and int(m.group(1)) < 24 and int(m.group(2)) < 60 else default


def in_quiet_hours(now: Optional[float] = None) -> bool:
    lt = time.localtime(now or time.time())
    cur = lt.tm_hour * 60 + lt.tm_min
    a, b = _minutes(K.cfg_get("quiet_start"), 22 * 60), _minutes(K.cfg_get("quiet_end"), 7 * 60)
    return (a <= cur or cur < b) if a > b else (a <= cur < b)


def _int(key: str, default: int) -> int:
    try:
        return max(0, int(float(K.cfg_get(key))))
    except Exception:
        return default


def shown_today(now: Optional[float] = None) -> int:
    lt = time.localtime(now or time.time())
    start = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
    return C.q("SELECT COUNT(*) n FROM suggestions7 WHERE shown_ts>=?", (start,))[0]["n"]


def last_shown() -> float:
    r = C.q("SELECT MAX(shown_ts) m FROM suggestions7")
    return float(r[0]["m"] or 0)


# ------------------------------------------------------------------ candidates (each returns dicts: kind, key, text, command, prio)
def _from_goals() -> List[Dict]:
    out: List[Dict] = []
    try:
        import friday_goals7 as G
        now = time.time()
        for o in G.objectives():
            if o["progress"] >= 100:
                continue
            title = o["title"]
            hint = title if (G.find(title) or {}).get("oid") == o["oid"] else o["oid"]
            nxt = G.next_ready(o["oid"])
            nx = f" Next: {nxt['text']}." if nxt else ""
            if o["status"] == "blocked" or o["blockers"]:
                why = o["blockers"][0]["text"] if o["blockers"] else "a blocker is recorded"
                out.append({"kind": "blocked", "key": f"obj-blocked:{o['oid']}", "prio": 2, "command": f"what is blocking {hint}",
                            "text": f"'{title}' is blocked: {C.clip(why, 90)}."})
                continue
            if o.get("due") and o["due"] <= now + 72 * 3600:
                when = time.strftime("%a %d %b", time.localtime(o["due"]))
                over = o["due"] < now
                out.append({"kind": "due", "key": f"obj-due:{o['oid']}", "prio": 0 if over else 1, "command": f"work on {hint}",
                            "text": f"'{title}' {'was due' if over else 'is due'} {when} and is {o['progress']} percent done.{nx}"})
                continue
            idle_d = (now - (o.get("updated") or now)) / 86400
            if o["status"] == "active" and idle_d >= STALE_DAYS:
                out.append({"kind": "stale", "key": f"obj-stale:{o['oid']}", "prio": 4, "command": f"work on {hint}",
                            "text": f"'{title}' hasn't moved for {int(idle_d)} days ({o['progress']} percent done).{nx}"})
    except Exception as exc:
        C.log(f"proactive goals scan failed: {exc}", "recovery")
    return out


def _from_missions() -> List[Dict]:
    out: List[Dict] = []
    try:
        import friday_orchestrator7 as O
        cands = O.jobs(5, ("paused", "failed", "partial"))
        if cands and cands[0]["state"] == "paused" and time.time() - cands[0]["created"] < 14 * 86400:
            j = cands[0]
            done = sum(1 for s in j["plan"] if s.get("status") == "done")
            out.append({"kind": "mission", "key": f"job-paused:{j['jid']}", "prio": 2, "command": "resume the mission",
                        "text": f"The mission '{C.clip(j['goal'], 70)}' is paused after {done} verified step(s)."})
    except Exception as exc:
        C.log(f"proactive missions scan failed: {exc}", "recovery")
    return out


def _from_prices() -> List[Dict]:
    out: List[Dict] = []
    try:
        rows = C.q("SELECT norm, item, MAX(ts) last, COUNT(*) n FROM prices7 WHERE kind='recorded' AND source='user' GROUP BY norm HAVING n>=2 AND last<? ORDER BY last LIMIT 1", (time.time() - PRICE_STALE_DAYS * 86400,))
        for r in rows:
            out.append({"kind": "price", "key": f"price-stale:{r['norm']}", "prio": 6, "command": f"what is the price of {r['item']}",
                        "text": f"The price you track for {r['item']} was last recorded {int((time.time() - r['last']) / 86400)} days ago; it may have changed."})
    except Exception:
        pass
    return out


def candidates() -> List[Dict]:
    return sorted(_from_goals() + _from_missions() + _from_prices(), key=lambda c: c["prio"])


# ------------------------------------------------------------------ queue
def _upsert(c: Dict) -> Optional[int]:
    now = time.time()
    rows = C.q("SELECT * FROM suggestions7 WHERE key=? ORDER BY id DESC LIMIT 1", (c["key"],))
    if rows:
        r = rows[0]
        if r["state"] in ("new", "shown"):
            C.x("UPDATE suggestions7 SET text=?, command=?, prio=? WHERE id=?", (c["text"], c["command"], c["prio"], r["id"]))
            return r["id"]
        if r["state"] == "dismissed" and now - (r["acted"] or r["shown_ts"] or r["ts"]) < DISMISS_COOLDOWN_S:
            return None
        if r["state"] == "accepted" and now - (r["acted"] or r["shown_ts"] or r["ts"]) < ACCEPT_COOLDOWN_S:
            return None
        if r["state"] == "snoozed" and (r["until"] or 0) > now:
            return None
    return C.x("INSERT INTO suggestions7(ts,kind,key,text,command,prio,state) VALUES(?,?,?,?,?,?, 'new')", (now, c["kind"], c["key"], c["text"], c["command"], c["prio"]))


def refresh() -> List[Dict]:
    """Re-scan the sources, queue new suggestions, and retire ones whose condition no longer holds."""
    cs = candidates()
    live = set()
    for c in cs:
        sid = _upsert(c)
        if sid:
            live.add(sid)
    for r in C.q("SELECT id FROM suggestions7 WHERE state IN ('new','shown') AND key NOT LIKE 'note:%'"):
        if r["id"] not in live:
            C.x("UPDATE suggestions7 SET state='done' WHERE id=?", (r["id"],))
    return open_items()


def open_items(limit: int = 6) -> List[Dict]:
    now = time.time()
    C.x("UPDATE suggestions7 SET state='new' WHERE state='snoozed' AND until<=?", (now,))
    return [dict(r) for r in C.q("SELECT * FROM suggestions7 WHERE state IN ('new','shown') ORDER BY prio, id LIMIT ?", (limit,))]


def _mark_shown(ids: List[int], proactive: bool = True):
    """proactive=True counts against the daily limit; a list the user asked for does not."""
    for i in ids:
        if proactive:
            C.x("UPDATE suggestions7 SET state='shown', shown_ts=? WHERE id=? AND state IN ('new','shown')", (time.time(), i))
        else:
            C.x("UPDATE suggestions7 SET state='shown' WHERE id=? AND state='new'", (i,))


# ------------------------------------------------------------------ surfacing (called from the runtime tick; never acts)
def surface(now: Optional[float] = None) -> Optional[Dict]:
    if not K.cfg_flag("proactive_enabled") or K.busy():
        return None
    try:
        import friday_health7 as H
        if H.light_mode():
            return None
    except Exception:
        pass
    now = now or time.time()
    if shown_today(now) >= _int("proactive_max_per_day", 4) or now - last_shown() < _int("proactive_min_gap_min", 45) * 60:
        return None
    items = [i for i in refresh() if i["state"] == "new"]
    if not items:
        return None
    s = items[0]
    _mark_shown([s["id"]])
    K.emit_ui("suggestion", {"id": s["id"], "text": s["text"], "command": s["command"], "kind": s["kind"]})
    if K.cfg_flag("proactive_speak") and not in_quiet_hours(now):
        K.say(s["text"] + " Say 'do suggestion' to act on it, or 'dismiss suggestion'.")
    return s


def tick() -> Optional[Dict]:
    try:
        return surface()
    except Exception as exc:
        C.log(f"proactive tick failed: {exc}", "recovery")
        return None


def add_note(key: str, text: str, command: str = "", prio: int = 5):
    """Other modules (self-improvement) may queue a plain suggestion; it is still only shown, never run."""
    _upsert({"kind": "note", "key": f"note:{key}", "text": text, "command": command, "prio": prio})


# ------------------------------------------------------------------ actions
def _get(sid: int) -> Optional[Dict]:
    r = C.q("SELECT * FROM suggestions7 WHERE id=?", (sid,))
    return dict(r[0]) if r else None


def dismiss(sid: int) -> bool:
    return K.xn("UPDATE suggestions7 SET state='dismissed', acted=? WHERE id=? AND state IN ('new','shown','snoozed')", (time.time(), sid)) > 0


def snooze(sid: int, hours: float = 24) -> bool:
    return K.xn("UPDATE suggestions7 SET state='snoozed', until=? WHERE id=? AND state IN ('new','shown')", (time.time() + hours * 3600, sid)) > 0


def accept(sid: int) -> Dict:
    s = _get(sid)
    if not s or s["state"] not in ("new", "shown"):
        return {"ok": False, "text": "That suggestion is no longer open."}
    C.x("UPDATE suggestions7 SET state='accepted', acted=? WHERE id=?", (time.time(), sid))
    if not s["command"]:
        return {"ok": True, "text": "Noted. That one has no action to run."}
    run = _cfg.get("run")
    if not run:
        return {"ok": True, "text": f"Say: {s['command']}", "command": s["command"]}
    try:
        reply = run(s["command"])
    except Exception as exc:
        return {"ok": False, "text": f"I couldn't run it: {exc}", "command": s["command"]}
    return {"ok": True, "text": reply or f"Done: {s['command']}.", "command": s["command"]}


# ------------------------------------------------------------------ chat
def _pick(t: str) -> Optional[int]:
    """Which suggestion does the user mean? 'suggestion 2', 'the second one', or the only one shown."""
    m = re.search(r"\b(?:suggestion|number|no\.?|#)\s*(\d)\b", t)
    n = int(m.group(1)) if m else None
    if n is None:
        m = re.search(r"\b(first|second|third|fourth|1st|2nd|3rd)\b", t)
        n = K.ordinal_to_int(m.group(1)) if m else None
    if n is not None:
        return _last_list[n - 1] if 1 <= n <= len(_last_list) else None
    cur = open_items()
    shown = [c for c in cur if c["state"] == "shown"] or cur
    return shown[0]["id"] if len(shown) == 1 else (_last_list[0] if len(_last_list) == 1 else None)


def _list_text(items: List[Dict]) -> str:
    return "Here is what could use your attention: " + " ".join(f"{i}. {s['text']}" for i, s in enumerate(items, 1)) + " Say 'do suggestion 1', 'dismiss suggestion 2', or 'snooze suggestion 3'."


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if not t:
        return None
    if re.match(r"^(?:do you have |got |are there )?any (?:suggestions|proactive suggestions)(?: for me)?$|^what (?:should i|do i need to|needs my) (?:do next|work on(?: next)?|attention)$|^what needs my attention$|^show (?:me )?(?:my |the )?suggestions$", t):
        items = refresh()[:3]
        _last_list[:] = [s["id"] for s in items]
        _list_ts["t"] = time.time()
        if not items:
            return "Nothing needs your attention right now." if not t.startswith("what should") else None
        _mark_shown(_last_list, proactive=False)
        return _list_text(items)
    if re.match(r"^(?:stop|turn off|disable|no more) (?:the )?(?:proactive )?suggestions$|^stop (?:making|giving me) suggestions$", t):
        K.cfg_set("proactive_enabled", "0")
        return "Okay, I'll stop queueing suggestions. Say 'turn on suggestions' to bring them back."
    if re.match(r"^(?:turn on|enable|start) (?:the )?(?:proactive )?suggestions$", t):
        K.cfg_set("proactive_enabled", "1")
        return "Suggestions are back on. I'll only show them, never act on them without you."
    if re.match(r"^(?:speak|say) (?:the )?suggestions aloud$|^read suggestions aloud$", t):
        K.cfg_set("proactive_speak", "1")
        return f"I'll speak suggestions aloud when you're idle, but never between {K.cfg_get('quiet_start')} and {K.cfg_get('quiet_end')}."
    if re.match(r"^(?:don'?t|do not|stop) (?:speak|say|read)(?:ing)? (?:the )?suggestions(?: aloud)?$", t):
        K.cfg_set("proactive_speak", "0")
        return "Suggestions will be shown on screen only."
    m = re.match(r"^(do|accept|run|act on|yes (?:to|do)) (?:the |that |this )?(?:(?:first|second|third|fourth|1st|2nd|3rd) )?(?:suggestion|one)(?: (?:number |no\.? |#)?(\d))?$", t)
    if m and (re.search(r"suggestion", t) or (_last_list and time.time() - _list_ts["t"] < LIST_TTL_S)):
        sid = _pick(t)
        if not sid:
            return "Which suggestion? Say 'any suggestions' and I'll number them."
        return accept(sid)["text"]
    if re.match(r"^(?:dismiss|drop|ignore|reject) (?:the |that |this )?(?:(?:first|second|third|fourth|1st|2nd|3rd) )?suggestion(?: (?:number |no\.? |#)?\d)?$", t):
        sid = _pick(t)
        if not sid:
            return "Which suggestion? Say 'any suggestions' and I'll number them."
        return "Dismissed. I won't bring that one up again for a week." if dismiss(sid) else "That suggestion is already gone."
    m = re.match(r"^snooze (?:the |that |this )?(?:(?:first|second|third|fourth|1st|2nd|3rd) )?suggestion(?: (?:number |no\.? |#)?\d)?(?: for (\d+) (hour|day|week)s?)?$|^remind me about (?:the |that |this )?suggestion (?:later|tomorrow)$", t)
    if m:
        sid = _pick(t)
        if not sid:
            return "Which suggestion? Say 'any suggestions' and I'll number them."
        n, unit = (int(m.group(1)), m.group(2)) if m.group(1) else (1, "day")
        hours = n * {"hour": 1, "day": 24, "week": 168}[unit]
        return f"Snoozed. I'll bring it back in {n} {unit}{'s' if n != 1 else ''}." if snooze(sid, hours) else "That suggestion is already gone."
    return None


# ------------------------------------------------------------------ UI
def ui_snapshot() -> Dict:
    try:
        items = open_items(8)
    except Exception:
        items = []
    return {"suggestions": {"enabled": K.cfg_flag("proactive_enabled"), "speak": K.cfg_flag("proactive_speak"), "shown_today": shown_today(), "max_per_day": _int("proactive_max_per_day", 4),
                            "quiet_now": in_quiet_hours(), "items": [{"id": s["id"], "text": s["text"], "command": s["command"], "kind": s["kind"], "state": s["state"]} for s in items]}}


def handle_ui(req: Dict) -> Optional[Dict]:
    a = (req or {}).get("action")
    sid = int((req or {}).get("id") or 0)
    if a == "refresh":
        refresh()
        return ui_snapshot()
    if a == "accept":
        r = accept(sid)
        return {**r, **ui_snapshot()}
    if a == "dismiss":
        return {"ok": dismiss(sid), **ui_snapshot()}
    if a == "snooze":
        return {"ok": snooze(sid, float((req or {}).get("hours") or 24)), **ui_snapshot()}
    if a == "toggle":
        K.cfg_set("proactive_enabled", "1" if (req or {}).get("enabled") else "0")
        return ui_snapshot()
    return None


def install_events():
    def _found(p):
        try:
            add_note("improvement", f"I found {int((p or {}).get('count', 1))} improvement idea(s): " + "; ".join((p or {}).get("titles", [])[:2]) + ".", "list improvements", 7)
        except Exception:
            pass
    K.on("improvement.found", _found)
