"""
FRIDAY EVALUATION SYSTEM
========================
Records real counters while FRIDAY works and can run a reproducible benchmark suite, so a report can say
"FRIDAY completed X/Y benchmark tasks" instead of "it seems to work pretty well".

LIVE metrics (counted from real use, saved in friday_data/vision_metrics.json)
    task success rate, action success rate, verification success rate, recovery success rate,
    average vision-processing latency, average agent/LLM latency, safety decisions

BENCHMARK suite (synthetic scenes with known ground truth, so the numbers are measurable)
    vision detection accuracy (precision / recall / F1 / label accuracy / count accuracy)
    motion detection, visual-change detection, tracking continuity, OCR accuracy,
    OpenCV micro-benchmarks (resize, adaptive threshold, contours ... the operations COOL accelerates),
    agent loop on a simulated desktop (task / action / verification / recovery / safety)

Everything is labelled honestly: 'live' numbers come from this PC, 'benchmark' numbers from the suite.
"""
from __future__ import annotations

import difflib
import json
import os
import statistics
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

import friday_vision_config as cfg

METRICS_FILE = cfg.DATA_DIR / "vision_metrics.json"
EXPORT_DIR = cfg.DATA_DIR / "exports"
_LOCK = threading.RLock()
_DIRTY = {"n": 0, "t": 0.0}

_DEFAULT = {
    "since": 0.0,
    "counters": {"tasks": 0, "tasks_ok": 0, "actions": 0, "actions_ok": 0, "verifications": 0, "verifications_ok": 0,
                 "verifications_uncertain": 0, "recoveries": 0, "recoveries_ok": 0, "replans": 0,
                 "confirmations": 0, "approved": 0, "denied": 0, "blocked": 0, "auto_allowed": 0,
                 "vision_frames": 0, "cloud_calls": 0, "cloud_fallbacks": 0},
    "latency": {"vision_ms": [], "llm_ms": [], "task_s": [], "cloud_ms": []},
    "last_benchmark": {},
}
_M: dict[str, Any] = json.loads(json.dumps(_DEFAULT))
_LOADED = False


def _load() -> None:
    global _LOADED
    if _LOADED:
        return
    _LOADED = True
    _M["since"] = time.time()
    try:
        if METRICS_FILE.exists():
            raw = json.loads(METRICS_FILE.read_text(encoding="utf-8"))
            for k in ("counters", "latency"):
                for kk, vv in (raw.get(k) or {}).items():
                    _M[k][kk] = vv
            _M["last_benchmark"] = raw.get("last_benchmark", {})
            _M["since"] = raw.get("since") or _M["since"]
    except Exception:
        pass


def _save(force: bool = False) -> None:
    now = time.time()
    _DIRTY["n"] += 1
    if not force and _DIRTY["n"] < 8 and now - _DIRTY["t"] < 5:
        return
    _DIRTY.update({"n": 0, "t": now})
    try:
        cfg.DATA_DIR.mkdir(parents=True, exist_ok=True)
        tmp = METRICS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_M), encoding="utf-8")
        os.replace(tmp, METRICS_FILE)
    except Exception:
        pass


def flush() -> None:
    with _LOCK:
        _save(True)


def _inc(name: str, n: int = 1) -> None:
    _M["counters"][name] = int(_M["counters"].get(name, 0)) + n


def _push(name: str, value: float, cap: int = 200) -> None:
    arr = _M["latency"].setdefault(name, [])
    arr.append(round(float(value), 2))
    if len(arr) > cap:
        del arr[: len(arr) - cap]


# ----------------------------------------------------------------- recorders
def record_vision_latency(ms: float) -> None:
    with _LOCK:
        _load()
        _inc("vision_frames")
        _push("vision_ms", ms)
        _save()


def record_llm_latency(ms: float) -> None:
    with _LOCK:
        _load()
        _push("llm_ms", ms)
        _save()


def record_cloud(ms: Optional[float], fallback: bool = False) -> None:
    with _LOCK:
        _load()
        if fallback:
            _inc("cloud_fallbacks")
        else:
            _inc("cloud_calls")
            if ms is not None:
                _push("cloud_ms", ms)
        _save()


def record_task(success: bool, seconds: float = 0.0, replans: int = 0, recovered: bool = False) -> None:
    with _LOCK:
        _load()
        _inc("tasks")
        if success:
            _inc("tasks_ok")
        if seconds:
            _push("task_s", seconds)
        if replans:
            _inc("replans", replans)
        if replans or recovered:
            _inc("recoveries")
            if success:
                _inc("recoveries_ok")
        _save()


def record_action(success: bool) -> None:
    with _LOCK:
        _load()
        _inc("actions")
        if success:
            _inc("actions_ok")
        _save()


def record_verification(verdict: str) -> None:
    with _LOCK:
        _load()
        _inc("verifications")
        v = (verdict or "").upper()
        if v == "SUCCESS":
            _inc("verifications_ok")
        elif v == "UNCERTAIN":
            _inc("verifications_uncertain")
        _save()


def record_safety(level: str, decision: str) -> None:
    with _LOCK:
        _load()
        d = decision or ""
        if d.startswith("auto_allowed"):
            _inc("auto_allowed")
        elif d in ("approved", "approved_typed"):
            _inc("confirmations")
            _inc("approved")
        elif d in ("denied", "timeout"):
            _inc("confirmations")
            _inc("denied")
        elif d == "blocked":
            _inc("blocked")
        _save()


def _avg(name: str) -> Optional[float]:
    arr = _M["latency"].get(name) or []
    return round(sum(arr) / len(arr), 1) if arr else None


def _p95(name: str) -> Optional[float]:
    arr = sorted(_M["latency"].get(name) or [])
    return round(arr[min(len(arr) - 1, int(len(arr) * 0.95))], 1) if arr else None


def _rate(num: str, den: str) -> Optional[float]:
    c = _M["counters"]
    return round(100.0 * c.get(num, 0) / c[den], 1) if c.get(den) else None


def snapshot() -> dict[str, Any]:
    with _LOCK:
        _load()
        c = _M["counters"]
        return {
            "since": _M["since"], "counters": dict(c),
            "rates": {"task_success_pct": _rate("tasks_ok", "tasks"), "action_success_pct": _rate("actions_ok", "actions"),
                      "verification_success_pct": _rate("verifications_ok", "verifications"), "recovery_success_pct": _rate("recoveries_ok", "recoveries")},
            "latency": {"vision_avg_ms": _avg("vision_ms"), "vision_p95_ms": _p95("vision_ms"), "llm_avg_ms": _avg("llm_ms"),
                        "task_avg_s": _avg("task_s"), "cloud_avg_ms": _avg("cloud_ms")},
            "last_benchmark": _M.get("last_benchmark", {}),
        }


def reset(keep_benchmark: bool = True) -> dict[str, Any]:
    with _LOCK:
        _load()
        bench = _M.get("last_benchmark", {}) if keep_benchmark else {}
        _M.clear()
        _M.update(json.loads(json.dumps(_DEFAULT)))
        _M["since"] = time.time()
        _M["last_benchmark"] = bench
        _save(True)
    return snapshot()


# =========================================================================
# BENCHMARK SUITE
# =========================================================================
def _need():
    import friday_vision_engine as ve
    ve._need_cv()
    return ve


def _prf(tp: int, fp: int, fn: int) -> dict[str, float]:
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return {"precision": round(p, 3), "recall": round(r, 3), "f1": round(f, 3)}


def bench_detection(scenes: int = 12) -> dict[str, Any]:
    ve = _need()
    import numpy as np
    out = {}
    for cond in ("clean", "noisy"):
        tp = fp = fn = label_ok = counts_ok = 0
        for i in range(scenes):
            img, truth = ve.synthetic_scene(seed=100 + i, n=3 + (i % 4))
            if cond == "noisy":
                img = np.clip(img.astype(np.int16) + np.random.RandomState(i).normal(0, 16, img.shape), 0, 255).astype(np.uint8)
            dets = [o for o in ve.analyze_frame(img, "image", publish_state=False, do_detect=True, mode="contours")["objects"]]
            used = set()
            for d in dets:
                best, bi = 0.0, -1
                for j, t in enumerate(truth):
                    if j in used:
                        continue
                    v = ve.iou(d["bbox"], t["bbox"])
                    if v > best:
                        best, bi = v, j
                if best >= 0.5:
                    tp += 1
                    used.add(bi)
                    if d["label"] == truth[bi]["label"]:
                        label_ok += 1
                else:
                    fp += 1
            fn += len(truth) - len(used)
            counts_ok += int(len(dets) == len(truth))
        out[cond] = {**_prf(tp, fp, fn), "label_accuracy": round(label_ok / tp, 3) if tp else 0.0,
                     "count_accuracy": round(counts_ok / scenes, 3), "scenes": scenes, "objects": tp + fn}
    return out


def bench_motion(n: int = 10) -> dict[str, Any]:
    import numpy as np, cv2
    ve = _need()
    tp = fn = fp = tn = dir_ok = dir_n = 0
    for i in range(n):
        base, _ = ve.synthetic_scene(seed=300 + i, n=3)
        md = ve.MotionDetector()
        rng = np.random.RandomState(i)
        moving = False
        for f in range(14):
            fr = np.clip(base.astype(np.int16) + rng.normal(0, 3, base.shape), 0, 255).astype(np.uint8)
            if f >= 6:
                x = 60 + (f - 6) * 70
                cv2.rectangle(fr, (x, 560), (x + 110, 660), (250, 250, 250), -1)
                moving = True
            r = md.update(fr)
        if r["motion"]:
            tp += 1
            dir_n += 1
            dir_ok += int(r["direction"] == "right")
        else:
            fn += 1
        md2 = ve.MotionDetector()
        for f in range(14):
            fr = np.clip(base.astype(np.int16) + rng.normal(0, 3, base.shape), 0, 255).astype(np.uint8)
            r2 = md2.update(fr)
        if r2["motion"]:
            fp += 1
        else:
            tn += 1
    return {"sequences": n * 2, "accuracy": round((tp + tn) / (2 * n), 3), "true_positive_rate": round(tp / n, 3), "false_positive_rate": round(fp / n, 3),
            "direction_accuracy": round(dir_ok / dir_n, 3) if dir_n else 0.0}


def bench_change(n: int = 10) -> dict[str, Any]:
    import numpy as np, cv2
    ve = _need()
    ok = tot = 0
    kinds = {"object_added": [0, 0], "object_removed": [0, 0], "no_change_noise": [0, 0], "window_opened": [0, 0]}
    for i in range(n):
        img, truth = ve.synthetic_scene(seed=500 + i, n=4)
        rng = np.random.RandomState(i)
        noisy = np.clip(img.astype(np.int16) + rng.normal(0, 4, img.shape), 0, 255).astype(np.uint8)
        added = img.copy()
        x, y, w, h = 40 + 90 * (i % 5), 30, 140, 110
        cv2.rectangle(added, (x, y), (x + w, y + h), (30, 30, 230), -1)
        t = truth[0]["bbox"]
        removed = img.copy()
        removed[t[1]:t[1] + t[3], t[0]:t[0] + t[2]] = img[5:6, 5:6]
        win = img.copy()
        cv2.rectangle(win, (300, 150), (980, 560), (235, 235, 235), -1)
        cv2.rectangle(win, (300, 150), (980, 190), (160, 90, 30), -1)
        cases = [("object_added", img, added, True), ("object_removed", img, removed, True), ("no_change_noise", img, noisy, False), ("window_opened", img, win, True)]
        for name, a, b, expect in cases:
            got = ve.compare_frames(a, b)["changed"]
            kinds[name][1] += 1
            kinds[name][0] += int(got == expect)
            ok += int(got == expect)
            tot += 1
    return {"cases": tot, "accuracy": round(ok / tot, 3), "by_kind": {k: f"{v[0]}/{v[1]}" for k, v in kinds.items()}}


def bench_tracking(sequences: int = 6) -> dict[str, Any]:
    ve = _need()
    import random
    switches = frames_total = matched = 0
    for s in range(sequences):
        rnd = random.Random(s)
        objs = [{"id": i, "x": rnd.randint(50, 400), "y": rnd.randint(80, 600), "vx": rnd.choice([-1, 1]) * rnd.randint(8, 22), "vy": rnd.randint(-6, 6),
                 "label": ["red object", "blue object", "green object"][i]} for i in range(3)]
        tr = ve.ObjectTracker()
        assigned: dict[int, dict[int, int]] = {o["id"]: {} for o in objs}
        for f in range(30):
            dets = []
            for o in objs:
                o["x"] += o["vx"]
                o["y"] += o["vy"]
                dets.append({"label": o["label"], "conf": 0.9, "bbox": [int(o["x"] + rnd.randint(-2, 2)), int(o["y"] + rnd.randint(-2, 2)), 90, 90], "_gt": o["id"]})
            res = tr.update(dets, (1280, 720), t=f * 0.1)
            for r in res:
                gt = max(objs, key=lambda o: -((o["x"] - r["bbox"][0]) ** 2 + (o["y"] - r["bbox"][1]) ** 2))["id"]
                frames_total += 1
                assigned[gt][r["id"]] = assigned[gt].get(r["id"], 0) + 1
        for gt, d in assigned.items():
            if d:
                matched += max(d.values())
                switches += len(d) - 1
    return {"sequences": sequences, "id_switches": switches, "identity_consistency": round(matched / frames_total, 3) if frames_total else 0.0}


def bench_ocr() -> dict[str, Any]:
    import numpy as np, cv2
    ve = _need()
    if not ve._tesseract_ready():
        return {"skipped": True, "reason": "Tesseract OCR is not installed on this PC"}
    phrases = ["Error: file not found", "Save changes?", "Open Chemistry Notes", "Download complete", "Meeting at 10 am", "Total 4500 rupees",
               "Connection lost", "Settings and privacy"]
    scores = []
    for i, ph in enumerate(phrases):
        img = np.full((140, 900, 3), 255 if i % 2 == 0 else 30, np.uint8)
        cv2.putText(img, ph, (20, 90), cv2.FONT_HERSHEY_SIMPLEX, 1.4 + 0.1 * (i % 3), (0, 0, 0) if i % 2 == 0 else (240, 240, 240), 2, cv2.LINE_AA)
        got = ve.ocr(img)["text"].replace("\n", " ").strip().lower()
        scores.append(difflib.SequenceMatcher(None, got, ph.lower()).ratio())
    return {"samples": len(phrases), "char_similarity": round(sum(scores) / len(scores), 3), "exact_matches": sum(1 for s in scores if s > 0.97)}


def run_suite(progress: Optional[Callable[[str, float], None]] = None, include_agent: bool = True) -> dict[str, Any]:
    """Run every benchmark. Returns a dict (also saved as the 'last benchmark')."""
    ve = _need()
    steps: list[tuple[str, Callable[[], Any]]] = [
        ("OpenCV micro-benchmarks", lambda: ve.micro_benchmark(10)),
        ("Object detection accuracy", bench_detection),
        ("Motion detection", bench_motion),
        ("Visual change detection", bench_change),
        ("Object tracking", bench_tracking),
        ("OCR accuracy", bench_ocr),
    ]
    if include_agent:
        def _agent():
            import friday_vision_agent as va
            return va.run_simulation_suite()
        steps.append(("Agent loop (simulated desktop)", _agent))

        def _agentic():
            import friday_agentic_vision as av
            return av.run_benchmark(quick=True, save=False)
        steps.append(("Agentic problem solver (simulated desktop)", _agentic))
    result: dict[str, Any] = {"started": time.strftime("%Y-%m-%d %H:%M:%S"), "environment": ve.environment()}
    t_all = time.perf_counter()
    for i, (name, fn) in enumerate(steps):
        if progress:
            progress(name, i / len(steps))
        t = time.perf_counter()
        try:
            data = fn()
        except Exception as exc:
            data = {"error": f"{type(exc).__name__}: {exc}"}
        key = {"OpenCV micro-benchmarks": "micro", "Object detection accuracy": "detection", "Motion detection": "motion",
               "Visual change detection": "change", "Object tracking": "tracking", "OCR accuracy": "ocr", "Agent loop (simulated desktop)": "agent_sim",
               "Agentic problem solver (simulated desktop)": "agentic_sim"}[name]
        if key == "micro":
            data = {k: v for k, v in data.items() if k != "environment"}
        result[key] = data
        result.setdefault("seconds", {})[key] = round(time.perf_counter() - t, 2)
    result["total_seconds"] = round(time.perf_counter() - t_all, 2)
    result["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")
    with _LOCK:
        _load()
        _M["last_benchmark"] = result
        _save(True)
    if progress:
        progress("Done", 1.0)
    return result


def headline(result: dict[str, Any]) -> str:
    """One spoken-friendly sentence."""
    bits = []
    d = (result.get("detection") or {}).get("clean")
    if d:
        bits.append(f"object detection F1 {d['f1']:.2f}")
    m = result.get("motion")
    if m and "accuracy" in m:
        bits.append(f"motion accuracy {round(m['accuracy'] * 100)} percent")
    c = result.get("change")
    if c and "accuracy" in c:
        bits.append(f"change detection {round(c['accuracy'] * 100)} percent")
    a = result.get("agent_sim")
    if a and "tasks_ok" in a:
        bits.append(f"{a['tasks_ok']} of {a['achievable']} achievable simulated agent tasks completed, {a['unsafe_blocked']} of {a['unsafe_total']} unsafe requests stopped, {a['honest_ok']} of {a['honest_total']} impossible tasks reported honestly")
    g = result.get("agentic_sim")
    if g and "task_completion_pct" in g:
        bits.append(f"problem solver fixed {g['task_completion_pct']} percent of fixable on-screen errors with {g['false_detection_pct']} percent false detections")
    micro = (result.get("micro") or {}).get("operations", {}).get("full_vision_pipeline")
    if micro:
        bits.append(f"full vision pipeline {micro['median_ms']:.0f} milliseconds per 720p frame")
    return "Benchmark finished: " + ", ".join(bits) + "." if bits else "Benchmark finished."


# =========================================================================
# REPORT
# =========================================================================
def _fmt(v: Any, suffix: str = "") -> str:
    return "n/a" if v is None else f"{v}{suffix}"


def build_report_markdown(live: Optional[dict] = None, bench: Optional[dict] = None, cloud: Optional[dict] = None) -> str:
    live = live or snapshot()
    bench = bench or live.get("last_benchmark") or {}
    env = bench.get("environment") or {}
    L = []
    L.append("# FRIDAY Evaluation Report")
    L.append(f"_Generated {time.strftime('%Y-%m-%d %H:%M:%S')}_\n")
    L.append("FRIDAY is a multimodal agent: OpenCV perceives (screen, camera, images, video), Gemini reasons, computer tools act, and OpenCV verifies "
             "whether each action worked, replanning when it did not.\n")
    L.append("## Environment")
    L.append(f"- OpenCV {env.get('opencv_version', '?')} (OpenCV 5 build: {env.get('opencv5')}); DNN engines: {', '.join(env.get('dnn_engines', [])) or 'n/a'}")
    L.append(f"- {env.get('platform', '?')} {env.get('machine', '?')}, {env.get('cpu_count', '?')} CPU cores, {env.get('threads', '?')} OpenCV threads, optimised code: {env.get('optimized')}")
    cool = env.get("cool") or {}
    L.append(f"- Graviton/ARM64: {cool.get('arm64')}; COOL build detected: {cool.get('active')} (COOL path present: {cool.get('cool_path_present')})\n")
    r = live.get("rates", {})
    c = live.get("counters", {})
    lat = live.get("latency", {})
    L.append("## Live metrics (counted from real use on this PC)")
    L.append("| Metric | Value | Counts |\n|---|---|---|")
    L.append(f"| Task success rate | {_fmt(r.get('task_success_pct'), '%')} | {c.get('tasks_ok', 0)}/{c.get('tasks', 0)} tasks |")
    L.append(f"| Action success rate | {_fmt(r.get('action_success_pct'), '%')} | {c.get('actions_ok', 0)}/{c.get('actions', 0)} actions |")
    L.append(f"| Verification success rate | {_fmt(r.get('verification_success_pct'), '%')} | {c.get('verifications_ok', 0)}/{c.get('verifications', 0)} checks (uncertain: {c.get('verifications_uncertain', 0)}) |")
    L.append(f"| Recovery success rate | {_fmt(r.get('recovery_success_pct'), '%')} | {c.get('recoveries_ok', 0)}/{c.get('recoveries', 0)} recoveries |")
    L.append(f"| Avg vision-processing latency | {_fmt(lat.get('vision_avg_ms'), ' ms')} | p95 {_fmt(lat.get('vision_p95_ms'), ' ms')}, {c.get('vision_frames', 0)} frames |")
    L.append(f"| Avg AI (Gemini) latency | {_fmt(lat.get('llm_avg_ms'), ' ms')} | |")
    L.append(f"| Avg task time | {_fmt(lat.get('task_avg_s'), ' s')} | |")
    L.append(f"| Safety | approved {c.get('approved', 0)}, denied {c.get('denied', 0)}, blocked {c.get('blocked', 0)} | {c.get('auto_allowed', 0)} auto-allowed |\n")
    if bench:
        L.append(f"## Benchmark suite ({bench.get('finished', '?')}, {bench.get('total_seconds', '?')} s)")
        det = bench.get("detection") or {}
        for cond in ("clean", "noisy"):
            d = det.get(cond)
            if d:
                L.append(f"- Detection ({cond} synthetic scenes): precision {d['precision']}, recall {d['recall']}, F1 {d['f1']}, label accuracy {d['label_accuracy']}, exact-count accuracy {d['count_accuracy']} ({d['scenes']} scenes, {d['objects']} objects)")
        m = bench.get("motion") or {}
        if "accuracy" in m:
            L.append(f"- Motion detection: accuracy {m['accuracy']}, true-positive {m['true_positive_rate']}, false-positive {m['false_positive_rate']}, direction {m['direction_accuracy']} ({m['sequences']} sequences)")
        ch = bench.get("change") or {}
        if "accuracy" in ch:
            L.append(f"- Visual change detection: accuracy {ch['accuracy']} over {ch['cases']} cases ({', '.join(f'{k} {v}' for k, v in ch['by_kind'].items())})")
        tr = bench.get("tracking") or {}
        if "identity_consistency" in tr:
            L.append(f"- Tracking: identity consistency {tr['identity_consistency']}, ID switches {tr['id_switches']} ({tr['sequences']} sequences)")
        oc = bench.get("ocr") or {}
        if oc.get("skipped"):
            L.append(f"- OCR: skipped ({oc.get('reason')})")
        elif oc:
            L.append(f"- OCR: character similarity {oc.get('char_similarity')}, exact matches {oc.get('exact_matches')}/{oc.get('samples')}")
        ag = bench.get("agent_sim") or {}
        if "tasks" in ag:
            L.append(f"- Agent loop on a **simulated** desktop ({ag['tasks']} scenarios): {ag['tasks_ok']}/{ag['achievable']} achievable tasks completed and verified, "
                     f"{ag['honest_ok']}/{ag['honest_total']} impossible tasks honestly reported as failed, step success {ag['actions_ok']}/{ag['actions']} (includes deliberately failing steps that trigger recovery), "
                     f"verification correct {ag['verifications_correct']}/{ag['verifications']}, recoveries {ag['recoveries_ok']}/{ag['recoveries']}, "
                     f"unsafe actions blocked {ag['unsafe_blocked']}/{ag['unsafe_total']}")
        gs = bench.get("agentic_sim") or {}
        if "task_completion_pct" in gs:
            L.append(f"- Agentic problem solver on a **simulated** desktop ({gs['scenarios']} scenarios): task completion {gs['task_completion_pct']}%, false detections {gs['false_detection_pct']}% "
                     f"(false-positive rate {gs['false_positive_rate_pct']}%, missed {gs['missed_detection_pct']}%), recovery {gs['recovery_pct']}%, median time to fix {(gs.get('time_to_complete') or {}).get('median')} s, "
                     f"unsafe stopped {gs['unsafe_stopped']}, honest outcomes {gs['honest_outcomes']}")
        micro = (bench.get("micro") or {}).get("operations") or {}
        if micro:
            L.append(f"\n### OpenCV micro-benchmarks ({(bench.get('micro') or {}).get('frame')}, median ms)")
            L.append("| Operation | median ms | p95 ms |\n|---|---|---|")
            for k, v in micro.items():
                if "median_ms" in v:
                    L.append(f"| {k} | {v['median_ms']} | {v['p95_ms']} |")
        L.append("")
    if cloud:
        L.append("## Cloud (AWS Graviton / COOL) comparison")
        L.append("```json\n" + json.dumps(cloud, indent=2)[:4000] + "\n```")
    L.append("## Notes on how to read this")
    L.append("- 'Live' numbers come from real FRIDAY use on this PC. 'Benchmark' numbers come from reproducible synthetic scenes (known ground truth) and a "
             "simulated desktop, so they measure the perception / agent logic, not the behaviour of any particular Windows app.")
    L.append("- Run the same benchmark on a Graviton instance (Settings > Vision > Cloud > Benchmark) and on this PC to compare processing speed, latency and cost/performance.")
    return "\n".join(L)


def export_report(live: Optional[dict] = None, cloud: Optional[dict] = None) -> dict[str, str]:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    live = live or snapshot()
    md = EXPORT_DIR / f"FRIDAY_evaluation_{stamp}.md"
    js = EXPORT_DIR / f"FRIDAY_evaluation_{stamp}.json"
    md.write_text(build_report_markdown(live, None, cloud), encoding="utf-8")
    js.write_text(json.dumps({"live": live, "cloud": cloud}, indent=2), encoding="utf-8")
    return {"markdown": str(md), "json": str(js)}
