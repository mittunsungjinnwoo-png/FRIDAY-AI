from pathlib import Path

s = Path(__file__).with_name("friday_backend.py").read_text(encoding="utf-8")
assert 'def _capture_until_silence(source):' in s
listen = s[s.index('def listen():'):s.index('def listen():') + 5000]
assert 'audio = _capture_until_silence(source)' in listen
assert 'audio = recognizer.listen(' not in listen
assert 'speak("I\'m having trouble reaching speech recognition right now.")' not in listen
assert 'speak("Something went wrong while I was listening.")' not in listen
assert 'VAD_PAUSE_THRESHOLD = float(os.getenv("FRIDAY_VAD_PAUSE", "1.15"))' in s
print("PASS: explicit VAD capture is active, recognition is reached after silence, and generic recognition failures are silent.")
