# FRIDAY V7.5 - agentic vision loop (see a problem, fix it with your approval, check it is gone)

Built on V7.4. Every other feature is untouched: voice, listening, wake word, widget, finance/food, the old "agent:" goals and the camera.
Reply speed is unchanged: the new code adds one pattern check (about 6 microseconds) in front of the normal command route and loads nothing else until you ask for it.
Her words appear in the chat at the moment she starts speaking, exactly as in V7.4, because every line goes through the same speak().

## What she does now
Say **"fix the error on my screen"** (also: "what's wrong with my screen", "an error popped up", "scan my screen for problems", "my app is frozen", or the button on Vision > Agent).

1. **Observe**: looks at the screen (OpenCV + OCR; on Windows also UI Automation, which gives the exact dialog text and buttons).
2. **Detect**: needs several signals together (problem wording + dialog-like title/buttons + compact message). A document, web page or code that merely says "error" is left alone; so is a "save changes?" prompt and her own chat.
3. **Read + diagnose**: message, app, buttons and file name; classed as missing file, network, not responding, crash, permission, low resource, save failure or generic.
4. **Propose**: one sentence, e.g. "I can see a missing-file error in Notepad. It says: ... I could click OK, then look for Chemistry Notes.docx on this PC and open it. Shall I?"
5. **Approve**: say or type yes / no, use the Approve / Deny card, or say **"that's not an error"** (or press *Not an error*) to mark a false detection. Only reading and web searches run without a yes.
6. **Pre-check**: just before acting she looks again. If the dialog is already gone she does nothing; if you switched windows she does nothing.
7. **Act** only the approved steps (click the dialog's own button, Escape, F5, wait, reopen the app or file, web search).
8. **Verify**: looks again. Same message = not fixed, a different message = new problem, nothing = fixed. She never says "fixed" unless the screen shows it.
9. **Recover**: if it persists she proposes the next option (asking again), up to 3 different fixes, then says honestly that she could not clear it.

Safety: nothing destructive is ever proposed (no delete, send, install, shell commands). If the dialog mentions payments, passwords, cards, deletion etc. she will not click and will not web-search its text. Honest partial outcomes are reported as partial (message closed but the file still not found; access denied; low disk space).

Optional: **"watch my screen for errors"** keeps an eye out and ASKS when something appears (never acts on its own). "Stop watching for errors" turns it off.

## Measured (Vision > Agent, say "problem solver stats", or Evaluation report)
Task completion, false detections, recovery rate and time to complete (detection to verified fix, not counting the time you took to answer).
Say **"run the problem solver benchmark"** for a reproducible run on a simulated desktop (23 scenarios incl. look-alikes, refusals, window switches, payment dialogs).
Result in this build: 8/8 fixable problems fixed and verified, 0 false detections on 6 look-alike scenes, 3/3 recoveries, 4/4 honest partial/failed outcomes, 1/1 sensitive dialog refused, median 1.5 s (excludes human wait).
Limits: that is a simulator, on clean rendered text. With very small, heavily compressed text detection drops (see FRIDAY_TEST_V75 notes); on a real PC Windows UI Automation is used first and OCR second. Live numbers on your PC are counted from real use.

## Files
New: friday_agentic_vision.py, FRIDAY_TEST_V75_AGENTIC_VISION.py, FRIDAY_V75_CHANGES.md
Changed (small, additive): friday_backend.py (lazy module + one early hook), friday_vision_hub.py (UI ops, status, stop), friday_vision_ui.js (Problem solver panel, "Not an error" button, settings),
friday_vision_config.py (5 new settings), friday_eval_metrics.py (benchmark step + report line).
Needs the same things as Vision already does: opencv, numpy, pytesseract + the Tesseract program (without text recognition she says so instead of guessing).
Tested headlessly only (simulated desktop, mocked Windows UI Automation); not run on real Windows.
