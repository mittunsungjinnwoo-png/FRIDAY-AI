"""V2037 regression tests: typo-tolerant document requests, honest AI-failure reasons,
window-aware screen reports, orbitals library. Needs no mic, key or network.
Run:  python TEST_V2037_DOCS_SCREEN_AI.py"""
import ast, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import friday_notes_knowledge as K
import friday_screen_intelligence as S


def test_orbitals_library_and_plan():
    for topic in ("orbitals", "atomic orbitals", "electronic configuration", "shells and subshells"):
        e = K.lookup(topic, "Chemistry", "2027")
        assert e and e["chapter_title"] == "Atomic Orbitals", topic
    assert K.lookup("sp3 orbitals")["chapter_title"].startswith("How sp3")     # sp3 must not be shadowed
    kinds = [d["kind"] for d in K.lookup("orbitals")["diagrams"]]
    assert "shapes" in kinds and kinds.count("energy") == 2
    plan = K.to_plan(K.lookup("orbitals"))
    assert len(plan["sections"]) >= 15 and plan["title"] == "Atomic Orbitals"
    assert "2n\u00b2" in " ".join(plan["key_facts"])


def test_orbital_notes_pdf_builds():
    import friday_notes_engine as E
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "orb.pdf"
        E.build_gorgeous_notes("orbitals", "chem", K.lookup("orbitals", "Chem", "2027"), out)
        assert out.stat().st_size > 20000


def test_creation_engine_parsing():
    try:
        import friday_creation_engine as ce
    except Exception as error:            # python-docx / python-pptx missing on this machine
        print("  (skipped: creation engine needs python-docx/pptx:", error, ")"); return
    cases = {
        "can u create a word documetn on orbitals make sure to the research": ("orbitals", {"docx"}),
        "create a word document on orbitals": ("orbitals", {"docx"}),
        "make a word doc on the periodic table with research": ("the periodic table", {"docx"}),
        "make me a presentaion on photosynthesis": ("photosynthesis", {"pptx"}),
        "research on Astrology and make it into a PDF": ("Astrology", {"pdf"}),
    }
    for command, (topic, wants) in cases.items():
        got_topic, got_wants, _ = ce._parse_project_request(command)
        assert (got_topic, got_wants) == (topic, wants), (command, got_topic, got_wants)
    assert hasattr(ce, "LAST_PROJECT")


def test_screen_report_names_all_windows():
    windows = [("FRIDAY", "FRIDAY - Widget"),
               ("Google Chrome", "Friday speech recognition - Claude - Google Chrome"),
               ("File Explorer", "Downloads")]
    said = S._compose_window_report(windows)
    assert "Google Chrome is in front" in said and "File Explorer" in said and "FRIDAY widget" in said
    assert "sir" in said.lower()
    assert S._compose_window_report([]) is None


def test_backend_static_wiring():
    src = (ROOT / "friday_backend.py").read_text(encoding="utf-8")
    ast.parse(src)
    for needle in ("def _gemini_generate", "def _classify_gemini_error", "GEMINI_MODEL_HEALED",
                   "def _notes_failure_explanation", "_SIR_LOWERCASE_OPENERS", "syllabus_key"):
        assert needle in src, needle
    agent = (ROOT / "friday_advanced_agent.py").read_text(encoding="utf-8")
    assert "def _spoken_issue" in agent and "LAST_PROJECT" in agent
    assert "Documents" in (ROOT / "friday_creation_engine.py").read_text(encoding="utf-8")


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print(f"  {name}: PASS")
    print("V2037 docs + screen + AI tests: PASS")
