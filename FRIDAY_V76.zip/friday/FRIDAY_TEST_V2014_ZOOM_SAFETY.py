import ast
from pathlib import Path
R=Path(__file__).resolve().parent
def r(n): return (R/n).read_text(encoding="utf-8")
for n in ["friday_backend.py","friday_zoom_notes.py","friday_notes_engine.py"]: ast.parse(r(n),filename=n)
assert "is_tts_active" in r("friday_backend.py")
assert "_tts_is_active" in r("friday_zoom_notes.py")
assert "modifies_microphone" in r("friday_zoom_notes.py") and "modifies_speaker" in r("friday_zoom_notes.py")
assert "ACTION::ZOOM_NOTES_WIDGET_ON" in r("friday_zoom_notes.py") and "ACTION::ZOOM_NOTES_WIDGET_OFF" in r("friday_zoom_notes.py")
assert "setContentProtection(true)" in r("main.js") and "setIgnoreMouseEvents(true" in r("main.js")
assert "onWidgetNoteMode" in r("preload.js")
assert "widgetNoteMode" in r("main.js")
assert "did-finish-load" in r("main.js")
assert all(x in r("friday_notes_engine.py") for x in ["PURPLE_LIGHT","PINK","BLUE","relationships"])
print("v2014 Zoom safety/style tests: PASS")
