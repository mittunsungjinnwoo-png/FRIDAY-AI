"""FRIDAY advanced brain - same architecture as FRIDAY's ask_ai():
  short-term conversation window + long-term distilled facts (embeddings, friday_context)
  + layered memory (friday_memory_layers) + continuous state (friday_agent_core)
  + streamed Gemini generation with model self-healing.
Added for FRIDAY: every money figure is computed exactly in Python and handed to the model, so it never does the arithmetic itself.
Also acts as the module friday_context expects (client, GEMINI_MODEL, _ensure_gemini_client, _get_embedding, _cosine_similarity)."""
import os, re, json, math, threading, time
from pathlib import Path

HERE = Path(__file__).parent
DATA_DIR = Path(os.environ.get("FRIDAY_DATA") or (HERE / "friday_data")); DATA_DIR.mkdir(parents=True, exist_ok=True)
GEMINI_MODEL = os.getenv("FRIDAY_GEMINI_MODEL", "gemini-3.1-flash-lite").strip() or "gemini-3.1-flash-lite"
FALLBACK_MODELS = [m.strip() for m in os.getenv("FRIDAY_GEMINI_FALLBACK_MODELS",
    "gemini-3.1-flash-lite,gemini-3.8-flash,gemini-flash-latest,gemini-3.7-flash,gemini-3.6-flash,gemini-3.5-flash,gemini-2.5-flash").split(",") if m.strip()]
EMBEDDING_MODEL = "gemini-embedding-001"
client = None
_EMB_CACHE = {}
CHAT_FILE = DATA_DIR / "chat_memory.json"
_chat_lock = threading.Lock()

try:
    import friday_context as ctxmem, friday_agent_core as agent, friday_memory_layers as layers
except Exception as _e:                      # brain still answers without the memory modules
    ctxmem = agent = layers = None; print("FRIDAY_BOOT::MEMORY_MODULES_UNAVAILABLE::" + str(_e), flush=True)

PERSONA = (
    "You are FRIDAY 5.0: a warm, sharp, trustworthy multi-tasking AI assistant. "
    "Your purpose is to help the user get things done: reasoning, research, files, code, planning, computer tasks and everyday life (finance and meal planning are just two of many abilities). You are friendly, "
    "calm and practical, and you speak like a smart, capable friend.\n"
    "RULES: Use ONLY numbers found in 'Computed figures' or 'Live data'. Never invent prices, balances or amounts. Quote computed figures exactly; "
    "do not redo arithmetic yourself. If data is missing, say precisely what the user should add. State any assumption in one short clause. "
    "Spoken answer: lead with the answer, short natural sentences, at most 4 sentences unless asked for detail, no markdown, no lists, no emojis. "
    "Offer one concrete next step when it is relevant.")

def resolve_key():
    for v in ("GEMINI_API_KEY", "GOOGLE_API_KEY"):
        if os.getenv(v, "").strip(): return os.getenv(v).strip()
    p = HERE / "gemini_key.txt"
    return p.read_text(encoding="utf-8").strip() if p.exists() else ""

def _ensure_gemini_client():
    global client
    key = resolve_key()
    if not key: client = None; return
    os.environ["GEMINI_API_KEY"] = key
    if client is None:
        try:
            from google import genai
            client = genai.Client(api_key=key)
        except Exception as e: client = None; print("FRIDAY_BOOT::GEMINI_CLIENT_FAILED::" + str(e), flush=True)

def _get_embedding(text):
    if not text or not text.strip(): return None
    if text in _EMB_CACHE: return _EMB_CACHE[text]
    _ensure_gemini_client()
    if client is None: return None
    try:
        r = client.models.embed_content(model=EMBEDDING_MODEL, contents=text)
        em = getattr(r, "embeddings", None)
        vec = list(getattr(em[0], "values", None) or em[0]) if em else None
        if vec: _EMB_CACHE[text] = vec
        return vec
    except Exception: return None

def _cosine_similarity(a, b):
    if not a or not b or len(a) != len(b): return 0.0
    na, nb = math.sqrt(sum(x * x for x in a)), math.sqrt(sum(y * y for y in b))
    return sum(x * y for x, y in zip(a, b)) / (na * nb) if na and nb else 0.0

def stream_text(prompt):
    """Yield Gemini text; if a model is rejected before any text arrives, try the next one (never restarts a stream mid-way)."""
    global GEMINI_MODEL
    _ensure_gemini_client()
    if client is None: return
    last = None
    for i, model in enumerate([GEMINI_MODEL] + [m for m in FALLBACK_MODELS if m != GEMINI_MODEL]):
        emitted = False
        try:
            for ch in client.models.generate_content_stream(model=model, contents=prompt):
                piece = getattr(ch, "text", None) or ""
                if piece: emitted = True; yield piece
            if i: GEMINI_MODEL = model
            return
        except Exception as e:
            last = e
            if emitted: return
            time.sleep(0.4 if i == 0 else 0)
    print("FRIDAY_BOOT::BRAIN_ERROR::" + str(last), flush=True)

# ---------- exact finance maths ----------
def _tot(x): return round(sum(float(i.get("a", 0)) for i in x or []), 2)
def computed(ctx):
    c = ctx or {}; cur = c.get("currency", "Rs")
    inc, exp, plan, goals = _tot(c.get("income")), _tot(c.get("expenses")), _tot(c.get("monthlyPlan")), _tot(c.get("goals"))
    wk = round(float(c.get("weeklyFoodCost") or 0), 2); mo_food = round(wk * 52 / 12, 2)
    left = round(inc - exp - plan, 2)
    out = [f"Currency: {cur}", f"Monthly income total: {inc}", f"Monthly expenses total: {exp}", f"Monthly plan total: {plan}",
           f"Left over each month (income - expenses - plan): {left}", f"Savings goals total: {goals}",
           f"Estimated weekly food cost from meal plan: {wk}", f"Estimated monthly food cost (weekly x 52/12): {mo_food}"]
    if inc > 0: out.append(f"Savings rate (left over / income): {round(left / inc * 100, 1)} percent")
    if left > 0 and goals > 0: out.append(f"Months to reach all goals at current surplus: {math.ceil(goals / left)}")
    g = next((x for x in c.get("monthlyPlan") or [] if re.search(r"groc|food", str(x.get("n", "")), re.I)), None)
    if g: out.append(f"Groceries budget {g['a']} vs estimated monthly food {mo_food}: difference {round(g['a'] - mo_food, 2)}")
    ing = sorted(c.get("weeklyIngredients") or [], key=lambda r: -float(r.get("cost") or 0))[:3]
    if ing and wk: out.append("Costliest ingredients this week: " + ", ".join(f"{r['name']} {r['cost']}" for r in ing))
    return "\n".join(out)

# ---------- short-term chat memory ----------
def _load_chat():
    try: return json.loads(CHAT_FILE.read_text(encoding="utf-8"))
    except Exception: return []
def _save_chat(m):
    try:
        t = CHAT_FILE.with_suffix(".tmp"); t.write_text(json.dumps(m[-60:], ensure_ascii=False), encoding="utf-8"); os.replace(t, CHAT_FILE)
    except Exception: pass

def build_prompt(q, ctx, chat):
    facts = ""
    try:
        if ctxmem:
            f = ctxmem.retrieve_relevant(q, top_k=8)
            if f: facts = "\n\nKnown long-term facts (from previous conversations):\n" + "\n".join("- " + x for x in f)
    except Exception: pass
    past = ""
    try:
        if layers:
            r = layers.recall("episodic", q, top_k=3)
            if r: past = "\n\nRelated past exchanges:\n" + "\n".join("- " + x["content"][:240] for x in r)
    except Exception: pass
    state = ""
    try:
        if agent: state = "\n\nContinuous FRIDAY state:\n" + agent.context_block()
    except Exception: pass
    hist = "\n".join(("User: " if m["role"] == "user" else "Friday: ") + m["content"] for m in chat[-20:])
    live = json.dumps(ctx or {}, ensure_ascii=False)[:6000]
    return (PERSONA + "\n\nComputed figures (exact, use verbatim):\n" + computed(ctx) + "\n\nLive data:\n" + live
            + facts + past + state + "\n\nConversation history:\n" + hist + "\n\nLatest user request:\n" + q)

def ask_stream(q, ctx):
    """Generator of answer text chunks. Records memory when finished."""
    with _chat_lock: chat = _load_chat(); chat.append({"role": "user", "content": q})
    try:
        if agent: agent.observe(q)
        if ctxmem: ctxmem.record_user_command(q)
    except Exception: pass
    full = []
    for piece in stream_text(build_prompt(q, ctx, chat)):
        full.append(piece); yield piece
    ans = "".join(full).strip()
    if not ans:
        yield "I can't reach my reasoning engine yet. Put your Gemini key in gemini_key.txt, or try a command like: income salary 250000."; return
    with _chat_lock: chat.append({"role": "assistant", "content": ans}); _save_chat(chat)
    def bg():
        try:
            if ctxmem: ctxmem.record_assistant_response(ans); ctxmem.maybe_extract_and_store(q, ans)
            if agent: agent.record_response(ans)
            if layers: layers.record("episodic", f"User: {q} | Friday: {ans[:300]}")
        except Exception as e: print("FRIDAY_BOOT::MEMORY_WRITE_FAILED::" + str(e), flush=True)
    threading.Thread(target=bg, daemon=True).start()
