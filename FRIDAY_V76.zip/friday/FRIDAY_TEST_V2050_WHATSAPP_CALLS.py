"""Tests for friday_whatsapp_calls (no WhatsApp / Windows needed: UI actions are faked)."""
import sys, re, difflib
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
import friday_whatsapp_calls as wac

failures = []
def check(name, cond, extra=""):
    if not cond:
        failures.append(name)
    print(("PASS " if cond else "FAIL ") + name + (f"  {extra}" if extra and not cond else ""))

# ---------------- parsing ----------------
P = wac.parse_call_command
cases = {
    "call Mom on WhatsApp": ("Mom", False),
    "Call mom on whatsapp please": ("mom", False),
    "hey friday call Sarah Khan on whatsapp": ("Sarah Khan", False),
    "call Mom": ("Mom", False),
    "whatsapp call Dave": ("Dave", False),
    "make a whatsapp call to Dave": ("Dave", False),
    "video call Priya": ("Priya", True),
    "make a video call to Priya on WhatsApp": ("Priya", True),
    "give Mom a call": ("Mom", False),
    "give Mom a video call on whatsapp": ("Mom", True),
    "can you please call my mom on whatsapp": ("mom", False),
    "start a whatsapp video call with Ravi": ("Ravi", True),
    "ring Suresh": ("Suresh", False),
}
for text, (contact, video) in cases.items():
    r = P(text)
    check(f"parse: {text!r}", r is not None and r["contact"].lower() == contact.lower() and r["video"] == video, r)

check("bare whatsapp call asks who", P("make a whatsapp call") == {"contact": "", "video": False}, P("make a whatsapp call"))
for text in [
    "call me a taxi", "call it a day", "call me later", "call of duty", "call a function", "call this function",
    "send whatsapp to mom saying call me later", "send a message to Mom saying call dad",
    "tell Mom to call Dave", "call Mom on zoom", "call Dave on Microsoft Teams", "email Mom to call me",
    "what is a phone call", "how do I call a function in python", "open whatsapp", "recall my notes",
    "call John Smith Junior The Third",
]:
    check(f"parse ignores: {text!r}", P(text) is None, P(text))

# ---------------- control phrases ----------------
C = wac.classify_control
for text, exp in {
    "answer the call": "answer", "pick up": "answer", "accept the call": "answer", "answer it": "answer",
    "friday please answer the whatsapp call": "answer", "decline the call": "decline", "reject it": "decline",
    "hang up": "hangup", "end the call": "hangup", "end call": "hangup", "end the whatsapp call": "hangup",
}.items():
    r = C(text)
    check(f"control: {text!r}", r is not None and r[0] == exp, r)
for text in ["end", "answer my question", "take a note", "yes", "open notes", "cut the video", "end the meeting"]:
    check(f"control ignores: {text!r}", C(text) is None, C(text))

# ---------------- toast classification ----------------
T = wac.classify_call_toast
r = T(["Mom", "Incoming voice call"]); check("toast incoming voice", r == {"kind": "incoming", "caller": "Mom", "video": False}, r)
r = T(["Mom", "Incoming video call"]); check("toast incoming video", r and r["kind"] == "incoming" and r["video"], r)
r = T(["Incoming WhatsApp call", "Mom"]); check("toast reversed order", r and r["caller"] == "Mom" and r["kind"] == "incoming", r)
r = T(["Mom is calling you"]); check("toast 'is calling'", r and r["caller"] == "Mom" and r["kind"] == "incoming", r)
r = T(["Mom", "Missed voice call"]); check("toast missed", r and r["kind"] == "missed" and r["caller"] == "Mom", r)
r = T(["Mom", "Call ended"]); check("toast ended -> not incoming", r is None or r["kind"] != "incoming", r)
check("toast ongoing ignored", T(["Mom", "Ongoing voice call"]) is None)
check("toast normal message ignored", T(["Mom", "Can you call me later?"]) is None or T(["Mom", "Can you call me later?"])["kind"] != "incoming", T(["Mom", "Can you call me later?"]))
check("toast plain message ignored", T(["Mom", "hello there"]) is None)
check("toast empty", T([]) is None)
r = T(["+94 77 123 4567", "Incoming voice call"]); check("toast number caller", r and r["caller"] == "+94 77 123 4567", r)
check("looks_like_call_text incoming", wac.looks_like_call_text("Mom", "Incoming voice call"))
check("looks_like_call_text message", not wac.looks_like_call_text("Mom", "see you soon"))

# ---------------- controller with fakes ----------------
class FakeActions:
    def __init__(self):
        self.calls = []; self.result = {"start": (True, "ringing"), "answer": (True, "connected"),
                                        "decline": (True, "done"), "hangup": (True, "done")}
        self.window = False
    def start_call(self, contact, video, log=print): self.calls.append(("start", contact, video)); return self.result["start"]
    def answer(self): self.calls.append(("answer",)); return self.result["answer"]
    def decline(self): self.calls.append(("decline",)); return self.result["decline"]
    def hangup(self): self.calls.append(("hangup",)); return self.result["hangup"]
    def call_window_present(self): return self.window

def yes_no(text):
    t = re.sub(r"[^\w\s']", " ", text.lower()).split()
    if any(w in ("no", "nah", "cancel") for w in t): return "no"
    if any(w in ("yes", "yeah", "sure", "ok", "okay", "please") for w in t): return "yes"
    return None

def make(saved=("Mom", "Sarah"), busy=False, low=()):
    said, store, state = [], list(saved), {"busy": busy, "cleared": 0}
    def resolve(raw, full=""):
        best = max(store, key=lambda n: difflib.SequenceMatcher(None, raw.lower(), n.lower()).ratio(), default=None)
        if raw in low: return raw.title(), "low"
        if best and difflib.SequenceMatcher(None, raw.lower(), best.lower()).ratio() >= 0.6: return best, "high"
        return raw.title(), "low"
    def parse_spelled(t):
        toks = re.split(r"[\s\-]+", t.strip())
        return "".join(toks).title() if all(len(x) == 1 for x in toks) else t.strip().title()
    def cleared(): state["cleared"] += 1
    clock = {"t": 1000.0}
    fake = FakeActions()
    c = wac.CallController(
        speak=said.append, resolve_contact=resolve, ask_to_spell=lambda n: said.append(f"SPELL:{n}"),
        parse_spelled=parse_spelled, yes_no=yes_no, is_cancel=lambda t: t.strip().lower() in ("cancel", "never mind", "stop", "no"),
        load_contacts=lambda: list(store), save_contacts=lambda l: (store.clear(), store.extend(l)),
        flow_in_progress=lambda: state["busy"], clear_pending_questions=cleared, actions=fake,
        clock=lambda: clock["t"])
    return c, said, fake, store, state, clock

# happy path outgoing
c, said, fake, store, state, clock = make()
check("out: start handled", c.handle("call Mom on WhatsApp") is True)
check("out: asks confirm", said[-1] == "Shall I call Mom on WhatsApp, sir?", said)
check("out: no dial before yes", fake.calls == [])
check("out: yes handled", c.handle("yes") is True)
check("out: dialled Mom", fake.calls == [("start", "Mom", False)], fake.calls)
check("out: announced ringing", said[-1] == "It's ringing, sir.", said)
check("out: hangup after call", c.handle("hang up") is True and fake.calls[-1] == ("hangup",) and said[-1] == "Call ended, sir.", said)

# unknown name -> spelling -> confirm -> call, then saved
c, said, fake, store, state, clock = make(saved=("Mom",))
c.handle("call Xzqvw on WhatsApp")
check("spell: asked to spell", said[-1].startswith("SPELL:"), said)
c.handle("h a r s h i k")
check("spell: then confirms with spelled name", said[-1] == "Shall I call Harshik on WhatsApp, sir?", said)
check("spell: saved to contacts", "Harshik" in store, store)
c.handle("yes")
check("spell: dialled spelled name", fake.calls == [("start", "Harshik", False)], fake.calls)

# cancel paths
c, said, fake, *_ = make()
c.handle("call Mom on whatsapp"); c.handle("no")
check("cancel at confirm", fake.calls == [] and "cancelled" in said[-1], said)
c, said, fake, *_ = make(saved=())
c.handle("call Xzqvw on whatsapp"); c.handle("cancel")
check("cancel at spelling", fake.calls == [] and "cancelled" in said[-1], said)

# missing contact
c, said, fake, *_ = make()
c.handle("make a whatsapp call")
check("ask who", said[-1] == "Who would you like to call on WhatsApp?", said)
c.handle("Sarah"); c.handle("yeah")
check("who -> dial", fake.calls == [("start", "Sarah", False)], fake.calls)

# video
c, said, fake, *_ = make()
c.handle("video call Mom"); c.handle("yes")
check("video call dialled", fake.calls == [("start", "Mom", True)] and "video" in said[-3].lower() + said[-2].lower(), (fake.calls, said))

# unclear confirm then stands down
c, said, fake, *_ = make()
c.handle("call Mom"); r1 = c.handle("banana"); r2 = c.handle("banana")
check("unclear x2 stands down", r1 is True and r2 is None and fake.calls == [], (r1, r2))

# failures are reported honestly
for code, needle in [("wrong_chat", "doesn't look like"), ("no_button", "call button"), ("not_ready", "front"), ("no_uia", "pywinauto")]:
    c, said, fake, *_ = make(); fake.result["start"] = (False, code)
    c.handle("call Mom"); c.handle("yes")
    check(f"failure {code} reported", needle in said[-1] and "ringing" not in said[-1], said)
c, said, fake, *_ = make(); fake.result["start"] = (True, "unverified")
c.handle("call Mom"); c.handle("yes")
check("unverified not claimed as ringing", "couldn't confirm" in said[-1], said)

# does not hijack message flow
c, said, fake, store, state, clock = make(busy=True)
check("busy message flow: not hijacked", c.handle("call me when you're free") is None and c.handle("call Mom") is None and said == [])

# incoming: yes
c, said, fake, store, state, clock = make()
c.on_incoming("Mom", False)
check("in: asks", said[-1] == "Sir, Mom is calling you on WhatsApp. Shall I answer it?", said)
check("in: cleared other questions", state["cleared"] == 1)
check("in: yes answers", c.handle("yes") is True and fake.calls == [("answer",)] and "connected to Mom" in said[-1], (fake.calls, said))
check("in: hangup afterwards", c.handle("end the call") is True and fake.calls[-1] == ("hangup",))
# incoming: no -> leaves ringing, no decline pressed
c, said, fake, *_ = make(); c.on_incoming("Mom", True)
check("in: video wording", "video calling you" in said[-1], said)
c.handle("no")
check("in: no leaves it", fake.calls == [] and "leave it ringing" in said[-1], (fake.calls, said))
# incoming: decline
c, said, fake, *_ = make(); c.on_incoming("Mom", False); c.handle("decline the call")
check("in: decline pressed", fake.calls == [("decline",)] and said[-1] == "Call declined, sir.", (fake.calls, said))
# incoming: unclear twice stands down (does not swallow a third command)
c, said, fake, *_ = make(); c.on_incoming("Mom", False)
a = c.handle("what's the weather"); b = c.handle("tell me a joke"); d = c.handle("what time is it")
check("in: one re-ask then stand down (same as download flow)", a is True and b is None and d is None and fake.calls == [], (a, b, d))
# incoming: caller hangs up -> question withdrawn
c, said, fake, *_ = make(); c.on_incoming("Mom", False); c.on_call_end("Mom", False)
check("in: withdrawn on hang-up", "has ended" in said[-1], said)
check("in: later yes not treated as answer", c.handle("yes") is None and fake.calls == [])
# incoming: answered then toast vanishes -> no chatter
c, said, fake, *_ = make(); c.on_incoming("Mom", False); c.handle("yes"); n = len(said); c.on_call_end("Mom", False)
check("in: no chatter after answering", len(said) == n)
# incoming: missed with no pending question
c, said, fake, *_ = make(); c.on_call_end("Dave", True)
check("missed announced", said[-1] == "Sir, you missed a WhatsApp call from Dave.", said)
# incoming: after declining, the missed toast is not announced again
c, said, fake, *_ = make(); c.on_incoming("Mom", False); c.handle("decline the call"); n = len(said); c.on_call_end("Mom", True)
check("no missed chatter after decline", len(said) == n, said)
# incoming: dedupe
c, said, fake, *_ = make(); c.on_incoming("Mom", False); c.on_incoming("Mom", False)
check("incoming dedupe", len([s for s in said if "calling you" in s]) == 1, said)
# incoming: expires
c, said, fake, store, state, clock = make(); c.on_incoming("Mom", False); clock["t"] += 120
check("incoming expires", c.handle("yes") is None and fake.calls == [])
# incoming while user is mid message flow: explicit only, bare yes not consumed
c, said, fake, store, state, clock = make(busy=True); c.on_incoming("Mom", False)
check("busy: explicit wording", "Say answer the call" in said[-1] and state["cleared"] == 0, (said, state))
check("busy: bare yes NOT consumed", c.handle("yes") is None and fake.calls == [])
check("busy: explicit answer works", c.handle("answer the call") is True and fake.calls == [("answer",)])
# incoming answer failure is honest
c, said, fake, *_ = make(); fake.result["answer"] = (False, "no_button"); c.on_incoming("Mom", False); c.handle("yes")
check("answer failure honest", "couldn't find the answer button" in said[-1] and "connected" not in said[-1], said)
c, said, fake, *_ = make(); fake.result["answer"] = (True, "unverified"); c.on_incoming("Mom", False); c.handle("yes")
check("answer unverified honest", "couldn't confirm" in said[-1], said)
# unknown number caller
c, said, fake, *_ = make(); c.on_incoming("", False)
check("unknown caller wording", "an unknown number" in said[-1], said)
# hang up must not hijack when not ours
c, said, fake, *_ = make()
check("hang up not ours -> None", c.handle("end the call") is None and fake.calls == [])
c.actions.window = True
check("hang up with call window -> handled", c.handle("end the call") is True and fake.calls == [("hangup",)])
# explicit answer with no pending call needs 'whatsapp call'
c, said, fake, *_ = make()
check("bare 'answer it' ignored", c.handle("answer it") is None and fake.calls == [])
check("'answer the whatsapp call' works", c.handle("answer the whatsapp call") is True and fake.calls == [("answer",)])

# regression: chat text must never look like a call
for msg in ["I'm calling you now", "Are you free for a video call?", "call me when you can", "Mom is calling you lol",
            "Missed you so much", "the voice call quality was bad", "see you at the call tomorrow"]:
    check(f"chat text not a call: {msg!r}", T(["Mom", msg]) is None, T(["Mom", msg]))
    check(f"chat text not a call (helper): {msg!r}", not wac.looks_like_call_text("Mom", msg))
check("label 'Voice call' recognised", T(["Mom", "Voice call"])["kind"] == "incoming")
check("label 'Incoming call from X'", T(["WhatsApp", "Incoming call from Mom"])["caller"] == "Mom", T(["WhatsApp", "Incoming call from Mom"]))
check("label 'Missed voice call'", T(["Mom", "Missed voice call"])["kind"] == "missed")

print()
print("ALL PASSED" if not failures else f"{len(failures)} FAILED: {failures}")
sys.exit(1 if failures else 0)
