# FRIDAY 7.0 — what changed

7.0 is **additive**. Every 6.3 feature is still there and still routed the way it was: the listening, recognition, speech and
personality code (`friday_voice5.py`, `friday_speech5.py`, the recogniser/TTS code in `friday_backend.py`) is **byte-identical** to 6.3
(the release gate in `friday_ci7.py` checks this on every build). The 7.0 layer sits *beside* the old code and only answers a request
when it is sure the request is for a 7.0 feature; otherwise the command flows on to exactly the code that handled it in 6.3.

---------------------------------------------------------------------------------------------------------------------------------

## 1. The four fixes you asked for

### 1.1 "open <file name>" opens the file — never a website
* New fast file finder, `friday_filesearch7.py`. It keeps a compact index of your files (Desktop, Documents, Downloads, Pictures, Music,
  Videos, OneDrive and your project folders) that refreshes in the background, instead of walking every folder on every request.
* Matching is forgiving: spoken names ("my physics notes" → `Physics_Notes_Final.docx`), word order, underscores/dashes/camelCase, file
  extensions you did or didn't say ("resume pdf"), and typos ("budgt reprot" → `Budget_Report.xlsx`). Ranking prefers an exact name, then
  recent files, then well-known document types; system, program, cache, `node_modules` and `.git` folders are never indexed.
* If several files match about equally FRIDAY says so and asks which one, rather than guessing.
* **Unchanged on purpose:** when you say `open discord` / `open <app>` and the app is *not installed*, FRIDAY still opens its website in
  Chrome exactly as in 6.3. Only a spoken *file* name is kept away from the website fallback.
* Want FRIDAY to look in another folder (a second drive, a work folder)? Put one folder per line in `friday_data/file_roots.txt`.

### 1.2 FRIDAY can maximise (and restore / minimise) windows
* "maximise chrome", "maximize whatsapp", "make notepad full screen", "restore spotify", "minimise everything", "maximise all windows" …
  are routed to the window engine in `friday_system_control.py` (an explicit state machine: restore ↔ maximise ↔ minimise, with the
  result read back from Windows so she only says "done" when the window really changed).

### 1.3 Closing FRIDAY no longer closes your apps and tasks
* `main.js` used to end FRIDAY's process tree with `taskkill /T`, which also killed every app FRIDAY had launched. It now ends only
  FRIDAY's own helper processes (`endFridayHelpers`), so Chrome, Notepad, Spotify, a running download or script … stay open when you close
  FRIDAY.

### 1.4 "play <song> on YouTube" plays the song instead of saying "play paused"
* Cause: the word **play** was treated as the media Play/Pause key whenever it appeared, so "play despacito on youtube" toggled the
  current media (and said "paused").
* Fix (`friday_desktop_agent.is_play_request`): the media key is pressed **only** for bare transport commands (`play`, `pause`,
  `resume`, `stop`, `next`, `previous`). Anything with a thing to play ("play despacito", "play shape of you", "play a song in
  youtube") or naming YouTube / Spotify / Netflix / Prime Video is a *content* request and goes to the YouTube player, which finds the
  song, opens the video and (if the lookup fails) falls back to the search results page. "play a song in youtube" without a song name asks
  you which song.

---------------------------------------------------------------------------------------------------------------------------------

## 2. The 30 roadmap features (from `FRIDAY.docx`)

All new code is in `friday_*7.py`; shared plumbing is `friday_common7.py` (settings, event bus, UI channel).

| # | Feature | Module | What it does |
|---|---|---|---|
| 1 | Unified Agent Orchestrator | `friday_orchestrator7.py` | One controller for multi-step "missions": intent classification, task state machine (queued → planning → running ⇄ waiting for approval → verifying → done / partial / failed / paused / cancelled), bounded concurrency (2, or 1 in light mode), time-outs, cancel, pause and resume after a restart. |
| 2 | Universal Execution Verification | `friday_verify7.py` | Every tool call returns a **receipt** with evidence (file exists, process running, text present …). A tool saying "ok" is not believed unless the postcondition holds. Failures are classified (transient / timeout / permission / not-found / …) and retried or revised accordingly. |
| 3 | Performance & Health Monitor | `friday_health7.py` | Latency, RAM, CPU, tool success rates, component health checks; switches to **light mode** (fewer optional model calls, 1 worker) when the laptop is struggling and back when it recovers. |
| 4 | Adaptive Multi-Model Intelligence | `friday_router7.py` | Routes each request to instant (exact local answer) / general / reasoning / code / sensitive-local paths using the models that are actually available; falls back safely. |
| 5 | Planning & Reasoning Engine | `friday_planner7.py` | Splits a goal into verifiable steps with dependencies, checks each result against what the plan expected and **revises** the plan when reality differs. |
| 6 | Specialised Agent Team | `friday_team7.py` | Research, coding, finance, document and computer-control specialists with fixed tool allow-lists, run under the orchestrator (≤2 at once, one model call at a time). |
| 7 | Advanced Memory | `friday_memory7.py` | Episodic, semantic, procedural, project and preference memory; newer facts *supersede* older ones with history kept; secrets/API keys are refused; correct / forget / recall. |
| 8 | Feedback-Driven Learning | `friday_learning7.py` | Lessons from corrections, failures and benchmarks. Shown as proposals you can apply or undo; needs ≥2 pieces of evidence; nothing trains a model. |
| 9 | Context & Continuity | `friday_continuity7.py` | Before a related task starts, offers to continue from the last *verified* checkpoint; asks which when several fit. |
| 10 | Goal-Driven Task Engine | `friday_goals7.py` | Long-term **objectives** with milestones, blockers, due dates and honest progress (only verified milestones count). |
| 11 | Reliable Computer-Use | `friday_computer7.py` | Stable APIs first (app launcher, file finder, window control), screen clicking last; every action checked before it is reported as done. |
| 12 | Sandboxed Coding & Repair | `friday_repair7.py` | Inspect → propose an exact edit → test it on a **copy** → apply only after you confirm, with backup and automatic rollback. |
| 13 | Permission & Policy | `friday_policy7.py` | Every action is risk-classified (safe / routine / sensitive / irreversible) and allowed, asked or denied. Instructions found inside web pages, documents or tool output are never obeyed. Autonomy level never unlocks irreversible actions. User rules ("never write files") are honoured. |
| 14 | Evidence-Based Research | `friday_evidence7.py` | Several sources, original documents, source grading, publication dates, verbatim claims, cross-checking; says what is corroborated, single-source or conflicting. |
| 15 | Multimodal Understanding | `friday_multimodal7.py` | Text, files, images, a fresh screenshot or camera frame as numbered items `[M1] …` with provenance; claims point back to the item. |
| 16 | Knowledge Synthesis | `friday_synthesis7.py` | Turns gathered material into a cited report (summary, findings, calculations, assumptions, comparison, uncertainty, evidence index). |
| 17 | Domain intelligence (saving money) | `friday_savings7.py` | Price book, recipe costing, alternatives, price history, budget checks. **There are no built-in prices** — every number comes from prices you told her, arithmetic is exact and re-checked, missing prices are reported as "NOT PRICED". |
| 18 | Speculative & Parallel Processing | `friday_runtime7.py` | Cheap look-ups start while the reply is being prepared; results never change the answer. |
| 19 | Streaming Conversation | `friday_stream7.py` | Careful sentence segmentation (abbreviations, decimals, URLs) so long reports are spoken sentence by sentence; code and headings are not read aloud. Uses the existing speech path — it does not replace it. |
| 20 | Resource-Aware Runtime | `friday_runtime7.py` | Bounded pool, idle components unloaded under memory pressure, light mode (see #3). |
| 21 | Conversation State & Recovery | `friday_runtime7.py` | Reports one of listening / thinking / speaking / idle / interrupted / recovering / degraded with the reason; read-only with respect to the microphone. |
| 22 | Automated Intelligence Benchmark | `friday_bench7.py` | Fixed offline cases (reasoning, memory, planning, verification, routing …) run in an isolated process with its own temporary database — your data is never touched. |
| 23 | CI & Regression Protection | `friday_ci7.py` | Release gate: everything compiles, JavaScript parses, no public function was removed, and the listening/speaking files are byte-identical to the known-good build. Baseline shipped in `friday_data/ci7/known_good_63.json`. |
| 24 | Controlled Self-Improvement | `friday_selfimprove7.py` | Finds recurring failures from real receipts/incidents, proposes a concrete reviewable fix, applies it only after "confirm improvement", and can undo it. |
| 25 | Security & Recovery Center | `friday_seccenter7.py` | Secret scan (masked), integrity check, backups, unclean-shutdown detection, one status page. |
| 26 | Capability Registry | `friday_capabilities7.py` | An honest inventory: for each tool its dependencies, permission, last self-test and success rate. |
| 27 | Unified Context Graph | `friday_graph7.py` | Projects, objectives, milestones, missions, documents, people, decisions, deadlines and outcomes **derived** from records FRIDAY already keeps (nothing invented, each node shows its source and age). |
| 28 | Independent Critic | `friday_critic7.py` | A separate checker that recomputes arithmetic, compares claims with receipts, compiles code, checks cited sources exist. A model is used only when worth the cost (`critic_budget`). |
| 29 | Proactive Assistance | `friday_proactive7.py` | Calm **suggestions** (objective near deadline, blocked objective, paused mission, stale price …). She never runs one herself; you say "do suggestion 1". Limited per day, with a minimum gap, quiet hours, not while she is busy, and not in light mode. |
| 30 | Unified FRIDAY Runtime | `friday_core7.py` | The single front door for 7.0: called after the 6.0 core for every typed or spoken command; claims only 7.0 requests; a module that throws is skipped, never fatal; very long pasted text is never pattern-matched. |

### Things you can say (examples)
* Missions: "research cheaper rice recipes, cost them, compare alternatives and save the findings" · "what missions are running" · "resume the mission" · "cancel the mission"
* Objectives: "create an objective to ship the site with milestones write copy; deploy" · "list objectives" · "how is the Atlas website" · "what is blocking the Atlas website"
* Context graph: "show the context graph" · "show all my deadlines" · "what is connected to Orion" · "show the context for Orion" · "why do we have <thing>" (these answer only when the thing really exists in your records; otherwise the normal chat answers)
* Savings: "price of rice is 60 per kg at Keells" · "what is the price of rice" · "price history of rice" · "cost this recipe: 2 kg rice, 1 kg dhal" (your grocery budget comes from the existing finance command "monthly plan groceries 30000")
* Suggestions: "any suggestions" · "do suggestion 1" · "dismiss suggestion 2" · "snooze suggestion 3" · "turn off suggestions"
* Safety & health: "security status" · "scan for secrets" · "check the integrity" · "verify my backups" · "what is your autonomy level" · "set autonomy to ask more" · "free up memory" · "test your tools" · "run the intelligence benchmark" · "run the release gate" · "show me the improvements"
* Memory: "I prefer …" / "from now on …" · "project note orion: progress: …" · "project status orion" · "what did we do last time" · "how do you know that …" · "correction: …" (the 6.x "remember that …" / "what do you remember about me" keep working exactly as before)
* Version: "what version are you" → "FRIDAY 7.0".

### New page: **Intelligence** (left navigation, "Intel")
Overview · Missions · Goals · Memory · Evidence · Security · Health · Quality · Savings · Suggestions · Settings. Every button on these tabs is wired
to a backend action; actions answer with a toast, and unknown settings/actions are refused with a clear message.

### Settings (Intelligence → Settings, or `friday_data` table `cfg7`)
`autonomy_level` (ask_more / balanced / independent) · `auto_orchestrate` · `proactive_enabled` · `proactive_speak` (default off — suggestions are shown, not spoken) ·
`proactive_max_per_day` (4) · `proactive_min_gap_min` (45) · `quiet_start` / `quiet_end` (22:00–07:00) · `stream_segments` · `light_ram_pct` (88) · `light_cpu_pct` (92) ·
`speculate` · `critic_budget` (never / balanced / always) · `ollama_model_code` / `_reasoning` / `_sensitive` (optional local models) · `retention_receipts_days` (90).

---------------------------------------------------------------------------------------------------------------------------------

## 3. 8 GB laptops
* At most 2 missions/tools run at once (1 in light mode) and only one model call at a time.
* The file index is compact and refreshes in the background; the context graph rebuilds at most once every 45 s and only from existing rows.
* Under memory pressure idle caches, the speculation cache, the file index and the database page cache are released automatically
  ("free up memory" does it on demand).
* Optional extras (critic model call, proactive suggestions, speculation, summaries) are skipped in light mode; answers themselves are never degraded.

## 4. Tests
* `FRIDAY_TEST_V70.py` — 63 tests: the four fixes, missions (verified, retried, refused when a claimed file doesn't exist, approval, cancel, restart), verification, critic,
  policy, objectives, memory, savings, streaming, health, context graph, suggestions, security centre, release gate, an 83-command **"7.0 must not steal an existing command"** battery, and every Intelligence tab/action.
* All earlier test files still run. Test files that already failed on 6.3 (they assert 6.2-era source text, or need `sympy`) fail exactly the same way; nothing that passed on 6.3 fails on 7.0.
* `python friday_ci7.py gate` — release gate. `python friday_bench7.py` — benchmark.

## 5. Honest limits
Tested here on Linux with Windows calls faked, so these still need your eyes on a real Windows PC:
* real microphone listening, wake word and speech output (these files are unchanged, so they behave as in 6.3);
* actual window maximise/restore on your screen, closing FRIDAY with other apps open, and real Chrome/YouTube playback (YouTube can change its page at any time; the search-results fallback is there for that);
* Gemini / Ollama answers, OCR and image understanding, WhatsApp;
* the very first "open <file>" after a fresh install waits a few seconds for the first file-index build (it is saved to disk, so later starts are instant); on a very large drive the first full build keeps running in the background.

## 6. Known quirks (existed in 6.3, left alone on purpose)
* "open whatsapp notes" enters the WhatsApp flow and "open youtube notes" opens YouTube — app names win over file names when the name *starts* with an installed app. Say "open the file whatsapp notes" to be explicit.
* Suggestions and the critic's optional model review need a working model connection; without one they are skipped, not faked.
