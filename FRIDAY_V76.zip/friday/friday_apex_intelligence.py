"""
FRIDAY APEX INTELLIGENCE v4020
==============================
Additive intelligence layer for FRIDAY V4010.x.

Design contract:
- NEVER replaces microphone, VAD, ASR, wake-word or TTS.
- NEVER removes or rewrites an existing feature.
- Uses the existing V4010 gateway as the insertion point.
- Degrades gracefully when optional packages/API access are unavailable.
- Separates FAST commands from expensive deep reasoning.
- Provides model routing, deep reasoning, self-critique, grounded research,
  coding-engineer workflows, local knowledge retrieval, vision, tool discovery,
  and controlled self-improvement proposals.

The module is intentionally self-contained so it can be removed without
affecting the legacy backend.
"""
from __future__ import annotations
import ast, concurrent.futures, contextlib, difflib, hashlib, json, os, re, shutil, sqlite3
import subprocess, tempfile, time, traceback, uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Callable, Optional

ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / "apex_state"
STATE_DIR.mkdir(exist_ok=True)
DB = STATE_DIR / "knowledge.sqlite3"
AUDIT = STATE_DIR / "apex_audit.jsonl"
VERSION = "4030.0-APEX-FRONTIER"

# ------------------------------ routing ---------------------------------
_FAST_RE = re.compile(r"^(what is|who is|where is|when is|how much|calculate|convert|open |close |launch |start |play |pause |stop )", re.I)
_RESEARCH_RE = re.compile(r"\b(research|investigate|latest|current|sources?|evidence|compare|verify|look up|find out|news)\b", re.I)
_CODE_RE = re.compile(r"\b(code|coding|program|python|javascript|typescript|bug|debug|error|exception|compile|refactor|repo|repository|project|implement|fix the code|write a function)\b", re.I)
_VISION_RE = re.compile(r"\b(screen|screenshot|look at|what.?s on my screen|click the|button|window|ui|interface)\b", re.I)
_CREATE_RE = re.compile(r"\b(create|generate|build|write|make|draft|export)\b", re.I)
_HARD_RE = re.compile(r"\b(delete|remove|format|shutdown|restart|uninstall|purchase|buy|pay|transfer|send|publish|post)\b", re.I)
_REASON_RE = re.compile(r"\b(explain why|why|prove|derive|design|architect|solve|analy[sz]e|reason|strategy|plan|decide|evaluate)\b", re.I)
_MATH_RE = re.compile(r"\b(math|mathematics|equation|integral|derivative|differentiate|integrate|probability|statistics|matrix|vector|geometry|trigonometry|calculus|algebra|calculate|solve for|proof)\b", re.I)
_EXPLAIN_RE = re.compile(r"\b(explain|teach me|break down|why does|how does|concept|intuition|analogy)\b", re.I)
_WRITING_RE = re.compile(r"\b(write|rewrite|polish|edit|draft|essay|article|speech|story|report|email|caption|documentation|professional|creative writing)\b", re.I)
_IDEA_RE = re.compile(r"\b(idea|ideas|brainstorm|innovate|invent|creative|novel|startup|concepts|solutions|possibilit(?:y|ies))\b", re.I)
_KNOWLEDGE_RE = re.compile(r"\b(what is|who is|when did|where did|define|meaning of|history of|tell me about|general knowledge)\b", re.I)
_UNFAMILIAR_RE = re.compile(r"\b(unfamiliar|new problem|never seen|novel problem|unknown|figure out|work this out|challenge)\b", re.I)

@dataclass
class Route:
    lane: str
    confidence: float
    reasons: list[str]
    requires_verification: bool

def route(command: str) -> Route:
    """Route by capability, while preserving the cheap legacy fast path."""
    c = str(command or "").strip()
    low = c.lower()
    if not c:
        return Route("fast", 1.0, ["empty"], False)
    reasons = []
    scores = {"fast": 0.0, "research": 0.0, "coding": 0.0, "vision": 0.0, "deep": 0.0,
              "math": 0.0, "writing": 0.0, "ideas": 0.0, "knowledge": 0.0}
    if _FAST_RE.search(low): scores["fast"] += .55; reasons.append("fast-command")
    if _RESEARCH_RE.search(low): scores["research"] += .8; reasons.append("live-evidence")
    if _CODE_RE.search(low): scores["coding"] += .9; reasons.append("engineering")
    if _VISION_RE.search(low): scores["vision"] += .75; reasons.append("visual-computer")
    if _MATH_RE.search(low): scores["math"] += 1.45; reasons.append("mathematical-reasoning")
    if _WRITING_RE.search(low): scores["writing"] += .95; reasons.append("writing")
    if _IDEA_RE.search(low): scores["ideas"] += .9; reasons.append("idea-generation")
    if _KNOWLEDGE_RE.search(low): scores["knowledge"] += .75; reasons.append("general-knowledge")
    if _UNFAMILIAR_RE.search(low): scores["deep"] += .9; reasons.append("unfamiliar-problem")
    if _EXPLAIN_RE.search(low): scores["deep"] += .7; reasons.append("explanation")
    if _REASON_RE.search(low) or len(c.split()) > 18: scores["deep"] += .65; reasons.append("complex-reasoning")
    if _CREATE_RE.search(low): scores["deep"] += .25; reasons.append("deliverable")
    if low.count(" and ") + low.count(" then ") >= 2: scores["deep"] += .3; reasons.append("multi-step")
    # Fast command patterns remain authoritative unless a clear intellectual task
    # is present. This protects the existing low-latency PC command path.
    intellectual = any(scores[k] >= .75 for k in ("research","coding","vision","math","writing","ideas","knowledge","deep"))
    if scores["fast"] >= .55 and not intellectual:
        return Route("fast", min(.99, scores["fast"]), reasons or ["fast"], False)
    # A clear mathematical task gets the deterministic math lane even when
    # words like "unfamiliar" also activate the generic deep-reasoning lane.
    if scores["math"] >= 1.4 and max(scores["research"], scores["coding"], scores["vision"]) < scores["math"]:
        lane = "math"
    else:
        lane = max((k for k in scores if k != "fast"), key=scores.get)
    conf = min(.99, max(.55, scores[lane]))
    return Route(lane, conf, reasons or ["general"], bool(_HARD_RE.search(low) or lane not in {"knowledge","writing"}))

# ------------------------------ audit -----------------------------------
def _audit(event: str, **data: Any) -> None:
    rec = {"ts": time.time(), "event": event, "version": VERSION, **data}
    try:
        with AUDIT.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
    except Exception:
        pass

# ------------------------------ model bridge ----------------------------
def _backend():
    try:
        import friday_backend as b
        return b
    except Exception:
        return None

def _gemini(prompt: str, *, system: str = "", temperature: float = .2,
            image: Any = None, model: str | None = None) -> str | None:
    """Use the already-configured V4010 Gemini client without touching voice."""
    b = _backend()
    if b is not None:
        try:
            ensure = getattr(b, "_ensure_gemini_client", None)
            if callable(ensure):
                ensure()
            client = getattr(b, "client", None)
            if client is not None:
                model_name = model or getattr(b, "GEMINI_MODEL", None)
                contents = (system + "\n\n" + prompt).strip() if system else prompt
                if image is not None:
                    contents = [contents, image]
                r = client.models.generate_content(model=model_name, contents=contents)
                text = getattr(r, "text", None)
                if text:
                    return str(text).strip()
        except Exception as e:
            _audit("model_primary_failed", error=str(e)[:500])
    # Optional independent Google GenAI fallback.
    try:
        from google import genai
        key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if key:
            c = genai.Client(api_key=key)
            model_name = model or os.getenv("FRIDAY_APEX_MODEL", "gemini-2.5-pro")
            contents = (system + "\n\n" + prompt).strip() if system else prompt
            if image is not None:
                contents = [contents, image]
            r = c.models.generate_content(model=model_name, contents=contents)
            return str(getattr(r, "text", "") or "").strip() or None
    except Exception as e:
        _audit("model_fallback_failed", error=str(e)[:500])
    return None

def _json_model(prompt: str, schema_hint: str) -> dict[str, Any] | None:
    raw = _gemini(
        prompt + "\n\nReturn ONLY valid JSON matching this shape:\n" + schema_hint,
        system=("You are FRIDAY APEX, a rigorous engineering-grade reasoning engine. "
                "Do not invent facts. Mark uncertainty explicitly. Prefer evidence."),
        temperature=.1,
    )
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        m = re.search(r"\{.*\}", raw, re.S)
        if m:
            try: return json.loads(m.group(0))
            except Exception: pass
    return None

# --------------------------- self critique --------------------------------
def deep_reason(command: str, context: str = "") -> dict[str, Any]:
    started = time.perf_counter()
    plan = _json_model(
        f"""Solve the user's problem rigorously.
USER: {command}
CONTEXT: {context[:18000]}
First decompose the problem, identify missing assumptions, compare plausible approaches,
and produce a candidate solution. Do not claim external facts without evidence.
""",
        '{"problem":"...", "assumptions":[],"subproblems":[],"candidate":"...","uncertainties":[]}',
    ) or {"problem": command, "candidate": _gemini(command) or "", "uncertainties":["model structured output unavailable"]}
    critique = _json_model(
        f"""Act as an adversarial reviewer.
USER REQUEST: {command}
CANDIDATE:
{json.dumps(plan, ensure_ascii=False)[:18000]}
Find factual errors, logical gaps, unsupported assumptions, and edge cases.
If the candidate is sound, say why. Then give precise corrections.
""",
        '{"issues":[],"severity":"low|medium|high","corrections":[],"confidence":0.0}',
    ) or {"issues": [], "severity": "unknown", "corrections": []}
    final = _gemini(
        f"""Produce the final answer to this request.
Request: {command}
Candidate reasoning: {json.dumps(plan, ensure_ascii=False)}
Independent critique: {json.dumps(critique, ensure_ascii=False)}
Correct every valid issue from the critique. Do not mention hidden reasoning.
Give a clear answer, state uncertainty where relevant, and distinguish verified facts
from assumptions. Context: {context[:12000]}""",
        system="You are FRIDAY APEX. Accuracy and usefulness are more important than confidence.",
        temperature=.15,
    ) or plan.get("candidate") or "I could not obtain a reliable reasoning result."
    result = {"lane":"deep","answer":final,"critique":critique,
              "confidence":float(critique.get("confidence", .75) or .75),
              "latency_s":round(time.perf_counter()-started,3)}
    _audit("deep_reason", command=command[:500], confidence=result["confidence"])
    return result

# ------------------------------ research ---------------------------------
def grounded_research(query: str) -> dict[str, Any]:
    try:
        import friday_web_research
        raw = friday_web_research.run_web_research(query, use_cache=True) or {}
    except Exception as e:
        return {"lane":"research","answer":None,"sources":[],"error":str(e)}
    sources = raw.get("_raw_sources") or raw.get("sources") or []
    compact = []
    for s in sources:
        if isinstance(s, dict):
            compact.append({"title": s.get("title"), "url": s.get("url"), "text": str(s.get("text",""))[:5000]})
    evidence = json.dumps(compact, ensure_ascii=False)[:26000]
    answer = _gemini(
        f"""Answer the user's research request using ONLY the evidence below.
REQUEST: {query}
EVIDENCE:
{evidence}
Rules: never invent a source; if evidence is insufficient, say so; reconcile contradictions;
prefer primary/official sources when present; include source titles/URLs in a compact Sources section.""",
        system="You are FRIDAY APEX Research. Ground every substantive current claim in supplied evidence.",
        temperature=.1,
    ) or raw.get("answer") or "Research completed, but synthesis was unavailable."
    return {"lane":"research","answer":answer,"sources":[{"title":s.get("title"),"url":s.get("url")} for s in compact],
            "source_count":len(compact),"verified":bool(compact)}

# --------------------------- knowledge base ------------------------------
def _db():
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS docs(
        id TEXT PRIMARY KEY, path TEXT, title TEXT, content TEXT, hash TEXT,
        updated REAL)""")
    con.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS docs_fts USING fts5(id UNINDEXED, title, content)""")
    return con

def index_path(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    files = [p] if p.is_file() else [x for x in p.rglob("*") if x.is_file() and x.stat().st_size < 5_000_000]
    count = 0
    con = _db()
    try:
        for f in files:
            if f.suffix.lower() not in {".txt",".md",".py",".js",".ts",".tsx",".jsx",".json",".csv",".html",".css",".xml",".yaml",".yml",".ini"}:
                continue
            try: text = f.read_text(encoding="utf-8", errors="ignore")
            except Exception: continue
            h=hashlib.sha256(text.encode("utf-8","ignore")).hexdigest()
            fid=hashlib.sha1(str(f.resolve()).encode()).hexdigest()
            con.execute("INSERT OR REPLACE INTO docs VALUES(?,?,?,?,?,?)",(fid,str(f),f.name,text,h,time.time()))
            con.execute("DELETE FROM docs_fts WHERE id=?",(fid,))
            con.execute("INSERT INTO docs_fts(id,title,content) VALUES(?,?,?)",(fid,f.name,text))
            count += 1
        con.commit()
    finally: con.close()
    _audit("knowledge_indexed", path=str(p), count=count)
    return {"indexed":count,"database":str(DB)}

def recall_knowledge(query: str, limit: int = 8) -> list[dict[str,Any]]:
    con=_db()
    try:
        # FTS query is escaped to avoid malformed operators from natural language.
        terms=[x for x in re.findall(r"[A-Za-z0-9_]{2,}",query)][:12]
        q=" OR ".join(terms) or '""'
        rows=con.execute("SELECT d.path,d.title,substr(d.content,1,7000) FROM docs_fts f JOIN docs d ON d.id=f.id WHERE docs_fts MATCH ? LIMIT ?",(q,limit)).fetchall()
        return [{"path":r[0],"title":r[1],"content":r[2]} for r in rows]
    except Exception:
        return []
    finally: con.close()

# ----------------------------- coding ------------------------------------
def inspect_project(path: str | Path) -> dict[str,Any]:
    p=Path(path).resolve()
    if not p.exists(): return {"ok":False,"error":"path does not exist"}
    files=[]
    for f in p.rglob("*"):
        if f.is_file() and f.stat().st_size < 2_000_000 and f.suffix.lower() in {".py",".js",".ts",".tsx",".jsx",".json",".html",".css",".md"}:
            files.append({"path":str(f.relative_to(p)),"bytes":f.stat().st_size})
        if len(files)>=1500: break
    return {"ok":True,"root":str(p),"files":files,"count":len(files)}

def run_static_checks(path: str | Path) -> dict[str,Any]:
    p=Path(path)
    py=[x for x in p.rglob("*.py") if x.is_file()][:1200]
    errors=[]
    for f in py:
        try: ast.parse(f.read_text(encoding="utf-8",errors="ignore"),filename=str(f))
        except Exception as e: errors.append({"file":str(f),"error":str(e)})
    return {"python_files":len(py),"syntax_errors":errors,"passed":not errors}

def coding_engineer(command: str, project: str | Path = ".") -> dict[str,Any]:
    root=Path(project).resolve()
    inspection=inspect_project(root)
    checks=run_static_checks(root)
    kb=recall_knowledge(command,8)
    prompt=f"""You are FRIDAY APEX Senior Software Engineer.
Task: {command}
Project: {root}
Project inventory: {json.dumps(inspection,ensure_ascii=False)[:18000]}
Static check: {json.dumps(checks,ensure_ascii=False)[:12000]}
Relevant indexed knowledge: {json.dumps(kb,ensure_ascii=False)[:12000]}
Return a safe engineering plan. Identify exact files to inspect/change, tests to run,
regression risks, rollback strategy, and what evidence proves success.
Do not claim you changed anything; this stage is planning only."""
    plan=_json_model(prompt,'{"diagnosis":"...","files":[],"changes":[],"tests":[],"risks":[],"rollback":"..."}') or {}
    return {"lane":"coding","plan":plan,"inspection":inspection,"checks":checks}

def _safe_project_files(root: Path) -> list[Path]:
    out=[]
    for f in root.rglob("*"):
        if not f.is_file(): continue
        if any(part in {".git","node_modules","venv",".venv","__pycache__","apex_state"} for part in f.parts):
            continue
        if f.stat().st_size > 1_500_000: continue
        if f.suffix.lower() in {".py",".js",".ts",".tsx",".jsx",".json",".html",".css",".md"}:
            out.append(f)
        if len(out)>=500: break
    return out

def _make_snapshot(root: Path, files: list[Path]) -> Path:
    snap=STATE_DIR / ("backup_"+time.strftime("%Y%m%d_%H%M%S")+"_"+uuid.uuid4().hex[:6])
    snap.mkdir(parents=True,exist_ok=True)
    manifest=[]
    for f in files:
        rel=f.relative_to(root)
        dest=snap / rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(f,dest)
        manifest.append(str(rel))
    (snap/"MANIFEST.json").write_text(json.dumps({"root":str(root),"files":manifest},indent=2),encoding="utf-8")
    return snap

def apply_coding_fix(command: str, project: str | Path = ".") -> dict[str,Any]:
    """Controlled coding agent: backup -> model edit plan -> exact replacements
    -> syntax/tests -> rollback on failed verification.

    It intentionally requires explicit mutation language and never executes
    arbitrary shell commands proposed by the model.
    """
    root=Path(project).resolve()
    if not re.search(r"\b(fix|implement|modify|change|refactor|patch|repair|add)\b", command, re.I):
        return {"lane":"coding","applied":False,"reason":"explicit mutation language required"}
    files=_safe_project_files(root)
    inventory=[str(f.relative_to(root)) for f in files]
    prompt=f"""You are a senior software engineer operating on a local project.
USER REQUEST: {command}
PROJECT ROOT: {root}
FILES:
{json.dumps(inventory[:500],ensure_ascii=False)}
Return JSON only:
{{
 "diagnosis":"...",
 "edits":[{{"file":"relative/path","old":"exact small snippet","new":"replacement snippet"}}],
 "tests":[{{"kind":"python_compile","file":"relative/path"}}]
}}
Rules:
- Never invent a file.
- Only edit files listed above.
- Keep edits small and local.
- Do not touch credentials, .env files, node_modules, virtual environments or binaries.
- Do not delete whole files.
- The old snippet MUST match exactly.
- Do not use shell commands.
"""
    plan=_json_model(prompt,'{"diagnosis":"...","edits":[],"tests":[]}')
    if not plan or not isinstance(plan.get("edits"),list):
        return {"lane":"coding","applied":False,"reason":"no valid structured edit plan","plan":plan or {}}
    targets=[]
    for e in plan["edits"]:
        rel=str(e.get("file",""))
        f=(root/rel).resolve()
        try: f.relative_to(root)
        except ValueError: return {"lane":"coding","applied":False,"reason":"path escaped project","file":rel}
        if f not in files or not f.exists(): return {"lane":"coding","applied":False,"reason":"file not in safe inventory","file":rel}
        targets.append(f)
    snap=_make_snapshot(root,list(dict.fromkeys(targets)))
    changed=[]
    try:
        for e,f in zip(plan["edits"],targets):
            old=str(e.get("old",""))
            new=str(e.get("new",""))
            data=f.read_text(encoding="utf-8",errors="strict")
            if not old or data.count(old)!=1:
                raise ValueError(f"exact edit anchor not unique in {f.relative_to(root)}")
            f.write_text(data.replace(old,new,1),encoding="utf-8")
            changed.append(str(f.relative_to(root)))
        checks=run_static_checks(root)
        if not checks["passed"]:
            raise RuntimeError("Python syntax verification failed")
        _audit("coding_fix_applied", command=command[:500], changed=changed, backup=str(snap))
        return {"lane":"coding","applied":True,"changed":changed,"backup":str(snap),
                "checks":checks,"diagnosis":plan.get("diagnosis"),"plan":plan}
    except Exception as exc:
        for f in targets:
            rel=f.relative_to(root)
            b=snap/rel
            if b.exists(): shutil.copy2(b,f)
        _audit("coding_fix_rolled_back", command=command[:500], error=str(exc), backup=str(snap))
        return {"lane":"coding","applied":False,"rolled_back":True,"error":str(exc),"backup":str(snap),"plan":plan}

# ----------------------- advanced cognition ------------------------------
def _openai(prompt: str, *, system: str = "", effort: str = "max", model: str | None = None) -> str | None:
    """Optional frontier-model bridge using the Responses API via stdlib HTTP.
    It is completely optional; without OPENAI_API_KEY FRIDAY uses its existing Gemini bridge.
    """
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return None
    try:
        import urllib.request
        model_name = model or os.getenv("FRIDAY_OPENAI_MODEL", "gpt-5.6")
        payload = {"model": model_name, "input": []}
        if system:
            payload["input"].append({"role":"system","content":[{"type":"input_text","text":system}]})
        payload["input"].append({"role":"user","content":[{"type":"input_text","text":prompt}]})
        payload["reasoning"] = {"effort": os.getenv("FRIDAY_REASONING_EFFORT", effort)}
        payload["max_output_tokens"] = int(os.getenv("FRIDAY_MAX_OUTPUT_TOKENS", "24000"))
        req=urllib.request.Request("https://api.openai.com/v1/responses", data=json.dumps(payload).encode(),
                                   headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=120) as resp:
            data=json.loads(resp.read().decode("utf-8"))
        # Responses API exposes output content in output[].content[].text.
        chunks=[]
        for item in data.get("output",[]) or []:
            for part in item.get("content",[]) or []:
                if isinstance(part,dict) and part.get("type") in {"output_text","text"} and part.get("text"):
                    chunks.append(part["text"])
        text="\n".join(chunks).strip()
        if text: return text
    except Exception as e:
        _audit("openai_bridge_failed", error=str(e)[:500])
    return None

def _frontier(prompt: str, *, system: str, effort: str = "max", temperature: float = .15) -> str | None:
    """Prefer an explicitly configured frontier provider; otherwise preserve Gemini."""
    provider=os.getenv("FRIDAY_APEX_PROVIDER","auto").lower()
    if provider in {"openai","auto"}:
        out=_openai(prompt, system=system, effort=effort)
        if out: return out
    return _gemini(prompt, system=system, temperature=temperature)

def advanced_math(command: str) -> dict[str,Any]:
    started=time.perf_counter()
    local={}
    # Deterministic symbolic assistance when SymPy is installed; never substitute
    # a model's guess for an exact result when a symbolic solver can verify it.
    try:
        import sympy as sp
        local["sympy_available"]=True
        local["capabilities"]=["simplify","solve","differentiate","integrate","factor","limit"]
    except Exception:
        local["sympy_available"]=False
    answer=_frontier(f"""Solve this mathematical problem rigorously: {command}\n\nUse explicit derivations and check the result independently. If there are multiple interpretations, state them. For numerical results, show enough intermediate work to make errors detectable. Do not invent missing givens.""",
        system="You are FRIDAY APEX Mathematical Reasoner. Be exact. Prefer symbolic reasoning, dimensional checks, boundary checks, and an independent verification pass.", effort="max")
    verify=_frontier(f"""Audit the proposed mathematical answer below for algebraic, arithmetic, logical, dimensional, and edge-case errors. Problem: {command}\nPROPOSED ANSWER:\n{answer or ''}\nReturn corrected mathematics only if needed, otherwise say VERIFIED.""",
        system="You are a meticulous independent mathematics verifier.", effort="high") if answer else None
    return {"lane":"math","answer":answer or "I could not obtain a reliable mathematical solution.","verification":verify,
            "verified":bool(answer),"latency_s":round(time.perf_counter()-started,3),"local":local}

def advanced_explanation(command: str) -> dict[str,Any]:
    answer=_frontier(f"""Explain the following so a learner can genuinely understand it: {command}\nBuild from prerequisites to intuition, then mechanism, then a concrete example, then common misconceptions and a concise mastery check. Adapt depth to the question.""",
        system="You are FRIDAY APEX Explanation Engine. Teach rather than merely state facts. Use precise terminology, intuitive analogies, examples, and explicit limits of each analogy.", effort="high")
    return {"lane":"deep","answer":answer or "I could not generate a reliable explanation.","verified":bool(answer)}

def advanced_knowledge(command: str) -> dict[str,Any]:
    # General knowledge uses the frontier model first. For freshness-sensitive
    # questions, the existing research router should win before this lane.
    answer=_frontier(f"Answer this general-knowledge question accurately: {command}. Distinguish established facts from uncertainty and avoid fabricating dates, names, statistics, or citations.",
        system="You are FRIDAY APEX General Knowledge Engine. Give concise but high-information answers and explicitly flag uncertainty.", effort="high")
    return {"lane":"knowledge","answer":answer or "I could not produce a reliable knowledge answer.","verified":bool(answer)}

def advanced_writing(command: str) -> dict[str,Any]:
    answer=_frontier(f"""Create the requested writing for: {command}\nInfer the appropriate audience, purpose, tone, structure and constraints. Produce polished original text. Do not claim sources or facts that were not supplied or verified.""",
        system="You are FRIDAY APEX Writing Engine. Produce sophisticated, natural, original prose with strong structure, clarity, rhythm, and audience awareness.", effort="high")
    return {"lane":"writing","answer":answer or "I could not generate the requested writing.","verified":bool(answer)}

def advanced_ideas(command: str) -> dict[str,Any]:
    # Deliberately separate divergent generation from convergence so the model
    # explores genuinely different solution families before selecting candidates.
    candidates=_frontier(f"Generate 12 genuinely different ideas for: {command}. Explore technical, unconventional, low-cost, scalable, human-centered, and contrarian directions. Avoid superficial rewordings.",
        system="You are FRIDAY APEX Innovation Engine. Maximize diversity of useful ideas first. Do not optimize too early.", effort="high")
    synthesis=_frontier(f"Cluster and improve the ideas below for the original request: {command}\nIDEAS:\n{candidates or ''}\nProduce a set of distinct, actionable concepts with mechanisms, assumptions, risks, and what would make each novel.",
        system="You are FRIDAY APEX Venture/Innovation Strategist. Converge only after preserving diversity; do not declare a single universal winner.", effort="high") if candidates else None
    return {"lane":"ideas","answer":synthesis or candidates or "I could not generate useful ideas.","verified":bool(synthesis or candidates),"candidate_pool":candidates}

def advanced_unfamiliar(command: str) -> dict[str,Any]:
    # Generalizes the deep loop for genuinely unfamiliar problems.
    return deep_reason(command, context="Treat this as a novel problem. Search your internal knowledge for analogous structures, explicitly test assumptions, generate at least two approaches, and stress-test the final approach.")

# ------------------------------ vision -----------------------------------
def inspect_screen(question: str) -> dict[str,Any]:
    try:
        import friday_truth_verifier as tv
        snap=tv.snapshot()
        image=snap.get("image")
        if image is None:
            return {"lane":"vision","answer":"Screen capture is unavailable.","verified":False}
        answer=_gemini(
            f"""Analyze this screenshot to answer: {question}
Describe only visible evidence. If something cannot be established from the image, say so.
If the user asks for a UI action, identify the relevant visible target but do not claim an action occurred.""",
            system="You are FRIDAY APEX Vision. Be precise about visible UI state.",
            temperature=.1, image=image)
        return {"lane":"vision","answer":answer or "I could not analyze the screen.","window":snap.get("window"),"ocr":snap.get("ocr","")[:2000],"verified":True}
    except Exception as e:
        return {"lane":"vision","answer":None,"error":str(e),"verified":False}

# ---------------------------- tool registry ------------------------------
def tools() -> dict[str,dict[str,Any]]:
    return {
        "deep_reason": {"description":"Multi-pass reasoning with adversarial critique","safe":True},
        "advanced_math": {"description":"Frontier mathematical reasoning with independent verification","safe":True},
        "advanced_explanation": {"description":"Layered teaching and conceptual explanation","safe":True},
        "advanced_knowledge": {"description":"Broad general-knowledge reasoning with uncertainty handling","safe":True},
        "advanced_writing": {"description":"Sophisticated original writing and editing","safe":True},
        "advanced_ideas": {"description":"Divergent/convergent novel idea generation","safe":True},
        "advanced_unfamiliar": {"description":"General problem-solving for unseen problems","safe":True},
        "grounded_research": {"description":"Live research using existing web research engine","safe":True},
        "index_path": {"description":"Index local text/code into FRIDAY knowledge base","safe":True},
        "recall_knowledge": {"description":"Search indexed local knowledge","safe":True},
        "inspect_project": {"description":"Inventory a software project","safe":True},
        "run_static_checks": {"description":"Compile-check Python project files","safe":True},
        "coding_engineer": {"description":"Analyze and plan engineering changes","safe":True},
        "inspect_screen": {"description":"Analyze current screen using vision","safe":True},
    }

def dispatch(command: str, *, project: str | Path = ".") -> dict[str,Any]:
    r=route(command)
    _audit("dispatch", command=command[:500], route=asdict(r))
    if r.lane=="research": return grounded_research(command)
    if r.lane=="math": return advanced_math(command)
    if r.lane=="writing": return advanced_writing(command)
    if r.lane=="ideas": return advanced_ideas(command)
    if r.lane=="knowledge": return advanced_knowledge(command)
    if r.lane=="coding":
        if re.search(r"\b(fix|implement|modify|change|refactor|patch|repair|add)\b", command, re.I):
            return apply_coding_fix(command, project)
        return coding_engineer(command, project)
    if r.lane=="vision": return inspect_screen(command)
    if r.lane=="deep": return deep_reason(command)
    return {"lane":"fast","answer":None,"pass_through":True}

def self_improvement_report() -> dict[str,Any]:
    """Turn recent APEX audit events into concrete, testable improvement proposals.
    It proposes changes only; deployment remains a human-controlled action."""
    events=[]
    try:
        if AUDIT.exists():
            for line in AUDIT.read_text(encoding="utf-8",errors="ignore").splitlines()[-250:]:
                try: events.append(json.loads(line))
                except Exception: pass
    except Exception: pass
    failures=[e for e in events if "failed" in str(e.get("event","")) or "rolled_back" in str(e.get("event",""))]
    proposal=_json_model(
        "Review these recent FRIDAY APEX audit events and propose the highest-value "
        "engineering improvements. Do not claim a change was made. Prefer measurable "
        "tests, latency reductions, reliability fixes and capability gaps.\n"+
        json.dumps(failures[-80:],ensure_ascii=False)[:18000],
        '{"observations":[],"proposals":[{"title":"...","reason":"...","test":"...","risk":"..."}]}'
    ) or {"observations":[],"proposals":[]}
    return {"version":VERSION,"failure_events":len(failures),"proposal":proposal}

def health() -> dict[str,Any]:
    return {"version":VERSION,"db":str(DB),"tools":list(tools()),"model_configured":bool(os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY"))}
