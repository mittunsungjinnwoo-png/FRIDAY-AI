"""FRIDAY 6.0 integration layer (blueprint section 13): one registry for every outside service, each with its own permission scope,
authentication state, error handling and a plain record of what it can access.  Includes: weather and time services, maps links,
smart-home / IoT over HTTP (Home Assistant style), calendar import/export (.ics), version control (via the engineer module), local
language models (via the router) and a sandboxed plugin loader for future capabilities.

Secrets (tokens) are stored encrypted when the `cryptography` package is present and are never logged or spoken.
"""
from __future__ import annotations

import importlib.util
import json
import re
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import friday_common6 as C
import friday_security6 as SEC

C.register_schema("""
CREATE TABLE IF NOT EXISTS integ6(name TEXT PRIMARY KEY, kind TEXT, scopes TEXT, auth TEXT DEFAULT 'none', enabled INTEGER DEFAULT 1, last_ok REAL, last_error TEXT DEFAULT '', calls INTEGER DEFAULT 0, access TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS secrets6(name TEXT PRIMARY KEY, blob BLOB);
CREATE TABLE IF NOT EXISTS plugins6(name TEXT PRIMARY KEY, path TEXT, enabled INTEGER DEFAULT 0, sha TEXT, description TEXT, scopes TEXT);
""")

BUILTIN = [("weather", "service", "network:open-meteo", "Reads public weather for a place you name. Sends only the place name."),
           ("time", "service", "local", "Reads the system clock and time zones. No network."),
           ("maps", "service", "open-url", "Builds map and route links and opens them in your browser."),
           ("calendar_ics", "files", "read-write:calendar", "Imports and exports .ics calendar files for FRIDAY's local calendar."),
           ("git", "dev", "read:repo,write:repo(approval)", "Runs git in folders you point me at. Commits need your approval."),
           ("smart_home", "device", "network:local-hub", "Calls your smart-home hub (Home Assistant style) with a token you stored. Every action asks first."),
           ("iot_webhook", "device", "network:webhook", "Calls webhook URLs you register for devices or sensors. Every action asks first."),
           ("local_llm", "model", "network:localhost", "Talks to a local Ollama server on this PC."),
           ("web_search", "service", "network:search", "The existing FRIDAY research pipeline."),
           ("messaging", "service", "send:messages(approval)", "WhatsApp via FRIDAY's existing integration. Always shows the message first.")]


def _boot():
    for n, k, s, a in BUILTIN:
        C.x("INSERT OR IGNORE INTO integ6(name,kind,scopes,access) VALUES(?,?,?,?)", (n, k, s, a))


# ------------------------------------------------------------------ secrets
def secret_set(name: str, value: str):
    import friday_memory6 as M
    raw = value.encode("utf-8")
    blob = M.encrypt_bytes(raw) if M.encryption_available() else b"plain:" + raw
    C.x("INSERT INTO secrets6(name,blob) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET blob=excluded.blob", (name, blob))
    SEC.audit("user", "secret-stored", name)


def secret_get(name: str) -> Optional[str]:
    import friday_memory6 as M
    r = C.q("SELECT blob FROM secrets6 WHERE name=?", (name,))
    if not r:
        return None
    b = bytes(r[0]["blob"])
    return b[6:].decode("utf-8") if b.startswith(b"plain:") else M.decrypt_bytes(b).decode("utf-8")


def _record(name: str, ok: bool, err: str = ""):
    C.x("UPDATE integ6 SET calls=calls+1, last_ok=CASE WHEN ? THEN ? ELSE last_ok END, last_error=? WHERE name=?", (int(ok), C.now(), err[:160], name))


def _get(url: str, timeout: float = 8.0, headers: Optional[Dict] = None) -> Dict:
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "FRIDAY/6.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


# ------------------------------------------------------------------ services
def weather(place: str) -> Dict:
    try:
        g = _get("https://geocoding-api.open-meteo.com/v1/search?name=" + urllib.parse.quote(place) + "&count=1")
        if not g.get("results"):
            _record("weather", False, "unknown place")
            return {"ok": False, "error": f"I couldn't find a place called {place}"}
        p = g["results"][0]
        w = _get(f"https://api.open-meteo.com/v1/forecast?latitude={p['latitude']}&longitude={p['longitude']}&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=2")
        c, d = w["current"], w["daily"]
        codes = {0: "clear", 1: "mostly clear", 2: "partly cloudy", 3: "overcast", 45: "foggy", 48: "foggy", 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle", 61: "light rain", 63: "rain", 65: "heavy rain",
                 71: "light snow", 73: "snow", 75: "heavy snow", 80: "rain showers", 81: "rain showers", 82: "violent showers", 95: "thunderstorms", 96: "thunderstorms with hail", 99: "thunderstorms with hail"}
        _record("weather", True)
        return {"ok": True, "place": p["name"], "now": f"{c['temperature_2m']:.0f}°C (feels {c['apparent_temperature']:.0f}°C), {codes.get(c['weather_code'], 'unsettled')}, wind {c['wind_speed_10m']:.0f} km/h",
                "today": f"high {d['temperature_2m_max'][0]:.0f}, low {d['temperature_2m_min'][0]:.0f}, rain chance {d['precipitation_probability_max'][0]} percent"}
    except Exception as exc:
        _record("weather", False, str(exc))
        return {"ok": False, "error": "I couldn't reach the weather service (check your internet connection)"}


def time_in(place: str) -> Dict:
    from zoneinfo import ZoneInfo, available_timezones
    key = re.sub(r"\s+", "_", place.strip().lower())
    zones = {z.lower(): z for z in available_timezones()}
    alias = {"london": "Europe/London", "new york": "America/New_York", "tokyo": "Asia/Tokyo", "colombo": "Asia/Colombo", "sri lanka": "Asia/Colombo", "dubai": "Asia/Dubai", "delhi": "Asia/Kolkata",
             "india": "Asia/Kolkata", "paris": "Europe/Paris", "sydney": "Australia/Sydney", "los angeles": "America/Los_Angeles", "singapore": "Asia/Singapore", "cambridge": "Europe/London",
             "berlin": "Europe/Berlin", "beijing": "Asia/Shanghai", "toronto": "America/Toronto", "san francisco": "America/Los_Angeles", "utc": "UTC"}
    z = alias.get(place.strip().lower()) or next((v for k, v in zones.items() if k.endswith("/" + key)), None)
    if not z:
        return {"ok": False, "error": f"I don't know the time zone for {place}"}
    now = datetime.now(ZoneInfo(z))
    return {"ok": True, "zone": z, "time": now.strftime("%I:%M %p").lstrip("0"), "date": now.strftime("%A %d %B")}


def maps_link(origin: str, dest: str = "") -> str:
    q = urllib.parse.quote
    return (f"https://www.google.com/maps/dir/?api=1&origin={q(origin)}&destination={q(dest)}" if dest else f"https://www.google.com/maps/search/?api=1&query={q(origin)}")


# ------------------------------------------------------------------ ICS calendar
def export_ics(path: Optional[str] = None) -> str:
    import friday_productivity6 as P
    f = lambda ts: datetime.utcfromtimestamp(ts).strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//FRIDAY 6.0//EN"]
    for e in P.events(C.now() - 30 * 86400, C.now() + 365 * 86400):
        lines += ["BEGIN:VEVENT", f"UID:friday-{e['id']}@local", f"DTSTAMP:{f(e['ts'])}", f"DTSTART:{f(e['start'])}", f"DTEND:{f(e['end'])}", f"SUMMARY:{e['title']}", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    p = Path(path) if path else C.DATA_DIR / "outputs" / "friday_calendar.ics"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("\r\n".join(lines), "utf-8")
    return str(p)


def import_ics(path: str) -> int:
    import friday_productivity6 as P
    txt = Path(path).read_text("utf-8", "ignore")
    n = 0
    for blk in re.findall(r"BEGIN:VEVENT(.*?)END:VEVENT", txt, re.S):
        s = re.search(r"SUMMARY:(.+)", blk); a = re.search(r"DTSTART[^:]*:(\d{8}T\d{6})Z?", blk); b = re.search(r"DTEND[^:]*:(\d{8}T\d{6})Z?", blk)
        if s and a:
            st = datetime.strptime(a.group(1), "%Y%m%dT%H%M%S").timestamp()
            en = datetime.strptime(b.group(1), "%Y%m%dT%H%M%S").timestamp() if b else st + 3600
            P.add_event(s.group(1).strip(), st, int((en - st) / 60))
            n += 1
    return n


# ------------------------------------------------------------------ smart home / IoT (permission + approval)
def smart_home_call(domain: str, service: str, entity: str) -> Dict:
    blocked = SEC.require("smart_home", f"{domain}.{service} {entity}")
    if blocked:
        return {"ok": False, "error": blocked}
    url, tok = secret_get("home_url"), secret_get("home_token")
    if not url or not tok:
        return {"ok": False, "error": "no smart-home hub is set up. Say 'set up smart home' with the hub URL and token"}
    try:
        req = urllib.request.Request(url.rstrip("/") + f"/api/services/{domain}/{service}", data=json.dumps({"entity_id": entity}).encode(), headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=8).read()
        SEC.audit("friday", "smart-home", f"{domain}.{service} {entity}")
        _record("smart_home", True)
        return {"ok": True}
    except Exception as exc:
        _record("smart_home", False, str(exc))
        return {"ok": False, "error": f"the hub didn't accept it ({type(exc).__name__})"}


def webhook_call(name: str) -> Dict:
    blocked = SEC.require("smart_home", f"webhook {name}")
    if blocked:
        return {"ok": False, "error": blocked}
    url = secret_get("hook_" + name.lower())
    if not url:
        return {"ok": False, "error": f"no webhook named {name}"}
    try:
        urllib.request.urlopen(urllib.request.Request(url, data=b"{}", headers={"Content-Type": "application/json"}), timeout=8).read()
        SEC.audit("friday", "webhook", name); _record("iot_webhook", True)
        return {"ok": True}
    except Exception as exc:
        _record("iot_webhook", False, str(exc))
        return {"ok": False, "error": f"the device didn't respond ({type(exc).__name__})"}


# ------------------------------------------------------------------ plugins (disabled until you enable them)
PLUGIN_DIR = C.DATA_DIR.parent / "friday_plugins"
_loaded: Dict[str, object] = {}


def scan_plugins() -> List[Dict]:
    out = []
    if not PLUGIN_DIR.exists():
        return out
    for f in sorted(PLUGIN_DIR.glob("*.py")):
        src = f.read_text("utf-8", "ignore")
        sha = C.fingerprint(src)
        meta = re.search(r"PLUGIN\s*=\s*\{.*?\}", src, re.S)
        risks = [m for m in ("subprocess", "os.system", "eval(", "exec(", "socket", "requests", "urllib", "shutil.rmtree", "ctypes") if m in src]
        name = f.stem
        C.x("INSERT INTO plugins6(name,path,sha,description,scopes) VALUES(?,?,?,?,?) ON CONFLICT(name) DO UPDATE SET path=excluded.path, description=excluded.description",
            (name, str(f), sha, C.clip(meta.group(0) if meta else "", 150), ",".join(risks)))
        row = C.q("SELECT enabled, sha FROM plugins6 WHERE name=?", (name,))[0]
        out.append({"name": name, "enabled": bool(row["enabled"]) and row["sha"] == sha, "risky_calls": risks, "changed_since_enabled": row["sha"] != sha and bool(row["enabled"])})
    return out


def enable_plugin(name: str) -> str:
    f = PLUGIN_DIR / (name + ".py")
    if not f.exists():
        return f"There's no plugin called {name}."
    src = f.read_text("utf-8", "ignore")
    inj = SEC.scan_untrusted(src, "plugin")
    try:
        compile(src, str(f), "exec")
    except SyntaxError as exc:
        return f"That plugin has a syntax error on line {exc.lineno}, so I won't load it."
    C.x("UPDATE plugins6 SET enabled=1, sha=? WHERE name=?", (C.fingerprint(src), name))
    SEC.audit("user", "plugin-enabled", name)
    return f"Plugin {name} enabled." + (" It uses: " + ", ".join(c for c in C.q("SELECT scopes FROM plugins6 WHERE name=?", (name,))[0]["scopes"].split(",") if c) + "." if C.q("SELECT scopes FROM plugins6 WHERE name=?", (name,))[0]["scopes"] else "")


def _plugin_module(name: str):
    if name in _loaded:
        return _loaded[name]
    f = PLUGIN_DIR / (name + ".py")
    spec = importlib.util.spec_from_file_location("friday_plugin_" + name, f)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    _loaded[name] = mod
    return mod


def plugin_handle(command: str) -> Optional[str]:
    for r in C.q("SELECT name,sha FROM plugins6 WHERE enabled=1"):
        f = PLUGIN_DIR / (r["name"] + ".py")
        if not f.exists() or C.fingerprint(f.read_text("utf-8", "ignore")) != r["sha"]:
            continue              # file changed after you enabled it: it stays off until you enable it again
        try:
            res = _plugin_module(r["name"]).handle(command)
            if res:
                SEC.audit("plugin:" + r["name"], "handled", command[:60])
                return str(res)
        except Exception as exc:
            SEC.audit("plugin:" + r["name"], "error", str(exc)[:100], "error")
    return None


def registry() -> List[Dict]:
    _boot()
    rows = [dict(r) for r in C.q("SELECT name,kind,scopes,auth,enabled,last_ok,last_error,calls,access FROM integ6")]
    for r in rows:
        r["last_ok"] = C.iso(r["last_ok"]) if r["last_ok"] else ""
    return rows


_pending: Dict = {}


def handle(command: str) -> Optional[str]:
    _boot()
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    m = re.match(r"^(?:what(?:'s| is) the )?weather(?: like)?(?: today| now)?(?: in| for| at)?\s*(.*)$|^(?:how(?:'s| is) the weather|is it (?:raining|sunny|hot|cold))(?: in (.+))?$", low)
    if False and m and re.search(r"weather|raining|sunny|hot|cold", low):      # the original FRIDAY weather handler (and header widget) keeps this one
        place = (m.group(1) or m.group(2) or "Colombo").strip() or "Colombo"
        r = weather(place)
        return f"In {r['place']} it's {r['now']}. Today: {r['today']}." if r["ok"] else r["error"].rstrip(".") + "."
    m = re.match(r"^what(?:'s| is) the time in ([\w ]+)$|^what time is it in ([\w ]+)$", low)
    if m:
        r = time_in(m.group(1) or m.group(2))
        return f"It's {r['time']} on {r['date']} in {m.group(1) or m.group(2)}." if r["ok"] else r["error"].rstrip(".") + "."
    m = re.match(r"^(?:directions|route|navigate|how do i get) (?:from (.+?) )?to (.+)$", low)
    if m:
        link = maps_link(m.group(1) or "My Location", m.group(2))
        try:
            import webbrowser; webbrowser.open(link)
        except Exception:
            pass
        return f"Opening directions to {m.group(2)} in your browser."
    if re.match(r"^export (?:my )?calendar$", low):
        return f"Calendar exported to {export_ics()}."
    m = re.match(r"^import (?:the )?calendar (?:from )?(.+\.ics)$", t, re.I)
    if m:
        return f"Imported {import_ics(m.group(1).strip(chr(34) + ' '))} events."
    m = re.match(r"^set up smart home (?:hub )?(https?://\S+) (?:token|key) (\S+)$", t, re.I)
    if m:
        secret_set("home_url", m.group(1)); secret_set("home_token", m.group(2))
        return "Smart-home hub saved securely. It stays blocked until you say 'allow smart home'."
    m = re.match(r"^register (?:a )?(?:device )?webhook (\w+) (https?://\S+)$", t, re.I)
    if m:
        secret_set("hook_" + m.group(1).lower(), m.group(2))
        return f"Webhook {m.group(1)} saved. Triggering it needs the smart-home permission and your confirmation."
    m = re.match(r"^(?:turn |switch )(on|off) (?:the )?([\w ]+)$", low)
    if m and secret_get("home_url"):
        ent = "light." + m.group(2).replace(" ", "_")
        _pending["act"] = ("light", "turn_" + m.group(1), ent)
        return f"I'll turn {m.group(1)} {m.group(2)} through your smart-home hub. Say 'confirm' to proceed."
    if low in ("confirm", "yes confirm", "confirm it") and "act" in _pending:
        r = smart_home_call(*_pending.pop("act"))
        return "Done." if r["ok"] else r["error"].rstrip(".") + "."
    m = re.match(r"^(?:trigger|run|fire) (?:the )?webhook (\w+)$", low)
    if m:
        r = webhook_call(m.group(1))
        return "Triggered." if r["ok"] else r["error"].rstrip(".") + "."
    if re.match(r"^(?:list|show|what) (?:my )?(?:integrations|connections|connected services)$|^what can you access$", low):
        return "Integrations: " + "; ".join(f"{r['name'].replace('_', ' ')} ({'ok' if not r['last_error'] else 'last error'})" for r in registry()[:10]) + ". Each has its own permission scope; ask 'what can <name> access'."
    m = re.match(r"^what can (?:the )?([\w ]+?) access$", low)
    if m:
        k = m.group(1).replace(" ", "_")
        r = next((x for x in registry() if x["name"] == k), None)
        return f"{r['name'].replace('_', ' ').title()}: {r['access']} Scope: {r['scopes']}." if r else "I don't have an integration by that name."
    if re.match(r"^(?:list|show) (?:my )?plugins$", low):
        p = scan_plugins()
        return "No plugins found. Drop .py files into the friday_plugins folder." if not p else "Plugins: " + "; ".join(f"{x['name']} ({'on' if x['enabled'] else 'off'}" + (f", uses {', '.join(x['risky_calls'])}" if x["risky_calls"] else "") + ")" for x in p) + "."
    m = re.match(r"^(?:enable|turn on|allow) plugin (\w+)$", low)
    if m:
        return enable_plugin(m.group(1))
    m = re.match(r"^(?:disable|turn off) plugin (\w+)$", low)
    if m:
        C.x("UPDATE plugins6 SET enabled=0 WHERE name=?", (m.group(1),))
        return f"Plugin {m.group(1)} disabled."
    return plugin_handle(command)
