"""
FRIDAY CONTEXT ENGINE
======================
Implements the two upgrades described in the "Intent-Driven
Interaction" and "Natural Language & Proactive Context" notes, built
INTO the existing intent system rather than as a separate feature
(exactly as the notes recommend):

  1. PROACTIVE CONTEXT / REFERENCE RESOLUTION
     Lets Friday understand follow-ups like "make it into slides" or
     "compare the prices" by tracking what the last research/creation
     turn was actually about, and rewriting a vague follow-up into a
     concrete one BEFORE it reaches intent classification --
         "make it into slides"
             -> "make a presentation about Singapore Airlines fares"
     -- so every existing handler downstream (web research, creation
     engine, the Gemini intent classifier) keeps working exactly as
     it already does, just fed a clearer sentence. Also lets the
     Creation Engine skip re-researching a topic it already just
     gathered sources for, which is both faster (no repeat web
     fetching) and more accurate (builds from the same verified
     sources instead of a second, possibly different, scrape).

  2. FLUID LONG-TERM MEMORY
     friday_brain.py's existing `memory` list/memory.json is left
     exactly as it was: a rolling window of raw conversation turns
     used as short-term context for ask_ai(). This module adds a
     SEPARATE, much smaller store -- knowledge_memory.json -- of
     distilled facts worth keeping across sessions (preferences,
     project details, standing facts, open tasks), classified and
     deduplicated instead of just accumulating every sentence ever
     said. ask_ai() asks this module for the handful of facts
     relevant to the current question and folds just those into the
     prompt, rather than memory.json growing forever with no way to
     tell what in it still matters.

Every public function here is wrapped so a failure (offline, bad
Gemini key, corrupt JSON, first run with no file yet) degrades to
"no context available" rather than raising -- nothing in here is
allowed to block a command the way it would if this were load-bearing
like the WhatsApp confirmation flow.
"""

import json
import re
import time
import datetime
from pathlib import Path
import os
DATA_DIR = Path(os.environ.get("FRIDAY_DATA") or (Path(__file__).parent / "friday_data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

CONTEXT_STATE_FILE = DATA_DIR / "context_state.json"
KNOWLEDGE_MEMORY_FILE = DATA_DIR / "knowledge_memory.json"

# How many raw sources (url, text) from the last research/creation
# turn get kept in memory for instant reuse by a follow-up like "make
# it into slides". Trimmed hard on storage (see remember_research) so
# this never turns context_state.json into another giant file.
_MAX_REUSABLE_SOURCES = 6
_MAX_REUSABLE_CHARS = 3000

# A "proactive context" turn is only reused within this window -- if
# the user researched something twenty minutes ago and now says
# "make it into slides", it's far more likely "it" means something
# from the CURRENT conversation than something from long ago. Keeps
# Friday from confidently reusing a stale topic.
_CONTEXT_TTL_SECONDS = 20 * 60

# Long-term knowledge memory is capped so it stays a curated set of
# facts, not an ever-growing log -- exactly the "giant memory.json"
# problem the fluid-memory notes call out. When full, the oldest,
# least-recently-retrieved entries are dropped first (see _prune()).
_MAX_KNOWLEDGE_ENTRIES = 400

_KNOWLEDGE_CATEGORIES = ("preference", "project", "fact", "task", "conversation")


# ============================================================
# STATE LOADING / SAVING
# ============================================================

_DEFAULT_STATE = {
    "last_topic": None,          # plain-text subject of the last research/creation turn
    "last_research": None,       # {"query", "answer", "sources": [url,...], "raw": [[url,text],...], "timestamp"}
    "last_creation": None,       # {"topic", "files": [...], "folder", "timestamp"}
    "last_intent": None,
    "updated_at": None,
}


def _load_json(path, default):
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as error:
        print(f"Context file read error ({path}), starting fresh:", error)
    return default


def _save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as error:
        print(f"Context file write error ({path}) (ignored):", error)


_state = _load_json(CONTEXT_STATE_FILE, dict(_DEFAULT_STATE))
_knowledge = _load_json(KNOWLEDGE_MEMORY_FILE, [])


def _touch():
    _state["updated_at"] = time.time()
    _save_json(CONTEXT_STATE_FILE, _state)


def _fresh_enough(entry):
    if not entry:
        return False
    ts = entry.get("timestamp")
    if not ts:
        return False
    return (time.time() - ts) <= _CONTEXT_TTL_SECONDS


# ============================================================
# 1. PROACTIVE CONTEXT / REFERENCE RESOLUTION
# ============================================================

# Deliberately short, unambiguous reference words/phrases only --
# this must never rewrite an ordinary, already-complete sentence.
# Checked with word boundaries (for single words like "it"/"that") or
# as plain substrings (for multi-word phrases like "the results"),
# and ONLY when the command doesn't already contain enough of its own
# subject matter (see resolve() below).
_REFERENCE_PATTERNS = [
    re.compile(r"\bit\b", re.I),
    re.compile(r"\bthat\b", re.I),
    re.compile(r"\bthis\b", re.I),
    re.compile(r"\bthose\b", re.I),
    re.compile(r"\bthese\b", re.I),
]
_REFERENCE_PHRASES = (
    "the results", "the result", "the prices", "the price",
    "the research", "the numbers", "the data", "that topic", "the same topic",
)

# Follow-up action words that, combined with a reference above, are
# the clearest signal of "continue what we were just doing" rather
# than a brand-new, self-contained request.
_FOLLOWUP_CREATE_HINTS = ("make", "turn", "build", "create", "put together", "prepare", "draft", "generate")
_FOLLOWUP_RESEARCH_HINTS = ("compare", "check", "look up", "double check", "verify", "confirm", "update")


def _contains_reference(command_lower):
    if any(p.search(command_lower) for p in _REFERENCE_PATTERNS):
        return True
    return any(phrase in command_lower for phrase in _REFERENCE_PHRASES)


def resolve(original_command):
    """
    Looks at the CURRENT command against whatever Friday was just
    doing and returns a dict describing how to handle it:

        {
          "command": str,          # command text to actually act on
                                    # (rewritten if a reference was
                                    # resolved, otherwise unchanged)
          "rewritten": bool,       # True if "command" differs from
                                    # the input
          "reuse_research": bool,  # True if cached sources from
                                    # last_research should be reused
                                    # instead of searching again
          "reuse_sources": list,   # the [(url, text), ...] to reuse,
                                    # only set when reuse_research
          "topic": str or None,    # the resolved subject, for the
                                    # persona "reuse" acknowledgement
        }

    Never raises. On anything uncertain (no recent context, command
    already looks self-contained, TTL expired) this returns the
    ORIGINAL command completely unchanged with reuse_research=False,
    which is exactly today's behavior -- so this can only ever ADD
    capability, never change how an already-working command resolves.
    """
    fallback = {
        "command": original_command,
        "rewritten": False,
        "reuse_research": False,
        "reuse_sources": [],
        "topic": None,
    }
    try:
        command_lower = (original_command or "").lower().strip()
        if not command_lower:
            return fallback

        last_research = _state.get("last_research")
        last_creation = _state.get("last_creation")
        topic = _state.get("last_topic")

        has_reference = _contains_reference(command_lower)
        has_followup_hint = any(w in command_lower for w in _FOLLOWUP_CREATE_HINTS + _FOLLOWUP_RESEARCH_HINTS)

        # Only act when BOTH a reference word/phrase AND a plausible
        # follow-up verb are present -- e.g. "make it into slides" or
        # "compare the prices" qualify; a bare "that's interesting"
        # does not, so ordinary conversation is never rewritten.
        if not (has_reference and has_followup_hint and topic):
            return fallback

        research_fresh = _fresh_enough(last_research)
        creation_source_topic = topic

        # "make it into slides" / "turn that into a presentation" /
        # "create a pdf from that" -- reuse last_research's sources
        # directly rather than re-searching, if they're still fresh.
        wants_new_creation = any(w in command_lower for w in _FOLLOWUP_CREATE_HINTS) and any(
            n in command_lower for n in (
                "slide", "presentation", "deck", "pptx", "document", "docx",
                "pdf", "spreadsheet", "excel", "xlsx", "report", "file", "project",
            )
        )
        if wants_new_creation and research_fresh:
            rewritten = f"create a presentation about {creation_source_topic}"
            # Respect whatever file type the user actually asked for,
            # instead of always defaulting to a presentation.
            for noun in ("pdf", "spreadsheet", "excel sheet", "xlsx", "word document", "docx", "document", "report"):
                if noun in command_lower:
                    rewritten = f"create a {noun} about {creation_source_topic}"
                    break
            return {
                "command": rewritten,
                "rewritten": True,
                "reuse_research": True,
                "reuse_sources": list(last_research.get("raw", [])),
                "topic": creation_source_topic,
            }

        # "compare the prices" / "check that again" / "what about the
        # cheapest option" (no new subject named) -- treat as a
        # continuation of the last research topic.
        wants_followup_research = any(w in command_lower for w in _FOLLOWUP_RESEARCH_HINTS) or has_reference
        if wants_followup_research and topic:
            rewritten = f"{original_command.strip()} regarding {topic}"
            return {
                "command": rewritten,
                "rewritten": True,
                "reuse_research": False,
                "reuse_sources": [],
                "topic": topic,
            }

        return fallback
    except Exception as error:
        print("Context resolution skipped (falling back to original command):", error)
        return fallback


def remember_research(query, result):
    """Called after a successful web-research turn so the NEXT turn
    can reference it. `result` is the dict returned by
    friday_web_research.run_web_research(); only a trimmed slice of
    each source's text is kept (see _MAX_REUSABLE_CHARS) so this
    file stays small even after a long session."""
    try:
        raw = result.get("_raw_sources") or []
        trimmed = [
            [url, text[:_MAX_REUSABLE_CHARS]]
            for url, text in raw[:_MAX_REUSABLE_SOURCES]
        ]
        _state["last_topic"] = query.strip()
        _state["last_intent"] = "live_information_request"
        _state["last_research"] = {
            "query": query.strip(),
            "answer": result.get("answer", ""),
            "sources": result.get("sources", []),
            "raw": trimmed,
            "timestamp": time.time(),
        }
        _touch()
    except Exception as error:
        print("Context: could not store research result (ignored):", error)


def remember_creation(topic, files, folder):
    """Called after a successful Creation Engine run."""
    try:
        _state["last_topic"] = topic.strip()
        _state["last_intent"] = "create_presentation"
        _state["last_creation"] = {
            "topic": topic.strip(),
            "files": [str(f) for f in files],
            "folder": str(folder),
            "timestamp": time.time(),
        }
        _touch()
    except Exception as error:
        print("Context: could not store creation result (ignored):", error)


def current_topic_hint():
    """One short line describing what Friday was just doing, if
    anything, for injection into the Gemini intent-classification
    prompt -- helps it correctly route a genuinely ambiguous
    follow-up ('and the cheapest one?') even in the rare case
    resolve() above didn't already rewrite it. Returns "" when there
    is no fresh context, so the prompt is unaffected by default."""
    try:
        last_research = _state.get("last_research")
        last_creation = _state.get("last_creation")
        if _fresh_enough(last_research):
            return f"(Context: the user was just researching '{last_research.get('query')}'.)"
        if _fresh_enough(last_creation):
            return f"(Context: the user just created files about '{last_creation.get('topic')}'.)"
        return ""
    except Exception:
        return ""


# ============================================================
# 2. FLUID LONG-TERM MEMORY
# ============================================================

# Cheap, local pre-filter run BEFORE ever spending a Gemini call on
# extraction -- most turns ("what time is it", small talk) contain
# nothing worth remembering long-term, so this skips the vast
# majority of turns for free. Only turns that pass this heuristic (or
# an explicit "remember ..." command) go on to the real
# classification call below.
_MEMORY_WORTHY_HINTS = (
    "remember", "my name is", "i live", "i work", "i use", "i prefer",
    "i like", "i don't like", "i dont like", "call me", "my project",
    "my job", "i'm working on", "im working on", "always", "from now on",
    "note that", "keep in mind", "for future reference", "don't forget",
    "dont forget", "my favorite", "my favourite", "i own", "i have a",
)

# A pure question almost never itself states a fact ABOUT the user --
# skip these before spending an AI call on them. Statements, even
# ones with no hint phrase above, still go on to be judged for real
# by maybe_extract_and_store's own Gemini call below.
_QUESTION_STARTS = (
    "what", "when", "where", "who", "why", "how", "is ", "are ", "can ",
    "could ", "do ", "does ", "did ", "will ", "would ", "should ",
)


def _looks_memory_worthy(question):
    """
    V2049 FIX: this used to ALSO require one of a small set of exact
    hint phrases ("my name is", "i prefer", ...) before a statement
    was even allowed to reach the real AI classifier in
    maybe_extract_and_store(). That meant a huge amount of clearly
    memorable stuff a person actually says -- "I'm sitting my A
    Levels in June", "my exam board is Cambridge", "I moved to a new
    flat last week", "I got a new laptop" -- never had a chance to be
    remembered at all, no matter how obviously worth keeping it was,
    simply because it didn't contain one of those exact phrases. The
    Gemini call in maybe_extract_and_store already IS the real
    "is this actually worth remembering" judge; this function's only
    job now is a cheap, local pre-filter to skip the AI call on
    things that obviously can't be a fact about the user (bare
    commands, short replies, plain questions) -- not to second-guess
    what counts as memorable.
    """
    lowered = (question or "").strip().lower()
    words = lowered.split()
    if len(words) < 4:
        return False
    if lowered.endswith("?"):
        return False
    if any(lowered.startswith(w) for w in _QUESTION_STARTS):
        return False
    return True


def maybe_extract_and_store(question, answer):
    """
    Fluid-memory extraction: decides whether THIS turn contains a
    fact worth keeping across sessions and, if so, classifies +
    stores a short, distilled version of it -- rather than the raw
    conversation piling up forever. Guarded at every step; any
    failure here is silently skipped so it can never interrupt a
    normal reply that already reached the user via speak().
    """
    try:
        if not _looks_memory_worthy(question):
            return
        import friday_brain  # lazy import -- avoids a circular import at module load

        friday_brain._ensure_gemini_client()
        if friday_brain.client is None:
            return

        prompt = (
            "A user said the following to their personal assistant Friday. "
            "Decide if it contains a durable fact worth remembering across "
            "future sessions (a stated preference, a fact about their "
            "life/work, a detail about an ongoing project, or a standing "
            "task/instruction) -- NOT a one-off conversational remark, a "
            "question, or small talk.\n\n"
            f"User said: {question}\n\n"
            "Reply with ONLY valid JSON, no markdown fences, no commentary, "
            "in exactly this shape:\n"
            '{"worth_remembering": true or false, '
            '"category": "preference" or "project" or "fact" or "task", '
            '"content": "one short, self-contained sentence stating the fact, '
            'written in third person about the user"}\n'
            'If worth_remembering is false, "category" and "content" can be empty strings.'
        )
        response = friday_brain.client.models.generate_content(
            model=friday_brain.GEMINI_MODEL, contents=prompt
        )
        raw = (getattr(response, "text", None) or "").strip()
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.I)
        parsed = json.loads(raw)

        if not parsed.get("worth_remembering"):
            return
        content = (parsed.get("content") or "").strip()
        category = (parsed.get("category") or "fact").strip().lower()
        if category not in _KNOWLEDGE_CATEGORIES:
            category = "fact"
        if not content:
            return

        _store_knowledge(content, category)
    except Exception as error:
        print("Fluid-memory extraction skipped (ignored):", error)


def _store_knowledge(content, category):
    """Adds a distilled fact, skipping near-duplicates of something
    already stored (checked semantically when embeddings are
    available, and always checked with a cheap text-similarity
    fallback so dedup still works with no Gemini access at all)."""
    try:
        import difflib

        for entry in _knowledge:
            ratio = difflib.SequenceMatcher(None, entry.get("content", "").lower(), content.lower()).ratio()
            if ratio >= 0.85:
                entry["last_used_at"] = time.time()
                _save_json(KNOWLEDGE_MEMORY_FILE, _knowledge)
                return  # already have this fact, just refresh its recency

        # V2049 FIX: embed the fact ONCE, right now, and persist the
        # vector alongside it. Previously retrieve_relevant() had to
        # re-embed EVERY stored fact on EVERY single question (the
        # in-memory _EMBEDDING_CACHE it relied on is wiped on every
        # restart), which meant a growing knowledge base got slower
        # and slower and, past a certain size, could make Friday
        # appear to "not remember" simply because the lookup was
        # timing out or taking too long before it ever got to
        # compare anything. Computing it here means retrieval only
        # ever needs to embed the new QUESTION, not the whole store.
        embedding = None
        try:
            import friday_brain
            embedding = friday_brain._get_embedding(content)
        except Exception:
            embedding = None

        _knowledge.append({
            "content": content,
            "category": category,
            "created_at": time.time(),
            "last_used_at": time.time(),
            "embedding": embedding,
        })
        _prune()
        _save_json(KNOWLEDGE_MEMORY_FILE, _knowledge)
    except Exception as error:
        print("Fluid-memory store error (ignored):", error)


def _prune():
    """Keeps knowledge_memory.json a curated set of facts instead of
    an ever-growing file: once over the cap, the least-recently-used
    entries are dropped first."""
    if len(_knowledge) <= _MAX_KNOWLEDGE_ENTRIES:
        return
    _knowledge.sort(key=lambda e: e.get("last_used_at", 0), reverse=True)
    del _knowledge[_MAX_KNOWLEDGE_ENTRIES:]


def retrieve_relevant(query, top_k=8):
    """
    Returns up to `top_k` stored facts relevant to `query`, newest
    matches and semantic closeness both weighed, for ask_ai() to fold
    into its prompt. Tries embedding similarity first (reusing
    friday_brain's own embedding helper -- see the module docstring
    there on the tiered "neural processing" approach this project
    already uses elsewhere); falls back to plain keyword overlap if
    embeddings are unavailable, so this still works offline.
    """
    if not _knowledge:
        return []
    try:
        import friday_brain

        query_vector = friday_brain._get_embedding(query)
        if query_vector:
            scored = []
            dirty = False
            # V2049 FIX: reuse each fact's own persisted embedding
            # (computed once, at _store_knowledge() time) instead of
            # re-embedding all ~400 possible facts on every single
            # question -- see the comment in _store_knowledge for why
            # that was both slow and a real cause of "forgetting"
            # (a lookup that's timing out finds nothing). Entries
            # saved before this fix won't have one yet; backfill
            # those lazily, once, instead of leaving them permanently
            # unsearchable by meaning.
            for entry in _knowledge:
                vector = entry.get("embedding")
                if vector is None:
                    vector = friday_brain._get_embedding(entry["content"])
                    if vector is not None:
                        entry["embedding"] = vector
                        dirty = True
                if vector is None:
                    continue
                score = friday_brain._cosine_similarity(query_vector, vector)
                scored.append((score, entry))
            if dirty:
                _save_json(KNOWLEDGE_MEMORY_FILE, _knowledge)
            scored.sort(key=lambda pair: pair[0], reverse=True)
            # V2049: threshold loosened slightly (0.55 -> 0.45) and
            # top_k raised (see the default below) -- 0.55 was tuned
            # tight enough that plausible paraphrases of a stored fact
            # ("what school am I sitting my exams at" vs a stored fact
            # phrased "studies at ...") often scored just under it and
            # were silently dropped, which is exactly what "doesn't
            # remember well" looks like from the outside.
            top = [entry for score, entry in scored[:top_k] if score >= 0.45]
            if top:
                for entry in top:
                    entry["last_used_at"] = time.time()
                _save_json(KNOWLEDGE_MEMORY_FILE, _knowledge)
                return [entry["content"] for entry in top]
    except Exception as error:
        print("Semantic memory retrieval skipped, using keyword fallback:", error)

    # Keyword-overlap fallback -- no network/API dependency at all.
    query_words = set(re.findall(r"[a-z0-9]+", query.lower()))
    if not query_words:
        return []
    scored = []
    for entry in _knowledge:
        entry_words = set(re.findall(r"[a-z0-9]+", entry["content"].lower()))
        overlap = len(query_words & entry_words)
        if overlap:
            scored.append((overlap, entry))
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [entry["content"] for _, entry in scored[:top_k]]


def all_known_facts():
    """Returns every stored long-term fact (newest first), for a direct
    "what do you remember about me" style request -- rather than only
    ever surfacing the handful retrieve_relevant() judges relevant to
    whatever the current question happens to be."""
    try:
        entries = [e for e in _knowledge if e.get("content")]
        entries.sort(key=lambda e: e.get("created_at", 0), reverse=True)
        return [{"content": e["content"], "category": e.get("category", "fact")} for e in entries]
    except Exception:
        return []


def trim_conversation(memory_list, max_len=200):
    """
    Caps friday_brain's raw conversation log (memory.json) at
    `max_len` most-recent turns. This is the "don't end up with a
    giant memory.json containing thousands of useless sentences"
    fix from the fluid-memory notes -- applied WITHOUT touching how
    that file is structured or loaded, so every existing reader of
    `memory` keeps working exactly as before, it just no longer grows
    without bound. Distilled long-term facts already live separately
    in knowledge_memory.json (see maybe_extract_and_store above), so
    trimming the raw log here never actually loses anything durable.
    """
    if len(memory_list) <= max_len:
        return memory_list
    return memory_list[-max_len:]


# ============================================================
# 3. PERSISTENT CONVERSATION CONTEXT (ADDITIVE)
# ============================================================
# This layer is intentionally separate from memory.json and the
# curated knowledge_memory.json. It remembers the user's recent
# conversational thread across restarts, without changing the
# existing memory format or replacing any existing feature.
#
# Goal: natural follow-ups such as:
#   "research quantum computers" -> "research that topic again"
#   "tell me about NVIDIA"       -> "what about its competitors?"
#   "compare these"              -> "make a report on them"
#
# It is deliberately bounded and local. No database is required.

CONVERSATION_CONTEXT_FILE = DATA_DIR / "conversation_context.json"
_MAX_CONTEXT_TURNS = 120
_CONTEXT_TOPIC_TTL_SECONDS = 7 * 24 * 60 * 60
_REFERENCE_ACTIONS = (
    "research", "look up", "check", "compare", "verify", "confirm",
    "continue", "expand", "explain", "elaborate", "summarize",
    "summarise", "analyze", "analyse", "find more", "tell me more",
    "go deeper", "deep research", "make", "create", "build", "write",
)
_REFERENCE_WORDS = (
    "it", "that", "this", "those", "these", "them", "they", "he", "she",
)
_REFERENCE_PHRASES_2 = (
    "that topic", "this topic", "the topic", "that subject", "this subject",
    "the same topic", "the same subject", "that research", "this research",
    "the research", "those results", "the results", "that information",
    "this information", "the data", "those companies", "those products",
)

_DEFAULT_CONVERSATION_CONTEXT = {
    "turns": [],
    "active_topic": None,
    "active_entities": [],
    "active_task": None,
    "updated_at": None,
}


def _load_conversation_context():
    data = _load_json(CONVERSATION_CONTEXT_FILE, dict(_DEFAULT_CONVERSATION_CONTEXT))
    if not isinstance(data, dict):
        return dict(_DEFAULT_CONVERSATION_CONTEXT)
    data.setdefault("turns", [])
    data.setdefault("active_topic", None)
    data.setdefault("active_entities", [])
    data.setdefault("active_task", None)
    data.setdefault("updated_at", None)
    return data


_conversation_context = _load_conversation_context()


def _save_conversation_context():
    try:
        # Keep the file bounded even after months of use.
        _conversation_context["turns"] = _conversation_context.get("turns", [])[-_MAX_CONTEXT_TURNS:]
        _conversation_context["updated_at"] = time.time()
        _save_json(CONVERSATION_CONTEXT_FILE, _conversation_context)
    except Exception as error:
        print("Persistent conversation context save skipped (ignored):", error)


def _clean_topic(text):
    text = re.sub(r"\s+", " ", (text or "").strip(" .?!"))
    if not text:
        return None
    # Remove conversational wrappers while retaining the user's actual subject.
    patterns = (
        r"^(?:please\s+)?(?:research|look up|check|verify|confirm)\s+(?:on|about|into)?\s*",
        r"^(?:can you|could you|would you|please)\s+",
        r"^(?:tell me|explain|teach me)\s+(?:about|on)?\s*",
        r"^(?:what is|what are|who is|who are|how does|how do)\s+",
        r"^(?:give me information on|information about)\s+",
    )
    previous = None
    while previous != text:
        previous = text
        for pattern in patterns:
            text = re.sub(pattern, "", text, flags=re.I).strip()
    return text[:300] if text else None


def _is_reference_command(command):
    low = (command or "").lower().strip()
    if not low:
        return False
    has_ref = any(re.search(r"\b" + re.escape(word) + r"\b", low) for word in _REFERENCE_WORDS)
    has_ref = has_ref or any(phrase in low for phrase in _REFERENCE_PHRASES_2)
    has_action = any(action in low for action in _REFERENCE_ACTIONS)
    # Short follow-ups such as "and what about it?" are also references.
    return has_ref and (has_action or len(low.split()) <= 8)


def record_user_command(command):
    """Record every user command in a small persistent context ledger.
    This is best-effort and never blocks FRIDAY."""
    try:
        text = re.sub(r"\s+", " ", (command or "").strip())
        if not text:
            return
        now = time.time()
        low = text.lower()
        turn = {"role": "user", "content": text, "timestamp": now}
        turns = _conversation_context.setdefault("turns", [])
        turns.append(turn)

        # Do not replace a strong topic with a reference-only command.
        if not _is_reference_command(text):
            topic = _clean_topic(text)
            if topic and len(topic.split()) >= 1:
                # Very short generic commands are not useful as a topic.
                generic = {"yes", "no", "okay", "ok", "thanks", "thank you", "hi", "hello", "listening"}
                if low not in generic:
                    _conversation_context["active_topic"] = topic

        # Keep the most recent explicit research/creation topic authoritative.
        if _state.get("last_topic") and _fresh_enough(_state.get("last_research")):
            _conversation_context["active_topic"] = _state.get("last_topic")

        _conversation_context["updated_at"] = now
        _save_conversation_context()
    except Exception as error:
        print("Persistent conversation context record skipped (ignored):", error)


def record_assistant_response(answer):
    """Store a compact assistant turn for context continuity."""
    try:
        text = re.sub(r"\s+", " ", (answer or "").strip())
        if not text:
            return
        _conversation_context.setdefault("turns", []).append({
            "role": "assistant", "content": text[:1800], "timestamp": time.time()
        })
        _save_conversation_context()
    except Exception:
        pass


def persistent_topic_hint():
    """Return a compact, restart-safe context hint for the AI prompt."""
    try:
        topic = _conversation_context.get("active_topic")
        if not topic:
            return ""
        updated = _conversation_context.get("updated_at") or 0
        if time.time() - updated > _CONTEXT_TOPIC_TTL_SECONDS:
            return ""
        return f"(Persistent conversation context: the active topic is '{topic}'.)"
    except Exception:
        return ""


def resolve_persistent(original_command):
    """Resolve pronoun/reference follow-ups using restart-safe context.
    Existing friday_context.resolve() remains authoritative when it already
    has a fresh, specific research/creation context."""
    fallback = {
        "command": original_command,
        "rewritten": False,
        "reuse_research": False,
        "reuse_sources": [],
        "topic": None,
    }
    try:
        text = (original_command or "").strip()
        topic = _conversation_context.get("active_topic")
        if not text or not topic:
            return fallback
        updated = _conversation_context.get("updated_at") or 0
        if time.time() - updated > _CONTEXT_TOPIC_TTL_SECONDS:
            return fallback
        if not _is_reference_command(text):
            return fallback

        low = text.lower()
        # A reference word/phrase is itself the safety gate here. Commands
        # such as "tell me more about it" or "compare those" intentionally
        # contain conversational language, but their subject is still
        # supplied by the active topic.
        rewritten = f"{text} regarding {topic}" 
        return {
            "command": rewritten,
            "rewritten": True,
            "reuse_research": False,
            "reuse_sources": [],
            "topic": topic,
        }
    except Exception as error:
        print("Persistent context resolution skipped (ignored):", error)
        return fallback
