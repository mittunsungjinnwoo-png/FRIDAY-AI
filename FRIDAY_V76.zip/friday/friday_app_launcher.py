"""
FRIDAY V2044 - UNIVERSAL APPLICATION LAUNCHER
=============================================

Before this module FRIDAY could only open the handful of programs listed in
friday_desktop_agent.APP_ALIASES (Chrome, Notepad, WhatsApp, WPS ...).  Anything
else ("open discord", "open vs code", "open photoshop") fell through to the AI
chat model, which then explained that it could not do it.

This module builds an INDEX of everything that is installed and launches it:

    * Start-Menu shortcuts (.lnk / .url / .appref-ms)        - classic desktop apps
    * Get-StartApps (Start-menu apps incl. Microsoft Store)  - launched through shell:AppsFolder
    * "App Paths" registry entries                            - chrome.exe, winword.exe ...
    * built-in Windows tools (Task Manager, Control Panel ...)
    * Windows Settings pages (ms-settings:) and special folders (Downloads ...)

`resolve()` matches what the user said ("vs code", "w p s", "whats app", "power
point", "discrod") to an installed program with typo / spoken-form tolerant
scoring. `launch()` starts it and then VERIFIES the result from the outside
(new window / new process / foreground window) instead of assuming success.

All Windows specifics live behind the small `WindowsPlatform` class so the
matching, ranking, caching and verification logic is unit-testable anywhere.
"""
from __future__ import annotations

import difflib
import json
import os
import platform
import re
import struct
import subprocess
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

IS_WINDOWS = platform.system() == "Windows"
CACHE_FILE = Path(__file__).resolve().parent / "friday_app_index.json"
CACHE_TTL_SECONDS = 12 * 3600
REFRESH_MIN_INTERVAL = 90          # never rescan more often than this when an app is simply missing

_KIND_PRIORITY = {"appsfolder": 4, "lnk": 3, "exe": 2, "system": 2, "uri": 2}


# ----------------------------------------------------------------------------
# data model
# ----------------------------------------------------------------------------
@dataclass
class AppEntry:
    name: str                      # display name, e.g. "Visual Studio Code"
    kind: str                      # appsfolder | lnk | exe | system | uri
    target: str                    # AppID / shortcut path / exe path / uri
    exe: str = ""                  # lower-case executable stem when known ("code")
    aliases: list = field(default_factory=list)
    source: str = ""

    @property
    def priority(self) -> int:
        return _KIND_PRIORITY.get(self.kind, 1)


@dataclass
class Resolution:
    entry: Optional[AppEntry]
    score: float
    alternatives: list             # [(AppEntry, score), ...] best first (excluding `entry`)


# ----------------------------------------------------------------------------
# text normalisation + scoring
# ----------------------------------------------------------------------------
_GENERIC_TOKENS = {"microsoft", "windows", "google", "the", "app", "application", "desktop", "for", "edition",
                   "official", "program", "software", "new", "classic", "preview", "beta"}
_NOISE_NAME = re.compile(
    r"\b(?:uninstall|un-install|readme|read me|help|documentation|release notes|license|manual|website|web site|"
    r"homepage|home page|updater|update|installer|setup|repair|debug|sdk|troubleshoot|what'?s new|changelog|"
    r"support|tutorial|samples?|eula|remove)\b", re.I)

# spoken forms -> canonical search strings (applied to the QUERY, in addition to the raw query)
_QUERY_REWRITES = {
    "vs code": "visual studio code", "vscode": "visual studio code", "v s code": "visual studio code",
    "code editor": "visual studio code", "visual studio": "visual studio",
    "ms word": "word", "microsoft word": "word", "ms excel": "excel", "microsoft excel": "excel",
    "ms powerpoint": "powerpoint", "microsoft powerpoint": "powerpoint", "power point": "powerpoint", "ppt": "powerpoint",
    "one note": "onenote", "ms teams": "teams", "microsoft teams": "teams",
    "whats app": "whatsapp", "what's app": "whatsapp", "whatsap": "whatsapp", "watsapp": "whatsapp",
    "you tube": "youtube", "insta": "instagram", "fb": "facebook",
    "chrome browser": "chrome", "google chrome": "chrome", "browser": "chrome", "web browser": "chrome",
    "edge browser": "edge", "microsoft edge": "edge",
    "notes": "sticky notes", "file explorer": "explorer", "windows explorer": "explorer", "files": "explorer",
    "cmd": "command prompt", "terminal": "terminal", "power shell": "powershell",
    "task manager": "task manager", "taskmanager": "task manager", "control panel": "control panel",
    "obs studio": "obs", "video lan": "vlc", "vlc player": "vlc", "vlc media player": "vlc",
    "wps": "wps office", "kingsoft wps": "wps office", "kingsoft wps office": "wps office",
    "pc": "this pc", "computer": "this pc", "my computer": "this pc",
    "calc": "calculator", "note pad": "notepad", "paint brush": "paint",
    "settings": "windows settings", "pc settings": "windows settings", "system settings": "windows settings",
    "computer settings": "windows settings",
}

# executable stem -> extra spoken aliases
_EXE_ALIASES = {
    "winword": ["word", "ms word"], "excel": ["excel", "ms excel"], "powerpnt": ["powerpoint", "ppt", "power point"],
    "msedge": ["edge"], "code": ["vscode", "vs code", "visual studio code"], "mspaint": ["paint"],
    "calc": ["calculator"], "wt": ["terminal", "windows terminal"], "cmd": ["command prompt", "cmd"],
    "outlook": ["outlook", "mail"], "onenote": ["onenote", "one note"], "teams": ["teams"], "chrome": ["chrome", "browser"],
    "firefox": ["firefox", "mozilla"], "brave": ["brave"], "spotify": ["spotify"], "wps": ["wps", "wps office"],
    "explorer": ["file explorer", "explorer", "files"], "notepad": ["notepad", "note pad"], "obs64": ["obs"],
    "vlc": ["vlc"], "zoom": ["zoom"], "discord": ["discord"], "slack": ["slack"], "steam": ["steam"],
    "telegram": ["telegram"], "whatsapp": ["whatsapp", "whats app"], "photoshop": ["photoshop", "ps"],
}


def _compact(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", s.lower())


def _tokens(s: str) -> list:
    return [t for t in re.split(r"[^a-z0-9]+", s.lower()) if t]


def _join_letters(q: str) -> str:
    """'w p s' -> 'wps' (spoken spelling)."""
    toks = q.lower().split()
    if len(toks) >= 2 and all(len(t) == 1 and t.isalnum() for t in toks):
        return "".join(toks)
    return q


def normalise_query(q: str) -> str:
    q = str(q or "").lower().strip()
    q = re.sub(r"[^\w\s.+#'-]", " ", q)
    q = re.sub(r"\b(?:the|my|a|an|please|app|application|program|software)\b", " ", q)
    q = re.sub(r"\s+", " ", q).strip()
    return _join_letters(q)


def expand_query(q: str) -> list:
    """Candidate search strings for one spoken query (raw first, then rewrites)."""
    base = normalise_query(q)
    out = [base]
    for k in (base, _compact(base)):
        v = _QUERY_REWRITES.get(k)
        if v and v not in out:
            out.append(v)
    # "microsoft word" -> "word", "google chrome" -> "chrome"
    stripped = " ".join(t for t in base.split() if t not in _GENERIC_TOKENS)
    if stripped and stripped not in out:
        out.append(stripped)
    return [o for o in out if o]


def _name_variants(entry: AppEntry) -> list:
    variants = [entry.name] + list(entry.aliases)
    if entry.exe:
        variants.append(entry.exe)
        variants += _EXE_ALIASES.get(entry.exe, [])
    return variants


def _significant(tokens: list) -> list:
    return [t for t in tokens if t not in _GENERIC_TOKENS]


def score_entry(query: str, entry: AppEntry) -> float:
    """0..1 similarity between a normalised query and one index entry."""
    qn = normalise_query(query)
    qc = _compact(qn)
    if not qc:
        return 0.0
    qtoks = _tokens(qn)
    qsig = set(_significant(qtoks)) or set(qtoks)
    best = 0.0
    for raw in _name_variants(entry):
        nn = normalise_query(raw) or raw.lower()
        nc = _compact(nn)
        if not nc:
            continue
        ntoks = _tokens(nn)
        nsig = set(_significant(ntoks)) or set(ntoks)
        s = 0.0
        if qc == nc:
            s = 1.0
        elif qsig == nsig:
            s = 0.99
        elif len(qc) >= 4 and nc.startswith(qc):
            s = 0.90 + 0.05 * (len(qc) / len(nc))
        elif qsig and qsig <= nsig:
            s = 0.86 + 0.04 * (len(qsig) / max(1, len(nsig)))
        elif len(qc) >= 4 and qc in nc:
            s = 0.84
        elif len(nc) >= 4 and nc in qc and len(nc) >= 0.6 * len(qc):
            s = 0.80
        else:
            r = difflib.SequenceMatcher(None, qc, nc).ratio()
            if r >= (0.8 if len(qc) >= 5 else 0.9):
                s = 0.78 + 0.19 * (r - 0.8) / 0.2
            # a single spoken word vs one word of a longer name ("discrod" vs "Discord Canary")
            if len(qc) >= 4:
                for t in nsig:
                    if len(t) >= 4:
                        rt = difflib.SequenceMatcher(None, qc, t).ratio()
                        if rt >= 0.85:
                            s = max(s, 0.70 + 0.25 * (rt - 0.85) / 0.15)
        best = max(best, s)
    return min(1.0, best)


# ----------------------------------------------------------------------------
# .lnk parsing (target exe of a Start-Menu shortcut, used only for verification tokens)
# ----------------------------------------------------------------------------
def parse_lnk_target(path: str) -> Optional[str]:
    """Minimal Shell-Link (.lnk) reader: returns the local target path when the shortcut stores one."""
    try:
        data = Path(path).read_bytes()
        if len(data) < 0x4C or data[:4] != b"L\x00\x00\x00":
            return None
        flags = struct.unpack_from("<I", data, 0x14)[0]
        pos = 0x4C
        if flags & 0x1:                                   # HasLinkTargetIDList
            pos += 2 + struct.unpack_from("<H", data, pos)[0]
        if flags & 0x2:                                   # HasLinkInfo
            li = pos
            (_size, _hdr, li_flags, _vol, base_off, _nv, suffix_off) = struct.unpack_from("<IIIIIII", data, li)
            if li_flags & 0x1:                            # VolumeIDAndLocalBasePath
                def cstr(off):
                    end = data.index(b"\x00", li + off)
                    return data[li + off:end].decode("mbcs" if IS_WINDOWS else "latin-1", "ignore")
                return cstr(base_off) + cstr(suffix_off)
    except Exception:
        return None
    return None


# ----------------------------------------------------------------------------
# platform layer
# ----------------------------------------------------------------------------
class WindowsPlatform:
    """Everything that touches Windows. Replaced by a fake in the unit tests."""

    def start_menu_shortcuts(self) -> list:
        roots = [
            Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
            Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
        ]
        found = []
        for root in roots:
            try:
                if not root.is_dir():
                    continue
                for p in root.rglob("*"):
                    if p.suffix.lower() in {".lnk", ".url", ".appref-ms"}:
                        found.append((p.stem, str(p)))
            except Exception:
                continue
        return found

    def start_apps(self) -> list:
        """(Name, AppID) for every Start-menu app, Store apps included."""
        if not IS_WINDOWS:
            return []
        cmd = ("[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;"
               "Get-StartApps | Select-Object Name,AppID | ConvertTo-Json -Compress")
        try:
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            cp = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", cmd],
                                capture_output=True, timeout=30, creationflags=flags)
            return parse_start_apps_json(cp.stdout.decode("utf-8", "ignore"))
        except Exception:
            return []

    def app_paths(self) -> list:
        """(exe file name, full path) from the 'App Paths' registry keys."""
        if not IS_WINDOWS:
            return []
        out = []
        try:
            import winreg
            base = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths"
            for hive, sub in ((winreg.HKEY_LOCAL_MACHINE, base),
                              (winreg.HKEY_CURRENT_USER, base),
                              (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths")):
                try:
                    with winreg.OpenKey(hive, sub) as k:
                        i = 0
                        while True:
                            try:
                                name = winreg.EnumKey(k, i)
                            except OSError:
                                break
                            i += 1
                            try:
                                with winreg.OpenKey(k, name) as sk:
                                    val, _t = winreg.QueryValueEx(sk, "")
                                    out.append((name, str(val).strip().strip('"')))
                            except OSError:
                                continue
                except OSError:
                    continue
        except Exception:
            pass
        return out

    def which(self, name: str) -> Optional[str]:
        import shutil
        return shutil.which(name)

    def start(self, kind: str, target: str) -> None:
        if kind == "appsfolder":
            os.startfile("shell:AppsFolder\\" + target)            # type: ignore[attr-defined]
        else:
            os.startfile(target)                                    # type: ignore[attr-defined]

    def focus_window(self, hwnd: int) -> bool:
        """Restore + bring a window to the front and confirm it is really the foreground window."""
        if not IS_WINDOWS:
            return False
        try:
            import friday_system_control
            return bool(friday_system_control._force_foreground(int(hwnd)))   # noqa: SLF001
        except Exception:
            return False

    def snapshot(self) -> dict:
        """{'windows': [(hwnd, title, proc_name_lower)], 'procs': {pid: name_lower}, 'fg': (title, proc)}"""
        snap = {"windows": [], "procs": {}, "fg": ("", "")}
        if not IS_WINDOWS:
            return snap
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            try:
                import psutil
            except Exception:
                psutil = None
            names = {}

            def proc_name(pid):
                if pid in names:
                    return names[pid]
                nm = ""
                if psutil:
                    try:
                        nm = psutil.Process(pid).name().lower()
                    except Exception:
                        nm = ""
                names[pid] = nm
                return nm

            EnumProc = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

            def cb(hwnd, _lp):
                try:
                    if not user32.IsWindowVisible(hwnd):
                        return True
                    n = user32.GetWindowTextLengthW(hwnd)
                    if n <= 0:
                        return True
                    buf = ctypes.create_unicode_buffer(n + 1)
                    user32.GetWindowTextW(hwnd, buf, n + 1)
                    pid = wintypes.DWORD()
                    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                    snap["windows"].append((int(hwnd), buf.value, proc_name(pid.value)))
                except Exception:
                    pass
                return True

            user32.EnumWindows(EnumProc(cb), 0)
            fg = user32.GetForegroundWindow()
            if fg:
                n = user32.GetWindowTextLengthW(fg)
                buf = ctypes.create_unicode_buffer(n + 1)
                user32.GetWindowTextW(fg, buf, n + 1)
                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(fg, ctypes.byref(pid))
                snap["fg"] = (buf.value, proc_name(pid.value))
            if psutil:
                for p in psutil.process_iter(["pid", "name"]):
                    try:
                        snap["procs"][p.info["pid"]] = (p.info.get("name") or "").lower()
                    except Exception:
                        pass
        except Exception:
            pass
        return snap


def parse_start_apps_json(text: str) -> list:
    """Get-StartApps | ConvertTo-Json output -> [(Name, AppID)] (one object or a list)."""
    text = (text or "").strip().lstrip("\ufeff")
    if not text:
        return []
    try:
        data = json.loads(text)
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    out = []
    for item in data if isinstance(data, list) else []:
        if isinstance(item, dict) and item.get("Name") and item.get("AppID"):
            out.append((str(item["Name"]).strip(), str(item["AppID"]).strip()))
    return out


# ----------------------------------------------------------------------------
# built-in Windows tools, settings pages and folders (always available)
# ----------------------------------------------------------------------------
def _system_entries() -> list:
    E = AppEntry
    tools = [
        ("Task Manager", "taskmgr.exe", ["taskmgr"]), ("Control Panel", "control.exe", ["control"]),
        ("Command Prompt", "cmd.exe", ["cmd", "command prompt", "dos"]),
        ("Registry Editor", "regedit.exe", ["regedit", "registry"]),
        ("Device Manager", "devmgmt.msc", ["devices manager"]), ("Disk Management", "diskmgmt.msc", ["disk manager"]),
        ("Services", "services.msc", []), ("Event Viewer", "eventvwr.msc", ["event logs"]),
        ("System Information", "msinfo32.exe", ["msinfo", "system info"]), ("Resource Monitor", "resmon.exe", []),
        ("Performance Monitor", "perfmon.exe", []), ("Disk Cleanup", "cleanmgr.exe", ["cleanup"]),
        ("Snipping Tool", "snippingtool.exe", ["snip", "screenshot tool"]), ("Paint", "mspaint.exe", ["ms paint"]),
        ("WordPad", "write.exe", ["word pad"]), ("Character Map", "charmap.exe", []),
        ("Remote Desktop Connection", "mstsc.exe", ["remote desktop", "rdp"]), ("On-Screen Keyboard", "osk.exe", ["screen keyboard"]),
        ("Magnifier", "magnify.exe", []), ("Narrator", "narrator.exe", []), ("Notepad", "notepad.exe", ["note pad"]),
        ("Calculator", "calc.exe", ["calc"]), ("File Explorer", "explorer.exe", ["explorer", "windows explorer", "files"]),
        ("System Configuration", "msconfig.exe", ["msconfig"]), ("DirectX Diagnostic Tool", "dxdiag.exe", ["dxdiag"]),
        ("Windows Media Player Legacy", "wmplayer.exe", ["media player", "wmplayer"]),
    ]
    out = [E(n, "system", exe, exe=exe.rsplit(".", 1)[0].lower(), aliases=list(al), source="builtin") for n, exe, al in tools]
    settings = [
        ("Windows Settings", "ms-settings:", ["settings app", "pc settings", "system settings", "computer settings"]),
        ("Wi-Fi Settings", "ms-settings:network-wifi", ["wifi settings", "wi fi settings", "wifi", "wi-fi", "network settings"]),
        ("Bluetooth Settings", "ms-settings:bluetooth", ["bluetooth", "bluetooth and devices"]),
        ("Display Settings", "ms-settings:display", ["display", "screen settings", "resolution settings"]),
        ("Sound Settings", "ms-settings:sound", ["sound", "audio settings", "volume settings"]),
        ("Battery Settings", "ms-settings:batterysaver", ["battery", "battery saver", "battery settings"]),
        ("Windows Update Settings", "ms-settings:windowsupdate", ["windows update", "updates", "check for updates"]),
        ("Apps and Features", "ms-settings:appsfeatures", ["installed apps", "apps settings", "uninstall programs"]),
        ("Default Apps Settings", "ms-settings:defaultapps", ["default apps"]),
        ("Personalization Settings", "ms-settings:personalization", ["personalization", "themes", "wallpaper settings"]),
        ("Privacy Settings", "ms-settings:privacy", ["privacy"]),
        ("Storage Settings", "ms-settings:storagesense", ["storage", "storage settings", "storage sense"]),
        ("Notification Settings", "ms-settings:notifications", ["notifications settings"]),
        ("Power and Sleep Settings", "ms-settings:powersleep", ["power settings", "sleep settings", "power and sleep"]),
        ("Night Light Settings", "ms-settings:nightlight", ["night light"]),
        ("VPN Settings", "ms-settings:network-vpn", ["vpn"]),
        ("Airplane Mode Settings", "ms-settings:network-airplanemode", ["airplane mode", "flight mode"]),
        ("Printers and Scanners", "ms-settings:printers", ["printers", "printer settings"]),
        ("Mouse Settings", "ms-settings:mousetouchpad", ["mouse", "touchpad settings", "mouse and touchpad"]),
        ("About This PC", "ms-settings:about", ["about my pc", "about pc", "pc info", "system about"]),
        ("Date and Time Settings", "ms-settings:dateandtime", ["date and time", "time settings", "clock settings"]),
        ("Language Settings", "ms-settings:regionlanguage", ["language settings", "region settings"]),
        ("Startup Apps Settings", "ms-settings:startupapps", ["startup apps", "startup programs"]),
    ]
    out += [E(n, "uri", uri, aliases=list(al), source="settings") for n, uri, al in settings]
    folders = [
        ("Downloads", "shell:Downloads", ["downloads", "downloads folder"]),
        ("Documents", "shell:Personal", ["documents", "documents folder", "my documents"]),
        ("Desktop", "shell:Desktop", ["desktop folder"]),
        ("Pictures", "shell:My Pictures", ["pictures", "pictures folder", "photos folder"]),
        ("Music", "shell:My Music", ["music folder"]),
        ("Videos", "shell:My Video", ["videos folder", "video folder"]),
        ("Recycle Bin", "shell:RecycleBinFolder", ["recycle bin", "trash", "bin"]),
        ("This PC", "shell:MyComputerFolder", ["this pc", "my computer", "computer", "pc"]),
    ]
    out += [E(n, "uri", uri, aliases=list(al), source="folder") for n, uri, al in folders]
    return out


# ----------------------------------------------------------------------------
# index
# ----------------------------------------------------------------------------
def _exe_stem(path_or_name: str) -> str:
    base = re.split(r"[\\/]", str(path_or_name or ""))[-1]
    return re.sub(r"\.(?:exe|msc|bat|cmd)$", "", base, flags=re.I).lower()


def build_entries(platform_: Any) -> list:
    """Collect every launchable thing, de-duplicated by display name (best source wins)."""
    entries: list = []
    try:
        for name, appid in platform_.start_apps():
            if name and appid and not _NOISE_NAME.search(name):
                exe = ""
                if re.search(r"\.exe$", appid, re.I):
                    exe = _exe_stem(appid)
                entries.append(AppEntry(name, "appsfolder", appid, exe=exe, source="start-apps"))
    except Exception:
        pass
    try:
        for name, path in platform_.start_menu_shortcuts():
            if name and not _NOISE_NAME.search(name):
                exe = ""
                if path.lower().endswith(".lnk"):
                    tgt = parse_lnk_target(path)
                    if tgt:
                        exe = _exe_stem(tgt)
                entries.append(AppEntry(name, "lnk", path, exe=exe, source="start-menu"))
    except Exception:
        pass
    try:
        for exe_name, path in platform_.app_paths():
            stem = _exe_stem(exe_name)
            if stem and path and not _NOISE_NAME.search(stem):
                entries.append(AppEntry(stem, "exe", path, exe=stem, source="app-paths"))
    except Exception:
        pass
    entries += _system_entries()

    best: dict = {}
    for e in entries:
        key = _compact(e.name)
        if not key:
            continue
        cur = best.get(key)
        if cur is None or e.priority > cur.priority:
            if cur is not None and cur.exe and not e.exe:
                e.exe = cur.exe                       # keep the exe hint discovered elsewhere
            best[key] = e
        elif cur is not None and e.exe and not cur.exe:
            cur.exe = e.exe
    return sorted(best.values(), key=lambda x: x.name.lower())


class AppIndex:
    def __init__(self, platform_: Any = None, cache_file: Optional[Path] = None, ttl: float = CACHE_TTL_SECONDS,
                 clock: Callable[[], float] = time.time):
        self.platform = platform_ or WindowsPlatform()
        self.cache_file = Path(cache_file) if cache_file else CACHE_FILE
        self.ttl = ttl
        self.clock = clock
        self.entries: list = []
        self.built_at = 0.0
        self._last_scan = 0.0
        self._refreshing = False
        self._lock = threading.RLock()

    # -- persistence -------------------------------------------------------
    def _load_cache(self) -> bool:
        try:
            data = json.loads(self.cache_file.read_text(encoding="utf-8"))
            self.entries = [AppEntry(**e) for e in data["entries"]]
            self.built_at = float(data["built"])
            return bool(self.entries)
        except Exception:
            return False

    def _save_cache(self) -> None:
        try:
            tmp = self.cache_file.with_suffix(".tmp")
            tmp.write_text(json.dumps({"built": self.built_at, "entries": [asdict(e) for e in self.entries]},
                                      ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.cache_file)
        except Exception:
            pass

    # -- API ---------------------------------------------------------------
    def refresh(self) -> int:
        with self._lock:
            self.entries = build_entries(self.platform)
            self.built_at = self.clock()
            self._last_scan = self.built_at
            self._save_cache()
            return len(self.entries)

    def ensure(self) -> list:
        with self._lock:
            if not self.entries and not self._load_cache():
                self.refresh()                                    # first ever run: must scan now
            elif self.clock() - self.built_at > self.ttl and not self._refreshing:
                # stale but usable: answer from the old index now, rescan without blocking the command
                self._refreshing = True

                def _bg():
                    try:
                        self.refresh()
                    finally:
                        self._refreshing = False
                threading.Thread(target=_bg, name="FridayAppIndexRefresh", daemon=True).start()
            return self.entries

    def maybe_rescan_for_miss(self) -> bool:
        """A just-installed app is not in the index yet: rescan, but at most once per REFRESH_MIN_INTERVAL."""
        with self._lock:
            if self.clock() - self._last_scan < REFRESH_MIN_INTERVAL:
                return False
            self.refresh()
            return True


_INDEX: Optional[AppIndex] = None
_INDEX_LOCK = threading.Lock()


def get_index() -> AppIndex:
    global _INDEX
    with _INDEX_LOCK:
        if _INDEX is None:
            _INDEX = AppIndex()
        return _INDEX


def set_index(index: Optional[AppIndex]) -> None:
    """Test hook / dependency injection."""
    global _INDEX
    with _INDEX_LOCK:
        _INDEX = index


def warm() -> None:
    """Build the index in the background (safe to call from a daemon thread)."""
    try:
        get_index().ensure()
    except Exception:
        pass


# ----------------------------------------------------------------------------
# resolution
# ----------------------------------------------------------------------------
ACCEPT_SCORE = 0.78


def _rank(query: str, entries: list) -> list:
    variants = expand_query(query)
    ranked = []
    for e in entries:
        if e.kind not in {"system", "uri"} and _NOISE_NAME.search(e.name):
            continue
        s = max((score_entry(v, e) for v in variants), default=0.0)
        if s > 0.5:
            ranked.append((e, s))
    # best score first; then kind priority; then shorter (closer) display name
    ranked.sort(key=lambda es: (-round(es[1], 3), -es[0].priority, len(es[0].name)))
    return ranked


def resolve(query: str, index: Optional[AppIndex] = None, allow_rescan: bool = True) -> Resolution:
    idx = index or get_index()
    entries = idx.ensure()
    ranked = _rank(query, entries)
    if (not ranked or ranked[0][1] < ACCEPT_SCORE) and allow_rescan:
        try:
            if idx.maybe_rescan_for_miss():
                ranked = _rank(query, idx.entries)
        except Exception:
            pass
    if ranked and ranked[0][1] >= ACCEPT_SCORE:
        return Resolution(ranked[0][0], ranked[0][1], ranked[1:4])
    return Resolution(None, ranked[0][1] if ranked else 0.0, ranked[:3])


# ----------------------------------------------------------------------------
# launching + verification
# ----------------------------------------------------------------------------
def _verify_tokens(entry: AppEntry) -> list:
    toks = set(_significant(_tokens(entry.name)))
    if entry.exe:
        toks.add(entry.exe.lower())
    for a in _EXE_ALIASES.get(entry.exe, []):
        toks.update(_significant(_tokens(a)))
    return [t for t in toks if len(t) >= 3 and t not in {"exe", "settings", "manager"} or t in {"wps", "obs", "vlc"}]


def _matches(tokens: list, title: str, proc: str) -> bool:
    """Short tokens ("word", "code") must appear in the PROCESS name so an unrelated window title cannot
    'verify' a launch; longer tokens may also match the window title (Store apps live in ApplicationFrameHost)."""
    tl, pl = (title or "").lower(), (proc or "").lower()
    for t in tokens:
        if t in pl:
            return True
        if t in tl and (len(t) >= 5 or pl == "applicationframehost.exe"):
            return True
    return False


def verify_launch(entry: AppEntry, before: dict, after: dict) -> tuple:
    """Decide from before/after desktop snapshots whether the app really appeared.
    Returns (verified, evidence, window_title)."""
    tokens = _verify_tokens(entry)
    before_hwnds = {w[0] for w in before.get("windows", [])}
    fg_title, fg_proc = after.get("fg", ("", ""))
    fg_before = before.get("fg", ("", ""))

    # 1. foreground window belongs to the app
    if tokens and _matches(tokens, fg_title, fg_proc):
        return True, "foreground window", fg_title
    # 2. a NEW window of the app
    new_windows = [w for w in after.get("windows", []) if w[0] not in before_hwnds]
    for hwnd, title, proc in new_windows:
        if tokens and _matches(tokens, title, proc):
            return True, "new window", title
    # 3. the app already had a window (single-instance apps just focus it)
    for hwnd, title, proc in after.get("windows", []):
        if tokens and _matches(tokens, title, proc) and hwnd in before_hwnds:
            return True, "existing window", title
    # 4. a new process of the app (no visible window yet, e.g. tray apps)
    new_procs = [n for pid, n in after.get("procs", {}).items() if pid not in before.get("procs", {})]
    if any(tokens and any(t in n for t in tokens) for n in new_procs):
        return True, "new process", ""
    # 5. settings pages / folders open in generic host windows: any brand-new window counts
    if entry.kind in {"uri"} and new_windows:
        return True, "new window", new_windows[0][1]
    if entry.kind in {"uri"} and fg_title and fg_title != fg_before[0]:
        return True, "foreground changed", fg_title
    return False, "", fg_title


def launch_entry(entry: AppEntry, platform_: Any = None, wait: float = 6.0, poll: float = 0.35,
                 sleep: Callable[[float], None] = time.sleep, clock: Callable[[], float] = time.time) -> dict:
    pf = platform_ or get_index().platform
    result = {"ok": False, "executed": False, "verified": False, "application": entry.name,
              "method": entry.kind, "evidence": "", "active_window": ""}
    try:
        before = pf.snapshot()
    except Exception:
        before = {"windows": [], "procs": {}, "fg": ("", "")}
    # Already running? Then "open X" means "go back to X": bring its existing window to the front
    # (restoring it if minimised) and only report success once it is really the foreground window.
    focus_fn = getattr(pf, "focus_window", None)
    tokens = _verify_tokens(entry)

    def _existing(snap: dict) -> list:
        return [w for w in snap.get("windows", []) if tokens and _matches(tokens, w[1], w[2])]

    def _try_focus(snap: dict) -> str:
        for hwnd, wtitle, _proc in _existing(snap)[:4]:
            try:
                if focus_fn(hwnd):
                    return wtitle
            except Exception:
                continue
        return ""

    existing_before = _existing(before) if focus_fn is not None else []
    if existing_before:
        focused = _try_focus(before)
        if focused:
            result.update(ok=True, executed=True, verified=True, evidence="brought existing window to front",
                          active_window=focused)
            return result
    try:
        pf.start(entry.kind, entry.target)
        result["executed"] = True
    except Exception as exc:
        result["error"] = f"launch_failed: {exc}"
        return result
    deadline = clock() + wait
    verified, evidence, title = False, "", ""
    while True:
        sleep(poll)
        try:
            after = pf.snapshot()
        except Exception:
            after = {"windows": [], "procs": {}, "fg": ("", "")}
        verified, evidence, title = verify_launch(entry, before, after)
        if verified or clock() >= deadline:
            break
    if existing_before:
        # The app already had a window, so "an existing window exists" proves nothing: require it in front.
        focused = _try_focus(after)
        verified = bool(focused)
        evidence = "brought existing window to front" if focused else ""
        title = focused or title
    result.update(ok=verified, verified=verified, evidence=evidence, active_window=title)
    if not verified:
        result["error"] = "application_open_not_verified"
    return result


def launch(query: str, index: Optional[AppIndex] = None, platform_: Any = None, **kw) -> dict:
    """Resolve `query` to an installed program and start it. Never raises."""
    res = {"ok": False, "executed": False, "verified": False, "application": query}
    if not IS_WINDOWS and platform_ is None and index is None:
        res["error"] = "not_windows"
        return res
    try:
        r = resolve(query, index=index)
    except Exception as exc:
        res["error"] = f"resolve_failed: {exc}"
        return res
    if r.entry is None:
        res["error"] = "application_not_found"
        res["suggestions"] = [e.name for e, _s in r.alternatives[:3]]
        return res
    idx = index or get_index()
    out = launch_entry(r.entry, platform_=platform_ or idx.platform, **kw)
    out["score"] = round(r.score, 3)
    return out
