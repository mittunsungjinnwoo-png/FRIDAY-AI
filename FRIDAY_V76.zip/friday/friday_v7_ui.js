/* FRIDAY 7.0 Intelligence - one page, ten tabs, driven by the Python backend over the FRIDAY_V7:: channel.
   Shows real recorded state only (missions with receipts, objectives, evidence, memory with dates and sources, security centre, health, benchmarks).
   Every button either sends an action to the backend or asks FRIDAY a normal chat command; nothing here animates for show. */
(function () {
  'use strict';
  var B = window.fridayBridge || null;
  var TABS = ['Overview', 'Missions', 'Goals', 'Memory', 'Evidence', 'Security', 'Health', 'Quality', 'Savings', 'Settings'];
  var S = { tab: 'Overview', data: {}, arg: '', result: {}, timer: null };

  function h(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function dec(b) { return decodeURIComponent(escape(atob(b))); }
  function A(x) { return Array.isArray(x) ? x : []; }
  function O(x) { return x && typeof x === 'object' && !Array.isArray(x) ? x : {}; }
  function send(o) { if (B && B.v7) B.v7(o); }
  function ask(tab, arg) { send({ op: 'snapshot', tab: tab.toLowerCase(), arg: arg || '' }); }
  function act(a, extra, tab) { var o = { op: 'action', action: a, tab: (tab || S.tab).toLowerCase() }; for (var k in (extra || {})) o[k] = extra[k]; send(o); }
  function toastx(t) { if (typeof toast === 'function') toast(t); }
  /* A chat command goes through the normal route, so the answer is spoken and shown in the conversation like any other request. */
  function say(text) { if (B && B.sendCommand) { B.sendCommand(text, []); toastx('Sent: ' + text); } else toastx('Open the desktop app to use this.'); }
  function pct(v) { return Math.max(0, Math.min(100, Number(v) || 0)); }
  function bar(label, v, warn, suffix) { v = pct(v); return '<div class="mr6"><span>' + h(label) + '</span><div class="m6" role="meter" aria-label="' + h(label) + '" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(v) + '"><i style="width:' + v + '%' + (warn && v > warn ? ';background:var(--bad)' : '') + '"></i></div><b>' + Math.round(v) + (suffix || '%') + '</b></div>'; }
  function tbl(head, rows) { return '<table><tr>' + head.map(function (x) { return '<th>' + h(x) + '</th>'; }).join('') + '</tr>' + (rows.length ? rows.join('') : '<tr><td colspan="' + head.length + '" class="note">Nothing yet.</td></tr>') + '</table>'; }
  function row(cells) { return '<tr>' + cells.map(function (c) { return '<td>' + c + '</td>'; }).join('') + '</tr>'; }
  function grp(title, body, note) { return '<div class="sg"><h4>' + h(title) + '</h4>' + (note ? '<p class="note">' + h(note) + '</p>' : '') + body + '</div>'; }
  function btn(label, a, extra, cls) { return '<button class="btn ' + (cls || '') + '" data-a="' + h(a) + '" data-x="' + h(JSON.stringify(extra || {})) + '">' + h(label) + '</button>'; }
  function cbtn(label, text, cls) { return '<button class="btn ' + (cls || '') + '" data-say="' + h(text) + '">' + h(label) + '</button>'; }
  function chip(t, kind) { return '<span class="chip ' + (kind || '') + '">' + h(t) + '</span>'; }
  function stat(s) { s = String(s || ''); var good = /^(ok|done|active|passed|verified|completed|working|success)/i.test(s), bad = /^(fail|error|broken|blocked|denied|unavailable|critical)/i.test(s); return '<span class="' + (good ? 'ok' : bad ? 'bad' : 'note') + '">' + h(s.replace(/_/g, ' ')) + '</span>'; }
  function list(items) { items = A(items); return items.length ? '<ul>' + items.map(function (x) { return '<li>' + h(x) + '</li>'; }).join('') + '</ul>' : '<p class="note">Nothing to show.</p>'; }
  function input(id, ph, label) { return '<input id="' + id + '" placeholder="' + h(ph) + '" aria-label="' + h(label || ph) + '">'; }

  /* ------------------------------------------------------------ shared blocks */
  function suggestionsBlock(sg) {
    sg = O(sg);
    var items = A(sg.items);
    var out = items.length ? items.map(function (s) {
      return '<div class="li"><span>' + h(s.text) + '</span><span class="row">' + (s.command ? btn('Do it', 'suggestion_accept', { id: s.id }) : '') + btn('Snooze', 'suggestion_snooze', { id: s.id, hours: 24 }, 'g') + btn('Dismiss', 'suggestion_dismiss', { id: s.id }, 'g') + '</span></div>';
    }).join('') : '<p class="note">Nothing needs your attention right now.</p>';
    out += '<div class="row">' + btn('Check again', 'suggestion_refresh', {}, 'g') + '<label class="tgl"><input type="checkbox" data-sugg-toggle ' + (sg.enabled ? 'checked' : '') + '> Allow suggestions</label></div>' +
      '<p class="note">Shown today ' + h(sg.shown_today || 0) + ' of ' + h(sg.max_per_day || 0) + (sg.quiet_now ? ' · quiet hours now' : '') + '. Suggestions are only shown; FRIDAY never runs one without you.</p>';
    return grp('Suggestions', out);
  }
  function missionList(jobs) {
    jobs = A(jobs);
    return jobs.length ? jobs.map(function (j) {
      var steps = A(j.steps).map(function (s) { return '<div class="' + (s.status === 'done' ? 'ok' : (s.status === 'failed' || s.status === 'skipped' ? 'bad' : '')) + '">' + (s.status === 'done' ? '✔' : s.status === 'failed' ? '✘' : '·') + ' ' + h(s.desc) + ' <span class="note">(' + h(s.tool) + ')</span></div>'; }).join('');
      return '<div class="sg"><b>' + h(String(j.jid || '').split('-').pop()) + '</b> ' + h(j.goal) + ' ' + stat(j.state) + (j.auto ? ' ' + chip('auto') : '') + ' <span class="note">' + h(j.created) + (j.revisions ? ' · revised ' + j.revisions + '×' : '') + '</span>' +
        ' ' + (/^(paused|failed|partial)$/.test(j.state) ? btn('Resume', 'mission_resume', { jid: j.jid }) : '') + (/^(queued|planning|running|waiting_approval|verifying)$/.test(j.state) ? btn('Cancel', 'mission_cancel', { jid: j.jid }, 'g') : '') +
        '<div class="steps6">' + steps + '</div>' + (j.report ? '<details><summary>Report</summary><pre class="term6">' + h(j.report) + '</pre></details>' : '') + '</div>';
    }).join('') : '<p class="note">No missions yet. Describe a goal above, or just ask FRIDAY for something with several steps.</p>';
  }
  function approvalBlock(st) {
    var a = O(st).awaiting;
    return a ? '<div class="tip"><b>Approval needed</b> - ' + h(a.question || a.desc) + '<div class="row">' + btn('Approve', 'mission_approve', { value: true }) + btn('Decline', 'mission_approve', { value: false }, 'g') + '</div></div>' : '';
  }

  /* ------------------------------------------------------------ tab renderers */
  var R = {};
  R.Overview = function (d) {
    var hl = O(d.health), res = O(hl.resources), rt = O(d.runtime), pol = O(d.policy), g = O(d.graph), st = O(d.status), bt = O(d.boot);
    var lm = O(hl.light_mode);
    var out = approvalBlock(st);
    if (bt.paused) out += '<div class="tip"><b>' + bt.paused + ' mission(s) were interrupted</b> when FRIDAY last closed. ' + btn('Resume the last one', 'mission_resume', {}) + '</div>';
    out += '<div class="grid6">';
    out += grp('FRIDAY ' + h(d.version || '7.0'), '<p>Overall health: ' + stat(hl.overall || '-') + ' · conversation: <b>' + h(rt.state || '-') + '</b> (' + h(rt.why || '') + ')</p>' +
      '<p>Autonomy: <b>' + h(String(pol.autonomy || '').replace('_', ' ')) + '</b> · tools ready: <b>' + h(st.tools || 0) + '</b> · light mode: ' + (lm.on ? '<span class="bad">on</span> (' + h(lm.reason) + ')' : '<span class="ok">off</span>') + '</p>' +
      bar('CPU', res.cpu, 85) + bar('RAM', res.ram, 85) + bar('Disk', res.disk, 92), 'Light mode switches heavy extras off automatically when the laptop is under load, and back on when it recovers.');
    out += grp('Missions', (A(st.running).length ? '<p>Running: ' + h(A(st.running).join(', ')) + '</p>' : '<p class="note">None running.</p>') +
      A(st.recent).map(function (j) { return '<div class="li"><span>' + h(j.goal) + '</span>' + stat(j.state) + '</div>'; }).join('') +
      '<div class="row">' + input('f7goal', 'Describe a goal with several steps...', 'Mission goal') + '<button class="btn" id="f7go">Start mission</button></div>');
    out += suggestionsBlock(d.suggestions);
    out += grp('Upcoming deadlines', A(g.deadlines).length ? A(g.deadlines).map(function (x) { return '<div class="li"><span>' + h(x.label) + '</span><span class="' + (x.overdue ? 'bad' : 'note') + '">' + (x.overdue ? 'overdue' : h(x.due)) + '</span></div>'; }).join('') : '<p class="note">No open deadlines.</p>');
    out += grp('Needs attention', A(hl.incidents_open).map(function (i) { return '<div class="li"><span>' + h(i.component) + ': ' + h(i.text) + '</span><span class="note">' + h(i.when) + '</span></div>'; }).join('') + list(hl.recommendations));
    return out + '</div>';
  };

  R.Missions = function (d) {
    var out = approvalBlock(d.status);
    out += grp('Give FRIDAY a mission', '<div class="row">' + input('f7goal', 'e.g. research the cheapest laptop stands, cost them, and save a report', 'Mission goal') + '<button class="btn" id="f7go">Start mission</button>' + btn('Resume last', 'mission_resume', {}, 'g') + btn('Cancel running', 'mission_cancel', {}, 'g') + '</div>',
      'FRIDAY plans the steps, checks each one independently (file exists, app really opened, numbers recomputed), revises the plan if a step fails, and reports only what was confirmed.');
    out += grp('Missions', missionList(d.jobs));
    out += grp('Receipts (what was actually checked)', tbl(['When', 'Tool', 'Result', 'Checks', 'ms', 'Claim'], A(d.receipts).slice(0, 15).map(function (r) {
      return row([h(r.when), h(r.tool), stat(r.status), A(r.evidence).length ? h(A(r.evidence).map(function (e) { return typeof e === 'string' ? e : (e.ok === false ? '✘ ' : '✔ ') + (e.name || e.check || e.what || ''); }).join('; ').slice(0, 90)) : '<span class="note">-</span>', h(r.ms), h(String(r.claim || r.error || '').slice(0, 80))]);
    })), 'Success ' + Math.round(100 * (O(d.stats).success_rate || 0)) + '% · independently verified ' + Math.round(100 * (O(d.stats).verified_rate || 0)) + '% of ' + (O(d.stats).total || 0) + ' recorded step(s).');
    out += grp('Specialist team', tbl(['Agent', 'Role', 'Tools'], A(O(d.team).agents).map(function (a) { return row([h(a.name), h(a.role), h(A(a.tools).join(', '))]); })), 'Say "use the team to ..." to have several specialists work a task; each only gets the tools its role needs.');
    out += grp('Code repairs', tbl(['#', 'Title', 'File', 'Status', 'When', ''], A(d.repairs).map(function (r) {
      return row([r.rid, h(r.title), h(r.path), stat(r.status), h(r.when), (r.status === 'proposed' || r.status === 'tested' ? btn('Test', 'repair_test', { rid: r.rid }, 'g') : '') + (r.status === 'tested' ? btn('Apply', 'repair_apply', { rid: r.rid, approved: true }) : '') + (r.status === 'applied' ? btn('Roll back', 'repair_rollback', { rid: r.rid }, 'g') : '')]);
    })), 'A repair is proposed, tested on a copy, applied only with your approval, and rolled back automatically if it breaks anything.');
    out += grp('Tools FRIDAY can use', tbl(['Tool', 'Risk', 'Agent', 'Timeout', 'What it does'], A(d.tools).map(function (t) { return row([h(t.name), '<span class="' + (t.risk === 'irreversible' ? 'bad' : t.risk === 'sensitive' ? 'note' : 'ok') + '">' + h(t.risk) + '</span>', h(t.agent || ''), h(t.timeout) + 's', h(t.desc)]); })));
    return out;
  };

  R.Goals = function (d) {
    var g = O(d.graph), nodes = A(g.nodes), byId = {};
    nodes.forEach(function (n) { byId[n.id] = n; });
    var out = grp('New objective', '<div class="row">' + input('f7otitle', 'Objective, e.g. Launch the Atlas website', 'Objective title') + '</div><textarea id="f7oms" rows="3" placeholder="Milestones, one per line" aria-label="Milestones"></textarea><div class="row"><button class="btn" id="f7ocreate">Create objective</button></div>',
      'Long-term goals are broken into milestones. A milestone only counts as done when its mission was verified, or when you say so.');
    out += grp('Objectives', A(d.objectives).length ? A(d.objectives).map(function (o) {
      return '<div class="sg"><b>' + h(o.title) + '</b> ' + stat(o.status) + ' <span class="note">' + o.progress + '% · due ' + h(o.due || 'no date') + '</span>' + bar('Progress', o.progress, 0) +
        A(o.milestones).map(function (m) { return '<div class="li"><span class="' + (m.status === 'done' ? 'ok' : '') + '">' + (m.status === 'done' ? '✔' : m.status === 'doing' ? '▶' : '○') + ' ' + m.idx + '. ' + h(m.text) + (m.evidence ? ' <span class="note">- ' + h(m.evidence) + '</span>' : '') + '</span>' + (m.status !== 'done' && m.status !== 'skipped' ? btn('Mark done', 'milestone_done', { oid: o.oid, idx: m.idx }, 'g') : '') + '</div>'; }).join('') +
        (A(o.blockers).length ? '<p class="bad">Blocked: ' + h(A(o.blockers).join('; ')) + '</p>' : '') +
        '<div class="row">' + btn('Do the next milestone', 'objective_run', { oid: o.oid }) + (A(o.blockers).length ? btn('Clear blockers', 'objective_unblock', { oid: o.oid }, 'g') : '') + '</div></div>';
    }).join('') : '<p class="note">No objectives yet.</p>');
    out += suggestionsBlock(d.suggestions);
    var counts = O(g.counts), kinds = ['project', 'objective', 'milestone', 'mission', 'document', 'person', 'decision', 'deadline', 'outcome', 'research'];
    out += grp('Context graph', '<p>' + kinds.filter(function (k) { return counts[k]; }).map(function (k) { return chip(counts[k] + ' ' + k + (counts[k] > 1 ? 's' : '')); }).join(' ') + ' ' + chip((counts.edges || 0) + ' connections') + '</p>' +
      '<div class="row">' + btn('Rebuild graph', 'command', { text: 'show the context graph' }, 'g') + '</div>' +
      (A(g.deadlines).length ? '<h5>Deadlines</h5>' + A(g.deadlines).map(function (x) { return '<div class="li"><span>' + h(x.label) + '</span><span class="' + (x.overdue ? 'bad' : 'note') + '">' + (x.overdue ? 'overdue' : h(x.due)) + '</span></div>'; }).join('') : '') +
      '<h5>Connections</h5>' + (A(g.edges).length ? '<ul>' + A(g.edges).slice(0, 40).map(function (e) { var a = byId[e.a], b = byId[e.b]; return '<li>' + h(a ? a.label : e.a) + ' <i>' + h(String(e.rel).replace(/_/g, ' ')) + '</i> ' + h(b ? b.label : e.b) + '</li>'; }).join('') + '</ul>' : '<p class="note">Nothing linked yet.</p>') +
      '<p class="note">Everything here is derived from your objectives, missions, reports, notes and decisions, with its source and age. Ask "what is connected to <name>" or "why do we have <thing>" in chat.</p>');
    return out;
  };

  R.Memory = function (d) {
    var m = O(d.memory), l = O(d.learning), cn = O(m.counts);
    var out = grp('Memory browser', '<div class="row">' + input('f7mq', 'Search by meaning, e.g. what did we decide about hosting', 'Search memory') + '<button class="btn" id="f7ms">Search</button></div><p>' + Object.keys(cn).map(function (k) { return chip(cn[k] + ' ' + k); }).join(' ') + '</p>' +
      tbl(['When', 'Kind', 'Memory', 'Source', 'Conf.', ''], A(m.items).map(function (x) { return row([h(x.ago || x.when), h(x.kind), h(x.text), h(x.source), Math.round((x.confidence || 0) * 100) + '%', btn('Forget', 'memory_forget', { id: x.id }, 'g')]); })),
      'Each memory shows how old it is and where it came from. Newer facts replace older ones; corrections keep a history.');
    out += grp('Your preferences', list(A(m.preferences).map(function (p) { return p.text; })) + '<div class="row">' + input('f7pref', 'e.g. I prefer short answers', 'New preference') + '<button class="btn" id="f7padd">Save</button></div>');
    out += grp('Sessions', list(A(m.episodes).map(function (e) { return e.when + ' - ' + e.summary; })));
    out += grp('Projects', list(A(m.projects).map(function (p) { return typeof p === 'string' ? p : (p.project || p.name || JSON.stringify(p)); })));
    out += grp('What FRIDAY has learned', tbl(['', 'Lesson', 'Evidence', 'Status', ''], A(l.lessons).map(function (x) {
      return row([h(x.kind), h(x.text), h(x.evidence), stat(x.status), (x.status === 'proposed' ? btn('Apply', 'lesson_apply', { id: x.id }) : '') + (x.status === 'applied' ? btn('Undo', 'lesson_undo', { id: x.id }, 'g') : '')]);
    })), 'A lesson is only a proposal until you apply it, and every applied lesson can be undone.');
    out += grp('Approved examples', tbl(['Goal', 'Approved', 'Verified', 'Used', 'When'], A(l.examples).map(function (x) { return row([h(x.goal), x.approved ? '✔' : '', Math.round((x.ratio || 0) * 100) + '%', h(x.uses), h(x.when)]); })));
    out += grp('Recent signals', tbl(['When', 'Kind', 'Goal', 'Detail'], A(l.feedback).map(function (x) { return row([h(x.when), h(x.kind), h(String(x.goal || '').slice(0, 60)), h(String(x.detail || '').slice(0, 80))]); })));
    return out;
  };

  R.Evidence = function (d) {
    var ev = O(d.evidence), sy = O(d.synthesis), mm = O(d.multimodal), r = S.result.evidence;
    var out = grp('Investigate a question', '<div class="row">' + input('f7inv', 'e.g. is a gas stove cheaper to run than an induction hob', 'Question to investigate') + '<button class="btn" id="f7invgo">Investigate</button></div>',
      'FRIDAY gathers sources, extracts claims, cross-checks them, and tells you how confident she is and where sources disagree. The answer comes in the conversation.');
    out += grp('Investigations', tbl(['#', 'Question', 'Confidence', 'When'], A(ev.investigations).map(function (x) { return row([x.id, h(x.question), stat(x.confidence), h(x.when)]); })));
    out += grp('Reports', tbl(['Topic', 'Sources', 'When', ''], A(sy.reports).map(function (x) { return row([h(x.topic), h(x.evidence), h(x.when), '<button class="btn g" data-open="' + h(x.path) + '">Open</button><button class="btn g" data-say="what supports ' + h(x.topic) + '">Evidence</button>']); })), 'Reports carry an evidence index: which source supports which claim, and its link.');
    out += grp('Screen and camera captures', tbl(['#', 'Kind', 'Window', 'Verified', 'When'], A(mm.captures).map(function (x) { return row([x.id, h(x.kind), h(x.window), x.verified ? '<span class="ok">✔</span>' : '<span class="note">no</span>', h(x.when)]); })), 'A capture is "verified" when the saved image really exists and is not blank.');
    return out;
  };

  R.Security = function (d) {
    var sec = O(d.security), pol = O(d.policy), bk = O(sec.backups), pv = O(sec.privileges);
    var out = grp('Security and recovery', '<div class="row">' + cbtn('Full security check', 'security status') + cbtn('Scan for leaked keys', 'scan for secrets', 'g') + cbtn('Check integrity', 'check integrity', 'g') + cbtn('Verify backups', 'verify my backups', 'g') + cbtn('Back up and verify', 'back up and verify', 'g') + cbtn('Recovery status', 'recovery status', 'g') + '</div>' +
      '<p>Backups: <b>' + h(bk.count || 0) + '</b>' + (bk.newest ? ' · newest ' + h(bk.newest) + ' (' + h(bk.age_days) + ' d old) · ' + (bk.valid ? '<span class="ok">valid</span>' : '<span class="bad">check failed</span>') : ' · none yet') + '</p>');
    out += grp('How much FRIDAY may do on her own', '<div class="row"><label for="f7auto">Autonomy</label><select id="f7auto"><option value="ask_more">Ask me more</option><option value="balanced">Balanced</option><option value="independent">Independent</option></select></div>' +
      '<p class="note">Whatever the level, irreversible actions (deleting, sending, buying, changing her own code) always need your OK, and she only uses permissions you have granted.</p>' +
      '<p>Last 7 days: allowed ' + h(O(pol.last_7_days).allow || 0) + ' · asked ' + h(O(pol.last_7_days).ask || 0) + ' · refused ' + h(O(pol.last_7_days).deny || 0) + '</p>');
    out += grp('Your rules', tbl(['Tool', 'Rule', 'Note', ''], A(d.rules).map(function (r) { return row([h(r.tool), h(r.mode), h(r.note), btn('Clear', 'rule_clear', { tool: r.tool }, 'g')]); })) +
      '<div class="row"><select id="f7rtool" aria-label="Tool">' + ['write_file', 'save_report', 'delete_file', 'send_message', 'purchase', 'run_python', 'capture_verify', 'file_op', 'apply_patch'].map(function (t) { return '<option>' + t + '</option>'; }).join('') + '</select><select id="f7rmode" aria-label="Rule"><option value="ask">always ask me</option><option value="never">never do</option><option value="allow">allow without asking</option></select><button class="btn" id="f7radd">Add rule</button></div>');
    out += grp('Permissions', tbl(['Permission', 'Risk', 'Allowed'], A(pv.permissions).map(function (p) { return row([h(String(p.tool).replace(/_/g, ' ')), '<span class="' + (p.risk === 'safe' ? 'ok' : 'note') + '">' + h(p.risk) + '</span>', p.allowed ? '<span class="ok">yes</span>' : '<span class="note">no</span>']); })) +
      (A(pv.flags).length ? '<h5>Worth a look</h5>' + list(pv.flags) : '') + '<p class="note">Change individual permissions in Command Centre → Security.</p>');
    out += grp('Recent decisions', tbl(['When', 'Tool', 'Risk', 'Decision', 'Why'], A(d.decisions).map(function (x) { return row([h(x.when), h(x.tool), h(x.risk), stat(x.decision), h(x.reason)]); })));
    out += grp('Consequential actions (24 h)', tbl(['When', 'Action', 'Detail', 'Result'], A(sec.consequential).map(function (x) { return row([h(x.when), h(x.action), h(String(x.detail || '').slice(0, 90)), h(x.result)]); })), 'Signed audit chain: each entry includes the previous one, so tampering shows.');
    return out;
  };

  R.Health = function (d) {
    var hl = O(d.health), res = O(hl.resources), rt = O(d.runtime), st = O(d.stream), comp = O(hl.components), met = O(hl.metrics), lm = O(hl.light_mode);
    var out = '<div class="grid6">' + grp('Right now', '<p>Overall: ' + stat(hl.overall) + ' · up ' + h(Math.round(hl.uptime_min || 0)) + ' min · session ' + h(hl.session) + '</p>' + bar('CPU', res.cpu, 85) + bar('RAM', res.ram, 85) + bar('Disk', res.disk, 92) +
      '<p class="note">FRIDAY itself uses ' + h(Math.round(res.process_mb || 0)) + ' MB of ' + h(res.ram_total_gb || '-') + ' GB · ' + h(res.cores || '-') + ' cores' + (res.battery != null ? ' · battery ' + h(res.battery) + '%' : '') + '</p>' +
      '<p>Light mode: ' + (lm.on ? '<span class="bad">on</span> - ' + h(lm.reason) : '<span class="ok">off</span>') + '</p><div class="row">' + cbtn('Free up memory', 'free up memory') + cbtn('How healthy are you', 'system status', 'g') + '</div>');
    out += grp('Conversation engine', '<p>State <b>' + h(rt.state) + '</b> - ' + h(rt.why) + '</p><p class="note">Worker threads ' + h(rt.pool) + ' · cache ' + h(O(rt.cache).entries) + ' items (' + h(O(rt.cache).hits) + ' hits) · speculative warm-ups ' + h(rt.speculations) + ' · listener restarts in the last hour ' + h(rt.restarts_last_hour) + '</p>' +
      '<p class="note">Released when idle: ' + h(A(rt.unloaders).join(', ') || '-') + (O(rt.last_unload).freed_mb ? ' · last freed ' + h(Math.round(rt.last_unload.freed_mb)) + ' MB' : '') + '</p>' +
      (O(st).streams ? '<p class="note">Streamed replies ' + h(st.streams) + ' · first word after ' + h(st.avg_first_chunk_s) + ' s · first spoken sentence ' + h(st.avg_first_segment_s) + ' s</p>' : '')) + '</div>';
    out += grp('Components', tbl(['Component', 'Status', 'Detail', 'If it fails'], Object.keys(comp).map(function (k) { var c = O(comp[k]); return row([h(k) + (c.critical ? ' *' : ''), stat(c.status), h(c.detail), h(c.fallback || '')]); })), '* critical. Each component has a plain fallback so FRIDAY keeps working.');
    out += grp('Response times', tbl(['Measure', 'Samples', 'Average', 'p95', 'Slowest'], Object.keys(met).map(function (k) { var m = O(met[k]); return row([h(k.replace(/_/g, ' ')), h(m.n), m.avg == null ? '-' : h(Math.round(m.avg)), m.p95 == null ? '-' : h(Math.round(m.p95)), m.max == null ? '-' : h(Math.round(m.max))]); })));
    out += grp('Open issues', A(hl.incidents_open).map(function (i) { return '<div class="li"><span>' + h(i.component) + ' (' + h(i.level) + '): ' + h(i.text) + '</span><span class="note">' + h(i.when) + '</span></div>'; }).join('') || '<p class="note">No open issues.</p>');
    out += grp('Suggestions', list(hl.recommendations));
    out += grp('What works right now', '<div class="row">' + cbtn('Test all tools', 'test your tools') + cbtn('What is broken?', 'what is broken', 'g') + '</div>' +
      tbl(['Tool', 'Status', 'Why', 'Risk', 'Calls 24h', 'Success', 'Avg ms'], A(d.capabilities).map(function (c) { return row([h(c.tool), stat(c.status), h(c.reason), h(c.risk), h(c.calls_24h), c.success_rate == null ? '-' : Math.round(100 * c.success_rate) + '%', h(c.avg_ms)]); })), 'Status comes from real self-tests and real recent results, not from what a tool claims.');
    out += grp('Recent log', '<pre class="term6">' + h(A(hl.log).map(function (l) { return l.t + '  ' + l.kind + '  ' + (l.name || '') + '  ' + (l.status || '') + '  ' + (l.detail || ''); }).join('\n')) + '</pre>');
    return out;
  };

  R.Quality = function (d) {
    var rel = O(d.release), bn = O(d.benchmark), rt = O(d.router);
    var out = grp('Release check against the last known-good build', '<div class="row">' + cbtn('Run release check', 'run the release gate') + cbtn('Mark this build known-good', 'mark this build as known good', 'g') + cbtn('History', 'release status', 'g') + '</div>' +
      tbl(['When', 'Result', 'Problems', 'Seconds'], A(rel.ci).map(function (x) { return row([h(x.when), x.passed ? '<span class="ok">PASS</span>' : '<span class="bad">FAIL</span>', h(A(x.problems).join('; ')), h(x.seconds)]); })), 'Checks that nothing from the previous build was removed and that voice, listening and speech files are unchanged.');
    out += grp('Intelligence benchmark', '<div class="row">' + cbtn('Run benchmark', 'run the intelligence benchmark') + cbtn('Last results', 'benchmark history', 'g') + '</div>' + (bn.running ? '<p class="note">Running...</p>' : '') +
      tbl(['When', 'Passed', 'Total', 'Failed'], A(bn.runs).map(function (x) { return row([h(x.when), h(x.passed), h(x.total), x.failed ? '<span class="bad">' + h(x.failed) + '</span>' : '0']); })) + (A(bn.failing).length ? '<p class="bad">Failing: ' + h(A(bn.failing).join(', ')) + '</p>' : ''));
    out += grp('Improvement proposals', '<div class="row">' + cbtn('Look for recurring problems', 'what keeps failing') + cbtn('List proposals', 'list the improvements', 'g') + '</div>' +
      tbl(['#', 'Kind', 'Proposal', 'Status', ''], A(d.improvement && d.improvement.improvements).map(function (x) {
        return row([x.id, h(x.kind), h(x.title) + (x.why ? '<div class="note">' + h(x.why) + '</div>' : ''), stat(x.status), (x.status === 'proposed' ? cbtn('Apply', 'apply improvement ' + x.id) + cbtn('Reject', 'reject improvement ' + x.id, 'g') : '') + (x.status === 'applied' ? cbtn('Undo', 'undo improvement ' + x.id, 'g') : '')]);
      })), 'Proposals come from failures that repeated 3 or more times. Nothing changes without your approval, and applied changes can be undone.');
    out += grp('Model routing', tbl(['Route', 'Model', 'Calls', 'Avg ms', 'Success'], A(rt.routes).map(function (x) { return row([h(x.route), h(x.choice), h(x.calls), h(x.avg_ms), Math.round(100 * (x.success || 0)) + '%']); })), 'FRIDAY picks the lightest model that can do the job and learns from what worked.');
    return out;
  };

  R.Savings = function (d) {
    var r = S.result.savings;
    var out = grp('Price book', '<div class="row">' + input('f7pi', 'Item (rice)', 'Item') + input('f7pp', 'Price (60)', 'Price') + input('f7pq', 'Amount (1)', 'Amount') + input('f7pu', 'Unit (kg)', 'Unit') + input('f7ps', 'Store (optional)', 'Store') + '<button class="btn" id="f7price">Record price</button></div>' +
      tbl(['Item', 'Price', 'Per', 'Store', 'Kind', 'Recorded', ''], A(d.prices).map(function (p) { return row([h(p.item), h(p.currency) + ' ' + h(p.price), h(p.per), h(p.store), h(p.kind), h(p.when), btn('Delete', 'price_delete', { id: p.id }, 'g')]); })), 'Only prices you recorded are used, each with its date. FRIDAY never invents a price; estimates are marked as estimates.');
    out += grp('Cost a recipe or meal', '<textarea id="f7rtext" rows="4" placeholder="Paste a recipe or ingredient list, one per line (2 cups rice, 300 g chicken ...)" aria-label="Recipe text"></textarea><div class="row">' + input('f7rname', 'Name (optional)', 'Recipe name') + '<button class="btn" id="f7rcost">Cost it</button></div>' + (r ? '<pre class="term6">' + h(r) + '</pre>' : ''));
    out += grp('Saved recipes', list(A(d.recipes).map(function (x) { return x.name + ' (' + x.servings + ' servings)'; })));
    return out;
  };

  R.Settings = function (d) {
    var out = '', pol = O(d.policy);
    var rows = A(d.settings).map(function (s) {
      var opts = /^([a-z_]+(?: \| [a-z_]+)+)\b/.exec(s.help || ''), ctl;
      if (s.default === '0' || s.default === '1') ctl = '<input type="checkbox" data-set="' + h(s.key) + '" ' + (s.value === '1' ? 'checked' : '') + ' aria-label="' + h(s.key) + '">';
      else if (opts) ctl = '<select data-set="' + h(s.key) + '" aria-label="' + h(s.key) + '">' + opts[1].split(' | ').map(function (o) { return '<option' + (o === s.value ? ' selected' : '') + '>' + h(o) + '</option>'; }).join('') + '</select>';
      else ctl = '<input data-set="' + h(s.key) + '" value="' + h(s.value) + '" aria-label="' + h(s.key) + '">';
      return row([h(s.key.replace(/_/g, ' ')), ctl, '<span class="note">' + h(s.help) + (s.value !== s.default ? ' (default ' + h(s.default || 'empty') + ')' : '') + '</span>']);
    });
    out += grp('FRIDAY 7.0 settings', tbl(['Setting', 'Value', 'What it does'], rows), 'Changes apply immediately. Voice, microphone and speech settings stay in the main Settings page, untouched.');
    out += grp('Autonomy', '<p>Currently <b>' + h(String(pol.autonomy || 'balanced').replace('_', ' ')) + '</b>. Change it under Security.</p>');
    out += grp('Extra folders for file search', '<p class="note">To make "open <file name>" search more places, list one folder per line in <code>friday_data/file_roots.txt</code> next to the app.</p>');
    return out;
  };

  /* ------------------------------------------------------------ page */
  window.intel7V = function (e) {
    var d = S.data[S.tab.toLowerCase()];
    e.innerHTML = '<h2>FRIDAY 7.0 Intelligence</h2><div class="tabs6" role="tablist">' + TABS.map(function (t) { return '<button role="tab" aria-selected="' + (t === S.tab) + '" class="' + (t === S.tab ? 'on' : '') + '" data-tab="' + t + '">' + t + '</button>'; }).join('') + '</div>' +
      '<div id="f7body">' + (d ? (R[S.tab] ? safe(R[S.tab], d) : '') : '<p class="note">' + (B && B.v7 ? 'Loading…' : 'Open the desktop app to see live data.') + '</p>') + '</div>';
    e.querySelectorAll('[data-tab]').forEach(function (b) { b.onclick = function () { S.tab = b.dataset.tab; S.arg = ''; window.intel7V(e); ask(S.tab); }; });
    wire(e);
    if (!d) ask(S.tab);
    clearInterval(S.timer);
    if (S.tab === 'Overview' || S.tab === 'Missions' || S.tab === 'Health') S.timer = setInterval(function () { if (typeof V !== 'undefined' && V === 'Intel') ask(S.tab); else clearInterval(S.timer); }, 8000);
  };
  function safe(fn, d) { try { return fn(d); } catch (e) { console.warn('intel7 render', S.tab, e); return '<p class="note">This section could not be drawn: ' + h(e.message) + '</p>'; } }

  function wire(e) {
    var q = function (id) { return e.querySelector(id); };
    e.querySelectorAll('[data-a]').forEach(function (b) { b.onclick = function () { var x = {}; try { x = JSON.parse(b.dataset.x || '{}'); } catch (er) {} if (b.dataset.a === 'command') { say(x.text); return; } act(b.dataset.a, x); }; });
    e.querySelectorAll('[data-say]').forEach(function (b) { b.onclick = function () { say(b.dataset.say); }; });
    e.querySelectorAll('[data-open]').forEach(function (b) { b.onclick = function () { if (B && B.openPath) B.openPath(b.dataset.open); }; });
    e.querySelectorAll('[data-set]').forEach(function (c) {
      c.onchange = function () { var v = c.type === 'checkbox' ? (c.checked ? '1' : '0') : c.value; act('setting_set', { key: c.dataset.set, value: v }); };
    });
    var tg = e.querySelector('[data-sugg-toggle]'); if (tg) tg.onchange = function () { act('suggestion_toggle', { enabled: tg.checked }); };
    if (q('#f7go')) q('#f7go').onclick = function () { var g = q('#f7goal').value.trim(); if (g) { act('mission_submit', { goal: g }); q('#f7goal').value = ''; } };
    if (q('#f7goal')) q('#f7goal').onkeydown = function (ev) { if (ev.key === 'Enter') q('#f7go').click(); };
    if (q('#f7ocreate')) q('#f7ocreate').onclick = function () { var t = q('#f7otitle').value.trim(); if (!t) { toastx('Give the objective a title first.'); return; } act('objective_create', { title: t, milestones: q('#f7oms').value }); q('#f7otitle').value = ''; q('#f7oms').value = ''; };
    if (q('#f7ms')) q('#f7ms').onclick = function () { S.arg = q('#f7mq').value; ask('Memory', S.arg); };
    if (q('#f7mq')) { q('#f7mq').value = S.arg; q('#f7mq').onkeydown = function (ev) { if (ev.key === 'Enter') q('#f7ms').click(); }; }
    if (q('#f7padd')) q('#f7padd').onclick = function () { var t = q('#f7pref').value.trim(); if (t) { act('preference_add', { text: t }); q('#f7pref').value = ''; } };
    if (q('#f7invgo')) q('#f7invgo').onclick = function () { var t = q('#f7inv').value.trim(); if (t) { say('investigate ' + t); q('#f7inv').value = ''; } };
    if (q('#f7auto')) { q('#f7auto').value = String((O(S.data.security).policy || {}).autonomy || 'balanced'); q('#f7auto').onchange = function () { act('autonomy_set', { level: this.value }); }; }
    if (q('#f7radd')) q('#f7radd').onclick = function () { act('rule_set', { tool: q('#f7rtool').value, mode: q('#f7rmode').value }); };
    if (q('#f7price')) q('#f7price').onclick = function () {
      var it = q('#f7pi').value.trim(), pr = q('#f7pp').value.trim();
      if (!it || !pr) { toastx('Enter the item and its price.'); return; }
      act('price_add', { item: it, price: pr, qty: q('#f7pq').value.trim() || '1', unit: q('#f7pu').value.trim() || 'each', store: q('#f7ps').value.trim() });
    };
    if (q('#f7rcost')) q('#f7rcost').onclick = function () { var t = q('#f7rtext').value.trim(); if (!t) { toastx('Paste a recipe or ingredient list first.'); return; } act('cost_recipe', { text: t, name: q('#f7rname').value.trim() }); };
  }

  /* ------------------------------------------------------------ channel */
  function onLine(l) {
    if (typeof l !== 'string' || l.indexOf('FRIDAY_V7::') !== 0) return;
    var m; try { m = JSON.parse(dec(l.slice(11))); } catch (e) { return; }
    var k = m.kind || '', dt = m.data || {};
    var here = typeof V !== 'undefined' && V === 'Intel';
    if (k.indexOf('snapshot:') === 0) {
      S.data[k.slice(9)] = dt;
      if (here && k.slice(9) === S.tab.toLowerCase()) { var ae = document.activeElement; if (!(ae && $('#view').contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName))) window.intel7V($('#view')); }
    }
    else if (k === 'toast') toastx(dt.text);
    else if (k === 'result') { S.result[dt.action === 'cost_recipe' ? 'savings' : 'evidence'] = dt.output; if (here) window.intel7V($('#view')); }
    else if (k === 'context_graph') { S.data.goals = Object.assign({}, S.data.goals || {}, { graph: dt }); if (here && S.tab === 'Goals') window.intel7V($('#view')); }
    else if (k === 'suggestion') { toastx('Suggestion: ' + dt.text + ' (say "any suggestions")'); if (here) ask(S.tab); }
    else if (k === 'event') {
      var n = dt.name || '', d2 = dt.data || {};
      if (n === 'job.done') toastx('Mission ' + (/^done$/.test(d2.state) ? 'finished' : 'ended (' + d2.state + ')') + ': ' + String(d2.goal || '').slice(0, 70));
      else if (n === 'light_mode') toastx(d2.on ? 'Light mode on: ' + (d2.reason || 'the laptop is busy') : 'Light mode off: back to full features');
      else if (n === 'lesson.proposed') toastx('FRIDAY has a new lesson to review (Intelligence → Memory)');
      else if (n === 'improvement.found') toastx('FRIDAY found improvement ideas (Intelligence → Quality)');
      else if (n === 'repair.proposed') toastx('A code repair was proposed (Intelligence → Missions)');
      if (here && /^(job\.|light_mode|incident|objective|report|price|improvement|repair|lesson|benchmark|investigation)/.test(n)) ask(S.tab);
    }
  }
  function init() {
    if (B && B.onLine) B.onLine(onLine);
    var css = document.createElement('style');
    css.textContent = '#f7body .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0}#f7body .row input,#f7body textarea{flex:1;min-width:140px}#f7body textarea{width:100%;box-sizing:border-box}#f7body table{width:100%}#f7body td,#f7body th{vertical-align:top}' +
      '#f7body .chip{display:inline-block;padding:2px 9px;border-radius:999px;border:1px solid var(--k3);background:var(--p2);font-size:12px;margin:2px 3px 2px 0}#f7body details summary{cursor:pointer;color:var(--m)}#f7body h5{margin:10px 0 4px;color:var(--m);font-weight:600}' +
      '#f7body .tip{border:1px solid var(--a);border-radius:var(--r3);padding:10px;margin:8px 0}#f7body .li{display:flex;justify-content:space-between;gap:10px;align-items:center;margin:4px 0}';
    document.head.appendChild(css);
    if (B && B.onBackendReady) B.onBackendReady(function () { setTimeout(function () { ask('Overview'); }, 4000); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
