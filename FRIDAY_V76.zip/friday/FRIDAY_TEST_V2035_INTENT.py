import ast, pathlib
root=pathlib.Path(__file__).parent
errors=[]
for p in root.glob("*.py"):
    try: ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
    except Exception as e: errors.append((p.name,str(e)))
assert not errors, errors
from friday_intent_engine import parse_browser_intent
assert parse_browser_intent("open Google and type hi in the search bar").payload == "hi"
assert parse_browser_intent("open Google and type type hi in the search bar").payload == "hi"
assert parse_browser_intent("go to Google and search for Python") .payload == "Python"
print("FRIDAY V2035 semantic intent audit: PASS")
