"""
FRIDAY FINANCE ENGINE
---------------------
Small deterministic money layer used before the general FRIDAY routing stack.
It is one of FRIDAY's many abilities: budgeting, savings goals, meal/grocery
planning, savings goals, and exact arithmetic. It never asks Gemini to do
financial arithmetic.

State is stored in friday_data/finance.json. The existing FRIDAY UI can sync
its local finance state into this file; voice commands update it directly.

Voice, typed and widget commands ALL arrive here through the backend's single
process_command() pipeline (same as JARVIS). Whenever a command changes the
data, the new state is pushed to the UI with a FINANCE_STATE:: line so the
screen always matches what FRIDAY just said.

Food planning only estimates QUANTITIES of ingredients. FRIDAY never estimates
grocery cost; the user records their own grocery budget in the monthly plan.
"""
from __future__ import annotations
import base64, json, os, re, math, threading, datetime
from pathlib import Path

BASE = Path(__file__).parent
DATA = BASE / "friday_data"
DATA.mkdir(parents=True, exist_ok=True)
FILE = DATA / "finance.json"
LOCK = threading.RLock()

DEFAULT = {
    "cur": "Rs",
    "income": [],
    "expense": [],
    "monthly": [],
    "goals": [],
    "foods": [],
    "snacks": [],
    "plan": {},
    "bev": {},
    "w": {"t": 28, "c": "Partly Cloudy", "p": "Sri Lanka"},
}

def _load():
    try:
        raw=json.loads(FILE.read_text(encoding="utf-8"))
        if isinstance(raw,dict):
            d=DEFAULT.copy()
            d.update(raw)
            return d
    except Exception:
        pass
    return json.loads(json.dumps(DEFAULT))

STATE=_load()

def save():
    with LOCK:
        tmp=FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(STATE,ensure_ascii=False,indent=2),encoding="utf-8")
        os.replace(tmp,FILE)

def sync(snapshot):
    if not isinstance(snapshot,dict): return
    with LOCK:
        for k in DEFAULT:
            if k in snapshot:
                STATE[k]=snapshot[k]
        save()

def _push():
    """Tell the UI the finance data changed (it never writes back, so no loops)."""
    try:
        blob=base64.b64encode(json.dumps(STATE,ensure_ascii=False).encode("utf-8")).decode("ascii")
        print("FINANCE_STATE::"+blob, flush=True)
    except Exception:
        pass

def _ui(view):
    try:
        print("FRIDAY_UI::VIEW::"+view, flush=True)
    except Exception:
        pass

_MULT={"k":1e3,"lakh":1e5,"lakhs":1e5,"m":1e6,"million":1e6}

def _amount(x):
    """'250000', '250,000', 'rs 250k', '2 lakh' -> float, else None."""
    s=str(x).lower().strip()
    s=re.sub(r"^(?:rs\.?|lkr|\$)\s*","",s)
    s=s.replace(",","").replace(" ","")
    m=re.match(r"^(-?\d+(?:\.\d+)?)(k|lakhs?|m|million)?$",s)
    if not m: return None
    return float(m.group(1))*_MULT.get(m.group(2) or "",1)

def _total(key):
    return round(sum(float(x.get("a",0)) for x in STATE.get(key,[]) if isinstance(x,dict)),2)

def totals():
    inc=_total("income"); exp=_total("expense"); plan=_total("monthly"); goals=_total("goals")
    surplus=round(inc-exp-plan,2)
    return {"income":inc,"expenses":exp,"planned":plan,"goals":goals,"surplus":surplus,
            "savings_rate": round(surplus/inc*100,1) if inc else None}


def advice():
    """Deterministic, personalized money-maintenance advice from recorded data."""
    t=totals(); cur=STATE.get("cur","Rs"); tips=[]
    inc=t["income"]; exp=t["expenses"]; plan=t["planned"]; surplus=t["surplus"]
    if not inc:
        return ["Record your regular income so I can calculate affordability and savings targets."]
    if surplus < 0:
        tips.append(f"Your recorded commitments exceed income by {cur} {abs(surplus):,.2f} per month. Start by reviewing the largest recurring expense or planned item.")
    elif t["savings_rate"] is not None and t["savings_rate"] < 10:
        tips.append(f"Your recorded surplus is {t['savings_rate']}% of income. A first target could be to protect a small fixed amount from each income payment before discretionary spending.")
    elif t["savings_rate"] is not None and t["savings_rate"] < 20:
        tips.append(f"Your recorded savings rate is {t['savings_rate']}%. If practical, compare your recurring categories and gradually move the rate upward rather than cutting essentials blindly.")
    else:
        tips.append(f"Your recorded surplus is {cur} {surplus:,.2f} per month. Keep a fixed savings transfer and treat the remainder as the flexible amount.")
    rows=sorted([(float(x.get("a",0)),str(x.get("n",""))) for x in STATE.get("expense",[]) if isinstance(x,dict)], reverse=True)
    if rows:
        a,n=rows[0]
        if inc and a/inc>=.25: tips.append(f"{n} is your largest recorded expense at {cur} {a:,.2f}; because it is a large share of income, review whether any part is reducible or negotiable.")
        elif a>0: tips.append(f"Your largest recorded expense is {n} at {cur} {a:,.2f}. Tracking it consistently will make future recommendations more reliable.")
    if t["goals"] and surplus>0:
        months=math.ceil(t["goals"]/surplus)
        tips.append(f"At the current recorded surplus, your listed goals total {cur} {t['goals']:,.2f} and would take about {months} month(s), assuming income and spending stay similar.")
    if exp+plan>0:
        buffer=exp+plan
        tips.append(f"A useful safety benchmark is several months of essential spending; your current recorded monthly commitments are about {cur} {buffer:,.2f}.")
    return tips[:5]

def report():
    t=totals()
    lines=[
        f"Currency: {STATE.get('cur','Rs')}",
        f"Monthly income: {t['income']}",
        f"Monthly expenses: {t['expenses']}",
        f"Planned monthly spending: {t['planned']}",
        f"Monthly surplus available for saving: {t['surplus']}",
        f"Savings goals total: {t['goals']}",
    ]
    if t["savings_rate"] is not None: lines.append(f"Savings rate: {t['savings_rate']} percent")
    if t["surplus"]>0 and t["goals"]>0:
        lines.append(f"Estimated months to reach all recorded goals at the current surplus: {math.ceil(t['goals']/t['surplus'])}")
    lines.append("Advice:")
    lines.extend("• "+x for x in advice())
    return "\n".join(lines)

_PAIR_SPLIT=re.compile(r"[;\n]|,(?=\s*[A-Za-z])")
_PAIR=re.compile(r"^(.+?)\s*(?:[:=]|\bat\b)?\s*((?:rs\.?|lkr|\$)?\s*-?[\d,.]+\s*(?:k|lakhs?|m|million)?)\s*$",re.I)

def _parse_pairs(text):
    """'salary 250000, other 20k' -> [(name, amount), ...]; None when any part is unreadable."""
    text=re.sub(r"^(?:add|record|log)\s+","",str(text),flags=re.I).strip()
    out=[]
    for part in _PAIR_SPLIT.split(text):
        part=part.strip()
        if not part: continue
        m=_PAIR.match(part)
        if not m: return None
        name=m.group(1).strip(" -:"); amt=_amount(m.group(2))
        if not name or amt is None: return None
        out.append((name,amt))
    return out or None

_TITLE={"income":"Income","expense":"Expenses","monthly":"Monthly plan","goals":"Savings goals"}

def _add(key, text):
    pairs=_parse_pairs(text)
    if not pairs: return "I couldn't read that. Say a name followed by an amount, like rent 50000."
    with LOCK:
        for name,amount in pairs:
            STATE.setdefault(key,[]).append({"n":name,"a":round(amount,2)})
        save()
    _push()
    cur=STATE.get("cur","Rs"); tot=_total(key)
    if len(pairs)==1:
        n,a=pairs[0]
        return f"Recorded {n} at {cur} {a:,.2f}. {_TITLE[key]} total is now {cur} {tot:,.2f}."
    return f"Recorded {len(pairs)} items. {_TITLE[key]} total is now {cur} {tot:,.2f}."

_DAYS=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]

def _parse_ingredients(text):
    parsed=[]; bad=[]
    for part in re.split(r"[;\n]|,(?=\s*[A-Za-z])", str(text)):
        part=part.strip()
        if not part: continue
        # An optional "@price" is still accepted so old entries keep working, but it is
        # ignored: FRIDAY only needs how much of each item is used, never what it costs.
        m=re.match(r"^(.+?)\s+(\d+(?:\.\d+)?)\s*(kg|g|ml|l|pcs|cups?|tbsp|tsp)?(?:\s*@\s*(?:rs\.?|lkr\s*)?\d+(?:\.\d+)?)?$",part,re.I)
        if not m: bad.append(part); continue
        q=float(m.group(2)); u=(m.group(3) or "pcs").lower()
        if u=="kg": q*=1000; u="g"
        elif u=="l": q*=1000; u="ml"
        elif u=="cups": u="cup"
        parsed.append({"n":m.group(1).strip(),"q":q,"u":u})
    return parsed,bad

def add_food_record(name, ingredient_text, meals=None):
    """Persist a food definition (name + ingredient quantities) in the shared finance state."""
    meals = meals or ["b","l","d"]
    parsed,bad=_parse_ingredients(ingredient_text)
    if not str(name).strip(): return "I need the food name, sir."
    if bad: return "I could not read these ingredients: " + ", ".join(bad)
    if not parsed: return "I could not read the ingredients, sir."
    with LOCK:
        fid=max([int(f.get("id",0)) for f in STATE.get("foods",[]) if isinstance(f,dict) and str(f.get("id","")).isdigit()] or [0])+1
        STATE.setdefault("foods",[]).append({"id":fid,"name":str(name).strip(),"meals":list(meals),"ing":parsed})
        save()
    _push()
    return f"Saved {name} with {len(parsed)} ingredients, sir."

def _day_in(l):
    names={"mon":"Mon","tue":"Tue","wed":"Wed","thu":"Thu","fri":"Fri","sat":"Sat","sun":"Sun"}
    m=re.search(r"\b(mon|tue|wed|thu|fri|sat|sun)(?:day|sday|nesday|rsday|urday)?\b",l)
    if m: return names[m.group(1)]
    return _DAYS[datetime.datetime.now().weekday()]

_NAV={"report":"Reports","reports":"Reports","plan":"Plans","plans":"Plans","meal plan":"Plans","meal plans":"Plans",
      "weekly plan":"Plans","weekly meal plan":"Plans","home":"Home","dashboard":"Home"}

def handle(command):
    """Return a deterministic finance response, or None when this isn't a finance command."""
    q=(command or "").strip()
    l=q.lower().strip(" .?!")
    if not q: return None

    # Screen navigation ("show reports", "open the meal plan", "go home")
    m=re.match(r"^(?:please\s+)?(?:show|open|go to|display|take me to|generate|make)\s+(?:me\s+)?(?:my\s+|the\s+|a\s+)?(reports?|plans?|meal plans?|weekly (?:meal )?plans?|home|dashboard)\s*(?:page|view|screen|tab)?$",l)
    if m:
        view=_NAV.get(re.sub(r"\s+"," ",m.group(1)).replace("weekly meal plan","weekly plan"),"Home")
        _ui(view)
        return f"Opening {view}."

    if re.search(r"\b(?:show|give|generate|open)\b.*\b(?:financial|finance|budget|money|saving|savings|expense|income)\b.*\b(?:report|summary|overview)\b",l) or l in {"budget report","money report","financial report"}:
        _ui("Reports")
        return report()

    # Income / expenses / monthly plan / goals (one or several "name amount" pairs)
    m=re.match(r"^(?:add\s+)?income\s+(.+)$",q,re.I)
    if m and re.search(r"\d",m.group(1)): return _add("income",m.group(1))
    m=re.match(r"^(?:add\s+)?(?:expense|expenses|spending)\s+(.+)$",q,re.I)
    if m and re.search(r"\d",m.group(1)): return _add("expense",m.group(1))
    m=re.match(r"^(?:add\s+)?(?:monthly plan|plan item|budget)\s+(.+)$",q,re.I)
    if m and re.search(r"\d",m.group(1)): return _add("monthly",m.group(1))
    m=re.match(r"^(?:add\s+)?(?:savings goal|saving goal|goals?|savings?)\s+(.+)$",q,re.I)
    if m and re.search(r"\d",m.group(1)): return _add("goals",m.group(1))

    # Drinks for a day: "coffee 2 tea 1 milk 200 monday"
    if re.search(r"\b(?:coffee|tea|milk)\s+\d",l):
        day=_day_in(l)
        with LOCK:
            b=STATE.setdefault("bev",{}).setdefault(day,{"coffee":0,"tea":0,"milk":0})
            for x in re.finditer(r"\b(coffee|tea|milk)\s+(\d+(?:\.\d+)?)",l):
                b[x.group(1)]=float(x.group(2))
            save()
        _push()
        return f"Saved drinks for {day}."

    if re.search(r"\b(?:how much|what)\b.*\b(?:left|surplus|save|savings)\b",l) or re.search(r"\b(?:left|surplus)\b.*\b(?:month|monthly)\b",l):
        t=totals()
        return f"You have {STATE.get('cur','Rs')} {t['surplus']:,.2f} left each month after recorded expenses and planned spending."

    if re.search(r"\b(?:savings rate|saving rate)\b",l):
        t=totals()
        return f"Your recorded savings rate is {t['savings_rate']} percent." if t["savings_rate"] is not None else "I need a recorded income amount before I can calculate a savings rate."

    if re.search(r"\b(?:can i afford|afford)\b",l):
        m=re.search(r"(?:afford|spend)\D+(\d+(?:,\d{3})*(?:\.\d+)?)",l)
        if m:
            amount=_amount(m.group(1)); t=totals()
            if amount is not None:
                return f"Your recorded monthly surplus is {STATE.get('cur','Rs')} {t['surplus']:,.2f}. A purchase of {STATE.get('cur','Rs')} {amount:,.2f} would leave {STATE.get('cur','Rs')} {t['surplus']-amount:,.2f} before any unrecorded costs."
        return "Tell me the amount you are considering, and I can compare it with your recorded monthly surplus."

    if re.search(r"\b(?:save money|saving money|reduce spending|cut spending|budget)\b",l):
        t=totals()
        return (f"Your recorded monthly surplus is {STATE.get('cur','Rs')} {t['surplus']:,.2f}. "
                "I can track income, expenses, planned spending and goals, then identify the largest recurring costs for you.")

    return None

def context():
    """Compact, exact figures for the general AI prompt."""
    t=totals()
    return (f"FRIDAY FINANCE DATA (deterministic; do not invent or recalculate): "
            f"income={t['income']}; expenses={t['expenses']}; planned={t['planned']}; "
            f"surplus={t['surplus']}; goals={t['goals']}; "
            f"savings_rate={t['savings_rate']}; currency={STATE.get('cur','Rs')}; "
            f"advice={advice()}.")
