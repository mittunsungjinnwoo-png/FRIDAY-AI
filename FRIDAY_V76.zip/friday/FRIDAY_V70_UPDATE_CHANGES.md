# FRIDAY 7.0 update — camera gate, faster replies, smarter answers

Nothing existing was removed or rewritten. New file: `friday_camera_gate.py`. Edited: `friday_backend.py` (small, marked "7.0 update").

## 1. Camera on / off never goes to Gemini
Any sentence containing the camera (camera / webcam / cam) and an on/off word is handled by the camera feature locally, first,
before every other router: "turn on the camera", "camera off", "can you switch my webcam off please", "I want the camera on",
"put the camera off", "switch the camera back on", "stop the camera", "is the camera on?" (answered from the real state).
Look / describe requests ("what do you see", "what's on my camera") keep their existing camera/vision routes.
A second safety net sits at the top of `ask_ai`, so no path can send such a sentence to Gemini.

## 2. Faster
* Fast-route replies now use Gemini's lowest thinking setting for short chat, so the first words arrive sooner.
* Deep-route questions stream in ONE call (no generate -> check -> correct round trips). Questions with numbers / calculations
  still go through the independent verifier, so maths stays checked.
* The first spoken piece now starts at the first comma (the old early-start rule could never trigger).
* A rejected thinking setting or model name is remembered and never costs a second round trip.

## 3. Smarter
* Harder questions (why / how / compare / should I / explain / code / plans, or 14+ words) use a stronger model
  (`gemini-3.8-flash`, override with `FRIDAY_SMART_MODEL`) with more thinking; simple chat stays on the fastest model.
* If the stronger model is not available to your key, FRIDAY falls back automatically to the old model.
* The voice prompt now asks for real-intent understanding, careful reasoning, honest uncertainty and sensible assumptions.

Tuning (optional env vars): `FRIDAY_SMART_MODEL`, `FRIDAY_DEEP_MODEL`, `FRIDAY_GEMINI_MODEL`.
