from __future__ import annotations
import datetime as dt, hashlib, re, threading, concurrent.futures
from pathlib import Path
from typing import Any, Optional

ROOT=Path(__file__).resolve().parent
LATEST=ROOT/"friday_screen_latest.png"
_LOCK=threading.RLock(); _STOP=threading.Event(); _THREAD:Optional[threading.Thread]=None
_STATE={"enabled":False,"started_at":None,"last_capture":None,"last_analysis":None,
"last_summary":"","last_active_window":"","last_error":"","changes_seen":0,"analyses":0}

def _now(): return dt.datetime.now().isoformat(timespec="seconds")

def capture_screen(path:Optional[str]=None)->dict[str,Any]:
    try:
        import mss
        from PIL import Image
        out=Path(path) if path else LATEST
        with mss.mss() as sct:
            shot=sct.grab(sct.monitors[0])
            Image.frombytes("RGB",shot.size,shot.rgb).save(out,"PNG")
        return {"ok":True,"path":str(out),"width":shot.width,"height":shot.height}
    except Exception as first_error:
        # MSS is fast, but FRIDAY must not lose screen awareness just because
        # that optional package is missing. Windows/Pillow provides a fallback.
        try:
            from PIL import ImageGrab
            out=Path(path) if path else LATEST
            im=ImageGrab.grab(all_screens=True)
            im.convert("RGB").save(out,"PNG")
            return {"ok":True,"path":str(out),"width":im.width,"height":im.height,"capture_backend":"Pillow"}
        except Exception as fallback_error:
            return {"ok":False,"error":f"Screen capture failed. MSS: {first_error}; Pillow fallback: {fallback_error}"}

def _sig(path):
    try:
        from PIL import Image
        im=Image.open(path).convert("L"); im.thumbnail((320,180))
        return hashlib.sha1(im.tobytes()).hexdigest()
    except Exception: return ""

def _active():
    try:
        import friday_backend as jb
        return jb.get_active_window_title()
    except Exception: return None

def extract_text(path):
    try:
        import pytesseract
        from PIL import Image,ImageOps,ImageEnhance,ImageFilter
        im=Image.open(path).convert("RGB").resize((1920,1080))
        im=ImageEnhance.Contrast(ImageOps.grayscale(im)).enhance(1.35).filter(ImageFilter.SHARPEN)
        texts=[]
        for psm in (11,6):
            try: texts.append(pytesseract.image_to_string(im,config=f"--oem 3 --psm {psm}"))
            except Exception: pass
        return {"ok":True,"text":"\n".join(texts)[:20000]}
    except Exception as e: return {"ok":False,"text":"","error":str(e)}

def _clean_active_window(active):
    """Turn a Windows window title into a useful application name."""
    if not active:
        return "the current application"
    title=re.sub(r"\s+", " ", str(active)).strip()
    low=title.lower()
    known=(
        ("google chrome", "Google Chrome"),
        ("microsoft edge", "Microsoft Edge"),
        ("visual studio code", "Visual Studio Code"),
        ("code", "Visual Studio Code"),
        ("explorer", "File Explorer"),
        ("spotify", "Spotify"),
        ("whatsapp", "WhatsApp"),
        ("discord", "Discord"),
        ("electron", "FRIDAY"),
        ("friday", "FRIDAY"),
    )
    for needle,name in known:
        if needle in low:
            return name
    # Remove common suffixes without exposing a raw, noisy window title.
    title=re.sub(r"\s*[-|—]\s*(Microsoft Edge|Google Chrome)$", "", title, flags=re.I).strip()
    return title[:80] or "the current application"

_SCREEN_MARKERS=(("chatgpt","ChatGPT"),("claude","Claude"),("gemini","Gemini"),("youtube","YouTube"),
("whatsapp","WhatsApp"),("gmail","Gmail"),("github","GitHub"),("google docs","Google Docs"),("spotify","Spotify"),
("discord","Discord"),("zoom","Zoom"),("microsoft teams","Microsoft Teams"),("stack overflow","Stack Overflow"),
("wikipedia","Wikipedia"),("netflix","Netflix"),("visual studio code","Visual Studio Code"))

def _visible_names(active,text,exclude=""):
    """Named apps / sites that genuinely appear in the window title or the OCR text."""
    hay=((active or "")+" "+(text or "")).lower(); out=[]
    for needle,name in _SCREEN_MARKERS:
        if needle in hay and name.lower()!=(exclude or "").lower() and name not in out: out.append(name)
    return out[:4]

def _join_names(names):
    if len(names)<=1: return "".join(names)
    return ", ".join(names[:-1])+" and "+names[-1]

def _readable_excerpt(text,limit=170):
    """A short, clean run of real words from the OCR text (no UI debris)."""
    keep=[]
    for line in (text or "").splitlines():
        line=re.sub(r"\s+"," ",line).strip()
        letters=sum(c.isalpha() for c in line)
        if len(line)>=18 and letters/max(1,len(line))>=0.72 and len(line.split())>=3:
            keep.append(line)
        if sum(len(x) for x in keep)>=limit: break
    out=" ".join(keep)[:limit].rsplit(" ",1)[0] if keep else ""
    return out.strip(" -|")

_EXE_NAMES={"chrome.exe":"Google Chrome","msedge.exe":"Microsoft Edge","firefox.exe":"Firefox","brave.exe":"Brave",
"explorer.exe":"File Explorer","code.exe":"Visual Studio Code","notepad.exe":"Notepad","winword.exe":"Word",
"excel.exe":"Excel","powerpnt.exe":"PowerPoint","spotify.exe":"Spotify","discord.exe":"Discord","whatsapp.exe":"WhatsApp",
"windowsterminal.exe":"Windows Terminal","cmd.exe":"Command Prompt","powershell.exe":"PowerShell","electron.exe":"FRIDAY",
"teams.exe":"Microsoft Teams","zoom.exe":"Zoom","vlc.exe":"VLC","calculatorapp.exe":"Calculator","snippingtool.exe":"Snipping Tool"}
_BROWSERS=("Google Chrome","Microsoft Edge","Firefox","Brave")

def _app_from(exe,title):
    low_t=(title or "").lower()
    if "friday" in low_t: return "FRIDAY"
    name=_EXE_NAMES.get((exe or "").lower())
    if name: return name
    if exe: return exe.rsplit(".",1)[0].replace("_"," ").title()
    return _clean_active_window(title)

def _visible_windows(limit=14):
    """[(app, title)] of visible, un-minimised top-level windows, front-most first.
    Windows only; returns [] anywhere else or on any error (never raises)."""
    import sys
    if not sys.platform.startswith("win"): return []
    try:
        import ctypes
        from ctypes import wintypes
        user32=ctypes.windll.user32; out=[]
        skip={"program manager","windows input experience","microsoft text input application","settings"}
        proc_t=ctypes.WINFUNCTYPE(ctypes.c_bool,wintypes.HWND,wintypes.LPARAM)
        def cb(hwnd,_):
            try:
                if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd): return True
                n=user32.GetWindowTextLengthW(hwnd)
                if n<=0: return True
                buf=ctypes.create_unicode_buffer(n+1); user32.GetWindowTextW(hwnd,buf,n+1)
                title=buf.value.strip()
                if not title or title.lower() in skip: return True
                cloaked=ctypes.c_int(0)
                try: ctypes.windll.dwmapi.DwmGetWindowAttribute(hwnd,14,ctypes.byref(cloaked),ctypes.sizeof(cloaked))
                except Exception: pass
                if cloaked.value: return True
                rect=wintypes.RECT(); user32.GetWindowRect(hwnd,ctypes.byref(rect))
                if rect.right-rect.left<120 or rect.bottom-rect.top<80: return True
                pid=wintypes.DWORD(); user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid)); exe=""
                try:
                    import psutil; exe=psutil.Process(pid.value).name()
                except Exception: pass
                out.append((_app_from(exe,title),title))
            except Exception: pass
            return len(out)<limit
        user32.EnumWindows(proc_t(cb),0)
        # EnumWindows is generally Z-order, but the always-on-top FRIDAY widget
        # can still be reported first. For screen questions, the underlying
        # application is the useful foreground target. Put a non-FRIDAY window
        # first whenever the widget is the foreground overlay.
        try:
            fg=user32.GetForegroundWindow()
            n=user32.GetWindowTextLengthW(fg); buf=ctypes.create_unicode_buffer(n+1)
            user32.GetWindowTextW(fg,buf,n+1); fg_title=buf.value.strip().lower()
            if "friday" in fg_title:
                non=[w for w in out if w[0] != "FRIDAY"]
                jar=[w for w in out if w[0] == "FRIDAY"]
                out=non+jar
            elif fg_title:
                exact=[w for w in out if w[1].lower()==fg_title]
                rest=[w for w in out if w[1].lower()!=fg_title]
                out=exact+rest
        except Exception: pass
        return out
    except Exception: return []

def _page_title(title,app):
    t=re.sub(r"\s*[-|\u2014]\s*(Google Chrome|Microsoft Edge|Mozilla Firefox|Brave)$","",title or "",flags=re.I).strip()
    return (t[:67].rstrip()+"...") if len(t)>70 else t

def _compose_window_report(windows):
    """Situation report from a front-to-back window list, or None when there is nothing to say."""
    if not windows: return None
    friday=[w for w in windows if w[0]=="FRIDAY"]; others=[w for w in windows if w[0]!="FRIDAY"]
    if not others:
        return "Only the FRIDAY interface is open, sir. All systems are standing by." if friday else None
    front_app,front_title=others[0]
    line=f"{front_app} is in front, sir"
    if front_app in _BROWSERS:
        page=_page_title(front_title,front_app)
        if page: line+=f", showing \u201c{page}\u201d"
    behind=[]
    for app,_ in others[1:]:
        if app!=front_app and app not in behind: behind.append(app)
    if behind: line+=f", with {_join_names(behind[:3])} open behind it"
    if friday: line+=", and the FRIDAY widget floating above them"
    return line+"."

def _local_summary(active,text):
    """Movie-style situation report used when Gemini vision is unavailable.

    Facts first, then the implication, in one or two short sentences. OCR text
    is never dumped into speech; it is only used to name what is genuinely
    visible. Nothing is claimed that was not actually observed.
    """
    # V2037: describe what is really open (all visible windows), not just the focused one --
    # the FRIDAY widget is often the "active" window while the user is looking at a browser.
    report=_compose_window_report(_visible_windows())
    if report: return report
    app=_clean_active_window(active)
    low=app.lower()
    seen=_visible_names(active,text,exclude=app)
    extra=(f" I can also make out {_join_names(seen)} on the display." if seen else "")
    if low=="friday":
        base="We're in the FRIDAY interface, sir. All systems are standing by."
        if seen: base=f"We're in the FRIDAY interface, sir, with {_join_names(seen)} visible alongside it."
        return base
    if low in ("google chrome","microsoft edge"):
        if len(seen)>=2:
            return f"{app} is up, sir, with {_join_names(seen)} in view. Shall I look closer at any of them?"
        return f"{app} is in the foreground, sir.{extra} Say the word and I'll examine the page."
    if low=="visual studio code":
        return f"Visual Studio Code is in focus, sir. Your workspace is in view.{extra}"
    if low=="file explorer":
        return f"File Explorer is open, sir. I can go through what's in view if you'd like."
    if low in ("spotify","whatsapp","discord"):
        return f"{app} is in focus, sir.{extra} I can go through what's on display if you'd like."
    return f"{app} is currently in focus, sir.{extra} I can look closer if required."

def _vision(path,active):
    try:
        import friday_backend as jb
        jb._ensure_gemini_client()
        if getattr(jb,"client",None) is None: return None
        from google.genai import types
        windows=_visible_windows()
        listing="; ".join(f"{a} - '{t[:60]}'" for a,t in windows[:8]) or "unknown"
        prompt=f"""You are FRIDAY, a composed, dry-witted British butler-style AI assistant looking at the user's screen.
Active window: {active or 'unknown'}. Visible windows, front to back: {listing}.
Speak as FRIDAY would over the intercom: begin with the situation ("Sir, ..." or a direct observation), report facts first, then at most one brief, understated remark or offer of help. Never theatrical, never a chatbot paragraph.
Give a natural 1-3 sentence situational summary of what is visibly happening across the whole screen (not only the FRIDAY widget, which is just an overlay).
Identify the applications and, only when visually clear, the user's current task or the important content being displayed.
Do NOT list UI labels, timestamps, slogans, buttons, menu items, OCR fragments, or disconnected pieces of text.
Do NOT quote visible text unless the user explicitly asked to read the screen.
Do NOT invent hidden information. If the task is unclear, simply state the applications and that you can inspect further."""
        # A downscaled JPEG uploads and answers several times faster than a 4K PNG.
        try:
            from PIL import Image; import io
            im=Image.open(path).convert("RGB"); im.thumbnail((1600,900)); buf=io.BytesIO(); im.save(buf,"JPEG",quality=82)
            data,mime=buf.getvalue(),"image/jpeg"
        except Exception:
            data,mime=Path(path).read_bytes(),"image/png"
        part=types.Part.from_bytes(data=data,mime_type=mime)
        pool=concurrent.futures.ThreadPoolExecutor(max_workers=1)
        future=pool.submit(lambda: jb._gemini_generate([prompt,part]))
        try:
            r=future.result(timeout=25)
        except Exception as error:
            print("Screen vision unavailable:", type(error).__name__, str(error)[:200], flush=True)
            return None
        finally:
            pool.shutdown(wait=False)
        return (jb._response_text(r) or "").strip()[:1800] or None
    except Exception as error:
        print("Screen vision error:", type(error).__name__, str(error)[:200], flush=True)
        return None

def inspect_screen(use_semantic_vision=True):
    shot=capture_screen()
    if not shot.get("ok"): return shot
    active=_active(); ocr=extract_text(shot["path"]); raw=ocr.get("text","")
    semantic=_vision(shot["path"],active) if use_semantic_vision else None
    return {**shot,"active_window":active,"ocr":raw,
            "summary":semantic or _local_summary(active,raw),
            "vision_mode":"gemini" if semantic else "local_context","timestamp":_now()}

def spoken_screen_report(result,read_text=False):
    """The one place that turns an inspect_screen() result into FRIDAY's spoken reply."""
    if not result or not result.get("ok"):
        return "I can't get a clear view of the screen at the moment, sir."
    said=(result.get("summary") or "").strip() or _local_summary(result.get("active_window"),result.get("ocr",""))
    if read_text:
        excerpt=_readable_excerpt(result.get("ocr",""))
        said+=(f" The legible text begins: {excerpt}." if excerpt else " I can't make out any legible text at the moment.")
    return said

def awareness_status():
    with _LOCK: return dict(_STATE)

def get_awareness_summary():
    with _LOCK: return _STATE["last_summary"] or "I am not currently observing a meaningful screen change."

def _loop(interval,semantic):
    prev=""; prev_window=""
    try:
        while not _STOP.wait(max(.75,float(interval))):
            shot=capture_screen()
            if not shot.get("ok"):
                with _LOCK:_STATE["last_error"]=shot.get("error","capture failed")
                continue
            sig=_sig(shot["path"]); active=_active()
            with _LOCK:
                _STATE["last_capture"]=_now(); _STATE["last_active_window"]=active or ""
            changed=(not prev) or (sig and sig!=prev) or (active and active!=prev_window)
            if changed:
                r=inspect_screen(use_semantic_vision=semantic)
                with _LOCK:
                    if r.get("ok"):
                        _STATE["last_analysis"]=_now(); _STATE["last_summary"]=r.get("summary","")
                        _STATE["changes_seen"]+=1; _STATE["analyses"]+=1; _STATE["last_error"]=""
                    else: _STATE["last_error"]=r.get("error","analysis failed")
            prev,prev_window=sig,active or ""
    except Exception as e:
        with _LOCK:_STATE["last_error"]=str(e)
    finally:
        with _LOCK:_STATE["enabled"]=False

def start_awareness(interval=2.5,semantic=True):
    global _THREAD
    with _LOCK:
        if _THREAD and _THREAD.is_alive(): return {"ok":True,"already_running":True,**_STATE}
        _STOP.clear(); _STATE.update({"enabled":True,"started_at":_now(),"last_error":"","last_summary":"","changes_seen":0,"analyses":0})
        _THREAD=threading.Thread(target=_loop,args=(interval,semantic),name="FRIDAY-Screen-Awareness",daemon=True)
        _THREAD.start(); return {"ok":True,"started":True,**_STATE}

def stop_awareness():
    _STOP.set()
    with _LOCK:_STATE["enabled"]=False
    return {"ok":True,"stopped":True,**_STATE}

_SCREEN_PATTERNS=[
r"\b(?:can|could|do|are|will)\s+you\s+(?:please\s+)?(?:check|see|view|look at|glance at|take|grab|get|read|scan|understand|analy[sz]e|inspect|describe)\s+(?:a\s+)?(?:my\s+)?screen\b",
r"\b(?:give|tell|show)\s+(?:me\s+)?(?:the\s+)?(?:info|information|details|description)\s+(?:on|about)\s+(?:the\s+)?(?:image|picture|photo)\b",
r"\b(?:what|whats|what's)\s+(?:is\s+)?(?:in|on)\s+(?:the\s+)?(?:image|picture|photo)\s+(?:i\s+am|im|i'm)\s+(?:seeing|looking at)\b",
r"\b(?:describe|analyze|inspect|read)\s+(?:the\s+)?(?:image|picture|photo)\s+(?:i\s+am|im|i'm)\s+(?:seeing|looking at)\b",
r"\bwhat('?s| is)\s+(on|happening on)\s+(my\s+)?screen\b",
r"\bwhat\s+am\s+i\s+(doing|looking at|working on)\b",
r"\bwhat('?s| is)\s+(happening|going on)\s+(on\s+)?my\s+(computer|pc|desktop)\b",
# Bare imperative form ("check my screen", "read this screen") -- the
# "can/could/do/are/will you" pattern above only covers the polite
# question phrasing, this covers the direct-command phrasing.
r"\b(?:check|read|scan|understand|analy[sz]e|inspect|describe|glance at)\s+(?:my|the|this)\s+screen\b",
r"\blook\s+at\s+(my|this)\s+screen\b",
r"\bwhat\s+do\s+you\s+see\s+(on\s+)?(my\s+)?screen\b",
r"\bcan\s+you\s+tell\s+what\s+i('?m| am)\s+doing\b",
# "take my screen" / "take a screenshot" / "grab my screen" phrasings --
# previously these fell through to plain AI chat instead of triggering
# a real screen capture, which is exactly why "can you take my screen
# right now?" produced a generic (and misleading) "AI brain not
# connected" reply instead of ever attempting to look at the screen.
r"\b(take|grab|get|capture)\s+(a\s+)?(screenshot|snapshot)\b",
r"\b(take|grab|get)\s+(a\s+(look\s+at\s+)?)?my\s+screen\b"]
def is_screen_intent(text):
    low=re.sub(r"\s+"," ",(text or "").strip().lower())
    return bool(low and any(re.search(p,low,re.I) for p in _SCREEN_PATTERNS))
def is_awareness_start_intent(text):
    low=re.sub(r"\s+"," ",(text or "").strip().lower())
    return bool(re.search(r"\b(watch|monitor|keep an eye on|observe|keep watching)\b.*\b(screen|desktop|computer|what i('?m| am) doing)\b",low))
def is_awareness_stop_intent(text):
    low=re.sub(r"\s+"," ",(text or "").strip().lower())
    return bool(re.search(r"\b(stop|disable|turn off|pause)\b.*\b(watch|watching|monitor|monitoring|observ|observing|screen awareness)\b",low))
