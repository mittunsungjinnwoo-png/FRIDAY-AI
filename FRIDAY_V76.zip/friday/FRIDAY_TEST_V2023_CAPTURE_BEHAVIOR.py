"""Deterministic synthetic regression tests for the V2023 capture algorithm.

No microphone, SpeechRecognition or PyAudio installation is required.
The test extracts the production capture function and feeds it synthetic
16-bit PCM chunks through the same stream.read() interface.
"""
from pathlib import Path
import ast, math, os, types

BACKEND = Path(__file__).with_name("friday_backend.py")
SOURCE = BACKEND.read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)

wanted = {"_pcm_rms_int16", "_pcm_rms", "_webrtc_speech_ratio", "_speech_decision", "_capture_until_silence"}
nodes = [n for n in TREE.body if isinstance(n, ast.FunctionDef) and n.name in wanted]
namespace = {
    "math": math,
    "os": os,
    "sr": types.SimpleNamespace(AudioData=lambda data, rate, width: (data, rate, width),
                                UnknownValueError=RuntimeError),
    "recognizer": types.SimpleNamespace(energy_threshold=300.0, dynamic_energy_ratio=1.5),
    "_VAD_NOISE_FLOOR": 0.0,
    "ADVANCED_VAD_ENABLED": False,
    "_webrtcvad": None,
    "WEBRTC_VAD_AGGRESSIVENESS": 2,
    "WEBRTC_VAD_MIN_RATIO": 0.25,
}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(BACKEND), "exec"), namespace)

capture = namespace["_capture_until_silence"]
pcm_rms = namespace["_pcm_rms_int16"]

RATE = 16000
CHUNK = 1024
BYTES = CHUNK * 2

def pcm(level):
    level = int(level)
    return (int(level).to_bytes(2, "little", signed=True) * CHUNK)

class FakePA:
    def __init__(self, frames):
        self.frames = iter(frames)
    def read(self, chunk, exception_on_overflow=False):
        return next(self.frames)

class FakeSource:
    SAMPLE_RATE = RATE
    CHUNK = CHUNK
    SAMPLE_WIDTH = 2
    def __init__(self, frames):
        self.stream = types.SimpleNamespace(pyaudio_stream=FakePA(frames))

def run(frames, pause="1.25", max_speech="30"):
    os.environ["FRIDAY_VAD_PAUSE"] = pause
    os.environ["FRIDAY_MAX_SPEECH_SECONDS"] = max_speech
    namespace["_VAD_NOISE_FLOOR"] = 0.0
    data, rate, width = capture(FakeSource(frames))
    return len(data) // 2 // RATE

# 1) Long idle must NOT consume the 30-second speech budget.
idle = [pcm(60)] * int(35 * RATE / CHUNK)
speech_levels = [750, 1050, 850, 1200, 900, 1100]
speech = [pcm(speech_levels[i % len(speech_levels)]) for i in range(int(2 * RATE / CHUNK))]
silence = [pcm(60)] * int(2.0 * RATE / CHUNK)
captured_seconds = run(idle + speech + silence)
assert captured_seconds >= 2.0, captured_seconds

# 2) Loud steady background noise must not trigger forever.
noise = [pcm(700)] * int(3 * RATE / CHUNK)
speech_levels = [1300, 1700, 1450, 1900, 1500, 1800]
speech = [pcm(speech_levels[i % len(speech_levels)]) for i in range(int(1.5 * RATE / CHUNK))]
silence = [pcm(700)] * int(2.0 * RATE / CHUNK)
captured_seconds = run(noise + speech + silence)
assert 1.3 <= captured_seconds <= 3.5, captured_seconds

# 3) Speech beginning immediately after Listening must be detected.
speech_levels = [900, 1300, 1050, 1500, 1100, 1400]
speech = [pcm(speech_levels[i % len(speech_levels)]) for i in range(int(1.2 * RATE / CHUNK))]
silence = [pcm(50)] * int(1.4 * RATE / CHUNK)
captured_seconds = run(speech + silence)
assert captured_seconds >= 1.2, captured_seconds

# 4) A single key-click-sized spike must not start capture.
click = [pcm(60)] * 10 + [pcm(5000)] + [pcm(60)] * int(1.5 * RATE / CHUNK)
# The function should continue waiting; feed a real utterance afterward.
speech_levels = [850, 1250, 1000, 1350, 950, 1200]
speech = [pcm(speech_levels[i % len(speech_levels)]) for i in range(int(1.0 * RATE / CHUNK))]
silence = [pcm(60)] * int(2.0 * RATE / CHUNK)
captured_seconds = run(click + speech + silence)
assert captured_seconds >= 1.0, captured_seconds

print("V2023 synthetic capture behavior: PASS")
print("  long idle: PASS")
print("  steady noisy mic: PASS")
print("  immediate speech: PASS")
print("  click rejection: PASS")
