"""V7.2 checks: small talk is answered locally, the intent classifier skips ordinary chat, deep route only on explicit asks."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import friday_backend as b

def check(name, cond):
    print(("PASS: " if cond else "FAIL: ") + name)
    if not cond:
        raise SystemExit(1)

for phrase, kind in [("thanks", "thanks"), ("Thank you so much, Friday", "thanks"), ("how are you", "how_are_you"),
                     ("hey friday", "hello"), ("good morning", "good_morning"), ("are you there", "there")]:
    hit = next((k for k, p in b._ST_PATTERNS if p.match(phrase)), None)
    check(f"small talk {phrase!r} -> {kind}", hit == kind)
for phrase in ["thanks for the file, can you open it", "hello world program in python", "how are you going to fix this bug",
               "send hello to mum", "good morning email to my boss", "open chrome", "save 500 rupees this week"]:
    check(f"NOT small talk: {phrase!r}", not any(p.match(phrase) for _, p in b._ST_PATTERNS))
for kind in ["thanks", "how_are_you", "hello", "good_morning", "good_afternoon", "good_evening", "good_night", "there", "nice", "back"]:
    check(f"reply exists: {kind}", bool(b._small_talk_reply(kind)))

# the intent classifier is only consulted for commands that contain a cue word
for phrase in ["i feel really tired today", "what do you think about electric cars", "how was your day"]:
    check(f"no classifier call: {phrase!r}", b._classify_intent_with_gemini(phrase) == "none" and not b._INTENT_CUE_RE.search(phrase))
check("cue words still reach the classifier", bool(b._INTENT_CUE_RE.search("what's the weather like")))

# deep (3 sequential calls) only when asked for
check("plain question is not deep", not b._deep_route_wanted("explain how photosynthesis works"))
check("'prove' is deep", b._deep_route_wanted("prove that root 2 is irrational"))

# a pending question must never be stolen by small talk
b._wa_session = {"stage": "await_message", "contact": "Sam"}
check("small talk skipped while WhatsApp flow is pending", b._try_instant_small_talk("hello") is False)
b._wa_session = None
print("ALL FRIDAY V7.2 FAST + HUMAN TESTS PASSED")
