"""V7.3 checks: strategy layer, mission engine, memory freshness, extended benchmark. Run: python FRIDAY_TEST_V73.py"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import friday_bench7 as B


def check(name, cond):
    print(("PASS: " if cond else "FAIL: ") + name)
    if not cond:
        raise SystemExit(1)


res = B.run_isolated(["strategy", "mission", "safety", "eval"])
check("benchmark ran in isolation", res.get("ok"))
for c in res["cases"]:
    check(f"[{c['id']}] {c['name']}", c["status"] == "pass")
full = B.run_isolated()
check("full benchmark (all 11 areas) passes", full.get("ok") and not full["failed"] and full["total"] >= 54)
for f in ("friday_strategy73.py", "friday_mission73.py", "friday_memory73.py"):
    check(f"{f} compiles", subprocess.run([sys.executable, "-m", "py_compile", str(HERE / f)]).returncode == 0)
print("ALL V7.3 CHECKS PASSED")
