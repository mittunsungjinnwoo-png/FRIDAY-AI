"""FRIDAY 6.0 voice *settings* layer. It never touches the listening, recognition or speaking mechanisms - it only sets the same
knobs they already read at run time (FRIDAY_MIC_INDEX, FRIDAY_EDGE_VOICE, VOICE_RATE, SPEECH_RECOGNITION_LANGUAGE), as the blueprint
asks: improve the surrounding architecture first, change the mechanisms only for a tested reason.

Adds: microphone listing / selection (+ recovery by re-selecting the default), adjustable voice / speed / speaking style, optional
multilingual conversation (recognition language + matching neural voice + reply-language instruction), text fallback hint.
"""
from __future__ import annotations

import json
import os
import re
from typing import Callable, Dict, List, Optional

import friday_common6 as C

CFG = C.DATA_DIR / "voice6.json"
_hook: Dict[str, Callable] = {"set_global": lambda n, v: None, "get_global": lambda n, d=None: d, "restart_listener": lambda: None}
_cfg: Dict = {"voice": "", "rate": None, "language": "en-US", "mic": None, "style": "balanced", "reply_language": ""}

VOICES = {"female": "en-US-AriaNeural", "male": "en-US-GuyNeural", "british female": "en-GB-SoniaNeural", "british male": "en-GB-RyanNeural", "british": "en-GB-SoniaNeural",
          "australian": "en-AU-NatashaNeural", "indian": "en-IN-NeerjaNeural", "default": "en-US-AriaNeural"}
LANGS = {  # name: (speech-recognition code, neural voice)
    "english": ("en-US", "en-US-AriaNeural"), "spanish": ("es-ES", "es-ES-ElviraNeural"), "french": ("fr-FR", "fr-FR-DeniseNeural"), "german": ("de-DE", "de-DE-KatjaNeural"),
    "italian": ("it-IT", "it-IT-ElsaNeural"), "portuguese": ("pt-BR", "pt-BR-FranciscaNeural"), "hindi": ("hi-IN", "hi-IN-SwaraNeural"), "tamil": ("ta-IN", "ta-IN-PallaviNeural"),
    "sinhala": ("si-LK", "si-LK-ThiliniNeural"), "japanese": ("ja-JP", "ja-JP-NanamiNeural"), "chinese": ("zh-CN", "zh-CN-XiaoxiaoNeural"), "korean": ("ko-KR", "ko-KR-SunHiNeural"),
    "arabic": ("ar-SA", "ar-SA-ZariyahNeural"), "russian": ("ru-RU", "ru-RU-SvetlanaNeural")}
STYLES = {"concise": "Keep spoken replies to one or two short sentences unless asked for more.", "detailed": "Give fuller spoken explanations with reasons, but stay clear and organised.",
          "formal": "Use a formal, courteous register.", "casual": "Use a relaxed, friendly register.", "balanced": ""}


def configure(**kw):
    _hook.update({k: v for k, v in kw.items() if v is not None})


def load():
    try:
        _cfg.update(json.loads(CFG.read_text("utf-8")))
    except Exception:
        pass


def save():
    try:
        CFG.parent.mkdir(parents=True, exist_ok=True)
        CFG.write_text(json.dumps(_cfg), "utf-8")
    except Exception:
        pass


def apply():
    """Push saved settings into the same variables the existing voice code reads. Called at boot and after each change."""
    if _cfg["voice"]:
        os.environ["FRIDAY_EDGE_VOICE"] = _cfg["voice"]
    if _cfg["mic"] is not None:
        os.environ["FRIDAY_MIC_INDEX"] = str(_cfg["mic"])
    if _cfg["rate"]:
        _hook["set_global"]("VOICE_RATE", int(_cfg["rate"]))
    if _cfg["language"]:
        _hook["set_global"]("SPEECH_RECOGNITION_LANGUAGE", _cfg["language"])


def list_mics() -> List[Dict]:
    try:
        import pyaudio
        pa = pyaudio.PyAudio()
        out = []
        default = None
        try:
            default = pa.get_default_input_device_info()["index"]
        except Exception:
            pass
        for i in range(pa.get_device_count()):
            d = pa.get_device_info_by_index(i)
            if d.get("maxInputChannels", 0) > 0:
                out.append({"index": i, "name": d["name"], "default": i == default})
        pa.terminate()
        return out
    except Exception:
        return []


def style_hint() -> str:
    h = STYLES.get(_cfg["style"], "")
    if _cfg["reply_language"]:
        h += f" Reply in {_cfg['reply_language'].title()} (the user chose this language)."
    return h.strip()


def state() -> Dict:
    return {"voice": _cfg["voice"] or os.environ.get("FRIDAY_EDGE_VOICE", "en-US-AriaNeural"), "rate": _cfg["rate"] or _hook["get_global"]("VOICE_RATE", 185),
            "language": _cfg["language"], "mic": _cfg["mic"], "style": _cfg["style"], "reply_language": _cfg["reply_language"], "mics": list_mics()}


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if re.match(r"^(?:list|show|what|which) (?:my )?(?:microphones?|mics?|audio inputs?)(?: (?:are|do i have|available))?$", low):
        mics = list_mics()
        return "I couldn't list microphones here." if not mics else "Microphones: " + "; ".join(f"{m['index']}: {m['name'][:36]}" + (" (default)" if m["default"] else "") for m in mics[:6]) + ". Say 'use microphone' and its number."
    m = re.match(r"^(?:use|select|switch to|change to) (?:the )?(?:microphone|mic|input)(?: number| index)? (\d+)$", low)
    if m:
        _cfg["mic"] = int(m.group(1)); save(); apply(); _hook["restart_listener"]()
        return f"Microphone {m.group(1)} selected. I've restarted listening on it."
    m = re.match(r"^(?:use|select|switch to) (?:the )?(?:microphone|mic|input) (?:called |named )?(.+)$", low)
    if m and not m.group(1).isdigit():
        for d in list_mics():
            if m.group(1) in d["name"].lower():
                _cfg["mic"] = d["index"]; save(); apply(); _hook["restart_listener"]()
                return f"Using {d['name'][:40]}."
        return "I couldn't find a microphone with that name."
    if re.match(r"^(?:fix|reset|recover|reconnect) (?:the |my )?(?:microphone|mic|listening)$|^(?:you can'?t hear me|i can'?t talk to you)$", low):
        _cfg["mic"] = None; save(); os.environ.pop("FRIDAY_MIC_INDEX", None); _hook["restart_listener"]()
        return "I've reset to the system default microphone and restarted listening. If I still can't hear you, you can always type to me."
    m = re.match(r"^(?:speak|talk|go) (faster|slower|quicker)$|^(?:speed up|slow down)$", low)
    if m:
        cur = int(_cfg["rate"] or _hook["get_global"]("VOICE_RATE", 185))
        faster = bool(m.group(1) in ("faster", "quicker")) if m.group(1) else low.startswith("speed")
        _cfg["rate"] = max(150, min(230, cur + (12 if faster else -12))); save(); apply()
        return f"Speaking {'faster' if faster else 'slower'}."
    m = re.match(r"^(?:use|switch to|change to|speak with) (?:an? |the )?(british male|british female|british|australian|indian|male|female|default)(?: voice)?$", low)
    if m:
        _cfg["voice"] = VOICES[m.group(1)]; save(); apply()
        return f"Voice changed to {m.group(1)}."
    m = re.match(r"^(?:use|switch to) (?:the )?voice ([a-z]{2}-[A-Z]{2}-\w+Neural)$", t.strip(" ."))
    if m:
        _cfg["voice"] = m.group(1); save(); apply()
        return f"Voice set to {m.group(1)}."
    m = re.match(r"^(?:speak|talk|reply|respond|converse) (?:to me )?in (\w+)$|^switch (?:the )?language to (\w+)$", low)
    if m and (m.group(1) or m.group(2)) in LANGS:
        name = m.group(1) or m.group(2)
        code, voice = LANGS[name]
        _cfg.update(language=code, voice=voice, reply_language="" if name == "english" else name); save(); apply()
        return f"Switching to {name.title()}. I'll listen for it and reply in it; say 'speak in English' to go back." + ("" if name == "english" else " Recognition quality depends on the speech service for that language.")
    m = re.match(r"^(?:speaking )?style (?:to )?(concise|detailed|formal|casual|balanced)$|^(?:be|speak) (?:more )?(concise|detailed|formal|casual)$", low)
    if m:
        _cfg["style"] = m.group(1) or m.group(2); save()
        return f"Speaking style set to {_cfg['style']}."
    if re.match(r"^(?:what|which) voice (?:are you using|is this)$|^voice settings$", low):
        s = state()
        return f"Voice {s['voice']}, speed {s['rate']}, language {s['language']}, style {s['style']}."
    return None
