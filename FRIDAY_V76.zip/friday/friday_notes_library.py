"""
FRIDAY V2036 OFFLINE STUDY LIBRARY
----------------------------------
Complete, hand-checked notes for high-value syllabus topics. They are used ONLY
when the live AI/research step cannot produce notes (no key, no network, quota,
etc.) so the student still receives full study content and real diagrams instead
of an empty placeholder sheet.

find_entry(topic, subject_label) -> dict in the same JSON shape the AI returns,
or None when the topic is not in the library.

Note on notation: plain text is used on purpose (the PDF renderer flattens
superscripts), so "2s2 2p2" means 2 electrons in 2s and 2 in 2p.
"""
from __future__ import annotations

import copy
import re

_SP3 = {
    "chapter_title": "How sp3 Orbitals Are Formed",
    "subject_line": "Chemical bonding - hybridisation of carbon (sp3)",
    "what_is": (
        "sp3 hybridisation is the mixing of ONE s orbital and THREE p orbitals of the same atom "
        "to give FOUR new, identical hybrid orbitals called sp3 orbitals. Each one has 25% s "
        "character and 75% p character, and the four point to the corners of a tetrahedron, "
        "109.5 degrees apart. Carbon in methane, ethane and every alkane uses sp3 orbitals to make "
        "four sigma bonds."
    ),
    "topic_coverage": [
        "Why hybridise: ground-state carbon (2s2 2p2) has only two unpaired electrons, yet forms four identical bonds",
        "Step 1 - promotion of a 2s electron into the empty 2p orbital (2s1 2p3)",
        "Step 2 - mixing one 2s and three 2p orbitals into four equal sp3 orbitals",
        "Shape: tetrahedral, 109.5 degrees, each lobe large in front and tiny at the back",
        "Bonding: head-on overlap with H 1s (or another sp3) gives a sigma bond",
        "Worked cases: methane CH4 and ethane C2H6",
        "Lone pairs in sp3 orbitals: NH3 (107 degrees) and H2O (104.5 degrees)",
        "Comparison of sp3, sp2 and sp",
    ],
    "key_points": [
        "Hybridisation = mixing of atomic orbitals on ONE atom. Orbitals in = orbitals out (1 s + 3 p = 4 sp3).",
        "Every sp3 orbital has the same energy and shape: 25% s character, 75% p character.",
        "The four sp3 orbitals repel and sit at the corners of a regular tetrahedron: H-C-H = 109.5 degrees.",
        "End-on (head-on) overlap along the line between the nuclei forms a sigma bond; a single bond is one sigma bond.",
        "Carbon is sp3 when it has four sigma-bonded groups and no pi bond (CH4, C2H6, CH3OH, diamond).",
        "Promotion costs energy, but forming four bonds instead of two releases far more, so the molecule is more stable.",
        "Lone pairs can sit in sp3 orbitals too (N in NH3, O in H2O); the molecular shape only names the atoms.",
    ],
    "equation": "1 s orbital + 3 p orbitals  ->  4 sp3 hybrid orbitals",
    "equation_explanation": (
        "Carbon: 1s2 2s2 2p2 (ground)  ->  1s2 2s1 2p3 (promoted)  ->  1s2 (sp3)1 (sp3)1 (sp3)1 (sp3)1. "
        "s character = 1/4 = 25%, p character = 3/4 = 75%."
    ),
    "requirements": [
        "The atom has FOUR electron domains (bonding pairs + lone pairs) and no pi bond.",
        "The orbitals that mix are in the same shell and close in energy (2s with 2p).",
        "A double bond needs sp2 and a triple bond needs sp - not sp3.",
    ],
    "process_steps": [
        {"title": "Ground state of carbon",
         "explanation": "1s2 2s2 2p2. Only two unpaired 2p electrons, so carbon would form just two bonds at about 90 degrees. That does not match CH4, which has four identical bonds at 109.5 degrees."},
        {"title": "Promotion",
         "explanation": "One 2s electron moves into the empty 2p orbital: 2s1 2p3. A little energy is needed, but now there are four unpaired electrons."},
        {"title": "Hybridisation (mixing)",
         "explanation": "The 2s and the three 2p orbitals (px, py, pz) mix to give four new orbitals of equal energy, labelled sp3. Each holds one electron. Their energy lies between 2s and 2p."},
        {"title": "Orientation",
         "explanation": "The four orbitals repel each other and move as far apart as possible: the corners of a tetrahedron, 109.5 degrees apart. Each has a big lobe for bonding and a small back lobe."},
        {"title": "Bond formation",
         "explanation": "Each big lobe overlaps head-on with a hydrogen 1s orbital. The overlap lies on the line joining the nuclei, so each C-H bond is a sigma bond holding one shared pair of electrons."},
    ],
    "key_ideas": [
        {"name": "Why promote AND hybridise?",
         "explanation": "Promotion gives four unpaired electrons so four bonds are possible. Hybridising makes the four orbitals identical, which explains why all four C-H bonds in methane have the same length, strength and angle."},
        {"name": "Sigma bond",
         "explanation": "Formed by head-on overlap of orbitals along the internuclear axis. The electron density is concentrated between the two nuclei and the bond allows rotation. Every single bond is a sigma bond."},
        {"name": "Character of sp3",
         "explanation": "One s plus three p gives 25% s and 75% p. More p character than sp2 (33% s) or sp (50% s), so sp3 bonds are the longest and the carbon is the least electronegative of the three."},
        {"name": "Methane and ethane",
         "explanation": "CH4: four sp3-1s sigma bonds. C2H6: six C-H bonds (sp3-1s) and one C-C bond (sp3-sp3 overlap), giving 7 sigma bonds. Each carbon is tetrahedral and the C-C bond can rotate freely."},
        {"name": "Lone pairs in sp3 orbitals",
         "explanation": "N (2s2 2p3) and O (2s2 2p4) also mix 2s + 3 x 2p into four sp3 orbitals. NH3 has 3 bond pairs + 1 lone pair (107 degrees, trigonal pyramidal); H2O has 2 + 2 (104.5 degrees, bent). Lone pairs repel more strongly, squeezing the angle below 109.5."},
    ],
    "reference_outline": [
        {"number": 1, "title": "What is an sp3 orbital?",
         "content": "A hybrid orbital made by combining one s and three p orbitals of the same atom. Four are produced, all identical, all pointing tetrahedrally.",
         "bullets": ["25% s, 75% p", "Same energy, same shape", "Bond angle 109.5 degrees"]},
        {"number": 2, "title": "Why carbon needs it",
         "content": "Ground-state carbon (2s2 2p2) has two unpaired electrons, but methane needs four equal bonds. Hybridisation explains the observed structure.",
         "bullets": ["CH4 has four identical C-H bonds", "Measured H-C-H angle is 109.5 degrees, not 90"]},
        {"number": 3, "title": "How they form",
         "content": "Promote 2s to 2p, then mix 2s + 2px + 2py + 2pz into four sp3 orbitals, each containing one electron.",
         "bullets": ["Promotion: 2s2 2p2 -> 2s1 2p3", "Mixing: 4 orbitals in -> 4 orbitals out"]},
        {"number": 4, "title": "Shape of each orbital",
         "content": "Each sp3 orbital is lopsided: a large lobe pointing out to bond, and a small lobe on the opposite side of the nucleus.",
         "bullets": ["Large lobe overlaps better", "So sp3 bonds are strong"]},
        {"number": 5, "title": "Bonds they make",
         "content": "sp3 orbitals overlap head-on with s or p orbitals of other atoms to form sigma bonds only.",
         "bullets": ["C-H: sp3 + 1s", "C-C: sp3 + sp3", "C-Cl: sp3 + 3p"]},
        {"number": 6, "title": "Where you meet sp3",
         "content": "Alkanes, alcohols and haloalkanes (the carbon attached to the functional group), diamond, and the central atom in NH3, H2O and NH4+.",
         "bullets": ["Any atom with 4 electron domains"]},
    ],
    "diagrams": [
        {"kind": "energy",
         "title": "Carbon: ground state to four sp3 orbitals (orbital-in-box)",
         "caption": "Promote one 2s electron, then mix 2s + 3 x 2p. The four sp3 orbitals are equal in energy and each holds one unpaired electron.",
         "columns": [
             {"title": "1. Ground state (2s2 2p2)", "levels": [
                 {"label": "2p", "energy": 2.0, "boxes": [1, 1, 0]},
                 {"label": "2s", "energy": 1.0, "boxes": [2]}]},
             {"title": "2. Promoted (2s1 2p3)", "levels": [
                 {"label": "2p", "energy": 2.0, "boxes": [1, 1, 1]},
                 {"label": "2s", "energy": 1.0, "boxes": [1]}]},
             {"title": "3. Hybridised: four sp3", "levels": [
                 {"label": "sp3", "energy": 1.6, "boxes": [1, 1, 1, 1]}]},
         ],
         "transitions": ["promote 1 electron from 2s to 2p", "mix 1 s + 3 p"]},
        {"kind": "lobes",
         "title": "The four sp3 orbitals around the carbon nucleus",
         "caption": "Big bonding lobes point to the corners of a tetrahedron; the dashed lobe points away from you. Each has a tiny back lobe.",
         "angles": [90, 210, 330, 30], "back": [3],
         "labels": ["sp3", "sp3", "sp3", "sp3 (behind)"], "center": "C"},
        {"kind": "molecule3d",
         "title": "Methane, CH4: tetrahedral",
         "caption": "Four C-H sigma bonds, each formed by sp3 + H 1s overlap. Every H-C-H angle is 109.5 degrees.",
         "shape": "tetrahedral", "center": "C", "substituents": ["H", "H", "H", "H"],
         "angle_label": "H-C-H = 109.5 degrees"},
    ],
    "worked_examples": [
        {"question": "Explain, in terms of orbitals, how the four C-H bonds in methane are formed and why they are identical.",
         "answer": "Carbon 2s2 2p2 promotes one 2s electron: 2s1 2p3. The 2s and three 2p orbitals hybridise to four equivalent sp3 orbitals, each with one electron, pointing tetrahedrally at 109.5 degrees. Each sp3 orbital overlaps head-on with a hydrogen 1s orbital to form four identical C-H sigma bonds."},
        {"question": "State the hybridisation of each carbon in ethane and describe the C-C bond.",
         "answer": "Each carbon has four sigma bonds so is sp3. The C-C bond is one sigma bond from head-on overlap of an sp3 orbital from each carbon (sp3-sp3); rotation about it is possible. Each carbon also forms three C-H bonds by sp3-1s overlap: 7 sigma bonds in total."},
        {"question": "Predict and explain the H-N-H bond angle in NH3.",
         "answer": "Nitrogen has 4 electron domains (3 bond pairs + 1 lone pair), so it is sp3 and the electron pairs are arranged tetrahedrally. The lone pair repels bond pairs more strongly than they repel each other, so the angle closes to about 107 degrees and the shape is trigonal pyramidal."},
    ],
    "common_mistakes": [
        "Saying orbitals from different atoms hybridise. Hybridisation happens within ONE atom; overlap happens between atoms.",
        "Missing the promotion step. For carbon, hybridisation starts from 2s1 2p3, not 2s2 2p2.",
        "Writing that electrons are mixed. Orbitals are mixed; in methane each sp3 orbital simply holds one electron.",
        "Giving 90 or 120 degrees. sp3 is 109.5 degrees (less with lone pairs: 107 for NH3, 104.5 for H2O).",
        "Calling C-H bonds pi bonds. Head-on overlap = sigma; pi bonds come from sideways overlap of unhybridised p orbitals (sp2 and sp carbons).",
        "Including lone pairs in the shape name. NH3 is trigonal pyramidal, H2O is bent - even though their electron pairs are tetrahedral.",
    ],
    "exam_tips": [
        "'Explain how sp3 orbitals are formed': promotion, mixing 1 s + 3 p, four equal orbitals, tetrahedral 109.5 degrees, head-on overlap gives sigma bonds.",
        "Draw orbital-in-box diagrams before and after, labelling 2s, 2p, sp3 and the electron arrows.",
        "Count electron domains: 4 = sp3, 3 = sp2, 2 = sp. Then quote the angle 109.5 / 120 / 180.",
        "Say 'overlap of orbitals' (not atoms) and 'sigma bond = head-on overlap along the internuclear axis'.",
        "For angles below 109.5 quote: lone pair-lone pair > lone pair-bond pair > bond pair-bond pair repulsion.",
    ],
    "vocabulary": [
        {"term": "Hybridisation", "meaning": "Mixing of atomic orbitals on one atom to form new equivalent orbitals."},
        {"term": "Hybrid orbital", "meaning": "New orbital formed by mixing; number formed = number mixed."},
        {"term": "Promotion", "meaning": "Moving an electron to a higher empty orbital so more unpaired electrons are available for bonding."},
        {"term": "Sigma (sigma) bond", "meaning": "Bond from head-on overlap of orbitals along the line joining the nuclei."},
        {"term": "Electron domain", "meaning": "A bonding pair, a lone pair or a multiple bond counted as one region of electron density."},
        {"term": "Tetrahedral", "meaning": "Four groups at the corners of a tetrahedron, 109.5 degrees apart."},
        {"term": "s character", "meaning": "Fraction of a hybrid orbital that comes from the s orbital (25% in sp3)."},
        {"term": "Orbital overlap", "meaning": "Region where two orbitals share space and a bonding pair of electrons is found."},
    ],
    "quick_facts": [
        "sp3 = 25% s + 75% p; sp2 = 33% s; sp = 50% s.",
        "H-C-H angle in methane = 109.5 degrees; C-C bond length in ethane about 0.154 nm.",
        "sp3 examples: CH4, C2H6, CH3OH, NH3, H2O, NH4+, diamond.",
        "Diamond: every carbon is sp3, bonded to four others in a giant tetrahedral lattice.",
    ],
    "exam_keywords": ["hybridisation", "promotion", "sp3", "tetrahedral", "109.5 degrees", "sigma bond",
                      "head-on overlap", "electron domain", "lone pair repulsion"],
    "comparison_tables": [
        {"title": "sp3 vs sp2 vs sp", "columns": ["Feature", "sp3", "sp2", "sp"],
         "rows": [
             ["Orbitals mixed", "1 s + 3 p", "1 s + 2 p", "1 s + 1 p"],
             ["Hybrid orbitals formed", "4", "3", "2"],
             ["Unhybridised p left", "0", "1", "2"],
             ["Character", "25% s, 75% p", "33% s, 67% p", "50% s, 50% p"],
             ["Geometry and angle", "Tetrahedral 109.5", "Trigonal planar 120", "Linear 180"],
             ["Bonds from carbon", "4 sigma", "3 sigma + 1 pi", "2 sigma + 2 pi"],
             ["Example", "CH4, C2H6", "C2H4", "C2H2"],
         ]},
    ],
    "summary_points": [
        "sp3 orbitals = four identical hybrids from one s + three p on the same atom.",
        "Carbon needs promotion first (2s2 2p2 -> 2s1 2p3) so that it has four unpaired electrons.",
        "The four orbitals point tetrahedrally at 109.5 degrees and make sigma bonds by head-on overlap.",
        "Four electron domains and no pi bond means sp3 (alkanes, alcohols, NH3, H2O).",
    ],
    "key_points_to_remember": [
        "1 s + 3 p = 4 sp3", "25% s : 75% p", "109.5 degrees, tetrahedral", "sigma = head-on overlap",
    ],
    "memory_hook": "S + 3P = 4 sp3: four domains, four sigma bonds, tetrahedron at 109.5 degrees.",
    "sources": ["FRIDAY built-in study library (Cambridge-style chemical bonding). Check details against your official syllabus."],
    "footer_line": "Draw it, label it, explain it - promotion, mixing, overlap.",
}


_SP2_SP = {
    "chapter_title": "sp2 and sp Hybridisation",
    "subject_line": "Chemical bonding - sp2 (alkenes) and sp (alkynes)",
    "what_is": (
        "In sp2 hybridisation one s and TWO p orbitals mix to give three sp2 orbitals in a flat "
        "trigonal-planar arrangement (120 degrees); one p orbital stays unhybridised and sticks out "
        "above and below the plane to form a pi bond. In sp hybridisation one s and ONE p mix to give "
        "two sp orbitals 180 degrees apart (linear); two p orbitals stay unhybridised and form two pi bonds."
    ),
    "topic_coverage": [
        "sp2: 1 s + 2 p -> 3 sp2 orbitals, planar, 120 degrees, one leftover p orbital",
        "sp: 1 s + 1 p -> 2 sp orbitals, linear, 180 degrees, two leftover p orbitals",
        "Sigma bonds (head-on overlap) versus pi bonds (sideways overlap of p orbitals)",
        "Ethene C2H4: C=C is one sigma + one pi; planar molecule; no rotation about C=C",
        "Ethyne C2H2: C-C is one sigma + two pi; linear molecule",
        "Why pi bonds make alkenes reactive (electron-rich region above and below the plane)",
    ],
    "key_points": [
        "Number of hybrid orbitals = number of orbitals mixed (sp2 gives 3, sp gives 2).",
        "sp2 carbon: three sigma bonds, one pi bond, 120 degrees, trigonal planar (C=C, C=O, benzene).",
        "sp carbon: two sigma bonds, two pi bonds, 180 degrees, linear (C-triple-C, C-triple-N).",
        "A pi bond is a sideways overlap of unhybridised p orbitals, above and below the bond axis; it is weaker and more exposed than a sigma bond.",
        "The pi bond stops rotation: rotation would break the sideways overlap, which leads to cis/trans (E/Z) isomers.",
        "Count sigma bonds + lone pairs on the atom: 4 = sp3, 3 = sp2, 2 = sp.",
    ],
    "equation": "sp2: 1 s + 2 p -> 3 sp2 (+ 1 p left)   |   sp: 1 s + 1 p -> 2 sp (+ 2 p left)",
    "equation_explanation": "Promoted carbon is 2s1 2p3. For sp2 the 2s and two 2p mix; the third 2p is left for the pi bond. For sp the 2s and one 2p mix; two 2p are left.",
    "process_steps": [
        {"title": "Promote", "explanation": "Carbon 2s2 2p2 becomes 2s1 2p3 so there are four unpaired electrons."},
        {"title": "Mix only some p orbitals", "explanation": "sp2: mix the 2s with two of the 2p orbitals. sp: mix the 2s with one 2p orbital. The unmixed p orbitals keep their dumb-bell shape."},
        {"title": "Arrange to minimise repulsion", "explanation": "Three sp2 orbitals spread out in a plane at 120 degrees. Two sp orbitals point opposite each other at 180 degrees."},
        {"title": "Sigma bonds first", "explanation": "The hybrid orbitals overlap head-on with H 1s or with hybrids on the other carbon, making all the sigma bonds and the molecule's skeleton."},
        {"title": "Then pi bonds", "explanation": "Unhybridised p orbitals on neighbouring carbons overlap sideways above and below the plane. C=C = 1 sigma + 1 pi; C-triple-C = 1 sigma + 2 pi."},
    ],
    "key_ideas": [
        {"name": "Ethene, C2H4 (sp2)", "explanation": "Each carbon: three sp2 orbitals (two to H, one to the other C) and one p orbital. Five sigma bonds + one pi bond. All six atoms lie in one plane, H-C-H about 120 degrees."},
        {"name": "Ethyne, C2H2 (sp)", "explanation": "Each carbon: two sp orbitals (one to H, one to the other C) and two p orbitals. Three sigma bonds + two pi bonds. The molecule is linear, H-C-C = 180 degrees."},
        {"name": "Why alkenes react", "explanation": "The pi electron cloud lies above and below the molecule where electrophiles can reach it, and the pi bond is weaker than the sigma bond, so addition reactions break the pi bond first."},
    ],
    "reference_outline": [
        {"number": 1, "title": "What is sp2?", "content": "One s + two p orbitals mix to form three planar hybrids at 120 degrees. One p orbital is left over.", "bullets": ["33% s character", "trigonal planar"]},
        {"number": 2, "title": "What is sp?", "content": "One s + one p orbital mix to form two hybrids 180 degrees apart. Two p orbitals are left over.", "bullets": ["50% s character", "linear"]},
        {"number": 3, "title": "Sigma and pi", "content": "Sigma: head-on overlap along the axis. Pi: sideways overlap of parallel p orbitals above and below the axis.", "bullets": ["single bond = 1 sigma", "double = 1 sigma + 1 pi", "triple = 1 sigma + 2 pi"]},
    ],
    "diagrams": [
        {"kind": "energy",
         "title": "Carbon: promotion then sp2 hybridisation",
         "caption": "Three sp2 orbitals (one electron each) form the sigma skeleton; the remaining 2p electron forms the pi bond.",
         "columns": [
             {"title": "Promoted (2s1 2p3)", "levels": [
                 {"label": "2p", "energy": 2.0, "boxes": [1, 1, 1]},
                 {"label": "2s", "energy": 1.0, "boxes": [1]}]},
             {"title": "sp2 hybridised: 3 sp2 + 1 p", "levels": [
                 {"label": "2p", "energy": 2.0, "boxes": [1]},
                 {"label": "sp2", "energy": 1.4, "boxes": [1, 1, 1]}]},
         ],
         "transitions": ["mix 1 s + 2 p (one p left over)"]},
        {"kind": "molecule3d", "title": "sp2 centre: trigonal planar (e.g. C in ethene)",
         "caption": "Three sigma bonds in one plane at 120 degrees; the unhybridised p orbital points above and below the plane.",
         "shape": "trigonal_planar", "center": "C", "substituents": ["H", "H", "C"], "angle_label": "bond angle = 120 degrees"},
        {"kind": "molecule3d", "title": "sp centre: linear (e.g. C in ethyne)",
         "caption": "Two sigma bonds 180 degrees apart; two p orbitals at right angles form the two pi bonds.",
         "shape": "linear", "center": "C", "substituents": ["H", "C"], "angle_label": "bond angle = 180 degrees"},
    ],
    "worked_examples": [
        {"question": "Describe the bonding in ethene in terms of orbitals.",
         "answer": "Each carbon is sp2: three sp2 orbitals form sigma bonds (two C-H by sp2-1s overlap, one C-C by sp2-sp2). The unhybridised 2p orbitals on the two carbons overlap sideways above and below the plane to form one pi bond. So C=C = 1 sigma + 1 pi; the molecule is planar with 120 degree angles."},
        {"question": "Why is there no free rotation about the C=C bond?",
         "answer": "Rotating one CH2 group would twist the two p orbitals out of parallel alignment, breaking the sideways overlap of the pi bond. This restricted rotation gives cis/trans (E/Z) isomerism."},
    ],
    "common_mistakes": [
        "Saying the pi bond is made by hybrid orbitals. Pi bonds come from unhybridised p orbitals.",
        "Drawing the pi bond between the nuclei. It lies above and below the bond axis.",
        "Forgetting that a double bond is one sigma + one pi, not two identical bonds.",
    ],
    "exam_tips": [
        "Always separate the sigma framework from the pi bond in your answer.",
        "Quote the shape and angle with the hybridisation: sp2 trigonal planar 120, sp linear 180.",
        "Use 'sideways overlap of p orbitals' for pi and 'head-on overlap' for sigma.",
    ],
    "vocabulary": [
        {"term": "Pi (pi) bond", "meaning": "Bond from sideways overlap of parallel p orbitals above and below the bond axis."},
        {"term": "Unhybridised p orbital", "meaning": "A p orbital not used in mixing; it forms the pi bond(s)."},
        {"term": "Trigonal planar", "meaning": "Three groups in one plane, 120 degrees apart."},
    ],
    "comparison_tables": [
        {"title": "Sigma vs pi bonds", "columns": ["Feature", "Sigma", "Pi"],
         "rows": [["Overlap", "Head-on, on the axis", "Sideways, above and below the axis"],
                  ["Orbitals used", "s, p or hybrid", "Unhybridised p only"],
                  ["Strength", "Stronger", "Weaker, more reactive"],
                  ["Rotation", "Free", "Restricted"]]},
    ],
    "summary_points": ["sp2 = 3 hybrids + 1 p (planar, 120); sp = 2 hybrids + 2 p (linear, 180).", "Pi bonds come from unhybridised p orbitals."],
    "key_points_to_remember": ["sp2: 120 degrees", "sp: 180 degrees", "double = 1 sigma + 1 pi", "triple = 1 sigma + 2 pi"],
    "memory_hook": "Fewer p orbitals mixed = more p orbitals left for pi bonds: sp3 (0), sp2 (1), sp (2).",
    "sources": ["FRIDAY built-in study library (Cambridge-style chemical bonding). Check details against your official syllabus."],
    "footer_line": "Sigma skeleton first, pi bonds on top.",
}


_NEWTON = {
    "chapter_title": "Newton's Laws of Motion",
    "subject_line": "Dynamics - force, mass and acceleration",
    "what_is": (
        "Newton's three laws link force and motion. Law 1: a body stays at rest or moves at constant "
        "velocity unless a resultant force acts on it. Law 2: the resultant force equals the rate of "
        "change of momentum, F = ma for constant mass. Law 3: when body A exerts a force on body B, B exerts "
        "an equal and opposite force on A, of the same type, acting on a different body."
    ),
    "topic_coverage": [
        "Law 1 and inertia; equilibrium when the resultant force is zero",
        "Law 2: F = ma and F = change in momentum / time; direction of the resultant force",
        "Law 3: force pairs (equal, opposite, same type, different bodies)",
        "Free-body diagrams and resolving forces",
        "Weight, normal contact force, friction, tension, drag",
        "Solving problems with F = ma together with the equations of motion",
    ],
    "key_points": [
        "Resultant force is a vector sum. Zero resultant means constant velocity (possibly zero).",
        "F = ma: acceleration has the same direction as the resultant force; unit of force: newton, N = kg m s-2.",
        "Weight W = mg is the gravitational force on a mass; mass (kg) is not weight (N).",
        "Newton 3 pairs act on DIFFERENT bodies, so they never cancel each other out.",
        "Terminal velocity: drag + upthrust = weight so resultant is zero and acceleration is zero.",
        "Momentum p = mv; impulse = F t = change in momentum.",
    ],
    "equation": "F = ma      p = mv      F = (mv - mu) / t",
    "equation_explanation": "F = resultant force (N); m = mass (kg); a = acceleration (m s-2); p = momentum (kg m s-1); u, v = initial and final velocity (m s-1); t = time (s).",
    "process_steps": [
        {"title": "Draw a free-body diagram", "explanation": "Sketch the object alone and draw every force acting ON it as an arrow from its centre: weight, normal force, tension, friction, drag."},
        {"title": "Choose axes", "explanation": "Pick a positive direction along the motion and resolve any angled force into components parallel and perpendicular to it."},
        {"title": "Find the resultant", "explanation": "Add forces along each axis with signs. Along the acceleration axis: resultant = forces forward minus forces backward."},
        {"title": "Apply F = ma", "explanation": "Set the resultant equal to ma to find a (or F or m)."},
        {"title": "Link to motion", "explanation": "Use v = u + at, s = ut + 1/2 a t2, v2 = u2 + 2as to get velocity, time or distance."},
    ],
    "key_ideas": [
        {"name": "Inertia", "explanation": "The reluctance of a mass to change its velocity. Larger mass = larger inertia = smaller acceleration for the same force."},
        {"name": "Third-law pairs", "explanation": "Earth pulls a book down (gravity) and the book pulls the Earth up (gravity): equal, opposite, same type, on different bodies. The book's weight and the table's support force are NOT a third-law pair."},
        {"name": "Resultant vs individual forces", "explanation": "Only the resultant force determines acceleration. A car at constant speed still has engine force and drag - they simply balance."},
    ],
    "reference_outline": [
        {"number": 1, "title": "Newton's first law", "content": "No resultant force means no change in velocity.", "bullets": ["Objects keep moving at constant velocity", "Explains why seat belts are needed"]},
        {"number": 2, "title": "Newton's second law", "content": "Resultant force = mass x acceleration.", "bullets": ["Vector equation", "1 N gives 1 kg an acceleration of 1 m s-2"]},
        {"number": 3, "title": "Newton's third law", "content": "Forces come in equal and opposite pairs acting on different bodies.", "bullets": ["Same type of force", "Same line of action"]},
    ],
    "diagrams": [
        {"kind": "hub", "center": "Newton's laws",
         "title": "The three laws at a glance",
         "caption": "Each law answers a different question: what happens with no force, how force changes motion, and how forces come in pairs.",
         "nodes": [
             {"label": "Law 1: Inertia", "detail": "Resultant force 0 -> constant velocity"},
             {"label": "Law 2: F = ma", "detail": "Resultant force causes acceleration in its own direction"},
             {"label": "Law 3: Pairs", "detail": "Equal, opposite, same type, different bodies"}]},
        {"kind": "flow",
         "title": "Method: solving a dynamics problem",
         "caption": "Follow the same five steps every time to get full method marks.",
         "nodes": [
             {"label": "Free-body diagram", "detail": "All forces acting on the object"},
             {"label": "Choose axes", "detail": "Resolve angled forces"},
             {"label": "Resultant", "detail": "Add forces with signs"},
             {"label": "F = ma", "detail": "Solve for a, F or m"},
             {"label": "Equations of motion", "detail": "Find v, s or t"}]},
    ],
    "worked_examples": [
        {"question": "A 1200 kg car accelerates from rest to 20 m/s in 8.0 s against a constant resistive force of 500 N. Find the driving force.",
         "answer": "a = (20 - 0)/8.0 = 2.5 m/s2. Resultant = ma = 1200 x 2.5 = 3000 N. Driving force = resultant + resistance = 3000 + 500 = 3500 N."},
    ],
    "common_mistakes": [
        "Treating weight and the normal force as a Newton-3 pair. They act on the same body.",
        "Using mass in newtons or weight in kilograms.",
        "Forgetting that F in F = ma is the RESULTANT force.",
    ],
    "exam_tips": [
        "State Newton's laws with the key words: 'resultant force', 'rate of change of momentum', 'equal and opposite', 'same type', 'different bodies'.",
        "Always draw and label a free-body diagram before calculating.",
        "Give a sign convention and units (N, m s-2) on every line.",
    ],
    "vocabulary": [
        {"term": "Resultant force", "meaning": "Vector sum of all forces acting on a body."},
        {"term": "Inertia", "meaning": "Resistance of a body to a change in its velocity; measured by mass."},
        {"term": "Momentum", "meaning": "Product of mass and velocity, p = mv."},
        {"term": "Newton", "meaning": "The force that gives a 1 kg mass an acceleration of 1 m s-2."},
    ],
    "summary_points": ["No resultant force -> no acceleration.", "Resultant force = ma.", "Forces always come in third-law pairs on different bodies."],
    "key_points_to_remember": ["F = ma", "N = kg m s-2", "W = mg", "Newton-3 pairs never cancel"],
    "memory_hook": "One: no force, no change. Two: F = ma. Three: pairs on different bodies.",
    "sources": ["FRIDAY built-in study library (Cambridge-style dynamics). Check details against your official syllabus."],
    "footer_line": "Draw the forces first, then use F = ma.",
}


def _match(topic: str):
    t = (topic or "").lower()
    t = t.replace("\u00b3", "3").replace("\u00b2", "2")
    if re.search(r"\bsp\s*-?\s*3\b|sp3d", t) and not re.search(r"sp3d", t):
        return _SP3
    if re.search(r"\bsp\s*-?\s*2\b|\bsp\s+(?:hybrid|orbital)|\bpi\s+bond|\bsigma\s+and\s+pi", t):
        return _SP2_SP
    if re.search(r"hybridi[sz]ation|hybrid\s+orbital", t):
        return _SP3
    if re.search(r"newton|laws?\s+of\s+motion|\bf\s*=\s*ma\b", t):
        return _NEWTON
    return None


def find_entry(topic, subject_label=""):
    """Return a deep copy of a matching library entry, or None."""
    entry = _match(topic)
    if entry is None:
        return None
    out = copy.deepcopy(entry)
    if subject_label and str(subject_label).strip().lower() not in ("general", ""):
        out["subject_line"] = f"{subject_label} - {out.get('subject_line', '')}".strip(" -")
    return out
