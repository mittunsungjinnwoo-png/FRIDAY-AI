import re, pathlib, py_compile
ROOT=pathlib.Path(__file__).resolve().parent
for p in ROOT.glob("*.py"): py_compile.compile(str(p),doraise=True)
import friday_v96_runtime as v
names={x["name"] for x in v.tool_catalog()}
required={"desktop.control","desktop.windows","desktop.apps","filesystem.control","browser.control","media.control","system.info"}
assert required <= names, names
assert v.permission_level("delete all files")[0] == 4
assert v.permission_level("send a message")[0] == 3
assert v.permission_level("open chrome")[0] == 1
assert v.permission_level("what is my cpu usage")[0] == 0
print("FRIDAY v2002 integration smoke tests: PASS")
