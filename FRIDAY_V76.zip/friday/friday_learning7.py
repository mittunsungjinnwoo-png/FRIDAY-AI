"""FRIDAY 7.0 feedback-driven learning (roadmap #8).

Learns from evidence only - corrections, failed tasks, approved outcomes and benchmark results - and changes *retrieval, routing
bias and workflow templates*.  Nothing here trains a model.  A change needs at least two independent pieces of evidence, is shown as
a lesson you can read, apply or undo, and is applied automatically only when autonomy is set to "independent".

    observe(kind, goal, detail)   store one piece of evidence (correction | failure | approval | benchmark | route)
    hint_for(goal)                an approved, verified plan from a similar earlier success (used by the planner)
    adjust_plan(plan_info, goal)  applies active tool-swap lessons to a freshly made plan (used by the orchestrator)
    lessons / apply / undo        the reviewable lessons
"""
from __future__ import annotations

import copy
import re
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS feedback7(id INTEGER PRIMARY KEY, ts REAL, kind TEXT, goal TEXT, route TEXT, tool TEXT, detail TEXT, ref TEXT);
CREATE TABLE IF NOT EXISTS examples7(id INTEGER PRIMARY KEY, ts REAL, goal TEXT, plan TEXT, template TEXT, ratio REAL, approved INTEGER DEFAULT 0, ref TEXT, uses INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS lessons7(id INTEGER PRIMARY KEY, ts REAL, kind TEXT, key TEXT UNIQUE, text TEXT, evidence INTEGER DEFAULT 0, status TEXT DEFAULT 'proposed', data TEXT, applied_ts REAL);
""")

NEEDED_EVIDENCE = 2
_last = {"route": "", "question": "", "answer": "", "jid": "", "goal": "", "ts": 0.0}


# ------------------------------------------------------------------ evidence
def observe(kind: str, goal: str = "", detail: str = "", route: str = "", tool: str = "", ref: str = "") -> int:
    i = C.x("INSERT INTO feedback7(ts,kind,goal,route,tool,detail,ref) VALUES(?,?,?,?,?,?,?)", (C.now(), kind, C.clip(goal, 200), route, tool, C.clip(C.redact(detail), 300), ref))
    try:
        _consider(kind, goal, route, tool)
    except Exception as exc:
        C.log(f"learning consider failed safely: {exc}", "recovery")
    return i


def _goal_type(goal: str) -> str:
    try:
        import friday_planner7 as P
        for name, pred, _ in P.TEMPLATES:
            if pred(goal):
                return name
    except Exception:
        pass
    return "general"


def _consider(kind: str, goal: str, route: str, tool: str):
    if kind == "failure" and tool:
        gt = _goal_type(goal)
        n = C.q("SELECT COUNT(*) c FROM feedback7 WHERE kind='failure' AND tool=? AND goal<>''", (tool,))
        # evidence counts only failures of that tool within the same goal type
        rows = C.q("SELECT goal FROM feedback7 WHERE kind='failure' AND tool=?", (tool,))
        c = sum(1 for r in rows if _goal_type(r["goal"]) == gt)
        alt = _alternative_for(tool, gt)
        if c >= NEEDED_EVIDENCE and alt:
            _propose("tool_swap", f"{gt}:{tool}", f"For {gt.replace('_', ' ')} tasks, '{tool}' failed {c} times; use '{alt}' first.", c, {"goal_type": gt, "from": tool, "to": alt})
    elif kind == "correction" and route:
        c = C.q("SELECT COUNT(*) c FROM feedback7 WHERE kind='correction' AND route=?", (route,))[0]["c"]
        if c >= NEEDED_EVIDENCE:
            _propose("route_bias", f"route:{route}", f"You corrected me {c} times after answers sent through the '{route}' route; lower its preference slightly.", c, {"route": route, "delta": -0.08})
    elif kind == "route" and route:
        # an explicit "that should have gone to X" - the router keeps the bias; a lesson records it so it is reviewable
        c = C.q("SELECT COUNT(*) c FROM feedback7 WHERE kind='route' AND route=?", (route,))[0]["c"]
        if c >= NEEDED_EVIDENCE:
            _propose("route_bias", f"prefer:{route}", f"You asked for the '{route}' route {c} times for requests like these; prefer it.", c, {"route": route, "delta": 0.08})


def _alternative_for(tool: str, goal_type: str) -> str:
    pairs = {"investigate": "web_research", "web_research": "think", "cost_recipe": "calc", "repair_inspect": "code_review", "capture_verify": "system_info", "synthesize": "think"}
    return pairs.get(tool, "")


def _propose(kind: str, key: str, text: str, evidence: int, data: Dict) -> int:
    r = C.q("SELECT id,status FROM lessons7 WHERE key=?", (key,))
    if r:
        C.x("UPDATE lessons7 SET evidence=?, text=? WHERE id=?", (evidence, text, r[0]["id"]))
        return r[0]["id"]
    lid = C.x("INSERT INTO lessons7(ts,kind,key,text,evidence,status,data) VALUES(?,?,?,?,?,?,?)", (C.now(), kind, key, text, evidence, "proposed", K.jd(data)))
    K.emit("lesson.proposed", {"id": lid, "text": text})
    if K.cfg_get("autonomy_level") == "independent":
        apply(lid)
    return lid


# ------------------------------------------------------------------ lessons
def lessons(status: Optional[str] = None, n: int = 20) -> List[Dict]:
    rows = C.q("SELECT * FROM lessons7 " + ("WHERE status=? " if status else "") + "ORDER BY id DESC LIMIT ?", ((status, n) if status else (n,)))
    return [{"id": r["id"], "kind": r["kind"], "text": r["text"], "evidence": r["evidence"], "status": r["status"], "data": K.jl(r["data"], {})} for r in rows]


def apply(lid: int) -> Dict:
    r = C.q("SELECT * FROM lessons7 WHERE id=?", (lid,))
    if not r:
        return {"ok": False, "error": "no such lesson"}
    row, data = r[0], K.jl(r[0]["data"], {})
    if row["status"] == "active":
        return {"ok": True, "text": row["text"]}
    if row["kind"] == "route_bias":
        try:
            import friday_router7 as R
            before = R.get_bias(data["route"]) if hasattr(R, "get_bias") else 0.0
            R.set_bias(data["route"], before + float(data["delta"]))
            data["before"] = before
        except Exception as exc:
            return {"ok": False, "error": f"couldn't change the routing bias: {exc}"}
    # tool_swap lessons are read live by adjust_plan; nothing else to change
    C.x("UPDATE lessons7 SET status='active', data=?, applied_ts=? WHERE id=?", (K.jd(data), C.now(), lid))
    return {"ok": True, "text": row["text"]}


def undo(lid: int) -> Dict:
    r = C.q("SELECT * FROM lessons7 WHERE id=?", (lid,))
    if not r:
        return {"ok": False, "error": "no such lesson"}
    row, data = r[0], K.jl(r[0]["data"], {})
    if row["kind"] == "route_bias" and row["status"] == "active" and "before" in data:
        try:
            import friday_router7 as R
            R.set_bias(data["route"], float(data["before"]))
        except Exception:
            pass
    C.x("UPDATE lessons7 SET status='undone' WHERE id=?", (lid,))
    return {"ok": True, "text": row["text"]}


def adjust_plan(plan_info: Dict, goal: str) -> Dict:
    """Apply active tool-swap lessons to a freshly made plan. Returns plan_info with 'learning' notes when something changed."""
    notes = []
    gt = _goal_type(goal)
    for l in lessons("active", 50):
        d = l["data"]
        if l["kind"] != "tool_swap" or d.get("goal_type") != gt:
            continue
        for s in plan_info.get("steps", []):
            if s.get("tool") == d.get("from"):
                alts = [a for a in (s.get("alternatives") or []) if a.get("tool") == d.get("to")]
                if alts:
                    s["alternatives"] = [{"tool": s["tool"], "args": s.get("args", {}), "desc": s.get("desc", "")}] + [a for a in s["alternatives"] if a is not alts[0]]
                    s["tool"], s["args"] = alts[0]["tool"], alts[0].get("args", s.get("args", {}))
                    notes.append(f"lesson {l['id']}: used {d['to']} instead of {d['from']}")
    if notes:
        plan_info["learning"] = notes
    return plan_info


# ------------------------------------------------------------------ approved examples (retrieval - the safest kind of learning)
def _on_job_done(p: Dict):
    if not p:
        return
    goal, state, ratio = p.get("goal", ""), p.get("state"), float(p.get("verified_ratio") or 0)
    _last.update({"jid": p.get("jid", ""), "goal": goal, "ts": C.now()})
    if str(goal).startswith("benchmark"):
        return
    if state == "done" and ratio >= 0.6 and p.get("plan"):
        plan = copy.deepcopy(p["plan"])
        for s in plan:
            s["status"], s["attempts"] = "pending", 0
            s.pop("error", None)
        old = C.q("SELECT id FROM examples7 WHERE goal=?", (C.clip(goal, 200),))
        if old:
            C.x("UPDATE examples7 SET ts=?, plan=?, ratio=?, ref=? WHERE id=?", (C.now(), K.jd(plan), ratio, p.get("jid", ""), old[0]["id"]))
        else:
            C.x("INSERT INTO examples7(ts,goal,plan,template,ratio,approved,ref) VALUES(?,?,?,?,?,?,?)", (C.now(), C.clip(goal, 200), K.jd(plan), (p.get("plan_meta") or {}).get("template", ""), ratio, 0, p.get("jid", "")))
    for f in (p.get("failures") or [])[:3]:
        observe("failure", goal, f.get("error", ""), tool=f.get("tool", ""), ref=p.get("jid", ""))


def approve_last() -> Optional[str]:
    if not _last["jid"] or C.now() - _last["ts"] > 3600:
        return None
    r = C.q("SELECT id,goal FROM examples7 WHERE ref=? ORDER BY id DESC LIMIT 1", (_last["jid"],))
    if not r:
        return None
    C.x("UPDATE examples7 SET approved=1 WHERE id=?", (r[0]["id"],))
    observe("approval", r[0]["goal"], "user approved the outcome", ref=_last["jid"])
    return r[0]["goal"]


def hint_for(goal: str) -> Optional[Dict]:
    """The best approved (or strongly verified) earlier plan for a similar goal, or None. Retrieval only - the planner still scores it against fresh templates."""
    best, best_s = None, 0.0
    for r in C.q("SELECT * FROM examples7 WHERE ratio>=0.6 ORDER BY ts DESC LIMIT 60"):
        s = C.similarity(goal, r["goal"])
        s += 0.08 if r["approved"] else 0.0
        if s > best_s:
            best, best_s = r, s
    if not best or best_s < (0.62 if best["approved"] else 0.74):
        return None
    C.x("UPDATE examples7 SET uses=uses+1 WHERE id=?", (best["id"],))
    return {"plan": K.jl(best["plan"], []), "example_id": best["id"], "similarity": round(best_s, 2), "approved": bool(best["approved"])}


def examples(n: int = 10) -> List[Dict]:
    return [{"id": r["id"], "goal": r["goal"], "approved": bool(r["approved"]), "ratio": r["ratio"], "uses": r["uses"], "when": C.iso(r["ts"])} for r in C.q("SELECT * FROM examples7 ORDER BY ts DESC LIMIT ?", (n,))]


def note_exchange(route: str, question: str, answer: str):
    _last.update({"route": route or "", "question": question, "answer": answer})


def benchmark_result(name: str, ok: bool, detail: str = ""):
    observe("benchmark", name, ("passed" if ok else "FAILED") + (": " + detail if detail else ""), tool="" if ok else "benchmark")


def install_events():
    K.on("job.done", _on_job_done)
    K.on("route_used", lambda p: _last.update({"route": (p or {}).get("route", "")}))


# ------------------------------------------------------------------ chat
_RX_WRONG = re.compile(r"^(?:no[, ]+)?(?:that(?:'s| is| was)|this is|you(?:'re| are)) (?:not right|wrong|incorrect|not correct|not what i (?:asked|meant|wanted))\b|^that(?:'s| is) not (?:right|correct|what i (?:asked|meant))\b|^(?:wrong answer|you got that wrong|that was wrong)\b", re.I)
_RX_GOOD = re.compile(r"^(?:that(?:'s| was| is) )?(?:perfect|exactly (?:what i wanted|right)|spot on|well done|great job|good job|nailed it)\b.*(?:remember|keep|use that|next time|again)|^(?:remember|keep|save) (?:that|this) (?:way|approach|workflow|plan)\b|^(?:do|use) (?:it|that) (?:that|the same) way (?:next time|again)\b", re.I)
_RX_ROUTE = re.compile(r"^(?:that|this|it) should (?:have )?(?:gone|been (?:sent|handled)) (?:to|by|as) (?:the )?(?:a )?(code|coding|research|reasoning|general|fast|local)\b", re.I)


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if not t:
        return None
    if _RX_WRONG.match(t):
        observe("correction", _last["question"] or _last["goal"], t, route=_last["route"])
        n = C.q("SELECT COUNT(*) c FROM feedback7 WHERE kind='correction'")[0]["c"]
        return "Noted. I've logged that as a correction, and I'll treat repeats as evidence rather than guessing why. What was wrong with it?" if n else "Noted."
    m = _RX_ROUTE.match(t)
    if m:
        route = {"coding": "code", "fast": "instant", "local": "general"}.get(m.group(1).lower(), m.group(1).lower())
        try:
            import friday_router7 as R
            R.feedback(_last["question"] or t, route, 0.3)
        except Exception:
            pass
        observe("route", _last["question"], t, route=route)
        return f"Understood. I'll lean towards the {route} route for requests like that once I've seen it a couple of times."
    if _RX_GOOD.match(t):
        g = approve_last()
        return f"Good. I've kept that way of doing '{g[:60]}' as an approved example." if g else "Glad it worked. I don't have a finished mission from the last hour to keep as an example."
    if re.match(r"^(?:what have you learn(?:ed|t)|show (?:me )?(?:your )?lessons|what lessons)\??$", t):
        ls = lessons(n=6)
        if not ls:
            return "Nothing yet. I only propose a change after at least two separate pieces of evidence."
        return "Lessons so far: " + " ".join(f"({l['id']}, {l['status']}) {l['text']}" for l in ls[:4])
    m = re.match(r"^(?:apply|accept|adopt) lesson (\d+)$", t)
    if m:
        r = apply(int(m.group(1)))
        return ("Applied: " + r["text"]) if r["ok"] else r["error"].capitalize() + "."
    m = re.match(r"^(?:undo|revert|remove) lesson (\d+)$", t)
    if m:
        r = undo(int(m.group(1)))
        return ("Undone: " + r["text"]) if r["ok"] else r["error"].capitalize() + "."
    return None


def ui_snapshot() -> Dict:
    return {"lessons": lessons(n=20), "examples": examples(10), "feedback": [{"kind": r["kind"], "goal": r["goal"], "detail": r["detail"], "when": C.iso(r["ts"])} for r in C.q("SELECT * FROM feedback7 ORDER BY id DESC LIMIT 15")]}


def handle_ui(req: Dict) -> Optional[Dict]:
    a = req.get("action")
    if a == "lesson_apply":
        return apply(int(req.get("id", 0)))
    if a == "lesson_undo":
        return undo(int(req.get("id", 0)))
    return None
