@echo off
cd /d "%~dp0"
echo Installing Python 3.13 packages...
py -3.13 -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Python 3.13 package installation reported an error.
  echo Check the message above and make sure Python 3.13 is installed.
  pause
  exit /b 1
)
echo.
echo Installing optional accelerators (safe to fail)...
py -3.13 -m pip install --only-binary=:all: -r requirements-optional.txt
echo.
echo Installing Electron...
call npm install
echo.
echo Done. Put your Gemini API key in gemini_key.txt if you want free-form AI/research reasoning.
echo Start FRIDAY with START_FRIDAY.bat
pause
