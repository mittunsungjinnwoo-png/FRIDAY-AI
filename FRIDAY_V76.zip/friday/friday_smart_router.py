"""FRIDAY Smart Router v4010.1

Additive natural-language normalization and high-confidence routing.
It never changes speech capture, TTS, or existing task implementations.
It only turns common human phrasing into a canonical command before the
existing verified handlers see it.
"""
from __future__ import annotations
import re
from difflib import SequenceMatcher
from dataclasses import dataclass

_FILLERS = {
    "please", "pls", "plz", "kindly", "for me", "for us", "right now",
    "now", "thanks", "thank you", "if you can", "if u can", "could you",
    "can you", "can u", "would you", "will you", "would u", "hey friday",
    "friday", "sir", "mate", "bro"
}
_APP_ALIASES = {
    "whatsapp": ("whatsapp", "whats app", "what's app", "whatsap", "whats appp"),
    "chrome": ("chrome", "google chrome", "chrom"),
    "edge": ("edge", "microsoft edge"),
    "firefox": ("firefox", "fire fox"),
    "brave": ("brave", "brave browser"),
    "spotify": ("spotify", "spottyfy", "spotifi"),
    "discord": ("discord", "discrod"),
    "word": ("word", "microsoft word", "ms word", "winword"),
    "excel": ("excel", "microsoft excel", "ms excel"),
    "powerpoint": ("powerpoint", "power point", "microsoft powerpoint", "ms powerpoint"),
    "notepad": ("notepad", "note pad"),
    "calculator": ("calculator", "calc", "calcuator"),
    "settings": ("settings", "windows settings", "setting"),
    "file explorer": ("file explorer", "explorer", "windows explorer"),
    "vscode": ("vscode", "vs code", "visual studio code"),
}
_OPEN = re.compile(r"\b(open|launch|start|run|bring up|pull up|fire up|load)\b", re.I)
_CLOSE = re.compile(r"\b(close|quit|exit|terminate|end|kill|force close|force quit|shut)\b", re.I)

@dataclass(frozen=True)
class Route:
    kind: str
    target: str | None
    canonical: str
    confidence: float


def _clean(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"[\u2018\u2019]", "'", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip(" \t\r\n.,!?;:")


def _strip_fillers(s: str) -> str:
    out = _clean(s)
    # Repeatedly remove polite wrappers from either edge only. This prevents
    # accidentally deleting meaningful words in the middle of a request.
    changed = True
    while changed and out:
        changed = False
        low = out.lower()
        for f in sorted(_FILLERS, key=len, reverse=True):
            if low == f:
                return ""
            if low.startswith(f + " "):
                out = _clean(out[len(f):]); changed = True; break
            if low.endswith(" " + f):
                out = _clean(out[:-(len(f))]); changed = True; break
    return out


def _score(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def _target(text: str) -> tuple[str | None, float]:
    low = _clean(text).lower()
    # Exact/phrase matching first.
    best = (None, 0.0)
    for canonical, aliases in _APP_ALIASES.items():
        for alias in aliases:
            if re.search(r"(?<!\w)" + re.escape(alias) + r"(?!\w)", low):
                return canonical, 1.0
    # Only fuzzy-match a short candidate after a clear action verb. This keeps
    # ordinary conversation from becoming an accidental app command.
    tokens = low.split()
    if len(tokens) > 8:
        return best
    for canonical, aliases in _APP_ALIASES.items():
        for alias in aliases:
            for tok in tokens:
                score = _score(tok, alias)
                if score > best[1]:
                    best = (canonical, score)
    return best if best[1] >= 0.84 else (None, 0.0)


def classify(command: str) -> Route | None:
    original = _clean(command)
    if not original:
        return None
    normalized = _strip_fillers(original)
    low = normalized.lower()
    if not low:
        return None

    action = None
    if _OPEN.search(low): action = "open"
    elif _CLOSE.search(low): action = "close"
    if not action:
        return None

    target, conf = _target(low)
    if not target:
        return None

    # Do not route a sentence that contains a second independent clause; leave
    # compound reasoning to the normal semantic/AI pipeline.
    clauses = re.split(r"\b(?:and then|then|after that|while|but)\b", low)
    if len([x for x in clauses if x.strip()]) > 1:
        return None

    canonical = f"{action} {target}"
    confidence = conf
    if re.search(r"\b(?:for me|please|right now|now)\b", original.lower()):
        confidence = min(1.0, confidence + 0.02)
    return Route(action, target, canonical, confidence)


def health() -> dict:
    return {"version": "4010.1-smart-router", "apps": len(_APP_ALIASES), "speech_mechanism": "unchanged"}
