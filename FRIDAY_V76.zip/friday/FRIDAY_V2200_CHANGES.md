# FRIDAY V2200 - new dashboard UI + competition features
Only index.html changed (backend, main.js, preload.js, widget.html are untouched, so widget mode and the voice pipeline are the same).
- New layout: sidebar (Home, Chat, Tasks & Agents, Tools, Memory, Finance, Calendar, Files, Web & Research, Multimedia, Settings), top bar, right status panels, "Good morning, Sir."
- Arc reactor is now the hero orb. Replies are always spoken (backend speech; browser speech in preview).
- Finance page holds every existing input: Quick Input, Food & Ingredients, Income, Expenses, Monthly Plan, Savings & Goals, Weather, Reports, plus the weekly meal plan.
- Tasks & Agents: multi-step plan with live progress box in chat, pause/resume/cancel/retry, retry then fallback on failure, honest partial-success report, file-saved verification.
- Memory centre (add, correct, delete, temporary vs long-term, shows memories used). Say "remember that ..." / "forget ...".
- Permissions: approval before sending/calling, saving files, sending data out. All logged in the action log (Tasks page, bell icon).
- Files: images, CSV/TSV/text analysis (min, max, mean, trend), report export.
- Tools page: performance dashboard + 8-test benchmark suite.
Light/dark toggle is the sun icon. Run START_FRIDAY.bat as before.
