"""Read-only deployment audit for the complete FRIDAY v106 upgrade.

Run before FRIDAY on the target PC:
    py -3.13 friday_preflight.py

This script never opens apps, captures the display, uses the microphone,
contacts a service, or changes FRIDAY state.  It checks whether the local code
and optional feature dependencies are present, so the HUD can distinguish a
feature that is installed from one that still requires setup.
"""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

PROJECT_MODULES = (
    "friday_backend", "friday_agent_core", "friday_voice_engine",
    "friday_web_research", "friday_youtube_research", "friday_creation_engine",
    "friday_context", "friday_persona", "friday_notes_engine",
    "friday_system_control", "friday_screen_intelligence", "friday_omni_engine",
    "friday_advanced_agent", "friday_v96_runtime", "friday_peak_engine",
    "friday_feature_hardening", "friday_quality", "friday_reliability",
    "friday_desktop_agent", "friday_gemini_computer_use", "friday_truth_verifier",
    "friday_uia", "friday_system_control", "friday_zoom_notes", "friday_notes_engine",
)

PACKAGE_FEATURES = {
    "voice": ("speech_recognition", "pyttsx3"),
    "ai": ("google.genai", "dotenv", "requests"),
    "desktop_control": ("pyautogui", "pyperclip", "psutil"),
    "screen_capture": ("mss", "PIL"),
    "ocr": ("pytesseract",),
    "documents": ("docx", "pptx", "openpyxl", "pypdf"),
    "web_research": ("bs4", "lxml"),
    "youtube_research": ("youtube_transcript_api",),
    "enhanced_voice": ("numpy", "noisereduce", "faster_whisper"),
}


def _local_module(name: str) -> bool:
    return (ROOT / f"{name}.py").is_file() or (ROOT / name / "__init__.py").is_file()


def _package(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ModuleNotFoundError, ValueError):
        return False


def run() -> dict:
    modules = {name: _local_module(name) for name in PROJECT_MODULES}
    features = {
        name: {package: _package(package) for package in packages}
        for name, packages in PACKAGE_FEATURES.items()
    }
    return {
        "version": "v106 full upgrade",
        "project_modules_ok": all(modules.values()),
        "missing_project_modules": [name for name, ok in modules.items() if not ok],
        "feature_dependencies": features,
        "features_ready": {
            name: all(status.values()) for name, status in features.items()
        },
        "setup_required": [
            name for name, status in features.items() if not all(status.values())
        ],
        "notes": [
            "Gemini functions also require a valid API key pasted into GEMINI_API_KEY_INLINE_FALLBACK in friday_backend.py.",
            "OCR also requires the Tesseract Windows application.",
            "Live voice, screen, browser, WhatsApp, and UI behaviour must be tested on the target PC.",
        ],
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
