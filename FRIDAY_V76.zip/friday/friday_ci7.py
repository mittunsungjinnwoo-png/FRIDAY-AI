"""FRIDAY 7.0 continuous-integration and regression protection (roadmap #23).

A release gate that compares a build against the last KNOWN-GOOD build and refuses changes that break existing functionality:

    manifest   every project file hashed, and for every Python module the public functions / classes with their parameter lists
    protected  the listening and speaking engines must be byte-identical to the known-good build (hash check)
    compile    every .py compiles; every .js passes `node --check` when Node is installed
    compare    nothing public was removed or made stricter (a removed function, a dropped parameter, a new required parameter) and no file vanished
    tests      (optional, slower) the project's own test files run one after another in a time-limited subprocess; a test that passed in the
               known-good baseline and fails now is a regression

`gate()` returns {"pass": bool, "problems": [...], "warnings": [...]}.  `mark_good()` records a passing build as the new known-good one.
Command line:  python friday_ci7.py gate [--tests] [--root DIR] [--baseline FILE]
               python friday_ci7.py manifest ROOT OUT.json        (create a known-good manifest from a build)
Nothing here touches the microphone, recognition or speech code - it only reads files.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import py_compile
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional

try:
    import friday_common6 as C
    import friday_common7 as K
except Exception:                                   # the command-line use needs neither
    C = K = None                                    # type: ignore

HERE = Path(__file__).resolve().parent
PROTECTED = ["friday_voice5.py", "friday_speech5.py"]
SKIP_DIRS = {"__pycache__", "node_modules", "dist", "friday_data", ".git", "outputs", "apex_state", "repair_backups", "trash", "captures", "speech_cache", "attachments"}
HASHED_EXT = {".py", ".js", ".html", ".css", ".json", ".bat", ".md", ".txt"}
TEST_GLOB = re.compile(r"^(?:FRIDAY_TEST_.*|FRIDAY_SMOKE_TEST|friday_test_.*)\.py$", re.I)

if C is not None:
    C.register_schema("""
CREATE TABLE IF NOT EXISTS ci_runs7(id INTEGER PRIMARY KEY, ts REAL, root TEXT, passed INTEGER, problems TEXT, warnings TEXT, seconds REAL, tests TEXT);
""")


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _sig(fn: ast.AST) -> Dict:
    a = fn.args                                   # type: ignore[attr-defined]
    pos = [x.arg for x in a.posonlyargs + a.args]
    ndef = len(a.defaults)
    required = pos[:len(pos) - ndef] if ndef else pos
    kwonly = [x.arg for x in a.kwonlyargs]
    kw_required = [x.arg for x, d in zip(a.kwonlyargs, a.kw_defaults) if d is None]
    return {"pos": pos, "required": required, "kwonly": kwonly, "kw_required": kw_required, "varargs": bool(a.vararg), "varkw": bool(a.kwarg)}


def symbols(path: Path) -> Dict[str, Dict]:
    """Public top-level functions and classes (with public methods) of a module."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return {"__syntax_error__": {"kind": "error"}}
    out: Dict[str, Dict] = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and not node.name.startswith("_"):
            out[node.name] = {"kind": "def", **_sig(node)}
        elif isinstance(node, ast.ClassDef) and not node.name.startswith("_"):
            methods = {n.name: _sig(n) for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and (not n.name.startswith("_") or n.name == "__init__")}
            out[node.name] = {"kind": "class", "methods": methods}
    return out


def build_manifest(root: Path, with_symbols: bool = True) -> Dict:
    root = Path(root)
    files: Dict[str, str] = {}
    syms: Dict[str, Dict] = {}
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP_DIRS and not d.startswith(".")]
        for name in fn:
            p = Path(dp) / name
            if p.suffix.lower() not in HASHED_EXT:
                continue
            try:
                rel = p.relative_to(root).as_posix()
                if p.stat().st_size > 8_000_000:
                    continue
                files[rel] = _sha(p)
                if with_symbols and p.suffix == ".py":
                    syms[rel] = symbols(p)
            except Exception:
                continue
    return {"v": 1, "created": time.strftime("%Y-%m-%d %H:%M:%S"), "files": files, "symbols": syms, "protected": {f: files.get(f, "") for f in PROTECTED}}


def compare(old: Dict, new: Dict, protected: Optional[List[str]] = None) -> Dict:
    """What got worse between two manifests. `problems` block a release; `warnings` are for information."""
    problems: List[str] = []
    warnings: List[str] = []
    protected = protected if protected is not None else PROTECTED
    for f in protected:
        a, b = (old.get("files") or {}).get(f), (new.get("files") or {}).get(f)
        if a and not b:
            problems.append(f"protected file {f} is missing")
        elif a and a != b:
            problems.append(f"protected file {f} was changed (the listening and speaking engines must stay byte-identical)")
    of, nf = old.get("files") or {}, new.get("files") or {}
    for f in sorted(set(of) - set(nf)):
        if f.endswith(".py") or f.endswith(".js") or f.endswith(".html"):
            problems.append(f"file removed: {f}")
        else:
            warnings.append(f"file removed: {f}")
    os_, ns_ = old.get("symbols") or {}, new.get("symbols") or {}
    for f, osy in os_.items():
        nsy = ns_.get(f)
        if nsy is None:
            continue                                              # already reported as a removed file
        if "__syntax_error__" in nsy:
            problems.append(f"{f} no longer parses")
            continue
        for name, o in osy.items():
            n = nsy.get(name)
            if n is None:
                problems.append(f"{f}: public {o.get('kind')} '{name}' was removed")
                continue
            if o.get("kind") == "def" and n.get("kind") == "def":
                problems += _sig_problems(f, name, o, n)
            elif o.get("kind") == "class" and n.get("kind") == "class":
                for mn, om in (o.get("methods") or {}).items():
                    nm = (n.get("methods") or {}).get(mn)
                    if nm is None:
                        problems.append(f"{f}: method {name}.{mn} was removed")
                    else:
                        problems += _sig_problems(f, f"{name}.{mn}", om, nm)
            elif o.get("kind") != n.get("kind"):
                problems.append(f"{f}: '{name}' changed from a {o.get('kind')} to a {n.get('kind')}")
    changed = [f for f in nf if f in of and of[f] != nf[f]]
    added = [f for f in nf if f not in of]
    return {"problems": problems, "warnings": warnings, "changed": sorted(changed), "added": sorted(added), "removed": sorted(set(of) - set(nf))}


def _sig_problems(f: str, name: str, o: Dict, n: Dict) -> List[str]:
    out = []
    if n.get("varargs") and n.get("varkw"):
        return out
    dropped = [p for p in o.get("pos", []) if p not in n.get("pos", []) and not n.get("varkw")]
    if dropped and not n.get("varargs"):
        out.append(f"{f}: {name}() lost parameter(s) {', '.join(dropped)}")
    newly_required = [p for p in n.get("required", []) if p not in o.get("pos", [])]
    if newly_required:
        out.append(f"{f}: {name}() now requires new parameter(s) {', '.join(newly_required)}")
    stricter = [p for p in n.get("required", []) if p in o.get("pos", []) and p not in o.get("required", [])]
    if stricter:
        out.append(f"{f}: {name}() parameter(s) {', '.join(stricter)} lost their default value")
    newkw = [p for p in n.get("kw_required", []) if p not in o.get("kw_required", []) and p not in o.get("kwonly", [])]
    if newkw:
        out.append(f"{f}: {name}() now requires keyword argument(s) {', '.join(newkw)}")
    return out


def compile_all(root: Path) -> List[str]:
    bad = []
    tmp = tempfile.mkdtemp(prefix="ci7pyc")
    try:
        for p in Path(root).glob("*.py"):
            try:
                py_compile.compile(str(p), cfile=os.path.join(tmp, p.name + "c"), doraise=True)
            except py_compile.PyCompileError as exc:
                bad.append(f"{p.name}: {str(exc).splitlines()[-1][:160]}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return bad


def check_js(root: Path) -> Dict:
    node = shutil.which("node")
    if not node:
        return {"ran": False, "bad": []}
    bad = []
    for p in Path(root).glob("*.js"):
        try:
            r = subprocess.run([node, "--check", str(p)], capture_output=True, text=True, timeout=30)
            if r.returncode != 0:
                bad.append(f"{p.name}: {(r.stderr or '').strip().splitlines()[-1][:160] if r.stderr else 'syntax error'}")
        except Exception as exc:
            bad.append(f"{p.name}: could not be checked ({exc})")
    return {"ran": True, "bad": bad}


def run_test_file(root: Path, name: str, timeout: float = 240.0) -> Dict:
    env = dict(os.environ, FRIDAY_TESTING="1", PYTHONDONTWRITEBYTECODE="1")
    t0 = time.time()
    try:
        r = subprocess.run([sys.executable, "-m", "unittest", "-q", Path(name).stem], cwd=str(root), capture_output=True, text=True, timeout=timeout, env=env)
        out = (r.stdout or "") + (r.stderr or "")
    except subprocess.TimeoutExpired:
        return {"file": name, "ran": 0, "failed": ["<timeout>"], "seconds": round(time.time() - t0, 1), "ok": False}
    m = re.search(r"Ran (\d+) tests?", out)
    ran = int(m.group(1)) if m else 0
    failed = sorted(set(re.findall(r"^(?:FAIL|ERROR): (\S+) \(([^)]+)\)", out, re.M)))
    failed_ids = [f"{b}.{a}" for a, b in failed]
    if not m and r.returncode != 0:
        failed_ids = failed_ids or ["<did not run>"]
    return {"file": name, "ran": ran, "failed": failed_ids, "seconds": round(time.time() - t0, 1), "ok": r.returncode == 0}


def test_files(root: Path) -> List[str]:
    return sorted(p.name for p in Path(root).glob("*.py") if TEST_GLOB.match(p.name))


def run_tests(root: Path, only: Optional[List[str]] = None, timeout: float = 240.0) -> Dict[str, Dict]:
    out = {}
    for name in (only or test_files(root)):
        out[name] = run_test_file(root, name, timeout)
    return out


# ------------------------------------------------------------------ known-good store
def _store_dir(root: Path) -> Path:
    return Path(root) / "friday_data" / "ci7"


def load_known_good(root: Path, baseline: Optional[Path] = None) -> Optional[Dict]:
    cands = [Path(baseline)] if baseline else [_store_dir(root) / "known_good.json", _store_dir(root) / "known_good_63.json"]
    for c in cands:
        try:
            if c.exists():
                d = json.loads(c.read_text(encoding="utf-8"))
                d["_path"] = str(c)
                return d
        except Exception:
            continue
    return None


def gate(root: Optional[Path] = None, tests: bool = False, baseline: Optional[Path] = None, timeout: float = 240.0, only_tests: Optional[List[str]] = None) -> Dict:
    root = Path(root or HERE)
    t0 = time.time()
    problems: List[str] = []
    warnings: List[str] = []
    bad = compile_all(root)
    problems += [f"does not compile - {b}" for b in bad]
    js = check_js(root)
    problems += [f"JavaScript error - {b}" for b in js["bad"]]
    if not js["ran"]:
        warnings.append("Node.js was not found, so JavaScript files were not syntax-checked")
    new = build_manifest(root)
    old = load_known_good(root, baseline)
    cmp_res: Dict = {}
    if old is None:
        warnings.append("no known-good manifest was found - nothing to compare against (run 'mark this build as known good' once it passes)")
    else:
        cmp_res = compare(old, new)
        problems += cmp_res["problems"]
        warnings += cmp_res["warnings"]
    tres: Dict[str, Dict] = {}
    if tests:
        tres = run_tests(root, only_tests, timeout)
        base_tests = (old or {}).get("tests") or {}
        for name, r in tres.items():
            was_failing = set((base_tests.get(name) or {}).get("failed", []))
            new_fail = [f for f in r["failed"] if f not in was_failing]
            if new_fail:
                problems.append(f"tests: {name} has new failure(s): {', '.join(new_fail[:4])}" + (" ..." if len(new_fail) > 4 else ""))
            elif r["failed"]:
                warnings.append(f"tests: {name} still has {len(r['failed'])} failure(s) that were already failing in the known-good build")
    res = {"pass": not problems, "problems": problems, "warnings": warnings, "seconds": round(time.time() - t0, 1), "root": str(root), "compared_with": (old or {}).get("_path", ""),
           "changed": len(cmp_res.get("changed", [])), "added": len(cmp_res.get("added", [])), "removed": len(cmp_res.get("removed", [])), "tests": tres, "manifest": new}
    if C is not None:
        try:
            C.x("INSERT INTO ci_runs7(ts,root,passed,problems,warnings,seconds,tests) VALUES(?,?,?,?,?,?,?)",
                (C.now(), str(root), int(res["pass"]), json.dumps(problems), json.dumps(warnings), res["seconds"], json.dumps({k: {"ran": v["ran"], "failed": v["failed"]} for k, v in tres.items()})))
        except Exception:
            pass
    return res


def mark_good(root: Optional[Path] = None, tests: Optional[Dict[str, Dict]] = None, force: bool = False) -> Dict:
    root = Path(root or HERE)
    g = gate(root, tests=False)
    if not g["pass"] and not force:
        return {"ok": False, "error": "the build does not pass the gate, so it can't be marked as known good", "problems": g["problems"]}
    m = g["manifest"]
    if tests:
        m["tests"] = {k: {"ran": v["ran"], "failed": v["failed"]} for k, v in tests.items()}
    d = _store_dir(root)
    d.mkdir(parents=True, exist_ok=True)
    kg = d / "known_good.json"
    if kg.exists():
        shutil.copy2(kg, d / f"known_good_prev_{time.strftime('%Y%m%d_%H%M%S')}.json")
    tmp = kg.with_suffix(".tmp")
    tmp.write_text(json.dumps(m, separators=(",", ":")), encoding="utf-8")
    os.replace(tmp, kg)
    return {"ok": True, "path": str(kg), "files": len(m["files"])}


def spoken(res: Dict) -> str:
    if res["pass"]:
        s = f"The build passes the release gate: it compiles, nothing public was removed, and the listening and speaking engines are unchanged. {res['changed']} files changed, {res['added']} added."
        if res["warnings"]:
            s += f" {len(res['warnings'])} note(s)."
        return s
    return f"The build does NOT pass. {len(res['problems'])} problem(s): " + "; ".join(res["problems"][:3]) + ("." if len(res["problems"]) <= 3 else f"; and {len(res['problems']) - 3} more.")


def describe(res: Dict) -> str:
    lines = [("PASS" if res["pass"] else "FAIL") + f" - release gate on {res['root']} in {res['seconds']}s" + (f" (compared with {res['compared_with']})" if res["compared_with"] else "")]
    for p in res["problems"][:25]:
        lines.append("  ✗ " + p)
    for w in res["warnings"][:10]:
        lines.append("  ! " + w)
    if res.get("tests"):
        ran = sum(v["ran"] for v in res["tests"].values())
        lines.append(f"  tests: {ran} ran in {len(res['tests'])} file(s), {sum(len(v['failed']) for v in res['tests'].values())} failing")
    return "\n".join(lines)


# ------------------------------------------------------------------ chat
_RUNNING = {"on": False}


def handle(command: str) -> Optional[str]:
    if K is None:
        return None
    t = K.norm_cmd(command)
    if re.match(r"^(?:run|do|start) (?:the |a )?(?:release|ci|regression)(?: gate| checks?| tests?)?(?: (?:with|including) (?:the )?tests)?$|^check (?:this|the) build (?:against|with) (?:the )?(?:last )?known[- ]good(?: build)?$", t):
        if _RUNNING["on"]:
            return "A release check is already running."
        with_tests = bool(re.search(r"with (?:the )?tests|including (?:the )?tests", t))
        _RUNNING["on"] = True
        import threading

        def work():
            try:
                res = gate(tests=with_tests)
                K.emit_ui("ci_result", {"pass": res["pass"], "text": describe(res)})
                K.say(spoken(res))
            finally:
                _RUNNING["on"] = False
        threading.Thread(target=work, name="Friday7CI", daemon=True).start()
        return "Running the release checks" + (" including the test files, which takes a few minutes" if with_tests else "") + ". I'll tell you the result."
    if re.match(r"^mark (?:this|the) build as (?:the )?(?:last )?known[- ]good$|^save (?:this|the) build as (?:the )?known[- ]good$", t):
        r = mark_good()
        return f"Recorded this build as known good ({r['files']} files hashed)." if r["ok"] else f"I didn't record it: {r['error']}. First problems: " + "; ".join(r["problems"][:3])
    if re.match(r"^(?:release|ci) (?:status|history)$|^last release check$", t):
        rows = C.q("SELECT * FROM ci_runs7 ORDER BY id DESC LIMIT 3")
        if not rows:
            return "No release check has been run yet."
        return "\n".join(f"{C.iso(r['ts'])}: {'passed' if r['passed'] else 'FAILED'} in {r['seconds']:.0f}s" + ("" if r["passed"] else " - " + "; ".join(json.loads(r["problems"])[:2])) for r in rows)
    return None


def ui_snapshot() -> Dict:
    rows = C.q("SELECT * FROM ci_runs7 ORDER BY id DESC LIMIT 5") if C is not None else []
    return {"ci": [{"when": C.iso(r["ts"]), "passed": bool(r["passed"]), "problems": json.loads(r["problems"])[:5], "seconds": r["seconds"]} for r in rows]}


# ------------------------------------------------------------------ command line
def _main(argv: List[str]) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="FRIDAY release gate")
    sub = ap.add_subparsers(dest="cmd")
    g = sub.add_parser("gate")
    g.add_argument("--root", default=str(HERE))
    g.add_argument("--tests", action="store_true")
    g.add_argument("--baseline", default="")
    g.add_argument("--mark", action="store_true", help="record the build as known good if it passes")
    m = sub.add_parser("manifest")
    m.add_argument("root")
    m.add_argument("out")
    a = ap.parse_args(argv)
    if a.cmd == "manifest":
        man = build_manifest(Path(a.root))
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(json.dumps(man, separators=(",", ":")), encoding="utf-8")
        print(f"wrote {a.out}: {len(man['files'])} files, {sum(len(v) for v in man['symbols'].values())} public symbols")
        return 0
    if a.cmd == "gate":
        res = gate(Path(a.root), tests=a.tests, baseline=Path(a.baseline) if a.baseline else None)
        print(describe(res))
        if a.mark and res["pass"]:
            print(mark_good(Path(a.root), res.get("tests") or None))
        return 0 if res["pass"] else 1
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
