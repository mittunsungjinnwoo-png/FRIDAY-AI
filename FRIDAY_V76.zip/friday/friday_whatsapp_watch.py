"""
FRIDAY WhatsApp Incoming-Notification Watcher (V2046)
=======================================================
Additive, fully optional module. It has ONE job: notice when Windows
shows a toast notification from WhatsApp Desktop for an incoming
message, and report the chat name + preview text to a callback so
friday_backend.py can speak:

    "Sir, <chat name> sent you a message on WhatsApp.
     Would you like to reply?"

This is the mirror image of the existing outgoing-message feature
(handle_whatsapp_start / handle_whatsapp_continuation / whatsapp_confirm.js)
-- that pipeline is for messages the user asks Friday to SEND; this one is
for messages the user RECEIVES.

How it works
------------
Windows exposes every toast notification currently in Action Center
through `Windows.UI.Notifications.Management.UserNotificationListener`.
This is the same public API legitimate notification-mirroring utilities
use, and it requires one-time user consent (Windows shows a system
"Let this app access your notifications" prompt / it can be granted at
Settings > Privacy & security > Notifications > "Notification access").
No content is read for any app other than WhatsApp -- everything else is
inspected only far enough to check its app name, then discarded.

Design guarantees (matching the rest of this project's optional-feature
philosophy: edge-tts, noisereduce, faster-whisper, pywinauto, etc all
degrade to "silently skip" when unavailable):
- Windows-only. On any other OS, start_listener() logs one line and
  returns immediately.
- Requires the optional `winsdk` package. If it is not installed,
  start_listener() logs one line (with the pip-install hint) and
  returns immediately -- it never raises into the caller.
- If the user has not granted notification-listener access, logs one
  line once and returns; it does not nag or retry-spam.
- Polling only, no window hooks, no keyboard/mouse hooks, no reading of
  any non-WhatsApp notification content.
- Never sends, replies to, or dismisses anything itself -- it only
  reports what it saw. All reply composition/sending still goes through
  the existing, unmodified WhatsApp send pipeline in friday_backend.py.
"""
from __future__ import annotations

import platform
import threading
import time
import traceback
from typing import Callable, Optional

POLL_SECONDS = 3.0
_MAX_SEEN_IDS = 500

_started = False
_lock = threading.Lock()


def _is_whatsapp_source(app_display_name: str, app_user_model_id: str) -> bool:
    text = f"{app_display_name or ''} {app_user_model_id or ''}".lower()
    return "whatsapp" in text


def _binding_texts(notification) -> list[str]:
    """Pulls the ordered text lines out of a toast's visual binding.
    WhatsApp Desktop's toast puts the chat/contact name as the first
    text line and the message preview as the second."""
    texts: list[str] = []
    try:
        visual = notification.notification.visual
        binding = visual.get_binding(visual.bindings[0].template) if visual.bindings else None
    except Exception:
        binding = None
    if binding is None:
        try:
            binding = notification.notification.visual.bindings[0]
        except Exception:
            return texts
    try:
        for element in binding.get_text_elements():
            t = (element.text or "").strip()
            if t:
                texts.append(t)
    except Exception:
        pass
    return texts


async def _poll_once(listener, seen_ids: "set[int]", on_message: Callable[[str, str], None]) -> None:
    try:
        from winsdk.windows.ui.notifications import NotificationKinds
    except Exception:
        return
    try:
        notifications = await listener.get_notifications_async(NotificationKinds.TOAST)
    except Exception:
        return
    for n in notifications:
        try:
            nid = n.id
            if nid in seen_ids:
                continue
            seen_ids.add(nid)
            if len(seen_ids) > _MAX_SEEN_IDS:
                # Cheap unbounded-growth guard; exact eviction order doesn't matter.
                seen_ids.pop()

            app_info = n.app_info
            display_name = getattr(getattr(app_info, "display_info", None), "display_name", "") or ""
            aumid = getattr(app_info, "app_user_model_id", "") or ""
            if not _is_whatsapp_source(display_name, aumid):
                continue

            texts = _binding_texts(n)
            if not texts:
                continue
            chat_name = texts[0].strip()
            preview = texts[1].strip() if len(texts) > 1 else ""
            # Skip generic/system toasts with no real chat name (e.g. a
            # bare "WhatsApp" badge summary) -- nothing useful to announce.
            if not chat_name or chat_name.lower() == "whatsapp":
                continue
            on_message(chat_name, preview)
        except Exception:
            # One malformed notification must never stop the watcher.
            continue


_last_disabled_reason: Optional[str] = None  # V2048: surfaced by whatsapp_watch_status()


def _run_loop(on_message: Callable[[str, str], None], log: Callable[[str], None],
              on_disabled: Optional[Callable[[str], None]] = None) -> None:
    import asyncio
    global _last_disabled_reason

    def _disable(msg: str) -> None:
        global _last_disabled_reason
        _last_disabled_reason = msg
        log(msg)
        # V2048 FIX: previously these three "can't run" cases were only ever
        # written to the internal event log, which the user has no reason to
        # be looking at -- so the feature failed *silently* and "Friday never
        # tells me about WhatsApp messages" looked like a mystery bug rather
        # than a one-line, fixable setup issue. Speak it once instead.
        if on_disabled is not None:
            try:
                on_disabled(msg)
            except Exception:
                pass

    try:
        from winsdk.windows.ui.notifications.management import (
            UserNotificationListener,
            UserNotificationListenerAccessStatus,
        )
    except Exception as import_error:
        _disable(
            "I can't watch for incoming WhatsApp messages yet, sir -- the "
            f"'winsdk' package isn't installed ({import_error}). Running "
            "'pip install winsdk' and restarting me will enable it."
        )
        return

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    listener = UserNotificationListener.get_current()

    try:
        status = loop.run_until_complete(listener.request_access_async())
    except Exception as access_error:
        _disable(f"WhatsApp notification watcher disabled: could not request notification access ({access_error}).")
        return

    if status != UserNotificationListenerAccessStatus.ALLOWED:
        _disable(
            "I can't watch for incoming WhatsApp messages yet, sir -- notification "
            "access hasn't been granted. Enable it under Windows Settings, Privacy "
            "and security, Notifications, Notification access, then restart me."
        )
        return

    seen_ids: "set[int]" = set()
    _last_disabled_reason = None
    log("WhatsApp notification watcher active.")
    while True:
        try:
            loop.run_until_complete(_poll_once(listener, seen_ids, on_message))
        except Exception:
            traceback.print_exc()
        time.sleep(POLL_SECONDS)


def whatsapp_watch_status() -> dict:
    """Lightweight status check so normal-mode FRIDAY (or a diagnostics
    command) can report *why* incoming-WhatsApp notifications aren't
    working, instead of the user just never getting told anything."""
    return {
        "started": _started,
        "active": _started and _last_disabled_reason is None,
        "disabled_reason": _last_disabled_reason,
    }


def start_listener(on_message: Callable[[str, str], None], log: Optional[Callable[[str], None]] = None,
                    on_disabled: Optional[Callable[[str], None]] = None) -> bool:
    """Starts the background watcher thread. Safe to call unconditionally
    at startup -- it is a silent no-op on non-Windows platforms or when
    the optional dependency / OS permission isn't available.

    on_message(chat_name, preview_text) is called from a background
    thread whenever a new incoming WhatsApp toast notification is seen.
    on_disabled(reason_text), if given, is called once (from that same
    background thread) if the watcher can't run at all, so the caller can
    speak/surface the reason instead of it only reaching a log file.
    """
    global _started
    log = log or (lambda msg: print("[friday_whatsapp_watch]", msg))

    if platform.system() != "Windows":
        log("WhatsApp notification watcher disabled: Windows-only feature.")
        return False

    with _lock:
        if _started:
            return True
        _started = True

    threading.Thread(
        target=_run_loop,
        args=(on_message, log, on_disabled),
        name="Friday-WhatsApp-Watch",
        daemon=True,
    ).start()
    return True
