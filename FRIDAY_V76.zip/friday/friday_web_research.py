"""
FRIDAY WEB RESEARCH MODULE
==========================
Adds live web research to Friday: given a natural-language question,
it searches the web, fetches the most relevant pages IN PARALLEL,
extracts the readable text, and asks Gemini to synthesize a grounded,
spoken-style answer with sources -- instead of letting Gemini guess a
number from memory.

Pipeline (matches the architecture in the system-update notes):
    query -> search engine(s) -> candidate URLs -> parallel fetch +
    extract text -> Gemini synthesis (told to use ONLY the fetched
    text) -> answer + sources

This is a SEPARATE module by design. friday_backend.py only imports
the public functions it needs (run_web_research, gather_sources) and
calls them from handle_command() / the Creation Engine. Nothing in
friday_backend.py's existing logic had to change to use this.

------------------------------------------------------------
THIS UPDATE (accuracy + speed pass)
------------------------------------------------------------
- PARALLEL FETCHING: pages are now downloaded concurrently (bounded
  thread pool) instead of one at a time with a politeness sleep after
  each -- on a typical 6-page research turn this is the difference
  between roughly 6x a single page's fetch time and roughly 1-2x it.
- TWO SEARCH BACKENDS: DuckDuckGo's "lite" endpoint stays primary
  (fastest, no key needed), but if it returns too few usable results
  (site layout hiccup, temporary block, an unusual query) this now
  automatically falls back to DuckDuckGo's separate "html" endpoint
  before giving up -- so a single scraper hiccup no longer means "no
  results" for the whole turn.
- DOMAIN QUALITY FILTERING: a short blocklist of domains that are
  reliably useless to scrape this way (they require login or a JS
  app shell to show any real content -- Friday would otherwise spend
  a whole fetch slot on an empty page) is skipped before ever being
  requested, and results are de-duplicated by domain so Friday
  doesn't burn its whole source budget on four pages of the same
  site when a broader spread would answer better.
- SHORT-LIVED RESULT CACHE: identical (or near-identical) queries
  within a few minutes reuse the last result instead of re-scraping
  the web from scratch -- this is what makes an immediate follow-up
  like "make it into slides" (which the Context Engine turns back
  into a full research-shaped request when it can't reuse cached
  sources outright) feel instant rather than re-running the whole
  pipeline.
- run_web_research()'s returned dict now also includes the raw
  "_raw_sources" (url, full extracted text) pairs, not just the
  trimmed spoken answer + source list -- friday_context.py uses this
  to let the Creation Engine build a presentation/document straight
  from already-gathered material instead of researching twice.

HONEST LIMITS -- please read before relying on this:
- Still no paid search API key configured, so search is done by
  scraping DuckDuckGo's no-JS pages (now with the two-endpoint
  fallback above). This is inherently more fragile than a paid search
  API (SerpAPI, Bing Web Search, Google Custom Search) -- if
  DuckDuckGo changes either page's HTML, `_search_lite()` /
  `_search_html_fallback()` below are the two places that need
  updating.
- Sites that require JavaScript, login, or that show prices only
  after you fill in a form (this affects some airline sites,
  including singaporeair.com's own fare search) still cannot be read
  this way. When that happens this module says so instead of
  inventing a number -- it will never fabricate a price, and neither
  should you trust a fully-automated scrape of a price quote without
  a quick glance at the source link it gives you.
- For a small number of "which service has an official API"
  situations (the docx notes mention Singapore Airlines' KrisConnect
  API), a direct API integration will always be more reliable than
  this general-purpose scraper. That has to be built per-service
  with real API credentials -- it's a separate, later piece of work,
  not something a generic scraper can substitute for.
"""

import re
import time
import html
import requests
from urllib.parse import urlparse, urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed
from bs4 import BeautifulSoup

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
}

MAX_SOURCES = 4
MAX_CHARS_PER_PAGE = 6000
REQUEST_TIMEOUT = (8, 15)
FETCH_WORKERS = 5           # bounded concurrency -- polite, not a hammer
RESULT_CACHE_TTL = 600      # 10 minutes: long enough for an immediate
                             # follow-up to feel instant, short enough
                             # that prices/news don't go stale.

# Domains that are technically reachable but essentially never yield
# usable text through a plain HTML scrape (login walls, JS-only app
# shells, or endless cookie/consent interstitials). Skipping these
# before they ever consume a fetch slot leaves more of the (bounded)
# source budget for pages actually worth reading.
_LOW_VALUE_DOMAINS = (
    "pinterest.", "instagram.com", "facebook.com", "tiktok.com",
    "linkedin.com", "quora.com",
)


# ============================================================
# SHORT-LIVED RESULT CACHE
# ============================================================
# Keyed on the normalized query text. Never persisted to disk --
# this is purely about not re-scraping the SAME thing twice in the
# same few minutes, not a long-term memory concern (friday_context.py
# handles what actually needs to survive a restart).
_result_cache = {}   # normalized_query -> (timestamp, result_dict)


def _normalize_query(query):
    return re.sub(r"\s+", " ", (query or "").strip().lower())


def _cache_get(query):
    key = _normalize_query(query)
    entry = _result_cache.get(key)
    if not entry:
        return None
    timestamp, result = entry
    if (time.time() - timestamp) > RESULT_CACHE_TTL:
        _result_cache.pop(key, None)
        return None
    return result


def _cache_set(query, result):
    _result_cache[_normalize_query(query)] = (time.time(), result)


# ============================================================
# SEARCH
# ============================================================

def _domain_of(url):
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""


def _is_low_value(url):
    domain = _domain_of(url)
    return any(blocked in domain for blocked in _LOW_VALUE_DOMAINS)


def _dedupe_by_domain(urls, limit):
    """Keeps result ORDER (search-engine ranking) but only takes the
    first result per domain, so 4 pages from the same site can't crowd
    out a broader, more reliable spread of sources."""
    seen_domains = set()
    out = []
    for url in urls:
        if _is_low_value(url):
            continue
        domain = _domain_of(url)
        if domain in seen_domains:
            continue
        seen_domains.add(domain)
        out.append(url)
        if len(out) >= limit:
            break
    return out


def _extract_search_links(soup, max_results):
    """Extract outbound links from multiple DuckDuckGo/Bing HTML layouts."""
    results = []
    selectors = [
        "a.result__a", "a.result__url", "li.b_algo h2 a", "li.b_algo a",
        "a[href]",
    ]
    for selector in selectors:
        for a in soup.select(selector):
            href = a.get("href", "").strip()
            if not href.startswith("http"):
                continue
            if any(x in urlparse(href).netloc.lower() for x in ("duckduckgo.com", "bing.com")):
                continue
            if href not in results:
                results.append(href)
            if len(results) >= max_results:
                return results
    return results


def _http_search(url, query, max_results, method="get"):
    try:
        if method == "post":
            resp = requests.post(url, data={"q": query}, headers=_HEADERS, timeout=REQUEST_TIMEOUT)
        else:
            resp = requests.get(url, params={"q": query}, headers=_HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        return _extract_search_links(BeautifulSoup(resp.text, "html.parser"), max_results)
    except Exception as error:
        print(f"Web search error ({url}):", error)
        return []


def _search_lite(query, max_results):
    return _http_search("https://lite.duckduckgo.com/lite/", query, max_results, method="post")


def _search_html_fallback(query, max_results):
    return _http_search("https://html.duckduckgo.com/html/", query, max_results, method="post")


def _search_bing(query, max_results):
    # Public HTML results are a fallback only; no attempt is made to bypass
    # authentication, robots controls, CAPTCHAs, or access restrictions.
    return _http_search("https://www.bing.com/search", query, max_results, method="get")


def _query_variants(query):
    q = re.sub(r"\s+", " ", query.strip())
    variants = [q]
    if len(q.split()) >= 3:
        variants.extend([f"{q} official", f"{q} latest information"])
    return list(dict.fromkeys(variants))


def _search_web(query, max_results=12):
    """Multi-backend search with bounded retries and query broadening."""
    all_results = []
    for variant in _query_variants(query):
        backends = (_search_lite, _search_html_fallback, _search_bing)
        for backend in backends:
            results = backend(variant, max_results=max_results)
            for url in results:
                if url not in all_results:
                    all_results.append(url)
            if len(_dedupe_by_domain(all_results, max_results)) >= max_results:
                break
        if len(_dedupe_by_domain(all_results, max_results)) >= max_results:
            break
    return _dedupe_by_domain(all_results, max_results)


# ============================================================
# FETCH
# ============================================================

def _fetch_readable_text(url):
    """Fetch readable HTML with retries and a lightweight canonical redirect pass."""
    session = requests.Session()
    headers = dict(_HEADERS)
    headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    last_error = None
    for attempt in range(3):
        try:
            resp = session.get(url, headers=headers, timeout=REQUEST_TIMEOUT, allow_redirects=True)
            resp.raise_for_status()
            content_type = resp.headers.get("Content-Type", "").lower()
            if "html" not in content_type and "xml" not in content_type:
                return ""
            soup = BeautifulSoup(resp.text, "html.parser")
            canonical = soup.find("link", rel=lambda x: x and "canonical" in str(x).lower())
            if canonical and canonical.get("href"):
                canonical_url = urljoin(resp.url, canonical["href"])
                if canonical_url != resp.url and _domain_of(canonical_url) == _domain_of(resp.url):
                    try:
                        resp = session.get(canonical_url, headers=headers, timeout=REQUEST_TIMEOUT)
                        resp.raise_for_status()
                        soup = BeautifulSoup(resp.text, "html.parser")
                    except Exception:
                        pass
            for tag in soup(["script", "style", "noscript", "svg", "nav", "footer", "header", "form"]):
                tag.decompose()
            text = soup.get_text(separator=" ", strip=True)
            text = re.sub(r"\s+", " ", html.unescape(text))
            if len(text) >= 300:
                return text[:MAX_CHARS_PER_PAGE]
            last_error = RuntimeError("page contained too little readable text")
        except Exception as error:
            last_error = error
            time.sleep(0.25 * (attempt + 1))
    print(f"Web fetch error ({url}):", last_error)
    return ""


def _source_reliability(url: str, text: str, query: str) -> float:
    """Heuristic reliability score used only to prioritize sources.

    This is not a truth detector. It rewards primary/official domains,
    substantive pages and less spam-like URLs, while keeping a diversity of
    domains. Final synthesis is still instructed to cross-check claims.
    """
    domain = _domain_of(url).split(":", 1)[0].lower()
    score = 0.45
    if domain.endswith(".gov") or ".gov." in domain:
        score += 0.30
    if domain.endswith(".edu") or ".edu." in domain:
        score += 0.20
    if domain.endswith(".org"):
        score += 0.08
    if any(x in domain for x in ("reuters.com", "apnews.com", "bbc.com", "who.int", "un.org")):
        score += 0.18
    if len(text) >= 2000:
        score += 0.08
    if len(text) >= 5000:
        score += 0.04
    if any(x in url.lower() for x in ("login", "signup", "register", "utm_", "affiliate")):
        score -= 0.10
    if any(word in query.lower() for word in ("official", "government", "statistics", "policy")) and domain.endswith(".gov"):
        score += 0.08
    return max(0.0, min(1.0, score))


def _rank_sources(collected, query):
    scored = [(round(_source_reliability(url, text, query), 3), url, text) for url, text in collected]
    scored.sort(key=lambda item: item[0], reverse=True)
    return [(url, text) for _, url, text in scored]


def _wikipedia_fallback_source(query):
    """Last-resort source when every scraped search backend has come up
    empty. No API key, no scraping/robots concerns -- Wikipedia's own
    REST API, meant for exactly this kind of programmatic lookup.
    Returns (url, text) or None."""
    try:
        clean_query = re.sub(r"\s+", " ", query.strip())[:150]
        resp = requests.get(
            "https://en.wikipedia.org/api/rest_v1/page/summary/" + requests.utils.quote(clean_query),
            headers=_HEADERS, timeout=REQUEST_TIMEOUT,
        )
        if resp.status_code != 200:
            # Try the search endpoint to find the closest matching title first.
            search_resp = requests.get(
                "https://en.wikipedia.org/w/api.php",
                params={"action": "query", "list": "search", "srsearch": clean_query, "format": "json", "srlimit": 1},
                headers=_HEADERS, timeout=REQUEST_TIMEOUT,
            )
            search_resp.raise_for_status()
            hits = search_resp.json().get("query", {}).get("search", [])
            if not hits:
                return None
            title = hits[0]["title"]
            resp = requests.get(
                "https://en.wikipedia.org/api/rest_v1/page/summary/" + requests.utils.quote(title),
                headers=_HEADERS, timeout=REQUEST_TIMEOUT,
            )
            resp.raise_for_status()
        data = resp.json()
        extract = (data.get("extract") or "").strip()
        if len(extract) < 80:
            return None
        page_url = (data.get("content_urls", {}).get("desktop", {}) or {}).get("page") or "https://en.wikipedia.org"
        return (page_url, extract)
    except Exception as error:
        print("Wikipedia fallback source unavailable:", error)
        return None


def gather_sources(query, depth=4, search_pool=8, use_cache=True):
    """
    Search + PARALLEL fetch, returning [(url, text), ...] for pages
    that actually yielded usable text. Used both by run_web_research()
    below and by the Creation Engine when it needs deeper research
    for a document/presentation rather than a one-line answer.

    Fetches are done concurrently across up to FETCH_WORKERS pages at
    once (rather than one at a time with a sleep between each) --
    this is the main speed improvement in this update. Still capped
    and still a normal, identifiable browser User-Agent -- concurrent
    does not mean aggressive.
    """
    if use_cache:
        cached = _cache_get(f"__sources__{query}__{depth}")
        if cached is not None:
            return cached

    urls = _search_web(query, max_results=max(search_pool, 12))
    if not urls:
        # V2045 FIX: previously returned nothing at all here, which is
        # exactly the "Friday can never seem to get research results"
        # complaint whenever all three scraped search backends happened
        # to be blocked/rate-limited/down at once. Wikipedia's REST
        # summary API is a stable, key-free, dependency-light source
        # that almost never goes down the same way a scraped search
        # page does -- used here purely as a last-resort baseline so
        # the caller gets SOMETHING to ground an answer in, rather than
        # an empty list and "no sources found".
        fallback = _wikipedia_fallback_source(query)
        return [fallback] if fallback else []

    collected = []
    with ThreadPoolExecutor(max_workers=min(FETCH_WORKERS, len(urls))) as pool:
        future_to_url = {pool.submit(_fetch_readable_text, url): url for url in urls}
        for future in as_completed(future_to_url):
            url = future_to_url[future]
            try:
                text = future.result()
            except Exception as error:
                print(f"Web fetch task error ({url}):", error)
                continue
            if len(text) > 300:
                collected.append((url, text))

    # as_completed() finishes in whatever order pages happen to
    # download, not the search engine's ranking order -- restore that
    # ranking so the FIRST (depth-limited) sources are still the ones
    # the search engine actually ranked highest, not just whichever
    # server happened to respond fastest.
    rank = {url: i for i, url in enumerate(urls)}
    collected.sort(key=lambda pair: rank.get(pair[0], len(urls)))
    collected = _rank_sources(collected, query)[:depth]

    if use_cache:
        _cache_set(f"__sources__{query}__{depth}", collected)
    return collected


# ============================================================
# v95 RESEARCH QUALITY LAYER
# ============================================================
def _claim_fingerprint(text: str) -> set[str]:
    """Small, dependency-free lexical fingerprint for cross-source checks."""
    words = re.findall(r"[a-z0-9]{4,}", (text or "").lower())
    stop = {"that","this","with","from","have","were","they","their","about","which","would","could","there","where"}
    return {w for w in words if w not in stop}

def detect_cross_source_signals(collected):
    """Return conservative signals; these are NOT a truth detector."""
    if not collected:
        return {"sources_compared":0,"similarity_pairs":[],"possible_contradictions":[]}
    fingerprints=[(u,_claim_fingerprint(t)) for u,t in collected]
    pairs=[]; contradictions=[]
    contradiction_terms=(" however "," but "," unlike "," not "," no "," denied ","disputed ","instead of ")
    for i in range(len(fingerprints)):
        for j in range(i+1,len(fingerprints)):
            u1,w1=fingerprints[i]; u2,w2=fingerprints[j]
            union=len(w1|w2) or 1
            sim=len(w1&w2)/union
            if sim >= .12:
                pairs.append({"a":u1,"b":u2,"lexical_similarity":round(sim,3)})
            t1=next(t for u,t in collected if u==u1)
            t2=next(t for u,t in collected if u==u2)
            c1=sum(1 for x in contradiction_terms if x in " "+t1.lower()+" ")
            c2=sum(1 for x in contradiction_terms if x in " "+t2.lower()+" ")
            if sim >= .10 and c1 and c2:
                contradictions.append({"a":u1,"b":u2,"reason":"both sources contain disagreement/qualification language"})
    return {"sources_compared":len(collected),"similarity_pairs":pairs[:12],
            "possible_contradictions":contradictions[:8]}

def validate_source_set(collected, query=""):
    """Produce machine-checkable metadata without asserting source truth."""
    now=time.time()
    rows=[]
    for url,text in collected:
        score=_source_reliability(url,text,query)
        rows.append({"url":url,"reliability_priority":round(score,3),
                     "content_chars":len(text or ""),
                     "checked_at":now,
                     "readable":len(text or "")>=300})
    signals=detect_cross_source_signals(collected)
    return {"source_count":len(rows),"sources":rows,"cross_source_signals":signals,
            "note":"Heuristics prioritize and flag material for review; they do not prove factual truth."}


def run_web_research(query, use_cache=True):
    """
    Full pipeline for a single spoken answer: search -> parallel
    fetch top pages -> Gemini synthesis. Returns a dict:
        {
          "answer": str,          # Gemini's grounded answer, or an
                                   # honest explanation of what went
                                   # wrong
          "sources": [url, ...],
          "ok": bool,              # False if nothing usable was found
          "_raw_sources": [(url, text), ...],  # full extracted text,
                                   # for friday_context.py to cache so
                                   # a follow-up "make it into slides"
                                   # can reuse it without re-searching
        }
    Never raises -- every failure mode degrades to ok=False with a
    speakable "answer", so handle_command() can always safely
    speak() the result without a try/except of its own.

    Repeating the SAME question within RESULT_CACHE_TTL seconds
    returns the cached answer immediately instead of researching
    again -- helpful for "wait, say that again" or a UI double-click,
    without ever serving a genuinely stale price/fact days later.
    """
    if use_cache:
        cached = _cache_get(query)
        if cached is not None:
            return cached

    # Lazy import: friday_backend imports this module, so importing
    # friday_backend back at module load time would be circular.
    import friday_backend

    start = time.time()
    collected = gather_sources(query, depth=MAX_SOURCES, search_pool=8, use_cache=use_cache)
    fetch_seconds = time.time() - start

    if not collected:
        # Web research is preferred, but a web outage must not make FRIDAY
        # unusable. Fall back to the AI model and explicitly disclose that
        # the answer was not live-verified.
        friday_backend._ensure_gemini_client()
        if friday_backend.client is None:
            return {
                "answer": "I could not reach usable web sources, and my AI fallback is unavailable right now.",
                "sources": [], "ok": False, "fallback": False, "_raw_sources": [],
            }
        fallback_prompt = (
            "Answer the user's request using your internal knowledge because live web research "
            "was unavailable. Do not invent current prices, dates, statistics, or events. "
            "If any requested fact may have changed since your knowledge cutoff, say that it "
            "could not be live-verified. Keep the answer useful and concise.\n\n"
            f"USER REQUEST: {query}"
        )
        try:
            response = friday_backend.client.models.generate_content(
                model=friday_backend.GEMINI_MODEL, contents=fallback_prompt
            )
            answer = (getattr(response, "text", "") or "").strip()
            if answer:
                answer = "I couldn't verify this live on the web, so this answer uses my AI knowledge. " + answer
                return {"answer": answer, "sources": [], "ok": True, "fallback": True,
                        "live_verified": False, "_raw_sources": [], "source_scores": []}
        except Exception as error:
            print("AI fallback error:", error)
        return {"answer": "I could not retrieve live sources or produce an AI fallback answer right now.", "sources": [], "ok": False, "fallback": False, "_raw_sources": []}

    friday_backend._ensure_gemini_client()
    if friday_backend.client is None:
        return {
            "answer": "I gathered web results, but my AI brain is unavailable to summarize them right now.",
            "sources": [u for u, _ in collected],
            "ok": False,
            "live_verified": bool(collected),
            "_raw_sources": collected,
        }

    sources_block = "\n\n".join(
        f"SOURCE {i + 1} ({url}):\n{text}" for i, (url, text) in enumerate(collected)
    )

    prompt = (
        "You are the reasoning layer of a personal assistant named Friday. "
        "The user asked a question that needs CURRENT, real information from "
        "the web, not something recalled from training data. Below are "
        "excerpts actually fetched from live web pages just now. Use ONLY "
        "this material -- if it doesn't contain the answer, say so plainly "
        "instead of guessing or inventing a figure.\n\n"
        f"USER QUESTION: {query}\n\n"
        f"{sources_block}\n\n"
        "Write a short, spoken-style answer (2-4 sentences) the way a voice "
        "assistant would say it out loud, in Friday's polite, concise style "
        "(you may address the user as 'sir'). Include concrete numbers or "
        "facts you found. If sources disagree, mention that briefly. Do not "
        "talk about 'sources' or 'excerpts' by number -- just answer naturally."
    )

    try:
        response = friday_backend.client.models.generate_content(
            model=friday_backend.GEMINI_MODEL, contents=prompt
        )
        answer = (getattr(response, "text", None) or "").strip()
        if not answer:
            raise ValueError("empty Gemini response")
    except Exception as error:
        print("Web research synthesis error:", error)
        return {
            "answer": "I gathered information from the web, but had trouble summarizing it just now.",
            "sources": [u for u, _ in collected],
            "ok": False,
            "_raw_sources": collected,
        }

    print(f"Web research: {len(collected)} sources fetched in {fetch_seconds:.1f}s")

    result = {
        "answer": answer,
        "sources": [u for u, _ in collected],
        "ok": True,
        "live_verified": True,
        "source_scores": [
            {"url": u, "score": _source_reliability(u, t, query)} for u, t in collected
        ],
        "validation": validate_source_set(collected, query),
        "_raw_sources": collected,
    }
    if use_cache:
        _cache_set(query, result)
    return result
