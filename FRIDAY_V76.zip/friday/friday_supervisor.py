"""
FRIDAY SUPERVISOR
-----------------
Implements the research doc's "8. Give Friday a Supervisor" section:

                     SUPERVISOR
                         |
             +-----------+-----------+
             v           v           v
          Planner      Agents     Verifier
             |           |           |
             +-----------+-----------+
                         v
                   State Manager

and the tool/knowledge/creation agent grouping from the "final
architecture" diagram:

    TOOL AGENTS (Computer/Browser/Apps/System/Files)
    KNOWLEDGE AGENTS (Research/Study/Documents)
    CREATION AGENTS (Notes/Documents/Reports/Diagrams)

plus the proactive permission boundaries from sections 8/10:

    SAFE        -> automatic
    LOW_RISK    -> automatic or notify
    HIGH_IMPACT -> ask first

This module NEVER performs an action itself and never imports any
existing friday_*.py agent module directly -- your existing modules
are registered into it at runtime by whatever wiring code you choose
to write (see INTEGRATION_GUIDE_UNIFIED_ARCHITECTURE.md), so this file
has zero coupling to your existing code and cannot break it.
"""

from __future__ import annotations

import re
import time
from typing import Any, Callable, Optional

import friday_state_engine as state
import friday_executive as executive

AgentFn = Callable[[dict[str, Any]], dict[str, Any]]

TIER_SAFE = "safe"
TIER_LOW_RISK = "low_risk"
TIER_HIGH_IMPACT = "high_impact"

_HIGH_IMPACT_PATTERNS = (
    r"\bdelete\b", r"\bremove\b", r"\bformat\b", r"\buninstall\b", r"\bpurchase\b", r"\bbuy\b",
    r"\bpay\b", r"\btransfer money\b", r"\bsend (message|email|whatsapp)\b", r"\bpost\b", r"\bpublish\b",
    r"\bshutdown\b", r"\brestart\b", r"\bfactory reset\b",
)
_LOW_RISK_PATTERNS = (
    r"\bwrite\b", r"\bclick\b", r"\btype\b", r"\bmove\b", r"\brename\b", r"\bcreate\b", r"\bsave\b",
)
_SAFE_PATTERNS = (
    r"\bopen\b", r"\bread\b", r"\bsearch\b", r"\blook up\b", r"\bresearch\b", r"\bview\b", r"\bcheck\b",
)


class Supervisor:
    def __init__(self) -> None:
        # {group: {agent_name: fn}}
        self._agents: dict[str, dict[str, AgentFn]] = {"knowledge": {}, "action": {}, "creation": {}}

    # -- agent registry ----------------------------------------------------
    def register_agent(self, group: str, name: str, fn: AgentFn) -> None:
        """Plug an EXISTING Friday capability in as an agent, e.g.:

            supervisor.register_agent("action", "desktop",
                lambda task: my_existing_desktop_agent.run(task["action"], task["inputs"]))

        This is the only integration point the rest of your codebase needs
        to touch, and it's opt-in -- nothing is registered automatically.
        """
        if group not in self._agents:
            self._agents[group] = {}
        self._agents[group][name] = fn
        state.upsert_item("agents", name, group=group, status="registered")

    def unregister_agent(self, group: str, name: str) -> None:
        self._agents.get(group, {}).pop(name, None)

    def list_agents(self) -> dict[str, list[str]]:
        return {group: list(agents.keys()) for group, agents in self._agents.items()}

    # -- routing -------------------------------------------------------------
    def route(self, task: dict[str, Any]) -> tuple[Optional[str], Optional[str]]:
        """Pick (group, agent_name) for a task. Honors an explicit
        agent_group/agent_name on the task first; otherwise falls back to
        keyword classification against the action text."""
        group = task.get("agent_group")
        name = task.get("agent_name")
        if group and name and name in self._agents.get(group, {}):
            return group, name
        if not group:
            group = self._classify_group(task.get("action", ""))
        agents = self._agents.get(group, {})
        if not agents:
            return group, None
        if name and name in agents:
            return group, name

        # 9.5+ deterministic capability routing. Agent registration order is
        # not a valid routing policy once several real agents are present.
        text = str(task.get("action", "")).lower()
        preferences = {
            "knowledge": (
                ("youtube_research", ("youtube", "video", "videos")),
                ("web_research", ("research", "source", "latest", "according to", "investigate")),
                ("study", ("study", "quiz", "exam", "syllabus", "practice")),
                ("knowledge_base", ("local knowledge", "my documents", "uploaded", "file")),
            ),
            "creation": (
                ("documents", ("document", "pdf", "docx", "word", "spreadsheet", "xlsx", "presentation", "slides")),
                ("notes", ("notes", "note")),
            ),
            "action": (
                ("browser", ("search", "google", "youtube", "browser", "tab", "navigate")),
                ("app_launcher", ("open", "launch", "start", "application", "app")),
                ("system", ("system status", "cpu", "ram", "battery", "disk")),
                ("desktop", ("click", "type", "write", "paste", "scroll", "move", "window")),
            ),
        }
        for candidate, keywords in preferences.get(group, ()):
            if candidate in agents and any(k in text for k in keywords):
                return group, candidate

        # Safe fallback: a specifically capability-oriented generic agent first,
        # otherwise registration order remains deterministic.
        for candidate in ("desktop", "web_research", "documents", "knowledge_base", "app_launcher"):
            if candidate in agents:
                return group, candidate
        return group, next(iter(agents))

    @staticmethod
    def _classify_group(action_text: str) -> str:
        text = (action_text or "").lower()
        if any(k in text for k in ("research", "study", "source", "claim", "understand", "verify_outcome",
                                    "synthesize", "identify_topic")):
            return "knowledge"
        if any(k in text for k in ("document", "note", "report", "diagram", "generate", "organize", "build_document")):
            return "creation"
        return "action"

    # -- permissions ---------------------------------------------------------
    @staticmethod
    def classify_risk(action_text: str) -> str:
        text = (action_text or "").lower()
        if any(re.search(p, text) for p in _HIGH_IMPACT_PATTERNS):
            return TIER_HIGH_IMPACT
        if any(re.search(p, text) for p in _LOW_RISK_PATTERNS):
            return TIER_LOW_RISK
        if any(re.search(p, text) for p in _SAFE_PATTERNS):
            return TIER_SAFE
        return TIER_LOW_RISK  # unknown actions default to "auto but notify", never silently high-impact

    def authorize(self, task: dict[str, Any], *, proactive: bool = False,
                  ask_user: Optional[Callable[[str], bool]] = None) -> tuple[bool, str]:
        """Returns (allowed, tier). For proactive (unprompted) actions, a
        HIGH_IMPACT tier requires an explicit `ask_user(question) -> bool`
        callback that returns True; without one supplied, it is refused
        rather than silently allowed, matching 'ask first'."""
        action_text = task.get("action", "")
        override = state.permission_tier_for(action_text)
        tier = override if override in (TIER_SAFE, TIER_LOW_RISK, TIER_HIGH_IMPACT) else self.classify_risk(action_text)

        if not proactive:
            # User explicitly asked for this in-session; only HIGH_IMPACT
            # still gets a confirmation prompt if one is available.
            if tier == TIER_HIGH_IMPACT and ask_user is not None:
                return bool(ask_user(f"This will '{action_text}', which is high-impact. Proceed?")), tier
            return True, tier

        if tier == TIER_SAFE:
            return True, tier
        if tier == TIER_LOW_RISK:
            return True, tier  # auto, caller is responsible for the "notify" half
        # HIGH_IMPACT + proactive
        if ask_user is not None:
            return bool(ask_user(f"Friday would like to proactively '{action_text}'. Allow it?")), tier
        return False, tier

    # -- dispatch --------------------------------------------------------------
    def dispatch_task(self, task: dict[str, Any], *, ask_user: Optional[Callable[[str], bool]] = None,
                       proactive: bool = False) -> dict[str, Any]:
        """The function you pass to friday_executive.execute_goal as `dispatch`.

        Handles: permission gating -> routing -> calling the registered
        agent -> capturing before/after evidence for mechanical_action
        verification -> normalising the agent's return value.
        """
        allowed, tier = self.authorize(task, proactive=proactive, ask_user=ask_user)
        if not allowed:
            return {"error": f"blocked by permission policy (tier={tier})", "method": "permission_check"}

        group, name = self.route(task)
        if not name:
            return {"error": f"no agent registered for group '{group}'", "method": "routing"}

        # 9.5+ alternate strategy: retries are allowed to choose a different
        # registered capability instead of blindly repeating the same failing
        # adapter. This is deterministic and only activates when the Executive
        # explicitly marks a retry as alternate.
        inputs = task.get("inputs") if isinstance(task.get("inputs"), dict) else {}
        if inputs.get("retry_strategy") == "alternate":
            alternates = {
                "action": {"browser": "desktop", "desktop": "browser", "app_launcher": "desktop", "system": "desktop"},
                "knowledge": {"web_research": "knowledge_base", "knowledge_base": "web_research", "youtube_research": "web_research"},
                "creation": {"documents": "notes", "notes": "documents"},
            }
            alt = alternates.get(group, {}).get(name)
            if alt and alt in self._agents.get(group, {}):
                name = alt

        agent_fn = self._agents.get(group, {}).get(name)
        if agent_fn is None:
            return {"error": f"agent '{name}' vanished from registry", "method": "routing"}

        before_snapshot = None
        if task.get("verification_level") == "mechanical_action":
            try:
                import friday_verifier_layer as verifier
                before_snapshot = verifier.capture_before_state()
            except Exception:
                before_snapshot = None

        state.upsert_item("agents", name, status="running", last_task=task.get("action"))
        try:
            result = agent_fn(task) or {}
        except Exception as exc:
            state.upsert_item("agents", name, status="error", last_error=str(exc))
            return {"error": str(exc), "method": name}

        state.upsert_item("agents", name, status="idle", last_used=time.time())
        if isinstance(result, dict):
            result.setdefault("method", name)
            if before_snapshot is not None:
                result.setdefault("before_snapshot", before_snapshot)
            try:
                from friday_action_contracts import infer_contract
                result.setdefault("contract", infer_contract(task.get("action", ""), task))
            except Exception:
                pass
            return result
        return {"summary": str(result), "method": name, "before_snapshot": before_snapshot}

    # -- convenience: plan + execute in one call --------------------------
    def run_goal(self, goal_text: str, *, priority: float = 0.5,
                 plan_override: Optional[list[dict[str, Any]]] = None,
                 ask_user: Optional[Callable[[str], bool]] = None,
                 proactive: bool = False) -> dict[str, Any]:
        goal = executive.plan(goal_text, priority=priority, plan_override=plan_override)
        return executive.execute_goal(
            goal["id"],
            dispatch=lambda task: self.dispatch_task(task, ask_user=ask_user, proactive=proactive),
            ask_user=ask_user,
        )


# Module-level default instance, mirroring the rest of this codebase's
# "import the module, call its functions" convention (see friday_agent_core).
_default = Supervisor()


def register_agent(group: str, name: str, fn: AgentFn) -> None:
    _default.register_agent(group, name, fn)


def list_agents() -> dict[str, list[str]]:
    return _default.list_agents()


def run_goal(goal_text: str, **kwargs: Any) -> dict[str, Any]:
    return _default.run_goal(goal_text, **kwargs)


def dispatch_task(task: dict[str, Any], **kwargs: Any) -> dict[str, Any]:
    return _default.dispatch_task(task, **kwargs)


def classify_risk(action_text: str) -> str:
    return Supervisor.classify_risk(action_text)
