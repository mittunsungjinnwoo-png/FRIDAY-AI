"""
FRIDAY Omni Engine
Additive v95 capability layer.

Design goals:
- Preserve the mature legacy dispatcher.
- Provide a single, defensive orchestration surface for widget/voice/typed UI.
- Keep all persistent data local to the FRIDAY directory.
- Never execute arbitrary destructive shell commands without explicit confirmation.
- Use optional dependencies when present and degrade gracefully when absent.
"""
from __future__ import annotations
import concurrent.futures
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import threading
import time
import traceback
import uuid
from urllib.parse import urlparse
from pathlib import Path
from typing import Any, Callable, Optional

ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / "friday_omni_state.json"
TASK_FILE = ROOT / "friday_omni_tasks.json"
MEMORY_FILE = ROOT / "friday_omni_memory.json"
LOCK = threading.RLock()
TOOLS: dict[str, dict[str, Any]] = {}
STOP = threading.Event()
_WORKERS = concurrent.futures.ThreadPoolExecutor(max_workers=4, thread_name_prefix="FridayOmni")

def _load(path: Path, default: Any) -> Any:
    try:
        if not path.exists(): return default
        value = json.loads(path.read_text(encoding="utf-8"))
        return value
    except Exception:
        return default

def _save(path: Path, value: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    except Exception:
        try:
            if tmp.exists(): tmp.unlink()
        except Exception: pass

STATE = _load(STATE_FILE, {
    "schema": 1, "active_topic": None, "summary": "", "updated_at": 0,
    "pending_task": None, "proactive_enabled": True, "safe_mode": True,
})
TASKS = _load(TASK_FILE, [])
MEMORY = _load(MEMORY_FILE, [])

def _emit(message: str, kind: str = "omni", **extra: Any) -> None:
    payload = {"id": str(uuid.uuid4()), "ts": dt.datetime.now().isoformat(timespec="seconds"),
               "kind": kind, "message": str(message)}
    payload.update(extra)
    print("FRIDAY_EVENT::" + json.dumps(payload, ensure_ascii=False), flush=True)

def _progress(percent: int, stage: str, task: str = "") -> None:
    print("PROGRESS::" + json.dumps({"percent": max(0,min(100,int(percent))),
          "stage": stage, "task": task}, ensure_ascii=False), flush=True)

def _backend():
    import friday_backend
    return friday_backend

# ----------------------------- Memory -----------------------------
def _importance(text: str) -> float:
    low = text.lower()
    score = 0.25
    if len(text) > 80: score += .15
    if re.search(r"\b(remember|important|always|never|preference|deadline|goal)\b", low): score += .35
    if re.search(r"\b(research|project|assignment|exam|report|presentation)\b", low): score += .15
    if "?" in text: score += .05
    return min(1.0, score)

def remember(text: str, metadata: Optional[dict[str,Any]]=None) -> None:
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if not text or len(text) < 4: return
    entry = {"id": str(uuid.uuid4()), "text": text[:2500], "importance": _importance(text),
             "created_at": time.time(), "metadata": metadata or {}}
    with LOCK:
        MEMORY.append(entry)
        # Keep high-value memories and a bounded recent tail.
        MEMORY[:] = sorted(MEMORY, key=lambda x:(x.get("importance",0), x.get("created_at",0)), reverse=True)[:600]
        _save(MEMORY_FILE, MEMORY)

def recall(query: str, limit: int=8) -> list[dict[str,Any]]:
    q = set(re.findall(r"[a-z0-9]{3,}", query.lower()))
    scored=[]
    with LOCK:
        for m in MEMORY:
            words=set(re.findall(r"[a-z0-9]{3,}", m.get("text","").lower()))
            overlap=len(q & words)/(len(q)|1)
            recency=1/(1+max(0,time.time()-m.get("created_at",0))/86400)
            score=.65*overlap+.2*m.get("importance",0)+.15*recency
            if score>.08: scored.append((score,m))
    scored.sort(key=lambda x:x[0], reverse=True)
    return [{"score":round(s,3), **m} for s,m in scored[:limit]]

def set_context(topic: Optional[str]=None, summary: Optional[str]=None, task: Optional[str]=None):
    with LOCK:
        if topic: STATE["active_topic"]=str(topic)[:500]
        if summary is not None: STATE["summary"]=str(summary)[:3000]
        if task is not None: STATE["pending_task"]=str(task)[:500]
        STATE["updated_at"]=time.time()
        _save(STATE_FILE, STATE)

# ----------------------------- Tasks -----------------------------
def _task(objective: str) -> dict[str,Any]:
    t={"id":"task_"+uuid.uuid4().hex[:10], "objective":objective[:1000],
       "status":"queued","progress":0,"steps":[],"errors":[],"created_at":time.time(),
       "updated_at":time.time()}
    with LOCK: TASKS.insert(0,t); del TASKS[500:]; _save(TASK_FILE,TASKS)
    return t

def _update(t, **changes):
    t.update(changes); t["updated_at"]=time.time()
    with LOCK: _save(TASK_FILE,TASKS)
    _emit(f"Task {t['id']} {t.get('status')}", "task", task=t)

def list_tasks(limit=20):
    with LOCK: return sorted(TASKS,key=lambda x:x.get("updated_at",0),reverse=True)[:limit]

# ----------------------------- Security -----------------------------
DANGEROUS = re.compile(r"\b(delete|format|shutdown|restart|power\s*off|remove\s+all|rd\s+/s|del\s+/s)\b",re.I)
def security_level(command: str) -> tuple[int,str]:
    c=command.strip()
    if DANGEROUS.search(c): return 4,"destructive system or file action"
    if re.search(r"\b(send|message|email|whatsapp)\b",c,re.I): return 3,"external communication"
    if re.search(r"\b(create|write|edit|save|move|rename|download)\b",c,re.I): return 2,"write/download action"
    if re.search(r"\b(open|launch|start|click|type|navigate)\b",c,re.I): return 1,"desktop interaction"
    return 0,"read-only"

def needs_confirmation(command: str) -> bool:
    return security_level(command)[0] >= 4

# ----------------------------- Tools -----------------------------
def register_tool(name: str, handler: Callable[...,Any], permission=0, description=""):
    if not name or not callable(handler): return False
    TOOLS[str(name)]={"handler":handler,"permission":int(permission),"description":description or str(name)}
    return True

def tools() -> list[dict[str,Any]]:
    return [{"name":n,"permission":v["permission"],"description":v["description"]} for n,v in sorted(TOOLS.items())]

def _screen():
    try:
        import mss
        from PIL import Image
        with mss.mss() as sct:
            mon=sct.monitors[0]
            shot=sct.grab(mon)
            path=ROOT/"friday_screen_latest.png"
            Image.frombytes("RGB",shot.size,shot.rgb).save(path)
            return {"ok":True,"path":str(path),"width":shot.width,"height":shot.height}
    except Exception as e:
        return {"ok":False,"error":str(e)}

def _ocr(path: str) -> dict[str,Any]:
    try:
        import pytesseract
        text=pytesseract.image_to_string(path)
        return {"ok":True,"text":text[:12000]}
    except Exception as e:
        return {"ok":False,"error":f"OCR unavailable: {e}"}

def screen_awareness_command(command: str):
    try:
        from friday_screen_intelligence import is_awareness_start_intent,is_awareness_stop_intent,is_screen_intent,start_awareness,stop_awareness,inspect_screen
        if is_awareness_start_intent(command): start_awareness(interval=2.5,semantic=False); return {"ok":True,"message":"Continuous screen awareness is now active, sir."}
        if is_awareness_stop_intent(command): stop_awareness(); return {"ok":True,"message":"Screen awareness is now off, sir."}
        if is_screen_intent(command): return inspect_screen(use_semantic_vision=True)
    except Exception as e: return {"ok":False,"error":str(e)}
    return None

def screen_understanding() -> dict[str,Any]:
    shot=_screen()
    if not shot.get("ok"): return shot
    out=dict(shot)
    ocr=_ocr(shot["path"])
    out["ocr"]=ocr.get("text","") if ocr.get("ok") else ""
    try: out["active_window"]=_backend().get_active_window_title()
    except Exception: out["active_window"]=None
    return out

def computer_action(command: str) -> dict[str,Any]:
    """Route desktop mutations through the shared truth-aware controller."""
    try:
        from friday_desktop_agent import computer
        return computer(command)
    except Exception as e:
        return {"ok":False,"executed":False,"error":str(e)}

# ----------------------------- Research quality -----------------------------
def _freshness_signal(url: str, text: str) -> dict[str,Any]:
    """Heuristic freshness signal from page text/URL; not a publication-date proof."""
    years=[int(y) for y in re.findall(r"\b(20\d{2})\b", (url+" "+text)[:20000]) if 2000 <= int(y) <= dt.datetime.now().year+1]
    latest=max(years) if years else None
    return {"latest_year_seen":latest, "checked_at":dt.datetime.now().isoformat(timespec="seconds"),
            "method":"URL/page-text year heuristic"}

def research(query: str) -> dict[str,Any]:
    _progress(10,"Searching multiple sources",query)
    result=_backend().friday_web_research.run_web_research(query,use_cache=True)
    raw=result.get("_raw_sources",[]) if isinstance(result,dict) else []
    urls=result.get("sources",[]) if isinstance(result,dict) else []
    domains={}
    for u in urls:
        domain=re.sub(r"^www\.","",urlparse(u).netloc.lower())
        domains[domain]=domains.get(domain,0)+1
    duplicates=[d for d,n in domains.items() if n>1]
    freshness=[]
    for u,text in raw:
        freshness.append({"url":u,**_freshness_signal(u,text)})
    if isinstance(result,dict):
        result["quality"]={"source_count":len(urls),"duplicate_domains":duplicates,
                           "freshness_checks":freshness,"cross_source_ready":len(raw)>=2,
                           "limitations":"Freshness is heuristic unless the source exposes an explicit publication/modified date."}
    _progress(70,"Cross-checking sources",query)
    remember(query,{"type":"research","sources":urls})
    _progress(100,"Research verified",query)
    return result

# ----------------------------- Multi-agent supervisor -----------------------------
def multi_agent_pipeline(command: str) -> dict[str,Any]:
    """Role-separated pipeline: planner -> researcher -> verifier -> writer.
    Roles share bounded artifacts, making the workflow inspectable and recoverable."""
    _emit("Planner agent decomposing the request","agent",role="planner")
    topic=command.strip()
    _progress(8,"Planner agent: decomposing request",command)
    _emit("Research agent collecting evidence","agent",role="researcher")
    result=research(topic)
    _progress(62,"Verification agent checking source diversity and signals",command)
    quality=result.get("quality",{}) if isinstance(result,dict) else {}
    validation=result.get("validation",{}) if isinstance(result,dict) else {}
    verification={"source_count":len(result.get("sources",[])) if isinstance(result,dict) else 0,
                  "diverse_domains":not bool(quality.get("duplicate_domains")),
                  "cross_source_signals":validation.get("cross_source_signals",{}) if isinstance(validation,dict) else {},
                  "status":"reviewed"}
    _emit("Verification agent completed source checks","agent",role="verifier",verification=verification)
    _emit("Supervisor agent accepted research package","agent",role="supervisor")
    return {"ok":bool(result.get("ok")) if isinstance(result,dict) else False,
            "research":result,"verification":verification,"roles":["planner","researcher","verifier","supervisor"]}

# ----------------------------- Orchestration -----------------------------
def _is_omni(command: str) -> bool:
    low=command.lower()
    return bool(
        re.search(r"\b(deep research|investigate|research thoroughly|research deeply)\b",low)
        or re.search(r"\b(remember|what do you remember|recall)\b",low)
        or re.search(r"\b(list|show)\s+(active\s+)?tasks?\b",low)
        or re.search(r"\b(proactive|self[- ]diagnostic|system check|safe mode)\b",low)
        or re.search(r"\b(read|scan|understand)\s+(my\s+)?screen\b",low)
        or re.search(r"\bclick\s+\d+\s+\d+\b",low)
        or re.search(r"\btype\s+.+",low)
    )

def _handle_memory(command):
    if re.search(r"\bwhat do you remember|recall\b",command,re.I):
        hits=recall(command,8)
        if hits:
            text="I found these relevant memories: "+"; ".join(h["text"][:180] for h in hits[:5])
        else: text="I do not have a relevant stored memory for that yet."
        _backend().speak(text)
        return True
    m=re.search(r"\bremember(?: that)?\s+(.+)$",command,re.I)
    if m:
        remember(m.group(1),{"type":"explicit"})
        _backend().speak("Understood, sir. I have stored that as an important memory.")
        return True
    return None

def run_complex(command: str):
    t=_task(command); _update(t,status="planning",progress=5)
    features={
      "research": bool(re.search(r"\b(research|investigate|according to)\b",command,re.I)),
      "screen": bool(re.search(r"\b(screen|screenshot|OCR|what.+screen)\b",command,re.I)),
      "document": bool(re.search(r"\b(pdf|docx|pptx|xlsx|presentation|report)\b",command,re.I)),
      "desktop": bool(re.search(r"\b(open|launch|click|type|navigate)\b",command,re.I)),
    }
    steps=[]
    if features["research"]: steps.append("research")
    if features["screen"]: steps.append("screen")
    if features["desktop"]: steps.append("desktop")
    if features["document"]: steps.append("document")
    if not steps: return None
    _update(t,status="running",steps=[{"name":s,"status":"queued"} for s in steps])
    results={}
    for idx,step in enumerate(steps):
        _progress(int(10+idx*80/max(1,len(steps))),f"Running {step}",command)
        try:
            if step=="research": results[step]=multi_agent_pipeline(command)
            elif step=="screen": results[step]=screen_understanding()
            elif step=="desktop": results[step]=computer_action(command)
            elif step=="document":
                # Delegate to the existing creation engine through its backend
                # dispatcher; this preserves established document formatting.
                ok=_backend().handle_command(command)
                results[step]={"ok":bool(ok)}
            t["steps"][idx]["status"]="verified" if results[step] else "failed"
        except Exception as e:
            t["steps"][idx]["status"]="failed"; t["errors"].append(f"{step}: {e}")
    t["results_summary"]={k:({"ok":v.get("ok",True),"sources":len(v.get("sources",[]))} if isinstance(v,dict) else bool(v)) for k,v in results.items()}
    _update(t,status="completed_with_errors" if t["errors"] else "completed",progress=100)
    remember(command,{"type":"task","task_id":t["id"],"result":t["status"]})
    return True

def self_diagnostics() -> dict[str,Any]:
    checks={}
    checks["state_files"]=all(p.parent.exists() for p in (STATE_FILE,TASK_FILE,MEMORY_FILE))
    try: checks["backend_import"]=bool(_backend())
    except Exception as e: checks["backend_import"]=False
    for name, mod in [("web_research","friday_web_research"),("voice","friday_voice_engine"),
                      ("agent","friday_advanced_agent")]:
        try: __import__(mod); checks[name]=True
        except Exception: checks[name]=False
    try:
        import psutil
        checks["system_monitor"]=True
    except Exception: checks["system_monitor"]=False
    checks["tool_registry"]=bool(TOOLS)
    # Surface the AI brain's actual state and *why*, rather than just a
    # bool -- "not connected" alone doesn't tell the user whether a key
    # is missing, misnamed, in the wrong file, or present but rejected.
    try:
        backend=_backend()
        backend._ensure_gemini_client()
        checks["ai_brain"]=backend.client is not None
        ai_brain_reason=getattr(backend,"GEMINI_STATUS_REASON","unknown")
    except Exception as e:
        checks["ai_brain"]=False
        ai_brain_reason=f"could not check: {e}"
    return {"overall":all(checks.values()),"checks":checks,"ai_brain_reason":ai_brain_reason,"timestamp":dt.datetime.now().isoformat(timespec="seconds")}

def handle(command: str):
    c=(command or "").strip()
    if not c: return None
    if re.search(r"\bself[- ]diagnostic|system check\b",c,re.I):
        report=self_diagnostics()
        _emit(f"Self-diagnostics {'passed' if report['overall'] else 'completed with warnings'}","diagnostics",report=report)
        good=sum(report["checks"].values()); total=len(report["checks"])
        msg=f"System check complete. {good} of {total} core checks passed, sir."
        if not report["checks"].get("ai_brain",True):
            msg+=f" The AI brain is down -- {report.get('ai_brain_reason','reason unknown')}."
        _backend().speak(msg)
        return True
    if re.search(r"\b(list|show)\s+(active\s+)?tasks?\b",c,re.I):
        active=list_tasks(12)
        _backend().speak(f"I have {len(active)} tracked tasks, sir.")
        _emit("Active task snapshot","task_snapshot",tasks=active)
        return True
    mem=_handle_memory(c)
    if mem is not None: return mem
    # Delegate to friday_screen_intelligence's own is_screen_intent() rather
    # than maintaining a second, independently-drifting copy of the same
    # pattern list here -- this exact duplication (this list didn't have
    # "check my screen" or "take my screen" until this list's twin in
    # friday_screen_intelligence.py was fixed and this one wasn't) is what
    # let the same routing bug reappear under a new phrasing twice in a
    # row. One pattern list, used everywhere.
    try:
        from friday_screen_intelligence import is_screen_intent as _is_screen_intent
    except Exception:
        _is_screen_intent = lambda _c: False
    if _is_screen_intent(c):
        result=screen_understanding()
        if result.get("ok"):
            answer=result.get("summary") or (
                "I inspected the screen. The active window is "
                + str(result.get("active_window") or "unknown") + "."
            )
        else:
            answer="I could not inspect the screen: "+str(result.get("error","unknown error"))
        _backend().speak(answer)
        _emit("Screen inspection completed","vision",
              result={k:v for k,v in result.items() if k!="ocr"})
        return True
    if re.search(r"\bdeep research|research thoroughly|research deeply|investigate\b",c,re.I):
        return run_complex(c)
    if _is_omni(c) and any(x in c.lower() for x in ("click ","type ")):
        result=computer_action(c)
        _backend().speak("Action completed, sir." if result.get("ok") else "I could not complete that action safely.")
        return True
    return None

# Register built-in capabilities without touching the legacy registry.
register_tool("omni.memory", recall, 0, "Importance-ranked local memory")
register_tool("omni.screen", screen_understanding, 0, "Screenshot plus optional OCR")
register_tool("omni.computer", computer_action, 1, "Conservative desktop automation")
register_tool("omni.research", research, 0, "Research with source-quality metadata")
register_tool("omni.diagnostics", self_diagnostics, 0, "Core dependency and state checks")

def start_background():
    """Safe proactive monitor. It only emits optional events; it never speaks."""
    if getattr(start_background,"_started",False): return
    start_background._started=True
    def loop():
        last_active=None
        while not STOP.wait(15):
            try:
                jb=_backend()
                active=jb.get_active_window_title()
                if active and active!=last_active:
                    last_active=active
                    _emit(f"Foreground application: {active}","awareness",active_window=active)
            except Exception: pass
    threading.Thread(target=loop,name="Friday-Proactive",daemon=True).start()

start_background()
