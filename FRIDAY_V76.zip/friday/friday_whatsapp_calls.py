"""
FRIDAY WhatsApp Calls (V2050)
=============================
Additive, fully optional module. Nothing in the existing WhatsApp
messaging pipeline is modified by it.

What it does
------------
1. OUTGOING CALLS  -- "call Mom on WhatsApp", "video call Sarah",
   "give Dave a call on WhatsApp".
   * The contact goes through the SAME resolver the message flow uses
     (saved contacts, fuzzy match, recognition alternatives, Gemini
     cleanup). A low-confidence name makes Friday ask you to SPELL it,
     exactly like sending a message.
   * Friday then asks "Shall I call <name> on WhatsApp?" and only dials
     after a yes.
   * WhatsApp Desktop is driven the same way the send pipeline drives it
     (Windows Search -> foreground check -> Ctrl+F -> contact), then the
     call button is found through Windows UI Automation. Before dialling,
     the open chat's header is checked against the requested name, so a
     wrong contact is never called. Success is only announced when
     WhatsApp actually shows a ringing / calling state.

2. INCOMING CALLS -- a Windows toast from WhatsApp such as
   "Mom / Incoming voice call" is recognised (missed / ended calls are
   not) and Friday asks "Sir, Mom is calling you on WhatsApp. Shall I
   answer it?" yes -> presses Accept, no -> leaves it ringing.
   "decline the call" presses Decline. If the caller hangs up first, the
   pending question is withdrawn.

3. "hang up" / "end the call" for a call Friday placed or answered.

What it does NOT do: it does not put Friday's voice/AI on the call audio.
Joining the live audio needs a virtual audio device and is a separate
project.

Design guarantees (same philosophy as friday_whatsapp_watch.py)
---------------------------------------------------------------
- Windows-only automation; on other OSes everything degrades to a spoken
  "I can't do that here" and never raises into the caller.
- Optional deps (pyautogui, pyperclip, pywinauto, winsdk) are imported
  lazily; a missing one produces one clear sentence, not a crash.
- The incoming-call watcher only inspects WhatsApp toasts and ignores
  every other app's notifications.
"""
from __future__ import annotations

import datetime
import platform
import re
import threading
import time
import traceback
from typing import Callable, Optional, Tuple

IS_WINDOWS = platform.system() == "Windows"

INCOMING_POLL_SECONDS = 1.0
INCOMING_MAX_AGE_SECONDS = 45
INCOMING_QUESTION_TTL = 60          # a ringing call doesn't last longer
ACTIVE_CALL_TTL = 3 * 3600

# ------------------------------------------------------------
# Text parsing
# ------------------------------------------------------------

_FILLER = (
    r"^\s*(?:(?:hey|ok|okay|hi|so)[,\s]+)?(?:friday[,\s]+)?"
    r"(?:(?:please|can you|can u|could you|could u|would you|would u|will you|i want you to|"
    r"i'd like you to|i would like you to|i want to|i need to|let'?s|go ahead and)[,\s]+)*"
)
_KIND = r"(?:(?P<kind>voice|video|audio)\s+)?"
_WA = r"(?:whats\s?app\s+)?"
_ON_WA = r"(?:on|via|through|throudh|thru|using|in|over|with)\s+(?:the\s+)?whats?\s?app"

_CALL_PATTERNS = [
    # "call Mom on WhatsApp", "make a video call to Mom on WhatsApp please"
    re.compile(
        _FILLER + r"(?:(?:make|place|start|give|do|initiate)\s+(?:a\s+|an\s+)?)?" + _WA + _KIND
        + r"(?:call|ring|dial)\s+(?:to\s+|with\s+)?(?P<contact>.+?)\s+" + _ON_WA + r"\b.*$",
        re.I),
    # "give Mom a call", "give Mom a video call on WhatsApp"
    re.compile(
        _FILLER + r"give\s+(?P<contact>.+?)\s+a\s+" + _WA + _KIND
        + r"(?:call|ring)(?:\s+" + _ON_WA + r")?\s*[.!?]*$",
        re.I),
    # "call Mom", "whatsapp call Mom", "video call Mom", "start a whatsapp call with Mom"
    re.compile(
        _FILLER + r"(?:(?:make|place|start|do|initiate)\s+(?:a\s+|an\s+)?)?" + _WA + _KIND
        + r"(?:call|ring|dial)\s+(?:to\s+|with\s+)?(?P<contact>.+)$",
        re.I),
    # bare "make a whatsapp call" / "whatsapp call" -> ask who
    re.compile(
        _FILLER + r"(?:(?:make|place|start|do|initiate)\s+(?:a\s+|an\s+)?)?whats\s?app\s+" + _KIND
        + r"call\s*[.!?]*$",
        re.I),
]

_OTHER_CHANNEL_WORDS = (
    "email", "e-mail", "gmail", "outlook", "sms", "text message", "imessage",
    "telegram", "messenger", "instagram", "discord", "slack", "signal", "zoom",
    "teams", "meet", "skype", "facetime", "google", "phone number", "landline",
)
_PLACEHOLDER_CONTACTS = {
    "me", "it", "this", "that", "us", "them", "him", "her", "you", "friday",
    "back", "later", "now", "again", "a day", "it a day", "off", "whatsapp",
}
_BAD_CONTACT_START = re.compile(r"^(?:a|an|of|for|off|on|in|at|it|to|out|up|down|about)\b", re.I)
_CONTACT_TRAIL = re.compile(
    r"\s*(?:,|\.|!|\?)*\s*(?:(?:on|via|through|using|over)\s+(?:the\s+)?whats?\s?app|"
    r"please|now|right now|for me|thanks|thank you)\s*[.!?]*$", re.I)
_CONTACT_LEAD = re.compile(r"^(?:back\s+|my\s+|the\s+|to\s+|with\s+)+", re.I)


def _clean_contact(raw: str) -> str:
    text = (raw or "").strip(" .,:-\"'!?")
    for _ in range(3):
        new = _CONTACT_TRAIL.sub("", text).strip(" .,:-\"'!?")
        if new == text:
            break
        text = new
    text = _CONTACT_LEAD.sub("", text).strip(" .,:-\"'!?")
    return text


def parse_call_command(text: str) -> Optional[dict]:
    """Returns {"contact": str ('' = ask who), "video": bool} or None.

    Anchored to the START of the utterance so a message body such as
    "send whatsapp to Mom saying call me later" is never misread as a
    call request. Without the word "WhatsApp", the generic "call X" only
    fires for a short, name-looking X and never when another channel or
    app (Zoom, Teams, email...) is named."""
    if not text:
        return None
    command = text.strip()
    lowered = command.lower()
    mentions_wa = bool(re.search(r"whats\s?app", lowered) or re.search(r"\bthroudh?\s+whats?\s?app\b", lowered))
    if not mentions_wa and any(w in lowered for w in _OTHER_CHANNEL_WORDS):
        return None
    if re.match(r"^\s*(?:friday[,\s]+)?(?:send|write|text|message|tell|say|reply)\b", lowered):
        return None                                   # a message request, not a call

    for pattern in _CALL_PATTERNS:
        match = pattern.match(command)
        if not match:
            continue
        kind = (match.groupdict().get("kind") or "").lower()
        contact = _clean_contact(match.groupdict().get("contact") or "")
        video = kind == "video" or bool(re.search(r"\bvideo\b", lowered))
        if not contact:
            return {"contact": "", "video": video} if mentions_wa else None
        first_word = contact.lower().split()[0]
        if (contact.lower() in _PLACEHOLDER_CONTACTS or first_word in _PLACEHOLDER_CONTACTS
                or _BAD_CONTACT_START.match(contact)):
            return {"contact": "", "video": video} if mentions_wa else None
        words = contact.split()
        if len(words) > (5 if mentions_wa else 3):
            continue
        if re.search(r"whats\s?app", contact, re.I):
            continue
        return {"contact": contact, "video": video}
    return None


_ANSWER_RE = re.compile(
    r"^(?:answer|pick up|pickup|accept|take)(?:\s+(?:the|that|this|it|my))?"
    r"(?:\s+(?:whatsapp|incoming|voice|video))*(?:\s+call)?$")
_DECLINE_RE = re.compile(
    r"^(?:decline|reject|refuse|ignore)(?:\s+(?:the|that|this|it))?"
    r"(?:\s+(?:whatsapp|incoming|voice|video))*(?:\s+call)?$")
_HANGUP_RE = re.compile(
    r"^(?:(?:hang up|hangup)(?:\s+(?:the|this|that|my|current|ongoing|active))?"
    r"(?:\s+(?:whatsapp|voice|video))*(?:\s+call)?"
    r"|(?:end|disconnect|terminate|cut)(?:\s+(?:the|this|that|my|current|ongoing|active))?"
    r"(?:\s+(?:whatsapp|voice|video))*\s+call)(?:\s+now)?$")


def _norm_control(text: str) -> str:
    t = (text or "").lower().strip()
    t = re.sub(r"[^\w\s']", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"^(?:(?:hey|ok|okay)\s+)?(?:friday\s+)?(?:(?:please|can you|could you|would you)\s+)*", "", t)
    t = re.sub(r"\s+(?:please|now|sir)$", "", t)
    return t.strip()


def classify_control(text: str) -> Optional[Tuple[str, bool]]:
    """Explicit call-control phrase -> (action, has_call_word) or None.
    action is 'answer' | 'decline' | 'hangup'."""
    t = _norm_control(text)
    if not t:
        return None
    has_call = bool(re.search(r"\bcall\b", t)) or "hang up" in t or "hangup" in t
    for action, rx in (("answer", _ANSWER_RE), ("decline", _DECLINE_RE), ("hangup", _HANGUP_RE)):
        if rx.match(t):
            return action, has_call
    return None


# ------------------------------------------------------------
# Toast classification (incoming / missed call)
# ------------------------------------------------------------

# Only WHOLE-LINE call labels count, so ordinary chat text such as
# "I'm calling you now" or "free for a video call?" is never mistaken for a
# ringing call.
_LBL_INCOMING = [
    re.compile(r"^incoming\s+(?:whatsapp\s+)?(?:(?:voice|video|audio)\s+)?call(?:\s+from\s+(?P<who>.+))?$", re.I),
    re.compile(r"^(?:whatsapp\s+)?(?:voice|video|audio)\s+call$", re.I),
    re.compile(r"^(?:incoming\s+)?(?:whatsapp\s+)?(?:(?:voice|video)\s+)?call\s+from\s+(?P<who>.+)$", re.I),
    re.compile(r"^(?P<who>.{1,60}?)\s+is\s+(?:(?:video|voice)\s+)?calling(?:\s+you)?$", re.I),
    re.compile(r"^ringing\.{0,3}$", re.I),
]
_LBL_MISSED = [
    re.compile(r"^missed\s+(?:whatsapp\s+)?(?:(?:voice|video|group)\s+)?call(?:\s+from\s+(?P<who>.+))?$", re.I),
    re.compile(r"^(?:(?:voice|video)\s+)?call\s+(?:missed|ended|declined|cancell?ed)$", re.I),
    re.compile(r"^(?:no answer|call ended)$", re.I),
]
_LBL_ONGOING = re.compile(r"^(?:ongoing|in)\s+(?:whatsapp\s+)?(?:(?:voice|video)\s+)?call\b", re.I)


def classify_call_toast(texts) -> Optional[dict]:
    """texts: ordered text lines of a WhatsApp toast.
    Returns {"kind": "incoming"|"missed", "caller": str, "video": bool} or None."""
    lines = [str(t).strip() for t in (texts or []) if str(t).strip()]
    if not lines:
        return None
    kind, who_in_label, label_idx = None, "", -1
    for i, line in enumerate(lines):
        if _LBL_ONGOING.match(line):
            return None
        for rx in _LBL_MISSED:
            m = rx.match(line)
            if m:
                kind, label_idx = "missed", i
                who_in_label = (m.groupdict().get("who") or "").strip()
                break
        if kind:
            break
        for rx in _LBL_INCOMING:
            m = rx.match(line)
            if m:
                kind, label_idx = "incoming", i
                who_in_label = (m.groupdict().get("who") or "").strip()
                break
        if kind:
            break
    if kind is None:
        return None
    caller = who_in_label
    if not caller:
        for i, line in enumerate(lines):
            if i != label_idx and line.lower() != "whatsapp":
                caller = line
                break
    video = bool(re.search(r"\bvideo\b", " ".join(lines), re.I))
    return {"kind": kind, "caller": caller, "video": video}


def looks_like_call_text(*parts) -> bool:
    """True if any text (chat name / preview) is a call notification, so the
    existing 'X sent you a message' announcer can skip it."""
    joined = " | ".join(str(p or "") for p in parts)
    return bool(joined.strip()) and classify_call_toast([p for p in parts if p]) is not None


# ------------------------------------------------------------
# Windows UI automation (WhatsApp Desktop)
# ------------------------------------------------------------

def _foreground_title() -> str:
    if not IS_WINDOWS:
        return ""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        return buf.value or ""
    except Exception:
        return ""


def _uia_available() -> bool:
    if not IS_WINDOWS:
        return False
    try:
        import pywinauto  # noqa: F401
        return True
    except Exception:
        return False


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "").strip().lower())


def _whatsapp_windows():
    """Top-level UIA windows of the WhatsApp process (main window, the
    separate call window, the incoming-call popup) plus Windows toast hosts
    that may carry Accept/Decline buttons."""
    from pywinauto import Desktop
    desktop = Desktop(backend="uia")
    try:
        windows = desktop.windows()
    except Exception:
        return []
    pids = set()
    for w in windows:
        try:
            if "whatsapp" in _norm(w.window_text()):
                pids.add(w.process_id())
        except Exception:
            continue
    found = []
    for w in windows:
        try:
            title = _norm(w.window_text())
            if w.process_id() in pids or "whatsapp" in title:
                found.append(w)
        except Exception:
            continue
    return found


def _toast_windows():
    from pywinauto import Desktop
    out = []
    try:
        for w in Desktop(backend="uia").windows():
            try:
                title = _norm(w.window_text())
                cls = str(w.class_name() or "")
                if title in ("new notification", "notification", "notification center") \
                        or "notification" in title or cls == "Windows.UI.Core.CoreWindow" and "notif" in title:
                    out.append(w)
            except Exception:
                continue
    except Exception:
        pass
    return out


def _buttons(window):
    try:
        return window.descendants(control_type="Button")
    except Exception:
        return []


def _button_name(button) -> str:
    try:
        return _norm(button.window_text()) or _norm(getattr(button.element_info, "name", ""))
    except Exception:
        return ""


def _press(button) -> bool:
    for method in ("invoke", "click_input"):
        try:
            getattr(button, method)()
            return True
        except Exception:
            continue
    return False


def _find_button(windows, include: "re.Pattern", exclude: Optional["re.Pattern"] = None):
    for w in windows:
        for b in _buttons(w):
            name = _button_name(b)
            if name and include.search(name) and not (exclude and exclude.search(name)):
                try:
                    if not b.is_enabled():
                        continue
                except Exception:
                    pass
                return b
    return None


def _button_names(windows, limit=40):
    names = []
    for w in windows:
        for b in _buttons(w):
            n = _button_name(b)
            if n:
                names.append(n)
            if len(names) >= limit:
                return names
    return names


def _header_matches(window, contact: str) -> Optional[bool]:
    """Does the open chat's header (top strip of the RIGHT pane) show the
    requested contact? True / False, or None if it can't be determined."""
    import difflib
    try:
        wr = window.rectangle()
        width = max(1, wr.right - wr.left)
        wanted = _norm(contact)
        wanted_words = [w for w in re.findall(r"\w+", wanted) if w]
        if not wanted_words:
            return None
        seen_any = False
        for e in window.descendants():
            try:
                name = _norm(e.window_text())
                if not name or len(name) > 80:
                    continue
                r = e.rectangle()
                if r.top - wr.top > 150:
                    continue
                if (r.left + r.right) / 2 < wr.left + 0.30 * width:
                    continue                          # left pane = chat list
                seen_any = True
                if wanted in name or all(w in name for w in wanted_words):
                    return True
                if difflib.SequenceMatcher(None, wanted, name).ratio() >= 0.85:
                    return True
            except Exception:
                continue
        return False if seen_any else None
    except Exception:
        return None


_CALL_BTN_VOICE = re.compile(r"^(?:start\s+)?(?:a\s+)?(?:voice|audio)\s+call$|^voice call|^call$|^audio call")
_CALL_BTN_VIDEO = re.compile(r"^(?:start\s+)?(?:a\s+)?video\s+call$|^video call")
_CALL_BTN_EXCLUDE = re.compile(r"\b(end|cancel|hang|decline|reject|mute|leave)\b")
_IN_CALL_RE = re.compile(r"\b(end call|cancel call|hang up|leave call|ringing|calling|connecting|mute)\b")
_ACCEPT_RE = re.compile(r"^(?:accept|answer|pick up)\b|\b(?:accept|answer)\s+(?:voice|video)?\s*call\b")
_DECLINE_BTN_RE = re.compile(r"^(?:decline|reject)\b|\b(?:decline|reject)\s+(?:voice|video)?\s*call\b")
_END_BTN_RE = re.compile(r"\b(end call|hang up|leave call|end)\b")


def _wait_in_call(timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            wins = _whatsapp_windows()
            for w in wins:
                for b in _buttons(w):
                    if _IN_CALL_RE.search(_button_name(b)):
                        return True
                try:
                    for t in w.descendants(control_type="Text"):
                        if _IN_CALL_RE.search(_norm(t.window_text())):
                            return True
                except Exception:
                    pass
        except Exception:
            pass
        time.sleep(0.4)
    return False


class UiActions:
    """All real-world side effects. Replaced by a fake in tests. Every method
    returns (ok, code); it never raises."""

    def start_call(self, contact: str, video: bool, log: Callable[[str], None] = print) -> Tuple[bool, str]:
        if not IS_WINDOWS:
            return False, "not_windows"
        try:
            import pyautogui
            import pyperclip
        except Exception as error:
            log(f"WhatsApp call: automation libraries missing ({error})")
            return False, "no_automation"
        if not _uia_available():
            return False, "no_uia"
        try:
            # Open WhatsApp exactly like the message-send pipeline does.
            pyautogui.hotkey("win", "s")
            time.sleep(1)
            pyautogui.write("WhatsApp", interval=0.03)
            time.sleep(1)
            pyautogui.press("enter")
            deadline = time.time() + 7.0
            ready = False
            while time.time() < deadline:
                if "whatsapp" in _foreground_title().lower():
                    ready = True
                    break
                time.sleep(0.25)
            if not ready:
                return False, "not_ready"
            time.sleep(0.6)

            # Find the contact.
            pyautogui.hotkey("ctrl", "f")
            time.sleep(1)
            pyautogui.hotkey("ctrl", "a")
            pyperclip.copy(contact)
            pyautogui.hotkey("ctrl", "v")
            time.sleep(2)
            pyautogui.press("down")
            time.sleep(0.5)
            pyautogui.press("enter")
            time.sleep(1.8)

            wins = _whatsapp_windows()
            main = next((w for w in wins if "whatsapp" in _norm(w.window_text())), wins[0] if wins else None)
            if main is None:
                return False, "not_ready"

            # Never call the wrong person: the open chat must be the one asked for.
            header = _header_matches(main, contact)
            log(f"WhatsApp call: chat header match for '{contact}' = {header}")
            if header is False:
                return False, "wrong_chat"

            include = _CALL_BTN_VIDEO if video else _CALL_BTN_VOICE
            button = _find_button(wins, include, _CALL_BTN_EXCLUDE)
            if button is None:
                log("WhatsApp call: call button not found. Buttons seen: "
                    + "; ".join(_button_names(wins)))
                return False, "no_button"
            if not _press(button):
                return False, "no_button"
            if _wait_in_call(7.0):
                return True, "ringing"
            return True, "unverified"
        except Exception as error:
            log(f"WhatsApp call error: {error}")
            traceback.print_exc()
            return False, "error"

    def _press_matching(self, include, exclude=None, extra_toasts=True, verify=False) -> Tuple[bool, str]:
        if not _uia_available():
            return False, "no_uia"
        try:
            wins = _whatsapp_windows()
            if extra_toasts:
                wins = wins + _toast_windows()
            button = _find_button(wins, include, exclude)
            if button is None:
                return False, "no_button"
            if not _press(button):
                return False, "no_button"
            if verify:
                return True, ("connected" if _wait_in_call(4.0) else "unverified")
            return True, "done"
        except Exception:
            traceback.print_exc()
            return False, "error"

    def answer(self) -> Tuple[bool, str]:
        return self._press_matching(_ACCEPT_RE, verify=True)

    def decline(self) -> Tuple[bool, str]:
        return self._press_matching(_DECLINE_BTN_RE)

    def hangup(self) -> Tuple[bool, str]:
        return self._press_matching(_END_BTN_RE, extra_toasts=False)

    def call_window_present(self) -> bool:
        if not _uia_available():
            return False
        try:
            for w in _whatsapp_windows():
                for b in _buttons(w):
                    if _END_BTN_RE.search(_button_name(b)):
                        return True
        except Exception:
            pass
        return False


# ------------------------------------------------------------
# Incoming-call watcher (WhatsApp toasts)
# ------------------------------------------------------------

_watch_started = False
_watch_lock = threading.Lock()


def _toast_age_seconds(notification) -> Optional[float]:
    try:
        created = notification.creation_time
        if created is None:
            return None
        if getattr(created, "tzinfo", None) is not None:
            now = datetime.datetime.now(created.tzinfo)
        else:
            now = datetime.datetime.now()
        return (now - created).total_seconds()
    except Exception:
        return None


async def _poll_calls(listener, state: dict, on_call, on_end) -> None:
    from winsdk.windows.ui.notifications import NotificationKinds
    import friday_whatsapp_watch as _w

    notifications = await listener.get_notifications_async(NotificationKinds.TOAST)
    first = not state["baseline_done"]
    current_ids = set()
    for n in notifications:
        try:
            nid = n.id
            current_ids.add(nid)
            if nid in state["seen"]:
                continue
            state["seen"].add(nid)
            if first:
                continue                            # backlog in Action Center at startup: never announce
            app_info = n.app_info
            display = getattr(getattr(app_info, "display_info", None), "display_name", "") or ""
            aumid = getattr(app_info, "app_user_model_id", "") or ""
            if not _w._is_whatsapp_source(display, aumid):
                continue
            age = _toast_age_seconds(n)
            if age is not None and age > INCOMING_MAX_AGE_SECONDS:
                continue
            info = classify_call_toast(_w._binding_texts(n))
            if info is None:
                continue
            if info["kind"] == "incoming":
                state["fired"][nid] = info["caller"]
                on_call(info["caller"], info["video"])
            else:
                on_end(info["caller"], True)
        except Exception:
            continue
    state["baseline_done"] = True
    if len(state["seen"]) > 800:
        state["seen"] = set(list(state["seen"])[-400:])
    for nid in [i for i in state["fired"] if i not in current_ids]:
        caller = state["fired"].pop(nid)
        try:
            on_end(caller, False)                   # toast vanished: answered, declined or caller hung up
        except Exception:
            pass


def _watch_loop(on_call, on_end, log) -> None:
    import asyncio
    try:
        from winsdk.windows.ui.notifications.management import (
            UserNotificationListener, UserNotificationListenerAccessStatus)
    except Exception as error:
        log(f"WhatsApp call watcher disabled: winsdk unavailable ({error}).")
        return
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    listener = UserNotificationListener.get_current()
    try:
        status = loop.run_until_complete(listener.request_access_async())
    except Exception as error:
        log(f"WhatsApp call watcher disabled: no notification access ({error}).")
        return
    if status != UserNotificationListenerAccessStatus.ALLOWED:
        log("WhatsApp call watcher disabled: notification access not granted.")
        return
    state = {"seen": set(), "fired": {}, "baseline_done": False}
    log("WhatsApp incoming-call watcher active.")
    while True:
        try:
            loop.run_until_complete(_poll_calls(listener, state, on_call, on_end))
        except Exception:
            traceback.print_exc()
        time.sleep(INCOMING_POLL_SECONDS)


def start_incoming_watcher(on_call: Callable[[str, bool], None],
                           on_end: Callable[[str, bool], None],
                           log: Optional[Callable[[str], None]] = None) -> bool:
    """Safe to call unconditionally at startup (silent no-op off Windows)."""
    global _watch_started
    log = log or (lambda m: print("[friday_whatsapp_calls]", m))
    if not IS_WINDOWS:
        log("WhatsApp call watcher disabled: Windows-only feature.")
        return False
    with _watch_lock:
        if _watch_started:
            return True
        _watch_started = True
    threading.Thread(target=_watch_loop, args=(on_call, on_end, log),
                     name="Friday-WhatsApp-CallWatch", daemon=True).start()
    return True


# ------------------------------------------------------------
# Conversation state machine
# ------------------------------------------------------------

class CallController:
    """Voice/typed conversation for WhatsApp calls. All dependencies on the
    rest of FRIDAY are injected, so it is testable without the backend.

    resolve_contact(raw, full_command) -> (name, "high"|"low")
    yes_no(text) -> "yes" | "no" | None
    is_cancel(text) -> bool
    """

    def __init__(self, speak, resolve_contact, ask_to_spell, parse_spelled, yes_no, is_cancel,
                 load_contacts, save_contacts, flow_in_progress, clear_pending_questions,
                 log=None, actions=None, clock=time.time):
        self.speak = speak
        self.resolve_contact = resolve_contact
        self.ask_to_spell = ask_to_spell
        self.parse_spelled = parse_spelled
        self.yes_no = yes_no
        self.is_cancel = is_cancel
        self.load_contacts = load_contacts
        self.save_contacts = save_contacts
        self.flow_in_progress = flow_in_progress
        self.clear_pending_questions = clear_pending_questions
        self.log = log or (lambda m: None)
        self.actions = actions or UiActions()
        self.clock = clock
        self._lock = threading.RLock()
        self._out = None          # outgoing flow: {"stage", "contact", "video"}
        self._incoming = None     # {"caller","video","asks","deadline","explicit_only"}
        self._active = None       # {"who","ts"}
        self._recent = {}         # caller.lower() -> ts of last resolution

    # ---- public entry point (called first thing in handle_command) ----
    def handle(self, command: str):
        text = (command or "").strip()
        if not text:
            return None
        with self._lock:
            self._expire()
            incoming, out = self._incoming, self._out
        if incoming is not None:
            result = self._incoming_reply(text, incoming)
            if result is not None:
                return result
        if out is not None:
            result = self._outgoing_reply(text, out)
            if result is not None:
                return result
        control = self._explicit_control(text)
        if control is not None:
            return control
        if out is None and not self.flow_in_progress():
            parsed = parse_call_command(text)
            if parsed is not None:
                return self._begin_outgoing(parsed, text)
        return None

    def has_pending_question(self) -> bool:
        """True while a call question (incoming ring or outgoing flow) is open."""
        with self._lock:
            self._expire()
            return self._incoming is not None or self._out is not None

    # ---- incoming ----
    def on_incoming(self, caller: str, video: bool) -> None:
        caller = (caller or "").strip()
        with self._lock:
            self._expire()
            if self._incoming is not None:
                return                                      # already ringing / already asked
            busy = self._out is not None or self.flow_in_progress()
            if not busy:
                self.clear_pending_questions()              # a ringing call outranks any other yes/no
            self._incoming = {
                "caller": caller, "video": bool(video), "asks": 1,
                "deadline": self.clock() + INCOMING_QUESTION_TTL, "explicit_only": busy,
            }
        who = caller or "an unknown number"
        kind = "video calling" if video else "calling"
        if busy:
            self.speak(f"Sir, {who} is {kind} you on WhatsApp. Say answer the call if you want me to pick up.")
        else:
            self.speak(f"Sir, {who} is {kind} you on WhatsApp. Shall I answer it?")

    def on_call_end(self, caller: str, missed: bool) -> None:
        caller = (caller or "").strip()
        with self._lock:
            inc = self._incoming
            same = inc is not None and (not caller or not inc["caller"]
                                        or _norm(caller) == _norm(inc["caller"]))
            if inc is not None and same:
                self._incoming = None
                who = inc["caller"] or "the caller"
                announce = "missed" if missed else "ended"
            else:
                who = caller or "someone"
                recently = self.clock() - self._recent.get(_norm(caller), 0) < 120
                announce = "missed" if (missed and not recently) else None
        if announce == "ended":
            self.speak(f"The WhatsApp call from {who} has ended, sir.")
        elif announce == "missed":
            self.speak(f"Sir, you missed a WhatsApp call from {who}.")

    def _expire(self):
        now = self.clock()
        if self._incoming is not None and now > self._incoming["deadline"]:
            self._incoming = None
        if self._active is not None and now - self._active["ts"] > ACTIVE_CALL_TTL:
            self._active = None

    def _mark_resolved(self, caller):
        self._recent[_norm(caller)] = self.clock()

    def _incoming_reply(self, text, inc):
        control = classify_control(text)
        action = control[0] if control else None
        if action == "answer":
            return self._do_answer(inc)
        if action == "decline":
            return self._do_decline(inc)
        if inc["explicit_only"]:
            return None
        if parse_call_command(text) is not None:
            with self._lock:
                self._incoming = None                       # they moved on to another call
            return None
        decision = self.yes_no(text)
        if decision == "yes":
            return self._do_answer(inc)
        if decision == "no":
            with self._lock:
                self._incoming = None
                self._mark_resolved(inc["caller"])
            self.speak("Understood, sir. I'll leave it ringing.")
            return True
        inc["asks"] += 1
        if inc["asks"] > 2:
            with self._lock:
                self._incoming = None
            return None
        self.speak(f"Sorry sir, shall I answer the call from {inc['caller'] or 'that number'}? Yes or no?")
        return True

    def _do_answer(self, inc):
        with self._lock:
            self._incoming = None
            self._mark_resolved(inc["caller"])
        ok, code = self.actions.answer()
        who = inc["caller"] or "the caller"
        if ok and code == "connected":
            with self._lock:
                self._active = {"who": who, "ts": self.clock()}
            self.speak(f"Answered, sir. You're connected to {who}.")
        elif ok:
            with self._lock:
                self._active = {"who": who, "ts": self.clock()}
            self.speak("I pressed accept, sir, but I couldn't confirm the call connected.")
        else:
            self.speak(_failure_text("answer", code))
        return True

    def _do_decline(self, inc):
        with self._lock:
            self._incoming = None
            self._mark_resolved(inc["caller"])
        ok, code = self.actions.decline()
        self.speak("Call declined, sir." if ok else _failure_text("decline", code))
        return True

    # ---- explicit control without a pending question ----
    def _explicit_control(self, text):
        control = classify_control(text)
        if control is None:
            return None
        action, has_call = control
        mentions_wa = bool(re.search(r"whats\s?app", text, re.I))
        if action == "hangup":
            known = self._active is not None
            if not (known or mentions_wa or self.actions.call_window_present()):
                return None                                 # not ours to handle
            ok, code = self.actions.hangup()
            if ok:
                with self._lock:
                    self._active = None
                self.speak("Call ended, sir.")
            elif code == "no_button":
                with self._lock:
                    self._active = None
                self.speak("I don't see an active WhatsApp call, sir.")
            else:
                self.speak(_failure_text("hangup", code))
            return True
        # answer / decline with nothing pending: only if clearly about a WhatsApp call
        if not (has_call and mentions_wa):
            return None
        ok, code = self.actions.answer() if action == "answer" else self.actions.decline()
        if ok:
            self.speak("Answered, sir." if action == "answer" else "Call declined, sir.")
        elif code == "no_button":
            self.speak("There's no incoming WhatsApp call showing right now, sir.")
        else:
            self.speak(_failure_text(action, code))
        return True

    # ---- outgoing ----
    def _begin_outgoing(self, parsed, command):
        video = parsed["video"]
        raw = parsed["contact"]
        if not raw:
            with self._lock:
                self._out = {"stage": "await_contact", "video": video}
            self.speak("Who would you like to call on WhatsApp?")
            return True
        contact, confidence = self.resolve_contact(raw, command)
        if not contact:
            with self._lock:
                self._out = {"stage": "await_contact", "video": video}
            self.speak("Who would you like to call on WhatsApp?")
            return True
        if confidence == "low":
            with self._lock:
                self._out = {"stage": "await_spelling", "video": video}
            self.ask_to_spell(contact)
            return True
        return self._ask_confirm(contact, video)

    def _ask_confirm(self, contact, video):
        with self._lock:
            self._out = {"stage": "confirm", "contact": contact, "video": video, "asks": 1}
        what = "start a WhatsApp video call with" if video else "call"
        tail = "" if video else " on WhatsApp"
        self.speak(f"Shall I {what} {contact}{tail}, sir?")
        return True

    def _outgoing_reply(self, text, out):
        stage = out["stage"]
        video = out["video"]
        if stage in ("await_contact", "await_spelling") and self.is_cancel(text):
            self._reset_out()
            self.speak("Okay, I've cancelled that call.")
            return True

        if stage == "await_contact":
            contact, confidence = self.resolve_contact(text.strip(" .,:-\"'"), text)
            if not contact:
                self.speak("Sorry, I didn't catch a name. Who would you like to call on WhatsApp?")
                return True
            if confidence == "low":
                with self._lock:
                    self._out = {"stage": "await_spelling", "video": video}
                self.ask_to_spell(contact)
                return True
            return self._ask_confirm(contact, video)

        if stage == "await_spelling":
            spelled = self.parse_spelled(text)
            if not spelled:
                self.speak("Sorry, I still didn't catch that. Could you spell the name letter by letter?")
                return True
            try:
                known = self.load_contacts()
                if spelled.lower() not in [c.lower() for c in known]:
                    known.append(spelled)
                    self.save_contacts(known)
            except Exception:
                pass
            return self._ask_confirm(spelled, video)

        if stage == "confirm":
            contact = out["contact"]
            decision = self.yes_no(text)
            if decision == "yes":
                return self._place_call(contact, video)
            if decision == "no":
                self._reset_out()
                self.speak("Understood, sir. I've cancelled the call.")
                return True
            out["asks"] = out.get("asks", 1) + 1
            if out["asks"] > 2:
                self._reset_out()
                return None
            self.speak(f"Sorry sir, shall I call {contact} on WhatsApp? Yes or no?")
            return True
        return None

    def _reset_out(self):
        with self._lock:
            self._out = None

    def _place_call(self, contact, video):
        self._reset_out()
        self.speak(f"Calling {contact} on WhatsApp, sir." if not video
                   else f"Starting a WhatsApp video call with {contact}, sir.")
        ok, code = self.actions.start_call(contact, video, self.log)
        if ok:
            with self._lock:
                self._active = {"who": contact, "ts": self.clock()}
            try:
                known = self.load_contacts()
                if contact.lower() not in [c.lower() for c in known]:
                    known.append(contact)
                    self.save_contacts(known)
            except Exception:
                pass
            if code == "ringing":
                self.speak(f"It's ringing, sir.")
            else:
                self.speak("I pressed the call button, sir, but I couldn't confirm that it's ringing. "
                           "Please glance at WhatsApp.")
        else:
            self.speak(_failure_text("call", code, contact))
        return True


def _failure_text(action: str, code: str, contact: str = "") -> str:
    if code == "not_windows":
        return "WhatsApp calling only works on Windows, sir."
    if code == "no_automation":
        return "I can't place WhatsApp calls yet, sir. The automation libraries aren't installed."
    if code == "no_uia":
        return "I need the pywinauto package to control WhatsApp calls, sir. Please run pip install pywinauto."
    if code == "not_ready":
        return "I couldn't bring WhatsApp to the front, sir, so I didn't call anyone."
    if code == "wrong_chat":
        return (f"The chat that opened doesn't look like {contact}, sir, so I didn't call. "
                "Please check the name and try again.")
    if code == "no_button":
        if action == "call":
            return "I couldn't find WhatsApp's call button, sir. I've noted what I saw in the event log."
        if action == "answer":
            return "I couldn't find the answer button, sir. The call may have already ended."
        if action == "decline":
            return "I couldn't find the decline button, sir."
        return "I couldn't find WhatsApp's end call button, sir."
    return "Something went wrong controlling WhatsApp, sir."
