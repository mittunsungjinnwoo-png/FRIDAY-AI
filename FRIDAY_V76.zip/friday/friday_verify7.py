"""FRIDAY 7.0 Universal Execution Verification Engine  (roadmap #2).

Every tool call goes through `execute()`, which returns a structured RECEIPT - evidence of success or failure - so FRIDAY only reports
what actually happened ("the file exists", "the application is running"), never what a tool merely claimed.

* execution receipts      id, tool, args, attempts, timing, evidence list, postcondition results, claim text
* postcondition checks    file exists / non-empty / contains, process running, JSON valid, Python compiles, number in range, regex, ...
* safe retries            only idempotent tools, only for transient / resource failures, with back-off. A tool with side effects is never
                          blindly repeated: after a time-out its postconditions are checked to find out whether it already worked.
* failure classification  transient | resource | permission | dependency | not_found | invalid_args | timeout | verification | cancelled | unknown
                          each with a recovery strategy hint the orchestrator / planner act on
* recovery checkpoints    named, optionally verified, state snapshots per job so work can resume from the last verified point
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS receipts7(id INTEGER PRIMARY KEY, rid TEXT, ts REAL, job TEXT, step INTEGER, tool TEXT, args TEXT, status TEXT, ok INTEGER,
    failure_class TEXT, attempts INTEGER, ms INTEGER, evidence TEXT, post TEXT, error TEXT, output TEXT, claim TEXT, checkpoint TEXT);
CREATE INDEX IF NOT EXISTS ix_receipts7_job ON receipts7(job);
CREATE TABLE IF NOT EXISTS checkpoints7(id INTEGER PRIMARY KEY, cid TEXT UNIQUE, ts REAL, job TEXT, label TEXT, state TEXT, verified INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_checkpoints7_job ON checkpoints7(job);
""")

BACKOFF_SCALE = 1.0          # tests set this to 0 so retries are instant
MAX_STATE_BYTES = 200_000

# failure class -> policy
POLICY: Dict[str, Dict] = {
    "transient": {"retry": True, "max": 2, "backoff": (0.4, 1.2), "strategy": "retry_same", "hint": "temporary problem - retried safely"},
    "timeout": {"retry": True, "max": 1, "backoff": (0.6,), "strategy": "retry_same", "hint": "took too long"},
    "resource": {"retry": True, "max": 1, "backoff": (1.0,), "strategy": "wait_for_resources", "hint": "the machine is short of memory or disk"},
    "unknown": {"retry": True, "max": 1, "backoff": (0.5,), "strategy": "retry_same", "hint": "unexpected failure"},
    "permission": {"retry": False, "max": 0, "backoff": (), "strategy": "ask_user", "hint": "needs your permission"},
    "dependency": {"retry": False, "max": 0, "backoff": (), "strategy": "fallback_tool", "hint": "a required component is missing"},
    "not_found": {"retry": False, "max": 0, "backoff": (), "strategy": "change_args", "hint": "the target was not found"},
    "invalid_args": {"retry": False, "max": 0, "backoff": (), "strategy": "change_args", "hint": "the inputs were not valid"},
    "verification": {"retry": False, "max": 0, "backoff": (), "strategy": "revise_plan", "hint": "it ran but the result did not check out"},
    "cancelled": {"retry": False, "max": 0, "backoff": (), "strategy": "abort", "hint": "cancelled"},
}

_RX = [
    ("cancelled", r"\bcancel(?:l)?ed\b|\binterrupted by user\b"),
    ("permission", r"permission|not allowed|access is denied|forbidden|not approved|unauthori[sz]ed|denied|\b403\b|\b401\b|read-only file system|operation not permitted"),
    ("dependency", r"no module named|modulenotfound|importerror|not installed|missing (?:api )?key|no (?:api )?key|dll load failed|command not found|is not recognized as|executable (?:not found|doesn't exist)|requires? (?:the )?\w+ package|library .* (?:missing|unavailable)"),
    ("not_found", r"no such file|file not found|filenotfound|not found|cannot find|does not exist|doesn't exist|unknown tool|unknown app|no match|\b404\b|nothing found|could not locate"),
    ("invalid_args", r"invalid|missing (?:required )?(?:argument|parameter|field)|typeerror|keyerror|valueerror|unexpected keyword|malformed|cannot parse|bad (?:request|input|format)|must be|expected .* got|syntax error|syntaxerror"),
    ("timeout", r"timed? ?out|time-?out|deadline exceeded"),
    ("transient", r"temporar|connection (?:reset|refused|aborted|error)|network|unreachable|rate.?limit|too many requests|\b429\b|\b50[0234]\b|try again|busy|unavailable|ssl|dns|name resolution|econn|broken pipe|reset by peer"),
    ("resource", r"memoryerror|out of memory|no space left|disk full|too many open files|resource exhausted"),
]


def classify_failure(error: str = "", result: Optional[Dict] = None, post_failed: bool = False) -> str:
    """Map an error message (and result flags) to a failure class."""
    res = result or {}
    if res.get("cancelled"):
        return "cancelled"
    if res.get("timeout"):
        return "timeout"
    if res.get("denied"):
        return "permission"
    text = (error or "").lower()
    for cls, rx in _RX:
        if re.search(rx, text):
            return cls
    if post_failed:
        return "verification"
    return "unknown"


# ------------------------------------------------------------------ postcondition checks (True / False / None = could not check)
Check = Tuple[Optional[bool], str]


def _path_of(val: Any, res: Dict, args: Dict) -> str:
    if isinstance(val, str) and val and val not in ("1", "true", "True"):
        try:
            return val.format_map({**{k: v for k, v in (args or {}).items() if isinstance(v, (str, int, float))}, "path": res.get("path") or (args or {}).get("path") or ""})
        except Exception:
            return val
    return str(res.get("path") or (args or {}).get("path") or (args or {}).get("name") or "")


def verify_file(path: str, min_bytes: int = 1, contains: Optional[str] = None, newer_than: Optional[float] = None) -> Check:
    if not path:
        return False, "no file path was reported"
    p = Path(path)
    if not p.exists():
        return False, f"{p.name} does not exist"
    if p.is_dir():
        return True, f"folder {p.name} exists"
    size = p.stat().st_size
    if size < min_bytes:
        return False, f"{p.name} exists but is only {size} bytes"
    if newer_than is not None and p.stat().st_mtime < newer_than - 2:
        return False, f"{p.name} exists but was not modified by this step"
    if contains is not None:
        try:
            body = p.read_text(encoding="utf-8", errors="ignore")
        except Exception as exc:
            return None, f"could not read {p.name}: {exc}"
        if contains.lower() not in body.lower():
            return False, f"{p.name} does not contain the expected text"
    return True, f"{p.name} exists ({size} bytes)"


def verify_process(name: str) -> Check:
    try:
        import psutil
    except Exception:
        return None, "process list unavailable (psutil missing)"
    want = re.sub(r"\.exe$", "", name.lower().strip())
    if not want:
        return None, "no process name given"
    try:
        for p in psutil.process_iter(["name"]):
            n = re.sub(r"\.exe$", "", (p.info.get("name") or "").lower())
            if n and (want in n or n in want and len(n) > 3):
                return True, f"process {p.info.get('name')} is running"
    except Exception as exc:
        return None, f"process check failed: {exc}"
    return False, f"no running process matches {name}"


def verify_app_launched(name: str) -> Check:
    return verify_process(name)


def _num(text: str) -> Optional[float]:
    m = re.search(r"-?\d[\d,]*\.?\d*", str(text))
    if not m:
        return None
    try:
        return float(m.group(0).replace(",", ""))
    except Exception:
        return None


def run_postconditions(res: Dict, args: Dict, post: Optional[Dict], started: float = 0.0) -> List[Dict]:
    """post: {check: param}. Params may be callables fn(res, args) -> bool | (bool, evidence)."""
    out: List[Dict] = []
    if not post:
        return out
    output = str(res.get("output", ""))
    for name, val in post.items():
        try:
            if callable(val):
                r = val(res, args)
                ok, ev = (r if isinstance(r, tuple) else (bool(r), "custom check"))
            elif name == "ok_true":
                ok, ev = bool(res.get("ok")), "tool reported success" if res.get("ok") else "tool reported failure"
            elif name == "nonempty":
                ok, ev = bool(output.strip()), f"{len(output)} characters returned" if output.strip() else "empty result"
            elif name == "contains":
                ok = str(val).lower() in output.lower()
                ev = f"result contains {val!r}" if ok else f"result does not contain {val!r}"
            elif name == "not_contains":
                ok = str(val).lower() not in output.lower()
                ev = f"result is free of {val!r}" if ok else f"result unexpectedly contains {val!r}"
            elif name == "regex":
                ok = bool(re.search(str(val), output, re.I | re.S))
                ev = "pattern matched" if ok else "pattern did not match"
            elif name in ("file_exists", "file_nonempty"):
                ok, ev = verify_file(_path_of(val, res, args), 1 if name == "file_nonempty" else 0)
            elif name == "file_contains":
                ok, ev = verify_file(_path_of(res.get("path") or args.get("path") or "", res, args), 1, contains=str(val))
            elif name == "file_fresh":
                ok, ev = verify_file(_path_of(val, res, args), 1, newer_than=started or None)
            elif name == "min_bytes":
                p = Path(_path_of(True, res, args))
                ok = p.exists() and p.stat().st_size >= int(val)
                ev = f"{p.name} has {p.stat().st_size if p.exists() else 0} bytes (need {val})"
            elif name == "dir_exists":
                p = Path(_path_of(val, res, args))
                ok, ev = p.is_dir(), f"folder {p} {'exists' if p.is_dir() else 'does not exist'}"
            elif name == "process_running":
                ok, ev = verify_process(str(val) if isinstance(val, str) and val not in ("1", "true", "True") else str(args.get("name") or args.get("app") or ""))
            elif name == "json_valid":
                try:
                    json.loads(output if val is True else str(val))
                    ok, ev = True, "valid JSON"
                except Exception as exc:
                    ok, ev = False, f"invalid JSON: {exc}"
            elif name == "python_compiles":
                src = output
                p = Path(_path_of(val, res, args)) if val is not True and isinstance(val, str) else None
                if p and p.exists():
                    src = p.read_text(encoding="utf-8", errors="ignore")
                try:
                    ast.parse(src)
                    ok, ev = True, "Python parses"
                except SyntaxError as exc:
                    ok, ev = False, f"syntax error line {exc.lineno}: {exc.msg}"
            elif name == "number_between":
                lo, hi = val
                n = _num(output) if res.get("value") is None else res.get("value")
                ok = n is not None and lo <= float(n) <= hi
                ev = f"value {n} is {'within' if ok else 'outside'} [{lo}, {hi}]"
            elif name == "min_items":
                items = res.get("items")
                n = len(items) if isinstance(items, (list, tuple)) else len([ln for ln in output.splitlines() if ln.strip()])
                ok, ev = n >= int(val), f"{n} item(s) (need {val})"
            else:
                ok, ev = None, f"unknown check {name}"
        except Exception as exc:
            ok, ev = None, f"check {name} could not run: {type(exc).__name__}: {exc}"
        out.append({"check": name, "ok": ok, "evidence": K.clip(ev, 200)})
    return out


# ------------------------------------------------------------------ execution
def _norm_result(r: Any) -> Dict:
    if isinstance(r, dict):
        d = dict(r)
        d.setdefault("ok", not d.get("error"))
        d["ok"] = bool(d["ok"])
        d.setdefault("output", "")
        return d
    if r is None:
        return {"ok": False, "output": "", "error": "the tool returned nothing"}
    if isinstance(r, bool):
        return {"ok": r, "output": "", "error": "" if r else "the tool reported failure"}
    return {"ok": True, "output": str(r)}


def _call_with_timeout(fn: Callable, args: Dict, timeout: float, cancel: Optional[threading.Event]) -> Dict:
    box: Dict = {}

    def run():
        try:
            box["r"] = fn(args)
        except Exception as exc:
            box["e"] = exc

    th = threading.Thread(target=run, daemon=True, name="FridayExec7")
    t0 = time.time()
    th.start()
    while th.is_alive():
        th.join(0.05)
        if cancel is not None and cancel.is_set():
            return {"ok": False, "error": "cancelled", "cancelled": True, "output": ""}
        if time.time() - t0 > timeout:
            return {"ok": False, "error": f"timed out after {timeout:g}s", "timeout": True, "output": ""}
    if "e" in box:
        e = box["e"]
        return {"ok": False, "error": f"{type(e).__name__}: {e}", "output": "", "exception": type(e).__name__}
    return _norm_result(box.get("r"))


def _claim(status: str, tool: str, res: Dict, post: List[Dict], err: str, attempts: int) -> str:
    good = [p["evidence"] for p in post if p["ok"] is True]
    if status == "verified":
        return f"Verified: {'; '.join(good) if good else tool + ' completed'}."
    if status == "unverified":
        return f"{tool} finished but I could not independently confirm the result."
    if status == "cancelled":
        return f"{tool} was cancelled before it finished."
    bad = [p["evidence"] for p in post if p["ok"] is False]
    why = "; ".join(bad) if bad else (err or "it failed")
    return f"{tool} did not succeed: {why}" + (f" (after {attempts} attempts)" if attempts > 1 else "") + "."


def execute(fn: Callable[[Dict], Any], args: Optional[Dict] = None, *, tool: str = "", post: Optional[Dict] = None, job: str = "", step: int = 0,
            idempotent: bool = True, retries: Optional[int] = None, timeout: float = 60.0, cancel: Optional[threading.Event] = None,
            sleep: Callable[[float], None] = time.sleep) -> Dict:
    """Run fn(args) and return a receipt. Never raises."""
    args = dict(args or {})
    tool = tool or getattr(fn, "__name__", "tool")
    t_start = time.time()
    attempts = 0
    classes: List[str] = []
    res: Dict = {}
    post_res: List[Dict] = []
    status, fclass, err = "failed", "", ""
    cap = 3
    while True:
        attempts += 1
        if cancel is not None and cancel.is_set():
            res = {"ok": False, "error": "cancelled", "cancelled": True, "output": ""}
        else:
            res = _call_with_timeout(fn, args, timeout, cancel)
        err = str(res.get("error") or "")
        post_res = []
        # postconditions run when the tool says it worked, and ALSO after a time-out of a side-effecting tool (it may have finished anyway)
        if post and (res.get("ok") or (res.get("timeout") and not idempotent)):
            post_res = run_postconditions(res, args, post, started=t_start)
        post_bad = any(p["ok"] is False for p in post_res)
        post_unknown = any(p["ok"] is None for p in post_res)
        if res.get("cancelled"):
            status, fclass = "cancelled", "cancelled"
            break
        if res.get("ok") and not post_bad:
            status, fclass = ("verified" if post_res and not post_unknown else "unverified"), ""
            break
        if res.get("timeout") and not idempotent and post_res and all(p["ok"] is True for p in post_res):
            status, fclass = "verified", ""
            res["ok"] = True
            res["note"] = "timed out but the result is present"
            break
        fclass = classify_failure(err, res, post_failed=post_bad)
        classes.append(fclass)
        pol = POLICY.get(fclass, POLICY["unknown"])
        max_retry = retries if retries is not None else pol["max"]
        if idempotent and pol["retry"] and attempts <= max_retry and attempts < cap + 1:
            delay = (pol["backoff"][min(attempts - 1, len(pol["backoff"]) - 1)] if pol["backoff"] else 0.3) * BACKOFF_SCALE
            if delay > 0:
                sleep(delay)
            continue
        status = "failed"
        break
    ms = int((time.time() - t_start) * 1000)
    if status == "failed" and not err and post_res:
        err = "; ".join(p["evidence"] for p in post_res if p["ok"] is False) or "the result did not pass its checks"
    rec = {
        "rid": K.new_id("R"), "ts": time.time(), "job": job, "step": step, "tool": tool, "args": args, "status": status, "ok": status in ("verified", "unverified"),
        "failure_class": fclass, "attempts": attempts, "ms": ms, "post": post_res, "error": K.clip(err, 300), "output": K.clip(res.get("output", ""), 2000),
        "path": res.get("path", ""), "strategy": POLICY.get(fclass, {}).get("strategy", "") if fclass else "", "retried_classes": classes,
        "idempotent": idempotent,
    }
    rec["evidence"] = [p["evidence"] for p in post_res if p["ok"] is not None]
    rec["claim"] = _claim(status, tool, res, post_res, err, attempts)
    rec["result"] = {k: v for k, v in res.items() if k not in ("output",)}
    try:
        C.x("INSERT INTO receipts7(rid,ts,job,step,tool,args,status,ok,failure_class,attempts,ms,evidence,post,error,output,claim,checkpoint) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (rec["rid"], rec["ts"], job, step, tool, C.redact(K.jd(args))[:1500], status, int(rec["ok"]), fclass, attempts, ms, K.jd(rec["evidence"]), K.jd(post_res),
             rec["error"], C.redact(rec["output"]), rec["claim"], ""))
    except Exception as exc:
        C.log(f"receipt not stored: {exc}", "recovery")
    K.emit("receipt", rec)
    return rec


# ------------------------------------------------------------------ checkpoints
def save_checkpoint(job: str, label: str, state: Any, verified: bool = False) -> str:
    blob = K.jd(state)
    if len(blob) > MAX_STATE_BYTES:
        blob = blob[:MAX_STATE_BYTES]
        blob = K.jd({"truncated": True})
    cid = K.new_id("CP")
    C.x("INSERT INTO checkpoints7(cid,ts,job,label,state,verified) VALUES(?,?,?,?,?,?)", (cid, time.time(), job, K.clip(label, 80), blob, int(bool(verified))))
    return cid


def mark_verified(cid: str):
    C.x("UPDATE checkpoints7 SET verified=1 WHERE cid=?", (cid,))


def get_checkpoint(cid: str) -> Optional[Dict]:
    r = C.q("SELECT * FROM checkpoints7 WHERE cid=?", (cid,))
    if not r:
        return None
    d = dict(r[0])
    d["state"] = K.jl(d["state"], {})
    return d


def last_checkpoint(job: str, verified_only: bool = False) -> Optional[Dict]:
    sql = "SELECT * FROM checkpoints7 WHERE job=?" + (" AND verified=1" if verified_only else "") + " ORDER BY id DESC LIMIT 1"
    r = C.q(sql, (job,))
    if not r:
        return None
    d = dict(r[0])
    d["state"] = K.jl(d["state"], {})
    return d


def checkpoints(job: str) -> List[Dict]:
    return [{"cid": r["cid"], "label": r["label"], "verified": bool(r["verified"]), "when": C.iso(r["ts"])} for r in C.q("SELECT * FROM checkpoints7 WHERE job=? ORDER BY id", (job,))]


# ------------------------------------------------------------------ reading receipts
def _row(r) -> Dict:
    d = dict(r)
    d["post"] = K.jl(d.get("post"), [])
    d["evidence"] = K.jl(d.get("evidence"), [])
    d["args"] = K.jl(d.get("args"), {})
    d["when"] = C.iso(d["ts"])
    return d


def receipts(job: Optional[str] = None, n: int = 20) -> List[Dict]:
    if job:
        rows = C.q("SELECT * FROM receipts7 WHERE job=? ORDER BY id DESC LIMIT ?", (job, n))
    else:
        rows = C.q("SELECT * FROM receipts7 ORDER BY id DESC LIMIT ?", (n,))
    return [_row(r) for r in rows]


def stats(since_s: Optional[float] = None) -> Dict:
    cut = time.time() - since_s if since_s else 0
    rows = C.q("SELECT tool, COUNT(*) n, SUM(ok) good, AVG(ms) ms, SUM(CASE WHEN status='verified' THEN 1 ELSE 0 END) ver FROM receipts7 WHERE ts>=? GROUP BY tool ORDER BY n DESC", (cut,))
    by_tool = []
    for r in rows:
        last = C.q("SELECT error, failure_class FROM receipts7 WHERE tool=? AND ok=0 AND ts>=? ORDER BY id DESC LIMIT 1", (r["tool"], cut))
        by_tool.append({"tool": r["tool"], "calls": r["n"], "ok": r["good"] or 0, "rate": round((r["good"] or 0) / max(1, r["n"]), 3), "avg_ms": int(r["ms"] or 0),
                        "verified": r["ver"] or 0, "last_error": last[0]["error"] if last else "", "last_class": last[0]["failure_class"] if last else ""})
    tot = sum(t["calls"] for t in by_tool)
    return {"by_tool": by_tool, "total": tot, "success_rate": round(sum(t["ok"] for t in by_tool) / max(1, tot), 3), "verified_rate": round(sum(t["verified"] for t in by_tool) / max(1, tot), 3),
            "classes": {r["failure_class"]: r["n"] for r in C.q("SELECT failure_class, COUNT(*) n FROM receipts7 WHERE ok=0 AND ts>=? GROUP BY failure_class", (cut,))}}


def prune(days: int) -> int:
    cut = time.time() - days * 86400
    n = len(C.q("SELECT id FROM receipts7 WHERE ts<?", (cut,)))
    C.x("DELETE FROM receipts7 WHERE ts<?", (cut,))
    C.x("DELETE FROM checkpoints7 WHERE ts<? AND verified=0", (cut,))
    return n


def spoken(rec: Dict) -> str:
    return rec.get("claim") or ("Done." if rec.get("ok") else "That failed.")
