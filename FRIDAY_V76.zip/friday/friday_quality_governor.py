"""FRIDAY V2034 quality governor.

Additive, dependency-free hardening layer. It never replaces the existing
voice, TTS, command, memory, vision, research or computer-control engines.
It observes runtime health and recommends the cheapest safe execution tier.
"""
from __future__ import annotations
import threading, time
from collections import defaultdict, deque

_lock = threading.RLock()
_stage = defaultdict(lambda: deque(maxlen=32))
_FEATURES = (
    "voice", "tts", "reasoning", "memory", "screen", "computer",
    "research", "study", "notes", "reliability", "ui", "autonomy"
)

def record(stage: str, elapsed_ms: float, ok: bool = True) -> None:
    with _lock:
        _stage[str(stage)].append((float(elapsed_ms), bool(ok), time.monotonic()))

def budget(stage: str, default_ms: float = 900.0) -> float:
    """Return an adaptive soft budget; never blocks or changes a command."""
    with _lock:
        rows = list(_stage.get(str(stage), ()))
    if len(rows) < 4:
        return float(default_ms)
    recent = [r[0] for r in rows[-12:]]
    avg = sum(recent) / len(recent)
    # Keep budgets stable: 0.75x..2.0x of the requested default.
    return max(default_ms * .75, min(default_ms * 2.0, max(default_ms, avg * 1.35)))

def health() -> dict:
    with _lock:
        out = {}
        for name, rows in _stage.items():
            if not rows:
                continue
            vals = [x[0] for x in rows]
            out[name] = {
                "samples": len(rows),
                "avg_ms": round(sum(vals) / len(vals), 1),
                "success": round(sum(1 for x in rows if x[1]) / len(rows), 3),
            }
    return out

def feature_names():
    return list(_FEATURES)

class Scope:
    def __init__(self, stage: str):
        self.stage = str(stage)
        self.started = time.perf_counter()
    def finish(self, ok: bool = True) -> float:
        ms = (time.perf_counter() - self.started) * 1000.0
        record(self.stage, ms, ok)
        return ms
