"""FRIDAY 7.0 shared plumbing for the Ultimate Intelligence layer.

* one settings store (table cfg7) with documented defaults
* a tiny in-process event bus so engines stay loosely coupled (orchestrator -> health / learning / graph / memory ...)
* the FRIDAY_V7:: UI channel (same transport as the 6.0 Command Centre)
* small helpers (ids, clock, bounded text, JSON)

Nothing here touches the microphone, recognition or speech code.
"""
from __future__ import annotations

import base64
import json
import os
import re
import threading
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

import friday_common6 as C

VERSION = "7.0"
SESSION_ID = uuid.uuid4().hex[:8]
STARTED = time.time()

C.register_schema("""
CREATE TABLE IF NOT EXISTS cfg7(k TEXT PRIMARY KEY, v TEXT, ts REAL);
""")

# setting -> (default, help)
SETTINGS: Dict[str, tuple] = {
    "autonomy_level": ("balanced", "ask_more | balanced | independent - how much FRIDAY may do without asking inside permissions you granted"),
    "auto_orchestrate": ("1", "1 = clear multi-step goals (research then cost then save ...) run as one verified mission automatically"),
    "proactive_enabled": ("1", "1 = FRIDAY may queue useful suggestions from your goals, tasks and preferences"),
    "proactive_speak": ("0", "1 = allowed to speak a suggestion aloud when you are idle (default: show only)"),
    "proactive_max_per_day": ("4", "most suggestions per day"),
    "proactive_min_gap_min": ("45", "minimum minutes between suggestions"),
    "quiet_start": ("22:00", "no spoken suggestions after this time"),
    "quiet_end": ("07:00", "no spoken suggestions before this time"),
    "stream_segments": ("1", "1 = long job reports are spoken sentence by sentence while the rest is still being prepared"),
    "light_ram_pct": ("88", "memory use that switches FRIDAY to light mode"),
    "light_cpu_pct": ("92", "CPU use that switches FRIDAY to light mode"),
    "speculate": ("1", "1 = begin cheap intent/memory lookups while the reply is being prepared"),
    "critic_budget": ("balanced", "never | balanced | always - when a second model call may review an important answer"),
    "ollama_model_code": ("", "optional local coder model name (e.g. qwen2.5-coder) used for programming questions"),
    "ollama_model_reasoning": ("", "optional local reasoning model name used for hard problems (needs plenty of RAM)"),
    "ollama_model_sensitive": ("", "optional local model used for private/confidential requests (default: your general local model)"),
    "retention_receipts_days": ("90", "days of execution receipts to keep"),
}

_cfg: Dict[str, Callable] = {"emit": lambda l: print(l, flush=True), "speak": lambda t: None, "speak_piece": None, "busy": lambda: False, "run_command": None}
_cfg_cache: Dict[str, str] = {}
_cache_lock = threading.Lock()


def configure(**kw):
    _cfg.update({k: v for k, v in kw.items() if v is not None})


def cfg_get(key: str, default: Optional[str] = None) -> str:
    with _cache_lock:
        if key in _cfg_cache:
            return _cfg_cache[key]
    try:
        r = C.q("SELECT v FROM cfg7 WHERE k=?", (key,))
    except Exception:
        r = []
    if r:
        v = str(r[0]["v"])
    else:
        v = str(default if default is not None else SETTINGS.get(key, ("", ""))[0])
    with _cache_lock:
        _cfg_cache[key] = v
    return v


def cfg_set(key: str, value: Any):
    v = str(value)
    C.x("INSERT INTO cfg7(k,v,ts) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, ts=excluded.ts", (key, v, C.now()))
    with _cache_lock:
        _cfg_cache[key] = v


def cfg_flag(key: str) -> bool:
    return cfg_get(key).strip().lower() in ("1", "true", "yes", "on")


def cfg_all() -> List[Dict]:
    return [{"key": k, "value": cfg_get(k), "default": d, "help": h} for k, (d, h) in SETTINGS.items()]


def reset_cache():
    with _cache_lock:
        _cfg_cache.clear()


# ------------------------------------------------------------------ event bus
_subs: Dict[str, List[Callable]] = {}
_bus_errors = {"count": 0, "last": ""}


def on(event: str, fn: Callable):
    _subs.setdefault(event, []).append(fn)


def off(event: str, fn: Callable):
    try:
        _subs.get(event, []).remove(fn)
    except ValueError:
        pass


def emit(event: str, payload: Any = None):
    """Fire-and-forget: a failing subscriber never breaks the emitter."""
    for fn in list(_subs.get(event, [])):
        try:
            fn(payload)
        except Exception as exc:
            _bus_errors["count"] += 1
            _bus_errors["last"] = f"{event}: {type(exc).__name__}: {exc}"[:160]
            C.log(f"v7 subscriber for {event} failed safely: {exc}", "recovery")


def bus_errors() -> Dict:
    return dict(_bus_errors)


# ------------------------------------------------------------------ UI channel
def emit_ui(kind: str, payload: Any):
    try:
        line = "FRIDAY_V7::" + base64.b64encode(json.dumps({"kind": kind, "data": payload}, ensure_ascii=False, default=str).encode("utf-8")).decode("ascii")
        _cfg["emit"](line)
    except Exception:
        pass


def say(text: str):
    try:
        _cfg["speak"](text)
    except Exception as exc:
        C.log(f"say failed: {exc}", "recovery")


def busy() -> bool:
    try:
        return bool(_cfg["busy"]())
    except Exception:
        return False


# ------------------------------------------------------------------ helpers
def xn(sql: str, args=()) -> int:
    """Run a write and return the number of ROWS AFFECTED (C.x returns the last inserted id, which is not a count)."""
    with C._lock:
        c = C.db()
        cur = c.execute(sql, tuple(args))
        c.commit()
        return max(0, int(cur.rowcount or 0))


def new_id(prefix: str) -> str:
    return f"{prefix}-{time.strftime('%y%m%d')}-{uuid.uuid4().hex[:5]}"


def jd(o) -> str:
    return json.dumps(o, ensure_ascii=False, default=str)


def jl(s, default=None):
    try:
        return json.loads(s) if isinstance(s, (str, bytes)) else (s if s is not None else default)
    except Exception:
        return default


def clip(text, n: int = 240) -> str:
    return C.clip(str(text if text is not None else ""), n)


def ago(ts: Optional[float]) -> str:
    if not ts:
        return "never"
    d = max(0, time.time() - float(ts))
    if d < 90:
        return "just now"
    if d < 3600:
        return f"{int(d // 60)} min ago"
    if d < 86400:
        return f"{int(d // 3600)} h ago"
    return f"{int(d // 86400)} d ago"


def strip_wake(text: str) -> str:
    return re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (text or "").strip(), flags=re.I)


def norm_cmd(text: str) -> str:
    return strip_wake(text).lower().strip(" .!?")


def ordinal_to_int(word: str) -> Optional[int]:
    w = (word or "").strip().lower()
    m = {"first": 1, "1st": 1, "one": 1, "second": 2, "2nd": 2, "two": 2, "third": 3, "3rd": 3, "three": 3, "fourth": 4, "4th": 4, "four": 4, "fifth": 5, "5th": 5, "five": 5}
    if w in m:
        return m[w]
    return int(w) if w.isdigit() else None


def is_test_env() -> bool:
    return os.environ.get("FRIDAY_TESTING") == "1"
