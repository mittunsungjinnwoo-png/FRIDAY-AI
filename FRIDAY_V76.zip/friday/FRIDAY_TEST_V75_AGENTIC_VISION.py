"""FRIDAY V7.5 agentic vision tests (headless; real OpenCV + OCR on a simulated desktop).  Run:  python FRIDAY_TEST_V75_AGENTIC_VISION.py
Needs opencv, numpy, pytesseract and the Tesseract program (the same things Settings > Vision already asks for)."""
import os, sys, tempfile, time, threading
os.environ.setdefault("FRIDAY_VISION_DATA", tempfile.mkdtemp(prefix="friday_av_"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import friday_agentic_vision as av

ok = True
def check(name, cond, extra=""):
    global ok
    ok &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))

# 1. only explicit requests are claimed; ordinary chat and code questions are not
av._say = lambda t: None
for fn in ("start_incident", "start_benchmark", "set_watch"):
    setattr(av, fn, lambda *a, **k: {"ok": True})
av.metrics_text = lambda: "m"
for c in ("fix the error on my screen", "what's wrong with my screen", "an error popped up", "scan my screen for problems", "watch my screen for errors"):
    check("claims: " + c, av.claim(c))
for c in ("fix the error in my python code", "what's wrong with this sentence", "solve this math problem", "open notepad", "hello friday", "how do i fix a syntax error"):
    check("leaves alone: " + c, not av.claim(c))
t = time.perf_counter()
for _ in range(5000):
    av.claim("what is the capital of france")
per = (time.perf_counter() - t) / 5000 * 1e6
check("routing costs almost nothing (%.0f microseconds)" % per, per < 200)

# 2. the whole benchmark: detect -> propose -> approve -> act -> verify, look-alikes ignored, restricted actions blocked
r = av.run_benchmark(save=False)
for row in r["rows"]:
    check("scenario: " + row["scenario"], row["ok"], f"expected {row['expected']} got {row['got']}")
check("task completion 100%", r["task_completion_pct"] == 100.0, r["task_completion_pct"])
check("no false detections", r["false_detection_pct"] == 0.0, r["false_detection_pct"])
check("recovery 100%", r["recovery_pct"] == 100.0, r["recovery_pct"])
check("nothing was clicked without a yes", r["counts"]["acted_without_yes"] == 0)
print("HEADLINE:", av.bench_headline(r))

# 3. the real approval broker with spoken yes / no / "that's not an error"
import friday_vision_hub as hub, friday_action_safety as sf
said = []
hub._speak = lambda t: said.append(t); hub.emit = lambda *a, **k: None; hub._log = lambda *a, **k: None
sf.set_hooks(emit=lambda k, p: None, speak=hub._speak)
# (start_incident was stubbed above for the routing test, so drive run_incident directly with the real asker)
def drive(name, replies):
    sc = [s for s in av._scenarios() if s["name"].startswith(name)][0]
    sim = av.make_sim(sc["spec"]); out = {}
    th = threading.Thread(target=lambda: out.update(av.run_incident(sim, record=False, source="user", settle=0.0, say=said.append, allow_cloud=False)), daemon=True)
    del said[:]; th.start()
    for rep in replies:
        for _ in range(300):
            if av.awaiting_answer(): break
            time.sleep(0.05)
        time.sleep(0.15); av.claim(rep)
        time.sleep(0.2)
    th.join(30); return sim, out
sim, out = drive("missing file", ["yes"]);                 check("spoken 'yes' -> fixed and verified", out.get("status") == "resolved" and not sim.dialogs, out.get("status"))
sim, out = drive("save error", ["no"]);                    check("spoken 'no' -> nothing clicked", out.get("status") == "declined" and len(sim.dialogs) == 1, out.get("status"))
sim, out = drive("save error", ["that's not an error"]);   check("'that's not an error' -> false alarm counted", out.get("status") == "false_alarm" and len(sim.dialogs) == 1, out.get("status"))
print("SPOKEN SAMPLE:", said[:2])
print("ALL PASS" if ok else "SOME FAILED"); sys.exit(0 if ok else 1)
