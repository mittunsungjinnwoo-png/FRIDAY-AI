"""FRIDAY 7.0 reliable computer-use engine (roadmap #11).

Stable APIs first, screen clicking last, and every consequential action is checked before it is reported as done:

    open_app         the installed-app launcher (Start Menu / Store / App Paths) - its own launch verification is kept as evidence
    open_file        the indexed file finder -> the OS "open" verb; a window carrying the file's name is the evidence
    window_control   Win32 window APIs (maximise / restore / minimise / focus) - the window state is read back afterwards
    file_op          create_folder / copy / move / rename with before/after checks; delete moves to a recoverable trash folder, never erases
    capture_verify   screenshot or file capture with provenance: what was captured, when, from which window, hash, and a non-blank check
    find_file        the fast indexed finder (read-only)
    computer_act     one natural-language command routed to the tools above (used by the specialist team)

Nothing here touches the microphone, speech recognition or speaking code.  On non-Windows machines the Windows-only parts report
"not available" instead of pretending.
"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

_IS_WINDOWS = sys.platform.startswith("win")
CAPTURE_DIR = lambda: (C.DATA_DIR / "captures")          # noqa: E731
TRASH_DIR = lambda: (C.DATA_DIR / "trash")               # noqa: E731

C.register_schema("""
CREATE TABLE IF NOT EXISTS captures7(id INTEGER PRIMARY KEY, ts REAL, kind TEXT, source TEXT, window TEXT, path TEXT, sha256 TEXT, width INTEGER, height INTEGER, verified INTEGER, note TEXT);
CREATE TABLE IF NOT EXISTS fileops7(id INTEGER PRIMARY KEY, ts REAL, op TEXT, src TEXT, dst TEXT, undo TEXT, ok INTEGER);
""")


def _res(ok: bool, output: str = "", error: str = "", **kw) -> Dict:
    d = {"ok": ok, "output": output, "error": error if not ok else ""}
    d.update(kw)
    return d


def _post_verified(res: Dict, args: Dict) -> Tuple[Optional[bool], str]:
    v = res.get("verified")
    if v is True:
        return True, res.get("evidence") or "the result was confirmed after the action"
    if v is False:
        return False, res.get("evidence") or "the result could not be confirmed"
    return None, "this action cannot be independently confirmed on this machine"


# ------------------------------------------------------------------ windows
def _titles() -> list:
    try:
        import friday_system_control as SC
        return [w.get("title", "") for w in SC.list_app_windows()]
    except Exception:
        return []


def window_with(text: str, timeout: float = 3.0, poll: float = 0.3) -> str:
    """Title of a visible window that contains `text` (or its words), waiting up to `timeout`. '' if none."""
    if not _IS_WINDOWS:
        return ""
    words = [w for w in re.findall(r"[a-z0-9]+", text.lower()) if len(w) > 1]
    if not words:
        return ""
    end = time.time() + timeout
    while True:
        for t in _titles():
            low = t.lower()
            if all(w in low for w in words) or (len(words) > 2 and sum(1 for w in words if w in low) >= len(words) - 1):
                return t
        if time.time() >= end:
            return ""
        time.sleep(poll)


def tool_window_control(a: Dict) -> Dict:
    action = str(a.get("action", "")).lower().replace("-", "_")
    app = str(a.get("app") or a.get("name") or "")
    if not _IS_WINDOWS:
        return _res(False, error="window control needs Windows", verified=False)
    try:
        import friday_system_control as SC
    except Exception as exc:
        return _res(False, error=f"window control unavailable: {exc}")
    fn = {"maximize": SC.maximize_application, "maximise": SC.maximize_application, "restore": SC.restore_down_application, "restore_down": SC.restore_down_application,
          "minimize": SC.minimize_application, "minimise": SC.minimize_application, "focus": getattr(SC, "focus_application", None)}.get(action)
    if fn is None:
        return _res(False, error=f"unknown window action '{action}'")
    r = fn(app) if app else fn()
    ok = bool(r.get("ok"))
    return _res(ok, output=f"{action} {app or 'the front window'}: {'done' if ok else r.get('error', 'not done')}", error=r.get("error", "window action failed"), verified=ok,
                evidence="window state read back after the action" if ok else "", detail={k: v for k, v in r.items() if k not in ("ok",)})


# ------------------------------------------------------------------ apps and files
def tool_open_app(a: Dict) -> Dict:
    name = str(a.get("name") or a.get("app") or "").strip()
    if not name:
        return _res(False, error="no application name given")
    try:
        import friday_desktop_agent as D
        r = D.launch_app(name)
    except Exception as exc:
        return _res(False, error=f"I couldn't launch it: {exc}")
    ok = bool(r.get("ok")) or bool(r.get("verified"))
    return _res(ok, output=f"{name}: " + ("opened" if ok else r.get("error", "not opened")), error=r.get("error", "not opened"), verified=bool(r.get("verified", False)) if ok else False,
                evidence=r.get("evidence") or (f"window confirmed: {r.get('active_window')}" if r.get("active_window") else ""), executed=bool(r.get("executed")))


def tool_find_file(a: Dict) -> Dict:
    q = str(a.get("query") or a.get("name") or "").strip()
    if not q:
        return _res(False, error="nothing to look for")
    try:
        import friday_filesearch7 as F
        hits = F.search(q, limit=int(a.get("limit", 5)))
    except Exception as exc:
        return _res(False, error=f"the file finder is unavailable: {exc}")
    if not hits:
        return _res(False, error=f"no file or folder matches '{q}'", items=[])
    lines = [f"{h['name']} - {h['path']}" for h in hits]
    return _res(True, output="\n".join(lines), items=lines, path=hits[0]["path"], verified=True, evidence=f"{len(hits)} match(es) from the file index")


def tool_open_file(a: Dict) -> Dict:
    path = str(a.get("path") or "").strip()
    q = str(a.get("query") or a.get("name") or "").strip()
    try:
        import friday_filesearch7 as F
        hit = None
        if path and Path(path).exists():
            hit = {"path": path, "name": Path(path).name, "stem": Path(path).stem, "confidence": "exact"}
        elif q or path:
            hit = F.best(q or path)
        if not hit:
            return _res(False, error=f"I couldn't find a file called '{q or path}'")
        if hit.get("confidence") == "low" and not a.get("force"):
            alts = ", ".join(str(x) for x in (hit.get("alternatives") or [])[:3])
            return _res(False, error=f"I'm not sure which file you mean ('{hit['name']}'" + (f", or {alts}" if alts else "") + ")")
        r = F.open_path(hit["path"])
        if not (r if isinstance(r, bool) else (r or {}).get("ok", True)):
            return _res(False, error=f"the system would not open {hit['name']}")
    except Exception as exc:
        return _res(False, error=f"couldn't open it: {exc}")
    title = window_with(hit.get("stem") or hit["name"], 4.0) if _IS_WINDOWS else ""
    tie_note = f" ({int(hit['ties']) + 1} files matched equally well; this is the most recent)" if hit.get("ties") else ""
    return _res(True, output=f"opened {hit['name']} ({hit['path']}){tie_note}", path=hit["path"], verified=True if title else (None if not _IS_WINDOWS else False),
                evidence=f"a window titled '{title}' is open" if title else "", opened=hit["path"])


# ------------------------------------------------------------------ file operations (reversible)
def _log_op(op: str, src: str, dst: str, undo: str, ok: bool):
    try:
        C.x("INSERT INTO fileops7(ts,op,src,dst,undo,ok) VALUES(?,?,?,?,?,?)", (C.now(), op, src, dst, undo, int(ok)))
    except Exception:
        pass


def tool_file_op(a: Dict) -> Dict:
    op = str(a.get("op") or a.get("action") or "").lower().replace(" ", "_")
    src = os.path.expandvars(os.path.expanduser(str(a.get("src") or a.get("path") or "")))
    dst = os.path.expandvars(os.path.expanduser(str(a.get("dst") or a.get("dest") or a.get("target") or "")))
    try:
        if op in ("create_folder", "mkdir"):
            p = Path(dst or src)
            existed = p.exists()
            p.mkdir(parents=True, exist_ok=True)
            ok = p.is_dir()
            _log_op(op, str(p), "", "" if existed else f"rmdir:{p}", ok)
            return _res(ok, output=f"folder {p} " + ("already existed" if existed else "created"), error="the folder was not created", path=str(p), verified=ok, evidence=f"{p} is a folder")
        s = Path(src)
        if not s.exists():
            return _res(False, error=f"{s} does not exist", verified=False)
        if op == "copy":
            d = Path(dst)
            if d.is_dir():
                d = d / s.name
            if d.exists():
                return _res(False, error=f"{d.name} already exists there; I won't overwrite it", verified=False)
            shutil.copytree(s, d) if s.is_dir() else shutil.copy2(s, d)
            ok = d.exists() and (s.is_dir() or d.stat().st_size == s.stat().st_size)
            _log_op(op, str(s), str(d), f"delete:{d}", ok)
            return _res(ok, output=f"copied {s.name} to {d}", error="the copy could not be confirmed", path=str(d), verified=ok, evidence=f"{d.name} exists with the same size")
        if op in ("move", "rename"):
            d = Path(dst)
            if op == "rename" and d.parent == Path("."):
                d = s.parent / d.name
            if d.is_dir():
                d = d / s.name
            if d.exists():
                return _res(False, error=f"{d.name} already exists there; I won't overwrite it", verified=False)
            d.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(s), str(d))
            ok = d.exists() and not s.exists()
            _log_op(op, str(s), str(d), f"move:{d}->{s}", ok)
            return _res(ok, output=f"{op}d {s.name} to {d}", error="the move could not be confirmed", path=str(d), verified=ok, evidence=f"{d.name} is at the new place and gone from the old one")
        if op in ("delete", "remove", "trash"):
            t = TRASH_DIR()
            t.mkdir(parents=True, exist_ok=True)
            d = t / f"{time.strftime('%y%m%d-%H%M%S')}-{s.name}"
            shutil.move(str(s), str(d))
            ok = d.exists() and not s.exists()
            _log_op("trash", str(s), str(d), f"move:{d}->{s}", ok)
            return _res(ok, output=f"moved {s.name} to FRIDAY's recoverable trash ({d})", error="could not move it to the trash", path=str(d), verified=ok,
                        evidence="the file is no longer at its old place and is in the trash folder")
        return _res(False, error=f"unknown file operation '{op}'")
    except Exception as exc:
        return _res(False, error=f"{type(exc).__name__}: {exc}"[:200], verified=False)


def undo_last_file_op() -> Dict:
    r = C.q("SELECT * FROM fileops7 WHERE ok=1 AND undo<>'' ORDER BY id DESC LIMIT 1")
    if not r:
        return {"ok": False, "error": "nothing to undo"}
    row = r[0]
    kind, _, arg = row["undo"].partition(":")
    try:
        if kind == "move":
            a, _, b = arg.partition("->")
            shutil.move(a, b)
            ok = Path(b).exists() and not Path(a).exists()
        elif kind == "delete":
            p = Path(arg)
            shutil.rmtree(p) if p.is_dir() else p.unlink()
            ok = not p.exists()
        elif kind == "rmdir":
            Path(arg).rmdir()
            ok = not Path(arg).exists()
        else:
            ok = False
        C.x("UPDATE fileops7 SET undo='' WHERE id=?", (row["id"],))
        return {"ok": ok, "text": f"Undid {row['op']} of {Path(row['src']).name}." if ok else "I couldn't undo that."}
    except Exception as exc:
        return {"ok": False, "error": str(exc)[:160]}


# ------------------------------------------------------------------ capture with provenance
def _active_window() -> str:
    try:
        import friday_desktop_agent as D
        return D.active_window() or ""
    except Exception:
        return ""


def _grab():
    try:
        from PIL import ImageGrab
        return ImageGrab.grab(all_screens=False)
    except Exception:
        pass
    try:
        import pyautogui
        return pyautogui.screenshot()
    except Exception:
        return None


def _image_stats(img) -> Tuple[int, int, float]:
    small = img.convert("L").resize((64, 64))
    px = list(small.getdata())
    mean = sum(px) / len(px)
    var = sum((p - mean) ** 2 for p in px) / len(px)
    return img.size[0], img.size[1], var ** 0.5


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def capture_provenance(row_id: int) -> Optional[Dict]:
    r = C.q("SELECT * FROM captures7 WHERE id=?", (row_id,))
    return dict(r[0]) if r else None


def tool_capture_verify(a: Dict) -> Dict:
    kind = str(a.get("kind") or "screen").lower()
    if kind in ("file", "image", "document"):
        p = Path(os.path.expandvars(os.path.expanduser(str(a.get("path") or ""))))
        if not p.is_file():
            return _res(False, error=f"{p} is not a file", verified=False)
        try:
            data = p.open("rb").read(16)
            magic = ("png" if data.startswith(b"\x89PNG") else "jpeg" if data[:3] == b"\xff\xd8\xff" else "pdf" if data.startswith(b"%PDF") else "gif" if data[:3] == b"GIF" else
                     "docx/zip" if data[:2] == b"PK" else "text/other")
            w = h = 0
            try:
                from PIL import Image
                with Image.open(p) as im:
                    w, h = im.size
            except Exception:
                pass
            sha = _sha(p)
            rid = C.x("INSERT INTO captures7(ts,kind,source,window,path,sha256,width,height,verified,note) VALUES(?,?,?,?,?,?,?,?,?,?)", (C.now(), "file", str(p), "", str(p), sha, w, h, 1, magic))
            return _res(True, output=f"File capture #{rid}: {p.name}, type {magic}, {p.stat().st_size} bytes, modified {C.iso(p.stat().st_mtime)}, sha256 {sha[:12]}.", path=str(p), capture_id=rid,
                        verified=True, evidence=f"the file exists and its content is {magic}", sha256=sha, width=w, height=h)
        except Exception as exc:
            return _res(False, error=f"couldn't inspect the file: {exc}", verified=False)
    if kind in ("screen", "screenshot", "window"):
        img = _grab()
        if img is None:
            return _res(False, error="I can't capture the screen here (no screen or no capture library)", verified=False)
        try:
            d = CAPTURE_DIR()
            d.mkdir(parents=True, exist_ok=True)
            win = _active_window()
            p = d / f"screen-{time.strftime('%y%m%d-%H%M%S')}.png"
            img.save(p)
            w, h, spread = _image_stats(img)
            blank = spread < 2.0
            sha = _sha(p)
            rid = C.x("INSERT INTO captures7(ts,kind,source,window,path,sha256,width,height,verified,note) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (C.now(), "screen", "screen", win, str(p), sha, w, h, 0 if blank else 1, "blank or uniform image" if blank else ""))
            if blank:
                return _res(False, error="the capture is blank or one flat colour (a locked screen, a protected window or a display problem)", path=str(p), capture_id=rid, verified=False)
            return _res(True, output=f"Screen capture #{rid} taken {time.strftime('%H:%M:%S')}: {w}x{h}, front window '{win or 'unknown'}', saved to {p}.", path=str(p), capture_id=rid, window=win,
                        verified=True, evidence=f"a {w}x{h} image with real content was saved", sha256=sha, width=w, height=h)
        except Exception as exc:
            return _res(False, error=f"capture failed: {exc}", verified=False)
    if kind == "camera":
        try:
            import cv2  # type: ignore
            cap = cv2.VideoCapture(0)
            ok, frame = cap.read()
            cap.release()
            if not ok:
                return _res(False, error="the camera did not return a picture", verified=False)
            d = CAPTURE_DIR()
            d.mkdir(parents=True, exist_ok=True)
            p = d / f"camera-{time.strftime('%y%m%d-%H%M%S')}.png"
            cv2.imwrite(str(p), frame)
            rid = C.x("INSERT INTO captures7(ts,kind,source,window,path,sha256,width,height,verified,note) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (C.now(), "camera", "camera 0", "", str(p), _sha(p), frame.shape[1], frame.shape[0], 1, ""))
            return _res(True, output=f"Camera capture #{rid} saved to {p}.", path=str(p), capture_id=rid, verified=True, evidence="a camera frame was saved")
        except Exception as exc:
            return _res(False, error=f"camera not available: {exc}", verified=False)
    return _res(False, error=f"unknown capture kind '{kind}'")


# ------------------------------------------------------------------ one-command front door
_RX_WIN = re.compile(r"^(?:please\s+)?(maxim[iz]e|minim[iz]e|restore(?:\s+down)?|focus)\s+(?:the\s+)?(.*)$", re.I)
_RX_OPEN = re.compile(r"^(?:please\s+)?(?:open|launch|start)\s+(?:the\s+|my\s+)?(.+)$", re.I)
_RX_FOLDER = re.compile(r"^(?:please\s+)?(?:create|make)\s+(?:a\s+)?(?:new\s+)?folder\s+(?:called\s+|named\s+)?(.+)$", re.I)
_RX_SHOT = re.compile(r"\b(screenshot|capture (?:the |my )?screen|take a (?:screen ?shot|picture of (?:the |my )?screen))\b", re.I)
_RX_FIND = re.compile(r"^(?:please\s+)?(?:find|search for|locate)\s+(?:the\s+|my\s+)?(?:file\s+|folder\s+)?(.+)$", re.I)


def tool_computer_act(a: Dict) -> Dict:
    cmd = K.strip_wake(str(a.get("command") or a.get("text") or a.get("goal") or "")).strip(" .!?")
    if not cmd:
        return _res(False, error="no command given")
    if _RX_SHOT.search(cmd):
        return tool_capture_verify({"kind": "screen"})
    m = _RX_WIN.match(cmd)
    if m:
        act = re.sub(r"[iz]e$", "ize", m.group(1).lower().split()[0].replace("maximise", "maximize").replace("minimise", "minimize"))
        act = {"maximize": "maximize", "minimize": "minimize", "restore": "restore", "focus": "focus"}.get(act, act)
        return tool_window_control({"action": act, "app": m.group(2)})
    m = _RX_FOLDER.match(cmd)
    if m:
        return tool_file_op({"op": "create_folder", "dst": m.group(1).strip()})
    m = _RX_OPEN.match(cmd)
    if m:
        target = m.group(1).strip()
        try:
            import friday_app_launcher as L
            res = L.resolve(target)
            if getattr(res, "entry", None) is not None and getattr(res, "score", 0) >= getattr(L, "ACCEPT_SCORE", 0.6):
                return tool_open_app({"name": target})
        except Exception:
            pass
        r = tool_open_file({"query": target})
        if r["ok"]:
            return r
        app = tool_open_app({"name": target})
        return app if app["ok"] else r
    m = _RX_FIND.match(cmd)
    if m:
        return tool_find_file({"query": m.group(1)})
    return _res(False, error=f"I don't have a supported, verifiable way to do '{cmd[:60]}' yet")


def install(registry):
    reg = registry.register
    reg("open_app", tool_open_app, risk="routine", desc="open an installed application (verified by its window)", post={"verified": _post_verified}, idempotent=True, timeout=30.0, agent="computer")
    reg("open_file", tool_open_file, risk="routine", desc="find a file by name and open it (never a website)", post={"verified": _post_verified}, idempotent=True, timeout=25.0, agent="computer")
    reg("window_control", tool_window_control, risk="routine", desc="maximise / restore / minimise / focus an app window and read the state back", post={"verified": _post_verified}, timeout=15.0, agent="computer")
    reg("file_op", tool_file_op, risk="sensitive", desc="create folder / copy / move / rename (delete goes to a recoverable trash); checked afterwards", post={"verified": _post_verified}, idempotent=False, timeout=60.0, agent="computer")
    reg("capture_verify", tool_capture_verify, risk="sensitive", desc="capture the screen / a camera frame / a file with provenance and a blank-image check", post={"verified": _post_verified}, timeout=20.0, agent="computer")
    reg("find_file", tool_find_file, risk="safe", desc="fast indexed file and folder search", post={"nonempty": True}, timeout=10.0, agent="computer")
    reg("computer_act", tool_computer_act, risk="routine", desc="one natural-language computer command routed to the verified tools above", timeout=60.0, agent="computer")


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if re.match(r"^(?:undo|reverse) (?:the )?last file (?:operation|change|move)$", t):
        r = undo_last_file_op()
        return r.get("text") or ("I couldn't undo that: " + r.get("error", "") if r.get("error") else "")
    return None
