"""FRIDAY 7.0 Adaptive Multi-Model Intelligence  (roadmap #4).

            request --> small always-loaded classifier --> route --> best AVAILABLE model, scored on capability, reliability, latency and cost

Routes (see the routing-architecture diagram in the roadmap):
  instant    an exact local answer exists (maths, units, time) - no model at all
  general    everyday tasks, quick answers, low resources            -> small local model or fast cloud model
  code       programming, scripting, debugging                       -> coder specialist
  reasoning  complex logic, analysis, step by step                   -> large reasoning model
  sensitive  confidential / private data                             -> LOCAL ONLY, never the cloud
  research   needs current information                               -> fast cloud model + search tools
  frontier   top-tier performance / huge context, only when needed   -> deepest cloud model

The classifier is a few hundred bytes of weights kept in memory (no model load, microseconds) and learns from feedback.
Candidate models are scored with MEASURED latency and reliability (from the 6.0 router's call log) and with hardware limits:
a 32B local model is never offered on an 8 GB laptop.
"""
from __future__ import annotations

import json
import re
import threading
import time
import urllib.request
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS route_log7(id INTEGER PRIMARY KEY, ts REAL, fp TEXT, route TEXT, choice TEXT, ms INTEGER, ok INTEGER, private INTEGER DEFAULT 0, note TEXT);
""")

ROUTES = ("instant", "general", "code", "reasoning", "sensitive", "research", "frontier")

_LEX: Dict[str, List[tuple]] = {
    "code": [(r"\b(code|coding|function|class|method|variable|bug|debug|compile|compiler|script|python|javascript|typescript|java|c\+\+|rust|golang|sql|regex|api|json|html|css|git|github|stack ?trace|exception|traceback|refactor|unit test|pytest|npm|pip|library|framework|algorithm|syntax|runtime error)\b", 2.0),
             (r"```|\bdef \w+\(|\bimport \w+|=>|\bfunction\s*\(", 3.0)],
    "reasoning": [(r"\b(prove|proof|derive|step by step|explain why|why does|why is|analy[sz]e|evaluate|critique|trade-?offs?|pros and cons|optimi[sz]e|strategy|logic|puzzle|deduce|infer|implications?|what would happen if|compare and contrast|decide between|weigh)\b", 2.0),
                  (r"\b(integral|derivative|equation|probability|theorem|matrix|differential|calculus|statistics)\b", 1.5)],
    "research": [(r"\b(latest|news|today'?s|current(?:ly)?|right now|this week|this year|research|look up|search for|find out|sources?|cross[- ]check|cite|citation|release date|price of|prices|trending|reviews?)\b", 2.0)],
    "sensitive": [(r"\b(password|passcode|confidential|private|secret|medical|diagnosis|prescription|diary|journal|salary|payslip|bank (?:account|statement)|credit card|ssn|social security|passport|legal case|lawsuit|therapy|keep (?:this )?local|don'?t send|do not send|offline only|never upload|personal data|health record)\b", 5.0)],
    "frontier": [(r"\b(most powerful|best model|frontier|state of the art|maximum quality|highest quality|very long document|entire (?:book|codebase|repository)|hundreds of pages)\b", 4.0)],
    "general": [(r"\b(hi|hello|hey|thanks|thank you|how are you|tell me a joke|what do you think|recommend|suggest|ideas?|summari[sz]e|rewrite|translate|define|meaning of)\b", 1.0)],
}
_LEX_RX = {r: [(re.compile(p, re.I), w) for p, w in items] for r, items in _LEX.items()}

# learned adjustments (kept small and capped): route bias and per-token weights
_bias: Dict[str, float] = {}
_tok_w: Dict[str, Dict[str, float]] = {}
_loaded = {"done": False}
_lock = threading.Lock()


def _load():
    if _loaded["done"]:
        return
    with _lock:
        if _loaded["done"]:
            return
        try:
            d = K.jl(K.cfg_get("router_learned", "{}"), {}) or {}
            _bias.update(d.get("bias", {}))
            _tok_w.update(d.get("tok", {}))
        except Exception:
            pass
        _loaded["done"] = True


def _persist():
    # keep it tiny: top 1500 token weights
    flat = sorted(((abs(w), t, r, w) for t, rr in _tok_w.items() for r, w in rr.items()), reverse=True)[:1500]
    tok: Dict[str, Dict[str, float]] = {}
    for _, t, r, w in flat:
        tok.setdefault(t, {})[r] = round(w, 3)
    try:
        K.cfg_set("router_learned", K.jd({"bias": {k: round(v, 3) for k, v in _bias.items()}, "tok": tok}))
    except Exception:
        pass


def get_bias(route: str) -> float:
    _load()
    return float(_bias.get(route, 0.0))


def set_bias(route: str, value: float):
    _load()
    if route in ROUTES:
        _bias[route] = max(-2.0, min(2.0, float(value)))
        _persist()


def feedback(text: str, correct_route: str, strength: float = 0.5):
    """Teach the classifier: this kind of request belongs to `correct_route`."""
    _load()
    if correct_route not in ROUTES:
        return
    for tkn in list(set(C.tokens(text)))[:40]:
        w = _tok_w.setdefault(tkn, {})
        w[correct_route] = min(3.0, w.get(correct_route, 0.0) + strength)
    _persist()


def classify(text: str, has_attachments: bool = False) -> Dict:
    """Pure local, microseconds. Returns the winning route with per-route scores and a confidence in [0, 1]."""
    _load()
    t = (text or "").strip()
    words = len(t.split())
    scores = {r: 0.0 for r in ROUTES}
    hits: Dict[str, List[str]] = {r: [] for r in ROUTES}
    try:
        import friday_router5 as R5
        if R5.instant_answer(t) is not None:
            return {"route": "instant", "confidence": 1.0, "scores": {**scores, "instant": 10.0}, "signals": {"instant": ["exact local answer"]}, "words": words}
    except Exception:
        pass
    for r, items in _LEX_RX.items():
        for rx, w in items:
            n = len(rx.findall(t))
            if n:
                scores[r] += w * min(n, 3)
                hits[r].append(rx.pattern[:30])
    for tkn in set(C.tokens(t)):
        for r, w in _tok_w.get(tkn, {}).items():
            scores[r] = scores.get(r, 0.0) + w
    if words >= 60:
        scores["reasoning"] += 1.5
    if len(t) > 3500:
        scores["frontier"] += 3.0
        hits["frontier"].append("very long input")
    if has_attachments:
        scores["reasoning"] += 0.5
    scores["general"] += 1.0 + (0.5 if words < 12 else 0)
    for r, b in _bias.items():
        scores[r] += b
    if scores["sensitive"] >= 5.0:
        route = "sensitive"
    else:
        route = max((r for r in ROUTES if r not in ("instant", "sensitive")), key=lambda r: scores[r])
    ordered = sorted(scores.values(), reverse=True)
    top, second = ordered[0], ordered[1] if len(ordered) > 1 else 0.0
    conf = round(min(1.0, 0.35 + (top - second) / max(1.0, top) * 0.65), 2) if top > 0 else 0.3
    return {"route": route, "confidence": conf, "scores": {k: round(v, 2) for k, v in scores.items()}, "signals": {k: v for k, v in hits.items() if v}, "words": words}


# ------------------------------------------------------------------ model catalogue
def _perf():
    import friday_perf6 as P
    return P


def _installed_ollama_models() -> List[str]:
    try:
        P = _perf()
        with urllib.request.urlopen(P.cfg("ollama_url", "http://127.0.0.1:11434") + "/api/tags", timeout=0.8) as r:
            return [m.get("name", "") for m in json.loads(r.read().decode()).get("models", [])]
    except Exception:
        return []


_MODELS = [
    {"id": "gemini-fast", "provider": "gemini", "tier": "fast", "kind": "cloud", "cap": {"general": .85, "code": .70, "reasoning": .55, "research": .72, "frontier": .45, "instant": .9}, "lat": 1500, "cost": 1.0, "ram": 0},
    {"id": "gemini-deep", "provider": "gemini", "tier": "deep", "kind": "cloud", "cap": {"general": .90, "code": .92, "reasoning": .96, "research": .90, "frontier": .95}, "lat": 7000, "cost": 4.0, "ram": 0},
    {"id": "local-general", "provider": "local", "tier": "fast", "kind": "local", "cap": {"general": .60, "code": .40, "reasoning": .35, "sensitive": .60, "research": .20}, "lat": 3500, "cost": 0.0, "ram": 4},
    {"id": "local-code", "provider": "local-code", "tier": "fast", "kind": "local", "cap": {"code": .85, "general": .50, "reasoning": .45, "sensitive": .55}, "lat": 5000, "cost": 0.0, "ram": 6, "cfg": "ollama_model_code"},
    {"id": "local-reasoning", "provider": "local-reasoning", "tier": "deep", "kind": "local", "cap": {"reasoning": .85, "code": .70, "general": .70, "sensitive": .80}, "lat": 20000, "cost": 0.0, "ram": 24, "cfg": "ollama_model_reasoning"},
    {"id": "local-sensitive", "provider": "local-sensitive", "tier": "fast", "kind": "local", "cap": {"sensitive": .85, "general": .55}, "lat": 5000, "cost": 0.0, "ram": 6, "cfg": "ollama_model_sensitive"},
]


def _ollama_fn(model: str):
    def call(prompt: str, tier: str) -> str:
        P = _perf()
        url = P.cfg("ollama_url", "http://127.0.0.1:11434") + "/api/generate"
        req = urllib.request.Request(url, data=json.dumps({"model": model, "prompt": prompt, "stream": False}).encode(), headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=90) as r:
            return str(json.loads(r.read().decode()).get("response", ""))
    return call


def sync_providers():
    """Register the optional specialist local models (only the ones the user configured) with the 6.0 router, so its circuit breaker and metrics apply."""
    P = _perf()
    for m in _MODELS:
        if m.get("cfg"):
            name = K.cfg_get(m["cfg"], "").strip()
            if name:
                P.register_provider(m["provider"], _ollama_fn(name), "local")
            elif m["provider"] in P._providers:
                P._providers.pop(m["provider"], None)


def _ram_total_gb() -> float:
    try:
        return float(_perf().resources().get("ram_total_gb") or 8)
    except Exception:
        return 8.0


def _measured(provider: str, tier: str) -> Dict:
    try:
        r = C.q("SELECT COUNT(*) n, AVG(ms) ms, AVG(ok) rel FROM model_calls6 WHERE provider=? AND tier=? AND cached=0 AND ts>?", (provider, tier, time.time() - 7 * 86400))
        if r and r[0]["n"] and r[0]["n"] >= 3:
            return {"n": r[0]["n"], "ms": float(r[0]["ms"] or 0), "rel": float(r[0]["rel"] or 0)}
    except Exception:
        pass
    return {"n": 0}


def candidates(route: str, *, mode: Optional[str] = None, check_local: bool = True) -> List[Dict]:
    """Every model with its availability and score for this route. Higher score = better. Sensitive requests only see local models."""
    P = _perf()
    mode = mode or P.cfg("routing", "auto")
    sync_providers()
    ram = _ram_total_gb()
    local_up = P.ollama_available() if check_local and any(m["kind"] == "local" for m in _MODELS) else False
    try:
        import friday_health7 as H
        light = H.light_mode()
    except Exception:
        light = False
    out = []
    for m in _MODELS:
        prov = P._providers.get(m["provider"])
        row = {"id": m["id"], "provider": m["provider"], "tier": m["tier"], "kind": m["kind"], "available": True, "why_not": "", "score": 0.0}
        if m["id"] == "local-general":
            if "local" not in P._providers and local_up:
                P.enable_local()
                prov = P._providers.get("local")
        if prov is None:
            row.update(available=False, why_not="not configured" if m["kind"] == "local" else "not connected")
        elif time.time() < prov["open_until"]:
            row.update(available=False, why_not="cooling down after failures")
        elif m["kind"] == "local" and not local_up:
            row.update(available=False, why_not="Ollama is not running")
        elif m["ram"] and ram < m["ram"] * 1.1:
            row.update(available=False, why_not=f"needs about {m['ram']} GB RAM, this machine has {ram:g}")
        elif m["kind"] == "cloud" and (mode == "local" or route == "sensitive"):
            row.update(available=False, why_not="cloud models are not allowed for this request" if route == "sensitive" else "routing is set to local only")
        elif m["kind"] == "local" and mode == "cloud" and route != "sensitive":
            row.update(available=False, why_not="routing is set to cloud only")
        elif light and m["ram"] >= 12:
            row.update(available=False, why_not="light mode: not loading a large local model")
        cap = m["cap"].get(route, 0.0)
        meas = _measured(m["provider"], m["tier"])
        lat = meas.get("ms") or m["lat"]
        rel = meas.get("rel") if meas.get("n") else 0.9
        w = {"cap": 0.50, "rel": 0.20, "lat": 0.20, "cost": 0.10}
        if route in ("reasoning", "frontier"):
            w = {"cap": 0.62, "rel": 0.18, "lat": 0.12, "cost": 0.08}
        elif route in ("general", "research"):
            w = {"cap": 0.40, "rel": 0.20, "lat": 0.28, "cost": 0.12}
        elif route == "sensitive":
            w = {"cap": 0.60, "rel": 0.20, "lat": 0.15, "cost": 0.05}
        score = w["cap"] * cap + w["rel"] * rel - w["lat"] * min(1.0, lat / 12000.0) - w["cost"] * min(1.0, m["cost"] / 4.0)
        if cap <= 0:
            row.update(available=False, why_not=row["why_not"] or f"not suited to {route} requests")
        row.update(score=round(score, 4), capability=cap, reliability=round(rel, 3), latency_ms=int(lat), cost=m["cost"], measured_calls=meas.get("n", 0))
        out.append(row)
    out.sort(key=lambda r: (not r["available"], -r["score"]))
    return out


def decide(text: str, tier_hint: Optional[str] = None, has_attachments: bool = False) -> Dict:
    """The routing decision with the evidence behind it."""
    cl = classify(text, has_attachments)
    route = cl["route"]
    if tier_hint == "deep" and route in ("general", "research"):
        route = "reasoning"
    if route == "instant":
        return {"route": "instant", "classifier": cl, "choice": None, "order": [], "private": False, "blocked": False, "reason": "An exact local calculation answers this without any model."}
    cands = candidates(route)
    usable = [c for c in cands if c["available"]]
    private = route == "sensitive"
    blocked = private and not usable
    choice = usable[0] if usable else None
    if choice is None and not private:
        # nothing scored (e.g. nothing registered yet): let the 6.0 router do its own thing
        reason = "No specialist model is connected; the standard router will handle it."
    elif blocked:
        reason = "This looks private, and no local model is available, so I will not send it to the cloud."
    else:
        why = ", ".join(sorted(set(cl["signals"].get(route, [])[:1] + [f"{cl['confidence']:.0%} confident"]))) if route in cl["signals"] else f"{cl['confidence']:.0%} confident"
        reason = f"{route} request ({why}); best available is {choice['id']} (score {choice['score']:.2f}: capability {choice['capability']:.2f}, reliability {choice['reliability']:.2f}, about {choice['latency_ms']} ms, relative cost {choice['cost']:g})."
    return {"route": route, "classifier": cl, "choice": choice["id"] if choice else None, "order": [(c["provider"], c["tier"]) for c in usable], "candidates": cands,
            "private": private, "blocked": blocked, "reason": reason}


def _log(fp: str, route: str, choice: str, ms: int, ok: bool, private: bool, note: str = ""):
    try:
        C.x("INSERT INTO route_log7(ts,fp,route,choice,ms,ok,private,note) VALUES(?,?,?,?,?,?,?,?)", (time.time(), fp, route, choice or "", ms, int(ok), int(private), note[:120]))
    except Exception:
        pass
    K.emit("route_used", {"route": route, "choice": choice, "ms": ms, "ok": ok})


def llm(prompt: str, model: Optional[str] = None, **kw) -> str:
    """Drop-in replacement for the model call used by agents, tasks, research and the orchestrator. Never raises."""
    P = _perf()
    t0 = time.time()
    try:
        d = decide(prompt, tier_hint=model if model in ("fast", "deep") else None)
    except Exception as exc:
        C.log(f"router7 decide failed, using the standard router: {exc}", "recovery")
        return P.call(prompt, tier=(model if model in ("fast", "deep") else None))
    fp = C.fingerprint(prompt)
    if d["blocked"]:
        _log(fp, d["route"], None, 0, False, True, "blocked: no local model")
        return ""
    order = d["order"]
    if not order:
        out = P.call(prompt, tier=(model if model in ("fast", "deep") else None)) if not d["private"] else ""
        _log(fp, d["route"], "gemini", int((time.time() - t0) * 1000), bool(out), d["private"], "standard router")
        return out
    for prov, tier in order[:3]:
        if prov == "gemini":
            out = P.call(prompt, tier=tier)
        else:
            out = _call_provider(prov, prompt, tier)
        if out and out.strip():
            _log(fp, d["route"], f"{prov}:{tier}", int((time.time() - t0) * 1000), True, d["private"])
            try:
                import friday_health7 as H
                H.record("model_ms", (time.time() - t0) * 1000, route=d["route"], provider=prov)
            except Exception:
                pass
            return out
    _log(fp, d["route"], None, int((time.time() - t0) * 1000), False, d["private"], "all candidates failed")
    return ""


def _call_provider(name: str, prompt: str, tier: str, timeout: float = 90.0) -> str:
    P = _perf()
    p = P._providers.get(name)
    if not p or time.time() < p["open_until"]:
        return ""
    box: Dict = {}

    def run():
        try:
            box["r"] = p["fn"](prompt, tier)
        except Exception as exc:
            box["e"] = exc

    t0 = time.time()
    th = threading.Thread(target=run, daemon=True)
    th.start()
    th.join(timeout)
    out = str(box.get("r") or "")
    ok = bool(out.strip()) and "e" not in box
    try:
        C.x("INSERT INTO model_calls6(ts,provider,tier,task,ms,ok,chars) VALUES(?,?,?,?,?,?,?)", (time.time(), name, tier, "routed", int((time.time() - t0) * 1000), int(ok), len(out)))
    except Exception:
        pass
    if ok:
        p["fails"] = 0
        return out
    p["fails"] += 1
    if p["fails"] >= 3:
        p["open_until"] = time.time() + 30.0
    return ""


def table(route: str = "general") -> List[Dict]:
    """For the UI and 'routing table': every model scored for a route."""
    return candidates(route)


def stats() -> Dict:
    rows = C.q("SELECT route, choice, COUNT(*) n, AVG(ms) ms, AVG(ok) ok FROM route_log7 GROUP BY route, choice ORDER BY n DESC LIMIT 20")
    return {"routes": [{"route": r["route"], "choice": r["choice"] or "-", "calls": r["n"], "avg_ms": int(r["ms"] or 0), "success": round(r["ok"] or 0, 2)} for r in rows],
            "learned": {"bias": dict(_bias), "tokens": sum(len(v) for v in _tok_w.values())}}


def handle(command: str) -> Optional[str]:
    low = K.norm_cmd(command)
    m = re.match(r"^(?:which|what) model (?:would|will|do) you (?:use|pick|choose) (?:for|to answer|on) (.+)$|^explain (?:the )?routing (?:for|of) (.+)$", low)
    if m:
        d = decide(m.group(1) or m.group(2))
        return d["reason"]
    if re.match(r"^(?:show |explain )?(?:the )?(?:model )?routing table$|^how do you (?:route|choose) models$", low):
        c = [x for x in candidates("general") if x["available"]]
        if not c:
            return "No model is connected yet. Once Gemini or a local Ollama model is available I score them on capability, reliability, speed and cost."
        return "I route each request to the best available model: " + "; ".join(f"{x['id']} ({x['kind']}, about {x['latency_ms']} ms)" for x in c[:4]) + ". Private requests only ever use local models."
    return None
