# FRIDAY fast boot launcher for the unified FRIDAY-native backend.
import os, runpy, sys
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True, write_through=True)
except Exception:
    pass
print("FRIDAY_BOOT::PROCESS_CONNECTED", flush=True)
runpy.run_path(os.path.join(os.path.dirname(os.path.abspath(__file__)), "friday_backend.py"), run_name="__main__")
