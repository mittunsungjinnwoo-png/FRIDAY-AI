"""V2036 regression tests: complete offline notes + real diagrams + cinematic screen replies.
Run:  python TEST_V2036_NOTES_AND_SCREEN.py     (needs only reportlab; no mic, key or network)"""
import ast, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import friday_notes_diagrams as D
import friday_notes_knowledge as K
import friday_notes_engine as E
import friday_screen_intelligence as S


def test_knowledge_lookup():
    for topic, title in (("how sp3 orbitals are formed", "sp3"), ("SP2 hybridisation", "sp2"),
                         ("sp hybrid orbitals", "sp"), ("hybridisation", "Hybridisation")):
        s = K.lookup(topic, "Cambridge A Level Chemistry 9701", "2025-2027")
        assert s and title in s["chapter_title"], (topic, s and s["chapter_title"])
        for key in ("what_is", "key_points", "process_items", "key_ideas", "diagrams", "worked_examples",
                    "common_mistakes", "exam_tips", "vocabulary", "comparison_tables", "reference_outline"):
            assert s.get(key), (topic, key)
        assert len(s["diagrams"]) >= 4
    assert K.lookup("the krebs cycle") is None      # unknown topics are NOT faked


def test_diagrams_draw():
    s = K.lookup("sp3", "x", "y")
    for spec in s["diagrams"]:
        assert D.build_diagram_drawing(spec, 470) is not None, spec.get("kind")
    for kind in ("cycle", "hub", "flow"):
        nodes = [{"label": f"n{i}", "detail": "detail text"} for i in range(5)]
        assert D.build_diagram_drawing({"kind": kind, "center": "Topic", "nodes": nodes}, 470) is not None
    assert D.build_diagram_drawing({"kind": "energy"}, 470) is None   # malformed -> None, never raises


def test_pdf_builds_multi_page():
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "sp3.pdf"
        E.build_gorgeous_notes("how sp3 orbitals are formed", "9701", K.lookup("sp3", "Chem", "2027"), out)
        data = out.read_bytes()
        assert data.startswith(b"%PDF") and len(data) > 20000
        assert data.count(b"/Type /Page\n") + data.count(b"/Type /Page ") >= 4


def test_screen_reply_is_cinematic():
    ocr = "ChatGPT New chat - Claude Import memory Ask Gemini Free plan Upgrade Hello"
    said = S._local_summary("FRIDAY - Widget", ocr)
    assert "Active window:" not in said and "sir" in said.lower()
    assert "ChatGPT" in said and "Claude" in said
    rep = S.spoken_screen_report({"ok": True, "active_window": "Notepad", "ocr": ocr, "summary": ""})
    assert rep.startswith("Notepad") and "sir" in rep.lower()
    assert "sir" in S.spoken_screen_report({"ok": False}).lower()


def test_backend_wiring_static():
    src = (ROOT / "friday_backend.py").read_text(encoding="utf-8")
    ast.parse(src)
    for needle in ("def _salvage_truncated_json", "def _notes_fallback_sections", "friday_notes_knowledge",
                   "notes_mode", "files_required=True"):
        assert needle in src, needle
    assert "My live research or AI structuring step was unavailable" not in src
    v96 = (ROOT / "friday_v96_runtime.py").read_text(encoding="utf-8")
    assert '"Active window: "+str(r.get("active_window")' not in v96


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print(f"  {name}: PASS")
    print("V2036 notes + screen tests: PASS")
