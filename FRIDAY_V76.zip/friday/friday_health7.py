"""FRIDAY 7.0 Performance and Health Monitor  (roadmap #3).

Measures what actually happens - response latency, voice latency, RAM, CPU, API failures, tool success rates - keeps structured logs,
runs component health checks, detects degraded parts and switches to SAFE FALLBACK PATHS (light mode), and produces diagnostic reports
and regression benchmarks.

Read-only with respect to listening / recognition / speaking: it only *reads* their health() numbers.
"""
from __future__ import annotations

import json
import os
import threading
import time
from collections import deque
from pathlib import Path
from typing import Callable, Deque, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS metrics7(id INTEGER PRIMARY KEY, ts REAL, name TEXT, value REAL, tags TEXT);
CREATE INDEX IF NOT EXISTS ix_metrics7_name ON metrics7(name, ts);
CREATE TABLE IF NOT EXISTS incidents7(id INTEGER PRIMARY KEY, ts REAL, component TEXT, level TEXT, text TEXT, resolved INTEGER DEFAULT 0, resolved_ts REAL);
""")

_ring: Dict[str, Deque[Tuple[float, float]]] = {}
_lock = threading.RLock()
_components: Dict[str, Dict] = {}
_state = {"light": False, "hot": 0, "cool": 0, "since": 0.0, "last_eval": 0.0, "reason": ""}
_light_hooks: List[Callable[[bool, str], None]] = []
_last_seen: Dict[str, object] = {}
SEV = {"ok": 0, "idle": 0, "off": 0, "unknown": 1, "degraded": 2, "down": 3}
LOG_DIR_NAME = "logs7"


# ------------------------------------------------------------------ metrics
def record(name: str, value: float, **tags):
    try:
        v = float(value)
    except Exception:
        return
    with _lock:
        _ring.setdefault(name, deque(maxlen=300)).append((time.time(), v))
    try:
        C.x("INSERT INTO metrics7(ts,name,value,tags) VALUES(?,?,?,?)", (time.time(), name, v, K.jd(tags) if tags else ""))
    except Exception:
        pass


class timer:
    """with H.timer('planner_ms'): ...  records the elapsed milliseconds."""

    def __init__(self, name: str, **tags):
        self.name, self.tags, self.ms = name, tags, 0.0

    def __enter__(self):
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *a):
        self.ms = (time.perf_counter() - self.t0) * 1000
        record(self.name, self.ms, **self.tags)
        return False


def series(name: str, since_s: float = 3600.0) -> List[Tuple[float, float]]:
    cut = time.time() - since_s
    with _lock:
        mem = [x for x in _ring.get(name, []) if x[0] >= cut]
    if mem:
        return mem
    try:
        return [(r["ts"], r["value"]) for r in C.q("SELECT ts,value FROM metrics7 WHERE name=? AND ts>=? ORDER BY ts", (name, cut))]
    except Exception:
        return []


def summary(name: str, since_s: float = 3600.0) -> Dict:
    vals = sorted(v for _, v in series(name, since_s))
    if not vals:
        return {"n": 0, "avg": None, "p50": None, "p95": None, "max": None, "last": None}
    n = len(vals)
    last = series(name, since_s)[-1][1]
    return {"n": n, "avg": round(sum(vals) / n, 2), "p50": round(vals[n // 2], 2), "p95": round(vals[min(n - 1, int(n * 0.95))], 2), "max": round(vals[-1], 2), "last": round(last, 2)}


def prune(days: int = 14) -> int:
    cut = time.time() - days * 86400
    n = len(C.q("SELECT id FROM metrics7 WHERE ts<?", (cut,)))
    C.x("DELETE FROM metrics7 WHERE ts<?", (cut,))
    return n


# ------------------------------------------------------------------ structured logs (JSON lines, rotated)
def _log_dir() -> Path:
    d = C.DATA_DIR / LOG_DIR_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def log_event(kind: str, **fields):
    """One JSON object per line: easy to grep, easy to load. Secrets are redacted; files rotate at 2 MB (3 kept)."""
    try:
        rec = {"ts": round(time.time(), 3), "t": time.strftime("%Y-%m-%d %H:%M:%S"), "session": K.SESSION_ID, "kind": kind}
        rec.update({k: (C.redact(v) if isinstance(v, str) else v) for k, v in fields.items()})
        p = _log_dir() / "events.jsonl"
        if p.exists() and p.stat().st_size > 2_000_000:
            for i in (2, 1):
                a, b = p.with_name(f"events.{i}.jsonl"), p.with_name(f"events.{i + 1}.jsonl")
                if a.exists():
                    a.replace(b)
            p.replace(p.with_name("events.1.jsonl"))
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
    except Exception:
        pass


def recent_log(n: int = 30) -> List[Dict]:
    try:
        p = _log_dir() / "events.jsonl"
        if not p.exists():
            return []
        lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()[-n:]
        return [json.loads(x) for x in lines if x.strip()]
    except Exception:
        return []


# ------------------------------------------------------------------ incidents
def incident(component: str, text: str, level: str = "warn"):
    if C.q("SELECT id FROM incidents7 WHERE component=? AND text=? AND resolved=0", (component, text)):
        return
    C.x("INSERT INTO incidents7(ts,component,level,text) VALUES(?,?,?,?)", (time.time(), component, level, K.clip(text, 240)))
    log_event("incident", component=component, level=level, text=text)
    K.emit("incident", {"component": component, "level": level, "text": text})


def resolve(component: str, text_like: str = ""):
    rows = C.q("SELECT id FROM incidents7 WHERE component=? AND resolved=0" + (" AND text LIKE ?" if text_like else ""), (component, f"%{text_like}%") if text_like else (component,))
    for r in rows:
        C.x("UPDATE incidents7 SET resolved=1, resolved_ts=? WHERE id=?", (time.time(), r["id"]))


def incidents(open_only: bool = False, n: int = 15) -> List[Dict]:
    rows = C.q("SELECT * FROM incidents7" + (" WHERE resolved=0" if open_only else "") + " ORDER BY id DESC LIMIT ?", (n,))
    return [{"when": C.iso(r["ts"]), "component": r["component"], "level": r["level"], "text": r["text"], "resolved": bool(r["resolved"])} for r in rows]


# ------------------------------------------------------------------ component health
def register_component(name: str, check: Callable[[], Tuple[str, str]], critical: bool = False, fallback: str = ""):
    """check() -> (status, detail) with status ok|idle|off|degraded|down|unknown."""
    _components[name] = {"check": check, "critical": critical, "fallback": fallback}


def _resources() -> Dict:
    try:
        import friday_perf6 as P
        return P.resources()
    except Exception:
        return {}


def check_all() -> Dict[str, Dict]:
    out: Dict[str, Dict] = {}
    for name, c in list(_components.items()):
        t0 = time.perf_counter()
        try:
            st, detail = c["check"]()
        except Exception as exc:
            st, detail = "down", f"check crashed: {type(exc).__name__}: {exc}"
        ms = round((time.perf_counter() - t0) * 1000, 1)
        out[name] = {"status": st if st in SEV else "unknown", "detail": K.clip(detail, 200), "ms": ms, "critical": c["critical"], "fallback": c["fallback"]}
        key = "comp:" + name
        if _last_seen.get(key) != out[name]["status"]:
            if _last_seen.get(key) is not None or out[name]["status"] in ("degraded", "down"):
                log_event("component", name=name, status=out[name]["status"], detail=out[name]["detail"])
            if out[name]["status"] in ("degraded", "down"):
                incident(name, f"{out[name]['status']}: {out[name]['detail']}", "error" if out[name]["status"] == "down" else "warn")
            elif _last_seen.get(key) in ("degraded", "down"):
                resolve(name)
            _last_seen[key] = out[name]["status"]
    return out


def overall(comps: Optional[Dict[str, Dict]] = None) -> str:
    comps = comps if comps is not None else check_all()
    worst = max((SEV.get(c["status"], 1) for c in comps.values()), default=0)
    return {0: "ok", 1: "ok", 2: "degraded", 3: "down"}[worst]


def install_default_checks():
    """Built-in checks. Each one only reads state."""
    def db():
        t = time.perf_counter()
        C.q("SELECT 1")
        ms = (time.perf_counter() - t) * 1000
        return ("ok" if ms < 250 else "degraded"), f"query {ms:.1f} ms"

    def system():
        r = _resources()
        if not r or r.get("ram") is None:
            return "unknown", "resource readings unavailable"
        bad = []
        if (r.get("ram") or 0) > float(K.cfg_get("light_ram_pct")):
            bad.append(f"memory {r['ram']}%")
        if (r.get("cpu") or 0) > float(K.cfg_get("light_cpu_pct")):
            bad.append(f"CPU {r['cpu']}%")
        if (r.get("disk") or 0) > 95:
            bad.append(f"disk {r['disk']}%")
        return ("degraded" if bad else "ok"), ("high " + ", ".join(bad)) if bad else f"CPU {r.get('cpu')}% memory {r.get('ram')}% disk {r.get('disk')}%"

    def models():
        try:
            import friday_perf6 as P
            provs = P.providers()
        except Exception:
            return "unknown", "router unavailable"
        if not provs:
            return "idle", "no model provider registered yet"
        healthy = [p for p in provs if p["healthy"]]
        rows = C.q("SELECT AVG(ok) a, COUNT(*) n FROM model_calls6 WHERE ts>? AND cached=0", (time.time() - 600,))
        rate, n = (rows[0]["a"], rows[0]["n"]) if rows else (None, 0)
        if not healthy:
            return "down", "every model provider is cooling down after repeated failures"
        if n >= 4 and rate is not None and rate < 0.6:
            return "degraded", f"{int((1 - rate) * 100)}% of model calls failed in the last 10 minutes"
        if len(healthy) < len(provs):
            return "degraded", "a provider is cooling down; using the others"
        return "ok", f"{len(healthy)} provider(s) healthy" + (f", {int(rate * 100)}% success" if rate is not None and n else "")

    def tools():
        try:
            import friday_verify7 as V
            s = V.stats(1800)
        except Exception:
            return "unknown", "no receipts"
        if s["total"] < 5:
            return "idle", f"{s['total']} tool run(s) recently"
        if s["success_rate"] < 0.3:
            return "down", f"tools succeed only {int(s['success_rate'] * 100)}% of the time"
        if s["success_rate"] < 0.6:
            return "degraded", f"tools succeed {int(s['success_rate'] * 100)}% of the time"
        return "ok", f"{int(s['success_rate'] * 100)}% success over {s['total']} runs"

    def listening():
        try:
            import friday_voice5 as V5
            h = V5.health()
        except Exception:
            return "unknown", "listening engine not loaded"
        if h.get("disabled_reason"):
            return "down", str(h["disabled_reason"])[:120]
        if not h.get("running"):
            return "idle", "listening engine not started yet"
        return "ok", f"running; noise floor {h.get('noise_floor')}"

    def speaking():
        try:
            import friday_speech5 as S5
            h = S5.health()
        except Exception:
            return "unknown", "speech engine not loaded"
        if not h.get("enabled"):
            return "off", "fast speech engine disabled"
        if not h.get("usable"):
            return "degraded", f"fast speech paused after {h.get('failures')} failure(s); falling back to the normal voice path"
        return "ok", f"ready; last first-audio {h.get('last', {}).get('first_audio_ms', '-')} ms"

    def memory():
        try:
            import friday_memory6 as M
            n = C.q("SELECT COUNT(*) n FROM mem6")[0]["n"]
            return "ok", f"{n} memories"
        except Exception as exc:
            return "degraded", f"memory store: {exc}"

    def jobs():
        try:
            stuck = C.q("SELECT COUNT(*) n FROM jobs7 WHERE state IN ('running','verifying') AND started<?", (time.time() - 1800,))[0]["n"]
        except Exception:
            return "idle", "no jobs table yet"
        return ("degraded", f"{stuck} job(s) running for over 30 minutes") if stuck else ("ok", "no stuck jobs")

    register_component("database", db, critical=True, fallback="in-memory working state")
    register_component("system", system, fallback="light mode (less parallel work, no speculation)")
    register_component("models", models, fallback="local model if present, then cached and deterministic answers")
    register_component("tools", tools, fallback="alternative tools / strategies from the planner")
    register_component("listening", listening)
    register_component("speaking", speaking, fallback="normal voice path")
    register_component("memory", memory)
    register_component("orchestrator", jobs)


# ------------------------------------------------------------------ light mode (the safe fallback path)
def light_mode() -> bool:
    return bool(_state["light"])


def on_light_change(fn: Callable[[bool, str], None]):
    _light_hooks.append(fn)


def set_light(on: bool, reason: str = ""):
    if on == _state["light"]:
        return
    _state.update(light=on, since=time.time(), reason=reason if on else "")
    log_event("light_mode", on=on, reason=reason)
    if on:
        incident("system", f"light mode on: {reason}")
    else:
        resolve("system", "light mode")
    for fn in list(_light_hooks):
        try:
            fn(on, reason)
        except Exception:
            pass
    K.emit("light_mode", {"on": on, "reason": reason})


def evaluate(r: Optional[Dict] = None) -> Dict:
    """One health sample: record CPU/RAM, decide on light mode with hysteresis (3 hot samples in, 4 cool samples out)."""
    r = r if r is not None else _resources()
    if r:
        if r.get("cpu") is not None:
            record("cpu_pct", r["cpu"])
        if r.get("ram") is not None:
            record("ram_pct", r["ram"])
        if r.get("process_mb") is not None:
            record("process_mb", r["process_mb"])
    ram_lim, cpu_lim = float(K.cfg_get("light_ram_pct")), float(K.cfg_get("light_cpu_pct"))
    hot = (r.get("ram") or 0) > ram_lim or (r.get("cpu") or 0) > cpu_lim
    if hot:
        _state["hot"] += 1
        _state["cool"] = 0
    else:
        _state["cool"] += 1
        _state["hot"] = 0
    _state["last_eval"] = time.time()
    if not _state["light"] and _state["hot"] >= 3:
        why = f"memory {r.get('ram')}%" if (r.get("ram") or 0) > ram_lim else f"CPU {r.get('cpu')}%"
        set_light(True, why + " is high")
    elif _state["light"] and _state["cool"] >= 4:
        set_light(False)
    return {"light": _state["light"], "hot": _state["hot"], "cool": _state["cool"]}


def sample():
    """Periodic sampling of numbers other engines already keep (read-only)."""
    evaluate()
    try:
        import friday_core5 as c5
        lat = c5._stats.get("latency") or []
        if lat and _last_seen.get("c5_len") != (len(lat), lat[-1]):
            record("voice_first_audio_ms", lat[-1])
            _last_seen["c5_len"] = (len(lat), lat[-1])
    except Exception:
        pass
    try:
        import friday_voice5 as V5
        t = (V5.health().get("last") or {})
        if t.get("stt_ms") is not None and _last_seen.get("stt") != json.dumps(t, sort_keys=True, default=str):
            record("stt_ms", t["stt_ms"])
            _last_seen["stt"] = json.dumps(t, sort_keys=True, default=str)
    except Exception:
        pass
    try:
        import friday_speech5 as S5
        t = (S5.health().get("last") or {})
        if t.get("first_audio_ms") is not None and _last_seen.get("fa") != json.dumps(t, sort_keys=True, default=str):
            record("tts_first_audio_ms", t["first_audio_ms"])
            _last_seen["fa"] = json.dumps(t, sort_keys=True, default=str)
    except Exception:
        pass


def note_response(ms: float, route: str = ""):
    record("response_ms", ms, route=route)


# ------------------------------------------------------------------ reports
def api_failure_rate(window_s: float = 600) -> Optional[float]:
    try:
        rows = C.q("SELECT AVG(ok) a, COUNT(*) n FROM model_calls6 WHERE ts>? AND cached=0", (time.time() - window_s,))
        if rows and rows[0]["n"]:
            return round(1 - rows[0]["a"], 3)
    except Exception:
        pass
    return None


def recommendations(comps: Dict[str, Dict], res: Dict) -> List[str]:
    out = []
    if comps.get("models", {}).get("status") in ("degraded", "down"):
        out.append("Check the Gemini key and internet connection (Settings), or install a local model with Ollama so FRIDAY has a fallback.")
    if comps.get("system", {}).get("status") == "degraded":
        out.append("Close heavy applications; FRIDAY is running in light mode to stay responsive.")
    if comps.get("tools", {}).get("status") in ("degraded", "down"):
        out.append("Several tools are failing; open Intelligence > Health to see which one and why.")
    if comps.get("speaking", {}).get("status") == "degraded":
        out.append("The fast speech engine paused; it recovers after the next successful sentence, speech continues on the normal path.")
    if comps.get("listening", {}).get("status") == "down":
        out.append("The listening engine reported a problem; say 'fix the microphone' or choose another microphone.")
    if (res.get("disk") or 0) > 90:
        out.append("The disk is almost full; free some space so backups and logs keep working.")
    return out or ["Nothing needs attention."]


def diagnostic_report() -> Dict:
    comps = check_all()
    res = _resources()
    m = {n: summary(n, 3600) for n in ("response_ms", "voice_first_audio_ms", "stt_ms", "tts_first_audio_ms", "cpu_pct", "ram_pct")}
    try:
        import friday_verify7 as V
        ts = V.stats(3600)
    except Exception:
        ts = {"total": 0, "success_rate": None, "by_tool": []}
    return {"generated": C.iso(), "version": K.VERSION, "session": K.SESSION_ID, "uptime_min": round((time.time() - K.STARTED) / 60, 1), "overall": overall(comps),
            "components": comps, "resources": res, "metrics": m, "api_failure_rate_10min": api_failure_rate(), "tool_success": ts.get("success_rate"), "tool_runs": ts.get("total"),
            "light_mode": {"on": _state["light"], "reason": _state["reason"], "since": C.iso(_state["since"]) if _state["since"] else ""},
            "incidents_open": incidents(True, 10), "recommendations": recommendations(comps, res), "bus_errors": K.bus_errors()}


def spoken_summary(rep: Optional[Dict] = None) -> str:
    rep = rep or diagnostic_report()
    bad = [f"{n} is {c['status']}" for n, c in rep["components"].items() if c["status"] in ("degraded", "down")]
    parts = [f"Overall health is {rep['overall']}."]
    if bad:
        parts.append("; ".join(bad[:3]).capitalize() + ".")
    m = rep["metrics"]["voice_first_audio_ms"]
    if m["n"]:
        parts.append(f"Average time to first sound is {int(m['avg'])} milliseconds.")
    if rep["light_mode"]["on"]:
        parts.append("I'm in light mode because " + (rep["light_mode"]["reason"] or "the machine is busy") + ".")
    parts.append(rep["recommendations"][0])
    return " ".join(parts)


def export_report() -> str:
    rep = diagnostic_report()
    d = C.DATA_DIR / "reports7"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"health-{time.strftime('%Y%m%d-%H%M%S')}.txt"
    lines = [f"FRIDAY {rep['version']} health report - {rep['generated']}", f"Overall: {rep['overall']}   Uptime: {rep['uptime_min']} min   Session: {rep['session']}", ""]
    lines += [f"[{c['status'].upper():8}] {n}: {c['detail']}" for n, c in rep["components"].items()]
    lines += ["", "Resources: " + json.dumps(rep["resources"], default=str), "", "Metrics (last hour):"]
    lines += [f"  {n}: {json.dumps(v)}" for n, v in rep["metrics"].items()]
    lines += ["", "Recommendations:"] + [f"  - {x}" for x in rep["recommendations"]]
    p.write_text("\n".join(lines), encoding="utf-8")
    return str(p)


# ------------------------------------------------------------------ regression benchmarks (micro, deterministic, local)
def _bench_db():
    C.q("SELECT 1")


def _bench_json():
    K.jl(K.jd({"a": list(range(200)), "b": "x" * 400}))


def _bench_similarity():
    C.similarity("my laptop keeps crashing during builds", "the computer has a bug and fails to compile")


def _bench_classify():
    try:
        import friday_orchestrator7 as O
        O.classify_intent("research cheaper chicken recipes then cost them and save a summary")
    except ImportError:
        _bench_similarity()


BENCHES: List[Tuple[str, Callable]] = [("db_roundtrip", _bench_db), ("json_codec", _bench_json), ("similarity", _bench_similarity), ("intent_classification", _bench_classify)]


def regression_benchmarks(repeat: int = 30, tolerance: float = 3.0) -> Dict:
    """Compare today's micro-timings with the stored baseline; a result more than `tolerance` x slower is flagged as a regression."""
    rows = []
    for name, fn in BENCHES:
        ts = []
        for _ in range(repeat):
            t0 = time.perf_counter()
            fn()
            ts.append((time.perf_counter() - t0) * 1000)
        ts.sort()
        med = ts[len(ts) // 2]
        key = "perf_base:" + name
        base = K.cfg_get(key, "")
        try:
            b = float(base)
        except Exception:
            b = 0.0
        if not b:
            K.cfg_set(key, f"{max(med, 0.01):.4f}")
            b = max(med, 0.01)
        ratio = round(med / b, 2) if b else 1.0
        rows.append({"name": name, "median_ms": round(med, 4), "baseline_ms": round(b, 4), "ratio": ratio, "regressed": ratio > tolerance and med > 1.0})
    return {"results": rows, "regressed": [r["name"] for r in rows if r["regressed"]]}


def snapshot() -> Dict:
    rep = diagnostic_report()
    rep["log"] = recent_log(15)
    rep["incidents_all"] = incidents(False, 12)
    return rep
