"""FRIDAY Movie-Agent Integration v4042.

Adds an observable agent layer around the existing V4041 stack without
replacing the microphone, VAD, ASR/recognition, or TTS implementation.

Responsibilities:
- build a cheap live situation/context snapshot
- maintain an event stream for changes worth knowing about
- provide compact context to the Gemini conversation path
- classify turns into fast / planned / supervised execution profiles
- record action outcomes for learning and verification layers
- keep all proactive actions behind the existing supervisor policy

Design rule: this module is fail-open. If it breaks, FRIDAY falls back to
V4041 exactly as before.
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Optional

try:
    import psutil
except Exception:
    psutil = None

try:
    import friday_state_engine as state
except Exception:
    state = None

try:
    import friday_agent_core as agent_core
except Exception:
    agent_core = None

_LOCK = threading.RLock()
_STARTED = False
_EVENTS = deque(maxlen=160)
_LAST_ACTIVE = None
_LAST_SYSTEM = 0.0
_LAST_RAM_WARN = 0.0
_LAST_CPU_WARN = 0.0
_VERSION = "4042-movie-agent"


def _now() -> float:
    return time.time()


def _emit(kind: str, text: str, **extra: Any) -> None:
    event = {"ts": _now(), "kind": kind, "text": str(text)[:600], **extra}
    with _LOCK:
        _EVENTS.append(event)
    try:
        print("FRIDAY_EVENT::" + json.dumps(event, ensure_ascii=False), flush=True)
    except Exception:
        pass


def _active_window() -> Optional[str]:
    """Use the existing lightweight foreground-window helper when available."""
    try:
        import friday_backend
        fn = getattr(friday_backend, "get_active_window_title", None)
        if callable(fn):
            value = fn()
            return str(value).strip() if value else None
    except Exception:
        pass
    return None


def _visible_windows() -> list[dict[str, str]]:
    try:
        import friday_screen_intelligence as screen
        fn = getattr(screen, "_visible_windows", None)
        if callable(fn):
            return [{"app": str(a), "title": str(t)} for a, t in fn(limit=10)]
    except Exception:
        pass
    return []


def _system_snapshot() -> dict[str, Any]:
    out: dict[str, Any] = {}
    if psutil is None:
        return out
    try:
        out["cpu_percent"] = round(float(psutil.cpu_percent(interval=None)), 1)
    except Exception:
        pass
    try:
        vm = psutil.virtual_memory()
        out["ram_percent"] = round(float(vm.percent), 1)
        out["ram_available_mb"] = round(float(vm.available) / 1048576, 1)
    except Exception:
        pass
    try:
        out["battery_percent"] = round(float(psutil.sensors_battery().percent), 1) if psutil.sensors_battery() else None
    except Exception:
        pass
    return out


def snapshot(include_windows: bool = True, include_system: bool = True) -> dict[str, Any]:
    """Cheap situation snapshot. Never captures the screen image by default."""
    active = _active_window()
    data: dict[str, Any] = {
        "timestamp": _now(),
        "active_window": active,
        "windows": _visible_windows() if include_windows else [],
        "system": _system_snapshot() if include_system else {},
        "version": _VERSION,
    }
    try:
        if agent_core is not None:
            data["conversation"] = agent_core.snapshot()
    except Exception:
        pass
    return data


def context_block(max_chars: int = 2200) -> str:
    """Return compact, factual context suitable for the LLM prompt."""
    try:
        snap = snapshot(include_windows=True, include_system=True)
        lines = ["LIVE FRIDAY SITUATION (observed facts only):"]
        if snap.get("active_window"):
            lines.append(f"Focused window: {snap['active_window']}")
        windows = snap.get("windows") or []
        if windows:
            names = []
            for w in windows[:6]:
                label = w.get("app") or w.get("title")
                if label and label not in names:
                    names.append(label)
            if names:
                lines.append("Visible applications: " + ", ".join(names))
        sysinfo = snap.get("system") or {}
        if sysinfo:
            metrics = []
            if sysinfo.get("cpu_percent") is not None:
                metrics.append(f"CPU {sysinfo['cpu_percent']}%")
            if sysinfo.get("ram_percent") is not None:
                metrics.append(f"RAM {sysinfo['ram_percent']}%")
            if sysinfo.get("battery_percent") is not None:
                metrics.append(f"battery {sysinfo['battery_percent']}%")
            if metrics:
                lines.append("System: " + ", ".join(metrics))
        if agent_core is not None:
            try:
                s = agent_core.snapshot()
                for label, key in (("Current task", "task"), ("Current topic", "topic"), ("Last action", "last_action")):
                    if s.get(key):
                        lines.append(f"{label}: {s[key]}")
            except Exception:
                pass
        return "\n".join(lines)[:max_chars]
    except Exception:
        return ""


def classify(command: str, context: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """Fast deterministic executive profile; no network/model call."""
    text = re.sub(r"\s+", " ", str(command or "").strip())
    low = text.lower()
    words = len(text.split())
    compound = len(re.findall(r"\b(and then|then|after that|also|once|before|while)\b", low)) >= 1
    external = bool(re.search(r"\b(latest|today|current|research|search|website|source|verify|look up)\b", low))
    consequential = bool(re.search(r"\b(send|delete|remove|purchase|buy|pay|transfer|publish|shutdown|restart|uninstall)\b", low))
    computer_action = bool(re.search(r"\b(open|close|launch|start|click|type|write|move|scroll|switch|navigate|play|press)\b", low))
    needs_plan = compound or external or words > 14 or bool(re.search(r"\b(create|build|analy[sz]e|compare|prepare|make)\b", low))
    if consequential:
        route = "supervised"
    elif needs_plan:
        route = "planned"
    elif computer_action:
        route = "tool_fast"
    else:
        route = "fast"
    result = {
        "version": _VERSION,
        "route": route,
        "needs_plan": needs_plan,
        "external_evidence": external,
        "consequential": consequential,
        "computer_action": computer_action,
        "compound": compound,
        "confidence": 0.92 if text else 0.0,
    }
    try:
        if state is not None:
            state.update("cognition", movie_agent_route=route, movie_agent_plan=needs_plan,
                         movie_agent_external=external, movie_agent_consequential=consequential,
                         updated_at=_now())
    except Exception:
        pass
    return result


def observe_environment() -> None:
    """Background sentinel: records meaningful changes but does not speak."""
    global _LAST_ACTIVE, _LAST_SYSTEM, _LAST_RAM_WARN, _LAST_CPU_WARN
    try:
        active = _active_window()
        if active and active != _LAST_ACTIVE:
            previous = _LAST_ACTIVE
            _LAST_ACTIVE = active
            if agent_core is not None:
                try:
                    agent_core.observer_tick(active)
                except Exception:
                    pass
            _emit("awareness", f"Focus changed to {active}", previous=previous, active=active)

        now = _now()
        if now - _LAST_SYSTEM >= 10.0:
            _LAST_SYSTEM = now
            info = _system_snapshot()
            ram = float(info.get("ram_percent") or 0)
            cpu = float(info.get("cpu_percent") or 0)
            if ram >= 92 and now - _LAST_RAM_WARN >= 90:
                _LAST_RAM_WARN = now
                _emit("resource_warning", f"RAM usage is high at {ram:.0f}%", ram_percent=ram)
            if cpu >= 95 and now - _LAST_CPU_WARN >= 90:
                _LAST_CPU_WARN = now
                _emit("resource_warning", f"CPU usage is high at {cpu:.0f}%", cpu_percent=cpu)
            if state is not None:
                state.update("environment", movie_agent_system=info, movie_agent_ts=now)
    except Exception:
        pass


def start(interval: float = 1.0) -> None:
    global _STARTED
    with _LOCK:
        if _STARTED:
            return
        _STARTED = True
    if state is not None:
        try:
            state.update("movie_agent", enabled=True, version=_VERSION, policy="observe -> understand -> plan -> execute -> verify; consequential actions remain gated")
        except Exception:
            pass

    def loop() -> None:
        while True:
            observe_environment()
            time.sleep(max(0.5, float(interval)))

    threading.Thread(target=loop, name="Jarvis-Movie-Agent-Sentinel", daemon=True).start()


def events(limit: int = 20) -> list[dict[str, Any]]:
    with _LOCK:
        return list(_EVENTS)[-max(1, int(limit)):]


def health() -> dict[str, Any]:
    with _LOCK:
        return {"version": _VERSION, "started": _STARTED, "events": len(_EVENTS)}
