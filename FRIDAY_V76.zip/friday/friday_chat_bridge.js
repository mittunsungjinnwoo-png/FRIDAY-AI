/* FRIDAY V2.3.1 - chat bridge.
   1) Keeps the backend informed about the Calendar / Memory / Tasks / Files / Tools pages so the chat can answer about them.
   2) Lets the chat (typed or spoken) add calendar events. Opening pages uses the existing  FRIDAY_UI::VIEW::  line.
   Additive only: it reads the page data and adds one line listener; it changes nothing else in the app. */
(function () {
  'use strict';
  var B = window.fridayBridge;
  if (!B || !B.appState || !B.onLine) return;

  function snapshot() {
    try {
      var m = (typeof X !== 'undefined' && X) || {};
      return {
        today: (typeof today === 'function') ? today() : new Date().toISOString().slice(0, 10),
        page: (typeof V !== 'undefined') ? V : '',
        mem: (m.mem || []).slice(0, 40).map(function (x) { return { t: String(x.text || '').slice(0, 200), k: x.kind }; }),
        cal: (m.cal || []).slice(0, 120).map(function (c) { return { d: c.d, t: c.t, n: String(c.n || '').slice(0, 120), done: !!c.done }; }),
        tasks: (m.tasks || []).slice(0, 10).map(function (k) { return { q: String(k.q || '').slice(0, 160), st: k.st }; }),
        files: (m.files || []).slice(0, 40).map(function (f) { return { name: String(f.name || '').slice(0, 80), size: +((f.size || 0) / 1024).toFixed(1), note: f.note ? String(f.note).slice(0, 80) : '' }; }),
        audit: (m.audit || []).slice(0, 10).map(function (a) { return String(a.a || '').slice(0, 80) + ' [' + a.r + ']'; }),
        metrics: m.m ? { ok: m.m.ok, tools: m.m.tools, toolOk: m.m.toolOk, cmds: m.m.cmds } : {},
        perm: m.perm || {}
      };
    } catch (e) { return null; }
  }

  var last = '';
  function push(force) {
    var s = snapshot();
    if (!s) return;
    var j = JSON.stringify(s);
    if (!force && j === last) return;
    last = j;
    try { B.appState(s); } catch (e) {}
  }

  // first push as soon as the engine is up, then whenever something changed
  if (B.onBackendReady) B.onBackendReady(function () { setTimeout(function () { push(true); }, 600); });
  setInterval(function () { push(false); }, 3000);
  setTimeout(function () { push(true); }, 2500);

  // V3.1: actions from chat / voice on the other pages (memory, calendar items, theme)
  B.onLine(function (l) {
    if (typeof l !== 'string' || l.indexOf('FRIDAY_UI::ACT::') !== 0) return;
    try {
      var raw = atob(l.slice('FRIDAY_UI::ACT::'.length));
      var o = JSON.parse(decodeURIComponent(escape(raw)));
      if (!o || !o.op) return;
      var norm = function (v) { return String(v || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').trim(); };
      var refresh = function () {
        if (typeof sx === 'function') sx();
        if (typeof V !== 'undefined' && typeof render === 'function' && V !== 'Home') render();
        push(true);
      };
      if (o.op === 'mem_add' && o.text) {
        X.mem.unshift({ id: (typeof uid === 'function') ? uid() : Date.now(), text: String(o.text), kind: /\b(today|for now|temporar)/i.test(o.text) ? 'temp' : 'long', used: 0 });
        if (typeof log === 'function') log('Memory added');
        refresh();
      } else if (o.op === 'mem_del' && o.text) {
        var k = norm(o.text);
        X.mem = X.mem.filter(function (m) { return norm(m.text).indexOf(k) < 0; });
        if (typeof log === 'function') log('Memory deleted');
        refresh();
      } else if ((o.op === 'cal_done' || o.op === 'cal_del') && o.name) {
        var n = norm(o.name), hit = null;
        for (var i = 0; i < X.cal.length; i++) {
          var c = X.cal[i];
          if (norm(c.n) === n && (!o.d || c.d === o.d) && (!o.t || c.t === o.t)) { hit = c; break; }
        }
        if (hit) {
          if (o.op === 'cal_done') hit.done = 1; else X.cal = X.cal.filter(function (x) { return x !== hit; });
          if (typeof log === 'function') log((o.op === 'cal_done' ? 'Event done: ' : 'Event removed: ') + o.name);
          refresh();
        }
      } else if (o.op === 'theme') {
        var isLight = (typeof Theme !== 'undefined' && Theme.isLight) ? !!Theme.isLight() : document.body.classList.contains('lt');
        if (!o.mode || (o.mode === 'light') !== isLight) { var b = document.getElementById('sun'); if (b) b.click(); }
      }
    } catch (e) { console.warn('[friday chat bridge act]', e); }
  });

  // calendar entries added from chat
  B.onLine(function (l) {
    if (typeof l !== 'string' || l.indexOf('FRIDAY_UI::CAL_ADD::') !== 0) return;
    try {
      var raw = atob(l.slice('FRIDAY_UI::CAL_ADD::'.length));
      var o = JSON.parse(decodeURIComponent(escape(raw)));
      if (!o || !o.n || !o.d) return;
      X.cal.push({ id: (typeof uid === 'function') ? uid() : Date.now(), d: String(o.d), t: String(o.t || '09:00'), n: String(o.n), done: false });
      if (typeof sx === 'function') sx();
      if (typeof log === 'function') log('Calendar event added from chat: ' + o.n);
      if (typeof V !== 'undefined' && V === 'Calendar' && typeof render === 'function') render();
      push(true);
    } catch (e) { console.warn('[friday chat bridge]', e); }
  });
})();
