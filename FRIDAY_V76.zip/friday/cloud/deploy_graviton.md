# Deploying FRIDAY Vision on AWS Graviton (COOL)

This is the optional "AWS" box of the architecture. FRIDAY works fully without it; with it, vision frames can be
analysed on a Graviton (ARM64) instance and you get measured local-vs-cloud numbers for the competition report.

## 1. Launch the instance
1. AWS Console > EC2 > Launch instance.
2. Pick the **Cloud Optimized OpenCV (COOL) for AWS Graviton** AMI from AWS Marketplace (search "Cloud Optimized OpenCV"),
   choose a Graviton instance type (for example `c7g.large`, Graviton3), and create/select a key pair.
3. Security group: allow SSH (22) from **your IP only**. Allow the FRIDAY port (8443) **only from your own IP** (or from a load balancer).
   Do not open it to 0.0.0.0/0.

## 2. Install FRIDAY's vision server
```bash
ssh -i your-key.pem ec2-user@<public-ip>          # (user name depends on the AMI: ec2-user / ubuntu)
mkdir friday && cd friday
# copy these 4 files from your FRIDAY folder (scp), keeping them together:
#   friday_vision_server.py friday_vision_engine.py friday_vision_config.py friday_vision_cloud.py
python3 -c "import cv2; print(cv2.__version__, cv2.__file__)"     # which OpenCV does Python see?
```
On the COOL AMI the optimised build lives under `/opt/cool`. If the line above does not show a COOL/OpenCV 5 build, follow the
AMI's usage notes (shown on its Marketplace page) to activate it. If it does, tell the server:
```bash
export FRIDAY_COOL=1
```
If OpenCV is missing: `pip3 install opencv-python-headless numpy pillow` (this is the *standard* pip build, handy as the baseline to compare against COOL).

## 3. Secret + TLS
```bash
export FRIDAY_CLOUD_TOKEN="$(openssl rand -hex 32)"       # copy this value; you will paste it into FRIDAY
echo $FRIDAY_CLOUD_TOKEN
openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 365 -subj "/CN=friday-vision"   # self-signed, fine for a test
python3 friday_vision_server.py --port 8443 --certfile cert.pem --keyfile key.pem
```
Self-signed certificates are rejected by default. For a quick test use an SSH tunnel instead and `http://localhost:8443` in FRIDAY:
`ssh -i your-key.pem -L 8443:localhost:8443 ec2-user@<public-ip>` and start the server with `--insecure-dev` bound to `--host 127.0.0.1`.
(For a permanent setup put it behind an Application Load Balancer with an ACM certificate.)

## 4. Connect FRIDAY
Settings > Vision > Cloud: tick *Use the cloud server*, paste the URL (for example `https://<public-ip>:8443`), paste the token, **Save token**, then **Test connection**.
It should show the OpenCV version, `aarch64`, and whether COOL is active.

## 5. Measure (for your report)
Settings > Vision > Cloud > **Compare local vs cloud** runs the same OpenCV micro-benchmarks on your PC and on the instance and shows the speed ratio.
Export the report from Settings > Vision > Evaluation. To measure the COOL benefit itself, run the benchmark twice on the same Graviton instance:
once with the standard pip OpenCV (`pip3 install opencv-python-headless`) and once with COOL, and compare the two JSON files.

## 6. Cost
Stop the instance when you are not using it (a stopped instance does not bill for compute). If you hold a competition AWS Compute Grant, apply it under Billing.
