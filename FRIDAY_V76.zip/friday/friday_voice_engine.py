"""Fast local speech-to-text helper for FRIDAY (Faster-Whisper).

v88 LATENCY REWRITE
-------------------
The previous version of this module had three defects that made recognition
feel slow and, on many machines, made it *wrong*:

  1. `sample_rate` was accepted as an argument and then completely ignored.
     Whisper requires 16 kHz mono float32. A typical microphone opens at
     44100 Hz, so the raw PCM was handed to Whisper at 2.76x the correct
     length. Whisper then heard a slowed-down, pitch-shifted voice: worse
     accuracy AND ~2.76x the compute per utterance.

  2. The model was built lazily inside the first transcription, so the first
     command after boot paid the entire model-load cost (several seconds)
     inside the critical path.

  3. `beam_size=5` on `small.en` / CPU. Beam search costs roughly 2-4x
     greedy decoding and buys essentially nothing on short command-length
     utterances.

All three are fixed here. The public API is backwards compatible:
`faster_whisper_available()` and `transcribe_pcm()` keep their signatures,
so nothing that already imports this module needs to change.

v89 GPU AUTO-DETECTION
----------------------
Device/compute now auto-detect a CUDA GPU (via ctranslate2, no torch
dependency) and use it when present, with a beam size of 5 there instead of
2 for both a large speed AND accuracy win. Falls back to cpu/int8 if no GPU
is found or if loading on the GPU fails for any reason. Set
FRIDAY_WHISPER_DEVICE explicitly to override auto-detection either way.

Environment variables (all optional):
    FRIDAY_WHISPER_MODEL     default "small.en"   (accuracy-first default)
    FRIDAY_WHISPER_DEVICE    default: auto-detected ("cuda" if available, else "cpu")
    FRIDAY_WHISPER_COMPUTE   default: "float16" on cuda, "int8" on cpu
    FRIDAY_WHISPER_BEAM      default: "5" on cuda, "2" on cpu
    FRIDAY_WHISPER_THREADS   default = physical cpu count (capped at 8)
    FRIDAY_WHISPER_PRELOAD   default "1"  -- warm the model at import time
    FRIDAY_STT_DEBUG         default "0"  -- print per-stage timings
"""
from __future__ import annotations

import os
import sys
import threading
import time
from typing import Optional

try:
    from faster_whisper import WhisperModel
except Exception:
    WhisperModel = None

try:
    import numpy as np
except Exception:
    np = None


TARGET_SAMPLE_RATE = 16000
# Keep language configurable for regional English/accent deployments while
# retaining the command-optimised English default. The prompt is a short hint,
# not a replacement for the user's words; it improves recognition of FRIDAY's
# own command vocabulary without inventing commands.
WHISPER_LANGUAGE = os.getenv("FRIDAY_WHISPER_LANGUAGE", "en").strip() or "en"
WHISPER_PROMPT = os.getenv("FRIDAY_WHISPER_PROMPT","Friday, open, close, search, play, remind me, send a message, WhatsApp, calendar, goals, memory, attach, file, code, research, screen, camera, system, income, expense, budget.")


_model = None
_model_device = "cpu"
_model_lock = threading.Lock()
# Separate, never-held-for-long lock guarding _load_started only.
# It must NOT be _model_lock: the preload worker holds _model_lock for the
# entire model build (which can be a multi-minute download), so any caller
# that took _model_lock just to check a boolean would block for that whole
# time -- which defeats the entire point of the non-blocking path.
_state_lock = threading.Lock()
_load_started = False
_load_error: Optional[str] = None
_last_transcription_confidence = 0.0
_DEBUG = os.getenv("FRIDAY_STT_DEBUG", "0").strip().lower() in {"1", "true", "yes", "on"}


def _log(message: str) -> None:
    if _DEBUG:
        try:
            print(f"[STT] {message}", flush=True)
        except Exception:
            pass


def faster_whisper_available() -> bool:
    """True when both faster-whisper and numpy are importable."""
    return WhisperModel is not None and np is not None


def _default_threads() -> int:
    try:
        configured = os.getenv("FRIDAY_WHISPER_THREADS", "").strip()
        if configured:
            return max(1, int(configured))
    except Exception:
        pass
    try:
        count = os.cpu_count() or 4
    except Exception:
        count = 4
    # Whisper on CPU scales poorly past ~8 threads and oversubscribing
    # starves the microphone/TTS threads.
    return max(1, min(8, count))


def _hf_cache_roots():
    """Candidate HuggingFace cache directories, in the order HF checks them."""
    roots = []
    for env_name, suffix in (("HF_HUB_CACHE", ""), ("HF_HOME", "hub"), ("XDG_CACHE_HOME", "huggingface/hub")):
        value = os.getenv(env_name, "").strip()
        if value:
            roots.append(os.path.join(value, suffix) if suffix else value)
    roots.append(os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub"))
    return roots


def is_model_cached(model_name: str) -> bool:
    """True when faster-whisper will NOT need to download this model.

    A local directory path is taken at face value; otherwise we look for the
    Systran repo snapshot in the HuggingFace cache.
    """
    try:
        if os.path.isdir(model_name):
            return True
        folder = f"models--Systran--faster-whisper-{model_name}"
        for root in _hf_cache_roots():
            candidate = os.path.join(root, folder, "snapshots")
            if os.path.isdir(candidate) and os.listdir(candidate):
                return True
    except Exception:
        pass
    return False


# Preference order when nothing is cached and nothing is configured: fast first.
_MODEL_PREFERENCE = ("base.en", "small.en", "tiny.en", "medium.en")   # 5.0: speed first - the cloud recogniser races it anyway
# Peak mode prefers the highest practical local model automatically:
# CUDA -> large-v3; CPU -> medium.en. Users can override with FRIDAY_WHISPER_MODEL.
PEAK_MODE = os.getenv("FRIDAY_PEAK_MODE", "0").strip().lower() in {"1","true","yes","on"}


def resolve_model_name() -> str:
    """Pick which Whisper model to load.

    An explicit FRIDAY_WHISPER_MODEL always wins. Otherwise we prefer a model
    that is ALREADY DOWNLOADED over the nominal default, because switching the
    default to a model the user does not have cached turns their next startup
    into a ~150 MB download -- and if they speak before it finishes, their
    first command appears to hang. Using what is already on disk is almost
    always the better trade.
    """
    configured = os.getenv("FRIDAY_WHISPER_MODEL", "").strip()
    if configured:
        return configured

    # In peak mode, select by hardware first. A GPU can handle large-v3;
    # CPU falls back to medium.en to avoid making the assistant unusably slow.
    if PEAK_MODE:
        try:
            if _cuda_device_count() > 0:
                return "large-v3"
        except Exception:
            pass
        # On CPU, prefer the fastest cached model that is still strong for
        # short commands. Medium can add noticeable decode latency on laptops.
        if is_model_cached("small.en"):
            return "small.en"
        if is_model_cached("medium.en"):
            return "medium.en"

    # Never force a download merely because a larger model exists: a cached
    # model gives a much better first-run experience and still keeps the
    # explicit override available for users who want maximum accuracy.
    for name in _MODEL_PREFERENCE:
        if is_model_cached(name):
            return name
    return _MODEL_PREFERENCE[0]


def _cuda_device_count() -> int:
    """GPU count via ctranslate2 -- no torch dependency required.

    faster-whisper runs on ctranslate2, which already ships its own CUDA
    runtime bindings. Checking through it means real GPU auto-detection
    without adding a ~2GB torch install just to ask "is there a GPU".
    """
    try:
        import ctranslate2
        return int(ctranslate2.get_cuda_device_count())
    except Exception:
        return 0


def _resolve_device_and_compute():
    """Pick device/compute_type. An explicit env var always wins.

    Otherwise, auto-detect a CUDA GPU and prefer it: on a GPU, decoding is
    roughly 5-10x faster than CPU int8, which is what actually gets FRIDAY
    to "instant, movie-style" recognition on machines that have one. CPU
    users see no change -- same int8 default as before.
    """
    device_override = os.getenv("FRIDAY_WHISPER_DEVICE", "").strip()
    compute_override = os.getenv("FRIDAY_WHISPER_COMPUTE", "").strip()

    if device_override:
        return device_override, (compute_override or ("float16" if device_override == "cuda" else "int8"))

    if _cuda_device_count() > 0:
        return "cuda", (compute_override or "float16")

    return "cpu", (compute_override or "int8")


def _build_model():
    """Construct the WhisperModel. Caller must hold _model_lock."""
    global _load_error
    model_name = resolve_model_name()
    device, compute = _resolve_device_and_compute()
    threads = _default_threads()

    if not is_model_cached(model_name):
        print(
            f"🧠 Downloading speech model '{model_name}' (one time, ~150 MB). "
            "Speech recognition uses Google STT until it finishes.",
            flush=True,
        )

    started = time.time()
    try:
        model = WhisperModel(
            model_name,
            device=device,
            compute_type=compute,
            cpu_threads=threads,
            num_workers=1,
        )
    except Exception as error:
        if device != "cpu":
            # A GPU was detected but the model failed to load on it (missing
            # CUDA/cuDNN runtime libs, driver mismatch, etc.) -- fall back to
            # CPU rather than leaving speech recognition broken entirely.
            _log(f"GPU load failed ({error}); falling back to cpu/int8")
            device, compute = "cpu", "int8"
            model = WhisperModel(
                model_name,
                device=device,
                compute_type=compute,
                cpu_threads=threads,
                num_workers=1,
            )
        else:
            raise
    _load_error = None
    global _model_device
    _model_device = device
    _log(f"loaded model={model_name} device={device} compute={compute} "
         f"threads={threads} in {time.time() - started:.2f}s")
    return model


def ensure_model(wait: bool = True):
    """Return the loaded model, building it if necessary. None on failure.

    With `wait=False`, returns None immediately if the model is not already
    resident instead of blocking behind the preload thread. That matters on
    the FIRST utterance of a session: faster-whisper downloads the model from
    HuggingFace the first time a given model name is used (~150 MB for
    base.en), and `_model_lock` would otherwise make the user's first command
    wait for that entire download before recognition even started -- exactly
    the "the first thing I say takes forever" symptom.
    """
    global _model, _load_error
    if not faster_whisper_available():
        return None
    if _model is not None:
        return _model
    if not wait:
        # Kick the background load off if nobody has yet, then give up for now.
        preload(blocking=False)
        return None
    with _model_lock:
        if _model is None:
            try:
                _model = _build_model()
            except Exception as error:
                _load_error = str(error)
                _log(f"model load FAILED: {error}")
                return None
    return _model


def is_ready() -> bool:
    """True when the model is loaded and a transcription will be fast."""
    return _model is not None


def load_error() -> Optional[str]:
    return _load_error


def last_transcription_confidence() -> float:
    """Approximate local-Whisper confidence for the most recent utterance."""
    try:
        return float(_last_transcription_confidence)
    except Exception:
        return 0.0


def preload(blocking: bool = False) -> None:
    """Warm the model (and its CTranslate2 kernels) off the critical path.

    Call this once at startup. Without it, the FIRST command a user speaks
    pays the whole model-load + first-inference cost, which is exactly the
    "why is FRIDAY so slow to recognise me" symptom.
    """
    global _load_started
    if not faster_whisper_available():
        return

    def _worker():
        model = ensure_model()
        if model is None:
            return
        # One tiny inference forces CTranslate2 to allocate and JIT its
        # kernels, so the first REAL utterance does not pay for it.
        try:
            if np is not None:
                silence = np.zeros(TARGET_SAMPLE_RATE // 2, dtype=np.float32)
                started = time.time()
                segments, _ = model.transcribe(silence, language="en", beam_size=1)
                list(segments)
                _log(f"warm-up inference {time.time() - started:.2f}s")
        except Exception as error:
            _log(f"warm-up skipped: {error}")

    with _state_lock:
        first_caller = not _load_started
        _load_started = True

    if blocking:
        # Must actually guarantee readiness on return. If a background preload
        # is already in flight, _worker()'s ensure_model(wait=True) blocks on
        # _model_lock until that load completes, then returns the same model --
        # so this is correct whether or not we are the first caller.
        _worker()
    elif first_caller:
        threading.Thread(target=_worker, name="whisper-preload", daemon=True).start()


def _resample_to_16k(samples, source_rate: int):
    """Linear-interpolation resample to 16 kHz.

    Deliberately numpy-only -- adding scipy as a hard dependency for one
    filter is not worth it, and for speech going *down* in rate the
    quality difference is inaudible to Whisper.
    """
    if source_rate == TARGET_SAMPLE_RATE or source_rate <= 0:
        return samples
    duration = samples.shape[0] / float(source_rate)
    target_length = int(round(duration * TARGET_SAMPLE_RATE))
    if target_length <= 1 or samples.shape[0] <= 1:
        return samples
    source_positions = np.linspace(0.0, samples.shape[0] - 1, num=samples.shape[0], dtype=np.float64)
    target_positions = np.linspace(0.0, samples.shape[0] - 1, num=target_length, dtype=np.float64)
    return np.interp(target_positions, source_positions, samples).astype(np.float32)


def pcm_to_float32(raw_pcm: bytes, sample_rate: int = TARGET_SAMPLE_RATE,
                   channels: int = 1):
    """16-bit little-endian PCM bytes -> mono float32 @ 16 kHz, or None."""
    if np is None or not raw_pcm:
        return None
    try:
        audio = np.frombuffer(raw_pcm, dtype=np.int16)
        if audio.size == 0:
            return None
        if channels > 1:
            usable = (audio.size // channels) * channels
            audio = audio[:usable].reshape(-1, channels).mean(axis=1)
        audio = audio.astype(np.float32) / 32768.0
        return _resample_to_16k(audio, int(sample_rate or TARGET_SAMPLE_RATE))
    except Exception as error:
        _log(f"pcm conversion failed: {error}")
        return None


def transcribe_pcm(raw_pcm: bytes, sample_rate: int = TARGET_SAMPLE_RATE,
                   channels: int = 1, wait_for_model: bool = False) -> Optional[str]:
    """Transcribe raw 16-bit PCM. Returns text, or None on any failure.

    `sample_rate` is now actually honoured -- the audio is resampled to the
    16 kHz Whisper expects instead of being reinterpreted at the wrong rate.

    `wait_for_model` defaults to False: if the model is still loading (first
    run, or a cold model download), this returns None immediately so the
    caller can fall back to Google STT rather than making the user wait. Pass
    True only if you specifically need the local engine.
    """
    if not faster_whisper_available() or not raw_pcm:
        return None
    global _last_transcription_confidence
    try:
        _last_transcription_confidence = 0.0
        started = time.time()
        audio = pcm_to_float32(raw_pcm, sample_rate=sample_rate, channels=channels)
        if audio is None or audio.size < TARGET_SAMPLE_RATE // 20:  # < 50 ms
            return None
        prepared = time.time()

        model = ensure_model(wait=wait_for_model)
        if model is None:
            return None
        loaded = time.time()

        try:
            # On GPU the extra beam-search cost is negligible, so default it
            # higher there for better accuracy. CPU keeps the existing
            # latency-friendly default of 2.
            default_beam = "5" if _model_device == "cuda" else ("2" if PEAK_MODE else "3")
            beam = max(1, int(os.getenv("FRIDAY_WHISPER_BEAM", default_beam)))
        except Exception:
            beam = 1

        segments, _info = model.transcribe(
            audio,
            language=WHISPER_LANGUAGE,
            beam_size=beam,
            # Command-style utterances are independent of each other; keeping
            # previous text as context makes Whisper hallucinate continuations.
            condition_on_previous_text=False,
            # Trim leading/trailing silence before decoding -- this is where
            # most of the wall-clock saving comes from on a short command.
            vad_filter=True,
            vad_parameters={
                "min_silence_duration_ms": 220,
                "speech_pad_ms": 80,
            },
            no_speech_threshold=0.55,
            log_prob_threshold=-1.0,
            compression_ratio_threshold=2.4,
            temperature=0.0,
            initial_prompt=WHISPER_PROMPT,
        )
        segment_list = list(segments)
        text = " ".join((segment.text or "").strip() for segment in segment_list).strip()

        # faster-whisper exposes avg_logprob per segment. Convert it to a
        # conservative 0..1 quality estimate. This is only used to decide
        # whether a local result is trustworthy enough; it never replaces
        # the transcript itself.
        if segment_list:
            try:
                probs = [float(getattr(seg, "avg_logprob", -2.5)) for seg in segment_list]
                avg_logprob = sum(probs) / len(probs)
                _last_transcription_confidence = max(0.0, min(1.0, (avg_logprob + 2.0) / 2.0))
            except Exception:
                _last_transcription_confidence = 0.75 if text else 0.0
        else:
            _last_transcription_confidence = 0.0

        done = time.time()
        _log(
            f"audio={audio.size / TARGET_SAMPLE_RATE:.2f}s "
            f"prep={prepared - started:.3f}s "
            f"load={loaded - prepared:.3f}s "
            f"decode={done - loaded:.3f}s -> {text!r}"
        )
        return text or None
    except Exception as error:
        _log(f"transcription failed: {error}")
        return None


# Warm the model at import time unless explicitly disabled. The import of
# friday_backend already happens behind the fast-boot launcher, and this is a
# daemon thread, so it never delays the UI handshake.
if os.getenv("FRIDAY_WHISPER_PRELOAD", "1").strip().lower() in {"1", "true", "yes", "on"}:
    try:
        preload(blocking=False)
    except Exception:
        pass
