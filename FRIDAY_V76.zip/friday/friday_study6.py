"""FRIDAY 6.0 study and academic intelligence (blueprint section 9) - works from material YOU provide (syllabus, past papers,
official mark schemes, notes).  FRIDAY never invents a mark scheme: marking compares your answer with the marking points you
supply and says plainly when none were supplied.

syllabus-aware tutoring - past-paper bank by topic/paper/session/type - mark-scheme evaluation - revision priorities from real
performance - mistake tracking - spaced-repetition flashcards (SM-2) - timed mock exams - progress analytics.
"""
from __future__ import annotations

import json
import math
import random
import re
import time
from typing import Dict, List, Optional

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS st_subjects(id INTEGER PRIMARY KEY, name TEXT UNIQUE, exam_date TEXT, created REAL);
CREATE TABLE IF NOT EXISTS st_topics(id INTEGER PRIMARY KEY, subject INTEGER, name TEXT, objective TEXT, weight REAL DEFAULT 1, UNIQUE(subject,name));
CREATE TABLE IF NOT EXISTS st_questions(id INTEGER PRIMARY KEY, subject INTEGER, topic INTEGER, paper TEXT, session TEXT, qtype TEXT, text TEXT, marks INTEGER, scheme TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS st_attempts(id INTEGER PRIMARY KEY, question INTEGER, topic INTEGER, ts REAL, score REAL, max REAL, seconds REAL, answer TEXT, missed TEXT);
CREATE TABLE IF NOT EXISTS st_cards(id INTEGER PRIMARY KEY, subject INTEGER, topic INTEGER, front TEXT, back TEXT, ease REAL DEFAULT 2.5, interval REAL DEFAULT 0, reps INTEGER DEFAULT 0, due REAL, ts REAL);
CREATE TABLE IF NOT EXISTS st_mistakes(id INTEGER PRIMARY KEY, topic INTEGER, kind TEXT, note TEXT, count INTEGER DEFAULT 1, ts REAL);
CREATE TABLE IF NOT EXISTS st_mock(id INTEGER PRIMARY KEY, subject INTEGER, started REAL, limit_s REAL, qids TEXT, ended REAL, result TEXT);
""")


def subject(name: str, create: bool = True) -> Optional[int]:
    name = name.strip().lower()
    r = C.q("SELECT id FROM st_subjects WHERE name=?", (name,))
    if r:
        return r[0]["id"]
    return C.x("INSERT INTO st_subjects(name,created) VALUES(?,?)", (name, C.now())) if create else None


def topic(subj: str, name: str, objective: str = "", weight: float = 1.0) -> int:
    sid = subject(subj)
    name = name.strip().lower()
    r = C.q("SELECT id FROM st_topics WHERE subject=? AND name=?", (sid, name))
    if r:
        if objective:
            C.x("UPDATE st_topics SET objective=? WHERE id=?", (objective, r[0]["id"]))
        return r[0]["id"]
    return C.x("INSERT INTO st_topics(subject,name,objective,weight) VALUES(?,?,?,?)", (sid, name, objective, weight))


def import_syllabus(subj: str, text: str) -> int:
    """One topic per line; 'topic: learning objective' allowed.  Numbering and bullets are stripped."""
    n = 0
    lines = text.splitlines()
    if len(lines) <= 1:                                     # spoken / one-line input: split on numbering, semicolons, or commas
        one = text.strip()
        parts = re.split(r"\s*;\s*|\s+(?=\d+[.)]\s)", one)
        if len(parts) <= 1 and ":" not in one:
            parts = re.split(r"\s*,\s*|\s+and\s+", one)
        lines = [x for x in parts if x.strip()]
    for line in lines:
        line = re.sub(r"^\s*(?:[-*•]|\d+(?:\.\d+)*[.)]?)\s*", "", line).strip()
        if len(line) < 3:
            continue
        name, _, obj = line.partition(":")
        topic(subj, name, obj.strip())
        n += 1
    return n


def add_question(subj: str, topic_name: str, text: str, marks: int = 1, scheme: str = "", paper: str = "", session: str = "", qtype: str = "short") -> int:
    return C.x("INSERT INTO st_questions(subject,topic,paper,session,qtype,text,marks,scheme,ts) VALUES(?,?,?,?,?,?,?,?,?)",
               (subject(subj), topic(subj, topic_name), paper, session, qtype, C.clip(text, 1200), marks, scheme, C.now()))


def bank(subj: str, by: str = "topic") -> Dict:
    """Past-paper analysis: how the question bank is distributed by topic / paper / session / type."""
    sid = subject(subj, False)
    if sid is None:
        return {}
    col = {"topic": "t.name", "paper": "q.paper", "session": "q.session", "type": "q.qtype"}[by]
    rows = C.q(f"SELECT {col} k, COUNT(*) n, SUM(q.marks) m FROM st_questions q JOIN st_topics t ON t.id=q.topic WHERE q.subject=? GROUP BY k ORDER BY m DESC", (sid,))
    return {(r["k"] or "unspecified"): {"questions": r["n"], "marks": r["m"]} for r in rows}


# ------------------------------------------------------------------ mark-scheme evaluation
def _points(scheme: str) -> List[str]:
    return [p.strip(" -•*\t") for p in re.split(r"[;\n]|(?<=\.)\s+(?=[A-Z0-9])", scheme or "") if len(p.strip(" -•*\t")) > 3]


def mark(answer: str, scheme: str, marks: int) -> Dict:
    """Compare an answer to marking points: a point is credited when most of its key terms (with stems and synonyms) appear."""
    pts = _points(scheme)
    if not pts:
        return {"ok": False, "error": "No mark scheme supplied. Give me the official marking points (separated by semicolons) and I'll mark against them."}
    got, missed = [], []
    for p in pts:
        keys = C.tokens(p, True)
        have = set(C.tokens(answer, True))
        need = [k for k in keys if not k.startswith("~g")] or keys
        hit = sum(1 for k in set(need) if k in have or any(C.similarity(k, w) > 0.8 for w in have if abs(len(w) - len(k)) < 3))
        (got if hit / max(1, len(set(need))) >= 0.6 else missed).append(p)
    score = min(marks, len(got) if len(pts) <= marks else round(len(got) / len(pts) * marks, 1))
    return {"ok": True, "score": score, "max": marks, "credited": got, "missed": missed}


def attempt(qid: int, answer: str, seconds: float = 0.0) -> Dict:
    q = C.q("SELECT * FROM st_questions WHERE id=?", (qid,))
    if not q:
        return {"ok": False, "error": "unknown question"}
    q = q[0]
    r = mark(answer, q["scheme"], q["marks"])
    if r["ok"]:
        C.x("INSERT INTO st_attempts(question,topic,ts,score,max,seconds,answer,missed) VALUES(?,?,?,?,?,?,?,?)", (qid, q["topic"], C.now(), r["score"], r["max"], seconds, C.clip(answer, 800), C.jdump(r["missed"])))
        for m in r["missed"][:3]:
            log_mistake(q["topic"], "missed-point", m)
    return r


# ------------------------------------------------------------------ mistakes, mastery, revision priorities
def log_mistake(topic_id: int, kind: str, note: str):
    r = C.q("SELECT id FROM st_mistakes WHERE topic=? AND kind=? AND note=?", (topic_id, kind, C.clip(note, 160)))
    if r:
        C.x("UPDATE st_mistakes SET count=count+1, ts=? WHERE id=?", (C.now(), r[0]["id"]))
    else:
        C.x("INSERT INTO st_mistakes(topic,kind,note,ts) VALUES(?,?,?,?)", (topic_id, kind, C.clip(note, 160), C.now()))


def mastery(subj: str) -> List[Dict]:
    sid = subject(subj, False)
    if sid is None:
        return []
    out = []
    for t in C.q("SELECT * FROM st_topics WHERE subject=?", (sid,)):
        a = C.q("SELECT score,max,ts,seconds FROM st_attempts WHERE topic=? ORDER BY ts DESC LIMIT 12", (t["id"],))
        if a:
            w = [(0.85 ** i) for i in range(len(a))]                      # recent attempts count more
            acc = sum(x["score"] / max(1, x["max"]) * wi for x, wi in zip(a, w)) / sum(w)
            trend = (a[0]["score"] / max(1, a[0]["max"])) - (a[-1]["score"] / max(1, a[-1]["max"])) if len(a) > 1 else 0.0
        else:
            acc, trend = None, 0.0
        cards = C.q("SELECT AVG(ease) e, COUNT(*) n FROM st_cards WHERE topic=?", (t["id"],))[0]
        out.append({"topic": t["name"], "accuracy": None if acc is None else round(acc, 2), "attempts": len(a), "trend": round(trend, 2), "weight": t["weight"], "cards": cards["n"],
                    "avg_seconds": round(sum(x["seconds"] for x in a) / len(a), 1) if a else None})
    return sorted(out, key=lambda d: (d["accuracy"] is None, d["accuracy"] or 0))


def revision_plan(subj: str, hours: float = 5.0) -> List[Dict]:
    """Prioritise weak topics from real performance; untried topics are treated as unknown (medium-weak), not as mastered."""
    m = mastery(subj)
    if not m:
        return []
    need = []
    for d in m:
        weak = 0.55 if d["accuracy"] is None else (1 - d["accuracy"])
        need.append((weak * d["weight"] + (0.05 if d["trend"] < 0 else 0), d))
    tot = sum(n for n, _ in need) or 1
    sid = subject(subj, False)
    ex = C.q("SELECT exam_date FROM st_subjects WHERE id=?", (sid,))
    return [{"topic": d["topic"], "minutes": max(10, int(hours * 60 * n / tot)), "why": ("not attempted yet" if d["accuracy"] is None else f"accuracy {int(d['accuracy'] * 100)} percent" + (", getting worse" if d["trend"] < 0 else ""))}
            for n, d in sorted(need, key=lambda x: -x[0])]


# ------------------------------------------------------------------ flashcards with spaced repetition (SM-2)
def add_card(subj: str, topic_name: str, front: str, back: str) -> int:
    return C.x("INSERT INTO st_cards(subject,topic,front,back,due,ts) VALUES(?,?,?,?,?,?)", (subject(subj), topic(subj, topic_name), C.clip(front, 400), C.clip(back, 600), C.now(), C.now()))


def cards_from_text(subj: str, topic_name: str, text: str) -> int:
    """Turn definition-style sentences from trusted notes into cards ('X is Y', 'X: Y', 'X - Y')."""
    n = 0
    for s in re.split(r"(?<=[.!?])\s+|\n", text):
        m = re.match(r"^\s*([A-Z][\w \-\(\)/']{2,50}?)\s*(?::|—|–| - | is | are | means | refers to )\s*(.{12,300})$", s.strip())
        if m:
            add_card(subj, topic_name, f"What is {m.group(1).strip().rstrip('?')}?", m.group(2).strip().rstrip("."))
            n += 1
    return n


def due_cards(subj: str = "", limit: int = 10) -> List[Dict]:
    sql = "SELECT c.*, t.name tname FROM st_cards c JOIN st_topics t ON t.id=c.topic WHERE c.due<=?" + (" AND c.subject=?" if subj else "") + " ORDER BY c.due LIMIT ?"
    args = [C.now()] + ([subject(subj, False)] if subj else []) + [limit]
    return [dict(r) for r in C.q(sql, args)]


def review_card(cid: int, quality: int) -> Dict:
    """SM-2: quality 0-5 (0-2 forgotten, 3 hard, 4 good, 5 easy)."""
    c = C.q("SELECT * FROM st_cards WHERE id=?", (cid,))[0]
    ease, reps, interval = c["ease"], c["reps"], c["interval"]
    if quality < 3:
        reps, interval = 0, 1.0
    else:
        reps += 1
        interval = 1.0 if reps == 1 else (6.0 if reps == 2 else round(interval * ease, 1))
    ease = max(1.3, ease + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)))
    C.x("UPDATE st_cards SET ease=?, reps=?, interval=?, due=? WHERE id=?", (round(ease, 3), reps, interval, C.now() + interval * 86400, cid))
    return {"interval_days": interval, "ease": round(ease, 2)}


# ------------------------------------------------------------------ mock exams
def start_mock(subj: str, minutes: int = 30, n: int = 5) -> Dict:
    sid = subject(subj, False)
    qs = [r for r in C.q("SELECT id,text,marks FROM st_questions WHERE subject=?", (sid,))] if sid else []
    if not qs:
        return {"ok": False, "error": "no questions in the bank for that subject yet"}
    random.shuffle(qs)
    pick = qs[:n]
    mid = C.x("INSERT INTO st_mock(subject,started,limit_s,qids) VALUES(?,?,?,?)", (sid, C.now(), minutes * 60, C.jdump([q["id"] for q in pick])))
    return {"ok": True, "mock": mid, "questions": [{"id": q["id"], "text": q["text"], "marks": q["marks"]} for q in pick], "limit_minutes": minutes}


def finish_mock(mid: int, answers: Dict[int, str]) -> Dict:
    m = C.q("SELECT * FROM st_mock WHERE id=?", (mid,))[0]
    used = C.now() - m["started"]
    tot = mx = 0.0
    detail = []
    for qid in C.jload(m["qids"], []):
        r = attempt(qid, answers.get(qid, ""), used / max(1, len(answers) or 1))
        if r.get("ok"):
            tot += r["score"]; mx += r["max"]
            detail.append({"q": qid, "score": r["score"], "max": r["max"], "missed": r["missed"][:2]})
    over = used > m["limit_s"]
    res = {"score": tot, "max": mx, "percent": round(100 * tot / mx, 1) if mx else 0, "minutes_used": round(used / 60, 1), "over_time": over, "detail": detail}
    C.x("UPDATE st_mock SET ended=?, result=? WHERE id=?", (C.now(), C.jdump(res), mid))
    return res


def analytics(subj: str) -> Dict:
    sid = subject(subj, False)
    if sid is None:
        return {}
    a = C.q("SELECT COUNT(*) n, SUM(score) s, SUM(max) m, SUM(seconds) sec FROM st_attempts a JOIN st_topics t ON t.id=a.topic WHERE t.subject=?", (sid,))[0]
    weekly = C.q("SELECT strftime('%Y-%W', datetime(ts,'unixepoch')) wk, SUM(score)*1.0/SUM(max) acc FROM st_attempts a JOIN st_topics t ON t.id=a.topic WHERE t.subject=? GROUP BY wk ORDER BY wk DESC LIMIT 6", (sid,))
    return {"attempts": a["n"], "accuracy": round((a["s"] or 0) / (a["m"] or 1), 3) if a["n"] else None, "study_minutes": round((a["sec"] or 0) / 60, 1),
            "weekly": [{"week": r["wk"], "accuracy": round(r["acc"], 2)} for r in weekly][::-1], "mastery": mastery(subj),
            "due_cards": len(due_cards(subj, 200)), "mistakes": [dict(r) for r in C.q("SELECT m.note, m.count FROM st_mistakes m JOIN st_topics t ON t.id=m.topic WHERE t.subject=? ORDER BY m.count DESC LIMIT 5", (sid,))]}


def teach_prompt(subj: str, topic_name: str, level: str = "standard") -> str:
    r = C.q("SELECT objective FROM st_topics WHERE name=? LIMIT 1", (topic_name.lower(),))
    obj = r[0]["objective"] if r and r[0]["objective"] else ""
    return (f"Teach {topic_name} for {subj} at {level} level, step by step, checking understanding with one short question at the end of each step. "
            + (f"Syllabus objective: {obj}. " if obj else "Stay within what a school syllabus at this level expects. ") + "Do not skip prerequisites; say when something is beyond the syllabus.")


# ------------------------------------------------------------------ chat commands
_active_mock: Dict = {}


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    m = re.match(r"^(?:add|import|set) (?:the )?syllabus (?:for |of )?([\w \-]+?)[:\n]\s*(.+)$", t, re.I | re.S)
    if m:
        return f"Syllabus saved: {import_syllabus(m.group(1), m.group(2))} topics for {m.group(1).strip()}."
    m = re.match(r"^(?:add|save) (?:a )?(?:past[- ]paper )?question (?:to |for |in )?([\w \-]+?) (?:topic|on) ([\w \-]+?)(?: \((\d+) marks?\))?[:\n]\s*(.+?)(?:\s*(?:mark scheme|scheme|marking points?)[:\-]\s*(.+))?$", t, re.I | re.S)
    if m:
        qid = add_question(m.group(1), m.group(2), m.group(4).strip(), int(m.group(3) or 1), (m.group(5) or "").strip())
        return f"Question {qid} saved under {m.group(2)}." + ("" if m.group(5) else " No mark scheme was given, so I can't mark it until you add one.")
    m = re.match(r"^(?:flash ?cards?|make cards?)(?: for| from)?\s+([\w \-]+?)[:\n]\s*(.+)$", t, re.I | re.S)
    if m:
        n = cards_from_text(m.group(1), m.group(1), m.group(2))
        return f"Made {n} flashcards." if n else "I couldn't find definition-style sentences. Write them like 'Osmosis: movement of water across a membrane'."
    if re.match(r"^(?:quiz me|test me|flash ?cards?|review (?:my )?cards?|start (?:a )?review)(?: on [\w \-]+)?$", low):
        d = due_cards("", 1)
        if not d:
            return "No flashcards are due. Well done."
        _active_mock["card"] = d[0]
        return f"Card from {d[0]['tname']}: {d[0]['front']} Say your answer, then 'show answer'."
    if low == "show answer" and "card" in _active_mock:
        c = _active_mock["card"]
        return f"The answer: {c['back']}. Say 'easy', 'good', 'hard' or 'forgot'."
    m = re.match(r"^(easy|good|hard|forgot|again)$", low)
    if m and "card" in _active_mock:
        q = {"easy": 5, "good": 4, "hard": 3, "forgot": 1, "again": 1}[m.group(1)]
        r = review_card(_active_mock.pop("card")["id"], q)
        d = due_cards("", 1)
        if d:
            _active_mock["card"] = d[0]
            return f"Next review in {r['interval_days']:g} days. Next card: {d[0]['front']}"
        return f"Next review in {r['interval_days']:g} days. That's every due card done."
    m = re.match(r"^(?:what should i revise|revision plan|plan my revision)(?: for ([\w \-]+?))?(?: with (\d+(?:\.\d+)?) hours?)?$", low)
    if m:
        subj = m.group(1) or (C.q("SELECT name FROM st_subjects ORDER BY created DESC LIMIT 1") or [{"name": ""}])[0]["name"]
        p = revision_plan(subj, float(m.group(2) or 5))
        return "I need a syllabus first. Say 'add syllabus for physics:' followed by the topics." if not p else "Revise in this order: " + "; ".join(f"{x['topic']} for {x['minutes']} minutes ({x['why']})" for x in p[:5]) + "."
    m = re.match(r"^(?:my )?(?:progress|study analytics|how am i doing)(?: in| for| on)? ?([\w \-]*)$", low)
    if m and re.search(r"progress|analytics|how am i doing", low):
        subj = m.group(1).strip() or (C.q("SELECT name FROM st_subjects ORDER BY created DESC LIMIT 1") or [{"name": ""}])[0]["name"]
        a = analytics(subj)
        if not a or not a["attempts"]:
            return "No marked attempts yet, so there's nothing to analyse. Do a few questions with mark schemes first."
        weak = [x for x in a["mastery"] if x["accuracy"] is not None][:2]
        return f"{subj.title()}: {a['attempts']} marked attempts, overall accuracy {int(a['accuracy'] * 100)} percent, {a['study_minutes']} minutes logged." + (f" Weakest: {', '.join(w['topic'] + ' ' + str(int(w['accuracy'] * 100)) + '%' for w in weak)}." if weak else "") + f" {a['due_cards']} flashcards due."
    m = re.match(r"^(?:start )?(?:a )?(?:timed )?mock (?:exam|test)(?: (?:for|in|on) ([\w \-]+?))?(?: (?:for )?(\d+) minutes?)?$", low)
    if m:
        subj = m.group(1) or (C.q("SELECT name FROM st_subjects ORDER BY created DESC LIMIT 1") or [{"name": ""}])[0]["name"]
        r = start_mock(subj, int(m.group(2) or 30))
        if not r["ok"]:
            return "I need past-paper questions for that subject first: " + r["error"] + "."
        _active_mock["mock"] = r
        qs = r["questions"]
        return f"Mock exam started: {len(qs)} questions, {r['limit_minutes']} minutes. Question 1 ({qs[0]['marks']} marks): {qs[0]['text']}"
    if low in ("what mistakes do i keep making", "my common mistakes", "mistake tracker"):
        rows = C.q("SELECT m.note, m.count, t.name FROM st_mistakes m JOIN st_topics t ON t.id=m.topic ORDER BY m.count DESC LIMIT 4")
        return "No mistakes recorded yet." if not rows else "Your repeat slips: " + "; ".join(f"{r['name']}: {r['note']} ({r['count']} times)" for r in rows) + "."
    m = re.match(r"^(?:teach me|explain|help me (?:learn|revise)) ([\w \-,]+?)(?: for ([\w \-]+))?$", low)
    if m and re.search(r"^(?:teach me|help me)", low):
        return "__MODEL__" + teach_prompt(m.group(2) or "the course", m.group(1))
    return None


def ui_snapshot() -> Dict:
    subs = [r["name"] for r in C.q("SELECT name FROM st_subjects ORDER BY created DESC")]
    return {"subjects": subs, "analytics": analytics(subs[0]) if subs else {}, "plan": revision_plan(subs[0]) if subs else [], "bank": bank(subs[0]) if subs else {}}
