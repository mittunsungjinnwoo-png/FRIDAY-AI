FRIDAY 6.0 plugins
------------------
Drop a .py file here with:

    PLUGIN = {"name": "hello", "description": "says hi", "scopes": []}
    def handle(command):            # return a string to answer, or None to pass
        return "hi" if command == "hello plugin" else None

Plugins are OFF until you say "enable plugin hello". FRIDAY lists any risky calls (subprocess, sockets, exec...) when you enable it, and
switches the plugin off again automatically if the file changes afterwards. Say "list plugins" to see them.
