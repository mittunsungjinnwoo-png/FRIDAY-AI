"""
FRIDAY VISION CLOUD CLIENT  (optional AWS Graviton / COOL offload)
==================================================================
Sends frames to YOUR OWN friday_vision_server.py (running on an AWS Graviton instance, ideally with the
Cloud-Optimized OpenCV Library) and gets back the same VisionState the local engine would produce.

Privacy and safety:
  * OFF by default.  Switch on in Settings > Vision > Cloud, with your server URL and (optional) access token.
  * The token is stored by the app in Windows secure storage (never in a file FRIDAY writes) and held in memory here.
  * Camera frames only leave this PC if "Allow camera frames to leave this PC" is ticked.
  * If the server is down or slow, FRIDAY silently falls back to local OpenCV (when 'fallback' is ticked).
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Optional

import friday_vision_config as cfg

_FAIL = {"until": 0.0, "count": 0}


def enabled() -> bool:
    return bool(cfg.get("cloud_enabled") and cfg.get("cloud_url")) and time.time() >= _FAIL["until"]


def _url(path: str) -> str:
    return cfg.get("cloud_url").rstrip("/") + path


def _headers(extra: Optional[dict] = None) -> dict[str, str]:
    h = {"User-Agent": "FRIDAY-Vision/2.3"}
    tok = cfg.secret("cloud_token")
    if tok:
        h["Authorization"] = "Bearer " + tok
    h.update(extra or {})
    return h


def _call(path: str, data: Optional[bytes] = None, headers: Optional[dict] = None, timeout: Optional[float] = None) -> dict[str, Any]:
    req = urllib.request.Request(_url(path), data=data, headers=_headers(headers), method="POST" if data is not None else "GET")
    with urllib.request.urlopen(req, timeout=float(timeout or cfg.get("cloud_timeout"))) as r:
        return json.loads(r.read().decode("utf-8"))


def health(timeout: float = 6.0) -> dict[str, Any]:
    """Used by the Settings 'Test connection' button."""
    if not cfg.get("cloud_url"):
        return {"ok": False, "error": "Enter your server URL first."}
    t0 = time.perf_counter()
    try:
        data = _call("/health", timeout=timeout)
        return {"ok": True, "ms": round((time.perf_counter() - t0) * 1000, 1), "server": data}
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            return {"ok": False, "error": "The server rejected the access token (check Settings > Vision > Cloud)."}
        return {"ok": False, "error": f"The server answered with an error ({exc.code})."}
    except Exception as exc:
        return {"ok": False, "error": f"Could not reach the server: {exc}"}


def analyze_remote(frame, source_kind: str, do_ocr: bool = False) -> Optional[dict[str, Any]]:
    """Returns a VisionState dict, or None (caller then uses local OpenCV)."""
    import friday_vision_engine as ve
    t0 = time.perf_counter()
    try:
        jpeg = ve.encode_jpeg(frame, 1280, 80)
        q = urllib.parse.urlencode({"kind": source_kind, "ocr": "1" if do_ocr else "0", "mode": cfg.get("detector"), "conf": cfg.get("conf_threshold")})
        state = _call("/analyze?" + q, jpeg, {"Content-Type": "image/jpeg"})
        ms = (time.perf_counter() - t0) * 1000
        state["timings_ms"] = {**(state.get("timings_ms") or {}), "round_trip": round(ms, 1)}
        _FAIL.update(until=0.0, count=0)
        try:
            import friday_eval_metrics as em
            em.record_cloud(ms)
        except Exception:
            pass
        return state
    except Exception:
        _FAIL["count"] += 1
        _FAIL["until"] = time.time() + min(60, 4 * _FAIL["count"])      # back off, keep using local OpenCV meanwhile
        try:
            import friday_eval_metrics as em
            em.record_cloud(None, fallback=True)
        except Exception:
            pass
        if not cfg.get("cloud_fallback_local"):
            raise
        return None


def remote_benchmark(timeout: float = 120.0) -> dict[str, Any]:
    try:
        return {"ok": True, "result": _call("/benchmark", b"{}", {"Content-Type": "application/json"}, timeout=timeout)}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def compare_local_vs_cloud() -> dict[str, Any]:
    """Run the same micro-benchmark here and on the server; returns both plus the speed ratios."""
    import friday_vision_engine as ve
    local = ve.micro_benchmark(10)
    remote = remote_benchmark()
    out: dict[str, Any] = {"local": {"environment": local["environment"], "operations": local["operations"]}, "cloud": None, "speedup": {}}
    if remote.get("ok"):
        r = remote["result"]
        out["cloud"] = {"environment": r.get("environment"), "operations": r.get("operations")}
        for name, lv in local["operations"].items():
            rv = (r.get("operations") or {}).get(name)
            if rv and "median_ms" in lv and "median_ms" in rv and rv["median_ms"] > 0:
                out["speedup"][name] = round(lv["median_ms"] / rv["median_ms"], 2)
    else:
        out["error"] = remote.get("error")
    return out
