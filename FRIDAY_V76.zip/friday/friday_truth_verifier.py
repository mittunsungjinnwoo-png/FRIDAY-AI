"""Independent post-action verification for FRIDAY desktop actions.

The executor is never the authority on success. This module observes the
computer *after* an action and returns evidence. It is intentionally optional:
when OCR/UIA are unavailable it uses independent screen/window/cursor evidence
and marks the evidence quality accordingly rather than claiming certainty.
"""
from __future__ import annotations
import hashlib, re, time
from pathlib import Path
from typing import Any, Optional


def screenshot() -> tuple[Any, int, int] | tuple[None, int, int]:
    try:
        import mss
        from PIL import Image
        with mss.mss() as sct:
            mon = sct.monitors[0]
            shot = sct.grab(mon)
            return Image.frombytes("RGB", shot.size, shot.rgb), shot.width, shot.height
    except Exception:
        return None, 0, 0


def image_hash(image: Any) -> Optional[str]:
    if image is None:
        return None
    try:
        small = image.convert("L").resize((96, 54))
        return hashlib.sha256(small.tobytes()).hexdigest()
    except Exception:
        return None


def visual_delta(before: Any, after: Any) -> float:
    if before is None or after is None:
        return 0.0
    try:
        from PIL import ImageChops, ImageStat
        a = before.convert("L").resize((96, 54))
        b = after.convert("L").resize((96, 54))
        diff = ImageChops.difference(a, b)
        return float(ImageStat.Stat(diff).mean[0]) / 255.0
    except Exception:
        return 0.0


def ocr_text(image: Any) -> str:
    if image is None:
        return ""
    try:
        import pytesseract
        return str(pytesseract.image_to_string(image, config="--psm 6") or "").strip()
    except Exception:
        return ""


def active_window_title() -> str:
    try:
        import ctypes
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        n = u.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        u.GetWindowTextW(hwnd, buf, n + 1)
        return buf.value.strip()
    except Exception:
        return ""


def cursor_position() -> tuple[int, int] | None:
    try:
        import pyautogui
        p = pyautogui.position()
        return int(p.x), int(p.y)
    except Exception:
        return None


def uia_snapshot(limit: int = 180) -> list[dict[str, Any]]:
    try:
        from friday_uia import inspect
        r = inspect(limit=limit)
        if r.get("ok"):
            return r.get("elements", [])
    except Exception:
        pass
    return []


def snapshot() -> dict[str, Any]:
    img, w, h = screenshot()
    return {
        "image": img,
        "width": w,
        "height": h,
        "hash": image_hash(img),
        "ocr": ocr_text(img),
        "window": active_window_title(),
        "cursor": cursor_position(),
        "uia": uia_snapshot(),
        "ts": time.time(),
    }


def compare(before: dict[str, Any], after: dict[str, Any], expected_text: str | None = None,
            expected_window: str | None = None) -> dict[str, Any]:
    delta = visual_delta(before.get("image"), after.get("image"))
    old_uia = {(x.get("name"), x.get("control_type"), x.get("rect",{}).get("left"), x.get("rect",{}).get("top")) for x in before.get("uia", [])}
    new_uia = {(x.get("name"), x.get("control_type"), x.get("rect",{}).get("left"), x.get("rect",{}).get("top")) for x in after.get("uia", [])}
    uia_changed = old_uia != new_uia
    ocr_match = False
    if expected_text:
        target = re.sub(r"\s+", " ", expected_text.strip().lower())
        observed = re.sub(r"\s+", " ", after.get("ocr", "").lower())
        ocr_match = bool(target and target in observed)
    window_match = bool(expected_window and expected_window.lower() in after.get("window", "").lower())
    return {
        "visual_delta": round(delta, 4),
        "visual_changed": delta >= 0.008,
        "uia_changed": uia_changed,
        "ocr_match": ocr_match,
        "window_match": window_match,
        "cursor_changed": before.get("cursor") != after.get("cursor"),
        "before_window": before.get("window", ""),
        "after_window": after.get("window", ""),
        "evidence_quality": "strong" if (ocr_match or window_match or uia_changed) else ("moderate" if delta >= 0.008 else "weak"),
    }


def verify_file(path: str | Path, min_size: int = 1) -> dict[str, Any]:
    p = Path(path)
    exists = p.exists() and p.is_file()
    size = p.stat().st_size if exists else 0
    return {"exists": exists, "size": size, "readable": bool(exists and size >= min_size), "path": str(p)}


def post_action(before: dict[str, Any], expected_text: str | None = None,
                expected_window: str | None = None, settle: float = 0.35) -> dict[str, Any]:
    if settle:
        time.sleep(settle)
    after = snapshot()
    result = compare(before, after, expected_text=expected_text, expected_window=expected_window)
    result["verified"] = bool(
        result["ocr_match"] or result["window_match"] or result["uia_changed"] or result["visual_changed"]
    )
    return result
