"""FRIDAY 6.0 software-engineering assistant (blueprint section 7).

Understands whole codebases (not snippets): dependency/module/class/function map, minimal targeted edits with a diff and
automatic rollback, static review (security + maintainability + performance hints), test generation and execution, isolated
code runs, git status/diff/log/branch/commit proposals (commits need approval), dependency and install diagnosis, build
verification ("does it actually run?"), and technical documentation generation.  Everything works offline on local files.
"""
from __future__ import annotations

import ast
import difflib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional

import friday_common6 as C

PKG_ALIAS = {"cv2": "opencv-python-headless", "PIL": "Pillow", "bs4": "beautifulsoup4", "yaml": "pyyaml", "sklearn": "scikit-learn", "docx": "python-docx", "pptx": "python-pptx", "serial": "pyserial", "dotenv": "python-dotenv", "speech_recognition": "SpeechRecognition", "pyaudio": "PyAudio", "fitz": "pymupdf"}
SKIP_DIRS = {"__pycache__", "node_modules", ".git", "venv", ".venv", "dist", "build", "friday_data", ".idea", ".mypy_cache"}


def _files(root: str, exts=(".py",), limit: int = 800) -> List[Path]:
    r = Path(root).expanduser()
    if r.is_file():
        return [r]
    out = []
    for p in r.rglob("*"):
        if len(out) >= limit:
            break
        if p.is_file() and p.suffix.lower() in exts and not (set(p.parts) & SKIP_DIRS):
            out.append(p)
    return out


# ------------------------------------------------------------------ 1. understand: map the codebase
def code_map(root: str) -> Dict:
    root_p = Path(root).expanduser()
    mods: Dict[str, Dict] = {}
    for f in _files(root):
        rel = str(f.relative_to(root_p)) if root_p.is_dir() else f.name
        try:
            src = f.read_text("utf-8", "ignore")
            tree = ast.parse(src)
        except Exception as exc:
            mods[rel] = {"error": f"syntax error: {exc}"}
            continue
        imports, classes, funcs = set(), [], []
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                imports |= {a.name.split(".")[0] for a in n.names}
            elif isinstance(n, ast.ImportFrom) and n.module:
                imports.add(n.module.split(".")[0])
        for n in tree.body:
            if isinstance(n, ast.ClassDef):
                classes.append({"name": n.name, "methods": [m.name for m in n.body if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef))][:30]})
            elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                funcs.append(n.name)
        mods[rel] = {"lines": src.count("\n") + 1, "imports": sorted(imports), "classes": classes, "functions": funcs[:60], "doc": (ast.get_docstring(tree) or "")[:120]}
    names = {Path(k).stem for k in mods}
    internal = {k: sorted(set(v.get("imports", [])) & names - {Path(k).stem}) for k, v in mods.items()}
    ext = sorted({i for v in mods.values() for i in v.get("imports", [])} - names - set(sys.stdlib_module_names))
    return {"modules": mods, "internal_deps": internal, "external_packages": ext, "files": len(mods), "lines": sum(v.get("lines", 0) for v in mods.values())}


def summarize_map(m: Dict) -> str:
    top = sorted(m["modules"].items(), key=lambda kv: -kv[1].get("lines", 0))[:5]
    hubs = sorted(m["internal_deps"].items(), key=lambda kv: -len(kv[1]))[:3]
    return (f"{m['files']} Python files, {m['lines']} lines. Largest: " + ", ".join(f"{k} ({v.get('lines', 0)})" for k, v in top) +
            (". Most connected: " + ", ".join(f"{k} uses {len(v)} local modules" for k, v in hubs if v) if any(v for _, v in hubs) else "") +
            (". External packages: " + ", ".join(m["external_packages"][:10]) if m["external_packages"] else "") + ".")


# ------------------------------------------------------------------ 2. review: bugs, security, maintainability
_SEC_RULES = [
    (re.compile(r"\beval\s*\("), "high", "eval() on dynamic input can run arbitrary code"),
    (re.compile(r"\bexec\s*\("), "high", "exec() can run arbitrary code"),
    (re.compile(r"shell\s*=\s*True"), "high", "subprocess with shell=True is injectable if any part is user-controlled"),
    (re.compile(r"\bpickle\.loads?\("), "high", "pickle can execute code when loading untrusted data"),
    (re.compile(r"yaml\.load\((?![^)]*Loader)"), "medium", "yaml.load without a safe Loader"),
    (re.compile(r"(?i)(?:api[_-]?key|secret|passwd|password|token)\s*=\s*['\"][A-Za-z0-9_\-/+=]{12,}['\"]"), "high", "hard-coded secret"),
    (re.compile(r"verify\s*=\s*False"), "medium", "TLS verification disabled"),
    (re.compile(r"\bmd5\(|\bsha1\("), "low", "weak hash (fine for checksums, not for security)"),
    (re.compile(r"except\s*:\s*(?:pass)?\s*$"), "low", "bare except hides real errors"),
    (re.compile(r"\binput\s*\(.*\)\s*\)\s*$"), "low", "unvalidated input"),
    (re.compile(r"os\.system\("), "medium", "os.system with a built string is injectable"),
    (re.compile(r"tempfile\.mktemp\("), "medium", "mktemp is racy; use NamedTemporaryFile"),
]


def review(root: str, max_findings: int = 40) -> Dict:
    findings, metrics = [], []
    for f in _files(root):
        try:
            src = f.read_text("utf-8", "ignore")
            tree = ast.parse(src)
        except Exception as exc:
            findings.append({"file": f.name, "line": 0, "sev": "high", "msg": f"does not parse: {exc}"})
            continue
        for i, line in enumerate(src.splitlines(), 1):
            for pat, sev, msg in _SEC_RULES:
                if pat.search(line) and not line.strip().startswith("#"):
                    findings.append({"file": f.name, "line": i, "sev": sev, "msg": msg})
        for n in ast.walk(tree):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                length = (getattr(n, "end_lineno", n.lineno) or n.lineno) - n.lineno + 1
                branches = sum(isinstance(c, (ast.If, ast.For, ast.While, ast.Try, ast.BoolOp, ast.ExceptHandler)) for c in ast.walk(n))
                metrics.append((f.name, n.name, n.lineno, length, branches + 1))
                if length > 120:
                    findings.append({"file": f.name, "line": n.lineno, "sev": "low", "msg": f"{n.name} is {length} lines long; consider splitting it"})
                if branches + 1 > 25:
                    findings.append({"file": f.name, "line": n.lineno, "sev": "low", "msg": f"{n.name} has high cyclomatic complexity (~{branches + 1})"})
                for a in n.args.defaults:
                    if isinstance(a, (ast.List, ast.Dict, ast.Set)):
                        findings.append({"file": f.name, "line": n.lineno, "sev": "medium", "msg": f"{n.name} uses a mutable default argument"})
            if isinstance(n, ast.For):                         # simple performance smell: string += in a loop
                for c in ast.walk(n):
                    if isinstance(c, ast.AugAssign) and isinstance(c.op, ast.Add) and isinstance(c.value, (ast.Constant, ast.JoinedStr)) and isinstance(getattr(c.value, "value", ""), str):
                        findings.append({"file": f.name, "line": c.lineno, "sev": "low", "msg": "string concatenation in a loop; build a list and join"}); break
    order = {"high": 0, "medium": 1, "low": 2}
    findings.sort(key=lambda d: (order[d["sev"]], d["file"], d["line"]))
    return {"findings": findings[:max_findings], "total": len(findings), "high": sum(1 for x in findings if x["sev"] == "high"),
            "longest": sorted(metrics, key=lambda m: -m[3])[:3]}


def spoken_review(r: Dict) -> str:
    if not r["total"]:
        return "I found no obvious bugs or security smells."
    top = r["findings"][:3]
    return f"I found {r['total']} issue{'s' if r['total'] != 1 else ''}, {r['high']} high severity. " + " ".join(f"{x['file']} line {x['line']}: {x['msg']}." for x in top)


# ------------------------------------------------------------------ 3. tests: generate, run, verify the build
def generate_tests(path: str) -> str:
    """Generate a unittest skeleton with real import checks and one smoke test per public function (no invented behaviour)."""
    f = Path(path).expanduser()
    src = f.read_text("utf-8", "ignore")
    tree = ast.parse(src)
    mod = f.stem
    lines = ["import importlib", "import inspect", "import sys", "import unittest", "from pathlib import Path", "",
             f"sys.path.insert(0, str(Path(__file__).resolve().parent))", f"M = importlib.import_module('{mod}')", "", "",
             f"class Test_{mod}(unittest.TestCase):", "    def test_imports(self):", "        self.assertIsNotNone(M)", ""]
    for n in tree.body:
        if isinstance(n, ast.FunctionDef) and not n.name.startswith("_"):
            args = [a.arg for a in n.args.args]
            lines += [f"    def test_{n.name}_exists_and_signature(self):", f"        fn = getattr(M, '{n.name}')", "        self.assertTrue(callable(fn))",
                      f"        self.assertEqual(list(inspect.signature(fn).parameters)[:{len(args)}], {args!r})", ""]
    lines += ["", "if __name__ == '__main__':", "    unittest.main()", ""]
    return "\n".join(lines)


def run_tests(path: str, timeout: int = 120) -> Dict:
    root = Path(path).expanduser()
    cwd = root if root.is_dir() else root.parent
    tests = [p for p in cwd.rglob("*.py") if re.search(r"(?:^test_|_test$|^FRIDAY_TEST)", p.stem, re.I) and not (set(p.parts) & SKIP_DIRS)][:12]
    if not tests:
        return {"ok": False, "ran": 0, "output": "no test files found (names like test_*.py)"}
    results, passed = [], 0
    for t in tests:
        try:
            r = subprocess.run([sys.executable, str(t)], cwd=str(cwd), capture_output=True, text=True, timeout=timeout, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            ok = r.returncode == 0
            passed += ok
            results.append({"test": t.name, "ok": ok, "tail": (r.stdout + r.stderr).strip()[-200:]})
        except subprocess.TimeoutExpired:
            results.append({"test": t.name, "ok": False, "tail": "timed out"})
    return {"ok": passed == len(tests), "ran": len(tests), "passed": passed, "results": results, "output": f"{passed} of {len(tests)} test files passed"}


def run_isolated(code: str, timeout: float = 10.0) -> Dict:
    """Run Python in a throw-away directory with a stripped environment and a time limit (not a security boundary; asks first)."""
    with tempfile.TemporaryDirectory(prefix="friday_run_") as d:
        p = Path(d) / "snippet.py"
        p.write_text(code, "utf-8")
        env = {"PATH": os.environ.get("PATH", ""), "PYTHONIOENCODING": "utf-8", "SYSTEMROOT": os.environ.get("SYSTEMROOT", "")}
        try:
            r = subprocess.run([sys.executable, "-I", str(p)], cwd=d, capture_output=True, text=True, timeout=timeout, env=env)
            return {"ok": r.returncode == 0, "stdout": r.stdout[-1500:], "stderr": r.stderr[-1500:], "code": r.returncode}
        except subprocess.TimeoutExpired:
            return {"ok": False, "stdout": "", "stderr": "timed out", "code": -1}


def verify_build(root: str) -> Dict:
    """'Verify that a build actually works before declaring success': syntax-compile everything, import top-level modules, run tests."""
    bad, ok_n = [], 0
    for f in _files(root):
        try:
            compile(f.read_text("utf-8", "ignore"), str(f), "exec")
            ok_n += 1
        except SyntaxError as exc:
            bad.append(f"{f.name}:{exc.lineno}: {exc.msg}")
    t = run_tests(root) if not bad else {"ok": False, "output": "skipped (fix syntax first)"}
    return {"ok": not bad and (t["ok"] or t.get("ran", 0) == 0), "compiled": ok_n, "syntax_errors": bad[:8], "tests": t["output"]}


# ------------------------------------------------------------------ 4. minimal, reversible edits
def propose_edit(path: str, old: str, new: str) -> Dict:
    f = Path(path).expanduser()
    src = f.read_text("utf-8", "ignore")
    if src.count(old) != 1:
        return {"ok": False, "error": f"the text to change appears {src.count(old)} times; I need exactly one match to keep the edit minimal"}
    after = src.replace(old, new)
    diff = "".join(difflib.unified_diff(src.splitlines(True), after.splitlines(True), f.name, f.name + " (proposed)", n=2))
    ok_syntax = True
    if f.suffix == ".py":
        try:
            compile(after, str(f), "exec")
        except SyntaxError as exc:
            ok_syntax = False
            diff += f"\n# WARNING: the edit would break syntax at line {exc.lineno}: {exc.msg}"
    return {"ok": ok_syntax, "diff": diff, "after": after}


def apply_edit(path: str, new_text: str) -> Dict:
    f = Path(path).expanduser()
    bak = f.with_suffix(f.suffix + ".friday.bak")
    shutil.copy2(f, bak)
    f.write_text(new_text, "utf-8")
    return {"ok": True, "backup": str(bak)}


def rollback_edit(path: str) -> bool:
    f = Path(path).expanduser()
    bak = f.with_suffix(f.suffix + ".friday.bak")
    if bak.exists():
        shutil.copy2(bak, f)
        return True
    return False


# ------------------------------------------------------------------ 5. git
def _git(args: List[str], cwd: str, timeout: int = 20) -> Dict:
    if not shutil.which("git"):
        return {"ok": False, "out": "git is not installed"}
    try:
        r = subprocess.run(["git"] + args, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return {"ok": r.returncode == 0, "out": (r.stdout or r.stderr).strip()}
    except Exception as exc:
        return {"ok": False, "out": str(exc)}


def git_status(cwd: str) -> str:
    s = _git(["status", "--short", "--branch"], cwd)
    return s["out"] if s["ok"] else "Not a git repository, or git failed: " + s["out"][:120]


def git_diff(cwd: str, stat: bool = True) -> str:
    return _git(["diff", "--stat"] if stat else ["diff"], cwd)["out"][:3000]


def git_log(cwd: str, n: int = 5) -> str:
    return _git(["log", f"-{n}", "--oneline"], cwd)["out"]


def git_branch(cwd: str) -> str:
    return _git(["branch", "--show-current"], cwd)["out"]


def propose_commit(cwd: str) -> Dict:
    d = _git(["diff", "--stat"], cwd)["out"]
    s = _git(["status", "--short"], cwd)["out"]
    msg = C.llm("Write a one-line conventional commit message for this change:\n" + d[:1500]) if C._cfg.get("llm") else ""
    files = [l[3:] for l in s.splitlines()][:6]
    return {"message": (msg or ("Update " + ", ".join(files)))[:100].strip(), "files": files, "stat": d}


def git_commit(cwd: str, message: str) -> str:
    a = _git(["add", "-A"], cwd)
    c = _git(["commit", "-m", message], cwd)
    return c["out"][:200] if c["ok"] else "Commit failed: " + c["out"][:200]


def git_rollback_proposal(cwd: str) -> str:
    log = _git(["log", "-3", "--oneline"], cwd)["out"]
    return "To undo the last commit and keep your changes: git reset --soft HEAD~1. To discard it entirely: git reset --hard HEAD~1 (destructive). Recent commits:\n" + log


# ------------------------------------------------------------------ 6. diagnose installs, document
def diagnose_install(error_text: str) -> str:
    t = error_text or ""
    rules = [
        (r"No module named ['\"]?([\w\.]+)", lambda m: f"The package '{m.group(1).split('.')[0]}' isn't installed in this Python. Run: {sys.executable} -m pip install {PKG_ALIAS.get(m.group(1).split('.')[0], m.group(1).split('.')[0])}"),
        (r"Microsoft Visual C\+\+ 14\.0.*required", lambda m: "A package needs the Microsoft C++ Build Tools; install them, or choose a version that ships a prebuilt wheel."),
        (r"Could not find a version that satisfies the requirement ([\w\-\.]+)", lambda m: f"No build of {m.group(1)} matches this Python version. Check the Python version (3.13 is very new) or try a newer release of the package."),
        (r"PermissionError|Access is denied|EACCES", lambda m: "A permission problem: close programs using the file, or run the installer as the same user that owns the folder."),
        (r"ERESOLVE|ResolutionImpossible|conflicting dependencies", lambda m: "Two packages need incompatible versions. Run pip check, then pin the one that is blocking, or use a fresh virtual environment."),
        (r"SSL|CERTIFICATE_VERIFY_FAILED", lambda m: "A certificate problem: check the system date and any antivirus or proxy that rewrites HTTPS."),
        (r"ModuleNotFoundError: No module named 'pyaudio'|PyAudio", lambda m: "PyAudio needs a prebuilt wheel on Windows: pip install pipwin then pipwin install pyaudio, or use the PyAudio wheel for your Python version."),
        (r"ENOENT|npm ERR! code E404", lambda m: "npm could not find a file or package; check the package name and your network, then npm install again."),
        (r"Address already in use|WinError 10048", lambda m: "Another program already uses that network port; close it or choose another port."),
    ]
    for pat, fn in rules:
        m = re.search(pat, t, re.I)
        if m:
            return fn(m)
    return "I don't recognise that error from my rules" + (". Here is how a model reads it: " + C.llm("Diagnose this install or runtime error and give the single most likely fix:\n" + t[-1500:]) if C._cfg.get("llm") else ". Paste the last 20 lines of the log and I'll look closer.")


def document(root: str) -> str:
    m = code_map(root)
    out = [f"# Technical documentation ({time.strftime('%Y-%m-%d')})", "", f"{m['files']} files, {m['lines']} lines.", "", "## Modules"]
    for k, v in sorted(m["modules"].items()):
        if "error" in v:
            out.append(f"- `{k}`: {v['error']}"); continue
        out.append(f"- `{k}` ({v['lines']} lines): {v['doc'] or 'no module docstring'}")
        if v["classes"]:
            out.append("  - classes: " + ", ".join(c["name"] for c in v["classes"][:8]))
        if v["functions"]:
            out.append("  - functions: " + ", ".join(v["functions"][:10]))
    out += ["", "## External packages", ", ".join(m["external_packages"]) or "none"]
    return "\n".join(out)


# ------------------------------------------------------------------ chat commands
def _path_from(text: str, default: str = ".") -> str:
    m = re.search(r"([A-Za-z]:\\[^\"'\n]+|/[\w\-./ ]+|\.{1,2}/[\w\-./]+)", text)
    return m.group(1).strip().rstrip(".,") if m else default


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if re.match(r"^(?:map|analy[sz]e|understand|scan|overview of) (?:the |my |this )?(?:code ?base|project|repo|code)(?: (?:at|in|of) .+)?$", low):
        p = _path_from(t, str(C.HERE))
        return summarize_map(code_map(p))
    if re.match(r"^(?:review|audit|check) (?:the |my |this )?(?:code ?base|project|repo|code)(?: .+)?$", low) and "folder" not in low:
        return spoken_review(review(_path_from(t, str(C.HERE))))
    if re.match(r"^(?:run|execute) (?:the |my )?(?:unit )?tests?(?: .+)?$", low):
        r = run_tests(_path_from(t, str(C.HERE)))
        return r["output"] + (". Failing: " + ", ".join(x["test"] for x in r["results"] if not x["ok"]) if r.get("results") and not r["ok"] else ".")
    if re.match(r"^(?:verify|check) (?:the |that the |my )?build(?: works| actually works)?(?: .+)?$", low):
        v = verify_build(_path_from(t, str(C.HERE)))
        return ("The build verifies: " if v["ok"] else "The build does NOT verify: ") + f"{v['compiled']} files compile" + (f", syntax errors: {'; '.join(v['syntax_errors'][:2])}" if v["syntax_errors"] else "") + f"; tests: {v['tests']}."
    m = re.match(r"^git (status|diff|log|branch)(?: .+)?$", low)
    if m:
        cwd = _path_from(t, str(C.HERE))
        return {"status": git_status, "diff": git_diff, "log": git_log, "branch": git_branch}[m.group(1)](cwd) or "Nothing to show."
    if re.match(r"^(?:propose|suggest|draft) (?:a )?(?:git )?commit(?: message)?$", low):
        p = propose_commit(str(C.HERE))
        return f"Proposed commit: \"{p['message']}\" covering {len(p['files'])} file(s). Say 'commit with that message' to confirm."
    if re.match(r"^(?:how (?:do i|can i) )?(?:roll ?back|undo) (?:the )?(?:last )?commit$", low):
        return git_rollback_proposal(str(C.HERE))
    m = re.match(r"^(?:diagnose|why (?:did|does) )?(?:this )?(?:install|installation|build|runtime) (?:error|failure|failed|problem)[: ]+(.+)$", t, re.I | re.S)
    if m:
        return diagnose_install(m.group(1))
    if re.match(r"^(?:generate|write|create) (?:technical )?documentation(?: for .+)?$", low):
        p = _path_from(t, str(C.HERE))
        out = C.DATA_DIR / "outputs"
        out.mkdir(parents=True, exist_ok=True)
        fp = out / "technical_documentation.md"
        fp.write_text(document(p), "utf-8")
        return f"Documentation written to {fp}."
    return None
