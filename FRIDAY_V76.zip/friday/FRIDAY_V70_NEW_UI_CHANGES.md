# FRIDAY 7.0 - New UI (complete makeover)

Only the interface changed. **No Python, voice, listening, recognition or speaking code was touched** - every `.py` file and the logic of the Voice settings tab are identical to the previous build.

## What is new

### Home
* New header (logo + FRIDAY wordmark, quote, clock, weather, status/mic/settings icons, window controls), sidebar (Home / Settings & Features), greeting with the ask bar and quick chips (Plan my day, Open Camera, Study Mode, Check Memory).
* **Today's Tasks** and **Upcoming Schedule** panels. Tick a task to mark it done, "View All" / "View Calendar" open **My Day**, where you add, edit, delete and repeat tasks and your weekly schedule. (A few sample tasks / classes are pre-filled so the panels are not empty - edit or delete them in My Day.)
* **Arc Reactor stage**: network sphere that rotates, rotating ring stack, beam, hologram platform, FRIDAY plate. It reacts to the assistant: idle, listening, recognising, speaking and thinking each look different and respond to the audio level.
* Four feature tiles (AI, Vision, Memory, Automation) - each opens its settings page.
* Right column: **System Status**, **Quick Actions** (File Explorer, Focus Mode with timer, Capture Screen / Record, Open Settings) and **Live Activity** (with a Stop button while FRIDAY is busy).
* Footer with status text and an **EXIT** button (asks Stay / Standby / Exit). `Esc` on Home opens the same dialog.
* Conversation drawer opens under the ask bar when you type or FRIDAY answers.

### Settings & Features
* Cards: Voice & Audio, AI & Model, Vision & Camera, Tasks & Automation, Memory, Appearance - plus the features that used to be hidden: **Finance, Calendar, Files, Web, Tools, Control Centre, Intelligence, General**.
* Current Mode & Quick Info bar (Productivity / Study / Focus / Creative / Relax) with Voice / Camera / Memory / Model shortcuts.
* Search (`Ctrl+K`), Back button, `Esc` goes back, EXIT SETTINGS, matching neon scroll bars everywhere.

### Widget
Restyled to the same HUD language (chamfered glass panel, gradient edge, pill command bar, new quick buttons). Orb / Mini / Bar types and the finance quick buttons still work.

### New customization (Settings > Appearance, Profile, Assistant, Sounds)
* **Reactor Lab** - live preview, 10 reactor designs, state tester, ring count / style / direction, emblem, beam, platform, particles, orbits, network, reaction strength, size, speed, glow, colours.
* **Effects** - scanlines, energy flow, neon strength, corner cut, parallax, UI sounds, boot animation, glass panels, background grid.
* **Home Screen** - show/hide each section (tasks, schedule, tiles, chips, quote, plate, decor, panels).
* **Layout** - sidebar mode, right column panels, which feature cards are shown.
* **Profile** - your name, badge and ask-bar text. (The name on Home is pre-set to "Hashik" to match the design - change it here.)
* **Sounds** (in Voice & Audio) - soft interface clicks and a done-chime, off by default, with a test button.
* 10 presets (Hologram Blue, Violet Nebula, Neon Cyberpunk, Mark VII, Emerald Ops, Arctic Ice, Gold Standard, Amber Terminal, Ghost Mono, Daylight), second accent colour, backgrounds (Soft glow, Nebula, Aurora, Tech grid, Starfield, Scanlines, Flat).

### Shortcuts
`Esc` back / exit dialog, `Ctrl+K` search settings, `Ctrl+,` Settings, `Ctrl+Shift+W` widget.

## Files
New: `friday_hud.css`, `friday_ui8.js` (home + shell), `friday_hub8.js` (Settings & Features). Updated: `index.html`, `widget.html`, `friday_theme.js`, `friday_settings.js`, `friday_chat5.js` (placeholder text only), `main.js` (one small block so Quick Actions > Record can capture the screen).

## Notes
* The reference image spelled "Setings"; the app uses "Settings".
* Screen recording needs the screen-capture permission of your OS.
* Tested in a browser harness with a mock backend (about 100 click-through checks, 0 console errors, 1280x720 up to 1920x1080, all presets). Real microphone / camera / screen capture, the floating widget window and window zoom run only inside Electron.
