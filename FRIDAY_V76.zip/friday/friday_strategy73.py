"""FRIDAY 7.3 Adaptive strategy layer  (upgrade 01 - adaptive intelligence engine).

Sits ON TOP of friday_router7 (which already scores models on capability, reliability, latency and cost).  It adds what router7 does not do:

    select()        one decision per request: which HANDLER (local / model / mission / computer-use / approval gate), which route and model order,
                    and which VERIFICATION strategy fits - arithmetic check, critic, evidence, tests, observe-act-verify, or explicit approval.
    call()          run a model request with a token budget (per request and per day), automatic fallback, latency tracking, and an
                    output-quality score; one bounded escalation to the next model when the answer scores badly.
    score_output()  cheap, deterministic quality score in [0, 1] (empty/error/refusal, length fit, arithmetic, code that does not parse).
    compare()       run a fixed task set against every available model and store the results, so routing follows MEASURED quality.
    order()         re-rank router7's candidate order with measured quality once a model has enough samples for that route.
    feedback()      user-approved routing corrections go to router7's tiny classifier (no model is retrained).

Nothing here touches the microphone, recognition or speech code.  Every call is wrapped: a failure falls back to router7 / the 6.0 router.
"""
from __future__ import annotations

import ast
import re
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS strat73_log(id INTEGER PRIMARY KEY, ts REAL, fp TEXT, route TEXT, model TEXT, ms INTEGER, tok_in INTEGER, tok_out INTEGER, quality REAL, ok INTEGER,
    escalated INTEGER DEFAULT 0, note TEXT);
CREATE INDEX IF NOT EXISTS ix_strat73_route ON strat73_log(route, model);
CREATE TABLE IF NOT EXISTS strat73_compare(id INTEGER PRIMARY KEY, ts REAL, run TEXT, route TEXT, model TEXT, case_id TEXT, ms INTEGER, quality REAL, ok INTEGER);
""")

for _k, _v in (("token_budget_request", ("6000", "most estimated tokens (prompt + answer) one request may use")),
               ("token_budget_day", ("400000", "most estimated model tokens per day before FRIDAY only uses local handlers and cheap routes")),
               ("quality_escalate_below", ("0.45", "answer quality score (0-1) below which the next model is tried once")),
               ("strategy_min_samples", ("5", "measured calls a model needs on a route before measured quality changes the routing order"))):
    K.SETTINGS.setdefault(_k, _v)

# ------------------------------------------------------------------ request kinds
_VISION = re.compile(r"\b(screenshot|on (?:my|the) screen|this (?:image|picture|photo|pic)|what do you see|look at (?:this|the)|camera|describe (?:the|this) (?:image|screen|photo)|read (?:this|the) (?:image|screen)|ocr)\b", re.I)
_DESKTOP = re.compile(r"\b(open|launch|close|minimi[sz]e|maximi[sz]e|click|double[- ]click|type|press|scroll|switch to|go to|drag|select)\b.{0,40}\b(app|window|tab|button|menu|folder|file|chrome|browser|notepad|settings|desktop|screen)\b|^(?:open|launch|close|minimi[sz]e)\s+\w+", re.I)
_HIGH_IMPACT = re.compile(r"\b(delete|erase|wipe|format|uninstall|remove all|overwrite|send (?:an? |the |my )?(?:e-?mail|message|whatsapp|text|sms|dm)|e-?mail (?:him|her|them|my|the)|message (?:him|her|them)|post (?:this|it) (?:on|to)|tweet|buy|purchase|order (?:a|an|the|some|my|me|\d+)\b|pay (?:for|my|the|him|her|them|rs|\d|\$)|transfer (?:money|funds|\$|rs|\d)|wire (?:money|funds)|checkout|check out and pay|subscribe|cancel (?:my|the) (?:subscription|account)|book (?:a|the) (?:ticket|flight|hotel))", re.I)
_INFO_QUESTION = re.compile(r"^\s*(?:what|what's|why|who|which|explain|define|tell me about|how does|how do)\b", re.I)
_MISSION = re.compile(r"\b(end to end|implement it|run (?:the )?tests?|fix (?:the )?failures|give me the finished|finished project|build (?:and|then)|research .{3,80}(?:implement|build|write|save|cost)|then\b.+\bthen\b)", re.I)
_CURRENT = re.compile(r"\b(latest|news|today|current(?:ly)?|right now|this week|price of|who is the (?:current )?|release date|score|weather)\b", re.I)

VERIFY = ("none", "arithmetic", "critic", "evidence", "tests", "observe_act_verify", "approval")


def kind_of(text: str, has_attachments: bool = False, has_image: bool = False) -> Dict:
    """Request kind with the signals that decided it. Order matters: safety (approval) first, then capability."""
    t = (text or "").strip()
    sig: List[str] = []
    try:
        import friday_router7 as R
        rc = R.classify(t, has_attachments)
    except Exception:
        rc = {"route": "general", "confidence": 0.3, "scores": {}}
    route = rc["route"]
    if has_image or _VISION.search(t):
        kind = "vision"
        sig.append("image/screen wording")
    elif _HIGH_IMPACT.search(t) and not _INFO_QUESTION.match(t):
        kind = "high_impact"
        sig.append("consequential action wording")
    elif route == "instant":
        kind = "deterministic"
        sig.append("exact local answer exists")
    elif route == "sensitive":
        kind = "sensitive"
        sig.append("private data wording")
    elif _MISSION.search(t) or len(t.split()) >= 18 and len(re.findall(r"\b(?:research|implement|build|test|fix|save|compare|cost|write|verify)\b", t, re.I)) >= 3:
        kind = "mission"
        sig.append("several dependent steps")
    elif _DESKTOP.search(t) and route != "code":
        kind = "computer_use"
        sig.append("interface action wording")
    elif route == "code":
        kind = "code"
    elif route in ("reasoning", "frontier"):
        kind = "reasoning"
    elif route == "research" or _CURRENT.search(t):
        kind = "research"
        sig.append("needs current information")
    else:
        kind = "chat"
    return {"kind": kind, "route": route, "confidence": rc.get("confidence", 0.3), "signals": sig}


_PLAN = {
    #  kind            handler       route default  verification
    "deterministic": ("local",       "instant",     "arithmetic"),
    "chat":          ("model",       "general",     "none"),
    "reasoning":     ("model",       "reasoning",   "critic"),
    "code":          ("model",       "code",        "tests"),
    "vision":        ("model",       "general",     "observe_act_verify"),
    "research":      ("research",    "research",    "evidence"),
    "computer_use":  ("computer",    "general",     "observe_act_verify"),
    "mission":       ("mission",     "reasoning",   "critic"),
    "high_impact":   ("approval",    "general",     "approval"),
    "sensitive":     ("model",       "sensitive",   "critic"),
}


def select(text: str, context: Optional[Dict] = None) -> Dict:
    """Decide handler + model order + verification + budget for one request. Pure routing: calls no model."""
    ctx = context or {}
    k = kind_of(text, bool(ctx.get("attachments")), bool(ctx.get("image")))
    handler, route, verify = _PLAN[k["kind"]]
    if k["kind"] in ("reasoning", "code", "sensitive", "research") and k["route"] in ("general", "code", "reasoning", "research", "frontier", "sensitive"):
        route = k["route"] if k["route"] != "general" else route
    order: List[Tuple[str, str]] = []
    reason = ""
    private = k["kind"] == "sensitive"
    blocked = False
    if handler in ("model", "research", "mission") and route != "instant":
        try:
            import friday_router7 as R
            d = R.decide(text, tier_hint="deep" if k["kind"] in ("reasoning",) else None)
            route = d["route"] if d["route"] != "instant" else route
            order = list(d.get("order") or [])
            reason = d.get("reason", "")
            private = private or bool(d.get("private"))
            blocked = bool(d.get("blocked"))
        except Exception as exc:
            C.log(f"strategy73 router7 decide failed, using standard router: {exc}", "recovery")
        order = reorder(route, order)
    approval = handler == "approval" or (k["kind"] == "computer_use" and bool(_HIGH_IMPACT.search(text or "")) and not _INFO_QUESTION.match(text or ""))
    return {"kind": k["kind"], "handler": handler, "route": route, "order": order, "verify": verify, "private": private, "blocked": blocked,
            "approval_required": approval, "deterministic": handler == "local", "signals": k["signals"], "confidence": k["confidence"],
            "budget_tokens": request_budget(), "reason": reason or f"{k['kind']} request -> {handler} handler, {verify} verification"}


# ------------------------------------------------------------------ budget
def est_tokens(text: str) -> int:
    return max(1, int(len(text or "") / 3.6))


def request_budget() -> int:
    try:
        return int(float(K.cfg_get("token_budget_request")))
    except Exception:
        return 6000


def tokens_today() -> int:
    try:
        r = C.q("SELECT COALESCE(SUM(tok_in+tok_out),0) n FROM strat73_log WHERE ts>?", (time.time() - 86400,))
        return int(r[0]["n"] or 0)
    except Exception:
        return 0


def budget_left() -> int:
    try:
        cap = int(float(K.cfg_get("token_budget_day")))
    except Exception:
        cap = 400000
    return max(0, cap - tokens_today())


# ------------------------------------------------------------------ quality
_ERRORISH = re.compile(r"^\s*(?:error|exception|traceback|sorry,? (?:i )?(?:can'?t|cannot|couldn'?t)|i (?:can'?t|cannot|am unable to)|as an ai|unable to (?:connect|process))", re.I)


def score_output(route: str, prompt: str, output: str) -> Dict:
    """Deterministic quality estimate. It cannot prove an answer is RIGHT; it catches the failures that are cheap to catch."""
    out = (output or "").strip()
    notes: List[str] = []
    if not out:
        return {"score": 0.0, "notes": ["empty answer"]}
    score = 0.75
    if _ERRORISH.search(out):
        score -= 0.4
        notes.append("looks like an error or refusal")
    words = len(out.split())
    asked = len((prompt or "").split())
    if route in ("reasoning", "frontier") and words < 12 and asked > 12:
        score -= 0.25
        notes.append("too short for a reasoning question")
    if route in ("general", "instant") and words > 400 and asked < 25:
        score -= 0.1
        notes.append("long for a quick question")
    if route == "code":
        blocks = re.findall(r"```(?:python|py)?\n(.*?)```", out, re.S)
        for b in blocks:
            try:
                ast.parse(b)
            except SyntaxError:
                if re.search(r"^\s*(def |class |import |from )", b, re.M):
                    score -= 0.35
                    notes.append("python code block does not parse")
                    break
        if not blocks and re.match(r"\s*(def |class |import |from )", out):
            try:
                ast.parse(out)
            except SyntaxError:
                score -= 0.35
                notes.append("python code does not parse")
        elif not blocks and re.search(r"\b(write|implement|function|script)\b", prompt or "", re.I):
            score -= 0.15
            notes.append("no code block in a coding answer")
    try:
        import friday_critic7 as CR
        rev = CR.review(out, allow_model=False)
        if not rev.get("ok", True):
            score -= 0.3
            notes.append("deterministic check: " + str((rev.get("issues") or [{}])[0].get("what", "problem"))[:80])
    except Exception:
        pass
    return {"score": round(max(0.0, min(1.0, score)), 2), "notes": notes}


# ------------------------------------------------------------------ measured routing
def measured(route: str, days: float = 14.0) -> Dict[str, Dict]:
    """model -> {n, quality, ok, ms} from real calls AND comparison runs on this route."""
    out: Dict[str, Dict] = {}
    cut = time.time() - days * 86400
    try:
        rows = C.q("SELECT model, COUNT(*) n, AVG(quality) quality, AVG(ok) ok, AVG(ms) ms FROM strat73_log WHERE route=? AND ts>? GROUP BY model", (route, cut))
        rows2 = C.q("SELECT model, COUNT(*) n, AVG(quality) quality, AVG(ok) ok, AVG(ms) ms FROM strat73_compare WHERE route=? AND ts>? GROUP BY model", (route, cut))
    except Exception:
        return out
    for r in list(rows) + list(rows2):
        m = r["model"] or ""
        n = int(r["n"] or 0)
        cur = out.setdefault(m, {"n": 0, "quality": 0.0, "ok": 0.0, "ms": 0.0})
        tot = cur["n"] + n
        if tot:
            for f in ("quality", "ok", "ms"):
                cur[f] = (cur[f] * cur["n"] + float(r[f] or 0) * n) / tot
        cur["n"] = tot
    return out


def reorder(route: str, order: List[Tuple[str, str]]) -> List[Tuple[str, str]]:
    """Router7 gives the capability/latency/cost order; once a model has enough measured samples on this route, measured quality x reliability decides among the
    models router7 already approved (it never adds a model router7 rejected, so private routes stay local-only)."""
    try:
        need = int(float(K.cfg_get("strategy_min_samples")))
    except Exception:
        need = 5
    m = measured(route)
    keyed = [(f"{p}:{t}", (p, t)) for p, t in order]
    if not keyed or not any(m.get(k, {}).get("n", 0) >= need for k, _ in keyed):
        return order

    def rank(item):
        i, (k, _) = item
        st = m.get(k)
        if not st or st["n"] < need:
            return (1, 0.0, i)                        # unmeasured models keep router7's position, after proven ones
        return (0, -(st["quality"] * 0.7 + st["ok"] * 0.3), i)
    return [keyed[i][1] for i, _ in sorted(enumerate(keyed), key=rank)]


def _log(fp: str, route: str, model: str, ms: int, tin: int, tout: int, quality: float, ok: bool, escalated: bool = False, note: str = ""):
    try:
        C.x("INSERT INTO strat73_log(ts,fp,route,model,ms,tok_in,tok_out,quality,ok,escalated,note) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (time.time(), fp, route, model, ms, tin, tout, quality, int(ok), int(escalated), note[:120]))
    except Exception:
        pass


Caller = Callable[[str, str, str], str]          # (provider, tier, prompt) -> text


def _default_caller(provider: str, tier: str, prompt: str) -> str:
    import friday_perf6 as P
    import friday_router7 as R
    if provider == "gemini":
        return P.call(prompt, tier=tier)
    return R._call_provider(provider, prompt, tier)


def call(prompt: str, *, strategy: Optional[Dict] = None, caller: Optional[Caller] = None, max_models: int = 3, context: Optional[Dict] = None) -> Dict:
    """Run one model request. Never raises. Returns {text, ok, model, route, quality, ms, tokens, tried, escalated, note}."""
    t0 = time.time()
    st = strategy or select(prompt, context)
    fp = C.fingerprint(prompt)
    res = {"text": "", "ok": False, "model": None, "route": st["route"], "quality": 0.0, "ms": 0, "tokens": 0, "tried": [], "escalated": False, "note": ""}
    if st.get("blocked"):
        res["note"] = "private request and no local model - not sent to the cloud"
        return res
    cost_in = est_tokens(prompt)
    if cost_in > st["budget_tokens"]:
        res["note"] = f"request is about {cost_in} tokens, over the per-request limit of {st['budget_tokens']}"
        return res
    if budget_left() < cost_in and not st.get("private"):
        res["note"] = "daily token budget used up - only local handlers are available until it resets"
        return res
    order = st.get("order") or []
    use = caller or _default_caller
    if not order:
        order = [("gemini", "fast")] if not st.get("private") else []
    try:
        floor = float(K.cfg_get("quality_escalate_below"))
    except Exception:
        floor = 0.45
    best: Optional[Dict] = None
    for i, (prov, tier) in enumerate(order[:max_models]):
        name = f"{prov}:{tier}"
        s0 = time.time()
        try:
            txt = use(prov, tier, prompt) or ""
        except Exception as exc:
            txt, res["note"] = "", f"{name} failed: {type(exc).__name__}"
        ms = int((time.time() - s0) * 1000)
        q = score_output(st["route"], prompt, txt)
        tout = est_tokens(txt) if txt else 0
        ok = bool(txt.strip())
        _log(fp, st["route"], name, ms, cost_in, tout, q["score"], ok, escalated=i > 0, note="; ".join(q["notes"]))
        res["tried"].append({"model": name, "ms": ms, "quality": q["score"], "ok": ok})
        cand = {"text": txt, "ok": ok, "model": name, "quality": q["score"], "ms": ms, "tokens": cost_in + tout}
        if ok and (best is None or cand["quality"] > best["quality"]):
            best = cand
        if ok and q["score"] >= floor:
            break
        res["escalated"] = i + 1 < len(order[:max_models])
        if budget_left() < cost_in:
            res["note"] = "stopped escalating: token budget"
            break
    if best:
        res.update(best)
    res["ms"] = int((time.time() - t0) * 1000)
    res["escalated"] = len(res["tried"]) > 1
    return res


# ------------------------------------------------------------------ model comparison
COMPARE_SET: List[Dict] = [
    {"id": "c1", "route": "general", "prompt": "In one sentence, what is compound interest?", "must": [r"interest"], "max_words": 60},
    {"id": "c2", "route": "reasoning", "prompt": "A shop sells 3 pens for 45 rupees. How much do 7 pens cost? Show the working in two lines.", "must": [r"105"], "max_words": 120},
    {"id": "c3", "route": "reasoning", "prompt": "If a budget is 28000 rupees and 35 percent goes to rent, how much remains? Give the number.", "must": [r"18[ ,]?200"], "max_words": 120},
    {"id": "c4", "route": "code", "prompt": "Write a Python function is_even(n) that returns True for even integers. Code only.", "must": [r"def\s+is_even"], "python": True, "max_words": 80},
    {"id": "c5", "route": "code", "prompt": "Write a Python function that reverses a string. Code only.", "must": [r"def\s+\w+\(", r"return"], "python": True, "max_words": 80},
    {"id": "c6", "route": "general", "prompt": "Reply with exactly the single word: ready", "must": [r"\bready\b"], "max_words": 6},
]


def _grade(case: Dict, text: str) -> float:
    t = text or ""
    if not t.strip():
        return 0.0
    hit = sum(1 for p in case.get("must", []) if re.search(p, t, re.I))
    s = hit / max(1, len(case.get("must", [])))
    if len(t.split()) > case.get("max_words", 10_000):
        s -= 0.2
    if case.get("python"):
        code = "\n".join(re.findall(r"```(?:python|py)?\n(.*?)```", t, re.S)) or t
        try:
            ast.parse(code)
        except SyntaxError:
            s -= 0.5
    return round(max(0.0, min(1.0, s)), 2)


def compare(models: Optional[List[Tuple[str, str]]] = None, cases: Optional[List[Dict]] = None, caller: Optional[Caller] = None) -> Dict:
    """Same tasks to every model. Stores results (they feed reorder()) and returns a ranking per route. Uses real providers unless `caller` is given."""
    cases = cases or COMPARE_SET
    use = caller or _default_caller
    if models is None:
        try:
            import friday_router7 as R
            models = [(c["provider"], c["tier"]) for c in R.candidates("general") if c["available"]]
        except Exception:
            models = []
    run = K.new_id("CMP")
    for prov, tier in models:
        for cs in cases:
            s0 = time.time()
            try:
                txt = use(prov, tier, cs["prompt"]) or ""
            except Exception:
                txt = ""
            ms = int((time.time() - s0) * 1000)
            g = _grade(cs, txt)
            try:
                C.x("INSERT INTO strat73_compare(ts,run,route,model,case_id,ms,quality,ok) VALUES(?,?,?,?,?,?,?,?)", (time.time(), run, cs["route"], f"{prov}:{tier}", cs["id"], ms, g, int(bool(txt.strip()))))
            except Exception:
                pass
    table: Dict[str, List[Dict]] = {}
    for r in C.q("SELECT route, model, COUNT(*) n, AVG(quality) q, AVG(ms) ms FROM strat73_compare WHERE run=? GROUP BY route, model", (run,)):
        table.setdefault(r["route"], []).append({"model": r["model"], "quality": round(r["q"], 2), "avg_ms": int(r["ms"]), "cases": r["n"]})
    for rows in table.values():
        rows.sort(key=lambda x: (-x["quality"], x["avg_ms"]))
    return {"run": run, "models": [f"{p}:{t}" for p, t in models], "ranking": table}


def feedback(text: str, correct_route: str, strength: float = 0.5) -> bool:
    """User-approved routing correction. Updates router7's tiny classifier weights; nothing is retrained."""
    try:
        import friday_router7 as R
        R.feedback(text, correct_route, strength)
        return correct_route in R.ROUTES
    except Exception:
        return False


def stats() -> Dict:
    rows = C.q("SELECT route, model, COUNT(*) n, AVG(ms) ms, AVG(quality) q, AVG(ok) ok FROM strat73_log GROUP BY route, model ORDER BY n DESC LIMIT 20")
    return {"tokens_today": tokens_today(), "budget_left": budget_left(),
            "routes": [{"route": r["route"], "model": r["model"], "calls": r["n"], "avg_ms": int(r["ms"] or 0), "quality": round(r["q"] or 0, 2), "success": round(r["ok"] or 0, 2)} for r in rows]}


def handle(command: str) -> Optional[str]:
    low = K.norm_cmd(command)
    m = re.match(r"^(?:which|what) strategy (?:would|will) you use (?:for|on) (.+)$|^explain (?:the )?strategy (?:for|of) (.+)$", low)
    if m:
        s = select(m.group(1) or m.group(2))
        return f"I'd treat that as {s['kind'].replace('_', ' ')}: {s['reason']}" + (" I'd ask your approval before doing it." if s["approval_required"] else "")
    if re.match(r"^(?:model|routing) (?:quality|performance|comparison) ?(?:report)?$|^which models? (?:work|works|perform) best$", low):
        st = stats()
        if not st["routes"]:
            return "I haven't measured any model calls yet. Once I've answered a few questions I'll show which models perform best per route."
        return "; ".join(f"{r['route']}: {r['model']} quality {r['quality']:.2f}, {r['avg_ms']} ms over {r['calls']} calls" for r in st["routes"][:5])
    if re.match(r"^(?:token|model) (?:budget|usage)$|^how many tokens (?:have i|did you) use(?:d)? today$", low):
        return f"About {tokens_today():,} estimated model tokens used in the last day; about {budget_left():,} left in today's budget."
    return None
