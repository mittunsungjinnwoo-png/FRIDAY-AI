import json, tempfile
from pathlib import Path
import friday_cognitive_architecture as c

p=c.cognitive_profile('research the latest information, compare sources, create a PDF report, and verify it')
assert p['planning_depth'] >= 3
contract=c.build_cognitive_contract('research and create a report', {'steps':['web_research','document_creation']})
assert 'provenance' in contract['phases'] and 'verify' in contract['phases']
assert c.adaptive_recommendation('x', {'ambiguity':0.1,'verification_depth':4})['strategy']=='evidence-first'
assert c.resource_policy(p)['max_parallel'] <= 2
print('V2041_COGNITIVE_ARCHITECTURE=PASS')
