"""
FRIDAY V2036 NOTES DIAGRAM ENGINE
---------------------------------
Draws REAL labelled vector diagrams (arrows, cycles, concept maps, energy-level
boxes, molecule geometry, orbital lobes) with reportlab.graphics so the study
notes contain actual pictures instead of a row of text boxes.

Public API
    build_diagram_drawing(spec: dict, width: float) -> Drawing | None

`spec["kind"]` selects the drawing:
    flow        nodes=[{label,detail}]                      numbered boxes joined by arrows
    cycle       nodes=[{label,detail}]                      boxes on a ring joined by arrows
    hub         center="Topic", nodes=[{label,detail}]      concept map, spokes from the centre
    energy      columns=[{title, levels:[{label,energy,boxes:[e,e,..]}]}], transitions=[str]
                                                            orbital / energy-level box diagram
    molecule3d  shape=tetrahedral|trigonal_planar|linear, center="C",
                substituents=["H",..], angle_label="109.5°"  wedge/dash molecule drawing
    shapes      orbitals=["s","px","py","pz"]                s sphere + p dumbbell orbital shapes
    lobes       angles=[deg,..], back=[idx,..], labels=[..], center="C",
                p_lobes=[{angle,label}]                     hybrid-orbital lobe picture

Unknown / malformed specs return None so the caller can fall back to its
text-only rendering. Only Helvetica (always available) is used, and text is
folded to Latin-1 so a missing Unicode font can never produce black boxes.
"""
from __future__ import annotations

import math
import re

from reportlab.graphics.shapes import (
    Drawing, Group, Line, Rect, String, Polygon, Circle, Ellipse,
)
from reportlab.lib import colors
from reportlab.lib.utils import simpleSplit

# Same notebook palette as friday_notes_engine.py (kept local to avoid a circular import).
PAPER = colors.HexColor("#FBF7EE")
INK = colors.HexColor("#28262D")
BLUE = colors.HexColor("#D7E8F6")
BLUE_DARK = colors.HexColor("#3F6E9E")
PURPLE_LIGHT = colors.HexColor("#E9D8F3")
PURPLE = colors.HexColor("#8A5DB1")
PURPLE_DARK = colors.HexColor("#5C3B7A")
PINK = colors.HexColor("#F1D0E0")
PINK_DARK = colors.HexColor("#9A4F72")
YELLOW = colors.HexColor("#F6E9B6")
MUTED = colors.HexColor("#6B6570")
WHITE = colors.white

_FILLS = [BLUE, PURPLE_LIGHT, PINK, YELLOW]
_EDGES = [BLUE_DARK, PURPLE, PINK_DARK, PINK_DARK]

_FOLD = {
    "\u2080": "0", "\u2081": "1", "\u2082": "2", "\u2083": "3", "\u2084": "4",
    "\u2085": "5", "\u2086": "6", "\u2087": "7", "\u2088": "8", "\u2089": "9",
    "\u2070": "0", "\u00b9": "1", "\u00b2": "2", "\u00b3": "3", "\u2074": "4",
    "\u2075": "5", "\u2076": "6", "\u2077": "7", "\u2078": "8", "\u2079": "9",
    "\u2192": "->", "\u2190": "<-", "\u2194": "<->", "\u21cc": "<=>",
    "\u03c3": "sigma", "\u03c0": "pi", "\u03bb": "lambda", "\u03bc": "mu",
    "\u0394": "Delta", "\u03b4": "delta", "\u03b8": "theta", "\u03b1": "alpha",
    "\u03b2": "beta", "\u2013": "-", "\u2014": "-", "\u2212": "-", "\u2018": "'",
    "\u2019": "'", "\u201c": '"', "\u201d": '"', "\u2026": "...", "\u2022": "-",
    "\u00d7": "x", "\u2248": "~", "\u2264": "<=", "\u2265": ">=", "\u221a": "sqrt",
}


def _t(text) -> str:
    """Fold arbitrary model text to something Helvetica can always print."""
    s = "" if text is None else str(text)
    for a, b in _FOLD.items():
        s = s.replace(a, b)
    s = re.sub(r"\s+", " ", s).strip()
    return s.encode("latin-1", "replace").decode("latin-1")


def _nodes(spec, limit=9):
    out = []
    for n in (spec.get("nodes") or spec.get("parts") or [])[:limit]:
        if isinstance(n, dict):
            label = _t(n.get("label") or n.get("title") or n.get("name") or "")
            detail = _t(n.get("detail") or n.get("explanation") or n.get("text") or "")
        else:
            label, detail = _t(n), ""
        if label or detail:
            out.append((label or "Step", detail))
    return out


def _wrap(text, font, size, max_w, max_lines):
    if not text:
        return []
    lines = simpleSplit(text, font, size, max_w)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        last = lines[-1]
        while last and _w(last + "...", font, size) > max_w:
            last = last[:-1]
        lines[-1] = last.rstrip() + "..."
    return lines


def _w(text, font, size):
    from reportlab.pdfbase.pdfmetrics import stringWidth
    return stringWidth(text, font, size)


def _arrow(g, x1, y1, x2, y2, color=PURPLE_DARK, width=1.3, head=5.0):
    """Line with a filled triangular head at (x2, y2)."""
    g.add(Line(x1, y1, x2, y2, strokeColor=color, strokeWidth=width))
    ang = math.atan2(y2 - y1, x2 - x1)
    a1, a2 = ang + math.radians(155), ang - math.radians(155)
    g.add(Polygon(
        [x2, y2, x2 + head * 1.6 * math.cos(a1), y2 + head * 1.6 * math.sin(a1),
         x2 + head * 1.6 * math.cos(a2), y2 + head * 1.6 * math.sin(a2)],
        fillColor=color, strokeColor=color, strokeWidth=0.4))


def _box(g, x, y, w, h, fill, edge, label, detail, num=None, label_size=8.2, detail_size=6.8):
    """Rounded box (x, y = bottom-left) with a bold label and wrapped detail."""
    g.add(Rect(x, y, w, h, rx=5, ry=5, fillColor=fill, strokeColor=edge, strokeWidth=0.9))
    pad = 5
    text_w = w - 2 * pad
    ty = y + h - pad - label_size
    lab_lines = _wrap(label, "Helvetica-Bold", label_size, text_w - (10 if num else 0), 2)
    for i, ln in enumerate(lab_lines):
        g.add(String(x + pad + (10 if num and i == 0 else 0), ty, ln, fontName="Helvetica-Bold",
                     fontSize=label_size, fillColor=INK))
        ty -= label_size + 1.5
    if num is not None:
        g.add(Circle(x + pad + 3.5, y + h - pad - 3.5, 4.6, fillColor=edge, strokeColor=edge))
        g.add(String(x + pad + 3.5, y + h - pad - 6.0, str(num), fontName="Helvetica-Bold",
                     fontSize=6.4, fillColor=WHITE, textAnchor="middle"))
    for ln in _wrap(detail, "Helvetica", detail_size, text_w, 5):
        ty -= 0.5
        g.add(String(x + pad, ty, ln, fontName="Helvetica", fontSize=detail_size, fillColor=INK))
        ty -= detail_size + 1.6


def _box_height(label, detail, w, label_size=8.2, detail_size=6.8, num=False):
    pad = 5
    text_w = w - 2 * pad
    nl = len(_wrap(label, "Helvetica-Bold", label_size, text_w - (10 if num else 0), 2)) or 1
    nd = len(_wrap(detail, "Helvetica", detail_size, text_w, 5))
    return pad * 2 + nl * (label_size + 1.5) + nd * (detail_size + 1.6) + (2 if nd else 0)


def _edge_point(cx, cy, hw, hh, dx, dy):
    """Where a ray from a box centre in direction (dx, dy) leaves the box."""
    if dx == 0 and dy == 0:
        return cx, cy
    tx = hw / abs(dx) if dx else float("inf")
    ty = hh / abs(dy) if dy else float("inf")
    t = min(tx, ty)
    return cx + dx * t, cy + dy * t


# --------------------------------------------------------------------------- flow
def _flow(spec, width):
    nodes = _nodes(spec, 9)
    if len(nodes) < 2:
        return None
    n = len(nodes)
    per_row = 2 if n == 4 else min(3, n)
    gap = 20
    box_w = (width - 8 - (per_row - 1) * gap) / per_row
    rows = [nodes[i:i + per_row] for i in range(0, n, per_row)]
    row_h = [max(_box_height(l, d, box_w, num=True) for l, d in r) for r in rows]
    row_gap = 20
    total_h = sum(row_h) + row_gap * (len(rows) - 1) + 8
    d = Drawing(width, total_h)
    g = Group()
    y_top = total_h - 4
    idx = 0
    centers = []
    for r, row in enumerate(rows):
        y = y_top - row_h[r]
        row_centers = []
        used_w = len(row) * box_w + (len(row) - 1) * gap
        x0 = (width - used_w) / 2
        for c, (label, detail) in enumerate(row):
            x = x0 + c * (box_w + gap)
            k = idx % 4
            _box(g, x, y, box_w, row_h[r], _FILLS[k], _EDGES[k], label, detail, num=idx + 1)
            row_centers.append((x, y, box_w, row_h[r]))
            if c > 0:
                px, py, pw, ph = row_centers[c - 1]
                _arrow(g, px + pw + 1, y + row_h[r] / 2, x - 1, y + row_h[r] / 2)
            idx += 1
        centers.append(row_centers)
        y_top = y - row_gap
    for r in range(len(centers) - 1):
        lx, ly, lw, lh = centers[r][-1]
        fx, fy, fw, fh = centers[r + 1][0]
        mid_y = ly - row_gap / 2
        g.add(Line(lx + lw / 2, ly, lx + lw / 2, mid_y, strokeColor=PURPLE_DARK, strokeWidth=1.3))
        g.add(Line(lx + lw / 2, mid_y, fx + fw / 2, mid_y, strokeColor=PURPLE_DARK, strokeWidth=1.3))
        _arrow(g, fx + fw / 2, mid_y, fx + fw / 2, fy + fh + 1)
    d.add(g)
    return d


# --------------------------------------------------------------------------- cycle / hub
def _ring(spec, width, hub):
    nodes = _nodes(spec, 8)
    if len(nodes) < 3 and not (hub and len(nodes) >= 2):
        return None
    n = len(nodes)
    box_w = min(112, max(78, width / 3.3))
    heights = [_box_height(l, dt, box_w) for l, dt in nodes]
    box_h = max(heights)
    H = max(230, box_h * 3.1)
    d = Drawing(width, H)
    g = Group()
    cx, cy = width / 2, H / 2
    rx = width / 2 - box_w / 2 - 6
    ry = H / 2 - box_h / 2 - 6
    centres = []
    for i in range(n):
        ang = math.radians(90 - i * 360.0 / n)
        centres.append((cx + rx * math.cos(ang), cy + ry * math.sin(ang)))
    hw, hh = box_w / 2, box_h / 2
    if hub:
        title = _t(spec.get("center") or spec.get("title") or "")
        ch = 26
        cw = min(120, max(70, _w(title, "Helvetica-Bold", 9) + 22))
        for (bx, by) in centres:
            dx, dy = bx - cx, by - cy
            sx, sy = _edge_point(cx, cy, cw / 2, ch / 2, dx, dy)
            ex, ey = _edge_point(bx, by, hw, hh, -dx, -dy)
            _arrow(g, sx, sy, ex, ey, color=PURPLE, width=1.1, head=4)
    else:
        for i in range(n):
            ax, ay = centres[i]
            bx, by = centres[(i + 1) % n]
            dx, dy = bx - ax, by - ay
            sx, sy = _edge_point(ax, ay, hw + 2, hh + 2, dx, dy)
            ex, ey = _edge_point(bx, by, hw + 3, hh + 3, -dx, -dy)
            _arrow(g, sx, sy, ex, ey)
    for i, (label, detail) in enumerate(nodes):
        bx, by = centres[i]
        k = i % 4
        _box(g, bx - hw, by - hh, box_w, box_h, _FILLS[k], _EDGES[k], label, detail,
             num=None if hub else i + 1)
    if hub:
        g.add(Rect(cx - cw / 2, cy - ch / 2, cw, ch, rx=13, ry=13, fillColor=YELLOW,
                   strokeColor=PINK_DARK, strokeWidth=1.2))
        for j, ln in enumerate(_wrap(title, "Helvetica-Bold", 9, cw - 10, 2)):
            g.add(String(cx, cy + 2 - j * 10, ln, fontName="Helvetica-Bold", fontSize=9,
                         fillColor=INK, textAnchor="middle"))
    else:
        t = _t(spec.get("center") or "")
        if t:
            for j, ln in enumerate(_wrap(t, "Helvetica-Bold", 9, 110, 3)):
                g.add(String(cx, cy + 4 - j * 11, ln, fontName="Helvetica-Bold", fontSize=9,
                             fillColor=PURPLE_DARK, textAnchor="middle"))
    d.add(g)
    return d


# --------------------------------------------------------------------------- energy levels
def _electron(g, x, y, up=True, color=PURPLE_DARK):
    """Half-arrow style electron spin marker inside a 14pt orbital box."""
    if up:
        _arrow(g, x, y - 4.5, x, y + 4.5, color=color, width=1.1, head=2.6)
    else:
        _arrow(g, x, y + 4.5, x, y - 4.5, color=color, width=1.1, head=2.6)


def _energy(spec, width):
    cols = spec.get("columns")
    if not isinstance(cols, list) or not cols:
        return None
    cols = [c for c in cols if isinstance(c, dict) and c.get("levels")][:4]
    if not cols:
        return None
    H = 172
    left = 22
    d = Drawing(width, H)
    g = Group()
    base, top = 34, H - 16
    _arrow(g, 12, base - 6, 12, top, color=MUTED, width=1.0, head=3.5)
    g.add(String(6, top + 4, "Energy", fontName="Helvetica-Bold", fontSize=6.6, fillColor=MUTED))
    col_w = (width - left) / len(cols)
    trans = [ _t(x) for x in (spec.get("transitions") or []) ]
    all_e = [float(l.get("energy", 0)) for c in cols for l in c["levels"] if isinstance(l, dict)]
    emin, emax = (min(all_e), max(all_e)) if all_e else (0.0, 1.0)
    span = (emax - emin) or 1.0
    for ci, col in enumerate(cols):
        x0 = left + ci * col_w
        title = _t(col.get("title") or "")
        for j, ln in enumerate(_wrap(title, "Helvetica-Bold", 7.4, col_w - 14, 2)):
            g.add(String(x0 + col_w / 2 - 6, 20 - j * 8.5, ln, fontName="Helvetica-Bold",
                         fontSize=7.4, fillColor=PURPLE_DARK, textAnchor="middle"))
        for lv in col["levels"]:
            if not isinstance(lv, dict):
                continue
            boxes = lv.get("boxes") or []
            if not isinstance(boxes, list):
                boxes = []
            nb = max(1, len(boxes))
            bw = 15
            group_w = nb * bw
            gx = x0 + col_w / 2 - group_w / 2 + 6
            e = float(lv.get("energy", 0))
            gy = base + 4 + (e - emin) / span * (top - base - 30)
            for bi in range(nb):
                bx = gx + bi * bw
                g.add(Rect(bx, gy, bw, 14, fillColor=WHITE, strokeColor=BLUE_DARK, strokeWidth=1.0))
                ne = int(boxes[bi]) if bi < len(boxes) and str(boxes[bi]).lstrip("-").isdigit() else 0
                if ne >= 1:
                    _electron(g, bx + (4.5 if ne == 2 else bw / 2), gy + 7, True)
                if ne >= 2:
                    _electron(g, bx + bw - 4.5, gy + 7, False)
            g.add(String(gx - 4, gy + 3.5, _t(lv.get("label") or ""), fontName="Helvetica-Bold",
                         fontSize=8, fillColor=INK, textAnchor="end"))
        if ci < len(cols) - 1:
            ax1 = x0 + col_w - 6
            ax2 = x0 + col_w + 8
            ay = base + (top - base) / 2
            _arrow(g, ax1 - 14, ay, ax2 + 12, ay, color=PINK_DARK, width=1.6, head=4)
            if ci < len(trans):
                for j, ln in enumerate(_wrap(trans[ci], "Helvetica-Oblique", 6.6, 62, 3)):
                    g.add(String(ax1 + 4, ay + 8 + (len(_wrap(trans[ci], "Helvetica-Oblique", 6.6, 62, 3)) - 1 - j) * 8,
                                 ln, fontName="Helvetica-Oblique", fontSize=6.6, fillColor=PINK_DARK,
                                 textAnchor="middle"))
    d.add(g)
    return d


# --------------------------------------------------------------------------- molecule geometry
_GEOMS = {
    "tetrahedral": [(90, "plain"), (210, "plain"), (330, "wedge"), (30, "dash")],
    "trigonal_planar": [(90, "plain"), (210, "plain"), (330, "plain")],
    "linear": [(180, "plain"), (0, "plain")],
    "bent": [(215, "plain"), (325, "plain")],
    "pyramidal": [(90, "plain"), (215, "wedge"), (325, "dash")],
}


def _molecule(spec, width):
    shape = str(spec.get("shape") or "tetrahedral").lower().replace(" ", "_")
    if shape not in _GEOMS:
        shape = "tetrahedral"
    bonds = _GEOMS[shape]
    subs = [_t(x) for x in (spec.get("substituents") or [])] or ["H"] * len(bonds)
    while len(subs) < len(bonds):
        subs.append(subs[-1])
    center = _t(spec.get("center") or "C")
    angle_label = _t(spec.get("angle_label") or "")
    H = 200
    d = Drawing(width, H)
    g = Group()
    cx, cy = width / 2, H / 2 + 6
    L = 68
    if shape in ("linear",):
        L = 82
    ends = []
    for i, (ang, style) in enumerate(bonds):
        a = math.radians(ang)
        ex, ey = cx + L * math.cos(a), cy + L * math.sin(a)
        ends.append((ex, ey, a, style))
    for ex, ey, a, style in ends:
        if style == "plain":
            g.add(Line(cx, cy, ex, ey, strokeColor=INK, strokeWidth=2.0))
        elif style == "wedge":
            px, py = -math.sin(a), math.cos(a)
            w = 6.5
            g.add(Polygon([cx, cy, ex + px * w, ey + py * w, ex - px * w, ey - py * w],
                          fillColor=INK, strokeColor=INK, strokeWidth=0.6))
        else:  # dashed = pointing away from the viewer
            px, py = -math.sin(a), math.cos(a)
            for k in range(1, 8):
                t = k / 8.0
                w = 1.0 + 5.2 * t
                mx, my = cx + (ex - cx) * t, cy + (ey - cy) * t
                g.add(Line(mx - px * w, my - py * w, mx + px * w, my + py * w,
                           strokeColor=INK, strokeWidth=1.3))
    for (ex, ey, a, style), lab in zip(ends, subs):
        g.add(Circle(ex, ey, 11, fillColor=BLUE, strokeColor=BLUE_DARK, strokeWidth=1.1))
        g.add(String(ex, ey - 3.2, lab[:4], fontName="Helvetica-Bold", fontSize=8.5,
                     fillColor=INK, textAnchor="middle"))
    g.add(Circle(cx, cy, 14, fillColor=PINK, strokeColor=PINK_DARK, strokeWidth=1.3))
    g.add(String(cx, cy - 3.6, center[:4], fontName="Helvetica-Bold", fontSize=10,
                 fillColor=INK, textAnchor="middle"))
    if angle_label:
        g.add(String(width - 6, 12, angle_label, fontName="Helvetica-Bold", fontSize=8.4,
                     fillColor=PURPLE_DARK, textAnchor="end"))
    key_y = H - 12
    for txt, dx in (("solid line = in the plane of the page", 0),
                    ("solid wedge = towards you", 0), ("dashed wedge = away from you", 0)):
        if shape in ("linear", "trigonal_planar", "bent") and "wedge" in txt:
            continue
        g.add(String(6, key_y, txt, fontName="Helvetica-Oblique", fontSize=6.4, fillColor=MUTED))
        key_y -= 8.5
    d.add(g)
    return d


# --------------------------------------------------------------------------- orbital lobes
def _lobe(g, x, y, ang_deg, length, thick, fill, edge, dashed=False):
    """One teardrop-like hybrid lobe: big lobe pointing along ang_deg + tiny back lobe."""
    grp = Group()
    grp.add(Ellipse(length * 0.5, 0, length * 0.5, thick, fillColor=fill, strokeColor=edge,
                    strokeWidth=1.0, strokeDashArray=[3, 2] if dashed else None))
    grp.add(Ellipse(-length * 0.09, 0, length * 0.09, thick * 0.32, fillColor=PAPER,
                    strokeColor=edge, strokeWidth=0.8, strokeDashArray=[2, 2] if dashed else None))
    a = math.radians(ang_deg)
    grp.transform = (math.cos(a), math.sin(a), -math.sin(a), math.cos(a), x, y)
    g.add(grp)


def _lobes(spec, width):
    angles = spec.get("angles")
    if not isinstance(angles, list) or not angles:
        return None
    try:
        angles = [float(a) for a in angles][:6]
    except Exception:
        return None
    back = set(int(i) for i in (spec.get("back") or []) if str(i).isdigit())
    labels = [_t(x) for x in (spec.get("labels") or [])]
    H = 210
    d = Drawing(width, H)
    g = Group()
    cx, cy = width / 2, H / 2
    length = 74
    for i, ang in enumerate(angles):
        fill = PURPLE_LIGHT if i not in back else colors.HexColor("#F1E9F7")
        _lobe(g, cx, cy, ang, length, 17, fill, PURPLE, dashed=(i in back))
        a = math.radians(ang)
        if i < len(labels) and labels[i]:
            lx, ly = cx + (length + 12) * math.cos(a), cy + (length + 12) * math.sin(a)
            anchor = "start" if math.cos(a) > 0.3 else ("end" if math.cos(a) < -0.3 else "middle")
            g.add(String(lx, ly - 3, labels[i], fontName="Helvetica-Bold", fontSize=7.4,
                         fillColor=PURPLE_DARK, textAnchor=anchor))
    for p in (spec.get("p_lobes") or [])[:2]:
        if not isinstance(p, dict):
            continue
        try:
            pa = float(p.get("angle", 90))
        except Exception:
            pa = 90.0
        for sign in (0, 180):
            _lobe(g, cx, cy, pa + sign, 58, 13, BLUE, BLUE_DARK)
        a = math.radians(pa)
        g.add(String(cx + 66 * math.cos(a) + 4, cy + 66 * math.sin(a) - 2, _t(p.get("label") or "p"),
                     fontName="Helvetica-Bold", fontSize=7.4, fillColor=BLUE_DARK))
    g.add(Circle(cx, cy, 4.5, fillColor=PINK_DARK, strokeColor=PINK_DARK))
    ct = _t(spec.get("center") or "")
    if ct:
        g.add(String(cx + 7, cy - 14, ct, fontName="Helvetica-Bold", fontSize=8, fillColor=INK))
    d.add(g)
    return d


# --------------------------------------------------------------------------- s / p orbital shapes
def _shapes(spec, width):
    """Row of mini panels: s (sphere), px, py, pz (dumbbells along their own axis)."""
    wanted = [str(x).lower() for x in (spec.get("orbitals") or ["s", "px", "py", "pz"])][:4]
    if not wanted:
        return None
    H = 150
    d = Drawing(width, H)
    g = Group()
    pw = width / len(wanted)
    for i, name in enumerate(wanted):
        cx, cy = pw * i + pw / 2, H / 2 + 6
        # axes
        for (dx, dy, lab) in ((1, 0, "x"), (0, 1, "y")):
            _arrow(g, cx - dx * 44, cy - dy * 44, cx + dx * 46, cy + dy * 46, color=MUTED, width=0.7, head=2.4)
            g.add(String(cx + dx * 52 - 2, cy + dy * 50 - 3, lab, fontName="Helvetica-Oblique", fontSize=6.6, fillColor=MUTED))
        if name.startswith("s"):
            g.add(Circle(cx, cy, 30, fillColor=PURPLE_LIGHT, strokeColor=PURPLE, strokeWidth=1.1))
            g.add(Circle(cx, cy, 3, fillColor=PINK_DARK, strokeColor=PINK_DARK))
            cap = "s: spherical"
        else:
            axis = {"px": 0, "py": 90, "pz": 90}.get(name, 0)
            for sign, fill, edge in ((0, PURPLE_LIGHT, PURPLE), (180, BLUE, BLUE_DARK)):
                grp = Group()
                grp.add(Ellipse(19, 0, 19, 11, fillColor=fill, strokeColor=edge, strokeWidth=1.0))
                a = math.radians(axis + sign)
                grp.transform = (math.cos(a), math.sin(a), -math.sin(a), math.cos(a), cx, cy)
                g.add(grp)
            g.add(Circle(cx, cy, 2.6, fillColor=PINK_DARK, strokeColor=PINK_DARK))
            if name == "pz":
                g.add(String(cx + 10, cy - 30, "(z axis, shown vertical)", fontName="Helvetica-Oblique",
                             fontSize=5.6, fillColor=MUTED))
            cap = name.replace("p", "p") + ": dumbbell"
        g.add(String(cx, 12, _t(cap), fontName="Helvetica-Bold", fontSize=8, fillColor=PURPLE_DARK, textAnchor="middle"))
    g.add(String(6, H - 8, "Purple / blue = the two lobes (opposite wave-function sign). Nucleus = dot at the centre.",
                 fontName="Helvetica-Oblique", fontSize=6, fillColor=MUTED))
    d.add(g)
    return d


_KIND_ALIASES = {
    "process": "flow", "steps": "flow", "sequence": "flow", "timeline": "flow", "flowchart": "flow",
    "loop": "cycle", "circular": "cycle", "concept_map": "hub", "mindmap": "hub", "map": "hub",
    "orbital_energy": "energy", "energy_levels": "energy", "orbitals": "energy",
    "molecule": "molecule3d", "geometry": "molecule3d", "structure": "molecule3d",
    "hybrid_lobes": "lobes", "orbital_lobes": "lobes", "orbital_shapes": "shapes",
}


def build_diagram_drawing(spec, width):
    """Return a reportlab Drawing for `spec`, or None when it can't be drawn."""
    if not isinstance(spec, dict):
        return None
    kind = str(spec.get("kind") or spec.get("type") or "").strip().lower().replace(" ", "_")
    kind = _KIND_ALIASES.get(kind, kind)
    try:
        if kind == "energy":
            return _energy(spec, width)
        if kind == "molecule3d":
            return _molecule(spec, width)
        if kind == "lobes":
            return _lobes(spec, width)
        if kind == "shapes":
            return _shapes(spec, width)
        if kind == "cycle":
            return _ring(spec, width, hub=False)
        if kind == "hub":
            return _ring(spec, width, hub=True)
        # default / "flow" / unknown kind but has nodes
        return _flow(spec, width)
    except Exception:
        return None
