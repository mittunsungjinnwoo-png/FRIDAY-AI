"""FRIDAY 7.0 goal-driven task engine (roadmap #10).

Larger objectives that live across sessions: milestones, blockers, scheduled *approved* tasks, resume of interrupted work and honest progress.
The wording is "objective" so it never collides with the existing 6.0 reminders / goals commands.

    create(title, milestones, due)         new objective with ordered milestones
    run_next(oid)                          starts the next ready milestone as a verified mission (orchestrator)
    schedule(oid, idx, when_ts)            a milestone you approved to start by itself at a time
    tick()                                 called by the runtime loop: starts approved scheduled milestones that are due, surfaces blockers
    progress(oid)                          percent + what is done / next / blocked - computed from verified milestone states only
"""
from __future__ import annotations

import re
import time
from typing import Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS objectives7(oid TEXT PRIMARY KEY, title TEXT, created REAL, updated REAL, status TEXT DEFAULT 'active', due REAL, notes TEXT DEFAULT '', path TEXT DEFAULT '.');
CREATE TABLE IF NOT EXISTS milestones7(id INTEGER PRIMARY KEY, oid TEXT, idx INTEGER, text TEXT, status TEXT DEFAULT 'pending', jid TEXT DEFAULT '', due REAL, run_at REAL, approved INTEGER DEFAULT 0,
    evidence TEXT DEFAULT '', ts REAL);
CREATE TABLE IF NOT EXISTS blockers7(id INTEGER PRIMARY KEY, oid TEXT, idx INTEGER, text TEXT, ts REAL, resolved INTEGER DEFAULT 0);
""")

MS_STATES = ("pending", "doing", "done", "blocked", "skipped")
MAX_ACTIVE_AUTO = 1          # at most one self-started milestone at a time (8 GB laptop)


# ------------------------------------------------------------------ storage
def _touch(oid: str, **cols):
    sets = ["updated=?"]
    args: list = [C.now()]
    for k, v in cols.items():
        sets.append(f"{k}=?")
        args.append(v)
    C.x(f"UPDATE objectives7 SET {', '.join(sets)} WHERE oid=?", args + [oid])


def create(title: str, milestones: Optional[List[str]] = None, due: Optional[float] = None, path: str = ".") -> Dict:
    title = C.clip(title.strip(), 140)
    oid = K.new_id("O")
    C.x("INSERT INTO objectives7(oid,title,created,updated,status,due,path) VALUES(?,?,?,?,?,?,?)", (oid, title, C.now(), C.now(), "active", due, path))
    for i, m in enumerate([m for m in (milestones or []) if m.strip()][:12]):
        C.x("INSERT INTO milestones7(oid,idx,text,ts) VALUES(?,?,?,?)", (oid, i + 1, C.clip(m.strip(), 200), C.now()))
    K.emit("objective.created", {"oid": oid, "title": title})
    return get(oid)


def find(hint: str) -> Optional[Dict]:
    """Find an objective by id, ordinal ('the first one') or fuzzy title; None if ambiguous or unknown."""
    hint = (hint or "").strip()
    if not hint:
        rows = C.q("SELECT * FROM objectives7 WHERE status IN ('active','blocked') ORDER BY updated DESC LIMIT 2")
        return get(rows[0]["oid"]) if len(rows) == 1 else None
    r = C.q("SELECT oid FROM objectives7 WHERE oid=?", (hint,))
    if r:
        return get(r[0]["oid"])
    scored = sorted(((C.similarity(hint, o["title"]) + (0.25 if hint.lower() in o["title"].lower() else 0), o["oid"]) for o in C.q("SELECT oid,title FROM objectives7 WHERE status<>'cancelled'")), reverse=True)
    if scored and scored[0][0] >= 0.35 and (len(scored) == 1 or scored[0][0] - scored[1][0] >= 0.08):
        return get(scored[0][1])
    return None


def get(oid: str) -> Optional[Dict]:
    r = C.q("SELECT * FROM objectives7 WHERE oid=?", (oid,))
    if not r:
        return None
    o = dict(r[0])
    o["milestones"] = [dict(m) for m in C.q("SELECT * FROM milestones7 WHERE oid=? ORDER BY idx", (oid,))]
    o["blockers"] = [dict(b) for b in C.q("SELECT * FROM blockers7 WHERE oid=? AND resolved=0", (oid,))]
    o["progress"] = _pct(o["milestones"])
    return o


def objectives(include_done: bool = False) -> List[Dict]:
    rows = C.q("SELECT oid FROM objectives7 " + ("" if include_done else "WHERE status IN ('active','blocked','paused') ") + "ORDER BY updated DESC LIMIT 30")
    return [get(r["oid"]) for r in rows]


def _pct(ms: List[Dict]) -> int:
    live = [m for m in ms if m["status"] != "skipped"]
    return int(round(100 * sum(1 for m in live if m["status"] == "done") / len(live))) if live else 0


# ------------------------------------------------------------------ milestones
def add_milestone(oid: str, text: str, after: Optional[int] = None) -> Optional[Dict]:
    o = get(oid)
    if not o:
        return None
    idx = (max([m["idx"] for m in o["milestones"]] or [0])) + 1
    C.x("INSERT INTO milestones7(oid,idx,text,ts) VALUES(?,?,?,?)", (oid, idx, C.clip(text, 200), C.now()))
    _touch(oid)
    return get(oid)


def _ms(oid: str, idx: int) -> Optional[Dict]:
    r = C.q("SELECT * FROM milestones7 WHERE oid=? AND idx=?", (oid, idx))
    return dict(r[0]) if r else None


def complete(oid: str, idx: int, evidence: str = "", by: str = "user") -> Dict:
    m = _ms(oid, idx)
    if not m:
        return {"ok": False, "error": "no such milestone"}
    C.x("UPDATE milestones7 SET status='done', evidence=?, ts=? WHERE id=?", (C.clip(f"{by}: {evidence}" if evidence else by, 300), C.now(), m["id"]))
    C.x("UPDATE blockers7 SET resolved=1 WHERE oid=? AND idx=?", (oid, idx))
    _after_change(oid)
    return {"ok": True, "text": m["text"]}


def block(oid: str, idx: Optional[int], text: str):
    C.x("INSERT INTO blockers7(oid,idx,text,ts) VALUES(?,?,?,?)", (oid, idx or 0, C.clip(text, 200), C.now()))
    if idx:
        C.x("UPDATE milestones7 SET status='blocked' WHERE oid=? AND idx=?", (oid, idx))
    _touch(oid, status="blocked")
    K.emit("objective.blocked", {"oid": oid, "text": text})


def unblock(oid: str, idx: Optional[int] = None) -> int:
    n = K.xn("UPDATE blockers7 SET resolved=1 WHERE oid=? AND resolved=0" + (" AND idx=?" if idx else ""), (oid, idx) if idx else (oid,))
    C.x("UPDATE milestones7 SET status='pending' WHERE oid=? AND status='blocked'" + (" AND idx=?" if idx else ""), (oid, idx) if idx else (oid,))
    o = get(oid)
    if o and not o["blockers"]:
        _touch(oid, status="active")
    return n


def _after_change(oid: str):
    o = get(oid)
    if not o:
        return
    live = [m for m in o["milestones"] if m["status"] != "skipped"]
    if live and all(m["status"] == "done" for m in live):
        _touch(oid, status="done")
        K.emit("objective.done", {"oid": oid, "title": o["title"]})
    else:
        _touch(oid, status="blocked" if o["blockers"] else "active")


def next_ready(oid: str) -> Optional[Dict]:
    o = get(oid)
    if not o:
        return None
    for m in o["milestones"]:
        if m["status"] == "pending":
            return m
        if m["status"] in ("doing", "blocked"):
            return None          # milestones are sequential: nothing starts past an unfinished or blocked one
    return None


def schedule(oid: str, idx: int, when_ts: float) -> Dict:
    """Approving a schedule is the approval: this milestone may start by itself at that time (still subject to the permission engine)."""
    m = _ms(oid, idx)
    if not m:
        return {"ok": False, "error": "no such milestone"}
    C.x("UPDATE milestones7 SET run_at=?, approved=1 WHERE id=?", (when_ts, m["id"]))
    return {"ok": True, "text": m["text"], "when": C.iso(when_ts)}


def run_next(oid: str, source: str = "user") -> Dict:
    o = get(oid)
    if not o:
        return {"ok": False, "error": "unknown objective"}
    m = next_ready(oid)
    if not m:
        why = "every milestone is done" if o["progress"] == 100 else "it is waiting on a blocker or an unfinished milestone"
        return {"ok": False, "error": why}
    try:
        import friday_orchestrator7 as O
        goal = f"{m['text']} (milestone {m['idx']} of the objective: {o['title']})"
        jid = O.submit(goal, intent="general", source=source, auto=(source != "user"), path=o.get("path") or ".", speak=(source == "user"))
    except Exception as exc:
        return {"ok": False, "error": f"I couldn't start it: {exc}"}
    C.x("UPDATE milestones7 SET status='doing', jid=?, ts=? WHERE id=?", (jid, C.now(), m["id"]))
    _touch(oid)
    return {"ok": True, "jid": jid, "milestone": m["text"], "idx": m["idx"]}


def _on_job_done(p: Dict):
    if not p:
        return
    r = C.q("SELECT * FROM milestones7 WHERE jid=? AND status='doing'", (p.get("jid", ""),))
    if not r:
        return
    m = r[0]
    ratio = float(p.get("verified_ratio") or 0)
    if p.get("state") == "done" and ratio >= 0.5:
        C.x("UPDATE milestones7 SET status='done', evidence=?, ts=? WHERE id=?", (C.clip(f"mission {p.get('jid')} verified {int(ratio * 100)}%", 300), C.now(), m["id"]))
        _after_change(m["oid"])
    elif p.get("state") == "cancelled":
        C.x("UPDATE milestones7 SET status='pending', jid='' WHERE id=?", (m["id"],))
    else:
        why = "; ".join(f"{f.get('tool')}: {f.get('error', '')[:60]}" for f in (p.get("failures") or [])[:2]) or f"mission {p.get('state')}"
        block(m["oid"], m["idx"], f"Milestone {m['idx']} did not complete - {why}")


def install_events():
    K.on("job.done", _on_job_done)


# ------------------------------------------------------------------ the loop
def tick(now: Optional[float] = None) -> List[str]:
    """Start approved scheduled milestones that are due. Never starts more than one self-started mission at a time and never while FRIDAY is speaking."""
    now = now or time.time()
    started: List[str] = []
    if K.busy():
        return started
    try:
        import friday_orchestrator7 as O
        if len(O._running) >= MAX_ACTIVE_AUTO:
            return started
        light = False
        try:
            import friday_health7 as H
            light = H.light_mode()
        except Exception:
            pass
        if light:
            return started
    except Exception:
        return started
    for m in C.q("SELECT * FROM milestones7 WHERE approved=1 AND status='pending' AND run_at IS NOT NULL AND run_at<=? ORDER BY run_at LIMIT 3", (now,)):
        o = get(m["oid"])
        if not o or o["status"] not in ("active",) or next_ready(m["oid"]) is None or next_ready(m["oid"])["idx"] != m["idx"]:
            continue
        r = run_next(m["oid"], source="schedule")
        C.x("UPDATE milestones7 SET approved=0 WHERE id=?", (m["id"],))
        if r.get("ok"):
            started.append(r["jid"])
            break
    return started


def due_soon(hours: float = 48) -> List[Dict]:
    lim = time.time() + hours * 3600
    return [o for o in objectives() if o.get("due") and o["due"] <= lim and o["status"] != "done"]


def resume_interrupted() -> List[str]:
    """Milestones marked 'doing' whose mission no longer exists or is paused are put back so they can be continued from the verified checkpoint."""
    out = []
    try:
        import friday_orchestrator7 as O
    except Exception:
        return out
    for m in C.q("SELECT * FROM milestones7 WHERE status='doing'"):
        j = O.get(m["jid"]) if m["jid"] else None
        if not j:
            C.x("UPDATE milestones7 SET status='pending', jid='' WHERE id=?", (m["id"],))
            out.append(m["oid"])
        elif j["state"] in ("paused",):
            out.append(m["oid"])
    return out


# ------------------------------------------------------------------ reporting
def report(oid: str) -> str:
    o = get(oid)
    if not o:
        return "I don't have that objective."
    done = [m for m in o["milestones"] if m["status"] == "done"]
    nxt = next_ready(oid)
    bits = [f"'{o['title']}' is {o['progress']} percent done ({len(done)} of {len([m for m in o['milestones'] if m['status'] != 'skipped'])} milestones, counted only when confirmed)."]
    if o["blockers"]:
        bits.append("Blocked: " + "; ".join(b["text"] for b in o["blockers"][:2]) + ".")
    if nxt:
        bits.append(f"Next: {nxt['text']}.")
    if o.get("due"):
        bits.append("Due " + time.strftime("%a %d %b", time.localtime(o["due"])) + ".")
    return " ".join(bits)


# ------------------------------------------------------------------ chat
_RX_CREATE = re.compile(r"^(?:create|start|set up|begin|add|make)\s+(?:a\s+|an\s+|new\s+)*(?:new\s+)?(?:long[- ]term\s+)?(?:objective|project goal|big goal)(?:\s+(?:called|named|to|for|:))?\s*[:,]?\s*(.+)$", re.I)
_RX_MS_LIST = re.compile(r"\s*(?:with\s+(?:the\s+)?milestones?|milestones?\s*[:\-]|steps?\s*[:\-])\s*(.+)$", re.I)


def _due_from(text: str):
    m = re.search(r"\b(?:by|due|before|until)\s+(?:the\s+)?(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?([a-z]{3,9})(?:\s+(\d{4}))?\b", text, re.I)
    if m:
        try:
            yr = int(m.group(3)) if m.group(3) else time.localtime().tm_year
            t = time.mktime(time.strptime(f"{int(m.group(1))} {m.group(2)[:3].title()} {yr}", "%d %b %Y"))
            if t < time.time() and not m.group(3):
                t = time.mktime(time.strptime(f"{int(m.group(1))} {m.group(2)[:3].title()} {yr + 1}", "%d %b %Y"))
            return t, text[:m.start()].strip(" ,.")
        except Exception:
            pass
    m = re.search(r"\b(?:by|in)\s+(?:the\s+)?(?:end of\s+)?(?:next\s+)?(week|month)\b", text, re.I)
    if m:
        return time.time() + (7 if m.group(1).lower() == "week" else 30) * 86400, text[:m.start()].strip(" ,.")
    return None, text


def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    raw = K.strip_wake(command).strip()
    if not t:
        return None
    m = _RX_CREATE.match(raw)
    if m:
        body = m.group(1).strip()
        mm = _RX_MS_LIST.search(body)
        steps: List[str] = []
        if mm:
            body, lst = body[:mm.start()].strip(" ,.:"), mm.group(1)
            steps = [s.strip(" .") for s in re.split(r"\s*(?:;|,\s*(?:and\s+)?|\band then\b|\bthen\b|\band\b)\s*", lst) if s.strip(" .")]
        due, body = _due_from(body)
        if not body:
            return "What should the objective be called?"
        o = create(body, steps, due)
        extra = f" with {len(steps)} milestones" if steps else ". Tell me the milestones whenever you're ready: 'add milestone ... to objective ...'"
        return f"Objective created: {o['title']}{extra}."
    m = re.match(r"^add (?:a\s+)?milestone\s+(.+?)\s+to\s+(?:the\s+)?(?:objective\s+)?(.+)$", t)
    if m:
        o = find(m.group(2))
        if not o:
            return "I couldn't tell which objective you mean. Say 'list objectives' to hear them."
        text = re.sub(r"^add (?:a\s+)?milestone\s+", "", raw, flags=re.I)
        text = re.sub(r"\s+to\s+(?:the\s+)?(?:objective\s+)?" + re.escape(m.group(2)) + r"\s*$", "", text, flags=re.I)
        add_milestone(o["oid"], text)
        return f"Added milestone {len(o['milestones']) + 1} to {o['title']}."
    if re.match(r"^(?:list|show|what are)\s+(?:my\s+)?(?:objectives|long[- ]term goals)\??$", t):
        os_ = objectives()
        if not os_:
            return "No objectives yet. Say 'create an objective to ... with milestones ...'."
        return "Your objectives: " + "; ".join(f"{o['title']} ({o['progress']} percent, {o['status']})" for o in os_[:5]) + "."
    m = re.match(r"^(?:mark )?milestone (\d+)(?:\s+(?:of|on|for|in)\s+(?:the\s+)?(?:objective\s+)?(.+?))?\s+(?:as\s+)?(?:done|complete|completed|finished)$", t)
    if m:
        o = find(m.group(2) or "")
        if not o:
            return "Which objective? Say 'list objectives' to hear them."
        r = complete(o["oid"], int(m.group(1)))
        return f"Marked '{r['text']}' as done on your say-so. {report(o['oid'])}" if r["ok"] else r["error"].capitalize() + "."
    m = re.match(r"^(?:how is|how's|how are we doing on|progress (?:on|of|for)|status of|report on)\s+(?:the\s+)?(?:objective\s+)?(.+?)\??$", t)
    if m and find(m.group(1)):
        return report(find(m.group(1))["oid"])
    m = re.match(r"^what(?:'s| is) (?:blocking|stopping|holding up)\s+(?:the\s+)?(?:objective\s+)?(.+?)\??$", t)
    if m:
        o = find(m.group(1))
        if not o:
            return "I don't know that objective."
        return ("Blocked by: " + "; ".join(b["text"] for b in o["blockers"][:3]) + ".") if o["blockers"] else "Nothing is recorded as blocking it."
    m = re.match(r"^(?:work on|continue|do the next (?:step|milestone) (?:of|for|on)|next milestone (?:of|for))\s+(?:the\s+)?(?:objective\s+)?(.+)$", t)
    if m and find(m.group(1)) and not re.match(r"^(?:that|it|this)$", m.group(1)):
        o = find(m.group(1))
        r = run_next(o["oid"])
        return f"Starting: {r['milestone']}. I'll confirm each step before I call it done." if r["ok"] else f"I can't start the next one: {r['error']}."
    m = re.match(r"^(?:unblock|clear the blocker on)\s+(?:the\s+)?(?:objective\s+)?(.+)$", t)
    if m and find(m.group(1)):
        o = find(m.group(1))
        n = unblock(o["oid"])
        return f"Cleared {n} blocker(s) on {o['title']}." if n else "Nothing was blocking it."
    m = re.match(r"^(?:block|mark)\s+(?:the\s+)?(?:objective\s+)?(.+?)\s+(?:as\s+)?blocked\s+(?:by|because|on)\s+(.+)$", t)
    if m and find(m.group(1)):
        block(find(m.group(1))["oid"], None, m.group(2))
        return "Noted the blocker."
    m = re.match(r"^(?:cancel|drop|delete)\s+(?:the\s+)?objective\s+(.+)$", t)
    if m:
        o = find(m.group(1))
        if not o:
            return "I don't know that objective."
        _touch(o["oid"], status="cancelled")
        return f"Dropped the objective {o['title']}."
    return None


def ui_snapshot() -> Dict:
    return {"objectives": [{"oid": o["oid"], "title": o["title"], "status": o["status"], "progress": o["progress"], "due": C.iso(o["due"]) if o.get("due") else "",
                            "milestones": [{"idx": m["idx"], "text": m["text"], "status": m["status"], "jid": m["jid"], "evidence": m["evidence"]} for m in o["milestones"]],
                            "blockers": [b["text"] for b in o["blockers"]]} for o in objectives(include_done=True)[:12]]}


def handle_ui(req: Dict) -> Optional[Dict]:
    a = req.get("action")
    if a == "objective_create":
        o = create(str(req.get("title", "")), [m for m in str(req.get("milestones", "")).split("\n") if m.strip()])
        return {"ok": True, "oid": o["oid"]}
    if a == "objective_run":
        return run_next(str(req.get("oid", "")))
    if a == "milestone_done":
        return complete(str(req.get("oid", "")), int(req.get("idx", 0)))
    if a == "objective_unblock":
        return {"ok": True, "cleared": unblock(str(req.get("oid", "")))}
    return None
