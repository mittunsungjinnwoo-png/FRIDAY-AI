"""FRIDAY 7.0 unified context graph (roadmap #27).

One connected view of the user's work, DERIVED from the records FRIDAY already keeps - nothing is invented and nothing is copied out of its source:

    nodes   project - objective - milestone - mission (task) - document - person - decision - deadline - outcome (verified result) - research
    edges   objective has milestone - milestone worked by mission - mission produced document / research - document belongs to project - person mentioned in
            decision / project note - deadline due-for objective / milestone / task / event
    every node carries its SOURCE (table:id or file path or URL) and a FRESHNESS stamp (when its source last changed); outcomes also carry whether they were verified.

    rebuild()            re-derive the graph (cheap; rate-limited)         about(name)       everything connected to a name, with freshness and sources
    upcoming(days)       deadlines in order                                trace(nid)        why does this exist? (outcome -> mission -> milestone -> objective)
Chat: "what is connected to X", "show the context graph", "show all my deadlines", "what documents belong to X", "why do we have X".
"""
from __future__ import annotations

import re
import time
from typing import Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS ctx_nodes7(nid TEXT PRIMARY KEY, kind TEXT, label TEXT, source TEXT, updated REAL, meta TEXT DEFAULT '{}', seen REAL);
CREATE TABLE IF NOT EXISTS ctx_edges7(id INTEGER PRIMARY KEY, a TEXT, rel TEXT, b TEXT, source TEXT, seen REAL, UNIQUE(a, rel, b));
CREATE INDEX IF NOT EXISTS ix_ctx_edges7_a ON ctx_edges7(a);
CREATE INDEX IF NOT EXISTS ix_ctx_edges7_b ON ctx_edges7(b);
""")

MIN_INTERVAL_S = 45.0
_last = {"ts": 0.0, "counts": {}}
KINDS = ("project", "objective", "milestone", "mission", "document", "person", "decision", "deadline", "outcome", "research")


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")[:48] or "x"


def _node(kind: str, key: str, label: str, source: str, updated: float, meta: Optional[Dict] = None) -> str:
    nid = f"{kind}:{key}"
    C.x("INSERT INTO ctx_nodes7(nid,kind,label,source,updated,meta,seen) VALUES(?,?,?,?,?,?,?) ON CONFLICT(nid) DO UPDATE SET label=excluded.label, source=excluded.source, updated=excluded.updated, meta=excluded.meta, seen=excluded.seen",
        (nid, kind, C.clip(label, 140), source, float(updated or 0), K.jd(meta or {}), C.now()))
    return nid


def _edge(a: str, rel: str, b: str, source: str = ""):
    if a and b and a != b:
        C.x("INSERT OR IGNORE INTO ctx_edges7(a,rel,b,source,seen) VALUES(?,?,?,?,?)", (a, rel, b, source, C.now()))


def _safe(sql: str, args=()):
    try:
        return C.q(sql, args)
    except Exception:
        return []


def rebuild(force: bool = False) -> Dict:
    if not force and time.time() - _last["ts"] < MIN_INTERVAL_S:
        return _last["counts"]
    t0 = time.time()
    # --- objectives, milestones, deadlines
    obj_nodes: Dict[str, str] = {}
    for o in _safe("SELECT * FROM objectives7"):
        n = _node("objective", o["oid"], o["title"], f"objectives7:{o['oid']}", o["updated"] or o["created"], {"status": o["status"], "path": o["path"]})
        obj_nodes[o["oid"]] = n
        if o["due"]:
            d = _node("deadline", f"obj-{o['oid']}", f"{o['title']} due {C.iso(o['due'])[:10]}", f"objectives7:{o['oid']}", o["updated"] or o["created"], {"due": o["due"], "open": o["status"] == "active"})
            _edge(d, "due_for", n, "objectives7")
    ms_by_jid: Dict[str, str] = {}
    for m in _safe("SELECT * FROM milestones7"):
        n = _node("milestone", f"{m['oid']}-{m['idx']}", m["text"], f"milestones7:{m['id']}", m["ts"] or 0, {"status": m["status"], "evidence": (m["evidence"] or "")[:160], "done": m["status"] == "done"})
        _edge(obj_nodes.get(m["oid"], ""), "has_milestone", n, "milestones7")
        if m["due"]:
            d = _node("deadline", f"ms-{m['oid']}-{m['idx']}", f"{m['text']} due {C.iso(m['due'])[:10]}", f"milestones7:{m['id']}", m["ts"] or 0, {"due": m["due"], "open": m["status"] not in ("done", "skipped")})
            _edge(d, "due_for", n, "milestones7")
        if m["jid"]:
            ms_by_jid[m["jid"]] = n
    # --- missions and their outcomes / documents
    reports = {r["path"]: r for r in _safe("SELECT * FROM reports7")}
    for r in reports.values():
        _node("document", _slug(r["path"]), r["topic"] or Path_name(r["path"]), r["path"], r["ts"], {"path": r["path"], "kind": "report"})
    for j in _safe("SELECT jid, goal, state, updated, report, plan_meta FROM jobs7 ORDER BY id DESC LIMIT 60"):
        n = _node("mission", j["jid"], j["goal"], f"jobs7:{j['jid']}", j["updated"], {"state": j["state"]})
        _edge(ms_by_jid.get(j["jid"], ""), "worked_by", n, "milestones7.jid")
        if j["state"] in ("done", "partial"):
            first = (j["report"] or "").splitlines()[1] if j["report"] and len((j["report"] or "").splitlines()) > 1 else ""
            o = _node("outcome", j["jid"], f"{'Verified' if state_verified(j['report']) else 'Unverified'} result: {j['goal']}", f"jobs7:{j['jid']}", j["updated"], {"verified": state_verified(j["report"]), "state": j["state"], "summary": first[:140]})
            _edge(n, "produced", o, "jobs7")
        for p in re.findall(r"Saved: ([^\n]+)", j["report"] or ""):
            for path in [x.strip() for x in p.split(",")]:
                if path in reports:
                    _edge(n, "produced", f"document:{_slug(path)}", "jobs7.report")
                else:
                    d = _node("document", _slug(path), Path_name(path), path, j["updated"], {"path": path, "kind": "file"})
                    _edge(n, "produced", d, "jobs7.report")
    for t in _safe("SELECT id, goal, status, deadline, created, ended FROM tasks6 ORDER BY id DESC LIMIT 40"):
        n = _node("mission", f"t{t['id']}", t["goal"], f"tasks6:{t['id']}", t["ended"] or t["created"], {"state": t["status"]})
        if t["deadline"]:
            d = _node("deadline", f"task-{t['id']}", f"{t['goal']} due {C.iso(t['deadline'])[:10]}", f"tasks6:{t['id']}", t["created"], {"due": t["deadline"], "open": t["status"] not in ("done", "cancelled", "failed")})
            _edge(d, "due_for", n, "tasks6")
    for r in _safe("SELECT id, ts, question, confidence FROM investigations7 ORDER BY id DESC LIMIT 30"):
        lvl = (K.jl(r["confidence"], {}) or {}).get("level", "")
        _node("research", str(r["id"]), r["question"], f"investigations7:{r['id']}", r["ts"], {"confidence": lvl})
    # --- projects, people, decisions
    proj: Dict[str, str] = {}
    for p in _safe("SELECT project, MAX(ts) ts, COUNT(*) n FROM project_notes GROUP BY project"):
        proj[p["project"]] = _node("project", _slug(p["project"]), p["project"], f"project_notes:{p['project']}", p["ts"], {"notes": p["n"]})
    for p in _safe("SELECT DISTINCT project FROM mem7 WHERE project!='' AND status='active'"):
        if p["project"] not in proj:
            proj[p["project"]] = _node("project", _slug(p["project"]), p["project"], f"mem7:project={p['project']}", time.time())
    for o in _safe("SELECT oid, title, path FROM objectives7 WHERE path NOT IN ('', '.')"):
        pn = proj.get(re.sub(r".*[\\/]", "", o["path"]))
        if pn:
            _edge(obj_nodes.get(o["oid"], ""), "part_of", pn, "objectives7.path")
    for o in _safe("SELECT oid, title FROM objectives7"):
        for pname, pn in proj.items():
            if len(pname) > 2 and re.search(r"\b" + re.escape(pname) + r"\b", o["title"], re.I):
                _edge(obj_nodes.get(o["oid"], ""), "part_of", pn, "objectives7.title")
    people: Dict[str, str] = {}
    for c in _safe("SELECT name, ts FROM pr_contacts LIMIT 200"):
        people[c["name"]] = _node("person", _slug(c["name"]), c["name"], f"pr_contacts:{c['name']}", c["ts"])
    for g in _safe("SELECT name, ts FROM graph_nodes WHERE kind='person' LIMIT 200"):
        people.setdefault(g["name"], _node("person", _slug(g["name"]), g["name"], f"graph_nodes:{g['name']}", g["ts"]))
    decisions = _safe("SELECT id, ts, text, status FROM mem6 WHERE kind='decision' AND status NOT IN ('superseded','forgotten','deleted') ORDER BY id DESC LIMIT 40")
    notes = _safe("SELECT id, project, ts, note FROM project_notes ORDER BY id DESC LIMIT 80")
    for d in decisions:
        dn = _node("decision", str(d["id"]), d["text"], f"mem6:{d['id']}", d["ts"], {"status": d["status"]})
        for name, pn in people.items():
            if len(name) > 2 and re.search(r"\b" + re.escape(name) + r"\b", d["text"], re.I):
                _edge(pn, "mentioned_in", dn, "mem6")
        for pname, pn in proj.items():
            if len(pname) > 2 and re.search(r"\b" + re.escape(pname) + r"\b", d["text"], re.I):
                _edge(dn, "about", pn, "mem6")
    for nt in notes:
        for name, pn in people.items():
            if len(name) > 2 and re.search(r"\b" + re.escape(name) + r"\b", nt["note"], re.I) and nt["project"] in proj:
                _edge(pn, "mentioned_in", proj[nt["project"]], "project_notes")
    for e in _safe("SELECT id, title, start FROM pr_events WHERE start>? ORDER BY start LIMIT 30", (time.time() - 86400,)):
        _node("deadline", f"ev-{e['id']}", e["title"], f"pr_events:{e['id']}", e["start"], {"due": e["start"], "open": True})
    for r in _safe("SELECT id, text, due FROM reminders WHERE done=0 AND due IS NOT NULL ORDER BY due LIMIT 30"):
        _node("deadline", f"rem-{r['id']}", r["text"], f"reminders:{r['id']}", r["due"], {"due": r["due"], "open": True})
    # documents -> projects (a report whose topic names a project)
    for r in reports.values():
        for pname, pn in proj.items():
            if len(pname) > 2 and pname.lower() in (r["topic"] or "").lower():
                _edge(f"document:{_slug(r['path'])}", "belongs_to", pn, "reports7.topic")
    counts = {k: (C.q("SELECT COUNT(*) n FROM ctx_nodes7 WHERE kind=?", (k,))[0]["n"]) for k in KINDS}
    counts["edges"] = C.q("SELECT COUNT(*) n FROM ctx_edges7")[0]["n"]
    counts["ms"] = int((time.time() - t0) * 1000)
    _last.update(ts=time.time(), counts=counts)
    return counts


def Path_name(p: str) -> str:
    return re.sub(r".*[\\/]", "", p or "") or p


def state_verified(report: str) -> bool:
    m = re.search(r"(\d+) of (\d+) step\(s\) succeeded, (\d+) independently verified", report or "")
    return bool(m and int(m.group(3)) >= max(1, int(m.group(1)) // 2) and int(m.group(1)) > 0)


# ------------------------------------------------------------------ queries
def _fresh(ts: float) -> str:
    if not ts:
        return "date unknown"
    d = (time.time() - ts) / 86400
    return ("today" if d < 1 else f"{int(d)} day(s) ago") + (" - may be stale" if d > 30 else "")


def find(name: str, kinds: Optional[Tuple[str, ...]] = None) -> Optional[Dict]:
    rebuild()
    rows = C.q("SELECT * FROM ctx_nodes7" + (" WHERE kind IN (%s)" % ",".join("?" * len(kinds)) if kinds else ""), tuple(kinds or ()))
    best, bs = None, 0.0
    low = name.lower().strip()
    for r in rows:
        lab = r["label"].lower()
        s = 1.0 if low == lab else 0.85 if low in lab or lab in low else C.similarity(low, lab)
        if r["kind"] in ("objective", "project", "person"):
            s += 0.03
        if s > bs:
            best, bs = dict(r), s
    return best if best and bs >= 0.4 else None


def neighbors(nid: str, depth: int = 1) -> List[Dict]:
    seen = {nid}
    frontier = [nid]
    out: List[Dict] = []
    for _ in range(depth):
        nxt = []
        for n in frontier:
            for e in C.q("SELECT * FROM ctx_edges7 WHERE a=? OR b=?", (n, n)):
                other, direction = (e["b"], "out") if e["a"] == n else (e["a"], "in")
                if other in seen:
                    continue
                seen.add(other)
                r = C.q("SELECT * FROM ctx_nodes7 WHERE nid=?", (other,))
                if r:
                    out.append({**dict(r[0]), "rel": e["rel"], "dir": direction, "via": n})
                    nxt.append(other)
        frontier = nxt
    return out


def about(name: str) -> str:
    n = find(name)
    if not n:
        return f"I have nothing connected to '{name}' in your projects, tasks, documents or decisions."
    nb = neighbors(n["nid"], 4 if n["kind"] == "project" else 3 if n["kind"] == "objective" else 2)
    meta = K.jl(n["meta"], {})
    head = f"{n['kind'].title()}: {n['label']} (source {n['source']}, updated {_fresh(n['updated'])}" + (f", status {meta['status']}" if meta.get("status") else "") + ")."
    if not nb:
        return head + " Nothing else is linked to it yet."
    by: Dict[str, List[str]] = {}
    for x in nb:
        m = K.jl(x["meta"], {})
        extra = " [verified]" if m.get("verified") else " [unverified]" if x["kind"] == "outcome" else ""
        by.setdefault(x["kind"], []).append(f"{x['label']}{extra} - {x['rel'].replace('_', ' ')}, {_fresh(x['updated'])}, source {x['source']}")
    lines = [head]
    for k in KINDS:
        if k in by:
            lines.append(f"{k.title()}s ({len(by[k])}):")
            lines += [f"  - {v}" for v in by[k][:5]]
    return "\n".join(lines)


def upcoming(days: float = 30, only_open: bool = True) -> List[Dict]:
    rebuild()
    now = time.time()
    out = []
    for r in C.q("SELECT * FROM ctx_nodes7 WHERE kind='deadline'"):
        m = K.jl(r["meta"], {})
        due = m.get("due")
        if not due or (only_open and not m.get("open", True)):
            continue
        if due <= now + days * 86400:
            rel = C.q("SELECT b FROM ctx_edges7 WHERE a=? AND rel='due_for'", (r["nid"],))
            out.append({"label": r["label"], "due": due, "overdue": due < now, "for": rel[0]["b"] if rel else "", "source": r["source"]})
    out.sort(key=lambda x: x["due"])
    return out


def trace(nid: str) -> List[Dict]:
    """Why does this exist? Walk 'produced' / 'worked_by' / 'has_milestone' edges back towards an objective."""
    path: List[Dict] = []
    cur, seen = nid, set()
    while cur and cur not in seen:
        seen.add(cur)
        r = C.q("SELECT * FROM ctx_nodes7 WHERE nid=?", (cur,))
        if not r:
            break
        path.append({"nid": cur, "kind": r[0]["kind"], "label": r[0]["label"], "source": r[0]["source"]})
        e = C.q("SELECT a FROM ctx_edges7 WHERE b=? AND rel IN ('produced','worked_by','has_milestone','part_of','belongs_to') LIMIT 1", (cur,))
        cur = e[0]["a"] if e else ""
        if not cur:
            e2 = C.q("SELECT b FROM ctx_edges7 WHERE a=? AND rel IN ('part_of','belongs_to') LIMIT 1", (nid if len(path) == 1 else path[-1]["nid"],))
            cur = e2[0]["b"] if e2 else ""
    return path


def snapshot_graph(limit: int = 60) -> Dict:
    rebuild()
    nodes = C.q("SELECT nid, kind, label, updated FROM ctx_nodes7 ORDER BY updated DESC LIMIT ?", (limit,))
    ids = {n["nid"] for n in nodes}
    edges = [e for e in C.q("SELECT a, rel, b FROM ctx_edges7 LIMIT 400") if e["a"] in ids and e["b"] in ids]
    return {"nodes": [{"id": n["nid"], "kind": n["kind"], "label": n["label"], "fresh": _fresh(n["updated"])} for n in nodes], "edges": [dict(e) for e in edges]}


# ------------------------------------------------------------------ chat
def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    m = re.match(r"^(?:what(?:'s| is| are)|show me what(?:'s| is)?) (?:connected|linked|related) to (.+)$|^(?:show|give me) (?:the )?context (?:for|of|on) (.+)$|^what documents (?:belong|relate|are linked) to (.+)$", t)
    if m:
        name = next(g for g in m.groups() if g)
        return about(name) if find(name) else None
    if re.match(r"^(?:show|open|display) (?:me )?(?:the |my )?(?:context )?graph$|^show (?:me )?(?:the )?context graph$", t):
        c = rebuild(force=True)
        K.emit_ui("context_graph", {"counts": c, "deadlines": [{"label": u["label"], "due": C.iso(u["due"])[:10], "overdue": u["overdue"]} for u in upcoming(30)[:8]], **snapshot_graph()})
        return f"The context graph links {sum(c.get(k, 0) for k in KINDS)} items with {c.get('edges', 0)} connections: " + ", ".join(f"{c[k]} {k}{'s' if c[k] != 1 else ''}" for k in KINDS if c.get(k)) + ". I've put it on screen."
    if re.match(r"^(?:show|list|what are) (?:me )?(?:all )?(?:my |the )?(?:upcoming )?deadlines$", t):
        ups = upcoming(60)
        if not ups:
            return "No open deadlines in the next sixty days."
        return "\n".join(("OVERDUE " if u["overdue"] else "") + f"{C.iso(u['due'])[:16].replace('T', ' ')} - {u['label']}" for u in ups[:10])
    m = re.match(r"^why (?:do we have|did we make|is there) (?:the )?(.+)$", t)
    if m:
        n = find(m.group(1))
        if not n:
            return None
        p = trace(n["nid"])
        if len(p) < 2:
            return f"'{n['label']}' is not linked to anything above it - it came from {n['source']}."
        return "Because " + " <- ".join(f"{x['kind']} '{C.clip(x['label'], 50)}'" for x in p) + "."
    return None


def ui_snapshot() -> Dict:
    c = rebuild()
    return {"graph": {"counts": c, "deadlines": [{"label": u["label"], "due": C.iso(u["due"])[:10], "overdue": u["overdue"]} for u in upcoming(30)[:8]], **snapshot_graph(40)}}


def install_events():
    for ev in ("job.done", "report.saved", "objective.created", "objective.blocked", "objective.done", "investigation.done"):
        K.on(ev, lambda p: _last.update(ts=0.0))
