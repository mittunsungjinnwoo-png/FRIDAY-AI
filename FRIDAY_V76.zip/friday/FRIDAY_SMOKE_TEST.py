import os, sys, tempfile, pathlib, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import friday_finance_engine as finance
assert finance.totals()["income"] >= 0
assert finance.advice()
import friday_attachment_engine as att
fd,tmp=tempfile.mkstemp(suffix=".py")
os.write(fd,b"print('FRIDAY smoke test')\n")
os.close(fd)
try:
    r=att.inspect([tmp])
    assert r and r[0]["kind"]=="text/code"
    assert "FRIDAY smoke test" in r[0]["content"]
finally:
    os.unlink(tmp)
print("FRIDAY native smoke tests: PASS")
