"""
FRIDAY UNIVERSAL VERIFICATION LAYER
------------------------------------
Implements the research doc's "7. Truth verification - 9.5+" and
"Verification should have different levels" sections:

    ACTION VERIFIED  !=  TASK VERIFIED  !=  GOAL VERIFIED

Four levels, exactly as specified:
    Level 1 - Mechanical : did the app open / file get created / click land?
    Level 2 - Semantic   : did the action achieve what was requested?
    Level 3 - Knowledge  : is the information actually correct?
    Level 4 - Goal       : did we accomplish the user's original goal?

Every result carries {status, confidence, evidence, level, notes} so
callers always get a confidence + evidence, never a bare boolean.

This module is additive: it OPTIONALLY calls your existing
friday_truth_verifier.py for real mechanical evidence (screenshots,
OCR, UIA, window title) when that module and its optional
dependencies (mss/PIL/pytesseract/pyautogui) are importable. When
they are not (e.g. this sandbox, or a headless CI box), it degrades
gracefully to "unknown" evidence with low confidence rather than
raising -- exactly the pattern friday_truth_verifier.py itself
already uses.

Nothing in friday_truth_verifier.py is imported destructively or
modified; if that file is missing entirely this module still works
(mechanical checks just report reduced confidence).
"""

from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Any, Callable, Optional

STATUS_VERIFIED = "verified"
STATUS_UNVERIFIED = "unverified"
STATUS_CONFLICT = "conflict"
STATUS_UNKNOWN = "unknown"


def _try_import_truth_verifier():
    try:
        import friday_truth_verifier as tv  # existing module, untouched
        return tv
    except Exception:
        return None


_tv = _try_import_truth_verifier()


def make_result(level: str, status: str, confidence: float, evidence: list[Any], notes: str = "") -> dict[str, Any]:
    """Public constructor for a verification result dict, for callers (like
    friday_executive) that need to synthesise a result without invoking one
    of the verify_* functions directly, e.g. when there's nothing to check."""
    return _result(level, status, confidence, evidence, notes)


def _result(level: str, status: str, confidence: float, evidence: list[Any], notes: str = "") -> dict[str, Any]:
    return {
        "level": level,
        "status": status,
        "confidence": round(max(0.0, min(1.0, confidence)), 3),
        "evidence": evidence,
        "notes": notes,
        "ts": time.time(),
    }


# ---------------------------------------------------------------------------
# Level 1 - Mechanical: "Did the application open? Did the file get created?
# Did the button click?"
# ---------------------------------------------------------------------------

def verify_mechanical_file(path: str | Path, min_size: int = 1) -> dict[str, Any]:
    """Did the file get created?"""
    try:
        if _tv is not None:
            info = _tv.verify_file(path, min_size=min_size)
            ok = bool(info.get("readable"))
            return _result("mechanical", STATUS_VERIFIED if ok else STATUS_UNVERIFIED,
                            0.9 if ok else 0.6, [info], "file existence/size check")
    except Exception:
        pass
    # Degrade to plain stdlib check if friday_truth_verifier isn't available.
    try:
        p = Path(path)
        exists = p.exists() and p.is_file()
        size = p.stat().st_size if exists else 0
        ok = exists and size >= min_size
        return _result("mechanical", STATUS_VERIFIED if ok else STATUS_UNVERIFIED,
                        0.85 if ok else 0.6, [{"exists": exists, "size": size, "path": str(p)}],
                        "stdlib fallback file check")
    except Exception as exc:
        return _result("mechanical", STATUS_UNKNOWN, 0.0, [], f"error: {exc}")


def verify_mechanical_action(
    before: Optional[dict[str, Any]] = None,
    expected_text: Optional[str] = None,
    expected_window: Optional[str] = None,
    settle: float = 0.35,
) -> dict[str, Any]:
    """Did the computer action (click / launch / navigate) actually take effect?

    `before` should be the dict returned by friday_truth_verifier.snapshot()
    (or this function's own no-op fallback) taken immediately BEFORE the
    action was performed. Call this immediately AFTER performing it.
    """
    if _tv is None:
        return _result("mechanical", STATUS_UNKNOWN, 0.2, [],
                        "friday_truth_verifier not importable in this environment; "
                        "cannot capture real screen evidence")
    try:
        before = before or _tv.snapshot()
        outcome = _tv.post_action(before, expected_text=expected_text, expected_window=expected_window, settle=settle)

        # If this machine has NO observability at all right now (no display
        # to screenshot, no window title API, no UIA, no OCR -- e.g. a
        # headless box, or optional deps like mss/PIL/pytesseract simply
        # aren't installed), that is fundamentally different from "we looked
        # and nothing changed". Reporting a false UNVERIFIED here would make
        # every action look like it failed on such a machine. Report UNKNOWN
        # instead so callers (friday_executive) can treat "no evidence" as
        # "trust the agent's own report" rather than as proof of failure --
        # this mirrors friday_truth_verifier's own stated philosophy of
        # "marks the evidence quality accordingly rather than claiming
        # certainty".
        no_observability = (
            not outcome.get("before_window") and not outcome.get("after_window")
            and outcome.get("visual_delta", 0.0) == 0.0
            and not outcome.get("uia_changed")
            and before.get("image") is None and before.get("uia") in (None, [])
            and not before.get("ocr")
        )
        if no_observability:
            return _result("mechanical", STATUS_UNKNOWN, 0.2, [outcome],
                            "no screen/window/UIA/OCR evidence is available on this machine right now "
                            "(headless environment, or optional capture dependencies not installed); "
                            "cannot confirm or deny the action mechanically")

        ok = bool(outcome.get("verified"))
        quality = outcome.get("evidence_quality", "weak")
        confidence = {"strong": 0.9, "moderate": 0.6, "weak": 0.3}.get(quality, 0.3)
        return _result("mechanical", STATUS_VERIFIED if ok else STATUS_UNVERIFIED,
                        confidence, [outcome], f"evidence_quality={quality}")
    except Exception as exc:
        return _result("mechanical", STATUS_UNKNOWN, 0.0, [], f"error: {exc}")


def capture_before_state() -> Optional[dict[str, Any]]:
    """Convenience wrapper: snapshot the screen/window/cursor state right
    before performing an action, for later comparison. Returns None (not
    an error) if screen evidence isn't available in this environment."""
    if _tv is None:
        return None
    try:
        return _tv.snapshot()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Level 2 - Semantic: "Did the action achieve what was requested?"
# ---------------------------------------------------------------------------

def verify_semantic(requested: str, achieved_summary: str,
                     judge: Optional[Callable[[str, str], float]] = None) -> dict[str, Any]:
    """Heuristic keyword-overlap check by default; if the caller supplies a
    `judge(requested, achieved_summary) -> float in [0,1]` (e.g. wired to an
    LLM call in your own backend), that is used instead for a much better
    signal. This module never calls an LLM itself so it has zero API-key /
    network dependency and can't silently rack up cost.
    """
    requested = (requested or "").strip()
    achieved_summary = (achieved_summary or "").strip()
    if judge is not None:
        try:
            score = float(judge(requested, achieved_summary))
            score = max(0.0, min(1.0, score))
            status = STATUS_VERIFIED if score >= 0.6 else STATUS_UNVERIFIED
            return _result("semantic", status, score, [{"judge": "external"}], "external semantic judge")
        except Exception:
            pass  # fall through to heuristic

    req_tokens = set(re.findall(r"[a-z0-9]{3,}", requested.lower()))
    ach_tokens = set(re.findall(r"[a-z0-9]{3,}", achieved_summary.lower()))
    if not req_tokens:
        return _result("semantic", STATUS_UNKNOWN, 0.0, [], "empty request text")
    overlap = len(req_tokens & ach_tokens) / max(1, len(req_tokens))
    status = STATUS_VERIFIED if overlap >= 0.35 else STATUS_UNVERIFIED
    return _result("semantic", status, round(0.3 + 0.6 * overlap, 3),
                    [{"overlap": round(overlap, 3), "requested_tokens": len(req_tokens),
                      "achieved_tokens": len(ach_tokens)}],
                    "keyword-overlap heuristic (no external judge supplied)")


# ---------------------------------------------------------------------------
# Level 3 - Knowledge: "Is the information actually correct?"
#   Claim -> Source A / Source B / Source C -> Agreement? -> Confidence
# ---------------------------------------------------------------------------

def verify_knowledge(claim: str, sources: list[dict[str, Any]]) -> dict[str, Any]:
    """`sources` is a list of {"name": str, "text": str, "supports": Optional[bool]}.

    If a source dict already has an explicit "supports" boolean (e.g. set by
    your own research pipeline after it read the source), that is trusted
    directly. Otherwise this falls back to a keyword-overlap heuristic
    between `claim` and the source's `text`, same spirit as friday_context's
    existing relevance scoring, so this module stays a pure, dependency-free
    utility rather than a second research engine.
    """
    claim = (claim or "").strip()
    if not sources:
        return _result("knowledge", STATUS_UNKNOWN, 0.0, [], "no sources supplied")

    claim_tokens = set(re.findall(r"[a-z0-9]{3,}", claim.lower()))
    votes = []
    for src in sources:
        name = src.get("name", "source")
        if "supports" in src and src["supports"] is not None:
            votes.append((name, bool(src["supports"])))
            continue
        text = src.get("text", "") or ""
        text_tokens = set(re.findall(r"[a-z0-9]{3,}", text.lower()))
        overlap = len(claim_tokens & text_tokens) / max(1, len(claim_tokens)) if claim_tokens else 0.0
        votes.append((name, overlap >= 0.4))

    supporting = [n for n, v in votes if v]
    dissenting = [n for n, v in votes if not v]
    agreement = len(supporting) / max(1, len(votes))

    evidence = [{"source": n, "supports": v} for n, v in votes]
    if dissenting and supporting:
        return _result("knowledge", STATUS_CONFLICT, round(0.3 + 0.2 * agreement, 3), evidence,
                        f"{len(supporting)} of {len(votes)} sources agree; conflicting information found, "
                        "recommend checking additional sources")
    if supporting and not dissenting:
        # More independent sources agreeing => higher confidence, capped.
        confidence = min(0.95, 0.55 + 0.15 * len(supporting))
        return _result("knowledge", STATUS_VERIFIED, confidence, evidence,
                        f"{len(supporting)} of {len(votes)} sources agree")
    return _result("knowledge", STATUS_UNVERIFIED, round(0.2 + 0.1 * len(votes), 3), evidence,
                    "no source supports the claim as checked")


# ---------------------------------------------------------------------------
# Level 4 - Goal: "Did we accomplish the user's original goal?"
# ---------------------------------------------------------------------------

def verify_goal(goal_description: str, task_results: list[dict[str, Any]]) -> dict[str, Any]:
    """`task_results` is the list of per-task verification results collected
    while executing the plan (friday_executive fills this in). A goal is
    VERIFIED only if every required task is itself verified; a single
    unverified/failed task drags goal confidence down sharply, matching the
    doc's "ACTION VERIFIED != TASK VERIFIED != GOAL VERIFIED" distinction.
    """
    if not task_results:
        return _result("goal", STATUS_UNKNOWN, 0.0, [], "no task results to evaluate")

    statuses = [t.get("status", STATUS_UNKNOWN) for t in task_results]
    confidences = [t.get("confidence", 0.0) for t in task_results]
    all_verified = all(s == STATUS_VERIFIED for s in statuses)
    any_failed_hard = any(s in (STATUS_UNVERIFIED,) for s in statuses)
    avg_conf = sum(confidences) / len(confidences)

    if all_verified:
        return _result("goal", STATUS_VERIFIED, round(min(0.97, avg_conf), 3), task_results,
                        f"goal '{goal_description}': all {len(task_results)} tasks verified")
    if any_failed_hard:
        return _result("goal", STATUS_UNVERIFIED, round(avg_conf * 0.7, 3), task_results,
                        f"goal '{goal_description}': at least one task did not verify")
    return _result("goal", STATUS_CONFLICT, round(avg_conf * 0.8, 3), task_results,
                    f"goal '{goal_description}': mixed/uncertain task verification")


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

def verify(level: str, **kwargs: Any) -> dict[str, Any]:
    """Single entry point: verify(level, ...) routes to the right function.

        verify("mechanical_file", path=...)
        verify("mechanical_action", before=..., expected_window=...)
        verify("semantic", requested=..., achieved_summary=...)
        verify("knowledge", claim=..., sources=[...])
        verify("goal", goal_description=..., task_results=[...])
    """
    try:
        if level == "mechanical_file":
            return verify_mechanical_file(**kwargs)
        if level == "mechanical_action":
            return verify_mechanical_action(**kwargs)
        if level == "semantic":
            return verify_semantic(**kwargs)
        if level == "knowledge":
            return verify_knowledge(**kwargs)
        if level == "goal":
            return verify_goal(**kwargs)
        return _result(level, STATUS_UNKNOWN, 0.0, [], f"unknown verification level '{level}'")
    except TypeError as exc:
        return _result(level, STATUS_UNKNOWN, 0.0, [], f"bad arguments for '{level}': {exc}")
    except Exception as exc:
        return _result(level, STATUS_UNKNOWN, 0.0, [], f"unexpected error: {exc}")
