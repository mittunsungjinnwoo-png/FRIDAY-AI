import ast, pathlib
ROOT=pathlib.Path(__file__).resolve().parent
for p in ROOT.glob("*.py"):
    ast.parse(p.read_text(encoding="utf-8", errors="ignore"), filename=str(p))
print("FRIDAY V2030 peak syntax audit: PASS")
