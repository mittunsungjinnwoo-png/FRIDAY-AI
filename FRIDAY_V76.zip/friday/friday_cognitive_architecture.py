"""FRIDAY Cognitive Architecture v2041.
General-purpose cognitive orchestration: goals, episodic memory, knowledge links,
provenance, adaptive planning, resource awareness and bounded self-improvement.
No microphone, VAD, ASR, recognition or TTS code is present here.
"""
from __future__ import annotations
import json, math, re, time, hashlib, threading
from pathlib import Path
from collections import Counter
from typing import Any

ROOT=Path(__file__).resolve().parent
STATE_FILE=ROOT/"friday_cognitive_state.json"
_LOCK=threading.RLock()
_STATE={"goals":{},"episodes":[],"entities":{},"relations":[],"metrics":{"tasks":0,"success":0,"failure":0}}
try:
    if STATE_FILE.exists():
        raw=json.loads(STATE_FILE.read_text(encoding="utf-8"));
        if isinstance(raw,dict): _STATE.update(raw)
except Exception: pass

def _save():
    tmp=STATE_FILE.with_suffix('.tmp')
    try:
        tmp.write_text(json.dumps(_STATE,ensure_ascii=False,indent=2)[:2_000_000],encoding='utf-8'); tmp.replace(STATE_FILE)
    except Exception: pass

def _tokens(s): return re.findall(r"[a-z0-9]{2,}",(s or '').lower())

def _id(s): return hashlib.sha256(str(s).encode()).hexdigest()[:16]

def cognitive_profile(command:str)->dict[str,Any]:
    c=(command or '').strip(); toks=_tokens(c); low=c.lower()
    ambiguity=sum(bool(re.search(p,low)) for p in [r'\b(it|that|this|they|them|there)\b',r'\bsomething\b',r'\bmaybe\b'])
    long_task=bool(re.search(r'\b(and then|after that|also|followed by|once|then)\b',low))
    external=bool(re.search(r'\b(research|latest|current|verify|source|compare|look up)\b',low))
    action=bool(re.search(r'\b(open|click|type|send|delete|install|change|run|execute)\b',low))
    creation=bool(re.search(r'\b(create|make|generate|build|write|document|pdf|docx|xlsx|pptx)\b',low))
    complexity=min(1.0,.08+len(toks)/90+.16*long_task+.12*external+.1*action+.08*creation)
    return {'complexity':round(complexity,3),'ambiguity':round(min(1,ambiguity*.22),3),'external_dependency':external,'action_required':action,'artifact':creation,
            'planning_depth':5 if complexity>.78 else 4 if complexity>.5 else 3 if complexity>.25 else 2,
            'verification_depth':4 if external or creation or action else 2}

def build_cognitive_contract(command:str, existing:dict|None=None)->dict[str,Any]:
    p=cognitive_profile(command)
    phases=['interpret','plan']
    if p['external_dependency']: phases += ['retrieve','provenance','cross_validate','synthesize']
    if p['action_required']: phases += ['precondition','act','observe','postcondition']
    if p['artifact']: phases += ['construct','structural_inspect','content_inspect']
    phases += ['verify','learn']
    return {'version':'2041.0','profile':p,'phases':list(dict.fromkeys(phases)),
            'gates':['scope','permission','evidence','postcondition','truthfulness'],
            'failure_policy':['retry_once','alternate_tool','degrade_gracefully','report_partial'],
            'success_rule':'never claim completion without evidence',
            'existing_plan':existing or {}}

def goal_key(command:str)->str:
    return _id(' '.join(_tokens(command)[:80]))

def start_goal(command:str, contract:dict)->dict[str,Any]:
    key=goal_key(command); now=time.time()
    with _LOCK:
        g=_STATE['goals'].get(key,{})
        g.update({'id':key,'objective':command,'contract':contract,'status':'active','started_at':g.get('started_at',now),'updated_at':now,'attempts':g.get('attempts',0)+1})
        _STATE['goals'][key]=g; _save(); return dict(g)

def finish_goal(command:str,status:str,summary:dict|None=None):
    key=goal_key(command)
    with _LOCK:
        g=_STATE['goals'].get(key,{'id':key,'objective':command}); g.update({'status':status,'updated_at':time.time(),'summary':summary or {}})
        _STATE['goals'][key]=g; _STATE['metrics']['tasks']=int(_STATE['metrics'].get('tasks',0))+1
        _STATE['metrics']['success' if status=='completed' else 'failure']=int(_STATE['metrics'].get('success' if status=='completed' else 'failure',0))+1
        _save()

def remember_episode(command:str, outcome:str, tools:list[str], evidence:dict|None=None):
    safe={'id':_id(f'{command}{time.time()}'),'ts':time.time(),'command':command[:1200],'outcome':outcome,'tools':tools[:30],'evidence':evidence or {}}
    with _LOCK:
        _STATE['episodes'].append(safe); _STATE['episodes']=_STATE['episodes'][-1000:]; _save()

def learn_relationships(command:str, tools:list[str], status:str):
    toks=[x for x in _tokens(command) if len(x)>3]
    if not toks:return
    with _LOCK:
        for t in toks[:20]:
            e=_STATE['entities'].setdefault(t,{'mentions':0,'last_seen':0}); e['mentions']+=1; e['last_seen']=time.time()
        rel={'id':_id(command+status),'entities':toks[:8],'tools':tools[:10],'status':status,'ts':time.time()}
        _STATE['relations'].append(rel); _STATE['relations']=_STATE['relations'][-2000:]; _save()

def adaptive_recommendation(command:str, profile:dict, prior_errors:list[str]|None=None)->dict[str,Any]:
    errors=prior_errors or []; strategy='standard'
    if errors: strategy='recovery-first'
    elif profile.get('ambiguity',0)>.3: strategy='clarify-or-constrain'
    elif profile.get('verification_depth',2)>=4: strategy='evidence-first'
    return {'strategy':strategy,'max_retries':2 if strategy!='standard' else 1,'parallel_safe':not profile.get('action_required',False),'ask_clarification_if':profile.get('ambiguity',0)>.55}

def resource_policy(profile:dict)->dict[str,Any]:
    # Conservative defaults for an 8 GB-class Windows machine; no process killing or service changes.
    return {'max_parallel':2 if profile.get('complexity',0)>.5 else 1,'prefer_local_parsers':True,'avoid_unbounded_workers':True,'memory_budget_mb':512}

def audit_result(command:str, status:str, verification:list|None=None)->dict[str,Any]:
    v=verification or []; verified=sum(bool(x.get('ok')) for x in v if isinstance(x,dict)); total=len(v)
    return {'status':status,'verification_ratio':round(verified/max(1,total),2),'verified_checks':verified,'checks':total,'timestamp':time.time()}

def health()->dict[str,Any]:
    m=_STATE.get('metrics',{}); total=m.get('tasks',0)
    return {'version':'2041.0','tasks':total,'success_rate':round(m.get('success',0)/max(1,total),3),'active_goals':sum(1 for g in _STATE.get('goals',{}).values() if g.get('status')=='active'),'entities':len(_STATE.get('entities',{})),'episodes':len(_STATE.get('episodes',[]))}
