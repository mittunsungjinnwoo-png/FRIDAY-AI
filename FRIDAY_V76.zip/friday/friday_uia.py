"""Windows UI Automation primary desktop-control adapter for FRIDAY.
Uses pywinauto's UIA backend (Microsoft UI Automation underneath).
Falls back cleanly when not on Windows or dependency is unavailable.
"""
from __future__ import annotations
import re, time
from typing import Any


def available() -> bool:
    if __import__('platform').system() != 'Windows':
        return False
    try:
        import pywinauto  # noqa
        return True
    except Exception:
        return False


def _desktop():
    from pywinauto import Desktop
    return Desktop(backend="uia")


def active_window():
    if not available(): return None
    try:
        w = _desktop().get_active()
        return w
    except Exception:
        return None


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "").strip().lower())


def _score(name: str, target: str) -> int:
    n, t = _norm(name), _norm(target)
    if not n or not t: return -1
    if n == t: return 100
    if t in n: return 80
    if n in t: return 70
    words = set(re.findall(r"[a-z0-9]+", t))
    nw = set(re.findall(r"[a-z0-9]+", n))
    return 50 + int(40 * len(words & nw) / max(1, len(words)))


def _elements(window=None, max_depth=5):
    w = window or active_window()
    if w is None: return []
    try:
        # pywinauto's descendants traverses the UIA tree and exposes control_type/name.
        return w.descendants(depth=max_depth)
    except Exception:
        return []


def inspect(window=None, max_depth=5, limit=250):
    w = window or active_window()
    if w is None:
        return {"ok": False, "error": "no_active_window"}
    out=[]
    try:
        for e in _elements(w, max_depth)[:limit]:
            try:
                r=e.rectangle()
                out.append({
                    "name": e.window_text(),
                    "control_type": e.element_info.control_type,
                    "automation_id": e.element_info.automation_id,
                    "class_name": e.element_info.class_name,
                    "enabled": bool(e.is_enabled()),
                    "visible": bool(e.is_visible()),
                    "rect": {"left":r.left,"top":r.top,"right":r.right,"bottom":r.bottom},
                })
            except Exception:
                continue
        return {"ok":True,"window":w.window_text(),"elements":out}
    except Exception as e:
        return {"ok":False,"error":str(e)}


def find(target: str, control_type: str|None=None, window=None):
    w=window or active_window()
    if w is None: return None
    target=_norm(target)
    best=None; best_score=-1
    for e in _elements(w):
        try:
            ct=e.element_info.control_type
            if control_type and _norm(ct)!=_norm(control_type): continue
            sc=_score(e.window_text(),target)
            if sc>best_score and e.is_visible():
                best,best_score=e,sc
        except Exception: continue
    return best if best_score>=50 else None


def _invoke(e):
    try:
        e.invoke(); return True
    except Exception:
        try:
            e.click_input(); return True
        except Exception:
            return False


def click(target: str, control_type: str|None=None):
    e=find(target,control_type)
    if e is None: return {"ok":False,"error":"uia_target_not_found","target":target}
    try:
        name=e.window_text(); ct=e.element_info.control_type
        ok=_invoke(e)
        return {"ok":ok,"backend":"uia","action":"click","target":name,"control_type":ct,
                "error":None if ok else "uia_invoke_failed"}
    except Exception as ex: return {"ok":False,"error":str(ex)}


def type_into(target: str, text: str):
    e=find(target, "Edit") or find(target)
    if e is None: return {"ok":False,"error":"uia_input_not_found","target":target}
    try:
        e.set_focus()
        try: e.set_edit_text(text)
        except Exception:
            e.type_keys("^a", with_spaces=True); e.type_keys(text, with_spaces=True)
        time.sleep(.15)
        observed=e.window_text()
        verified=(str(text).strip().lower() in str(observed).strip().lower()) if text.strip() else True
        return {"ok":verified,"executed":True,"backend":"uia","action":"type","target":observed,"verified":verified,
                **({} if verified else {"error":"uia_type_not_verified"})}
    except Exception as ex: return {"ok":False,"error":str(ex)}


def click_button(target: str): return click(target, "Button")


def get_text(target: str|None=None):
    e=find(target) if target else active_window()
    if e is None: return {"ok":False,"error":"uia_target_not_found"}
    try:
        txt=e.window_text()
        return {"ok":True,"backend":"uia","text":txt,"target":txt}
    except Exception as ex: return {"ok":False,"error":str(ex)}


def action(command: str):
    c=command.strip()
    # Explicit target forms. Keep this conservative: no guessing on destructive actions.
    m=re.search(r"\b(?:click|press|activate|invoke)\s+(?:the\s+)?(?:button\s+)?[\"']?(.+?)[\"']?$",c,re.I)
    if m and not re.search(r"\b(?:double|right|middle)\s*click",c,re.I):
        target=m.group(1).strip(" .\"'")
        r=click(target)
        if r.get("ok"): return r
    m=re.search(r"\b(?:type|enter|fill)\s+[\"'](.+?)[\"']\s+(?:into|in)\s+(?:the\s+)?(?:field|box|input)\s+[\"']?(.+?)[\"']?$",c,re.I)
    if m:
        return type_into(m.group(2).strip(),m.group(1))
    m=re.search(r"\b(?:click|press)\s+(?:the\s+)?button\s+[\"']?(.+?)[\"']?$",c,re.I)
    if m: return click_button(m.group(1).strip(" .\"'"))
    return {"ok":False,"error":"no_unambiguous_uia_action"}
