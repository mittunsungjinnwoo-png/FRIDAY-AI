"""FRIDAY 5.0 voice engine tests (no microphone needed): python FRIDAY_TEST_V5_VOICE.py"""
import sys, time, queue, threading
import numpy as np
sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
import friday_voice5 as v5

rng = np.random.default_rng(1)
def noise(ms, amp=30):
    return (rng.normal(0, amp, int(16000*ms/1000))).astype(np.int16)
def speech(ms, amp=4000):
    n = int(16000*ms/1000); t = np.arange(n)/16000
    s = amp*(np.sin(2*np.pi*180*t)+0.6*np.sin(2*np.pi*720*t)+0.3*np.sin(2*np.pi*2400*t))*(0.6+0.4*np.sin(2*np.pi*4*t))
    return (s/1.9 + rng.normal(0, 40, n)).astype(np.int16)
def frames(sig):
    b = sig.tobytes()
    return [b[i:i+v5.FRAME_BYTES] for i in range(0, len(b)-v5.FRAME_BYTES+1, v5.FRAME_BYTES)]

def run_seg(sig, tts=False):
    seg = v5.Segmenter(); out = []
    for f in frames(sig): out += seg.feed(f, tts_active=tts)
    return out

fails = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: fails.append(name)

# 1 single utterance -> spec then final, speech not clipped
ev = run_seg(np.concatenate([noise(600), speech(1200), noise(1000)]))
kinds = [e.kind for e in ev]
check("start/spec/final order", kinds == ["start", "spec", "final"])
fin = [e for e in ev if e.kind == "final"][0]
check("final audio holds the speech (>=1.2 s)", len(fin.pcm)/32000 >= 1.2)
check("trailing silence trimmed (<1.9 s)", len(fin.pcm)/32000 < 1.9)

# 2 pause mid-sentence shorter than commit -> resume, ONE final containing both parts
ev = run_seg(np.concatenate([noise(500), speech(800), noise(380), speech(800), noise(1000)]))
kinds = [e.kind for e in ev]
check("mid-sentence pause resumes", kinds.count("final") == 1 and "resume" in kinds)
check("both halves in the one utterance", [e for e in ev if e.kind=="final"][0].duration >= 1.9)

# 3 pure noise -> nothing
ev = run_seg(noise(3000, amp=60))
check("noise only -> no events", ev == [])

# 4 short click dropped
ev = run_seg(np.concatenate([noise(500), speech(60), noise(900)]))
check("click is ignored", not any(e.kind == "final" for e in ev))

# 5 speaking mode needs louder speech
quiet = np.concatenate([noise(500), speech(1000, amp=1200), noise(900)])
check("quiet speech accepted when idle", any(e.kind == "final" for e in run_seg(quiet)))
check("quiet speech (echo level) rejected while FRIDAY speaks", not any(e.kind == "final" for e in run_seg(quiet, tts=True)))
loud = np.concatenate([noise(500), speech(1000, amp=9000), noise(900)])
ev = run_seg(loud, tts=True)
check("loud interruption accepted while speaking, flagged", any(e.kind == "final" and e.speaking for e in ev))

# 6 commit latency: final fires <= 0.6 s after speech stops
seg = v5.Segmenter(); sig = np.concatenate([noise(500), speech(1000)]); n_sp = len(frames(sig)); t = None
for i, f in enumerate(frames(np.concatenate([sig, noise(1500)]))):
    for e in seg.feed(f):
        if e.kind == "final": t = (i - n_sp) * 0.02
check("endpoint latency <= 0.62 s (old: 1.05 s)", t is not None and t <= 0.62)
print("   endpoint latency: %.2f s" % t)

# 7 wake word
check("wake: hey friday open chrome", v5.find_wake("hey friday open chrome") == (True, "open chrome"))
check("wake: fryday", v5.find_wake("Fryday what time is it")[0])
check("wake: absent", not v5.find_wake("open chrome please")[0])
check("standby: wake at the end", v5.find_wake("open chrome friday", anywhere=True) == (True, "open chrome"))
check("active: day name 'friday' is NOT stripped", v5.find_wake("what is on my calendar for friday") == (False, "what is on my calendar for friday"))
check("stop words", v5.STOP_WORDS.match("stop talking") and not v5.STOP_WORDS.match("stop the music and play jazz"))
check("hallucination filter", v5.looks_like_hallucination("Thank you.", 0.5, 200) and not v5.looks_like_hallucination("open chrome", 1.0, 900))

# 8 recognizer race: slow local, fast cloud -> cloud wins quickly; cloud offline -> local
def slow_local(p): time.sleep(0.6); return v5.Recognition("local text", 0.9, "local")
def fast_cloud(p): time.sleep(0.05); return v5.Recognition("cloud text", 0.8, "cloud")
def bad_cloud(p): raise RuntimeError("offline")
t0 = time.time(); r = v5.Recognizer(slow_local, fast_cloud).transcribe(b"\0"*3200)
check("race: fast engine wins", r.text == "cloud text" and time.time()-t0 < 0.4)
r = v5.Recognizer(slow_local, bad_cloud).transcribe(b"\0"*3200)
check("race: falls back to local", r.text == "local text")
r = v5.Recognizer(slow_local, fast_cloud).transcribe(b"\0"*3200, wake_check=lambda t: "local" in t)
check("race: wake gate prefers the result containing the wake word", r.text == "local text")

# 9 full engine with fake mic: standby -> wake -> command -> barge-in
class FakeMic:
    def __init__(s, sig): s.q = queue.Queue(); [s.q.put(f) for f in frames(sig)]; s.end = threading.Event()
    def read(s, timeout=0.5):
        try: return s.q.get(timeout=0.01)
        except queue.Empty: time.sleep(0.01); return None
    def alive(s): return True
    def close(s): pass
state = {"active": False, "spoken": [], "interrupts": 0}
speaking = {"v": False}
h = v5.Hooks(is_active=lambda: state["active"], set_active=lambda a, r="": state.update(active=a),
             speak=lambda t: state["spoken"].append(t), is_speaking=lambda: speaking["v"],
             interrupt=lambda: state.update(interrupts=state["interrupts"]+1), emit=lambda l: None)
script = iter(["what time is it", "friday open chrome", "play some music", "stop"])
def stt(p): time.sleep(0.05); return v5.Recognition(next(script), 0.9, "local")
sig = np.concatenate([noise(500)] + [np.concatenate([speech(900), noise(900)]) for _ in range(4)])
eng = v5.VoiceEngine(h, v5.Recognizer(stt, None), mic=FakeMic(sig)); eng.start()
got = []
t0 = time.time()
while time.time()-t0 < 12 and len(got) < 2:
    c = eng.get_command(0.3)
    if c: got.append(c)
time.sleep(0.5)
check("standby ignored 'what time is it', accepted 'friday open chrome'", got[:1] == ["open chrome"])
check("then active: next command without wake word", got[:2] == ["open chrome", "play some music"])
check("'stop' interrupts, is not queued", state["interrupts"] >= 1 and eng.get_command(0.2) is None)
eng.stop()
print("\n%d failure(s)" % len(fails)); sys.exit(1 if fails else 0)
