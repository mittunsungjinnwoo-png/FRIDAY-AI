"""Offline regression tests for FRIDAY v2040 MAX intelligence layer."""
from pathlib import Path
import hashlib
import py_compile
import friday_intelligence_hub as h

ROOT = Path(__file__).resolve().parent

# Protected mechanisms: compare against the supplied v2038 baseline mounted by the upgrade process.
BASE = Path('/mnt/data/friday_orig/j2032_final')
for name in ('friday_voice_engine.py', 'friday_backend.py'):
    cur = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
    base = hashlib.sha256((BASE/name).read_bytes()).hexdigest()
    assert cur == base, f'{name} changed: {cur} != {base}'

for p in ROOT.glob('*.py'):
    py_compile.compile(str(p), doraise=True)

x = h.analyze_request('research the latest AI safety developments and create a PDF report')
assert 'research' in x['intents'] and 'creation' in x['intents']
assert x['requires_verification'] is True
assert h.build_execution_blueprint(x['command'])['phases'][-2:] == ['verify', 'respond']

r = h.audit_research({'sources': [
    {'url': 'https://www.nist.gov/example', 'title': 'NIST', 'text': 'x '*300},
    {'url': 'https://www.nature.com/example', 'title': 'Nature', 'text': 'y '*300},
]})
assert r['unique_domains'] == 2 and r['source_diversity'] > 0

print('V2040_MAX_INTELLIGENCE=PASS')
print('PROTECTED_VOICE_BACKEND=PASS')
