"""FRIDAY quality/reliability layer (v2024).

Keeps the existing voice-listening/recognition path untouched.  This module
hardens the non-voice feature layer with bounded retries, timing metrics,
result normalization and conservative post-condition checks.
"""
from __future__ import annotations
import json, os, threading, time
from collections import defaultdict, deque
from pathlib import Path

_LOCK = threading.RLock()
_METRICS = defaultdict(lambda: {"calls": 0, "ok": 0, "failed": 0, "latency_ms": deque(maxlen=50), "last_error": ""})
_STATE = Path(__file__).resolve().parent / "friday_quality_state.json"


def _save():
    try:
        data = {}
        for k, v in _METRICS.items():
            vals = list(v["latency_ms"])
            data[k] = {"calls": v["calls"], "ok": v["ok"], "failed": v["failed"],
                       "avg_latency_ms": round(sum(vals) / len(vals), 1) if vals else 0.0,
                       "last_error": v["last_error"]}
        tmp = _STATE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(tmp, _STATE)
    except Exception:
        pass


def run(name, fn, attempts=2, delay=0.35, verify=None):
    """Run a non-destructive feature with bounded retry + optional verification."""
    attempts = max(1, min(3, int(attempts)))
    last = None
    for n in range(attempts):
        started = time.perf_counter()
        with _LOCK:
            _METRICS[name]["calls"] += 1
        try:
            result = fn()
            if verify is not None and not bool(verify(result)):
                raise RuntimeError("post-condition verification failed")
            elapsed = (time.perf_counter() - started) * 1000
            with _LOCK:
                _METRICS[name]["ok"] += 1
                _METRICS[name]["latency_ms"].append(elapsed)
            _save()
            return result
        except Exception as exc:
            last = exc
            with _LOCK:
                _METRICS[name]["failed"] += 1
                _METRICS[name]["last_error"] = str(exc)[:300]
            if n + 1 < attempts:
                time.sleep(delay * (n + 1))
    _save()
    raise last


def result_ok(result):
    if result is True:
        return True
    if isinstance(result, dict):
        if result.get("ok") is False:
            return False
        if result.get("verified") is False:
            return False
        if result.get("handled") is False:
            return False
        return bool(result.get("ok") or result.get("verified") or result.get("handled") or result.get("result") is not None)
    return bool(result)


def health():
    with _LOCK:
        out = {}
        for name, v in _METRICS.items():
            vals = list(v["latency_ms"])
            calls = v["calls"]
            out[name] = {"calls": calls, "success_rate": round(v["ok"] / calls, 3) if calls else None,
                         "avg_latency_ms": round(sum(vals) / len(vals), 1) if vals else None,
                         "last_error": v["last_error"]}
        return out
