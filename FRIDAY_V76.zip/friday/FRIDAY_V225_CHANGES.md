# FRIDAY V2.2.5 - faster speech (same voice, same everything else)

Problem: the reply text appeared quickly in chat, but the spoken voice started late.

Cause: for EVERY sentence the old path started a brand-new Python process (re-importing the voice library),
waited for the whole audio file to be made, started a brand-new PowerShell (re-loading the Windows media
libraries), and only began the next sentence after the previous one had finished playing.

## What changed (speech output only)
- The voice library stays loaded inside FRIDAY; one audio player stays resident and is started at launch.
- The next sentence's audio is prepared while the current sentence is still playing, so gaps between sentences shrink to almost nothing.
- Multi-part replies prepare their following parts ahead of time too.
- SAME voice, SAME rate/pitch, SAME text cleaning, SAME "Sir"/address handling, SAME reactor SPEAK_START/SPEAK_END timing, SAME mute behaviour.
- Safety net: any failure in the fast path falls back to the original one-process-per-sentence code (kept unchanged as `_run_edge_tts_legacy`).
  After 3 failures in a row it uses the old path for 2 minutes, then tries the fast path again.
- Switch off if ever needed: set environment variable FRIDAY_FAST_TTS=0.

## Files changed
`friday_backend.py` (speech output section + the sentence queue), `package.json` (2.2.5), this note.
Nothing in the UI, Settings, listening, recognition, finance, notes, Gemini connection or uninstall code was touched.
