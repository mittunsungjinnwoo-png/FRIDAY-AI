/* FRIDAY 7.0 - chat attachments, file cards, live HUD, benchmark and permissions.
   Loaded after the main page script. It builds on the existing chat (msg / cmd / think / view / render) and never
   replaces the voice, speech or finance code. */
(function () {
  'use strict';
  var B = window.fridayBridge;
  var $ = function (s) { return document.querySelector(s); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var dec = function (b) { try { return decodeURIComponent(escape(atob(b))); } catch (e) { return atob(b); } };

  /* ---------------------------------------------------------------- styles */
  var css = document.createElement('style');
  css.textContent = [
    '#chips5{display:flex;flex-wrap:wrap;gap:8px;padding:0 0 4px}#chips5:empty{display:none}',
    '.fc5{display:flex;align-items:center;gap:9px;padding:6px 8px 6px 6px;border:1px solid var(--k3);border-radius:var(--r3);background:var(--p);max-width:260px;position:relative}',
    '.fc5 .th{width:34px;height:34px;border-radius:7px;background:var(--s1);display:grid;place-items:center;overflow:hidden;flex:none;font-size:10px;letter-spacing:.5px;color:var(--a2);font-weight:600}',
    '.fc5 .th img{width:100%;height:100%;object-fit:cover}',
    '.fc5 .tx{min-width:0;display:flex;flex-direction:column;line-height:1.2}.fc5 .tx b{font-weight:500;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:170px}.fc5 .tx small{color:var(--m);font-size:11px}',
    '.fc5 .rm{margin-left:2px;color:var(--m);padding:2px 5px;border-radius:50%}.fc5 .rm:hover{background:var(--hov);color:var(--t)}',
    '.fc5.out{border-color:var(--a);box-shadow:0 0 10px var(--a22);max-width:none}.fc5.out .tx b{max-width:240px}.fc5.out .bt button{white-space:nowrap}.fc5.out .bt{display:flex;gap:4px;margin-left:6px}',
    '.fc5 .bt button{font-size:11px;padding:3px 8px;border:1px solid var(--k3);border-radius:6px;color:var(--a2)}.fc5 .bt button:hover{border-color:var(--a);background:var(--hov)}',
    '.fcards{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}',
    '#qa5{display:flex;flex-wrap:wrap;gap:6px}#qa5:empty{display:none}#qa5 button{font-size:12px;padding:4px 10px;border:1px solid var(--k3);border-radius:999px;color:var(--a2)}#qa5 button:hover{border-color:var(--a);background:var(--hov)}',
    '#drop5{position:absolute;inset:0;z-index:30;display:none;place-items:center;border:2px dashed var(--a);border-radius:var(--r1);background:var(--p3);opacity:.94;font-size:18px;letter-spacing:1px;color:var(--a2);pointer-events:none}',
    '#chat{position:relative}',
    '#hud5 h4{margin:0 0 8px;font-weight:500;display:flex;justify-content:space-between;align-items:center}',
    '#hud5 .hr{display:flex;justify-content:space-between;gap:10px;padding:3px 0;font-size:12.5px}#hud5 .hr span:first-child{color:var(--m);letter-spacing:.8px;font-size:10.5px;text-transform:uppercase;padding-top:2px}#hud5 .hr span:last-child{text-align:right;color:var(--t);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:62%}',
    '#hud5 .dot{width:9px;height:9px;border-radius:50%;background:var(--ok);display:inline-block;margin-right:8px;box-shadow:0 0 8px var(--ok)}#hud5 .dot.busy{background:var(--a);box-shadow:0 0 8px var(--a);animation:p5 1s infinite}',
    '@keyframes p5{50%{opacity:.35}}',
    '#hud5 .cb{height:5px;border-radius:3px;background:var(--k2);overflow:hidden;margin-top:2px}#hud5 .cb i{display:block;height:100%;background:linear-gradient(90deg,var(--a),var(--a2))}',
    '.bm5 td:nth-child(2),.bm5 th:nth-child(2){text-align:right}.bm5 .big{font-size:34px;font-weight:300;color:var(--a2)}'
  ].join('\n');
  document.head.appendChild(css);

  /* ---------------------------------------------------------------- pending attachments */
  var P5 = [];   // {path,name,size,url}
  var EXT_LABEL = { pdf: 'PDF', doc: 'DOC', docx: 'DOC', xls: 'XLS', xlsx: 'XLS', csv: 'CSV', ppt: 'PPT', pptx: 'PPT', py: 'PY', js: 'JS', ts: 'TS', html: 'HTML', css: 'CSS', json: 'JSON', txt: 'TXT', md: 'MD', zip: 'ZIP', mp3: 'AUD', wav: 'AUD', m4a: 'AUD', mp4: 'VID', mov: 'VID', mkv: 'VID', java: 'JAVA', c: 'C', cpp: 'C++', cs: 'C#' };
  var IMG = /\.(png|jpe?g|gif|webp|bmp|svg)$/i;
  function ext(n) { var m = /\.([A-Za-z0-9]+)$/.exec(n || ''); return m ? m[1].toLowerCase() : ''; }
  function human(n) { n = +n || 0; return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : n > 1024 ? Math.round(n / 1024) + ' KB' : n + ' B'; }
  function thumb(f) {
    if (f.url) return '<img src="' + esc(f.url) + '">';
    return esc(EXT_LABEL[ext(f.name)] || ext(f.name).toUpperCase().slice(0, 4) || 'FILE');
  }
  function cardHTML(f, removable, idx) {
    return '<div class="fc5"><div class="th">' + thumb(f) + '</div><div class="tx"><b title="' + esc(f.name) + '">' + esc(f.name) + '</b><small>' + (f.size ? human(f.size) : (ext(f.name) || 'file').toUpperCase()) + '</small></div>' +
      (removable ? '<button class="rm" data-i="' + idx + '" title="Remove">&#10005;</button>' : '') + '</div>';
  }
  function renderChips() {
    var host = $('#chips5');
    if (!host) return;
    host.innerHTML = P5.map(function (f, i) { return cardHTML(f, true, i); }).join('');
    host.querySelectorAll('.rm').forEach(function (b) { b.onclick = function () { P5.splice(+b.dataset.i, 1); renderChips(); }; });
    var qa = $('#qa5');
    if (qa) {
      var hasCode = P5.some(function (f) { return /^(py|js|ts|java|c|cpp|cs|html|css|json)$/.test(ext(f.name)); });
      var hasData = P5.some(function (f) { return /^(csv|xlsx|xls|tsv)$/.test(ext(f.name)); });
      var hasImg = P5.some(function (f) { return IMG.test(f.name); });
      var list = !P5.length ? [] : ['Summarise this'].concat(hasCode ? ['Find and fix the bugs', 'Explain this code'] : hasData ? ['Analyse the numbers', 'Make a chart-ready summary'] : hasImg ? ['What is in this picture?', 'Read the text in it'] : ['Explain this simply', 'List the key points']);
      qa.innerHTML = list.map(function (t) { return '<button>' + esc(t) + '</button>'; }).join('');
      qa.querySelectorAll('button').forEach(function (b) { b.onclick = function () { var i = $('#ti'); i.value = b.textContent; send5(); }; });
    }
  }
  function addPath(p, fileObj) {
    if (!p || P5.some(function (x) { return x.path === p; })) return;
    var name = p.split(/[\\/]/).pop();
    var url = '';
    try { if (IMG.test(name)) url = fileObj ? URL.createObjectURL(fileObj) : 'file:///' + p.replace(/\\/g, '/'); } catch (e) {}
    P5.push({ path: p, name: name, size: fileObj ? fileObj.size : 0, url: url });
  }
  async function addFileObjects(list) {
    var files = Array.prototype.slice.call(list || []);
    for (var i = 0; i < files.length; i++) {
      var f = files[i], p = '';
      try { p = B && B.pathFor ? B.pathFor(f) : ''; } catch (e) {}
      if (!p && B && B.saveTemp) {   // dragged from a browser / pasted screenshot: no path on disk, so keep a copy
        var b64 = await new Promise(function (res) { var r = new FileReader(); r.onload = function () { res(String(r.result).split(',')[1] || ''); }; r.onerror = function () { res(''); }; r.readAsDataURL(f); });
        p = await B.saveTemp(f.name || ('pasted.' + (ext(f.type.replace('/', '.')) || 'png')), b64);
      }
      if (p) addPath(p, f);
    }
    renderChips();
    var t = $('#ti'); if (t) t.focus();
  }
  async function pick5() {
    if (!B || !B.pickFiles) { var fi = $('#fi5'); if (fi) fi.click(); return; }
    try {
      var paths = await B.pickFiles();
      (paths || []).forEach(function (p) { addPath(p, null); });
      renderChips();
      var t = $('#ti'); if (t) t.focus();
    } catch (e) { if (typeof toast === 'function') toast('Could not attach: ' + (e.message || e)); }
  }

  /* ---------------------------------------------------------------- sending */
  var origCmd = window.cmd;
  function bubbleWithFiles(t, files) {
    var b = msg(t || ('Attached ' + files.length + ' file' + (files.length > 1 ? 's' : '')), 1);
    var box = document.createElement('div');
    box.className = 'fcards';
    box.innerHTML = files.map(function (f) { return cardHTML(f, false); }).join('');
    b.appendChild(box);
    $('#msgs').scrollTop = 1e9;
    return b;
  }
  function send5() {
    var i = $('#ti'), t = (i.value || '').trim();
    if (!t && !P5.length) return;
    i.value = '';
    if (!P5.length) { return origCmd(t); }
    var files = P5.slice();
    P5 = []; renderChips();
    bubbleWithFiles(t, files);
    try { X.m.cmds++; log('Attached ' + files.map(function (f) { return f.name; }).join(', ')); } catch (e) {}
    if (!B) { msg('File reading needs the desktop app.'); return; }
    think();
    lastT = performance.now();
    B.sendCommand(t, files.map(function (f) { return f.path; }));
  }
  window.sendTyped = send5;

  /* ---------------------------------------------------------------- wiring */
  function init() {
    var ib = document.querySelector('.ib');
    if (!ib || $('#chips5')) return;
    var chips = document.createElement('div'); chips.id = 'chips5';
    var qa = document.createElement('div'); qa.id = 'qa5';
    ib.insertBefore(qa, ib.firstChild);
    ib.insertBefore(chips, ib.firstChild);
    var fi = document.createElement('input'); fi.type = 'file'; fi.multiple = true; fi.hidden = true; fi.id = 'fi5';
    fi.onchange = function (e) { addFileObjects(e.target.files); e.target.value = ''; };
    document.body.appendChild(fi);
    var clip = $('#clip'), pa = $('#pa');
    if (clip) { clip.onclick = pick5; clip.title = 'Attach files to this message'; }
    if (pa) pa.onclick = pick5;
    $('#sd').onclick = send5;
    $('#ti').onkeydown = function (e) { if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); send5(); } };
    $('#ti').placeholder = 'Ask me anything...';
    // drag & drop anywhere on the chat
    var chat = document.body, drop = document.createElement('div');   /* new HUD: the drop zone covers the whole window */
    drop.id = 'drop5'; drop.textContent = 'Drop files to attach them to your message';
    chat.appendChild(drop);
    var depth = 0;
    ['dragenter', 'dragover'].forEach(function (ev) { chat.addEventListener(ev, function (e) { if (e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') >= 0) { e.preventDefault(); drop.style.display = 'grid'; } }); });
    chat.addEventListener('dragenter', function () { depth++; });
    chat.addEventListener('dragleave', function () { depth = Math.max(0, depth - 1); if (!depth) drop.style.display = 'none'; });
    chat.addEventListener('drop', function (e) { e.preventDefault(); depth = 0; drop.style.display = 'none'; if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) { if (typeof view === 'function' && typeof V !== 'undefined' && V !== 'Home') view('Home'); addFileObjects(e.dataTransfer.files); } });
    // paste screenshots / copied files straight into the message box
    $('#ti').addEventListener('paste', function (e) {
      var fl = e.clipboardData && e.clipboardData.files;
      if (fl && fl.length) { e.preventDefault(); addFileObjects(fl); }
    });
    // HUD panel
    var aside = document.querySelector('aside');
    if (aside && !$('#hud5')) {
      var h = document.createElement('div'); h.className = 'p'; h.id = 'hud5';
      aside.insertBefore(h, aside.firstChild);
      renderHud({});
    }
  }

  /* ---------------------------------------------------------------- HUD */
  var HUD = {};
  function renderHud(o) {
    HUD = Object.assign(HUD, o || {});
    var h = $('#hud5'); if (!h) return;
    var busy = HUD.core && !/^ready$/i.test(HUD.core);
    var conf = HUD.confidence == null ? null : Math.round(HUD.confidence * 100);
    h.innerHTML = '<h4><span><i class="dot ' + (busy ? 'busy' : '') + '"></i>FRIDAY 7.0 Core</span><span class="note" style="margin:0">' + esc(HUD.core || 'Ready') + '</span></h4>' +
      '<div class="hr"><span>Route</span><span>' + esc(HUD.route || '-') + '</span></div>' +
      '<div class="hr"><span>Tool</span><span>' + esc(HUD.tool || '-') + '</span></div>' +
      '<div class="hr"><span>Task</span><span title="' + esc(HUD.task || '') + '">' + esc(HUD.task || '-') + '</span></div>' +
      '<div class="hr"><span>Memory</span><span title="' + esc((HUD.memory || []).join(' | ')) + '">' + ((HUD.memory || []).length ? esc(HUD.memory[0]) + ((HUD.memory.length > 1) ? ' +' + (HUD.memory.length - 1) : '') : '-') + '</span></div>' +
      '<div class="hr"><span>Reply</span><span>' + (HUD.latency_ms != null ? (HUD.latency_ms / 1000).toFixed(2) + ' s' : '-') + '</span></div>' +
      '<div class="hr"><span>Confidence</span><span>' + (conf == null ? '-' : conf + '%') + '</span></div>' + (conf == null ? '' : '<div class="cb"><i style="width:' + conf + '%"></i></div>');
  }

  /* ---------------------------------------------------------------- backend lines */
  function fileOut(card) {
    var row = document.createElement('div');
    row.className = 'mr f';
    row.innerHTML = '<span class="orb"></span><div class="mc2"><small><b>' + esc((window.Theme && Theme.cfg && Theme.cfg.assistant.name) || 'FRIDAY') + '</b>' + (typeof tm === 'function' ? tm() : '') + '</small><div class="m"><div style="margin-bottom:6px">Created a file for you:</div><div class="fc5 out"><div class="th">' + esc(EXT_LABEL[ext(card.name)] || ext(card.name).toUpperCase().slice(0, 4) || 'FILE') + '</div><div class="tx"><b>' + esc(card.name) + '</b><small>' + human(card.size) + '</small></div><div class="bt"><button data-a="open">Open</button><button data-a="save">Save as...</button><button data-a="show">Show</button></div></div></div></div>';
    row.querySelectorAll('button').forEach(function (b) {
      b.onclick = async function () {
        if (!B) return;
        if (b.dataset.a === 'open') B.openPath(card.path);
        else if (b.dataset.a === 'show') B.revealPath(card.path);
        else { var r = await B.saveFileAs(card.path); if (r && r.ok && typeof toast === 'function') toast('Saved to ' + r.path); }
      };
    });
    $('#msgs').appendChild(row);
    $('#msgs').scrollTop = 1e9;
    try { X.files.unshift({ id: uid(), name: card.name, size: card.size, at: Date.now(), saved: 1 }); log('FRIDAY created ' + card.name); sx(); } catch (e) {}
  }
  function benchModal(r) {
    var rows = Object.keys(r.categories).map(function (k) { var c = r.categories[k]; return '<tr><td>' + esc(k) + (c.failed.length ? '<br><small class="bad">' + esc(c.failed.join('; ')) + '</small>' : '') + '</td><td class="' + (c.score === 100 ? 'ok' : 'bad') + '">' + c.passed + '/' + c.total + '</td></tr>'; }).join('');
    var hist = (r.history || []).map(function (h) { return h.version + ' → ' + h.score + '/100'; }).join('&nbsp;&nbsp;·&nbsp;&nbsp;');
    mod('FRIDAY Benchmark', '<div class="bm5"><div class="big">' + r.score + '<small style="font-size:16px;color:var(--m)"> / 100</small></div><p class="note">FRIDAY ' + esc(r.version) + ' · ' + esc(r.at) + '</p><table><tr><th>Category</th><th>Passed</th></tr>' + rows + '</table><p class="note">' + hist + '</p><p class="note">Not measured here: ' + esc((r.not_measured || []).join('; ')) + '.</p></div>');
  }
  if (B && B.onLine) {
    B.onLine(function (l) {
      if (typeof l !== 'string') return;
      try {
        if (l.indexOf('FRIDAY_HUD::') === 0) renderHud(JSON.parse(dec(l.slice(12))));
        else if (l.indexOf('FRIDAY_FILE::') === 0) fileOut(JSON.parse(dec(l.slice(13))));
        else if (l.indexOf('FRIDAY_BENCH::') === 0) { var r = JSON.parse(dec(l.slice(14))); window._bench5 = r; benchModal(r); if (typeof V !== 'undefined' && V === 'Tools') render(); }
        else if (l.indexOf('FRIDAY_STATUS5::') === 0) {
          window._st5 = JSON.parse(dec(l.slice(16)));
          if (typeof V !== 'undefined' && V === 'Tools') render();
          else if (typeof V !== 'undefined' && V === 'Settings') { var pp = document.getElementById('perm5'); if (pp) pp.outerHTML = perm5Html(); }   /* V6.0.1: never rebuild the whole Settings page (it swallowed clicks) */
        }
        else if (l.indexOf('FRIDAY_ATTACHMENTS_READY::') === 0) {
          var a = JSON.parse(dec(l.slice(26)));
          if (typeof toast === 'function') toast('FRIDAY read ' + a.count + ' file' + (a.count === 1 ? '' : 's'));
        }
      } catch (e) { console.warn('[friday5]', e); }
    });
    B.onBackendReady && B.onBackendReady(function () { setTimeout(function () { B.status5 && B.status5(); }, 1500); });
  }

  /* ---------------------------------------------------------------- Tools + Settings pages */
  var _tools = window.toolsV;
  window.toolsV = function (e) {
    _tools(e);
    var st = window._st5 || {}, v = st.voice || {}, sp = st.speech || {}, kn = st.knowledge || {};
    var tl = (st.tools || []).map(function (t) { return '<tr><td style="text-align:left">' + esc(t.name) + '</td><td>' + esc(t.risk === 'safe' ? 'runs at once' : 'asks first') + '</td><td class="' + (t.enabled ? 'ok' : 'bad') + '">' + (t.enabled ? 'allowed' : 'blocked') + '</td></tr>'; }).join('');
    var b = window._bench5;
    e.insertAdjacentHTML('beforeend',
      '<h4>FRIDAY 7.0 engine</h4><table><tr><th>Part</th><th>Status</th></tr>' +
      '<tr><td>Listening</td><td>' + (v.running ? 'continuous, ' + (v.webrtcvad ? 'WebRTC VAD' : 'energy VAD') + (v.last && v.last.stt_ms ? ', last recognition ' + v.last.stt_ms + ' ms (' + esc(v.last.source) + ')' : '') : 'starts with the first listen') + '</td></tr>' +
      '<tr><td>Speaking</td><td>' + (sp.usable ? 'in-memory, parallel, interruptible' : 'previous path') + (sp.last && sp.last.first_audio_ms ? ', first audio ' + sp.last.first_audio_ms + ' ms' : '') + '</td></tr>' +
      '<tr><td>Average reply time</td><td>' + (st.avg_latency_ms ? (st.avg_latency_ms / 1000).toFixed(2) + ' s' : '-') + '</td></tr>' +
      '<tr><td>Long-term memory</td><td>' + (kn.memories != null ? kn.memories + ' memories, ' + kn.kb_chunks + ' document passages, ' + kn.goals + ' goals' : '-') + '</td></tr></table>' +
      '<h4>Tool permissions</h4><table><tr><th>Tool</th><th>Mode</th><th>Permission</th></tr>' + (tl || '<tr><td colspan="3" class="note">Connect the desktop app to see tools.</td></tr>') + '</table>' +
      '<div class="row"><button class="btn" onclick="window._runBench5()">Run FRIDAY benchmark</button><button class="btn g" onclick="window.fridayBridge&&fridayBridge.status5()">Refresh</button></div>' +
      (b ? '<p class="note">Last FRIDAY benchmark: ' + b.score + '/100 (' + esc(b.at) + ')</p>' : ''));
  };
  window._runBench5 = function () { if (!B || !B.bench5) return toast('The benchmark needs the desktop app'); toast('Running the benchmark...'); B.bench5(); };
  /* V6.0.1: the FRIDAY 7.0 tool permissions live in Settings > General inside <div id="perm5">.
     A status update refreshes only that block, so the Settings page is never rebuilt under the user's mouse. */
  var PERM_MAP = { 'System monitor': 'system_info', 'Read & search files': 'read_files', 'Create files': 'write_files', 'Run code': 'run_code', 'Delete files': 'delete_files' };
  function perm5Html() {
    var st = window._st5 || {}, tools = st.tools || [];
    return '<div id="perm5"><h4>FRIDAY 7.0 tool permissions</h4><p class="note">What FRIDAY may do on her own. Anything that changes something asks for a yes first. You can also say "revoke file writing" or "allow code running".</p>' +
      (tools.length ? tools.map(function (t) { return '<div class="li"><label><input type="checkbox" ' + (t.enabled ? 'checked' : '') + ' onchange="fridayBridge.setPerm(\'' + PERM_MAP[t.name] + '\',this.checked)"> ' + esc(t.name) + ' <small class="note">(' + (t.risk === 'safe' ? 'runs at once' : 'asks first') + ')</small></label></div>'; }).join('') : '<p class="note">FRIDAY is still starting. This list fills in by itself in a moment.</p>') + '</div>';
  }
  window.fridaySettingsGeneralExtra = function () {
    if (!window._st5 && B && B.status5) { try { B.status5(); } catch (x) {} }
    return perm5Html();
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
