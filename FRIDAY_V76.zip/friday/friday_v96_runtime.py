"""
FRIDAY v96 Unified Runtime
===========================
A defensive orchestration layer implementing the architecture in the FRIDAY
upgrade blueprint: event bus, persistent task graph, tool contracts,
permissions, multi-agent roles, closed-loop computer/vision helpers,
research-quality packaging, diagnostics and proactive monitoring.

The module is deliberately additive. Existing FRIDAY handlers remain the
source of truth for mature features; this runtime coordinates them and
degrades gracefully when optional dependencies are absent.
"""
from __future__ import annotations
import concurrent.futures, datetime as dt, json, os, re, subprocess, threading, time, traceback, uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Optional

ROOT=Path(__file__).resolve().parent
STATE_FILE=ROOT/"friday_v96_runtime.json"
PROACTIVE_FILE=ROOT/"friday_v96_proactive.json"
TASK_FILE=ROOT/"friday_v96_tasks.json"
LOG_FILE=ROOT/"friday_v96_actions.jsonl"
MAX_TASKS=1000
MAX_EVENTS=500
EXECUTOR=concurrent.futures.ThreadPoolExecutor(max_workers=max(4, min(12, (os.cpu_count() or 4)+2)), thread_name_prefix="FRIDAY-v96")
LOCK=threading.RLock()
EVENTS=[]
TOOLS={}
TASKS={}
_STOP=threading.Event()
_BG_STARTED=False

def _now(): return time.time()
def _iso(): return dt.datetime.now().isoformat(timespec="seconds")
def _load(p, default):
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default
    except Exception: return default
def _save(p, value):
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp=p.with_suffix(p.suffix+".tmp"); tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8"); os.replace(tmp,p)
    except Exception: pass

_state=_load(STATE_FILE, {"schema":1,"safe_mode":True,"proactive":False,"started_at":_now(),"last_health":None})
_proactive=_load(PROACTIVE_FILE, {"enabled":True,"quiet_minutes":30,"cooldown_seconds":300,"notify_level":"important","monitor_window":True,"monitor_tasks":True,"monitor_system":True,"last_notifications":{},"last_window":None,"last_window_at":0,"baseline_ts":_now(),"download_snapshot":{}})
if not PROACTIVE_FILE.exists():
    _save(PROACTIVE_FILE,_proactive)
_state["proactive"] = bool(_proactive.get("enabled", False))
for t in _load(TASK_FILE, []):
    if isinstance(t,dict) and t.get("id"): TASKS[t["id"]]=t

def emit(event:str, **data):
    payload={"id":uuid.uuid4().hex,"event":event,"ts":_iso(),**data}
    with LOCK:
        EVENTS.append(payload); del EVENTS[:-MAX_EVENTS]
    try:
        print("FRIDAY_EVENT::"+json.dumps(payload,ensure_ascii=False),flush=True)
    except Exception: pass
    try:
        with LOG_FILE.open("a",encoding="utf-8") as f: f.write(json.dumps(payload,ensure_ascii=False)+"\n")
    except Exception: pass
    return payload

# ---------------- Event bus ----------------
class EventBus:
    def __init__(self): self._subs={}; self._lock=threading.RLock()
    def subscribe(self,event,fn):
        with self._lock: self._subs.setdefault(event,[]).append(fn)
    def publish(self,event,**data):
        emit(event,**data)
        with self._lock: callbacks=list(self._subs.get(event,[]))+list(self._subs.get("*",[]))
        for fn in callbacks:
            EXECUTOR.submit(_safe_call,fn,{"event":event,**data})
BUS=EventBus()

def _safe_call(fn,*args,**kwargs):
    try:return fn(*args,**kwargs)
    except Exception:return None

# ---------------- Security ----------------
DANGEROUS_PATTERNS=(
 r"\bformat(?:\s+[a-z]:)?\b",r"\b(del|erase|rmdir|rd)\s+/s\b",r"\bremove\s+all\b",
 r"\b(delete|destroy|wipe|purge)\s+(?:all|everything|the entire|all files)\b",
 r"\bshutdown\b",r"\brestart\s+(?:the\s+)?(?:pc|computer|system)\b",
)
def permission_level(command:str)->tuple[int,str]:
    c=command.lower().strip()
    if any(re.search(p,c) for p in DANGEROUS_PATTERNS): return 4,"destructive"
    if re.search(r"\b(send|publish|post|email|whatsapp|message|purchase|pay)\b",c): return 3,"external"
    if re.search(r"\b(create|write|edit|save|move|rename|download|install)\b",c): return 2,"modify"
    if re.search(r"\b(open|launch|start|click|type|scroll|select|navigate|switch)\b",c): return 1,"desktop"
    return 0,"read"
def is_safe(command): return permission_level(command)[0] < 4

# ---------------- Tools ----------------
@dataclass
class Tool:
    name:str
    description:str
    permission:int=0
    timeout:float=60.0
    execute:Optional[Callable]=None
    verify:Optional[Callable]=None
    recover:Optional[Callable]=None

def register_tool(name,description,execute,permission=0,timeout=60,verify=None,recover=None):
    TOOLS[name]=Tool(name,description,permission,timeout,execute,verify,recover)
    return True
def tool_catalog(): return [{"name":t.name,"description":t.description,"permission":t.permission,"timeout":t.timeout} for t in TOOLS.values()]
def run_tool(name,**kwargs):
    t=TOOLS.get(name)
    if not t or not callable(t.execute): return {"ok":False,"error":"tool_not_registered"}
    emit("tool.started",tool=name,parameters={k:str(v)[:200] for k,v in kwargs.items()})
    try:
        result=t.execute(**kwargs)
        verified=True if not t.verify else bool(t.verify(result))
        if verified:
            emit("tool.completed",tool=name,verified=True)
            return result if isinstance(result,dict) else {"ok":True,"result":result}
        raise RuntimeError("verification_failed")
    except Exception as e:
        emit("tool.failed",tool=name,error=str(e))
        if t.recover:
            try:return t.recover(e,kwargs)
            except Exception:pass
        return {"ok":False,"error":str(e)}

# ---------------- Task graph ----------------
def create_task(objective,steps=None,parent=None):
    tid="task_"+uuid.uuid4().hex[:12]
    s=[]
    for x in steps or []:
        if isinstance(x,str): s.append({"id":"step_"+uuid.uuid4().hex[:7],"name":x,"status":"queued","progress":0})
        else: s.append(x)
    task={"id":tid,"objective":objective[:2000],"status":"queued","progress":0,"steps":s,
          "parent":parent,"created_at":_now(),"updated_at":_now(),"result":None,"error":None,"checkpoint":0}
    with LOCK: TASKS[tid]=task; _persist_tasks()
    BUS.publish("task.created",task=task)
    return task
def _persist_tasks():
    _save(TASK_FILE,sorted(TASKS.values(),key=lambda x:x.get("updated_at",0),reverse=True)[:MAX_TASKS])
def update_task(tid,**changes):
    with LOCK:
        t=TASKS.get(tid)
        if not t:return None
        t.update(changes); t["updated_at"]=_now(); _persist_tasks()
    BUS.publish("task.progress",task=t)
    return t
def set_step(tid,index,status,progress=None,error=None):
    with LOCK:
        t=TASKS.get(tid)
        if not t or index>=len(t["steps"]): return
        st=t["steps"][index]; st["status"]=status
        if progress is not None: st["progress"]=progress
        if error: st["error"]=str(error)
        done=sum(1 for x in t["steps"] if x.get("status") in ("done","verified")) 
        t["progress"]=int(done*100/max(1,len(t["steps"]))); t["updated_at"]=_now(); _persist_tasks()
    BUS.publish("task.progress",task=t)
def list_tasks(active_only=False,limit=30):
    vals=sorted(TASKS.values(),key=lambda x:x.get("updated_at",0),reverse=True)
    if active_only: vals=[x for x in vals if x.get("status") in ("queued","planning","running","paused","recovering")]
    return vals[:limit]
def cancel_active_tasks():
    count=0
    with LOCK:
        ids=[tid for tid,t in TASKS.items() if t.get("status") in ("queued","planning","running","paused","recovering")]
    for tid in ids:
        if cancel_task(tid): count+=1
    emit("task.cancel_all",count=count)
    return count

def cancel_task(tid): return bool(update_task(tid,status="cancelled",cancel_requested=True))
def pause_task(tid): return bool(update_task(tid,status="paused"))
def resume_task(tid): return bool(update_task(tid,status="queued"))

# ---------------- Memory/context ----------------
MEMORY_FILE=ROOT/"friday_v96_memory.json"
MEMORY=_load(MEMORY_FILE,[])
def remember(text,kind="fact",importance=0.5,metadata=None):
    text=re.sub(r"\s+"," ",str(text or "")).strip()
    if len(text)<4:return
    with LOCK:
        # exact + near duplicate suppression
        key=set(re.findall(r"[a-z0-9]{3,}",text.lower()))
        for m in MEMORY[-200:]:
            mk=set(re.findall(r"[a-z0-9]{3,}",m.get("text","").lower()))
            if key and len(key&mk)/max(1,len(key|mk))>.88:return
        MEMORY.append({"id":uuid.uuid4().hex,"text":text[:2500],"kind":kind,"importance":max(0,min(1,float(importance))),
                       "created_at":_now(),"last_used":_now(),"metadata":metadata or {}})
        MEMORY[:]=sorted(MEMORY,key=lambda x:(x.get("importance",0),x.get("last_used",0)),reverse=True)[:800]
        _save(MEMORY_FILE,MEMORY)
    BUS.publish("memory.updated",kind=kind,text=text[:300])
def recall(query,limit=8):
    q=set(re.findall(r"[a-z0-9]{3,}",query.lower())); out=[]
    for m in MEMORY:
        w=set(re.findall(r"[a-z0-9]{3,}",m.get("text","").lower()))
        overlap=len(q&w)/max(1,len(q|w)); rec=1/(1+max(0,_now()-m.get("created_at",0))/86400)
        score=.62*overlap+.23*m.get("importance",0)+.15*rec
        if score>.08:out.append((score,m))
    out.sort(key=lambda x:x[0],reverse=True)
    for _,m in out[:limit]:m["last_used"]=_now()
    return [{"score":round(s,3),**m} for s,m in out[:limit]]

_REF=re.compile(r"\b(it|this|that|these|those|them|the results|the research|the file|the topic)\b",re.I)
def resolve_reference(text,topic=None):
    if not _REF.search(text or ""): return text
    hits=recall(text,5)
    subject=topic or (hits[0]["text"] if hits else None)
    if not subject:return text
    # Only rewrite clearly incomplete follow-ups.
    if re.search(r"\b(make|create|turn|compare|verify|check|update|continue|summarize|explain)\b",text,re.I):
        return f"{text.strip()} regarding {subject[:300]}"
    return text

# ---------------- Vision ----------------
def capture_screen(path=None):
    try:
        import mss
        from PIL import Image
        with mss.mss() as sct:
            mon=sct.monitors[0]; shot=sct.grab(mon)
            out=Path(path) if path else ROOT/"friday_screen_latest.png"
            Image.frombytes("RGB",shot.size,shot.rgb).save(out)
            return {"ok":True,"path":str(out),"width":shot.width,"height":shot.height}
    except Exception as e:return {"ok":False,"error":str(e)}
def ocr_screen(path):
    try:
        import pytesseract
        return {"ok":True,"text":pytesseract.image_to_string(path)[:20000]}
    except Exception as e:return {"ok":False,"error":str(e)}
def locate_text(path, target):
    """OCR-grounded visual target using word bounding boxes."""
    try:
        import pytesseract
        from pytesseract import Output
        data=pytesseract.image_to_data(path, output_type=Output.DICT)
        target=str(target).strip().lower()
        for i,w in enumerate(data.get("text",[])):
            if str(w).strip().lower()==target:
                x,y,ww,hh=[int(data[k][i]) for k in ("left","top","width","height")]
                return {"ok":True,"text":w,"x":x,"y":y,"width":ww,"height":hh,
                        "center_x":x+ww//2,"center_y":y+hh//2}
        return {"ok":False,"error":"target_not_found","target":target}
    except Exception as e:return {"ok":False,"error":str(e)}

def inspect_screen():
    shot=capture_screen()
    if not shot.get("ok"):return shot
    out=dict(shot); out["ocr"]=ocr_screen(shot["path"]).get("text","")
    try:
        import friday_backend; out["active_window"]=friday_backend.get_active_window_title()
    except Exception:out["active_window"]=None
    # Add the structured Windows UIA tree when available; OCR remains the fallback.
    try:
        import friday_desktop_agent as _d
        if _d.uia_available():
            ui=_d.uia_inspect()
            if ui.get("ok"):
                out["uia_elements"]=ui.get("elements",[])[:200]
    except Exception: pass
    BUS.publish("vision.updated",active_window=out.get("active_window"),ocr_chars=len(out.get("ocr","")))
    return out

# ---------------- Computer closed loop ----------------
def computer_action(command):
    """Truth-aware compatibility wrapper around the primary desktop agent."""
    try:
        from friday_desktop_agent import computer
        return computer(command)
    except Exception as e:
        return {"ok":False,"executed":False,"error":str(e)}

# ---------------- Multi-agent orchestration ----------------
ROLES=("supervisor","planner","researcher","verifier","computer","writer","study","file","document")
def _complex_features(c):
    return {
      "research":bool(re.search(r"\b(research|investigate|find reliable sources|compare sources|deep research)\b",c,re.I)),
      "computer":bool(re.search(r"\b(open|launch|click|type|scroll|navigate|switch|drag|select)\b",c,re.I)),
      "vision":bool(re.search(r"\b(screen|screenshot|ocr|what am i looking at|read the screen)\b",c,re.I)),
      "document":bool(re.search(r"\b(presentation|slides|pptx|report|document|docx|pdf|spreadsheet|xlsx|excel)\b",c,re.I)),
      "study":bool(re.search(r"\b(study|quiz|flashcards|exam|teach me|revision)\b",c,re.I)),
    }
def _backend(): import friday_backend; return friday_backend

def _do_research(c):
    try:return _backend().friday_web_research.run_web_research(c,use_cache=True)
    except Exception as e:return {"ok":False,"error":str(e)}
def _do_document(c):
    try:return {"ok":bool(_backend().handle_command(c))}
    except Exception as e:return {"ok":False,"error":str(e)}
def _do_study(c):
    try:return {"ok":bool(_backend().handle_command(c))}
    except Exception as e:return {"ok":False,"error":str(e)}

def run_agent_graph(command):
    f=_complex_features(command)
    steps=[]
    if f["research"]:steps.append("research")
    if f["vision"]:steps.append("vision")
    if f["computer"]:steps.append("computer")
    if f["study"]:steps.append("study")
    if f["document"]:steps.append("document")
    if not steps:return None
    task=create_task(command,steps)
    update_task(task["id"],status="planning")
    BUS.publish("agent.planning",role="planner",task_id=task["id"],steps=steps)
    results={}
    for i,step in enumerate(steps):
        t=TASKS.get(task["id"],{})
        if t.get("cancel_requested"):break
        set_step(task["id"],i,"running",0)
        BUS.publish("agent.started",role=step if step in ROLES else "supervisor",task_id=task["id"])
        try:
            if step=="research": result=_do_research(command)
            elif step=="vision": result=inspect_screen()
            elif step=="computer": result=computer_action(command)
            elif step=="study": result=_do_study(command)
            else: result=_do_document(command)
            results[step]=result
            ok=bool(result.get("ok",True)) if isinstance(result,dict) else bool(result)
            if not ok:
                set_step(task["id"],i,"recovering",50,result.get("error") if isinstance(result,dict) else "failed")
                BUS.publish("agent.retry",role=step,task_id=task["id"])
                # One bounded recovery attempt: research cache, document legacy
                # route, or re-observe the screen; never infinite retry.
                if step=="vision": result=inspect_screen()
                elif step=="research": result=_do_research(command)
                ok=bool(result.get("ok",True)) if isinstance(result,dict) else bool(result)
                results[step]=result
            set_step(task["id"],i,"verified" if ok else "failed",100 if ok else 50)
        except Exception as e:
            set_step(task["id"],i,"failed",0,str(e)); results[step]={"ok":False,"error":str(e)}
        update_task(task["id"],checkpoint=i+1)
    errors=[k for k,v in results.items() if isinstance(v,dict) and v.get("ok") is False]
    status="completed_with_errors" if errors else ("cancelled" if TASKS[task["id"]].get("cancel_requested") else "completed")
    update_task(task["id"],status=status,progress=100,result={"steps":list(results),"errors":errors})
    BUS.publish("task.completed",task_id=task["id"],status=status)
    return {"handled":True,"task":TASKS[task["id"]],"results":results}

# ---------------- Diagnostics/self-healing ----------------
def diagnostics():
    checks={}
    checks["runtime_state"]=STATE_FILE.parent.exists()
    checks["python"]=True
    for name,mod in [("web_research","friday_web_research"),("voice","friday_voice_engine"),("study","friday_creation_engine")]:
        try: __import__(mod); checks[name]=True
        except Exception: checks[name]=False
    try: import psutil; checks["system_monitor"]=True
    except Exception: checks["system_monitor"]=False
    try: import pyautogui; checks["computer_control"]=True
    except Exception: checks["computer_control"]=False
    try: import mss; checks["screen_capture"]=True
    except Exception: checks["screen_capture"]=False
    try: import pytesseract; checks["ocr_bridge"]=True
    except Exception: checks["ocr_bridge"]=False
    try: import numpy; checks["numeric"]=True
    except Exception: checks["numeric"]=False
    checks["tool_registry"]=bool(TOOLS)
    ok=sum(bool(v) for v in checks.values()); report={"overall":ok==len(checks),"passed":ok,"total":len(checks),"checks":checks,"timestamp":_iso()}
    _state["last_health"]=report; _save(STATE_FILE,_state); BUS.publish("system.diagnostics",report=report)
    return report

def start_background():
    global _BG_STARTED
    if _BG_STARTED:return
    _BG_STARTED=True
    emit("runtime.started",version="v96",tools=len(TOOLS))
    # Health monitor is intentionally quiet; it emits only state changes.
    def monitor():
        last=None
        while not _STOP.wait(10):
            try:
                # Cheap checks only; expensive dependency probes stay manual.
                state="healthy" if ROOT.exists() else "degraded"
                if state!=last: BUS.publish("system.health",state=state); last=state
            except Exception: pass
            try: proactive_tick()
            except Exception: pass
    threading.Thread(target=monitor,daemon=True,name="FRIDAY-v96-health").start()

def stop_background(): _STOP.set()

# ---------------- Proactive intelligence ----------------
# The proactive layer is intentionally conservative: it observes cheap,
# high-signal events, decides whether the user needs to know, and prefers
# silent recovery/continuation over interruptions. State is persisted so a
# restart does not forget the user's proactive preference or notification
# cooldowns.
PROACTIVE_LEVELS={"silent":0,"useful":1,"important":2,"critical":3}

def proactive_status():
    with LOCK:
        return {
            "enabled":bool(_proactive.get("enabled",False)),
            "quiet_minutes":int(_proactive.get("quiet_minutes",30)),
            "cooldown_seconds":int(_proactive.get("cooldown_seconds",300)),
            "notify_level":_proactive.get("notify_level","important"),
            "monitor_window":bool(_proactive.get("monitor_window",True)),
            "monitor_tasks":bool(_proactive.get("monitor_tasks",True)),
            "monitor_system":bool(_proactive.get("monitor_system",True)),
        }

def set_proactive(enabled=None, quiet_minutes=None, cooldown_seconds=None, notify_level=None):
    with LOCK:
        if enabled is not None: _proactive["enabled"]=bool(enabled)
        if quiet_minutes is not None: _proactive["quiet_minutes"]=max(0,int(quiet_minutes))
        if cooldown_seconds is not None: _proactive["cooldown_seconds"]=max(30,int(cooldown_seconds))
        if notify_level is not None and notify_level in PROACTIVE_LEVELS: _proactive["notify_level"]=notify_level
        _state["proactive"]=_proactive["enabled"]
        _save(PROACTIVE_FILE,_proactive); _save(STATE_FILE,_state)
    BUS.publish("proactive.changed",status=proactive_status())
    return proactive_status()

def _proactive_should_notify(key, level="useful", force=False):
    if not _proactive.get("enabled",False): return False
    threshold=PROACTIVE_LEVELS.get(_proactive.get("notify_level","important"),2)
    if PROACTIVE_LEVELS.get(level,1) < threshold and not force: return False
    now=_now()
    with LOCK:
        last=float(_proactive.setdefault("last_notifications",{}).get(key,0) or 0)
        if not force and now-last < float(_proactive.get("cooldown_seconds",300)): return False
        _proactive["last_notifications"][key]=now
        _save(PROACTIVE_FILE,_proactive)
    return True

def proactive_notify(message, *, level="important", key=None, action=None, data=None, force=False):
    message=re.sub(r"\s+"," ",str(message or "")).strip()
    if not message:return False
    key=key or re.sub(r"[^a-z0-9]+","_",message.lower())[:120]
    if not _proactive_should_notify(key,level,force): return False
    payload={"message":message,"level":level,"key":key,"proactive":True}
    if action: payload["action"]=action
    if data: payload["data"]=data
    BUS.publish("proactive.notification",**payload)
    return True

def _task_monitor_tick():
    if not _proactive.get("monitor_tasks",True): return
    now=_now()
    for t in list_tasks(active_only=False,limit=100):
        status=t.get("status")
        tid=t.get("id","task")
        if status in ("completed","completed_with_errors") and t.get("proactive_reported") is not True and float(t.get("created_at",0) or 0) >= baseline:
            # Only report meaningful completed background work.
            if t.get("created_at",now) and now-t.get("created_at",now)>2:
                msg=(f"Task {tid} completed successfully." if status=="completed" else f"Task {tid} completed with errors; review is recommended.")
                level="important" if status=="completed" else "critical"
                if proactive_notify(msg,level=level,key=f"task_complete:{tid}",data={"task_id":tid,"status":status},force=False):
                    t["proactive_reported"]=True; _persist_tasks()
        elif status in ("running","planning","recovering"):
            age=now-float(t.get("updated_at",now) or now)
            # A stalled task is one with no state update for 5 minutes.
            if age>=300:
                proactive_notify(f"Task {tid} appears stalled. I can investigate or retry it.",level="important",key=f"task_stalled:{tid}",data={"task_id":tid,"age_seconds":int(age)})
        elif status=="paused":
            proactive_notify(f"Task {tid} is paused and waiting to resume.",level="useful",key=f"task_paused:{tid}",data={"task_id":tid})

def _window_monitor_tick():
    if not _proactive.get("monitor_window",True): return
    try:
        import platform
        if platform.system()!="Windows": return
        import ctypes
        user32=ctypes.windll.user32; hwnd=user32.GetForegroundWindow()
        if not hwnd:return
        n=user32.GetWindowTextLengthW(hwnd)
        if n<=0:return
        buf=ctypes.create_unicode_buffer(n+1); user32.GetWindowTextW(hwnd,buf,n+1)
        title=buf.value.strip()
        if not title:return
        previous=_proactive.get("last_window")
        _proactive["last_window"]=title
        _proactive["last_window_at"]=_now()
        if previous and previous!=title:
            # Record the context change for the shared memory/event system,
            # but do not interrupt the user merely because a window changed.
            BUS.publish("awareness.window_changed",previous=previous,current=title)
    except Exception: pass

def _system_monitor_tick():
    if not _proactive.get("monitor_system",True): return
    try:
        import psutil
        mem=psutil.virtual_memory()
        if mem.percent>=92:
            proactive_notify(f"System memory usage is very high ({mem.percent:.0f}%). Consider closing unused applications.",level="critical",key="system:memory_high",data={"memory_percent":mem.percent})
        cpu=psutil.cpu_percent(interval=None)
        if cpu>=98:
            proactive_notify(f"CPU usage is very high ({cpu:.0f}%). A process may be consuming excessive resources.",level="important",key="system:cpu_high",data={"cpu_percent":cpu})
    except Exception: pass


def _download_monitor_tick():
    if not _proactive.get("monitor_tasks",True): return
    try:
        d=Path.home()/"Downloads"
        if not d.exists(): return
        current={}
        for f in d.iterdir():
            if f.is_file():
                try: current[str(f)] = f.stat().st_mtime
                except Exception: pass
        previous=_proactive.get("download_snapshot") or {}
        _proactive["download_snapshot"]=current
        if previous:
            new=[p for p in current if p not in previous]
            # Only announce files that have remained unchanged for a short
            # interval; this avoids announcing a partially downloaded file.
            for p in new[:3]:
                try:
                    if time.time()-current[p] >= 1.5:
                        proactive_notify(f"New file detected in Downloads: {Path(p).name}",level="important",key="download:"+p,data={"path":p})
                except Exception: pass
        _save(PROACTIVE_FILE,_proactive)
    except Exception: pass

def proactive_tick():
    if not _proactive.get("enabled",False): return
    try:_task_monitor_tick()
    except Exception:pass
    try:_window_monitor_tick()
    except Exception:pass
    try:_system_monitor_tick()
    except Exception:pass
    try:_download_monitor_tick()
    except Exception:pass


# ---------------- Desktop capability bridge ----------------
def _desktop():
    try:
        import friday_desktop_agent
        return friday_desktop_agent
    except Exception:
        return None

def _speak_result(result):
    try:
        jb=_backend()
        if not isinstance(result,dict): return
        r=result.get("result",result)
        if isinstance(r,dict) and r.get("error"):
            # V2048 FIX: "executed" true means the launch actually happened -
            # FRIDAY just couldn't confirm the window in time (common for
            # slow-starting apps like office suites). That is not a safety
            # failure, so don't tell the user it is. Only apps that never
            # executed at all (not found, launch raised an exception, etc.)
            # get the "could not do that" message.
            app_name = r.get("application") or "that"
            if r.get("executed"):
                jb.speak(f"I've opened {app_name}, sir, though I couldn't confirm the window came up yet.")
            else:
                jb.speak(f"I couldn't open {app_name}, sir.")
            return
        action = r.get("action") if isinstance(r,dict) else None
        if action:
            jb.speak(f"Completed: {action.replace('_',' ')}.")
        elif isinstance(r,dict) and "active_window" in r:
            jb.speak(f"The active window is {r.get('active_window') or 'unknown'}, sir.")
        elif isinstance(r,dict) and "cpu_percent" in r:
            jb.speak(f"CPU is at {r['cpu_percent']:.0f} percent, memory is at {r.get('ram_percent',0):.0f} percent.")
        elif isinstance(r,dict) and r.get("action") == "read_webpage":
            text=re.sub(r"\s+"," ",str(r.get("text",""))).strip()
            jb.speak(text[:700] if text else "The page contains no readable text.")
    except Exception:
        pass

def _contextual(command:str):
    """Resolve 'this/that' from current selection without replacing legacy context."""
    low=command.lower().strip()
    if not re.search(r"\b(search|explain|translate|what does)\s+(?:this|that|it)\b",low):
        return None
    try:
        import pyperclip, friday_desktop_agent as d
        old=pyperclip.paste()
        p=d._pyautogui()
        p.hotkey("ctrl","c"); time.sleep(.08)
        selected=pyperclip.paste().strip()
        try: pyperclip.copy(old)
        except Exception: pass
        if not selected: return None
        if re.search(r"\bsearch\b",low):
            r=d.browser("search "+selected)
            return {"handled":True,"context":selected[:500],"result":r}
        jb=_backend()
        prompt = ("Explain this selected text clearly and briefly:\n"+selected) if "explain" in low else ("Translate this selected text to English, preserving meaning:\n"+selected)
        try: jb.speak(jb.ask_ai(prompt))
        except Exception: jb.speak("I have the selected text, but the language service is unavailable, sir.")
        return {"handled":True,"context":selected[:500]}
    except Exception:
        return None

# ---------------- Registration + command gateway ----------------
def _register_defaults():
    register_tool("vision.screen","Capture screen + OCR",lambda:inspect_screen(),0)
    register_tool("computer.action","Conservative desktop input",lambda command:computer_action(command),1)
    register_tool("research.deep","Multi-source research adapter",lambda query:_do_research(query),0)
    register_tool("memory.recall","Ranked local memory",lambda query:recall(query),0)
    d=_desktop()
    if d:
        register_tool("windows.uia","Microsoft UI Automation primary desktop control",lambda command:d.uia_action(command),1)
        register_tool("windows.uia.inspect","Inspect active Windows UI Automation tree",lambda:d.uia_inspect(),0)
        register_tool("browser.playwright","Playwright browser automation",lambda command:d.playwright_browser(command),1)
        try:
            import friday_gemini_computer_use as gcu
            register_tool("ai.computer_use","Gemini Computer Use (safety-gated visual fallback)",lambda task:gcu.run(task),1)
        except Exception: pass
        register_tool("desktop.control","Mouse and keyboard control",lambda command:d.computer(command),1)
        register_tool("desktop.windows","Window management",lambda command:d.window_action(command),1)
        register_tool("desktop.apps","Launch supported applications",lambda name:d.launch_app(name),1)
        register_tool("filesystem.control","Search/create/rename/copy/move files",lambda command:d.file_action(command),2)
        register_tool("browser.control","Browser navigation, tabs and search",lambda command:d.browser(command),1)
        register_tool("media.control","System media keys and volume",lambda command:d.media(command),1)
        register_tool("system.info","System status",lambda: d.system_info(),0)
_register_defaults()

def gateway(command,topic=None):
    c=(command or "").strip()
    if not c:return None
    # Level-4 actions are deliberately allowed to reach the existing backend
    # confirmation state machine. The runtime never executes them itself.
    low=c.lower()
    # Proactive assistance controls are available from voice and widget.
    if re.search(r"\b(?:enable|turn on|activate|start)\s+(?:proactive|proactive assistance)\b",low):
        st=set_proactive(enabled=True)
        try:_backend().speak("Proactive assistance is now enabled. I will monitor tasks and important system events without interrupting unnecessarily.")
        except Exception:pass
        return {"handled":True,"proactive":st}
    if re.search(r"\b(?:disable|turn off|deactivate|stop)\s+(?:proactive|proactive assistance)\b",low):
        st=set_proactive(enabled=False)
        try:_backend().speak("Proactive assistance is now disabled.")
        except Exception:pass
        return {"handled":True,"proactive":st}
    if re.search(r"\b(?:proactive status|status of proactive assistance|is proactive assistance on)\b",low):
        st=proactive_status()
        try:_backend().speak("Proactive assistance is enabled." if st["enabled"] else "Proactive assistance is disabled.")
        except Exception:pass
        BUS.publish("proactive.status",status=st)
        return {"handled":True,"proactive":st}
    m=re.search(r"\bproactive\s+(?:quiet|silence)\s+(\d+)\s*(?:minutes?|mins?)?\b",low)
    if m:
        st=set_proactive(quiet_minutes=int(m.group(1)))
        try:_backend().speak(f"Proactive quiet period set to {st['quiet_minutes']} minutes.")
        except Exception:pass
        return {"handled":True,"proactive":st}
    # Task controls are available from both voice and widget because both use
    # the same backend gateway.
    m=re.search(r"\b(?:pause|resume|cancel|stop|retry)\s+(?:task\s+)?(task_[a-f0-9]+)\b",low)
    if m:
        tid=m.group(1); action=re.search(r"^\s*(pause|resume|cancel|stop|retry)",low).group(1)
        ok={"pause":pause_task,"resume":resume_task,"cancel":cancel_task,"stop":cancel_task,"retry":resume_task}[action](tid)
        try:_backend().speak(f"Task {tid} {action}ed." if ok else f"I could not update task {tid}.")
        except Exception:pass
        return {"handled":True}
    if re.search(r"\b(list|show)\s+(?:my\s+)?(?:active\s+)?tasks?\b",low):
        tasks=list_tasks(active_only=False)
        try:_backend().speak(f"I have {len(tasks)} tracked tasks. The most recent is {tasks[0]['id']}." if tasks else "There are no tracked tasks yet.")
        except Exception:pass
        BUS.publish("task.snapshot",tasks=tasks)
        return {"handled":True}
    if re.search(r"\b(?:system check|self diagnostic|self-diagnostic|diagnostics)\b",low):
        r=diagnostics()
        try:_backend().speak(f"Diagnostics complete. {r['passed']} of {r['total']} checks passed.")
        except Exception:pass
        return {"handled":True}
    if re.search(r"\b(?:what do you remember|recall)\b",low):
        hits=recall(c)
        text=("Relevant memories: "+"; ".join(x["text"][:180] for x in hits[:5])) if hits else "I have no relevant stored memory."
        try:_backend().speak(text)
        except Exception:pass
        return {"handled":True}
    m=re.match(r"remember(?: that)?\s+(.+)$",c,re.I)
    if m:
        remember(m.group(1),"explicit",0.9); 
        try:_backend().speak("Stored as an important memory.")
        except Exception:pass
        return {"handled":True}
    if re.search(r"\b(?:read|scan|understand)\s+(?:my\s+)?screen\b|what.+(?:on|am looking at).+screen",low):
        # V2036: speak like FRIDAY (situation report), not a raw "Active window: ... OCR dump".
        _wants_read=bool(re.search(r"\bread\b",low))
        try:
            import friday_screen_intelligence as _jsi
            text=_jsi.spoken_screen_report(_jsi.inspect_screen(use_semantic_vision=True),read_text=_wants_read)
        except Exception:
            r=inspect_screen()
            text=("Sir, the active window is "+str(r.get("active_window") or "unknown")+".") if r.get("ok") else "I can't inspect the screen at the moment, sir."
        try:_backend().speak(text)
        except Exception:pass
        return {"handled":True}
    contextual=_contextual(c)
    if contextual is not None:
        return contextual
    d=_desktop()
    if d:
        # Destructive file/system operations intentionally remain in the legacy
        # confirmation path; this router only claims unambiguous non-destructive
        # desktop operations.
        if permission_level(c)[0] < 4:
            # Precision order: UIA -> Playwright for browser intent -> legacy fallbacks.
            if getattr(d, "uia_available", lambda:False)() and re.search(r"\b(?:click|press|activate|invoke|type|fill)\b", c, re.I):
                ur=d.uia_action(c)
                if ur.get("ok"):
                    _speak_result(ur); return {"handled":True,"result":ur}
            if re.search(r"\b(?:click|press|open|interact|find|select|type)\b", c, re.I) and ("next to" in c.lower() or "on the screen" in c.lower() or "visually" in c.lower()):
                try:
                    import friday_gemini_computer_use as gcu
                    gr=gcu.run(c, max_steps=6)
                    if gr.get("ok") or gr.get("confirmation_required"):
                        try: _speak_result(gr)
                        except Exception: pass
                        return {"handled":True,"result":gr}
                except Exception: pass
            # Browser intent goes through the explicit Chrome controller first.
            # This prevents Edge/default-browser routing and makes compound
            # requests (new tab + type/search) a single verified action.
            if re.search(r"\b(?:google|chrome|search|navigate|open https?://|new tab|close tab|switch tab|find text|click (?:the )?(?:link|button)|type .+ in (?:the )?search bar)\b", c, re.I):
                br=d.browser(c)
                if br.get("ok"):
                    _speak_result(br); return {"handled":True,"result":br}
            r=d.handle(c)
            if r is not None:
                _speak_result(r)
                return r
    # Complex requests become background task graphs; simple commands retain
    # the mature fast path and existing no-wake-word voice loop.
    f=_complex_features(c)
    if sum(f.values())>=2 or re.search(r"\bdeep research|research thoroughly\b",low):
        EXECUTOR.submit(run_agent_graph,c)
        try:_backend().speak("Understood. I am handling that as a background task and will report when it is complete.")
        except Exception:pass
        return {"handled":True,"background":True}
    if re.search(r"\b(click|type|scroll)\b",low):
        r=computer_action(c)
        try:_backend().speak("Action completed." if r.get("ok") else "I could not complete that action safely.")
        except Exception:pass
        return {"handled":True}
    return None
