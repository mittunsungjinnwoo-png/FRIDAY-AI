"""
FRIDAY CREATION ENGINE v2
=========================

Drop-in replacement for the previous creation engine.

PUBLIC API (unchanged):
    create_folder_command(command)
    create_project_command(command, reuse_sources=None, reuse_topic=None)

The rest of FRIDAY does not need to change.

Main improvements:
- Preserves the user's original topic casing instead of lower-casing it.
- Uses a stricter source-grounded Gemini content package instead of one
  generic outline being stretched across every file type.
- Creates substantially richer DOCX/PDF/PPTX/XLSX artifacts.
- Adds section/source traceability so factual content can be checked.
- Uses safe text wrapping and table sizing to reduce overflow/corruption.
- Validates every generated file by reopening it before reporting success.
- Uses atomic writes so a failed build does not leave a misleading file.
- Retries content planning once with a repair prompt when Gemini returns
  malformed or incomplete JSON.
- Keeps the existing folder location, progress events, voice messages,
  context-memory integration, and public command routing intact.

ACCURACY NOTE:
No automated system can honestly guarantee perfect factual accuracy.
This engine therefore makes the generated artifacts source-grounded and
traceable, and refuses to claim success if the artifact itself fails
validation. The quality of the research sources remains important.
"""

from __future__ import annotations

import json
import time
import os
import re
import tempfile
from pathlib import Path
from urllib.parse import urlparse

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.util import Inches as PInches, Pt as PPt

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table as XLTable, TableStyleInfo
from openpyxl.worksheet.dimensions import ColumnDimension

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    PageTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    KeepTogether,
    PageBreak,
)
from reportlab.pdfbase.pdfmetrics import stringWidth

# OpenDocument support (ODT/ODS/ODP). Kept optional at import time so the
# existing DOCX/PDF/XLSX/PPTX features still start if odfpy is unavailable.
try:
    from odf.opendocument import OpenDocumentText, OpenDocumentSpreadsheet, OpenDocumentPresentation
    from odf.text import P, H
    from odf.table import Table as ODFTable, TableRow as ODFTableRow, TableCell as ODFTableCell
    from odf.draw import Page, Frame as ODFFrame, TextBox
    from odf.style import Style, TextProperties, MasterPage, PageLayout, PageLayoutProperties
    ODF_AVAILABLE = True
except Exception:
    ODF_AVAILABLE = False


PROJECTS_ROOT = Path.home() / "Documents" / "FRIDAY Projects"

# V2037: what the most recent create_project_command() really produced. The agent's
# independent verifier used to look in the wrong folder (study_files/projects) and so
# reported "issues" even after a perfect file was written; it now reads this record.
LAST_PROJECT = {"time": 0.0, "topic": "", "folder": "", "files": [], "ok": False, "note": ""}

_BASE_DIRS = {
    "downloads": Path.home() / "Downloads",
    "documents": Path.home() / "Documents",
    "desktop": Path.home() / "Desktop",
    "pictures": Path.home() / "Pictures",
}

# Internal visual palette. This affects generated files only; the Electron UI
# is untouched.
_NAVY = "07111F"
_CYAN = "00CFE8"
_CYAN_DARK = "008EA0"
_WHITE = "F4FBFF"
_MUTED = "6E8798"
_GRID = "D7E3EA"
_LIGHT = "EEF6F9"
_DARK_TEXT = "10212D"


# ============================================================
# SMALL, SAFE HELPERS
# ============================================================


def _safe_folder_name(name):
    name = re.sub(r'[<>:"/\\|?*]', "_", str(name)).strip(" .")
    return name[:150] or "New Folder"


def _resolve_base_dir(command):
    c = (command or "").lower()
    for key, path in _BASE_DIRS.items():
        if key in c:
            return path
    return _BASE_DIRS["documents"]


def _clean_text(value, limit=5000):
    if value is None:
        return ""
    text = re.sub(r"\s+", " ", str(value)).strip()
    return text[:limit]


def _display_topic(command):
    """Extract a human-readable topic while preserving original casing."""
    original = str(command or "").strip()
    topic = original

    # Remove the wake-word / conversational wrapper only.
    topic = re.sub(
        r"^\s*(?:hey\s+)?(?:friday[,:]?\s*)?(?:can\s+(?:you|u|i)|could\s+(?:you|u)|would\s+(?:you|u)|will\s+you|pls|please|kindly)\s+(?:please\s+)?",
        "",
        topic,
        flags=re.I,
    )
    topic = re.sub(r"^\s*(?:let's|lets)\s+", "", topic, flags=re.I)

    # If the request explicitly says "about X" or "on X", everything after
    # that marker is normally the topic. This handles natural phrasing such
    # as "research on Astrology and make it into a PDF" without requiring an
    # exact sentence template.
    marker = re.search(r"\b(?:about|on)\s+", topic, flags=re.I)
    if marker:
        topic = topic[marker.end():]
    else:
        # Otherwise remove a leading research/create verb phrase, but leave
        # the user's original capitalization untouched.
        topic = re.sub(
            r"^\s*(?:research|look\s+up|look\s+into|find\s+out|create|make|build|generate|prepare|draft)\s+",
            "",
            topic,
            count=1,
            flags=re.I,
        )

    # Speech often inserts a filler phrase such as "on the topic orbitals".
    # "the topic" is instruction residue, not part of the requested subject.
    topic = re.sub(r"^the\s+topic\s+", "", topic, flags=re.I).strip()

    # Remove creation/request suffixes that are not part of the subject.
    suffix_patterns = [
        # V2037: filler such as "... on orbitals make sure to do the research", "please", "in word"
        r"\s*[,.;]?\s*(?:and\s+)?(?:please\s+)?(?:make|be)\s+sure\b.*$",
        r"\s*[,.;]?\s*(?:and\s+)?(?:please\s+)?(?:do|with|including|using|after)\s+(?:some\s+|proper\s+|good\s+|deep\s+|real\s+|live\s+)*research\b.*$",
        r"\s*[,.;]?\s*(?:and\s+)?(?:research|search)\s+(?:it|this|that|the\s+web|online|properly|first)\b.*$",
        r"\s+(?:in|as|into)\s+(?:a\s+|an\s+)?(?:ms\s+|microsoft\s+)?(?:word|pdf|docx|powerpoint)\b.*$",
        r"\s+(?:please|pls|thanks|thank\s+you)\s*[.!]?\s*$",
        r"\s+(?:and\s+)?(?:make|create|build|generate|prepare|draft)\s+(?:me\s+)?(?:a\s+|an\s+)?(?:presentation|slideshow|slide\s+deck|slides?|deck|word\s+doc\w*|doc\w*|report|pdf|spreadsheet|excel(?:\s+sheet)?|xlsx|project)\b.*$",
        r"\s*,?\s*(?:include|with)\s+(?:references|sources|citations)\b.*$",
        r"\s*\(command\s+completed\)\s*.*$",
        r"\s+and\s+make\s+it\b.*$",
        r"\s+and\s+create\s+it\b.*$",
    ]
    for pattern in suffix_patterns:
        topic = re.sub(pattern, "", topic, count=1, flags=re.I)

    # Remove an explicit slide-count phrase if it survived the extraction.
    topic = re.sub(r"\b\d{1,2}\s*[- ]?slides?\b", " ", topic, flags=re.I)

    # Strip artifact nouns only when they are clearly request residue.
    topic = re.sub(
        r"\b(?:include references|with references|include sources|with sources|include citations|with citations)\b",
        " ", topic, flags=re.I,
    )
    topic = re.sub(r"\s+", " ", topic).strip(" .,;:-?\"'")
    return topic or original


def _atomic_path(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.stem}_", suffix=path.suffix, dir=str(path.parent))
    os.close(fd)
    return Path(tmp)


def _atomic_save(path, saver):
    """Run saver(temp_path), validate externally, then atomically replace."""
    path = Path(path)
    tmp = _atomic_path(path)
    try:
        saver(tmp)
        if not tmp.exists() or tmp.stat().st_size < 100:
            raise RuntimeError(f"Generated file is empty or suspiciously small: {path.name}")
        os.replace(str(tmp), str(path))
    except Exception:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        raise


def _validate_nonempty(path):
    p = Path(path)
    if not p.exists() or p.stat().st_size < 100:
        raise RuntimeError(f"Validation failed: {p.name} is missing or empty.")


def _normalise_plan(plan, topic):
    if not isinstance(plan, dict):
        raise RuntimeError("Gemini returned a content package that was not an object.")

    title = _clean_text(plan.get("title") or topic, 180)
    summary = _clean_text(plan.get("summary"), 1500)
    sections = plan.get("sections")
    if not isinstance(sections, list) or not sections:
        raise RuntimeError("Gemini returned no content sections.")

    cleaned = []
    for section in sections:
        if not isinstance(section, dict):
            continue
        heading = _clean_text(section.get("heading"), 180)
        body = _clean_text(section.get("body"), 3000)
        bullets = section.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = [bullets]
        bullets = [_clean_text(x, 600) for x in bullets if _clean_text(x, 600)]

        table = section.get("table")
        if table and isinstance(table, dict):
            headers = table.get("headers") or []
            rows = table.get("rows") or []
            headers = [_clean_text(x, 120) for x in headers]
            safe_rows = []
            for row in rows:
                if not isinstance(row, list):
                    continue
                safe_rows.append([_clean_text(x, 500) for x in row[:len(headers)]])
            table = {"headers": headers, "rows": safe_rows} if headers else None
        else:
            table = None

        source_ids = section.get("source_ids") or []
        if not isinstance(source_ids, list):
            source_ids = [source_ids]
        source_ids = [int(x) for x in source_ids if str(x).isdigit()]

        if heading and (body or bullets or table):
            cleaned.append({
                "heading": heading,
                "body": body,
                "bullets": bullets,
                "table": table,
                "source_ids": source_ids,
            })

    if not cleaned:
        raise RuntimeError("Gemini returned sections, but none contained usable content.")

    facts = plan.get("key_facts") or []
    if not isinstance(facts, list):
        facts = []
    facts = [_clean_text(x, 700) for x in facts if _clean_text(x, 700)]

    methodology = _clean_text(plan.get("methodology"), 1500)
    return {
        "title": title,
        "summary": summary,
        "key_facts": facts,
        "methodology": methodology,
        "sections": cleaned,
    }


# ============================================================
# FOLDER CREATOR — PUBLIC API UNCHANGED
# ============================================================


def create_folder_command(command):
    import friday_backend

    match = re.search(
        r"folder(?:s)?(?: named| called)?\s+(.+?)(?:\s+in\s+(?:the\s+)?(?:downloads|documents|desktop|pictures)(?:\s+folder)?)?$",
        command.strip(),
        flags=re.IGNORECASE,
    )
    name = match.group(1).strip() if match else ""
    if not name:
        friday_backend.speak("What would you like me to name the folder?")
        return True

    base = _resolve_base_dir(command)
    folder_name = _safe_folder_name(name)
    target = base / folder_name
    counter = 2
    while target.exists():
        target = base / f"{folder_name} ({counter})"
        counter += 1

    try:
        target.mkdir(parents=True, exist_ok=False)
        friday_backend.speak(f"I've created the folder {folder_name} in your {base.name} folder.")
        print(f"ACTION::FOLDER_CREATED::{target}")
    except Exception as error:
        print("Folder creation error:", error)
        friday_backend.speak("I couldn't create that folder.")
    return True


# ============================================================
# RESEARCH -> VERIFIED CONTENT PACKAGE
# ============================================================


def _source_label(url, index):
    try:
        domain = urlparse(url).netloc.replace("www.", "")
    except Exception:
        domain = "source"
    return f"Source {index}: {domain or 'web source'}"


def _sources_block(sources):
    chunks = []
    for i, (url, text) in enumerate(sources, start=1):
        chunks.append(
            f"[{i}] {_source_label(url, i)}\nURL: {url}\nCONTENT:\n{str(text)[:6500]}"
        )
    return "\n\n".join(chunks)


def _extract_json_object(raw):
    raw = (raw or "").strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
    raw = re.sub(r"\s*```$", "", raw, flags=re.I)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Balanced-brace extraction is safer than greedy .* when the model
        # includes a stray brace inside explanatory text.
        start = raw.find("{")
        if start < 0:
            raise
        depth = 0
        in_string = False
        escaped = False
        for i in range(start, len(raw)):
            ch = raw[i]
            if in_string:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_string = False
                continue
            if ch == '"':
                in_string = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(raw[start:i + 1])
        raise


def _fallback_plan_from_sources(topic, sources):
    """Build a conservative document plan when Gemini planning fails.

    This is intentionally source-only: it never invents facts merely to keep
    the file pipeline alive. The resulting Word document is still useful and
    clearly traceable to the material FRIDAY actually retrieved.
    """
    sections=[]
    for i,(url,text) in enumerate(sources[:8],1):
        clean=re.sub(r"\s+", " ", str(text or "")).strip()
        if not clean:
            continue
        # Prefer a short factual window; never dump an entire webpage into a box.
        snippet=clean[:900]
        heading=(urlparse(url).netloc.replace("www.", "") or f"Source {i}").title()
        sections.append({
            "heading": f"Research finding {i}: {heading}",
            "body": snippet,
            "bullets": [],
            "source_ids": [i],
        })
    if not sections:
        raise RuntimeError("Research sources contained no readable text.")
    return {
        "title": str(topic).strip().title(),
        "summary": f"Source-grounded research notes on {topic}. The content below is drawn directly from the readable research material collected by FRIDAY.",
        "methodology": "The primary research material was collected from the sources listed below. Because the structured AI planning step was unavailable, FRIDAY preserved the retrieved source material rather than inventing or guessing missing facts.",
        "key_facts": [],
        "sections": sections,
    }


def _plan_content(topic, sources, slide_count=None, doc_style="standard"):
    import friday_backend

    friday_backend._ensure_gemini_client()
    if friday_backend.client is None:
        raise RuntimeError("Gemini is not configured -- cannot plan content.")
    if not sources:
        raise RuntimeError("No source material is available.")

    target_sections = slide_count or 10
    source_text = _sources_block(sources)

    if doc_style == "questions":
        # Same JSON schema as the standard report (heading/body/bullets/
        # source_ids per "section") so every file builder below (docx, pdf,
        # pptx, xlsx, odt, ods, odp) renders it correctly with no changes --
        # only the CONTENT REQUIREMENTS differ: each "section" is one
        # research-grounded question with its own model answer, instead of
        # one paragraph of a report.
        content_requirements = f"""
CONTENT REQUIREMENTS -- this is a QUESTION SET, not a report:
- A clear professional title such as "{topic} -- Study Questions".
- A concise 2-4 sentence summary describing the scope of the question set.
- {max(6, min(target_sections, 20))} distinct questions covering the topic,
  spanning a genuine mix of difficulty: recall/definition questions,
  understanding/explanation questions, and at least a few application or
  "why"/"how" questions that require reasoning rather than one-line recall.
- Each "section" IS one question:
    * heading: the question itself, written as "Q<number>: <question text>"
      (e.g. "Q1: What is the function of chlorophyll in photosynthesis?").
    * body: leave empty or provide only a very short instruction such as
      "Answer in the space provided." Do NOT provide the answer, solution,
      marking scheme, hints, or worked explanation.
    * bullets: omit them for the question-only format.
- Do not pad with generic introduction/conclusion sections. Every section
  must be a genuine question only.
- This is a STUDENT QUESTION SHEET, not an answer key. Never reveal answers
  unless the user explicitly asks for an answer key in a separate request.
- Tables only where an actual comparison table would itself be a question
  worth including (rare).
- key_facts: use an empty list. This file must not contain revision facts or answers.
- A short methodology statement describing the source basis.
"""
    else:
        content_requirements = f"""
CONTENT REQUIREMENTS:
- A clear professional title.
- A concise 2-4 sentence summary.
- {max(6, min(target_sections, 16))} substantive sections.
- Each section: heading, concise body, 3-6 useful bullets where appropriate.
- Tables only where actual tabular comparison/data improves clarity.
- 6-12 key_facts suitable for an Excel summary sheet.
- A short methodology statement describing the source basis.
- Keep bullets concise enough for presentation slides.
"""

    prompt = f"""
You are FRIDAY's document-production research engine.
Create a high-quality, source-grounded content package about: {topic!r}

NON-NEGOTIABLE ACCURACY RULES:
1. Use ONLY facts supported by the supplied source material.
2. Do not invent statistics, dates, quotations, names, measurements, prices,
   scientific claims, or references.
3. If sources disagree, explicitly state that they disagree and identify the
   relevant source numbers.
4. Every section must contain source_ids pointing to the supplied source
   numbers that actually support it.
5. Do not cite a source merely because it is about the topic.
6. Prefer primary/official/academic sources when the supplied material permits.
7. Keep claims precise and distinguish established facts from interpretation.
8. The package will be rendered into Word, PDF, PowerPoint and Excel, so make
   the content useful in all four formats.
{content_requirements}
Return ONLY valid JSON with this exact top-level structure:
{{
  "title": "...",
  "summary": "...",
  "methodology": "...",
  "key_facts": ["..."],
  "sections": [
    {{
      "heading": "...",
      "body": "...",
      "bullets": ["...", "...", "..."],
      "source_ids": [1, 2],
      "table": {{
        "headers": ["...", "..."],
        "rows": [["...", "..."], ["...", "..."]]
      }}
    }}
  ]
}}

Do not include a table key if a table is not genuinely useful.

SUPPLIED SOURCES:
{source_text}
"""

    def call(p):
        # V2037: shared Gemini layer = real error reasons + model self-healing. A larger
        # output budget stops long JSON packages being cut off; if the API rejects that
        # setting we retry with the plain call the rest of FRIDAY already uses.
        try:
            from google.genai import types as _gt
            response = friday_backend._gemini_generate(p, config=_gt.GenerateContentConfig(max_output_tokens=16000))
        except Exception:
            if friday_backend._GEMINI_LAST_ERROR_KIND in ("key", "quota", "network", "busy", "model"):
                raise
            response = friday_backend._gemini_generate(p)
        return (friday_backend._response_text(response) or "").strip()

    raw = call(prompt)
    try:
        try:
            return _normalise_plan(_extract_json_object(raw), topic)
        except Exception:
            salvaged = friday_backend._salvage_truncated_json(raw)   # JSON cut off by a token limit
            if not salvaged:
                raise
            return _normalise_plan(salvaged, topic)
    except Exception as first_error:
        repair_prompt = f"""
Repair the following attempted JSON content package.
Return ONLY valid JSON matching the requested schema. Do not add facts.
Preserve all factual claims unless they are malformed. Ensure every section
has source_ids and that source_ids are integers referring only to the supplied
source numbers.

ATTEMPTED RESPONSE:
{raw[:30000]}

ORIGINAL REQUIREMENT:
{prompt}
"""
        try:
            repaired = call(repair_prompt)
            return _normalise_plan(_extract_json_object(repaired), topic)
        except Exception as second_error:
            raise RuntimeError(
                f"Gemini content package could not be validated: {first_error}; repair also failed: {second_error}"
            ) from second_error


# ============================================================
# DOCX
# ============================================================


def _set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def _set_cell_margins(cell, top=90, start=100, bottom=90, end=100):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in("w:tcMar")
    if tcMar is None:
        tcMar = OxmlElement("w:tcMar")
        tcPr.append(tcMar)
    for m, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcMar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tcMar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def _add_docx_source_line(doc, source_ids, sources):
    valid = [i for i in source_ids if 1 <= i <= len(sources)]
    if not valid:
        return
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(3)
    r = p.add_run("Sources: " + ", ".join(f"[{i}]" for i in valid))
    r.italic = True
    r.font.size = Pt(8)
    r.font.color.rgb = __import__("docx").shared.RGBColor.from_string(_MUTED)


def _build_docx(plan, sources, path):
    def save(tmp):
        doc = Document()
        section = doc.sections[0]
        section.top_margin = Inches(0.7)
        section.bottom_margin = Inches(0.7)
        section.left_margin = Inches(0.8)
        section.right_margin = Inches(0.8)

        styles = doc.styles
        styles["Normal"].font.name = "Aptos"
        styles["Normal"].font.size = Pt(10.5)
        styles["Title"].font.name = "Aptos Display"
        styles["Title"].font.size = Pt(26)
        styles["Heading 1"].font.name = "Aptos Display"
        styles["Heading 1"].font.size = Pt(17)
        styles["Heading 1"].font.color.rgb = __import__("docx").shared.RGBColor.from_string(_CYAN_DARK)
        styles["Heading 2"].font.name = "Aptos"
        styles["Heading 2"].font.size = Pt(13)

        title = doc.add_paragraph(style="Title")
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title.add_run(plan["title"])
        subtitle = doc.add_paragraph()
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = subtitle.add_run("FRIDAY Research Brief")
        run.font.size = Pt(10)
        run.font.color.rgb = __import__("docx").shared.RGBColor.from_string(_CYAN_DARK)

        if plan.get("summary"):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(12)
            r = p.add_run(plan["summary"])
            r.bold = True

        if plan.get("key_facts"):
            doc.add_heading("Key facts", level=1)
            for fact in plan["key_facts"]:
                doc.add_paragraph(fact, style="List Bullet")

        for section_data in plan["sections"]:
            doc.add_heading(section_data["heading"], level=1)
            if section_data.get("body"):
                doc.add_paragraph(section_data["body"])
            for bullet in section_data.get("bullets", []):
                doc.add_paragraph(bullet, style="List Bullet")

            table = section_data.get("table")
            if table and table.get("headers"):
                headers = table["headers"]
                t = doc.add_table(rows=1, cols=len(headers))
                t.autofit = True
                try:
                    t.style = "Table Grid"
                except Exception:
                    pass
                for i, header in enumerate(headers):
                    cell = t.rows[0].cells[i]
                    cell.text = header
                    _set_cell_shading(cell, _NAVY)
                    _set_cell_margins(cell)
                    for p in cell.paragraphs:
                        for r in p.runs:
                            r.bold = True
                            r.font.color.rgb = __import__("docx").shared.RGBColor.from_string(_WHITE)
                            r.font.size = Pt(9)
                for row in table.get("rows", []):
                    cells = t.add_row().cells
                    for i, value in enumerate(row):
                        if i >= len(cells):
                            break
                        cells[i].text = value
                        _set_cell_margins(cells[i])
                        cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
                        for p in cells[i].paragraphs:
                            for r in p.runs:
                                r.font.size = Pt(9)

            _add_docx_source_line(doc, section_data.get("source_ids", []), sources)

        doc.add_page_break()
        doc.add_heading("Methodology & sources", level=1)
        if plan.get("methodology"):
            doc.add_paragraph(plan["methodology"])
        for i, (url, _text) in enumerate(sources, start=1):
            p = doc.add_paragraph(style="List Number")
            p.add_run(f"[{i}] ").bold = True
            p.add_run(url)

        doc.save(str(tmp))

    _atomic_save(path, save)
    # Structural validation.
    check = Document(str(path))
    if not check.paragraphs:
        raise RuntimeError("DOCX validation failed: no paragraphs found.")


# ============================================================
# PDF
# ============================================================


def _pdf_safe(text):
    # ReportLab Paragraph understands a small HTML subset.
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


class _NumberedDocTemplate(BaseDocTemplate):
    def __init__(self, filename, **kwargs):
        super().__init__(filename, **kwargs)
        frame = Frame(
            self.leftMargin,
            self.bottomMargin,
            self.width,
            self.height,
            id="normal",
        )
        self.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=self._header_footer)])

    def _header_footer(self, canvas, doc):
        canvas.saveState()
        w, h = LETTER
        canvas.setStrokeColor(colors.HexColor("#" + _CYAN))
        canvas.setLineWidth(0.7)
        canvas.line(doc.leftMargin, h - 0.48 * inch, w - doc.rightMargin, h - 0.48 * inch)
        canvas.setFillColor(colors.HexColor("#" + _MUTED))
        canvas.setFont("Helvetica", 7.5)
        canvas.drawString(doc.leftMargin, 0.35 * inch, "FRIDAY Research Brief")
        canvas.drawRightString(w - doc.rightMargin, 0.35 * inch, f"Page {doc.page}")
        canvas.restoreState()


def _build_pdf(plan, sources, path):
    def save(tmp):
        styles = getSampleStyleSheet()
        title = ParagraphStyle(
            "JTitle", parent=styles["Title"], fontName="Helvetica-Bold",
            fontSize=23, leading=28, alignment=TA_CENTER,
            textColor=colors.HexColor("#" + _NAVY), spaceAfter=10,
        )
        subtitle = ParagraphStyle(
            "JSubtitle", parent=styles["BodyText"], fontName="Helvetica",
            fontSize=9, leading=12, alignment=TA_CENTER,
            textColor=colors.HexColor("#" + _CYAN_DARK), spaceAfter=18,
        )
        h1 = ParagraphStyle(
            "JH1", parent=styles["Heading1"], fontName="Helvetica-Bold",
            fontSize=15, leading=18, textColor=colors.HexColor("#" + _CYAN_DARK),
            spaceBefore=12, spaceAfter=7,
        )
        body = ParagraphStyle(
            "JBody", parent=styles["BodyText"], fontName="Helvetica",
            fontSize=9.7, leading=14, textColor=colors.HexColor("#" + _DARK_TEXT),
            spaceAfter=6,
        )
        bullet = ParagraphStyle(
            "JBullet", parent=body, leftIndent=13, firstLineIndent=-7,
            bulletIndent=5, spaceAfter=3,
        )
        source = ParagraphStyle(
            "JSource", parent=body, fontSize=7.6, leading=10,
            textColor=colors.HexColor("#" + _MUTED),
        )

        doc = _NumberedDocTemplate(
            str(tmp), pagesize=LETTER,
            leftMargin=0.65 * inch, rightMargin=0.65 * inch,
            topMargin=0.68 * inch, bottomMargin=0.62 * inch,
            title=plan["title"], author="FRIDAY",
        )
        story = [
            Spacer(1, 0.25 * inch),
            Paragraph(_pdf_safe(plan["title"]), title),
            Paragraph("FRIDAY Research Brief", subtitle),
        ]
        if plan.get("summary"):
            story += [Paragraph(_pdf_safe(plan["summary"]), body), Spacer(1, 6)]

        if plan.get("key_facts"):
            story.append(Paragraph("Key facts", h1))
            for fact in plan["key_facts"]:
                story.append(Paragraph("• " + _pdf_safe(fact), bullet))

        for sec in plan["sections"]:
            block = [Paragraph(_pdf_safe(sec["heading"]), h1)]
            if sec.get("body"):
                block.append(Paragraph(_pdf_safe(sec["body"]), body))
            for b in sec.get("bullets", []):
                block.append(Paragraph("• " + _pdf_safe(b), bullet))

            table = sec.get("table")
            if table and table.get("headers"):
                data = [[_pdf_safe(x) for x in table["headers"]]]
                for row in table.get("rows", []):
                    data.append([_pdf_safe(x) for x in row])
                col_count = len(table["headers"])
                available = 7.2 * inch
                widths = [available / max(1, col_count)] * col_count
                t = Table(data, colWidths=widths, repeatRows=1, hAlign="LEFT")
                t.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#" + _NAVY)),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 7.5),
                    ("LEADING", (0, 0), (-1, -1), 9),
                    ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#" + _GRID)),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#" + _LIGHT)]),
                    ("LEFTPADDING", (0, 0), (-1, -1), 5),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]))
                block += [Spacer(1, 5), t]

            valid = [i for i in sec.get("source_ids", []) if 1 <= i <= len(sources)]
            if valid:
                block += [Spacer(1, 3), Paragraph(
                    "Sources: " + ", ".join(f"[{i}]" for i in valid), source
                )]
            story.append(KeepTogether(block))

        story += [PageBreak(), Paragraph("Methodology & sources", h1)]
        if plan.get("methodology"):
            story.append(Paragraph(_pdf_safe(plan["methodology"]), body))
        for i, (url, _text) in enumerate(sources, start=1):
            story.append(Paragraph(f"[{i}] {_pdf_safe(url)}", source))
            story.append(Spacer(1, 4))

        doc.build(story)

    _atomic_save(path, save)

    # Validate by asking ReportLab/PyPDF2-compatible parser to read the file.
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(path))
        if not reader.pages:
            raise RuntimeError("PDF validation failed: no pages found.")
    except ImportError:
        _validate_nonempty(path)


# ============================================================
# EXCEL
# ============================================================


def _style_header_row(ws, row=1):
    fill = PatternFill("solid", fgColor=_NAVY)
    font = Font(color=_WHITE, bold=True)
    side = Side(style="thin", color=_GRID)
    for cell in ws[row]:
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(vertical="top", wrap_text=True)
        cell.border = Border(bottom=side)


def _autofit(ws, max_width=55):
    for column_cells in ws.columns:
        letter = get_column_letter(column_cells[0].column)
        max_len = 0
        for cell in column_cells:
            value = "" if cell.value is None else str(cell.value)
            max_len = max(max_len, max((len(line) for line in value.splitlines()), default=0))
        ws.column_dimensions[letter].width = min(max(max_len + 2, 10), max_width)


def _add_excel_table(ws, ref, name):
    if ref.count(":") == 0:
        return
    tab = XLTable(displayName=name, ref=ref)
    style = TableStyleInfo(name="TableStyleMedium2", showFirstColumn=False,
                           showLastColumn=False, showRowStripes=True, showColumnStripes=False)
    tab.tableStyleInfo = style
    ws.add_table(tab)


def _build_xlsx(plan, sources, path):
    def save(tmp):
        wb = Workbook()
        ws = wb.active
        ws.title = "Overview"
        ws.freeze_panes = "A3"
        ws["A1"] = plan["title"]
        ws["A1"].font = Font(size=18, bold=True, color=_NAVY)
        ws.merge_cells("A1:D1")
        ws["A2"] = "Summary"
        ws["B2"] = plan.get("summary", "")
        ws["A2"].font = Font(bold=True, color=_CYAN_DARK)
        ws["A2"].alignment = Alignment(vertical="top")
        ws["B2"].alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[2].height = 65

        start = 4
        ws.cell(start, 1, "Key fact")
        ws.cell(start, 2, "Source IDs")
        _style_header_row(ws, start)
        for idx, fact in enumerate(plan.get("key_facts", []), start=start + 1):
            ws.cell(idx, 1, fact)
            ws.cell(idx, 2, "See section/source mapping")
            ws.cell(idx, 1).alignment = Alignment(wrap_text=True, vertical="top")
            ws.cell(idx, 2).alignment = Alignment(wrap_text=True, vertical="top")
        if plan.get("key_facts"):
            _add_excel_table(ws, f"A{start}:B{start + len(plan['key_facts'])}", "KeyFacts")

        # One worksheet per genuine table plus a structured section sheet.
        section_sheet = wb.create_sheet("Sections")
        section_sheet.append(["Section", "Body", "Bullets", "Source IDs"])
        _style_header_row(section_sheet, 1)
        for sec in plan["sections"]:
            section_sheet.append([
                sec["heading"],
                sec.get("body", ""),
                "\n".join(f"• {b}" for b in sec.get("bullets", [])),
                ", ".join(str(i) for i in sec.get("source_ids", [])),
            ])
        for row in section_sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical="top")
        _add_excel_table(section_sheet, f"A1:D{section_sheet.max_row}", "SectionsTable")
        section_sheet.freeze_panes = "A2"

        table_number = 0
        for sec in plan["sections"]:
            table = sec.get("table")
            if not table or not table.get("headers"):
                continue
            table_number += 1
            title = re.sub(r"[^A-Za-z0-9 _-]", "", sec["heading"]).strip() or f"Table {table_number}"
            title = title[:25]
            sheet_name = f"T{table_number:02d} {title}"[:31]
            ws2 = wb.create_sheet(sheet_name)
            ws2.append(table["headers"])
            _style_header_row(ws2, 1)
            for row in table.get("rows", []):
                ws2.append(row[:len(table["headers"])])
            for row in ws2.iter_rows():
                for cell in row:
                    cell.alignment = Alignment(wrap_text=True, vertical="top")
            ws2.freeze_panes = "A2"
            if ws2.max_row >= 2:
                _add_excel_table(ws2, f"A1:{get_column_letter(ws2.max_column)}{ws2.max_row}", f"DataTable{table_number}")
            _autofit(ws2)

        src = wb.create_sheet("Sources")
        src.append(["ID", "URL"])
        _style_header_row(src, 1)
        for i, (url, _text) in enumerate(sources, start=1):
            src.append([i, url])
            src.cell(i + 1, 2).hyperlink = url
            src.cell(i + 1, 2).style = "Hyperlink"
        src.freeze_panes = "A2"
        _autofit(src, max_width=100)
        _autofit(ws)
        _autofit(section_sheet, max_width=70)

        # Workbook metadata.
        wb.properties.title = plan["title"]
        wb.properties.subject = "FRIDAY source-grounded research workbook"
        wb.properties.creator = "FRIDAY"
        wb.save(str(tmp))

    _atomic_save(path, save)
    check = load_workbook(str(path), read_only=True, data_only=False)
    if "Overview" not in check.sheetnames or "Sources" not in check.sheetnames:
        check.close()
        raise RuntimeError("XLSX validation failed: required worksheets are missing.")
    check.close()


# ============================================================
# POWERPOINT
# ============================================================


# V2045 presentation-quality redesign. Per the pptx skill's design
# guidance (never default to Aptos -- it has no reliable metric-compatible
# substitute and ships inconsistently; pick a header/body font PAIR;
# commit to ONE dominant color with a single sharp accent rather than
# flat two-tone equality; vary layouts instead of repeating one
# title+bullets template on every slide). _GOLD is the new "one sharp
# accent" used sparingly (numbering, the callout layout) so it reads as
# a deliberate highlight rather than decoration.
_HEADER_FONT = "Cambria"   # safe-list serif with personality (skill: renders true-to-width, ships with Office)
_BODY_FONT = "Calibri"     # safe-list sans body font
_GOLD = "F4C95D"


def _ppt_add_textbox(slide, left, top, width, height, text, font_size=18,
                     bold=False, color=_WHITE, align=PP_ALIGN.LEFT, font=None):
    box = slide.shapes.add_textbox(PInches(left), PInches(top), PInches(width), PInches(height))
    tf = box.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.margin_left = PInches(0.05)
    tf.margin_right = PInches(0.05)
    tf.margin_top = PInches(0.03)
    tf.margin_bottom = PInches(0.03)
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = str(text)
    r.font.name = font or _BODY_FONT
    r.font.size = PPt(font_size)
    r.font.bold = bold
    r.font.color.rgb = RGBColor.from_string(color)
    return box


def _ppt_background(slide):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor.from_string(_NAVY)
    # Subtle framing lines; no UI changes, only generated deck design.
    line = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, PInches(0.18), PInches(0.18),
        PInches(12.97), PInches(7.14)
    )
    line.fill.background()
    line.line.color.rgb = RGBColor.from_string(_CYAN_DARK)
    line.line.width = PPt(0.7)


def _ppt_title(slide, title, section_no=None):
    _ppt_add_textbox(slide, 0.65, 0.42, 11.9, 0.75, title, 32, True, _WHITE, font=_HEADER_FONT)
    slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, PInches(0.67), PInches(1.18), PInches(1.15), PInches(0.04)).fill.solid()
    accent = slide.shapes[-1]
    accent.fill.fore_color.rgb = RGBColor.from_string(_CYAN)
    accent.line.fill.background()
    if section_no is not None:
        _ppt_circle_number(slide, 11.75, 0.42, 0.7, section_no)


def _ppt_circle_number(slide, left, top, diameter, number, color=_GOLD):
    """One small colored circle with a number inside -- the 'icon in a
    colored circle' motif the pptx skill recommends, repeated
    consistently across the deck instead of a bare accent stripe."""
    circle = slide.shapes.add_shape(MSO_SHAPE.OVAL, PInches(left), PInches(top), PInches(diameter), PInches(diameter))
    circle.fill.solid()
    circle.fill.fore_color.rgb = RGBColor.from_string(color)
    circle.line.fill.background()
    tf = circle.text_frame
    tf.word_wrap = False
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    r = p.add_run()
    r.text = f"{number:02d}" if isinstance(number, int) else str(number)
    r.font.name = _BODY_FONT
    r.font.bold = True
    r.font.size = PPt(13)
    r.font.color.rgb = RGBColor.from_string(_NAVY)
    return circle


def _ppt_footer_citations(slide, source_ids, sources):
    """Slim footer strip of just the citation numbers used on this
    slide, replacing the old full-width sidebar that spent a third of
    EVERY slide on a bare list of domain names -- content now gets the
    full slide width, and the reader who wants the actual source can
    still see exactly which numbers back this slide's claims."""
    valid = [i for i in source_ids if 1 <= i <= len(sources)]
    if not valid:
        return
    text = "Sources: " + ", ".join(
        f"[{i}] {urlparse(sources[i-1][0]).netloc.replace('www.', '') or sources[i-1][0]}" for i in valid[:4]
    )
    _ppt_add_textbox(slide, 0.85, 6.95, 11.6, 0.35, text, 9, False, _MUTED)


def _ppt_layout_bullets(slide, bullets, sources, source_ids):
    """Default layout: full-width bullet rows, each with a small
    numbered accent circle instead of a plain bullet dot ('icon + text
    row' motif) -- used when a section has several points to make."""
    top = 1.55
    row_height = min(1.05, 4.9 / max(1, len(bullets)))
    for idx, bullet in enumerate(bullets):
        y = top + idx * row_height
        _ppt_circle_number(slide, 0.85, y + 0.03, 0.42, idx + 1, color=_CYAN)
        _ppt_add_textbox(slide, 1.5, y, 10.9, row_height, bullet,
                          16 if len(bullets) <= 5 else 14, False, _WHITE)
    _ppt_footer_citations(slide, source_ids, sources)


def _ppt_layout_callout(slide, headline, sources, source_ids):
    """Big-stat/callout layout: used when a section boils down to one
    short, punchy point -- per the skill's 'large stat callouts'
    layout idea, instead of forcing a one-line section into the same
    bullet template as everything else."""
    _ppt_add_textbox(slide, 1.2, 2.7, 10.9, 2.2, headline, 34, True, _GOLD, PP_ALIGN.CENTER, font=_HEADER_FONT)
    line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, PInches(5.9), PInches(4.55), PInches(1.5), PInches(0.05))
    line.fill.solid(); line.fill.fore_color.rgb = RGBColor.from_string(_CYAN); line.line.fill.background()
    _ppt_footer_citations(slide, source_ids, sources)


def _ppt_layout_table(slide, bullets, table, sources, source_ids):
    """Full-width table layout: previously every table was squeezed
    into a 1.15in strip UNDER a bullets+evidence-panel layout meant for
    prose, often visually cramped or overlapping. A section with real
    tabular data now gets the width and height a table actually needs."""
    lead = bullets[0] if bullets else ""
    top = 1.55
    if lead:
        _ppt_add_textbox(slide, 0.85, top, 11.6, 0.6, lead, 15, False, _MUTED)
        top += 0.7
    headers = table["headers"][:6]
    rows = table.get("rows", [])[:8]
    shape = slide.shapes.add_table(len(rows) + 1, len(headers), PInches(0.85), PInches(top), PInches(11.6), PInches(min(4.8, 0.5 * (len(rows) + 1))))
    tbl = shape.table
    for c, h in enumerate(headers):
        cell = tbl.cell(0, c)
        cell.text = h
        cell.fill.solid()
        cell.fill.fore_color.rgb = RGBColor.from_string(_CYAN_DARK)
    for r, row in enumerate(rows, start=1):
        for c, value in enumerate(row[:len(headers)]):
            tbl.cell(r, c).text = value
    for row_cells in tbl.rows:
        for cell in row_cells.cells:
            cell.text_frame.word_wrap = True
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            for p in cell.text_frame.paragraphs:
                for run in p.runs:
                    run.font.name = _BODY_FONT
                    run.font.size = PPt(11)
                    run.font.color.rgb = RGBColor.from_string(_WHITE)
    _ppt_footer_citations(slide, source_ids, sources)


def _build_pptx(plan, sources, path, slide_count=None):
    def save(tmp):
        prs = Presentation()
        prs.slide_width = PInches(13.333)
        prs.slide_height = PInches(7.5)
        blank = prs.slide_layouts[6]

        # Cover.
        slide = prs.slides.add_slide(blank)
        _ppt_background(slide)
        _ppt_add_textbox(slide, 0.85, 1.7, 11.65, 1.6, plan["title"], 40, True, _WHITE, PP_ALIGN.CENTER, font=_HEADER_FONT)
        _ppt_add_textbox(slide, 1.4, 3.5, 10.55, 1.0, plan.get("summary", ""), 16, False, _MUTED, PP_ALIGN.CENTER)
        _ppt_add_textbox(slide, 4.6, 5.6, 4.1, 0.35, "SOURCE-GROUNDED BRIEFING", 10, True, _CYAN, PP_ALIGN.CENTER)

        sections = plan["sections"]
        if slide_count:
            sections = sections[:max(1, int(slide_count))]

        for n, sec in enumerate(sections, start=1):
            slide = prs.slides.add_slide(blank)
            _ppt_background(slide)
            _ppt_title(slide, sec["heading"], n)

            bullets = [str(b) for b in sec.get("bullets", []) if str(b).strip()]
            if not bullets and sec.get("body"):
                bullets = [sec["body"]]
            bullets = bullets[:6]
            table = sec.get("table")
            source_ids = sec.get("source_ids", [])

            # V2045: pick a layout that fits what this section actually
            # contains, instead of stamping every slide with the same
            # bullets+sidebar template regardless of content.
            if table and table.get("headers"):
                _ppt_layout_table(slide, bullets, table, sources, source_ids)
            elif len(bullets) == 1 and len(bullets[0]) <= 90:
                _ppt_layout_callout(slide, bullets[0], sources, source_ids)
            elif bullets:
                _ppt_layout_bullets(slide, bullets, sources, source_ids)
            else:
                _ppt_footer_citations(slide, source_ids, sources)

        # Sources slide.
        slide = prs.slides.add_slide(blank)
        _ppt_background(slide)
        _ppt_title(slide, "Sources")
        box = slide.shapes.add_textbox(PInches(0.8), PInches(1.45), PInches(11.8), PInches(5.4))
        tf = box.text_frame
        tf.clear()
        tf.word_wrap = True
        for idx, (url, _text) in enumerate(sources, start=1):
            p = tf.paragraphs[0] if idx == 1 else tf.add_paragraph()
            p.text = f"[{idx}] {url}"
            p.font.name = _BODY_FONT
            p.font.size = PPt(11)
            p.font.color.rgb = RGBColor.from_string(_WHITE)
            p.space_after = PPt(8)

        prs.core_properties.title = plan["title"]
        prs.core_properties.author = "FRIDAY"
        prs.save(str(tmp))

    _atomic_save(path, save)
    check = Presentation(str(path))
    if len(check.slides) < 2:
        raise RuntimeError("PPTX validation failed: expected at least cover + sources slides.")


# ============================================================
# OPENDOCUMENT (ODT / ODS / ODP)
# ============================================================


def _require_odf():
    if not ODF_AVAILABLE:
        raise RuntimeError("OpenDocument support requires odfpy. Install: py -3.13 -m pip install odfpy")


def _build_odt(plan, sources, path):
    _require_odf()
    doc = OpenDocumentText()
    doc.text.addElement(H(outlinelevel=1, text=plan["title"]))
    if plan.get("summary"):
        doc.text.addElement(P(text=plan["summary"]))
    for fact in plan.get("key_facts", []):
        doc.text.addElement(P(text="• " + fact))
    for sec in plan["sections"]:
        doc.text.addElement(H(outlinelevel=2, text=sec["heading"]))
        if sec.get("body"):
            doc.text.addElement(P(text=sec["body"]))
        for bullet in sec.get("bullets", []):
            doc.text.addElement(P(text="• " + bullet))
        table = sec.get("table")
        if table and table.get("headers"):
            t = ODFTable(name="Data")
            hr = ODFTableRow()
            for h in table["headers"]:
                c = ODFTableCell(); c.addElement(P(text=h)); hr.addElement(c)
            t.addElement(hr)
            for row in table.get("rows", []):
                rr = ODFTableRow()
                for value in row[:len(table["headers"])]:
                    c = ODFTableCell(); c.addElement(P(text=str(value))); rr.addElement(c)
                t.addElement(rr)
            doc.text.addElement(t)
    doc.text.addElement(H(outlinelevel=1, text="Methodology & sources"))
    if plan.get("methodology"):
        doc.text.addElement(P(text=plan["methodology"]))
    for i, (url, _) in enumerate(sources, 1):
        doc.text.addElement(P(text=f"[{i}] {url}"))
    _atomic_save(path, lambda tmp: doc.save(str(tmp)))
    _validate_nonempty(path)


def _build_ods(plan, sources, path):
    _require_odf()
    doc = OpenDocumentSpreadsheet()
    from odf.table import TableColumn
    def add_sheet(name, headers, rows):
        t = ODFTable(name=name[:31] or "Sheet")
        for _ in headers:
            t.addElement(TableColumn())
        r = ODFTableRow()
        for h in headers:
            c = ODFTableCell(); c.addElement(P(text=str(h))); r.addElement(c)
        t.addElement(r)
        for row in rows:
            rr = ODFTableRow()
            for value in row[:len(headers)]:
                c = ODFTableCell(); c.addElement(P(text="" if value is None else str(value))); rr.addElement(c)
            t.addElement(rr)
        doc.spreadsheet.addElement(t)
    add_sheet("Overview", ["Field", "Value"], [["Title", plan["title"]], ["Summary", plan.get("summary", "")]])
    facts = [[fact, ""] for fact in plan.get("key_facts", [])]
    add_sheet("Key Facts", ["Fact", "Notes"], facts or [["No key facts supplied", ""]])
    for idx, sec in enumerate(plan["sections"], 1):
        table = sec.get("table")
        if table and table.get("headers"):
            add_sheet(f"Section {idx}", table["headers"], table.get("rows", []))
    add_sheet("Sources", ["ID", "URL"], [[i, u] for i, (u, _) in enumerate(sources, 1)])
    _atomic_save(path, lambda tmp: doc.save(str(tmp)))
    _validate_nonempty(path)


def _build_odp(plan, sources, path, slide_count=None):
    _require_odf()
    doc = OpenDocumentPresentation()
    layout = PageLayout(name="FRIDAYSlideLayout")
    layout.addElement(PageLayoutProperties(pagewidth="28cm", pageheight="15.75cm", margin="0cm"))
    doc.automaticstyles.addElement(layout)
    master = MasterPage(name="FRIDAYMaster", pagelayoutname="FRIDAYSlideLayout")
    doc.masterstyles.addElement(master)
    def add_slide(title, lines):
        page = Page(name=f"Slide {len(doc.presentation.childNodes)+1}", masterpagename="FRIDAYMaster")
        frame = ODFFrame(width="24cm", height="3cm", x="1cm", y="1cm")
        box = TextBox()
        box.addElement(P(text=title))
        frame.addElement(box); page.addElement(frame)
        y = 4
        for line in lines[:8]:
            frame2 = ODFFrame(width="22cm", height="1cm", x="1cm", y=f"{y}cm")
            box2 = TextBox(); box2.addElement(P(text="• " + str(line)))
            frame2.addElement(box2); page.addElement(frame2); y += 1.15
        doc.presentation.addElement(page)
    add_slide(plan["title"], [plan.get("summary", "")])
    sections = plan["sections"][:max(1, int(slide_count))] if slide_count else plan["sections"]
    for sec in sections:
        lines = list(sec.get("bullets", [])) or ([sec.get("body", "")] if sec.get("body") else [])
        add_slide(sec["heading"], lines)
    add_slide("Sources", [f"[{i}] {u}" for i, (u, _) in enumerate(sources, 1)])
    _atomic_save(path, lambda tmp: doc.save(str(tmp)))
    _validate_nonempty(path)


# ============================================================
# REQUEST PARSING — preserves existing routing semantics
# ============================================================


def _fuzzy_has(text, targets, cutoff=0.8):
    """True if any word in `text` is a close (typo-tolerant) match for one of `targets`."""
    import difflib
    for w in re.findall(r"[a-z0-9]+", str(text or "").lower()):
        if len(w) >= 3 and difflib.get_close_matches(w, targets, n=1, cutoff=cutoff):
            return True
    return False


def _parse_project_request(command):
    original = str(command or "").strip()
    c = original.lower()
    wants = set()

    # V2037: tolerant of typos / speech-to-text slips ("documetn", "presentaion", "word doc").
    if any(w in c for w in ("presentation", "slides", "slideshow", "pptx", "slide deck", "deck")) \
            or _fuzzy_has(c, ["presentation", "powerpoint"], 0.82):
        wants.add("pptx")
    if any(w in c for w in ("odp", "open document presentation", "openoffice presentation")):
        wants.add("odp")
    if "pdf" in c:
        wants.add("pdf")
    if any(w in c for w in ("spreadsheet", "excel", "xlsx", "excel sheet")):
        wants.add("xlsx")
    if any(w in c for w in ("ods", "open document spreadsheet", "openoffice spreadsheet")):
        wants.add("ods")
    _is_word = (
        any(w in c for w in ("word document", "docx", "research notes", "report"))
        or ("document" in c and "presentation" not in c)
        or (_fuzzy_has(c, ["document", "documents", "docx"], 0.8) and "presentation" not in c)
        or bool(re.search(r"\bdocs?\b", c))
        or bool(re.search(r"\b(?:ms\s+|microsoft\s+)?word\s+(?:doc\w*|file|format|report)\b", c))
        or bool(re.search(r"\b(?:in|as|into|to)\s+(?:a\s+|an\s+)?(?:ms\s+|microsoft\s+)?word\b", c))
    )
    if _is_word:
        wants.add("docx")
    if any(w in c for w in ("odt", "open document text", "openoffice document")):
        wants.add("odt")
    if not wants:
        wants.add("pptx")

    slide_count = None
    m = re.search(r"(\d{1,2})\s*[- ]?slides?\b", c)
    if m:
        slide_count = max(3, min(30, int(m.group(1))))

    topic = _display_topic(original)
    doc_style = _detect_document_style(original)
    return topic, wants, slide_count, doc_style


# ============================================================
# DOCUMENT STYLE DETECTION (V2038 "smarter documents" upgrade)
# ============================================================
# Previously every "create a document/presentation/... about X" request
# produced the exact same generic report-style layout (heading/body/
# bullets per section) no matter how the request was phrased. Asking for
# "a document containing questions on photosynthesis" still produced a
# generic research essay rather than an actual set of questions -- the
# content was still real, source-grounded research, but not shaped the
# way the user actually asked for it.
#
# This keeps the exact same research pipeline (still real web research,
# still source-grounded, still the same JSON plan schema so every existing
# file builder below needs no changes) and only changes how _plan_content
# below instructs Gemini to *shape* that researched content when the
# request is clearly asking for a set of questions rather than a report.
_QUESTION_STYLE_PATTERNS = (
    r"\bquestions?\b",
    r"\brequests?\s+(?:on|about|for)\b",
    r"\bquestion\s+paper\b",
    r"\bquestion\s+bank\b",
    r"\bquiz\b",
    r"\bq\s*(?:&|and)\s*a\b",
    r"\bpractice\s+(?:questions|problems|exercises)\b",
    r"\bexam\s+questions\b",
    r"\brevision\s+questions\b",
    r"\btest\s+questions\b",
)


def _detect_document_style(command):
    """Return 'questions' when the request is clearly asking for a set of
    questions on a topic rather than a written report/summary; otherwise
    'standard'. Deliberately conservative (keyword-anchored, like the rest
    of the Creation Engine's intent parsing) so a request that merely
    happens to mention "question" in passing does not accidentally change
    the shape of an otherwise normal report request -- it must look like
    the actual subject of what's being built.
    """
    c = str(command or "").lower()
    for pattern in _QUESTION_STYLE_PATTERNS:
        if re.search(pattern, c):
            return "questions"
    return "standard"


def _question_library_plan(topic):
    """Convert curated study material into a question-only document plan."""
    try:
        import friday_notes_knowledge
        entry = friday_notes_knowledge.lookup(topic, "", "")
        if not entry:
            return None
        questions=[]
        for item in entry.get("questions", []) if isinstance(entry, dict) else []:
            q = item.get("question") if isinstance(item, dict) else str(item)
            if q and q.strip():
                questions.append(q.strip())
        # The curated knowledge base usually stores teaching facts rather than
        # a dedicated question list. Turn those headings/facts into prompts
        # without copying their answers into the student sheet.
        if isinstance(entry, dict):
            for item in entry.get("worked_examples", []) or []:
                q = item.get("question") if isinstance(item, dict) else ""
                if q and q.strip(): questions.append(q.strip())
            for item in entry.get("key_points", []) or []:
                text = str(item).strip()
                if text: questions.append(f"Explain the following key point about {topic}: {text}")
            for item in entry.get("key_ideas", []) or []:
                text = str(item).strip()
                if text: questions.append(f"Explain why the following idea is important in {topic}: {text}")
        questions = list(dict.fromkeys(q for q in questions if q))
        if not questions:
            return None
        questions = questions[:20]
        return {
            "title": f"{topic} -- Study Questions",
            "summary": "", "methodology": "Questions generated from FRIDAY's curated study reference material.",
            "key_facts": [],
            "sections": [{"heading": f"Q{i}: {q}", "body": "", "bullets": [], "source_ids": []} for i,q in enumerate(questions,1)]
        }
    except Exception as error:
        print("Question library fallback failed:", error)
        return None


# ============================================================
# PROJECT ORCHESTRATION — PUBLIC API UNCHANGED
# ============================================================


def _library_plan(topic):
    """Curated offline content package for topics FRIDAY holds in its reference library."""
    try:
        import friday_notes_knowledge
        entry = friday_notes_knowledge.lookup(topic, "", "")
        return friday_notes_knowledge.to_plan(entry, topic) if entry else None
    except Exception as error:
        print("Library plan lookup failed:", error)
        return None


def _ai_fail_phrase():
    """Short spoken reason for the last Gemini failure (empty when unknown)."""
    try:
        import friday_backend
        kind, why = friday_backend._classify_gemini_error(RuntimeError(friday_backend._GEMINI_LAST_ERROR or ""))
        return why if friday_backend._GEMINI_LAST_ERROR else "my AI planner didn't answer"
    except Exception:
        return "my AI planner didn't answer"


def create_project_command(command, reuse_sources=None, reuse_topic=None, speak_progress=True):
    import friday_backend
    import friday_web_research
    import friday_persona
    import friday_context

    LAST_PROJECT.update(time=0.0, topic="", folder="", files=[], ok=False, note="")
    topic, wants, slide_count, doc_style = _parse_project_request(command)
    if not topic:
        if speak_progress:
            friday_backend.speak("What topic would you like me to research and build this on?")
        return True

    display_topic = reuse_topic or topic
    if reuse_sources:
        if speak_progress:
            friday_backend.speak(friday_persona.line("creation_ack_reuse", topic=display_topic))
        sources = reuse_sources
    else:
        if speak_progress:
            friday_backend.speak(friday_persona.line("creation_ack", topic=display_topic))
        sources = None

    task_label = f"Researching & building: {display_topic}"
    if speak_progress:
        friday_backend.emit_progress(5, "Request understood — starting", task=task_label)

    try:
        if sources is None:
            if speak_progress:
                friday_backend.emit_progress(15, "Searching multiple live-web sources…", task=task_label)
            research_result = friday_web_research.run_web_research(topic, use_cache=True)
            sources = research_result.get("_raw_sources") or []
            if not sources and research_result.get("fallback"):
                # Build from the AI fallback instead of aborting. The research
                # module explicitly labels this content as not live-verified.
                fallback_text = research_result.get("answer", "")
                sources = [("AI knowledge (not live-verified)", fallback_text)] if fallback_text else []
        else:
            if speak_progress:
                friday_backend.emit_progress(40, "Reusing sources already researched this session…", task=task_label)

        plan = None
        if not sources:
            plan = _question_library_plan(topic) if doc_style == "questions" else _library_plan(topic)
            if plan is None:
                if speak_progress:
                    friday_backend.emit_progress(100, "Stopped — no usable research material", task=task_label)
                if speak_progress:
                    friday_backend.speak(
                        "I could not obtain enough research material to build a reliable file."
                    )
                return True
            if speak_progress:
                friday_backend.speak("I couldn't reach any web sources, sir, but I hold this topic in my own reference library, "
                                     "so I'll build the document from that and label it accordingly.")
            if speak_progress:
                friday_backend.emit_progress(60, "Web research unavailable — using the built-in reference library", task=task_label)
        else:
            if speak_progress:
                friday_backend.emit_progress(45, f"Found {len(sources)} sources — validating research…", task=task_label)
            try:
                plan = _plan_content(topic, sources, slide_count=slide_count, doc_style=doc_style)
                if speak_progress:
                    friday_backend.emit_progress(60, "AI content package validated — generating files…", task=task_label)
            except Exception as planning_error:
                # A planning-model failure is NOT the same as a research failure.
                # V2037: prefer the curated library (real study content) over a raw dump of
                # source snippets, and say plainly why the AI planner was skipped.
                print("Project AI planning fallback:", planning_error)
                plan = _question_library_plan(topic) if doc_style == "questions" else _library_plan(topic)
                if plan is not None:
                    if speak_progress:
                        friday_backend.speak(f"I'm afraid {_ai_fail_phrase()}, sir, so I'll build this from my own reference "
                                             "library, and list the sources I did retrieve.")
                    if speak_progress:
                        friday_backend.emit_progress(60, "AI planner unavailable — using the built-in reference library", task=task_label)
                else:
                    plan = _fallback_plan_from_sources(topic, sources)
                    if doc_style == "questions":
                        plan = {"title": f"{topic} -- Study Questions", "summary": "", "methodology": "Source-grounded question sheet.", "key_facts": [], "sections": [{"heading": f"Q{i}: Explain one important concept from the research on {topic}.", "body": "", "bullets": [], "source_ids": []} for i in range(1, min(8, len(sources))+1)]}
                    if speak_progress:
                        friday_backend.speak(f"I'm afraid {_ai_fail_phrase()}, sir, so the document will contain the retrieved "
                                             "source material rather than a written summary.")
                    if speak_progress:
                        friday_backend.emit_progress(60, "AI planner unavailable — using verified source material", task=task_label)
        task_label = f"Building: {plan.get('title', display_topic)}"
    except Exception as error:
        print("Project research/planning error:", error)
        if speak_progress:
            friday_backend.emit_progress(100, "Stopped — no usable research material", task=task_label)
        if speak_progress:
            friday_backend.speak(
                "I could not obtain usable research material for that request, so I did not create unsupported content."
            )
        return True

    folder_name = _safe_folder_name(plan.get("title", topic))[:80]
    project_dir = PROJECTS_ROOT / folder_name
    counter = 2
    while project_dir.exists():
        project_dir = PROJECTS_ROOT / f"{folder_name} ({counter})"
        counter += 1

    source_urls = [u for u, _ in sources]
    created_files = []

    try:
        project_dir.mkdir(parents=True, exist_ok=True)
        file_steps = [w for w in ("pptx", "docx", "pdf", "xlsx", "odp", "odt", "ods") if w in wants]
        step_pct = 30 / len(file_steps) if file_steps else 0
        progress = 60

        if "pptx" in wants:
            p = project_dir / f"{folder_name}.pptx"
            _build_pptx(plan, sources, p, slide_count=slide_count)
            created_files.append(p)
            progress += step_pct
            if speak_progress:
                friday_backend.emit_progress(progress, "Presentation (.pptx) generated and validated", task=task_label)

        if "docx" in wants:
            p = project_dir / "Research_Notes.docx"
            _build_docx(plan, sources, p)
            created_files.append(p)
            progress += step_pct
            if speak_progress:
                friday_backend.emit_progress(progress, "Word document (.docx) generated and validated", task=task_label)

        if "pdf" in wants:
            p = project_dir / "Research_Summary.pdf"
            _build_pdf(plan, sources, p)
            created_files.append(p)
            progress += step_pct
            if speak_progress:
                friday_backend.emit_progress(progress, "PDF (.pdf) generated and validated", task=task_label)

        if "xlsx" in wants:
            p = project_dir / "Research_Data.xlsx"
            _build_xlsx(plan, sources, p)
            created_files.append(p)
            progress += step_pct
            if speak_progress:
                friday_backend.emit_progress(progress, "Excel workbook (.xlsx) generated and validated", task=task_label)

        if "odt" in wants:
            p = project_dir / "Research_Notes.odt"
            _build_odt(plan, sources, p)
            created_files.append(p)
            progress += step_pct
            if speak_progress:
                friday_backend.emit_progress(progress, "OpenDocument text (.odt) generated and validated", task=task_label)

        if "ods" in wants:
            p = project_dir / "Research_Data.ods"
            _build_ods(plan, sources, p)
            created_files.append(p)
            progress += step_pct
            if speak_progress:
                friday_backend.emit_progress(progress, "OpenDocument spreadsheet (.ods) generated and validated", task=task_label)

        if "odp" in wants:
            p = project_dir / f"{folder_name}.odp"
            _build_odp(plan, sources, p, slide_count=slide_count)
            created_files.append(p)
            progress += step_pct
            if speak_progress:
                friday_backend.emit_progress(progress, "OpenDocument presentation (.odp) generated and validated", task=task_label)

        (project_dir / "Sources.txt").write_text("\n".join(source_urls), encoding="utf-8")
        (project_dir / "Content_Package.json").write_text(
            json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        if speak_progress:
            friday_backend.emit_progress(94, "Source list and content package saved", task=task_label)

        if not created_files:
            raise RuntimeError("No requested file type was generated.")

    except Exception as error:
        print("File generation/validation error:", error)
        if speak_progress:
            friday_backend.emit_progress(100, "Stopped — file generation/validation error", task=task_label)
        if speak_progress:
            friday_backend.speak(
                "I researched the topic, but one of the generated files failed validation, so I did not report the project as complete."
            )
        return True

    LAST_PROJECT.update(time=time.time(), topic=topic, folder=str(project_dir),
                        files=[str(f) for f in created_files], ok=True,
                        note="library" if plan.get("_offline_library") else "ai")
    if speak_progress:
        friday_backend.speak(friday_persona.creation_done_line(plan.get("title", topic), len(created_files)))
    if speak_progress:
        friday_backend.emit_progress(100, f"Done — {len(created_files)} validated file(s) ready", task=task_label)
    print("ACTION::PROJECT_CREATED::" + json.dumps({
        "folder": str(project_dir),
        "files": [str(f) for f in created_files],
    }))

    try:
        friday_context.remember_creation(plan.get("title", topic), created_files, project_dir)
    except Exception as error:
        print("Context: could not remember creation result (ignored):", error)

    for f in created_files:
        try:
            os.startfile(str(f))
        except Exception as error:
            print(f"Could not auto-open {f}:", error)

    return True
