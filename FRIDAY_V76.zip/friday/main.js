// FRIDAY Electron main process — one backend, one voice/listening/recognition path.
const { app, BrowserWindow, ipcMain, screen, shell, safeStorage, dialog, Tray, Menu, nativeImage } = require("electron");
const path=require("path"), fs=require("fs"), {spawn,execFile,execFileSync}=require("child_process"), https=require("https");
const PYTHON_COMMAND=process.env.FRIDAY_PYTHON||"C:\\Users\\Asus\\AppData\\Local\\Programs\\Python\\Python313\\python.exe";
// V6.0: the app is now called "FRIDAY 6.2", but its saved data (API key, finance, memory, Python runtime) stays in the existing "FRIDAY 2.0" data folder so nothing is lost.
try{app.setPath("userData",path.join(app.getPath("appData"),"FRIDAY 2.0"))}catch{}
const RUNTIME_DIR=path.join(app.getPath("userData"),"runtime");
const RUNTIME_PY=path.join(RUNTIME_DIR,"python.exe");
const RUNTIME_STAMP=path.join(RUNTIME_DIR,"ready.json");
function findPythonOnPath(){
 if(process.platform!=="win32")return null;
 try{const out=require("child_process").execFileSync("where",["python"],{encoding:"utf8",timeout:4000,windowsHide:true});
  for(const l of out.split(/\r?\n/)){const c=l.trim(); if(c&&/python\.exe$/i.test(c)&&!/WindowsApps/i.test(c)&&fs.existsSync(c))return c}}catch{}
 return null;
}
function resolvePython(){
 if(fs.existsSync(RUNTIME_PY)&&fs.existsSync(RUNTIME_STAMP))return {command:RUNTIME_PY,args:[]};
 if(fs.existsSync(PYTHON_COMMAND))return{command:PYTHON_COMMAND,args:[]};
 const onPath=findPythonOnPath(); if(onPath)return{command:onPath,args:[]};
 return null;
}
function downloadFile(url,dest){
 return new Promise((resolve,reject)=>{
   const follow=u=>https.get(u,res=>{
     if(res.statusCode>=300&&res.statusCode<400&&res.headers.location)return follow(new URL(res.headers.location,u).href);
     if(res.statusCode!==200)return reject(new Error("Download failed: HTTP "+res.statusCode));
     fs.mkdirSync(path.dirname(dest),{recursive:true}); const f=fs.createWriteStream(dest);
     res.pipe(f); f.on("finish",()=>f.close(resolve)); f.on("error",reject);
   }).on("error",reject);
   follow(url);
 });
}
async function ensureBundledPython(){
 const existing=resolvePython(); if(existing)return existing;
 const zip=path.join(RUNTIME_DIR,"python-embed.zip"), stamp=RUNTIME_STAMP;
 if(!fs.existsSync(RUNTIME_PY)){
   broadcast("friday:error","FRIDAY is preparing its private Python runtime. This is a one-time setup.");
   await downloadFile("https://www.python.org/ftp/python/3.13.5/python-3.13.5-embed-amd64.zip",zip);
   fs.mkdirSync(RUNTIME_DIR,{recursive:true});
   await new Promise((res,rej)=>execFile(process.env.COMSPEC||"cmd.exe",["/c","tar","-xf",zip,"-C",RUNTIME_DIR],(e)=>e?rej(e):res()));
 }
 const py={command:RUNTIME_PY,args:[]};
 if(!fs.existsSync(stamp)){
   // Enable site-packages and bootstrap pip.
   const pth=path.join(RUNTIME_DIR,"python313._pth");
   if(fs.existsSync(pth)){let x=fs.readFileSync(pth,"utf8");if(!x.includes("import site"))x=x.replace(/#import site/,"import site");fs.writeFileSync(pth,x);}
   const getpip=path.join(RUNTIME_DIR,"get-pip.py");
   await downloadFile("https://bootstrap.pypa.io/get-pip.py",getpip);
   const setupLog=fs.openSync(path.join(RUNTIME_DIR,"setup.log"),"a");
   await new Promise((res,rej)=>{const c=spawn(py.command,[getpip],{cwd:__dirname,stdio:["ignore",setupLog,setupLog],windowsHide:true});c.on("error",rej);c.on("exit",code=>code===0?res():rej(new Error("pip bootstrap failed ("+code+"). See "+path.join(RUNTIME_DIR,"setup.log"))));});
   const req=path.join(__dirname,"requirements.txt");
   await new Promise((res,rej)=>{const c=spawn(py.command,["-m","pip","install","--disable-pip-version-check","-r",req],{cwd:__dirname,stdio:["ignore",setupLog,setupLog],windowsHide:true});c.on("error",rej);c.on("exit",code=>code===0?res():rej(new Error("FRIDAY dependencies failed ("+code+"). See "+path.join(RUNTIME_DIR,"setup.log"))));});
   try{fs.closeSync(setupLog)}catch{}
   fs.writeFileSync(stamp,JSON.stringify({python:"3.13.5",readyAt:new Date().toISOString()}));
 }
 return py;
}
const BACKEND=path.join(__dirname,"friday_launcher.py");
let mainWindow=null,widgetWindow=null,backendProcess=null,backendConnected=false,rendererReady=false,handshakeSent=false;
const DATA_DIR=path.join(app.getPath("userData"),"friday_data"), FINANCE_FILE=path.join(DATA_DIR,"finance.json");
const API_FILE=path.join(DATA_DIR,"api_key.bin"), MODEL_FILE=path.join(DATA_DIR,"gemini_model.txt"), ATTACH_DIR=path.join(DATA_DIR,"attachments");
// V2.3.0 OpenCV-5 vision: its own data folder (settings, metrics, exports, models) and a secure-storage slot for the optional cloud token.
const VISION_DIR=path.join(DATA_DIR,"vision"), VISION_SECRET_FILE=path.join(VISION_DIR,"cloud_token.bin");
function sendStoredVisionSecrets(){
 try{
   if(!fs.existsSync(VISION_SECRET_FILE)||!safeStorage.isEncryptionAvailable()) return;
   const val=safeStorage.decryptString(fs.readFileSync(VISION_SECRET_FILE));
   if(val) sendBackend("__FRIDAY_VISION_SECRET__::"+Buffer.from(JSON.stringify({name:"cloud_token",value:val}),"utf8").toString("base64"));
 }catch(e){broadcast("friday:error","Stored cloud token could not be loaded: "+e.message)}
}
function broadcast(ch,payload,except){[mainWindow,widgetWindow].forEach(w=>{if(w&&!w.isDestroyed()&&(!except||w.webContents!==except))w.webContents.send(ch,payload)})}
function sendBackend(line){if(backendProcess?.stdin?.writable)backendProcess.stdin.write(String(line).replace(/[\r\n]/g,"")+"\n")}
function sendHandshake(){if(handshakeSent)return; if(!backendProcess?.stdin?.writable)return; handshakeSent=true; sendBackend("__FRIDAY_UI_READY__")}
function sendStoredGeminiModel(){
 try{
   if(!fs.existsSync(MODEL_FILE)) return;
   const model=fs.readFileSync(MODEL_FILE,"utf8").trim();
   if(model) sendBackend("__FRIDAY_GEMINI_MODEL__::"+Buffer.from(model,"utf8").toString("base64"));
 }catch(e){broadcast("friday:error","Saved Gemini model could not be loaded: "+e.message)}
}
function sendStoredApiKey(){
 try{
   if(!fs.existsSync(API_FILE)||!safeStorage.isEncryptionAvailable()) return;
   const enc=fs.readFileSync(API_FILE);
   const key=safeStorage.decryptString(enc);
   if(key) sendBackend("__FRIDAY_API_KEY__::"+Buffer.from(key,"utf8").toString("base64"));
 }catch(e){broadcast("friday:error","Stored API key could not be loaded: "+e.message)}
}

let lastApiStatus=null, apiWaiters=[], quitting=false, restartTimes=[];
function handleApiStatusLine(t){
 const raw=t.slice("FRIDAY_API_STATUS::".length); let st;
 try{st=JSON.parse(Buffer.from(raw,"base64").toString("utf8"))}catch{st={state:/READY/i.test(raw)?"ready":"other",message:raw,tested:false}}
 lastApiStatus=st;
 if(st.state==="ready"&&st.model){try{const cur=fs.existsSync(MODEL_FILE)?fs.readFileSync(MODEL_FILE,"utf8").trim():"";if(cur!==st.model){fs.mkdirSync(DATA_DIR,{recursive:true});fs.writeFileSync(MODEL_FILE,st.model,"utf8")}}catch{}}
 broadcast("friday:api-status",st);
 if(st.tested){const w=apiWaiters;apiWaiters=[];w.forEach(f=>f(st))}
}
function waitForApiTest(ms){return new Promise(res=>{const timer=setTimeout(()=>{apiWaiters=apiWaiters.filter(f=>f!==done);res({state:"timeout",message:"The connection test is taking longer than expected. FRIDAY will keep retrying in the background.",tested:true})},ms);const done=st=>{clearTimeout(timer);res(st)};apiWaiters.push(done)})}
// V6.4: closing FRIDAY must NOT close the apps and tasks she opened for you (Chrome, Notepad, Spotify, a running script ...).
// The old "taskkill /T" ended every descendant of the engine, including those. Now ONLY FRIDAY's own helpers are ended:
// the engine itself, its python helper workers, its hidden PowerShell/ffmpeg/tesseract/playwright-driver helpers and any stray
// friday_launcher.py engine. Anything else the engine started is left running and is never even walked into.
let helpersEnded=false;
function endFridayHelpers(rootPid){
 if(process.platform!=="win32"||helpersEnded)return;
 helpersEnded=true;
 const script=[
  "$ErrorActionPreference='SilentlyContinue'",
  "$root="+(Number(rootPid)|0),
  "$all=@(Get-CimInstance Win32_Process)",
  "$kids=@{}",
  "foreach($p in $all){$k=[int]$p.ParentProcessId; if(-not $kids.ContainsKey($k)){$kids[$k]=New-Object System.Collections.ArrayList}; [void]$kids[$k].Add($p)}",
  "$q=New-Object System.Collections.Queue; $q.Enqueue($root); $seen=@{}",
  "while($q.Count -gt 0){$cur=$q.Dequeue(); if(-not $kids.ContainsKey($cur)){continue}",
  " foreach($c in $kids[$cur]){$id=[int]$c.ProcessId; if($seen.ContainsKey($id)){continue}; $seen[$id]=1",
  "  $n=([string]$c.Name).ToLower(); $cl=[string]$c.CommandLine; $int=$false",
  "  if($n -eq 'python.exe' -or $n -eq 'pythonw.exe' -or $n -eq 'py.exe'){$int=($cl -match 'friday|\\s-c\\s|\\spip\\s|runner\\.py')}",
  "  if($n -eq 'powershell.exe' -or $n -eq 'pwsh.exe'){$int=($cl -match '-NonInteractive|-EncodedCommand|-WindowStyle\\s+Hidden')}",
  "  if($n -eq 'node.exe'){$int=($cl -match 'playwright')}",
  "  if($n -eq 'ffmpeg.exe' -or $n -eq 'ffprobe.exe' -or $n -eq 'tesseract.exe'){$int=$true}",
  "  if($int){$q.Enqueue($id); Stop-Process -Id $id -Force}",
  " }}",
  "foreach($p in $all){if($p.CommandLine -and ($p.CommandLine -like '*friday_launcher.py*') -and [int]$p.ProcessId -ne $PID){Stop-Process -Id ([int]$p.ProcessId) -Force}}"
 ].join("; ");
 try{
  const ps=path.join(process.env.SystemRoot||"C:\\Windows","System32","WindowsPowerShell","v1.0","powershell.exe");
  execFileSync(fs.existsSync(ps)?ps:"powershell.exe",["-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",script],{windowsHide:true,stdio:"ignore",timeout:7000});
  swept=true;                       // the stray-engine sweep above already ran inside this one call
 }catch{}
}
function killBackendTree(){
 // The engine owns the microphone/camera, so it must always end with the app. Its helpers end with it; the user's apps do not.
 try{
  const child=backendProcess;
  const pid=child?.pid;
  if(!pid)return;
  if(process.platform==="win32"){
   endFridayHelpers(pid);           // BEFORE the engine is ended, so its helper workers can still be found
   // V3.1: full path to taskkill. NO /T any more (that is what used to close your apps) - only the engine process itself.
   const tk=path.join(process.env.SystemRoot||"C:\\Windows","System32","taskkill.exe");
   try{execFileSync(fs.existsSync(tk)?tk:"taskkill",["/PID",String(pid),"/F"],{windowsHide:true,stdio:"ignore",timeout:5000})}catch{}
  }
  try{child.kill()}catch{}
 }catch{}
}
// V3.1: last resort - end ANY FRIDAY engine (friday_launcher.py) still alive, e.g. one orphaned by a crash, so Python never keeps the microphone.
let swept=false;
function sweepStrayEngines(){
 if(swept||process.platform!=="win32")return; swept=true;
 try{
  const ps=path.join(process.env.SystemRoot||"C:\\Windows","System32","WindowsPowerShell","v1.0","powershell.exe");
  execFileSync(fs.existsSync(ps)?ps:"powershell.exe",["-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command","Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine -like '*friday_launcher.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"],{windowsHide:true,stdio:"ignore",timeout:8000});
 }catch{}
}
// V5.0: optional accelerators (in-process mp3 playback). Best effort, in the background, once; FRIDAY works without them.
function ensureOptional5(py){
 try{
  const marker=path.join(app.getPath("userData"),"optional5.json"), req=path.join(__dirname,"requirements-optional.txt");
  if(fs.existsSync(marker)||!fs.existsSync(req))return;
  fs.mkdirSync(path.dirname(marker),{recursive:true});
  const c=spawn(py.command,[...py.args,"-m","pip","install","--disable-pip-version-check","--only-binary=:all:","-r",req],{cwd:__dirname,stdio:"ignore",windowsHide:true});
  c.on("error",()=>{}); c.on("exit",code=>{try{fs.writeFileSync(marker,JSON.stringify({code,at:new Date().toISOString()}))}catch{}});
 }catch{}
}
async function startBackend(){
 const py=await ensureBundledPython();
 ensureOptional5(py);
 handshakeSent=false;
 backendProcess=spawn(py.command,[...py.args,"-u",BACKEND],{cwd:__dirname,stdio:["pipe","pipe","pipe"],windowsHide:true,env:{...process.env,PYTHONIOENCODING:"utf-8",PYTHONUTF8:"1",FRIDAY_PYTHON_MODE:"electron",FRIDAY_VISION_DATA:VISION_DIR}});
 let buf="";
 backendProcess.stdout.on("data",chunk=>{buf+=chunk.toString("utf8");let lines=buf.split(/\r?\n/);buf=lines.pop();for(const line of lines){const t=line.trim();if(!t)continue;
   if(t==="FRIDAY_BOOT::PROCESS_CONNECTED"){backendConnected=true;broadcast("friday:backend-ready",true);if(rendererReady)sendHandshake();sendStoredApiKey();sendStoredGeminiModel();sendStoredVisionSecrets();continue}
   if(t.startsWith("FRIDAY_API_STATUS::")){handleApiStatusLine(t);continue}
   if(t==="ACTION::MINIMIZE_WIDGET"){enterWidget();continue} if(t==="ACTION::RESTORE_WINDOW"){exitWidget();continue}
   if(t==="ACTION::OPEN_SETTINGS"){showMain();broadcast("friday:open-settings",null);continue}
   if(t==="ACTION::SHUTDOWN"){setTimeout(()=>app.quit(),1200);continue}
   if(t==="VOICE_MODE::STANDBY"||t==="VOICE_MODE::ACTIVE"){broadcast("friday:voice-mode",t.endsWith("ACTIVE")?"active":"standby");continue}
   broadcast("friday:line",line);
 }})
 backendProcess.stderr.on("data",c=>broadcast("friday:error",c.toString("utf8")));
 backendProcess.on("error",e=>broadcast("friday:error","Could not start FRIDAY backend: "+e.message));
 backendProcess.on("exit",code=>{backendConnected=false;broadcast("friday:exit",code);backendProcess=null;
   // Crash recovery: an unexpected exit restarts the engine (and re-sends the saved key). Never on quit or a clean goodbye.
   if(quitting||code===0||code===null)return;
   const now=Date.now(); restartTimes=restartTimes.filter(x=>now-x<120000); if(restartTimes.length>=5){broadcast("friday:error","FRIDAY's engine keeps stopping. Please restart the app.");return}
   restartTimes.push(now); broadcast("friday:error","FRIDAY's engine stopped unexpectedly. Restarting it now...");
   setTimeout(()=>{if(!quitting&&!backendProcess)startBackend().catch(e=>broadcast("friday:error","FRIDAY restart failed: "+e.message))},1500);
 });
}
function createMain(){const d=screen.getPrimaryDisplay().workArea;mainWindow=new BrowserWindow({x:d.x,y:d.y,width:d.width,height:d.height,minWidth:900,minHeight:600,frame:false,show:false,icon:path.join(__dirname,"assets","friday.ico"),backgroundColor:"#02070f",webPreferences:{preload:path.join(__dirname,"preload.js"),contextIsolation:true,nodeIntegration:false,backgroundThrottling:false}});mainWindow.loadFile(path.join(__dirname,"index.html"));
 mainWindow.once("ready-to-show",()=>mainWindow.show());
 /* FRIDAY 7.0 new UI: lets the Quick Actions "Record" button capture the screen via getDisplayMedia (primary screen). Harmless on older Electron. */
 try{const{desktopCapturer}=require("electron");mainWindow.webContents.session.setDisplayMediaRequestHandler((req,cb)=>{desktopCapturer.getSources({types:["screen"]}).then(s=>s&&s[0]?cb({video:s[0]}):cb({})).catch(()=>cb({}))})}catch{}
 mainWindow.webContents.on("did-finish-load",()=>setTimeout(()=>{rendererReady=true;if(backendConnected)sendHandshake()},300));
 mainWindow.on("closed",()=>{mainWindow=null;rendererReady=false});}
const WIDGET_W=500,WIDGET_H=230;
let inWidget=false, tray=null;
const ICON_ICO=path.join(__dirname,"assets","friday.ico"), ICON_PNG=path.join(__dirname,"assets","friday_icon.png");
function createWidget(){if(widgetWindow&&!widgetWindow.isDestroyed())return;const d=screen.getPrimaryDisplay().workArea;
 // V2.2.6: the widget now has its own taskbar button (skipTaskbar:false) and an icon, so FRIDAY is always visible in the taskbar.
 widgetWindow=new BrowserWindow({width:WIDGET_W,height:WIDGET_H,x:d.x+d.width-WIDGET_W-24,y:d.y+d.height-WIDGET_H-24,frame:false,transparent:true,resizable:false,alwaysOnTop:true,skipTaskbar:false,hasShadow:false,show:false,focusable:true,icon:ICON_ICO,title:"FRIDAY",backgroundColor:"#00000000",webPreferences:{preload:path.join(__dirname,"preload.js"),contextIsolation:true,nodeIntegration:false,backgroundThrottling:false}});
 const w=widgetWindow; w.setAlwaysOnTop(true,"screen-saver"); w.setVisibleOnAllWorkspaces?.(true); w.loadFile(path.join(__dirname,"widget.html"));
 // Closing the widget (Alt+F4, taskbar "Close window") closes the whole app - it never just vanishes while FRIDAY keeps running unseen.
 w.on("close",()=>{if(!quitting&&inWidget){quitting=true;setTimeout(()=>app.quit(),0)}});
 // Nothing may minimise or hide the widget while in widget mode (Win+D, taskbar click, other apps).
 w.on("minimize",()=>{if(inWidget&&!quitting)setTimeout(()=>keepWidgetAlive(),0)});
 w.on("hide",()=>{if(inWidget&&!quitting)setTimeout(()=>keepWidgetAlive(),0)});
 w.on("blur",()=>{if(inWidget&&!quitting)try{w.setAlwaysOnTop(true,"screen-saver");w.moveTop()}catch{}});
 w.webContents.on("render-process-gone",()=>{if(!quitting&&!w.isDestroyed())try{w.webContents.reload()}catch{}});
 w.webContents.on("unresponsive",()=>{if(!quitting&&!w.isDestroyed())try{w.webContents.reload()}catch{}});
 w.webContents.on("did-fail-load",()=>{if(!quitting&&!w.isDestroyed())setTimeout(()=>{try{w.loadFile(path.join(__dirname,"widget.html"))}catch{}},800)});
 w.on("closed",()=>{if(widgetWindow===w)widgetWindow=null; if(inWidget&&!quitting)setTimeout(()=>keepWidgetAlive(),200)})}
function widgetOnScreen(b){return screen.getAllDisplays().some(d=>{const a=d.workArea,ox=Math.min(b.x+b.width,a.x+a.width)-Math.max(b.x,a.x),oy=Math.min(b.y+b.height,a.y+a.height)-Math.max(b.y,a.y);return ox>=Math.min(60,b.width/2)&&oy>=Math.min(60,b.height/2)})}
// Called every ~1.5 s and on every display / hide / minimise event while in widget mode: recreate, show, restore, re-pin, re-position.
function keepWidgetAlive(){
 if(!inWidget||quitting)return;
 try{
  if(!widgetWindow||widgetWindow.isDestroyed()){createWidget()}
  const w=widgetWindow; if(!w||w.isDestroyed())return;
  if(w.isMinimized())w.restore();
  if(!w.isVisible())w.showInactive();
  const b=w.getBounds();
  if(!widgetOnScreen(b)){const d=screen.getPrimaryDisplay().workArea;w.setBounds({x:d.x+d.width-b.width-24,y:d.y+d.height-b.height-24,width:b.width,height:b.height})}
  w.setAlwaysOnTop(true,"screen-saver"); w.moveTop();
  if(mainWindow&&!mainWindow.isDestroyed()&&mainWindow.isVisible())mainWindow.hide();
 }catch{}
}
function enterWidget(){inWidget=true;createWidget();widgetWindow.show();if(mainWindow&&!mainWindow.isDestroyed())mainWindow.hide();broadcast("widget:state","widget");keepWidgetAlive()}
function exitWidget(){inWidget=false;if(widgetWindow&&!widgetWindow.isDestroyed())widgetWindow.hide();showMain();broadcast("widget:state","main")}
function showMain(){if(mainWindow&&!mainWindow.isDestroyed()){mainWindow.show();mainWindow.focus()}else createMain()}
ipcMain.on("renderer:ready",()=>{rendererReady=true;if(backendConnected){broadcast("friday:backend-ready",true);sendHandshake()}});
ipcMain.on("friday:send",(_e,line)=>{if(typeof line!=="string")return;const c=line.replace(/[\r\n]/g,"");
 /* V7.4: a command typed (or tapped) in the desktop widget is also written into the main window's conversation, so everything you command is there. */
 try{if(widgetWindow&&!widgetWindow.isDestroyed()&&_e.sender===widgetWindow.webContents&&mainWindow&&!mainWindow.isDestroyed()){let q="";if(c.startsWith("ASK::")){try{q=String(JSON.parse(Buffer.from(c.slice(5),"base64").toString("utf8")).q||"").trim()}catch{}}else if(!/^(LISTEN|STOP_LISTEN|SPEAK::|__FRIDAY_)/.test(c))q=c.trim();
  if(q)mainWindow.webContents.send("friday:line","ACTION::WIDGET_CMD::"+Buffer.from(q,"utf8").toString("base64"))}}catch{}
if(/^(LISTEN|STOP_LISTEN|SPEAK::|ASK::|__FRIDAY_)/.test(c))sendBackend(c);else if(c.trim())sendBackend("ASK::"+Buffer.from(JSON.stringify({q:c,voice:true}),"utf8").toString("base64"))});
ipcMain.on("widget:enter",enterWidget);ipcMain.on("widget:exit",exitWidget);ipcMain.on("widget:move",(_e,dx,dy)=>{if(!widgetWindow||widgetWindow.isDestroyed()||!Number.isFinite(dx)||!Number.isFinite(dy))return;const b=widgetWindow.getBounds();let x=Math.round(b.x+dx),y=Math.round(b.y+dy);const wa=screen.getDisplayNearestPoint({x:x+Math.round(b.width/2),y:y+Math.round(b.height/2)}).workArea;/* keep the widget fully reachable: it can be dragged anywhere on screen but never off it */x=Math.min(Math.max(x,wa.x),wa.x+wa.width-b.width);y=Math.min(Math.max(y,wa.y),wa.y+wa.height-b.height);widgetWindow.setPosition(x,y)});
ipcMain.handle("api:get-status",()=>{try{
 let model="gemini-3.1-flash-lite"; if(fs.existsSync(MODEL_FILE)) model=fs.readFileSync(MODEL_FILE,"utf8").trim()||model;
 return {configured:fs.existsSync(API_FILE),encrypted:safeStorage.isEncryptionAvailable(),model,status:lastApiStatus};
}catch{return {configured:false,encrypted:false,model:"gemini-3.1-flash-lite"}}});
ipcMain.handle("api:set-model",(_e,model)=>{model=String(model||"").trim().replace(/[\r\n]/g,"").slice(0,160);try{
 if(!model)return {ok:false,error:"Enter a Gemini model name."};
 fs.mkdirSync(DATA_DIR,{recursive:true}); fs.writeFileSync(MODEL_FILE,model,"utf8");
 sendBackend("__FRIDAY_GEMINI_MODEL__::"+Buffer.from(model,"utf8").toString("base64"));
 return {ok:true,model};
}catch(e){return {ok:false,error:e.message}}});
ipcMain.handle("api:set-key",async(_e,key)=>{key=String(key||"").trim();try{fs.mkdirSync(DATA_DIR,{recursive:true});
 if(!key){if(fs.existsSync(API_FILE))fs.unlinkSync(API_FILE);sendBackend("__FRIDAY_API_KEY__::"+Buffer.from("","utf8").toString("base64"));return {ok:true,configured:false}}
 if(!safeStorage.isEncryptionAvailable())return {ok:false,error:"Windows secure storage is unavailable."};
 fs.writeFileSync(API_FILE,safeStorage.encryptString(key));
 if(!backendConnected)return {ok:true,configured:true,status:{state:"pending",message:"Key saved. FRIDAY will connect as soon as its engine has started."}};
 const waiter=waitForApiTest(40000);
 sendBackend("__FRIDAY_API_KEY__::"+Buffer.from(key,"utf8").toString("base64"));
 const st=await waiter;
 return {ok:true,configured:true,status:st,connected:st.state==="ready",message:st.message}}catch(e){return {ok:false,error:e.message}}});
ipcMain.handle("api:test",async()=>{if(!backendConnected)return {state:"pending",message:"FRIDAY's engine is still starting. Try again in a moment.",tested:true};const waiter=waitForApiTest(40000);sendBackend("__FRIDAY_API_TEST__");return await waiter});
ipcMain.handle("vision:set-secret",(_e,name,value)=>{
 name=String(name||""); value=String(value||"").trim();
 if(name!=="cloud_token") return {ok:false,error:"Unknown secret."};
 try{
   fs.mkdirSync(VISION_DIR,{recursive:true});
   if(!value){ if(fs.existsSync(VISION_SECRET_FILE)) fs.unlinkSync(VISION_SECRET_FILE); sendBackend("__FRIDAY_VISION_SECRET__::"+Buffer.from(JSON.stringify({name,value:""}),"utf8").toString("base64")); return {ok:true,set:false}; }
   if(!safeStorage.isEncryptionAvailable()) return {ok:false,error:"Windows secure storage is unavailable."};
   fs.writeFileSync(VISION_SECRET_FILE,safeStorage.encryptString(value));
   sendBackend("__FRIDAY_VISION_SECRET__::"+Buffer.from(JSON.stringify({name,value}),"utf8").toString("base64"));
   return {ok:true,set:true};
 }catch(e){return {ok:false,error:e.message}}
});
ipcMain.handle("vision:secret-status",()=>{try{return {cloud_token:fs.existsSync(VISION_SECRET_FILE),encrypted:safeStorage.isEncryptionAvailable()}}catch{return {cloud_token:false,encrypted:false}}});
ipcMain.handle("vision:pick-file",async(_e,kind)=>{
 const filters=kind==="model"?[{name:"ONNX model",extensions:["onnx"]},{name:"All files",extensions:["*"]}]
   :kind==="labels"?[{name:"Labels (text)",extensions:["txt","names","labels"]},{name:"All files",extensions:["*"]}]
   :kind==="tesseract"?[{name:"tesseract.exe",extensions:["exe"]},{name:"All files",extensions:["*"]}]
   :[{name:"Pictures and videos",extensions:["png","jpg","jpeg","bmp","webp","tif","tiff","gif","mp4","mkv","avi","mov","webm","m4v","wmv","3gp"]},{name:"All files",extensions:["*"]}];
 const r=await dialog.showOpenDialog(mainWindow,{title:kind==="model"?"Choose an ONNX detector model":kind==="labels"?"Choose a labels file":kind==="tesseract"?"Locate tesseract.exe":"Choose a picture or video",properties:["openFile"],filters});
 return r.canceled?"":(r.filePaths[0]||"");
});
ipcMain.handle("vision:open-folder",(_e,sub)=>{
 try{
   const dir=path.join(VISION_DIR,sub==="exports"?"exports":sub==="models"?"models":"");
   fs.mkdirSync(dir,{recursive:true}); shell.openPath(dir); return {ok:true,path:dir};
 }catch(e){return {ok:false,error:e.message}}
});
function findUninstaller(){
 const c=[path.join(path.dirname(process.execPath),"Uninstall FRIDAY.exe"),
  path.join(process.env.LOCALAPPDATA||"","Programs","FRIDAY","Uninstall FRIDAY.exe"),
  path.join(process.env.LOCALAPPDATA||"","Programs","friday-ui","Uninstall FRIDAY.exe"),
  path.join(process.env.ProgramFiles||"","FRIDAY","Uninstall FRIDAY.exe")];
 return c.find(f=>{try{return f&&fs.existsSync(f)}catch{return false}})||null;
}
async function doUninstall(){
 try{
  const parent=(mainWindow&&!mainWindow.isDestroyed()&&mainWindow.isVisible())?mainWindow:undefined;
  const r=await dialog.showMessageBox(parent,{type:"warning",buttons:["Uninstall FRIDAY","Cancel"],defaultId:1,cancelId:1,title:"Uninstall FRIDAY",message:"Uninstall FRIDAY from this computer?",detail:"FRIDAY will close and the Windows uninstaller will open. The uninstaller asks whether to keep or delete your saved data."});
  if(r.response!==0)return {ok:false,cancelled:true};
  const uninstaller=findUninstaller();
  if(uninstaller){inWidget=false;quitting=true;spawn(uninstaller,[],{detached:true,stdio:"ignore"}).unref();setTimeout(()=>app.quit(),400);return {ok:true}}
  // Not installed with the setup file (e.g. running from the folder): open Windows' own app list so FRIDAY can be removed there.
  shell.openExternal("ms-settings:appsfeatures").catch(()=>{});
  return {ok:true,fallback:true,message:"FRIDAY was not found as an installed app. If you run it from a folder, double-click UNINSTALL_FRIDAY.bat in that folder."};
 }catch(e){return {ok:false,error:e.message}}
}
ipcMain.handle("app:uninstall",doUninstall);
ipcMain.handle("files:pick",async()=>{const r=await dialog.showOpenDialog(mainWindow,{title:"Attach to FRIDAY",properties:["openFile","multiSelections"],filters:[{name:"All supported files",extensions:["txt","md","py","js","ts","jsx","tsx","html","css","json","xml","yaml","yml","toml","ini","cfg","bat","cmd","ps1","sql","java","c","cpp","h","hpp","cs","go","rs","php","rb","swift","kt","r","csv","tsv","log","pdf","docx","pptx","xlsx","ods","odt","png","jpg","jpeg","webp","bmp","gif","tif","tiff","mp4","mkv","avi","mov","webm","m4v","wmv","3gp","zip"]},{name:"All files",extensions:["*"]}]});return r.canceled?[]:r.filePaths});
// FRIDAY 5.0: files in chat (drop / paste / created by FRIDAY)
ipcMain.handle("files:save-temp",(_e,name,b64)=>{try{
 fs.mkdirSync(ATTACH_DIR,{recursive:true});
 const safe=String(name||"file").replace(/[^A-Za-z0-9._ -]/g,"_").slice(0,120)||"file";
 const dst=path.join(ATTACH_DIR,Date.now().toString(36)+"_"+safe);
 fs.writeFileSync(dst,Buffer.from(String(b64||""),"base64"));return dst}catch(e){return ""}});
ipcMain.handle("files:open",async(_e,p)=>{try{if(!p||!fs.existsSync(p))return {ok:false};const r=await shell.openPath(p);return {ok:!r,error:r}}catch(e){return {ok:false,error:e.message}}});
ipcMain.handle("files:reveal",(_e,p)=>{try{if(p&&fs.existsSync(p)){shell.showItemInFolder(p);return {ok:true}}}catch{}return {ok:false}});
ipcMain.handle("files:save-as",async(_e,p)=>{try{if(!p||!fs.existsSync(p))return {ok:false};const r=await dialog.showSaveDialog(mainWindow,{defaultPath:path.join(app.getPath("documents"),path.basename(p))});if(r.canceled||!r.filePath)return {ok:false,cancelled:true};fs.copyFileSync(p,r.filePath);return {ok:true,path:r.filePath}}catch(e){return {ok:false,error:e.message}}});
ipcMain.handle("finance:load",()=>{try{return fs.readFileSync(FINANCE_FILE,"utf8")}catch{return ""}});
ipcMain.on("finance:save",(_e,text)=>{if(typeof text!=="string")return;try{fs.mkdirSync(DATA_DIR,{recursive:true});if(fs.existsSync(FINANCE_FILE))fs.copyFileSync(FINANCE_FILE,FINANCE_FILE+".bak");fs.writeFileSync(FINANCE_FILE+".tmp",text,"utf8");fs.renameSync(FINANCE_FILE+".tmp",FINANCE_FILE);sendBackend("__FRIDAY_FINANCE_SYNC__::"+Buffer.from(text,"utf8").toString("base64"))}catch(e){broadcast("friday:error","Finance save failed: "+e.message)}});
ipcMain.on("window:minimize",()=>mainWindow?.minimize());ipcMain.on("window:maximize-toggle",()=>mainWindow&&(mainWindow.isMaximized()?mainWindow.unmaximize():mainWindow.maximize()));ipcMain.on("window:close",()=>app.quit());ipcMain.on("shell:open-external",(_e,url)=>typeof url==="string"&&shell.openExternal(url).catch(()=>{}));
const UI_FILE=path.join(DATA_DIR,"ui_config.json");
ipcMain.handle("ui:load",()=>{try{return fs.readFileSync(UI_FILE,"utf8")}catch{return ""}});
ipcMain.on("ui:save",(_e,text)=>{if(typeof text!=="string"||text.length>200000)return;try{JSON.parse(text);fs.mkdirSync(DATA_DIR,{recursive:true});fs.writeFileSync(UI_FILE+".tmp",text,"utf8");fs.renameSync(UI_FILE+".tmp",UI_FILE);broadcast("ui:config",text,_e.sender)}catch(e){broadcast("friday:error","UI config save failed: "+e.message)}});
ipcMain.on("widget:resize",(_e,w,h)=>{if(!widgetWindow||widgetWindow.isDestroyed())return;w=Math.round(Math.min(900,Math.max(80,+w||0)));h=Math.round(Math.min(600,Math.max(80,+h||0)));const b=widgetWindow.getBounds();if(b.width===w&&b.height===h)return;const wa=screen.getDisplayMatching(b).workArea;let x=b.x+b.width-w,y=b.y+b.height-h;x=Math.min(Math.max(x,wa.x),wa.x+wa.width-w);y=Math.min(Math.max(y,wa.y),wa.y+wa.height-h);widgetWindow.setResizable(true);widgetWindow.setBounds({x,y,width:w,height:h});widgetWindow.setResizable(false)});
ipcMain.on("widget:top",()=>{/* V2.2.6: the widget always stays on top until the app is closed */if(!widgetWindow||widgetWindow.isDestroyed())return;widgetWindow.setAlwaysOnTop(true,"screen-saver")});
function ensureWindowsShortcuts(){
  if(process.platform!=="win32" || !app.isPackaged) return;
  try{
    app.setAppUserModelId("com.friday.assistant");
    const target=process.execPath;
    const icon=path.join(process.resourcesPath,"app","assets","friday.ico");
    const desktop=app.getPath("desktop");
    const startMenu=path.join(app.getPath("appData"),"Microsoft","Windows","Start Menu","Programs");
    fs.mkdirSync(startMenu,{recursive:true});
    const desktopLink=path.join(desktop,"FRIDAY.lnk");
    const startLink=path.join(startMenu,"FRIDAY.lnk");
    const options={target,workingDirectory:path.dirname(target),description:"FRIDAY personal AI assistant",icon:fs.existsSync(icon)?icon:target,iconIndex:0};
    try{shell.writeShortcutLink(desktopLink,"create",options);}catch(e){broadcast("friday:error","Desktop shortcut could not be created: "+e.message)}
    try{shell.writeShortcutLink(startLink,"create",options);}catch(e){broadcast("friday:error","Start Menu shortcut could not be created: "+e.message)}
  }catch(e){broadcast("friday:error","Shortcut setup failed: "+e.message)}
}
const gotInstanceLock=app.requestSingleInstanceLock();
if(!gotInstanceLock){app.quit()}else{app.on("second-instance",()=>{try{if(widgetWindow&&!widgetWindow.isDestroyed()&&widgetWindow.isVisible())exitWidget();else showMain()}catch{}})}
function createTray(){
 try{
  let img=nativeImage.createFromPath(fs.existsSync(ICON_ICO)?ICON_ICO:ICON_PNG); if(img.isEmpty())img=nativeImage.createFromPath(ICON_PNG);
  tray=new Tray(img.resize({width:16,height:16})); tray.setToolTip("FRIDAY");
  const toggle=()=>{if(inWidget)exitWidget();else showMain()};
  tray.setContextMenu(Menu.buildFromTemplate([
   {label:"Open FRIDAY",click:()=>exitWidget()},
   {label:"Show desktop widget",click:()=>enterWidget()},
   {type:"separator"},
   {label:"Uninstall FRIDAY...",click:()=>doUninstall()},
   {label:"Quit FRIDAY",click:()=>app.quit()}]));
  tray.on("click",toggle);
 }catch{}
}
function startWidgetWatchdog(){
 setInterval(keepWidgetAlive,1500);
 for(const ev of ["display-added","display-removed","display-metrics-changed"])screen.on(ev,()=>setTimeout(keepWidgetAlive,300));
 try{require("electron").powerMonitor.on("unlock-screen",()=>setTimeout(keepWidgetAlive,500));require("electron").powerMonitor.on("resume",()=>setTimeout(keepWidgetAlive,1500))}catch{}
}
if(process.platform==="win32")try{app.setAppUserModelId("com.friday.assistant")}catch{}
app.whenReady().then(()=>{if(!gotInstanceLock)return;ensureWindowsShortcuts();createMain();createTray();startWidgetWatchdog();startBackend().catch(e=>broadcast("friday:error","FRIDAY runtime setup failed: "+e.message));});
// A hidden widget/tray window can keep Electron alive after the main UI closes.
// Make app quit authoritative and stop audio/backend workers as part of shutdown.
app.on("before-quit",()=>{
 quitting=true;
 try{sendBackend("__FRIDAY_QUIT__")}catch{}
 killBackendTree();
});
// V2.3.1: last line of defence - whatever way Electron ends, the Python engine (microphone + camera owner) is ended with it.
process.on("exit",()=>{try{killBackendTree()}catch{}});
app.on("will-quit",()=>{
 quitting=true;
 killBackendTree();
 sweepStrayEngines();
 try{if(tray){tray.destroy();tray=null}}catch{}
});
app.on("window-all-closed",()=>app.quit());
