# FRIDAY V2101 - JARVIS voice path, quantity-only meals, typed commands, hover widget

## What changed
1. Same speaking / listening / recognising as JARVIS
   - Backend capture/recognition code was already the JARVIS algorithm; the real gaps were found and fixed:
     * `base64` was never imported in friday_backend.py, so every ACTION::HEARD, ACTION::ANSWER_PART and typed ASK:: line crashed (NameError). Fixed.
     * The old UI re-processed what it heard in the browser AND the backend also answered (double handling) and forced re-listening. Now the backend owns the whole loop (like JARVIS); the UI only displays it.
     * Speaking rate set to JARVIS's 185 wpm (was 197). Voice stays en-US-AriaNeural.
     * "Speak replies" switch now really mutes speech (text still shows).
2. Meals: FRIDAY only estimates quantities, never grocery cost. friday_food_optimizer.py rewritten; UI Plans/Reports show quantities only; you enter your own grocery cost in Monthly Plan. Old "@price" entries are accepted and ignored.
3. Typed commands: chat box, Quick Input and the widget all go to the backend's single process_command(). Understands: income/expense/monthly plan/goal with several items (salary 250k, rent 50000; lights 12000), "2 lakh", coffee/tea/milk per day, show reports / open meal plan, how much is left, can I afford, ingredient needs. The screen refreshes from FINANCE_STATE:: after every change.
4. Widget: JARVIS-style hover command panel. Move the pointer beside the reactor and a panel opens (command box, SEND, LEFT / NEEDS / REPORT / OPEN). Click the reactor centre to reopen FRIDAY; drag to move.

## Verified (sandbox)
34 headless-browser UI checks, backend process_command/listen()/stdin tests, py_compile, JS syntax. Not tested on a real mic/Windows/Electron.
