"""
FRIDAY PROACTIVE MONITOR
------------------------
Implements the research doc's "10. Proactive intelligence comes AFTER
this" and "8. Proactive intelligence - 9.5+" sections:

    WORLD STATE CHANGES -> PROACTIVE MONITOR -> Is this important? ->
    YES -> Create internal goal -> EXECUTIVE -> PLAN -> EXECUTE -> VERIFY

so Friday can say things like "Sir, your download has finished" or
"Sir, the document contains three unverified claims" without being
asked -- while every proactive action still passes through
friday_supervisor's permission tiers (SAFE / LOW_RISK / HIGH_IMPACT)
so autonomy stays bounded rather than unpredictable, exactly as the
doc requires ("proactive actions should have permission boundaries so
Friday doesn't randomly take consequential actions").

This module sits ABOVE friday_executive/friday_supervisor and does not
touch your existing friday_proactive_reasoning.py at all -- that module
keeps doing its own (richer, command-analysis-focused) job untouched.
This one is specifically the "world event happened, should Friday act
on its own" trigger described in the architecture doc, which is a
different concern from analysing a command the user just typed.
"""

from __future__ import annotations

import time
from typing import Any, Callable, Optional

import friday_state_engine as state
import friday_supervisor as supervisor

# Keywords/categories the doc explicitly calls "important enough to act on".
_RELEVANT_EVENT_TYPES = {
    "download_complete", "file_changed", "long_running_task_finished",
    "unverified_claims_found", "error_detected", "reminder_due",
}

_LAST_EVENTS: dict[str, float] = {}

def relevance_score(event: dict[str, Any]) -> tuple[float, str]:
    """Return a transparent 0..1 relevance score instead of a binary guess."""
    event = event or {}
    score = 0.0
    reasons = []
    if event.get("important") is True:
        score += 0.65; reasons.append("explicitly important")
    if event.get("type") in _RELEVANT_EVENT_TYPES:
        score += 0.55; reasons.append("important event type")
    desc = str(event.get("description") or "").lower()
    env = state.get("environment") or {}
    topic = str(env.get("current_topic") or env.get("current_task") or "").lower()
    if topic and topic in desc:
        score += 0.20; reasons.append("matches current task/topic")
    if event.get("urgent") is True:
        score += 0.20; reasons.append("urgent")
    return min(1.0, score), ", ".join(reasons) or "low relevance"

def _dedupe_key(event: dict[str, Any]) -> str:
    return f"{event.get('type','')}|{str(event.get('description','')).strip().lower()}"


def relevance_check(event: dict[str, Any]) -> tuple[bool, str]:
    score, reason = relevance_score(event)
    key = _dedupe_key(event)
    last = _LAST_EVENTS.get(key, 0.0)
    if last and time.time() - last < 30.0:
        return False, "duplicate proactive event suppressed"
    threshold = 0.45
    return score >= threshold, f"score={score:.2f}; {reason}"


def emit(event: dict[str, Any], *, ask_user: Optional[Callable[[str], bool]] = None,
         auto_execute: bool = True) -> dict[str, Any]:
    """Feed one world-state-change event through the proactive pipeline.

    `event` shape: {"type": str, "description": str, "important": bool?,
                     "goal_text": str?}. If `goal_text` is omitted, a goal
    description is derived from `description`.

    Returns a report dict: {"acted": bool, "reason": str, "result": ...}
    so the caller (e.g. friday_unified_loop) can decide how/whether to
    surface a spoken notification.
    """
    event = dict(event or {})
    event.setdefault("ts", time.time())

    relevant, reason = relevance_check(event)
    if relevant:
        _LAST_EVENTS[_dedupe_key(event)] = time.time()
    if not relevant:
        return {"acted": False, "reason": reason, "event": event, "relevance": relevance_score(event)[0]}

    goal_text = event.get("goal_text") or event.get("description") or event.get("type") or "unspecified event"

    if not auto_execute:
        return {"acted": False, "reason": "relevant but auto_execute=False; goal not run", "event": event,
                "would_run_goal": goal_text}

    # Register the real V3086 agents lazily so proactive events use the same
    # execution stack as user-requested complex tasks.
    try:
        import friday_unified_gateway as gateway
        gateway.register_default_agents()
    except Exception:
        pass

    # The very first task in a proactively-generated plan is what gets
    # permission-checked as "proactive"; friday_supervisor still enforces
    # SAFE / LOW_RISK / HIGH_IMPACT for every task inside the run.
    result = supervisor.run_goal(goal_text, priority=_priority_for(event), ask_user=ask_user, proactive=True)
    return {"acted": True, "reason": reason, "event": event, "result": result,
            "relevance": relevance_score(event)[0], "suggestion_level": "act" if result.get("status") == "COMPLETED" else "suggest"}


def _priority_for(event: dict[str, Any]) -> float:
    if event.get("type") == "error_detected":
        return 0.9
    if event.get("type") in ("unverified_claims_found", "reminder_due"):
        return 0.7
    return 0.5


# -- convenience helpers for common event sources --------------------------

def on_download_complete(filename: str, *, ask_user: Optional[Callable[[str], bool]] = None) -> dict[str, Any]:
    return emit({
        "type": "download_complete",
        "description": f"Download finished: {filename}",
        "goal_text": f"inspect the downloaded file {filename} and report what it is",
    }, ask_user=ask_user)


def on_file_changed(path: str, *, ask_user: Optional[Callable[[str], bool]] = None) -> dict[str, Any]:
    return emit({
        "type": "file_changed",
        "description": f"File changed on disk: {path}",
        "goal_text": f"inspect the changed file {path} and report anything notable",
    }, ask_user=ask_user)


def on_unverified_claims(document_path: str, claim_count: int,
                          *, ask_user: Optional[Callable[[str], bool]] = None) -> dict[str, Any]:
    return emit({
        "type": "unverified_claims_found",
        "important": True,
        "description": f"The document {document_path} contains {claim_count} unverified claims",
        "goal_text": f"verify the {claim_count} unverified claims in {document_path}",
    }, ask_user=ask_user)
