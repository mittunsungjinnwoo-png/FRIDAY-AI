import os, re

# Static/source-level regression checks; no microphone or Windows TTS required.
backend = open('friday_backend.py', encoding='utf-8').read()
voice = open('friday_voice_engine.py', encoding='utf-8').read()
assert 'VAD_PAUSE_THRESHOLD = float(os.getenv("FRIDAY_VAD_PAUSE", "1.15"))' in backend
assert 'VAD_PHRASE_THRESHOLD = float(os.getenv("FRIDAY_VAD_PHRASE", "0.08"))' in backend
assert 'VAD_NON_SPEAKING_DURATION = float(os.getenv("FRIDAY_VAD_NON_SPEAKING", "0.22"))' in backend
assert 'LISTEN_TIMEOUT_SECONDS = None' in backend
assert 'max(420, int(os.getenv("FRIDAY_TTS_SEGMENT_CHARS", "900")))' in backend
assert 'default_beam = "3" if _model_device == "cuda" else "1"' in voice
assert '"min_silence_duration_ms": 220' in voice
assert '"speech_pad_ms": 80' in voice
# The configured voice rate remains the sole speed authority.
assert 'effective_rate = VOICE_RATE' in backend
assert 'edge_tts' in backend  # optional legacy engine remains available but is not made default
print('V2016 voice speed/humanity static tests: PASS')

assert 'PHRASE_TIME_LIMIT_SECONDS = None' in backend
