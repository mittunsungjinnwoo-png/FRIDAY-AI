"""FRIDAY 7.0 Independent Critic and Verification Layer  (roadmap #28).

A SEPARATE checker for important outputs.  It never trusts the producer: it re-computes arithmetic, re-adds totals, re-reads percentages,
compares claims with execution receipts, compiles code, checks that cited sources exist and that dates are plausible.  A model call is
made only when the expected benefit justifies the cost and delay (setting `critic_budget`: never | balanced | always).

review() -> {ok, issues:[{severity, check, detail}], checked:[...], model_used, verdict, ms}
  ok = no MAJOR issue found.  Minor issues are advice.  "checked" lists what was actually verified so a clean result is meaningful.
"""
from __future__ import annotations

import ast
import re
import time
from datetime import date
from decimal import Decimal, InvalidOperation, getcontext
from typing import Any, Dict, List, Optional

import friday_common6 as C
import friday_common7 as K

getcontext().prec = 28

_NUM = r"-?\d[\d,]*(?:\.\d+)?"
_CUR = r"(?:rs\.?|lkr|usd|eur|gbp|[$€£])?\s*"
_EQ = re.compile(rf"(?P<a>{_CUR}{_NUM})\s*(?P<op>[x×*+\-−/÷])\s*(?P<b>{_CUR}{_NUM})\s*(?:=|equals|is|gives|makes)\s*(?P<c>{_CUR}{_NUM})", re.I)
_PCT = re.compile(rf"(?P<p>{_NUM})\s*%\s*(?:of)\s*(?P<base>{_CUR}{_NUM})\s*(?:=|is|equals|gives)\s*(?P<res>{_CUR}{_NUM})", re.I)
_TOTAL_LINE = re.compile(rf"^\s*(?:total|sum|grand total|overall)[^\d\n-]*(?P<n>{_CUR}{_NUM})\s*\S*\s*$", re.I)
_ITEM_LINE = re.compile(rf"^\s*(?:[-*•]|\d+[.)])?\s*[A-Za-z][^\n\d]{{0,60}}?[:\-–—=@]?\s*(?P<n>{_CUR}{_NUM})\s*\S{{0,12}}\s*$")
_CITE = re.compile(r"\[(\d{1,2})\]")
_YEAR = re.compile(r"\b(19[5-9]\d|20[0-9]\d|21\d\d)\b")
_DONE_CLAIM = re.compile(r"\bI(?:'ve| have)?\s+(saved|created|opened|sent|deleted|installed|closed|moved|renamed|launched|written|wrote|copied|ran|run|fixed|updated)\b", re.I)
_CERTAIN = re.compile(r"\b(definitely|guaranteed|certainly|always|never fails|100%|without doubt|proven)\b", re.I)
_LABEL_NUM = re.compile(rf"(?P<label>[A-Za-z][A-Za-z ]{{2,30}}?)\s+(?:is|costs?|=|:)\s*{_CUR}(?P<n>{_NUM})\b", re.I)

_TOOL_FOR_VERB = {"saved": ("save_report", "write_file"), "created": ("save_report", "write_file", "file_op"), "written": ("save_report", "write_file"), "wrote": ("save_report", "write_file"),
                  "opened": ("open_app", "open_file"), "launched": ("open_app",), "sent": ("send_message",), "deleted": ("delete_file", "file_op"), "moved": ("file_op",),
                  "renamed": ("file_op",), "copied": ("file_op",), "ran": ("run_python", "run_tests"), "run": ("run_python", "run_tests"), "closed": ("window_control",),
                  "fixed": ("apply_patch",), "updated": ("apply_patch",), "installed": ()}


def _dec(s: str) -> Optional[Decimal]:
    s = re.sub(r"(?i)rs\.?|lkr|usd|eur|gbp|[$€£\s]", "", str(s)).replace(",", "").replace("−", "-")
    try:
        return Decimal(s)
    except (InvalidOperation, ValueError):
        return None


def _close(a: Decimal, b: Decimal) -> bool:
    tol = max(Decimal("0.011"), abs(b) * Decimal("0.006"))
    return abs(a - b) <= tol


def _issue(sev: str, check: str, detail: str) -> Dict:
    return {"severity": sev, "check": check, "detail": detail}


# ------------------------------------------------------------------ deterministic checks (each returns (issues, checked_count))
def check_arithmetic(text: str) -> (List[Dict], int):
    issues, n = [], 0
    for m in _EQ.finditer(text or ""):
        a, b, c = _dec(m.group("a")), _dec(m.group("b")), _dec(m.group("c"))
        if a is None or b is None or c is None:
            continue
        op = m.group("op")
        try:
            val = {"x": a * b, "×": a * b, "*": a * b, "+": a + b, "-": a - b, "−": a - b, "/": (a / b if b else None), "÷": (a / b if b else None)}[op]
        except Exception:
            continue
        if val is None:
            continue
        n += 1
        if not _close(val, c):
            issues.append(_issue("major", "arithmetic", f"'{m.group(0).strip()}' is wrong: {a} {op} {b} = {val.quantize(Decimal('0.01'))}, not {c}"))
    for m in _PCT.finditer(text or ""):
        p, base, res = _dec(m.group("p")), _dec(m.group("base")), _dec(m.group("res"))
        if None in (p, base, res):
            continue
        n += 1
        want = base * p / Decimal(100)
        if not _close(want, res):
            issues.append(_issue("major", "percentage", f"{p}% of {base} is {want.quantize(Decimal('0.01'))}, not {res}"))
    return issues, n


def check_totals(text: str) -> (List[Dict], int):
    """Item lines followed by a 'Total' line: re-add them."""
    issues, n = [], 0
    block: List[Decimal] = []
    for line in (text or "").splitlines():
        tm = _TOTAL_LINE.match(line)
        if tm and block:
            tot = _dec(tm.group("n"))
            if tot is not None and len(block) >= 2:
                n += 1
                s = sum(block, Decimal(0))
                if not _close(s, tot):
                    issues.append(_issue("major", "total", f"the items add up to {s.quantize(Decimal('0.01'))} but the total says {tot}"))
            block = []
            continue
        im = _ITEM_LINE.match(line)
        if im:
            v = _dec(im.group("n"))
            if v is not None:
                block.append(v)
                continue
        if not line.strip():
            block = [] if block and len(block) < 2 else block
        elif not im:
            block = []
    return issues, n


def check_dates(text: str) -> (List[Dict], int):
    issues, n = [], 0
    this_year = date.today().year
    for m in re.finditer(r"\b(?:published|updated|released|dated|as of|retrieved)\s+(?:in |on )?(?:[A-Za-z]+ \d{0,2},? )?(\d{4})\b", text or "", re.I):
        n += 1
        y = int(m.group(1))
        if y > this_year + 1:
            issues.append(_issue("major", "date", f"a source is dated {y}, which is in the future"))
    for m in re.finditer(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b", text or ""):
        d1, d2, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        n += 1
        ok_dm = 1 <= d1 <= 31 and 1 <= d2 <= 12
        ok_md = 1 <= d2 <= 31 and 1 <= d1 <= 12
        if not (ok_dm or ok_md):
            issues.append(_issue("minor", "date", f"'{m.group(0)}' is not a valid date"))
    return issues, n


def check_citations(text: str, sources: Optional[List] = None, require: bool = False) -> (List[Dict], int):
    issues, n = [], 0
    refs = {int(x) for x in _CITE.findall(text or "")}
    if sources is not None:
        n += 1
        bad = sorted(r for r in refs if r < 1 or r > len(sources))
        if bad:
            issues.append(_issue("major", "citation", f"citation(s) {bad} point to sources that do not exist (only {len(sources)} were gathered)"))
    if require:
        n += 1
        sentences = [s for s in re.split(r"(?<=[.!?])\s+", text or "") if re.search(r"\d", s) and len(s) > 25]
        uncited = [s for s in sentences if not _CITE.search(s)]
        if sentences and len(uncited) > max(1, len(sentences) // 2):
            issues.append(_issue("minor", "citation", f"{len(uncited)} of {len(sentences)} sentences with figures have no source attached"))
    return issues, n


def check_contradictions(text: str) -> (List[Dict], int):
    issues, seen = [], {}
    n = 0
    for m in _LABEL_NUM.finditer(text or ""):
        label = re.sub(r"\s+", " ", m.group("label").strip().lower())
        label = re.sub(r"^(?:the|a|an|total|average)\s+", "", label)
        v = _dec(m.group("n"))
        if v is None or len(label) < 4:
            continue
        n += 1
        if label in seen and not _close(seen[label], v):
            issues.append(_issue("major", "contradiction", f"'{label}' is given as both {seen[label]} and {v}"))
        seen.setdefault(label, v)
    return issues, n


def check_claims_vs_receipts(text: str, receipts: Optional[List[Dict]]) -> (List[Dict], int):
    """'I saved the file' is only acceptable when a verified receipt for a matching tool exists."""
    if receipts is None:
        return [], 0
    issues, n = [], 0
    ok_tools = {r.get("tool") for r in receipts if r.get("status") in ("verified", "unverified") and r.get("ok")}
    verified_tools = {r.get("tool") for r in receipts if r.get("status") == "verified"}
    for m in _DONE_CLAIM.finditer(text or ""):
        verb = m.group(1).lower()
        tools = _TOOL_FOR_VERB.get(verb, ())
        if not tools:
            continue
        n += 1
        if not (set(tools) & ok_tools):
            issues.append(_issue("major", "claim", f"the text says it {verb} something, but there is no successful {'/'.join(tools)} receipt"))
        elif not (set(tools) & verified_tools):
            issues.append(_issue("minor", "claim", f"it says it {verb} something; the tool finished but the result was not independently confirmed"))
    return issues, n


def check_code(text: str) -> (List[Dict], int):
    issues, n = [], 0
    for m in re.finditer(r"```(?:python|py)\s*\n(.*?)```", text or "", re.S | re.I):
        n += 1
        try:
            ast.parse(m.group(1))
        except SyntaxError as e:
            issues.append(_issue("major", "code", f"a Python block does not compile (line {e.lineno}: {e.msg})"))
    return issues, n


def check_certainty(text: str) -> (List[Dict], int):
    hits = _CERTAIN.findall(text or "")
    if len(hits) >= 3:
        return [_issue("minor", "certainty", "very confident wording ('" + "', '".join(sorted({h.lower() for h in hits})[:3]) + "') without hedging")], 1
    return [], 1 if hits else 0


def check_files(paths: Optional[List[str]]) -> (List[Dict], int):
    import os
    issues, n = [], 0
    for p in paths or []:
        n += 1
        if not os.path.exists(p):
            issues.append(_issue("major", "file", f"the file {p} does not exist"))
        elif os.path.isfile(p) and os.path.getsize(p) == 0:
            issues.append(_issue("major", "file", f"the file {p} is empty"))
    return issues, n


# ------------------------------------------------------------------ model use policy
def _model_allowed(importance: str, deterministic_checks: int, length: int) -> bool:
    mode = K.cfg_get("critic_budget", "balanced").strip().lower()
    if mode == "never":
        return False
    try:
        import friday_health7 as H
        if H.light_mode():
            return False
        fr = H.api_failure_rate()
        if fr is not None and fr > 0.5:
            return False
    except Exception:
        pass
    if mode == "always":
        return True
    # balanced: only when it can plausibly add value
    return importance == "high" and (deterministic_checks == 0 or length > 500)


def _model_review(content: str, evidence: Optional[str]) -> List[Dict]:
    try:
        import friday_router7 as R
        raw = R.llm("You are an independent fact checker. List ONLY clear factual, logical or arithmetic errors in the text below as a JSON array of short strings "
                    "(empty array if none). Do not rewrite it, do not praise it.\n" + (f"Evidence you may rely on:\n{evidence[:1500]}\n\n" if evidence else "") + f"TEXT:\n{content[:3000]}")
    except Exception:
        return []
    m = re.search(r"\[.*\]", raw or "", re.S)
    j = C.jload(m.group(0)) if m else None
    out = []
    if isinstance(j, list):
        for s in j[:5]:
            if isinstance(s, str) and len(s) > 8:
                out.append(_issue("minor", "model", K.clip(s, 200) + " (model opinion - not independently verified)"))
    return out


# ------------------------------------------------------------------ public API
def review(content: str, importance: str = "normal", evidence: Optional[str] = None, receipts: Optional[List[Dict]] = None, kind: Optional[str] = None,
           sources: Optional[List] = None, files: Optional[List[str]] = None, allow_model: bool = True) -> Dict:
    t0 = time.time()
    text = str(content or "")
    issues: List[Dict] = []
    checked: List[str] = []
    n_det = 0
    for name, fn in (("arithmetic", lambda: check_arithmetic(text)), ("totals", lambda: check_totals(text)), ("dates", lambda: check_dates(text)),
                     ("contradictions", lambda: check_contradictions(text)), ("code", lambda: check_code(text)), ("certainty", lambda: check_certainty(text)),
                     ("citations", lambda: check_citations(text, sources, require=(kind == "research" or sources is not None))),
                     ("claims vs receipts", lambda: check_claims_vs_receipts(text, receipts)), ("files", lambda: check_files(files))):
        try:
            iss, n = fn()
        except Exception as exc:
            C.log(f"critic check {name} failed safely: {exc}", "recovery")
            continue
        issues.extend(iss)
        if n:
            checked.append(f"{name} ({n})")
            n_det += n
    used_model = False
    if allow_model and text.strip() and _model_allowed(importance, n_det, len(text)):
        extra = _model_review(text, evidence)
        used_model = True
        issues.extend(extra)
    major = [i for i in issues if i["severity"] == "major"]
    ok = not major
    if not checked and not used_model:
        verdict = "There was nothing I could check mechanically, so this is unreviewed rather than confirmed."
    elif ok and not issues:
        verdict = "Checked " + ", ".join(checked) + (" and a second model opinion" if used_model else "") + ": no problems found."
    elif ok:
        verdict = f"No serious problems, {len(issues)} minor note(s): " + "; ".join(i["detail"] for i in issues[:2]) + "."
    else:
        verdict = f"I found {len(major)} problem(s): " + "; ".join(i["detail"] for i in major[:3]) + "."
    rec = {"ok": ok, "issues": issues, "checked": checked, "model_used": used_model, "verdict": verdict, "ms": int((time.time() - t0) * 1000), "importance": importance}
    K.emit("critic.review", {"ok": ok, "issues": len(issues), "major": len(major), "model": used_model})
    return rec


def tool_critic_review(args: Dict) -> Dict:
    """Orchestrator tool: {content, importance, sources?, receipts?}"""
    r = review(str(args.get("content", "")), str(args.get("importance", "normal")), evidence=args.get("evidence"), receipts=args.get("receipts"),
               kind=args.get("kind"), sources=args.get("sources"), files=args.get("files"))
    return {"ok": True, "output": r["verdict"], "review": r, "flagged": not r["ok"]}


def install(registry):
    registry.register("critic_review", tool_critic_review, risk="safe", desc="independently check an output (arithmetic, totals, citations, claims vs receipts)", post={"nonempty": True}, agent="critic")
