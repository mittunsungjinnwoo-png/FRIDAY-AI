"""
FRIDAY TASK GRAPH
-----------------
Implements the research doc's "Goal -> Plan -> Tasks -> Dependencies"
and "Every task should have a state" sections.

Pure stdlib, additive-only module: it does not alter any existing
file. Other new modules (friday_executive, friday_supervisor,
friday_unified_loop) build on top of this; nothing in your existing
Friday needs to change for this file to exist.

Task state machine (exactly as specified in the research doc):

    PENDING -> PLANNING -> RUNNING -> OBSERVING -> VERIFYING -> COMPLETED
    FAILED -> DIAGNOSING -> REPLANNING -> RETRYING

RETRYING loops back to RUNNING. A task that exhausts its retry policy
stays FAILED with a structured `failure_explanation`.
"""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Optional

STATE_FILE = Path(__file__).with_name("friday_task_graph_state.json")

TASK_STATES = (
    "PENDING", "PLANNING", "RUNNING", "OBSERVING", "VERIFYING", "COMPLETED",
    "FAILED", "DIAGNOSING", "REPLANNING", "RETRYING",
)
TERMINAL_STATES = ("COMPLETED", "FAILED")

_lock = threading.RLock()
_graph: dict[str, Any] = {"goals": {}, "tasks": {}}


def _load() -> None:
    global _graph
    try:
        if STATE_FILE.exists():
            raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict) and "goals" in raw and "tasks" in raw:
                _graph = raw
    except Exception:
        pass


def _save() -> None:
    try:
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_graph, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        os.replace(tmp, STATE_FILE)
    except Exception:
        pass


_load()


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


def create_goal(description: str, priority: float = 0.5, metadata: Optional[dict[str, Any]] = None) -> dict[str, Any]:
    """GOAL: the thing the user (or a proactive trigger) actually wants achieved."""
    goal_id = _new_id("goal")
    goal = {
        "id": goal_id,
        "description": str(description or "").strip(),
        "status": "PENDING",
        "priority": float(max(0.0, min(1.0, priority))),
        "task_ids": [],
        "created": time.time(),
        "updated_at": time.time(),
        "metadata": metadata or {},
    }
    with _lock:
        _graph["goals"][goal_id] = goal
        _save()
    return dict(goal)


def create_task(
    goal_id: Optional[str],
    action: str,
    *,
    dependencies: Optional[list[str]] = None,
    priority: float = 0.5,
    inputs: Optional[dict[str, Any]] = None,
    verification_criteria: Optional[dict[str, Any]] = None,
    verification_level: str = "mechanical",
    retry_policy: Optional[dict[str, Any]] = None,
    agent_group: Optional[str] = None,
    agent_name: Optional[str] = None,
) -> dict[str, Any]:
    """A single step of a plan, exactly matching the doc's `task = {...}` shape,
    extended with dependencies / priority / verification criteria / retry policy
    as the doc's "Planning - 9.5+" section calls for.
    """
    task_id = _new_id("task")
    task = {
        "id": task_id,
        "goal_id": goal_id,
        "action": str(action or "").strip(),
        "status": "PENDING",
        "priority": float(max(0.0, min(1.0, priority))),
        "dependencies": list(dependencies or []),
        "inputs": inputs or {},
        "outputs": None,
        "verification_criteria": verification_criteria or {},
        "verification_level": verification_level,
        "verification_result": None,
        "agent_group": agent_group,
        "agent_name": agent_name,
        "attempts": 0,
        "retry_policy": retry_policy or {"max_attempts": 3, "strategy": "alternate_then_stop"},
        "history": [],
        "failure_explanation": None,
        "created": time.time(),
        "updated_at": time.time(),
    }
    with _lock:
        _graph["tasks"][task_id] = task
        if goal_id and goal_id in _graph["goals"]:
            _graph["goals"][goal_id]["task_ids"].append(task_id)
            _graph["goals"][goal_id]["updated_at"] = time.time()
        _save()
    return dict(task)


def set_status(task_id: str, status: str, note: Optional[str] = None) -> Optional[dict[str, Any]]:
    if status not in TASK_STATES:
        return None
    with _lock:
        task = _graph["tasks"].get(task_id)
        if not task:
            return None
        task["status"] = status
        task["updated_at"] = time.time()
        task["history"].append({"status": status, "ts": time.time(), "note": note})
        if status == "RUNNING":
            task["attempts"] = int(task.get("attempts", 0)) + 1
        _graph["tasks"][task_id] = task
        _maybe_update_goal_status(task.get("goal_id"))
        _save()
        return dict(task)


def set_outputs(task_id: str, outputs: Any) -> None:
    with _lock:
        task = _graph["tasks"].get(task_id)
        if task:
            task["outputs"] = outputs
            task["updated_at"] = time.time()
            _save()


def set_verification_result(task_id: str, result: dict[str, Any]) -> None:
    with _lock:
        task = _graph["tasks"].get(task_id)
        if task:
            task["verification_result"] = result
            task["updated_at"] = time.time()
            _save()


def set_failure_explanation(task_id: str, explanation: str) -> None:
    with _lock:
        task = _graph["tasks"].get(task_id)
        if task:
            task["failure_explanation"] = explanation
            task["updated_at"] = time.time()
            _save()


def can_retry(task_id: str) -> bool:
    with _lock:
        task = _graph["tasks"].get(task_id)
        if not task:
            return False
        max_attempts = int(task.get("retry_policy", {}).get("max_attempts", 3))
        return int(task.get("attempts", 0)) < max_attempts


def dependencies_satisfied(task_id: str) -> bool:
    with _lock:
        task = _graph["tasks"].get(task_id)
        if not task:
            return False
        for dep_id in task.get("dependencies", []):
            dep = _graph["tasks"].get(dep_id)
            if not dep or dep.get("status") != "COMPLETED":
                return False
        return True


def ready_tasks(goal_id: str) -> list[dict[str, Any]]:
    """Tasks belonging to `goal_id` whose dependencies are all COMPLETED and
    which are not yet in a terminal state, ordered by priority (desc)."""
    with _lock:
        goal = _graph["goals"].get(goal_id)
        if not goal:
            return []
        out = []
        for task_id in goal.get("task_ids", []):
            task = _graph["tasks"].get(task_id)
            if not task:
                continue
            if task["status"] in TERMINAL_STATES:
                continue
            if dependencies_satisfied(task_id):
                out.append(dict(task))
        out.sort(key=lambda t: t.get("priority", 0.5), reverse=True)
        return out


def _maybe_update_goal_status(goal_id: Optional[str]) -> None:
    if not goal_id:
        return
    goal = _graph["goals"].get(goal_id)
    if not goal:
        return
    tasks = [_graph["tasks"].get(tid) for tid in goal.get("task_ids", [])]
    tasks = [t for t in tasks if t]
    if not tasks:
        return
    if all(t["status"] == "COMPLETED" for t in tasks):
        goal["status"] = "COMPLETED"
    elif any(t["status"] == "FAILED" and not can_retry(t["id"]) for t in tasks):
        goal["status"] = "FAILED"
    else:
        goal["status"] = "RUNNING"
    goal["updated_at"] = time.time()


def get_goal(goal_id: str) -> Optional[dict[str, Any]]:
    with _lock:
        goal = _graph["goals"].get(goal_id)
        return dict(goal) if goal else None


def get_task(task_id: str) -> Optional[dict[str, Any]]:
    with _lock:
        task = _graph["tasks"].get(task_id)
        return dict(task) if task else None


def goal_tasks(goal_id: str) -> list[dict[str, Any]]:
    with _lock:
        goal = _graph["goals"].get(goal_id)
        if not goal:
            return []
        return [dict(_graph["tasks"][t]) for t in goal.get("task_ids", []) if t in _graph["tasks"]]


def goal_is_complete(goal_id: str) -> bool:
    goal = get_goal(goal_id)
    return bool(goal and goal.get("status") == "COMPLETED")


def open_goal_count() -> int:
    with _lock:
        return sum(1 for g in _graph.get("goals", {}).values() if g.get("status") not in ("COMPLETED", "FAILED"))


def prune(max_age_seconds: float = 7 * 24 * 3600) -> int:
    """Drop terminal goals/tasks older than max_age_seconds. Returns count removed."""
    removed = 0
    now = time.time()
    with _lock:
        stale_goals = [
            gid for gid, g in _graph["goals"].items()
            if g.get("status") in ("COMPLETED", "FAILED") and now - g.get("updated_at", now) > max_age_seconds
        ]
        for gid in stale_goals:
            for tid in _graph["goals"][gid].get("task_ids", []):
                _graph["tasks"].pop(tid, None)
                removed += 1
            _graph["goals"].pop(gid, None)
            removed += 1
        if stale_goals:
            _save()
    return removed
