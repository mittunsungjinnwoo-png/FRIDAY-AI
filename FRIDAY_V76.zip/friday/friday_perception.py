"""
FRIDAY PERCEPTION LAYER
-----------------------
Implements the research doc's "1. Perception layer" section: a single
facade (hear / see_screen / inspect_file / inspect_system) so "the
planner shouldn't care how information was obtained."

    Planner: "What is currently on the screen?"
                    |
                    v
                Perception
                    |
                    v
             Screen Intelligence
                    |
                    v
            Structured observation

This module does NOT reimplement voice/screen/system logic. It is a
thin, defensive wrapper that lazily imports your EXISTING modules
(friday_voice_engine, friday_screen_intelligence, friday_uia,
friday_gemini_computer_use, friday_system_control, friday_truth_verifier)
and normalises whatever they return into one structured shape. If a
given backend module or one of ITS optional dependencies isn't
available in the current environment, that sense simply reports
{"available": False, ...} instead of raising -- callers can always
treat the return value as a plain dict.

Nothing here imports any existing module at MODULE level, so simply
importing friday_perception can never fail or have side effects, even
on a machine with none of the optional voice/vision dependencies
installed.
"""

from __future__ import annotations

import os
import platform
import time
from pathlib import Path
from typing import Any, Optional


def _safe_import(name: str):
    try:
        import importlib
        return importlib.import_module(name)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# hear() - voice / ASR sense
# ---------------------------------------------------------------------------

def hear(timeout: Optional[float] = None) -> dict[str, Any]:
    """Attempt one listen/transcribe cycle via the existing voice engine.

    Tries, in order: friday_voice_engine.listen_once / listen / transcribe.
    Reports {"available": False} rather than raising if no compatible
    function is found or the voice stack isn't installed in this
    environment (e.g. no microphone, no faster-whisper).
    """
    mod = _safe_import("friday_voice_engine")
    if mod is None:
        return {"available": False, "text": None, "reason": "friday_voice_engine not importable here", "ts": time.time()}
    for fn_name in ("listen_once", "listen", "transcribe", "capture_and_transcribe"):
        fn = getattr(mod, fn_name, None)
        if callable(fn):
            try:
                if timeout is not None:
                    try:
                        result = fn(timeout=timeout)
                    except TypeError:
                        result = fn()
                else:
                    result = fn()
                text = result if isinstance(result, str) else (result or {}).get("text") if isinstance(result, dict) else None
                return {"available": True, "text": text, "raw": result if not isinstance(result, str) else None,
                        "backend_fn": fn_name, "ts": time.time()}
            except Exception as exc:
                return {"available": True, "text": None, "error": str(exc), "backend_fn": fn_name, "ts": time.time()}
    return {"available": False, "text": None, "reason": "no known listen function on friday_voice_engine", "ts": time.time()}


# ---------------------------------------------------------------------------
# see_screen() - vision / screen intelligence sense
# ---------------------------------------------------------------------------

def see_screen(describe: bool = False) -> dict[str, Any]:
    """Structured observation of the current screen.

    Prefers friday_screen_intelligence (your richer, purpose-built module)
    for a description; always tries friday_truth_verifier.snapshot() for
    raw evidence (window title / cursor / OCR / UIA), since that module
    already has well-tested optional-dependency fallbacks.
    """
    observation: dict[str, Any] = {"available": False, "ts": time.time()}

    tv = _safe_import("friday_truth_verifier")
    if tv is not None:
        try:
            snap = tv.snapshot()
            observation.update({
                "available": True,
                "active_window": snap.get("window"),
                "cursor": snap.get("cursor"),
                "ocr_text": snap.get("ocr"),
                "uia_elements": len(snap.get("uia") or []),
            })
        except Exception as exc:
            observation["error"] = str(exc)

    if describe:
        si = _safe_import("friday_screen_intelligence")
        if si is not None:
            for fn_name in ("describe_screen", "analyze_screen", "describe", "analyze"):
                fn = getattr(si, fn_name, None)
                if callable(fn):
                    try:
                        observation["description"] = fn()
                        observation["available"] = True
                        break
                    except Exception as exc:
                        observation["description_error"] = str(exc)

    if not observation.get("available"):
        observation["reason"] = "no screen backend importable in this environment"
    return observation


# ---------------------------------------------------------------------------
# inspect_file() - file / document sense
# ---------------------------------------------------------------------------

def inspect_file(path: str | Path, preview_chars: int = 2000) -> dict[str, Any]:
    """Metadata + a safe text preview of a file. Never raises; binary or
    unreadable files just get preview=None."""
    p = Path(path)
    info: dict[str, Any] = {
        "available": p.exists(),
        "path": str(p),
        "exists": p.exists(),
        "is_file": p.is_file() if p.exists() else False,
        "size": None,
        "modified": None,
        "preview": None,
        "ts": time.time(),
    }
    if not p.exists():
        info["reason"] = "file does not exist"
        return info
    try:
        stat = p.stat()
        info["size"] = stat.st_size
        info["modified"] = stat.st_mtime
    except Exception as exc:
        info["stat_error"] = str(exc)
    if p.is_file() and p.suffix.lower() in {".txt", ".md", ".json", ".py", ".csv", ".log", ".yaml", ".yml"}:
        try:
            info["preview"] = p.read_text(encoding="utf-8", errors="replace")[:preview_chars]
        except Exception as exc:
            info["preview_error"] = str(exc)
    return info


# ---------------------------------------------------------------------------
# inspect_system() - system / environment sense
# ---------------------------------------------------------------------------

def inspect_system() -> dict[str, Any]:
    """Best-effort system snapshot. Prefers friday_system_control if it
    exposes a status/inspect function; otherwise falls back to psutil if
    installed; otherwise to plain stdlib platform info so this NEVER
    returns unavailable."""
    info: dict[str, Any] = {
        "available": True,
        "platform": platform.system(),
        "platform_release": platform.release(),
        "python_version": platform.python_version(),
        "cwd": os.getcwd(),
        "ts": time.time(),
    }

    sc = _safe_import("friday_system_control")
    if sc is not None:
        for fn_name in ("get_status", "inspect", "system_status", "status"):
            fn = getattr(sc, fn_name, None)
            if callable(fn):
                try:
                    info["system_control"] = fn()
                    break
                except Exception as exc:
                    info["system_control_error"] = str(exc)

    psutil = _safe_import("psutil")
    if psutil is not None:
        try:
            info["cpu_percent"] = psutil.cpu_percent(interval=0.0)
            info["memory_percent"] = psutil.virtual_memory().percent
        except Exception as exc:
            info["psutil_error"] = str(exc)

    return info


def snapshot_all(describe_screen: bool = False, *, include_screen: bool = True, include_system: bool = True) -> dict[str, Any]:
    """One call that gathers everything the doc's 'PERCEIVE' step needs:
    screen + system (voice is intentionally excluded from the passive
    snapshot since listening is an active, blocking action a caller opts
    into via hear())."""
    return {
        "screen": see_screen(describe=describe_screen) if include_screen else {"skipped": True, "reason": "fast_path"},
        "system": inspect_system() if include_system else {"skipped": True, "reason": "fast_path"},
        "ts": time.time(),
    }
