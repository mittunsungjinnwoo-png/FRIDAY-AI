# FRIDAY V2.2.6 - widget can't vanish, taskbar icon in widget mode, easy uninstall

## Widget always stays until the app is closed
Causes found: the widget was hidden from the taskbar, could be sent behind other windows (the "keep on top" setting),
dragged off-screen, minimised/hidden by Win+D, or lost after a display/lock-screen change or renderer crash - and then
nothing on screen or in the taskbar could bring it back or close the app.
- A watchdog (every 1.5 s + on display change, unlock, resume, hide, minimise, close) re-creates, re-shows, restores, re-pins on top and pulls the widget back on screen.
- The widget is clamped to the screen when dragged; always on top (the old "keep above other windows" toggle was removed).
- A crashed/unresponsive widget page reloads itself.
- Closing the widget (Alt+F4, taskbar > Close window) now closes the whole app instead of leaving it running unseen.
- New small x button in the widget panel header = close FRIDAY. Tray icon menu: Open FRIDAY / Show widget / Uninstall / Quit.

## Taskbar icon in widget mode
- The widget window now has its own taskbar button with the FRIDAY icon (skipTaskbar off, icon set); the app ID is set on startup so the icon groups correctly.

## Uninstall (several ways)
- Windows Settings > Apps > FRIDAY > Uninstall (installed with the setup .exe)
- Start menu > "Uninstall FRIDAY" (new shortcut) - also removed on uninstall
- FRIDAY > Settings > AI > Uninstall FRIDAY...
- Tray icon (bottom right) > Uninstall FRIDAY...
- `UNINSTALL_FRIDAY.bat` (new): for running from the folder or any leftovers - closes FRIDAY, removes shortcuts, runs the installed uninstaller if found, optionally deletes saved data and the folder.
- The uninstaller force-stops FRIDAY (even in widget mode) and asks whether to delete saved data.

## Files changed
main.js, widget.html, friday_settings.js, installer.nsh, package.json (2.2.6), UNINSTALL_FRIDAY.bat (new), this note.
Speech, listening, finance, notes, Gemini code untouched.
