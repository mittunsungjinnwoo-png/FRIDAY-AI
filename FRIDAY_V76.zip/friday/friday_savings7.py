"""FRIDAY 7.0 domain intelligence for money saving (roadmap #17).

Ingredient cost estimation, recipe costing, alternative comparison, price history and budget-aware advice - built so that a number can never
quietly come from a guess:

* There are NO built-in prices.  Every price comes from the PRICE BOOK, i.e. something you told me ("rice is 60 per kg at Keells").
* Arithmetic is exact (Decimal) and re-checked by a second method (Fraction) before a total is reported.
* Every costed line lands in exactly one of three groups that are never added together:
      RECORDED   a recorded price in the same kind of unit - nothing assumed
      ESTIMATED  a price you marked as an estimate, OR a conversion I had to assume (cups -> grams needs a density, "3 onions" needs a weight)
      UNPRICED   no recorded price / no way to convert - left out of every total and listed so you can fill the gap
* Budget comparisons use the figures recorded in FRIDAY's finance engine; nothing is recalculated by a language model.

Tools: cost_recipe, compare_costs, budget_check, finance_snapshot  (registered by install()).
"""
from __future__ import annotations

import json
import re
import time
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from fractions import Fraction
from typing import Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

D = Decimal
CENT = D("0.01")

C.register_schema("""
CREATE TABLE IF NOT EXISTS prices7(id INTEGER PRIMARY KEY, ts REAL, item TEXT, norm TEXT, price TEXT, qty TEXT, unit TEXT, dim TEXT, ppb TEXT, currency TEXT, store TEXT, kind TEXT DEFAULT 'recorded', source TEXT DEFAULT 'user');
CREATE INDEX IF NOT EXISTS ix_prices7_norm ON prices7(norm, ts);
CREATE TABLE IF NOT EXISTS recipes7(id INTEGER PRIMARY KEY, name TEXT UNIQUE, servings INTEGER, ing TEXT, ts REAL);
""")

# ------------------------------------------------------------------ units (definitions, not prices)
# unit -> (dimension, factor to the base unit of that dimension: grams, millilitres, pieces)
UNITS: Dict[str, Tuple[str, D]] = {}
for _names, _dim, _f in (
    (("g", "gm", "gms", "gram", "grams", "gramme", "grammes"), "mass", "1"), (("kg", "kgs", "kilo", "kilos", "kilogram", "kilograms"), "mass", "1000"),
    (("mg",), "mass", "0.001"), (("oz", "ounce", "ounces"), "mass", "28.349523125"), (("lb", "lbs", "pound", "pounds"), "mass", "453.59237"),
    (("ml", "millilitre", "millilitres", "milliliter", "milliliters"), "volume", "1"), (("l", "litre", "litres", "liter", "liters"), "volume", "1000"),
    (("cup", "cups"), "volume", "240"), (("tbsp", "tbsps", "tablespoon", "tablespoons"), "volume", "15"), (("tsp", "tsps", "teaspoon", "teaspoons"), "volume", "5"),
    (("floz", "fl oz"), "volume", "29.5735"),
    (("pcs", "pc", "piece", "pieces", "each", "whole", "item", "items", "ea", "unit", "units", "clove", "cloves", "slice", "slices"), "count", "1"),
    (("dozen", "doz"), "count", "12"), (("pair", "pairs"), "count", "2"),
):
    for _n in _names:
        UNITS[_n] = (_dim, D(_f))

# ASSUMPTIONS - used only to bridge dimensions, always reported as assumed
DENSITY_G_PER_ML = {"water": "1.0", "milk": "1.03", "oil": "0.92", "flour": "0.53", "sugar": "0.85", "rice": "0.78", "dhal": "0.80", "lentil": "0.80", "salt": "1.2", "butter": "0.96",
                    "honey": "1.42", "oats": "0.38", "yogurt": "1.03", "curd": "1.03", "coconut milk": "0.97", "tea": "0.4", "coffee": "0.4", "cream": "1.0", "semolina": "0.7", "rava": "0.7"}
PIECE_WEIGHT_G = {"egg": "50", "onion": "150", "potato": "170", "tomato": "120", "carrot": "70", "garlic": "5", "lemon": "60", "banana": "120", "apple": "180", "bread": "30",
                  "chilli": "5", "chili": "5", "capsicum": "150", "cucumber": "300", "brinjal": "250", "eggplant": "250", "lime": "45", "orange": "150", "coconut": "400", "beetroot": "150"}
ALIASES = {"onions": "onion", "tomatoes": "tomato", "potatoes": "potato", "eggs": "egg", "carrots": "carrot", "lentils": "dhal", "red lentils": "dhal", "red lentil": "dhal",
           "lemons": "lemon", "limes": "lime", "bananas": "banana", "apples": "apple", "chillies": "chilli", "chilies": "chili", "cooking oil": "oil", "vegetable oil": "oil",
           "sunflower oil": "oil", "coconut oil": "oil", "olive oil": "oil", "basmati rice": "rice", "white rice": "rice", "red rice": "rice", "garlic clove": "garlic", "garlic cloves": "garlic",
           "cloves of garlic": "garlic", "chicken breast": "chicken", "chicken breasts": "chicken", "plain flour": "flour", "wheat flour": "flour", "all-purpose flour": "flour"}
IGNORE_NAMES = re.compile(r"^(?:minutes?|mins?|hours?|hrs?|degrees?|servings?|people|persons?|steps?|times?|days?|weeks?|calories?|kcal|cm|inch(?:es)?|percent|%)\b", re.I)
STALE_DAYS = 60


# ------------------------------------------------------------------ small helpers
def _d(x) -> Optional[D]:
    try:
        return D(str(x).replace(",", "").strip())
    except (InvalidOperation, ValueError):
        return None


def money(x: D, cur: str = "") -> str:
    q = x.quantize(CENT, rounding=ROUND_HALF_UP)
    s = f"{q:,.2f}"
    return f"{cur} {s}".strip() if cur else s


def _cur_default() -> str:
    try:
        from friday_finance_engine import STATE
        return str(STATE.get("cur", "Rs") or "Rs")
    except Exception:
        return "Rs"


_CUR = {"rs": "Rs", "rs.": "Rs", "lkr": "Rs", "rupee": "Rs", "rupees": "Rs", "₹": "₹", "inr": "₹", "$": "$", "usd": "$", "dollar": "$", "dollars": "$", "£": "£", "gbp": "£", "pound": "£", "€": "€", "eur": "€", "euro": "€", "euros": "€"}


def norm_item(name: str) -> str:
    s = re.sub(r"[^a-z0-9' -]+", " ", str(name).lower())
    s = re.sub(r"\b(?:fresh|organic|large|small|medium|chopped|diced|sliced|minced|grated|ripe|raw|dried|boiled|whole)\b", " ", s)
    s = re.sub(r"\s+", " ", s).strip(" -'")
    if s in ALIASES:
        return ALIASES[s]
    words = s.split()
    if words and words[-1] in ALIASES:
        words[-1] = ALIASES[words[-1]]
        s = " ".join(words)
    if s.endswith("ies") and len(s) > 4:
        s = s[:-3] + "y"
    elif s.endswith("oes"):
        s = s[:-2]
    elif s.endswith("s") and not s.endswith("ss") and len(s) > 3:
        s = s[:-1]
    return ALIASES.get(s, s)


def _unit(u: str) -> Optional[Tuple[str, D]]:
    return UNITS.get((u or "").lower().strip(". "))


# ------------------------------------------------------------------ price book
def record_price(item: str, price, qty="1", unit: str = "each", store: str = "", currency: str = "", estimate: bool = False, source: str = "user") -> Dict:
    p, q = _d(price), _d(qty)
    u = _unit(unit or "each")
    if p is None or q is None or p < 0 or q <= 0:
        return {"ok": False, "error": "I couldn't read that price"}
    if u is None:
        return {"ok": False, "error": f"I don't know the unit '{unit}'. Use kg, g, litre, ml, cup, tbsp, each or dozen."}
    dim, factor = u
    ppb = p / (q * factor)                                      # price per gram / millilitre / piece
    cur = _CUR.get((currency or "").lower().strip(), currency) or _cur_default()
    nm = norm_item(item)
    if not nm:
        return {"ok": False, "error": "which item is that price for?"}
    pid = C.x("INSERT INTO prices7(ts,item,norm,price,qty,unit,dim,ppb,currency,store,kind,source) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
              (C.now(), item.strip().lower(), nm, str(p), str(q), (unit or "each").lower(), dim, format(ppb, "f") if ppb < D("1e-12") else str(ppb), cur, store.strip().lower(), "estimate" if estimate else "recorded", source))
    K.emit("price.recorded", {"id": pid, "item": nm})
    return {"ok": True, "id": pid, "item": nm, "price": p, "per": f"{q.normalize():f} {unit}", "currency": cur, "store": store, "kind": "estimate" if estimate else "recorded"}


def _entry(r) -> Dict:
    return {"id": r["id"], "ts": r["ts"], "item": r["item"], "norm": r["norm"], "price": _d(r["price"]), "qty": _d(r["qty"]), "unit": r["unit"], "dim": r["dim"], "ppb": _d(r["ppb"]),
            "currency": r["currency"], "store": r["store"], "kind": r["kind"], "age_days": int((time.time() - r["ts"]) / 86400)}


def prices_for(item: str, limit: int = 40) -> List[Dict]:
    """All entries for an item (exact normalised name first, then names sharing every word), newest first."""
    nm = norm_item(item)
    rows = C.q("SELECT * FROM prices7 WHERE norm=? ORDER BY ts DESC LIMIT ?", (nm, limit))
    if not rows and nm:
        toks = set(nm.split())
        cands = C.q("SELECT * FROM prices7 ORDER BY ts DESC LIMIT 400")
        rows = [r for r in cands if toks and (toks <= set(r["norm"].split()) or set(r["norm"].split()) <= toks)][:limit]
    return [_entry(r) for r in rows]


def latest_per_store(item: str) -> List[Dict]:
    seen, out = set(), []
    for e in prices_for(item):
        if e["store"] in seen:
            continue
        seen.add(e["store"])
        out.append(e)
    return out


def best_entry(item: str, dim: Optional[str] = None) -> Optional[Dict]:
    """The entry used for costing: the cheapest of the latest price per store (a recorded price beats an estimate when both are fresh)."""
    es = latest_per_store(item)
    if dim:
        same = [e for e in es if e["dim"] == dim]
        es = same or es
    if not es:
        return None
    rec = [e for e in es if e["kind"] == "recorded"]
    return min(rec or es, key=lambda e: e["ppb"])


def forget_price(item: str) -> int:
    nm = norm_item(item)
    return K.xn("DELETE FROM prices7 WHERE norm=?", (nm,))


def history(item: str) -> Dict:
    es = list(reversed(prices_for(item, 200)))
    if not es:
        return {"ok": False, "error": f"I have no recorded prices for {item}"}
    same = [e for e in es if e["dim"] == es[-1]["dim"] and e["currency"] == es[-1]["currency"]]
    first, last = same[0], same[-1]
    hi, lo = max(same, key=lambda e: e["ppb"]), min(same, key=lambda e: e["ppb"])
    change = None if len(same) < 2 or first["ppb"] == 0 else ((last["ppb"] - first["ppb"]) / first["ppb"] * 100).quantize(D("0.1"), rounding=ROUND_HALF_UP)
    return {"ok": True, "entries": es, "count": len(same), "first": first, "last": last, "high": hi, "low": lo, "change_pct": change}


def _age_text(d: int) -> str:
    return "recorded today" if d <= 0 else "recorded 1 day ago" if d == 1 else f"recorded {d} days ago"


def _per_text(e: Dict) -> str:
    q = e["qty"].normalize()
    if e["unit"] in ("each", "piece", "pcs", "pc", "item", "whole") and q == 1:
        return f"{money(e['price'], e['currency'])} each"
    qs = "" if q == 1 else f"{q:f} "
    return f"{money(e['price'], e['currency'])} per {qs}{e['unit']}"


# ------------------------------------------------------------------ ingredient parsing
_QTY = r"(?:\d+\s+\d+/\d+|\d+/\d+|\d+(?:\.\d+)?(?:\s*[-–]\s*\d+(?:\.\d+)?)?|[¼½¾⅓⅔⅛])"
_UNIT = r"(?:kgs?|kilos?|kilograms?|gm?s?|grams?|grammes?|mg|oz|ounces?|lbs?|pounds?|ml|millilit(?:re|er)s?|l|lit(?:re|er)s?|cups?|tbsps?|tablespoons?|tsps?|teaspoons?|pcs?|pieces?|each|dozen|doz|cloves?|slices?)"
_FRAC = {"¼": D("0.25"), "½": D("0.5"), "¾": D("0.75"), "⅓": D("0.3333333333"), "⅔": D("0.6666666667"), "⅛": D("0.125")}
_LINE_A = re.compile(rf"^\s*(?:[-*•·]+\s*|\d+[.)]\s+)?(?P<qty>{_QTY})\s*(?P<unit>{_UNIT})?\b\.?\s*(?:of\s+)?(?P<name>[A-Za-z][A-Za-z' \-]{{1,40}}?)\s*(?:[,(;:].*)?$", re.I)
_LINE_B = re.compile(rf"^\s*(?P<name>[A-Za-z][A-Za-z' \-]{{1,40}}?)\s*[:\-–]?\s*(?P<qty>{_QTY})\s*(?P<unit>{_UNIT})?\s*$", re.I)


def _qty(s: str) -> Tuple[Optional[D], bool]:
    s = s.strip()
    if s in _FRAC:
        return _FRAC[s], False
    rng = re.match(r"^(\d+(?:\.\d+)?)\s*[-–]\s*(\d+(?:\.\d+)?)$", s)
    if rng:
        return D(rng.group(2)), True                 # a range: use the upper end (the safe side for a budget) and say so
    mixed = re.match(r"^(\d+)\s+(\d+)/(\d+)$", s)
    if mixed:
        return D(mixed.group(1)) + D(mixed.group(2)) / D(mixed.group(3)), False
    frac = re.match(r"^(\d+)/(\d+)$", s)
    if frac and int(frac.group(2)):
        return D(frac.group(1)) / D(frac.group(2)), False
    return _d(s), False


def _known_item(name: str) -> bool:
    nm = norm_item(name)
    return nm in PIECE_WEIGHT_G or nm in DENSITY_G_PER_ML or bool(C.q("SELECT 1 FROM prices7 WHERE norm=? LIMIT 1", (nm,)))


def parse_ingredients(text: str, strict: bool = False) -> List[Dict]:
    """Ingredient lines from a typed list or a block of text. strict=True (free text such as research) only accepts a line with a known unit
    or a known item, so '30 minutes' or '350 degrees' are never read as ingredients."""
    out: List[Dict] = []
    text = str(text or "")
    parts = re.split(r"[\n;]|,(?=\s*(?:\d|[A-Za-z]+\s+\d|[¼½¾⅓⅔⅛]))|\s+\band\b\s+(?=\d)", text)
    for raw in parts:
        raw = raw.strip(" \t-•*·")
        if not raw or len(raw) > 90:
            continue
        m = _LINE_A.match(raw) or _LINE_B.match(raw)
        if not m:
            continue
        name = re.sub(r"\s+", " ", m.group("name")).strip(" -'")
        unit = (m.group("unit") or "").lower()
        vague = re.match(r"^(pinch(?:es)?|dash(?:es)?|handful|sprigs?|bunch(?:es)?|knob|splash|drizzle)\s+(?:of\s+)?(.+)$", name, re.I)
        if vague:
            unit, name = vague.group(1).lower(), vague.group(2).strip()
        if not name or IGNORE_NAMES.match(name) or len(name.split()) > 5:
            continue
        qty, ranged = _qty(m.group("qty"))
        if qty is None or qty <= 0:
            continue
        if strict and not unit and not _known_item(name):
            continue
        if strict and unit and IGNORE_NAMES.match(name):
            continue
        out.append({"raw": raw, "qty": qty, "unit": unit or "each", "name": name, "norm": norm_item(name), "ranged": ranged, "assumed_unit": not unit})
    seen, uniq = set(), []
    for i in out:
        k = (i["norm"], str(i["qty"]), i["unit"])
        if k not in seen:
            seen.add(k)
            uniq.append(i)
    return uniq[:60]


def servings_in(text: str) -> Optional[int]:
    m = re.search(r"\b(?:serves|servings?|feeds)\s*[:\-]?\s*(\d{1,2})\b", str(text), re.I) or re.search(r"\b(?:makes|for)\s+(\d{1,2})\s*(?:servings?|portions?|people|persons)\b", str(text), re.I) \
        or re.search(r"\b(\d{1,2})\s*(?:servings?|portions?|people|persons)\b", str(text), re.I)
    return int(m.group(1)) if m else None


# ------------------------------------------------------------------ costing
def _convert(ing: Dict, entry: Dict) -> Tuple[Optional[D], List[str], str]:
    """Quantity of the ingredient expressed in the base unit of the price entry. -> (qty, assumptions, why_not)"""
    u = _unit(ing["unit"])
    if u is None:
        if re.match(r"^(?:pinch|dash|handful|sprig|bunch|knob|splash|drizzle)", ing["unit"]):
            return None, [], f"a '{ing['unit']}' is too vague to price exactly"
        return None, [], f"I don't know the unit '{ing['unit']}'"
    dim, factor = u
    qty = ing["qty"] * factor
    notes: List[str] = []
    if ing.get("assumed_unit"):
        pass
    if dim == entry["dim"]:
        return qty, notes, ""
    nm = ing["norm"]
    if dim in ("mass", "volume") and entry["dim"] in ("mass", "volume"):
        dens = D(DENSITY_G_PER_ML.get(nm) or next((v for k, v in DENSITY_G_PER_ML.items() if k in nm.split()), "0"))
        if dens <= 0:
            return None, [], f"I don't know how heavy a {ing['unit']} of {ing['name']} is, so I can't turn it into {entry['unit']}"
        if dim == "volume":
            return qty * dens, [f"assumed the density of {ing['name']} is {dens} g per ml"], ""
        return qty / dens, [f"assumed the density of {ing['name']} is {dens} g per ml"], ""
    if dim == "count" and entry["dim"] == "mass":
        w = PIECE_WEIGHT_G.get(nm)
        if not w:
            return None, [], f"I don't know the usual weight of one {ing['name']}"
        return qty * D(w), [f"assumed one piece of {ing['name']} weighs {w} g"], ""
    if dim == "mass" and entry["dim"] == "count":
        w = PIECE_WEIGHT_G.get(nm)
        if not w:
            return None, [], f"I don't know the usual weight of one {ing['name']}"
        return qty / D(w), [f"assumed one piece of {ing['name']} weighs {w} g"], ""
    return None, [], f"I can't convert {ing['unit']} of {ing['name']} to the unit its price is recorded in ({entry['unit']})"


def cost_line(ing: Dict, currency: str) -> Dict:
    line = {"ingredient": ing["raw"], "name": ing["name"], "qty": ing["qty"], "unit": ing["unit"], "group": "unpriced", "cost": None, "notes": [], "reason": "", "entry": None}
    cands = [e for e in latest_per_store(ing["norm"])]
    if not cands:
        line["reason"] = "no recorded price"
        return line
    # prefer an entry in the same currency and the same dimension (no assumption needed)
    u = _unit(ing["unit"])
    cands.sort(key=lambda e: (e["currency"] != currency, u is None or e["dim"] != u[0], e["kind"] != "recorded", e["ppb"]))
    entry = cands[0]
    if entry["currency"] != currency:
        line["reason"] = f"its price is in {entry['currency']}, not {currency}"
        return line
    qty_base, notes, why = _convert(ing, entry)
    if qty_base is None:
        line["reason"] = why
        return line
    cost = qty_base * entry["ppb"]
    line.update({"cost": cost, "entry": entry, "qty_base": qty_base})
    if ing.get("ranged"):
        notes.append("a range was given, so I used the upper end")
    if entry["kind"] == "estimate":
        notes.append("the price you gave was an estimate")
    if entry["age_days"] > STALE_DAYS:
        line["stale"] = entry["age_days"]
    line["notes"] = notes
    line["group"] = "recorded" if not [n for n in notes if n.startswith("assumed") or "estimate" in n] else "estimated"
    return line


def _selfcheck(lines: List[Dict]) -> bool:
    """Second, independent calculation with Fractions straight from the stored strings."""
    try:
        for g in ("recorded", "estimated"):
            a = sum((l["cost"] for l in lines if l["group"] == g), D(0))
            b = sum((Fraction(str(l["qty_base"])) * Fraction(str(l["entry"]["price"])) / (Fraction(str(l["entry"]["qty"])) * Fraction(str(_unit(l["entry"]["unit"])[1]))) for l in lines if l["group"] == g), Fraction(0))
            if abs(Fraction(str(a)) - b) > Fraction(1, 200):
                return False
        return True
    except Exception:
        return False


def cost_ingredients(ings: List[Dict], servings: Optional[int] = None, title: str = "") -> Dict:
    cur = _cur_default()
    first = next((e for i in ings for e in latest_per_store(i["norm"])), None)
    if first:
        cur = first["currency"]
    lines = [cost_line(i, cur) for i in ings]
    rec = sum((l["cost"] for l in lines if l["group"] == "recorded"), D(0))
    est = sum((l["cost"] for l in lines if l["group"] == "estimated"), D(0))
    unpriced = [l for l in lines if l["group"] == "unpriced"]
    return {"title": title, "currency": cur, "lines": lines, "recorded_total": rec, "estimated_total": est, "unpriced": unpriced, "servings": servings,
            "counts": {"recorded": sum(1 for l in lines if l["group"] == "recorded"), "estimated": sum(1 for l in lines if l["group"] == "estimated"), "unpriced": len(unpriced)},
            "selfcheck": _selfcheck(lines), "per_serving": (rec / servings).quantize(CENT, rounding=ROUND_HALF_UP) if servings and servings > 0 else None}


def render(r: Dict) -> str:
    cur = r["currency"]
    out = [f"Cost of {r['title'] or 'the recipe'} (from the prices you recorded; nothing is built in):"]
    for l in r["lines"]:
        if l["group"] == "unpriced":
            out.append(f"- {l['ingredient']}: NOT PRICED - {l['reason']}")
            continue
        e = l["entry"]
        where = f" at {e['store']}" if e["store"] else ""
        age = f", {_age_text(e['age_days'])}" if e["age_days"] >= 1 else ""
        tag = "RECORDED" if l["group"] == "recorded" else "ESTIMATED"
        extra = ("; " + "; ".join(l["notes"])) if l["notes"] else ""
        stale = f"; price is {l['stale']} days old" if l.get("stale") else ""
        out.append(f"- {l['ingredient']}: {money(l['cost'], cur)} [{tag}] using {_per_text(e)}{where}{age}{extra}{stale}")
    out.append(f"Recorded total: {money(r['recorded_total'], cur)} ({r['counts']['recorded']} item(s), no assumptions).")
    if r["counts"]["estimated"]:
        out.append(f"Estimated additions (rely on assumptions or estimated prices, kept separate): {money(r['estimated_total'], cur)} ({r['counts']['estimated']} item(s)).")
    if r["unpriced"]:
        out.append("Not priced, left out of every total: " + ", ".join(l["name"] for l in r["unpriced"]) + ". Tell me, for example, 'price of " + r["unpriced"][0]["name"] + " is 100 per kg' and I'll include it.")
    if r["per_serving"] is not None:
        extra = f"; with the estimated parts {money(((r['recorded_total'] + r['estimated_total']) / r['servings']), cur)}" if r["counts"]["estimated"] else ""
        out.append(f"Per serving ({r['servings']}): recorded {money(r['per_serving'], cur)}{extra}.")
    out.append("Arithmetic double-checked: " + ("yes" if r["selfcheck"] else "NO - the two methods disagreed, do not rely on these totals") + ".")
    return "\n".join(out)


# ------------------------------------------------------------------ sources of ingredients
def _saved_recipe(name: str) -> Optional[Dict]:
    nm = norm_item(name)
    for r in C.q("SELECT * FROM recipes7 ORDER BY ts DESC"):
        if norm_item(r["name"]) == nm or (nm and nm in norm_item(r["name"])):
            ings = parse_ingredients(r["ing"])
            return {"name": r["name"], "servings": r["servings"], "ings": ings}
    try:
        from friday_finance_engine import STATE
        for f in STATE.get("foods", []):
            if isinstance(f, dict) and nm and (norm_item(f.get("name", "")) == nm or nm in norm_item(f.get("name", ""))):
                ings = []
                for i in f.get("ing", []):
                    ings.append({"raw": f"{i.get('q')} {i.get('u')} {i.get('n')}", "qty": _d(i.get("q")) or D(0), "unit": {"pcs": "each"}.get(str(i.get("u", "pcs")).lower(), str(i.get("u", "pcs")).lower()),
                                 "name": str(i.get("n", "")), "norm": norm_item(i.get("n", "")), "ranged": False, "assumed_unit": False})
                return {"name": f.get("name", ""), "servings": None, "ings": [i for i in ings if i["qty"] > 0]}
    except Exception:
        pass
    return None


def save_recipe(name: str, text: str, servings: Optional[int] = None) -> Dict:
    ings = parse_ingredients(text)
    if not ings:
        return {"ok": False, "error": "I couldn't read any ingredients in that"}
    servings = servings or servings_in(text)
    C.x("INSERT INTO recipes7(name,servings,ing,ts) VALUES(?,?,?,?) ON CONFLICT(name) DO UPDATE SET servings=excluded.servings, ing=excluded.ing, ts=excluded.ts",
        (name.strip().lower(), servings, "\n".join(i["raw"] for i in ings), C.now()))
    return {"ok": True, "count": len(ings), "servings": servings}


def tool_cost_recipe(a: Dict) -> Dict:
    text, research, name = str(a.get("text") or ""), str(a.get("research") or ""), str(a.get("name") or "")
    ings, title, serv = [], "", a.get("servings")
    if name:
        s = _saved_recipe(name)
        if s:
            ings, title, serv = s["ings"], s["name"], serv or s["servings"]
    if not ings and text:
        s = _saved_recipe(re.sub(r"^(?:how much (?:does|would|will|is)|what(?:'s| is| does)|cost|price)\s+(?:of\s+)?(?:my\s+|the\s+)?|\s*(?:recipe|dish|meal)?\s*(?:cost|costs)?\??$", "", text, flags=re.I).strip()) if len(text) < 60 else None
        if s and s["ings"]:
            ings, title, serv = s["ings"], s["name"], serv or s["servings"]
    if not ings:
        ings = parse_ingredients(text)
        title = title or "the ingredients you listed"
    if not ings and research:
        ings = parse_ingredients(research, strict=True)
        title = "the recipe in the research"
        serv = serv or servings_in(research)
    if not ings:
        return {"ok": False, "output": "", "error": "I couldn't find an ingredient list with quantities to cost. Give me one (for example '2 cups rice, 1 onion, 3 eggs') or save a recipe first."}
    serv = serv or servings_in(text)
    r = cost_ingredients(ings, int(serv) if serv else None, title)
    priced = r["counts"]["recorded"] + r["counts"]["estimated"]
    out = render(r)
    return {"ok": priced > 0, "output": out, "error": "" if priced else "none of the ingredients has a recorded price yet", "recorded_total": str(r["recorded_total"]), "estimated_total": str(r["estimated_total"]),
            "unpriced": [l["name"] for l in r["unpriced"]], "selfcheck": r["selfcheck"], "currency": r["currency"], "verified": bool(r["selfcheck"]),
            "evidence": "totals recomputed with a second method (exact fractions) and matched" if r["selfcheck"] else "the two calculation methods disagreed"}


# ------------------------------------------------------------------ comparison
_SPLIT_VS = re.compile(r"\s+(?:vs\.?|versus|or|compared (?:to|with)|against)\s+", re.I)
_HEAD = re.compile(r"(?im)^\s*(?:#+\s*|\*\*)?(?:recipe|option|alternative|version|variation)\s*(?:#?\d+|[a-d])?\s*[:.)\-–]*\s*(.*)$")


def _segments(text: str, research: str) -> List[Tuple[str, str]]:
    segs: List[Tuple[str, str]] = []
    body = text
    m = re.search(r"(?:compare|comparison|which is cheaper|cheaper)[^:]*:\s*(.+)$", text, re.I | re.S)
    if m:
        body = m.group(1)
    for src in (body, research):
        if not src:
            continue
        heads = list(_HEAD.finditer(src))
        if len(heads) >= 2:
            for i, h in enumerate(heads):
                end = heads[i + 1].start() if i + 1 < len(heads) else len(src)
                segs.append((h.group(1).strip()[:40] or f"option {i + 1}", src[h.end():end] if not h.group(1) else src[h.start():end]))
            if len(segs) >= 2:
                return segs
        parts = _SPLIT_VS.split(src)
        if len(parts) >= 2 and all(parse_ingredients(p) for p in parts[:2]):
            return [(f"option {i + 1}", p) for i, p in enumerate(parts[:4])]
        segs = []
    return segs


def compare_recipes(items: List[Tuple[str, List[Dict], Optional[int]]]) -> Dict:
    costed = [cost_ingredients(ings, serv, name) for name, ings, serv in items]
    return {"results": costed}


def _priced(r: Dict) -> D:
    return r["recorded_total"] + r["estimated_total"]


def tool_compare_costs(a: Dict) -> Dict:
    text, research = str(a.get("text") or ""), str(a.get("research") or "")
    segs = _segments(text, research)
    items = []
    for name, body in segs:
        s = _saved_recipe(name)
        ings = s["ings"] if s and not parse_ingredients(body) else parse_ingredients(body, strict=body is research)
        if ings:
            items.append((name, ings, servings_in(body)))
    if len(items) < 2:
        # fall back to what can be compared with certainty: the same ingredient at different stores / over time
        names = [i["norm"] for i in parse_ingredients(text + "\n" + research, strict=True)][:8]
        rows = []
        for n in dict.fromkeys(names):
            es = latest_per_store(n)
            if len({e["store"] for e in es}) >= 2:
                es.sort(key=lambda e: e["ppb"])
                rows.append(f"{n}: cheapest at {es[0]['store'] or 'one store'} ({_per_text(es[0])}); {es[-1]['store'] or 'another store'} is {_per_text(es[-1])}.")
        if rows:
            return {"ok": True, "output": "I couldn't find two separate recipes to compare, but from your recorded prices:\n" + "\n".join(rows), "verified": True, "evidence": "differences read directly from recorded prices"}
        return {"ok": False, "output": "", "error": "I need two or more ingredient lists to compare (for example 'compare: 2 cups rice, 1 onion versus 300 g pasta, 2 tomatoes'), or the same item priced at two stores."}
    res = compare_recipes(items)["results"]
    use_serv = all(r["servings"] for r in res)
    basis = "per serving" if use_serv else "total"

    def val(r):
        return (_priced(r) / r["servings"]) if use_serv else _priced(r)

    ranked = sorted(res, key=val)
    out = ["Comparison on your recorded prices (" + basis + "; recorded and estimated parts are shown separately):"]
    for r in ranked:
        cur = r["currency"]
        parts = [f"recorded {money(r['recorded_total'], cur)}"]
        if r["counts"]["estimated"]:
            parts.append(f"estimated {money(r['estimated_total'], cur)}")
        if r["counts"]["unpriced"]:
            parts.append(f"{r['counts']['unpriced']} item(s) NOT priced")
        out.append(f"- {r['title']}: {money(val(r), cur)} {basis} ({', '.join(parts)}" + (f", serves {r['servings']}" if use_serv else "") + ")")
    best, worst = ranked[0], ranked[-1]
    bv, wv = val(best), val(worst)
    if wv > 0 and bv < wv:
        out.append(f"{best['title']} comes out cheapest, {money(wv - bv, best['currency'])} less ({((wv - bv) / wv * 100).quantize(D('1'), rounding=ROUND_HALF_UP)} percent) than {worst['title']}.")
    elif bv == wv:
        out.append("They cost the same on the prices I have.")
    cautions = []
    if any(r["counts"]["unpriced"] for r in res):
        cautions.append("some items have no recorded price, so the ranking could change once they are added")
    if any(r["counts"]["estimated"] for r in res):
        cautions.append("the figures include estimated parts (assumed conversions or prices you marked as estimates)")
    if len({r["currency"] for r in res}) > 1:
        cautions.append("the recipes use different currencies, so the comparison is not reliable")
    if cautions:
        out.append("Caution: " + "; ".join(cautions) + ".")
    ok = all(r["selfcheck"] for r in res)
    return {"ok": True, "output": "\n".join(out), "verified": ok, "evidence": "each total recomputed with a second method" if ok else "calculation methods disagreed", "cheapest": best["title"]}


# ------------------------------------------------------------------ finance engine bridge
def _fin():
    try:
        import friday_finance_engine as FE
        return FE
    except Exception:
        return None


def _grocery_budget() -> Optional[Tuple[D, str]]:
    FE = _fin()
    if not FE:
        return None
    for x in FE.STATE.get("monthly", []):
        if isinstance(x, dict) and re.search(r"groc|food|meal|market|supermarket", str(x.get("n", "")), re.I):
            v = _d(x.get("a"))
            if v is not None:
                return v, str(x.get("n", ""))
    return None


def tool_finance_snapshot(a: Dict) -> Dict:
    FE = _fin()
    if not FE:
        return {"ok": False, "output": "", "error": "the finance records are unavailable"}
    t = FE.totals()
    cur = str(FE.STATE.get("cur", "Rs"))
    gb = _grocery_budget()
    lines = [f"Recorded in your finance records (exact, not recalculated by a model): income {cur} {t['income']:,.2f}; expenses {cur} {t['expenses']:,.2f}; planned monthly spending {cur} {t['planned']:,.2f}; "
             f"savings goals {cur} {t['goals']:,.2f}; monthly surplus {cur} {t['surplus']:,.2f}" + (f"; savings rate {t['savings_rate']} percent" if t["savings_rate"] is not None else "") + "."]
    if gb:
        lines.append(f"Recorded grocery budget: {cur} {gb[0]:,.2f} per month (from '{gb[1]}').")
    else:
        lines.append("No grocery budget is recorded. Say 'monthly plan groceries 30000' to record one.")
    if not t["income"]:
        lines.append("No income is recorded yet, so I can't judge affordability.")
    return {"ok": True, "output": "\n".join(lines), "verified": True, "evidence": "figures read directly from the finance records", "surplus": t["surplus"], "income": t["income"]}


def tool_budget_check(a: Dict) -> Dict:
    text = str(a.get("text") or "")
    m = re.search(r"Recorded total:\s*(?:[A-Za-z₹$£€.]*\s*)?([\d,]+\.\d{2})", text) or re.search(r"(?:total|cost|costs)\D{0,25}?([\d,]+(?:\.\d+)?)", text, re.I)
    amount = _d(m.group(1)) if m else None
    gb = _grocery_budget()
    cur = _cur_default()
    if amount is None:
        return {"ok": False, "output": "", "error": "I couldn't find a cost figure to compare with the budget"}
    if not gb:
        return {"ok": True, "output": f"This comes to {money(amount, cur)} on recorded prices, but no grocery budget is recorded, so I can't compare it. Say 'monthly plan groceries 30000' to record one.", "verified": True, "evidence": "no budget on record"}
    budget, label = gb
    share = (amount / budget * 100).quantize(D("0.1"), rounding=ROUND_HALF_UP) if budget else None
    times = (budget / amount).quantize(D("0.1"), rounding=ROUND_HALF_UP) if amount else None
    out = (f"{money(amount, cur)} is {share} percent of your recorded {label} budget of {money(budget, cur)} per month. "
           f"At these prices the whole monthly budget would cover about {times} such batches. (Assumption: the batch price stays the same.)")
    return {"ok": True, "output": out, "verified": True, "evidence": "budget read from the finance records; percentage computed exactly"}


def cost_weekly_plan() -> Dict:
    """Weekly ingredient quantities from the meal planner x recorded prices."""
    try:
        import friday_food_optimizer as FO
        wt = FO.week_totals()
    except Exception as exc:
        return {"ok": False, "error": f"the meal planner is unavailable: {exc}"}
    ings = []
    for row in wt.get("ingredients", []):
        u = {"pcs": "each"}.get(row["unit"], row["unit"])
        q = _d(round(row["qty"], 4))
        if q and q > 0 and u in UNITS:
            ings.append({"raw": f"{q} {u} {row['name']}", "qty": q, "unit": u, "name": row["name"], "norm": norm_item(row["name"]), "ranged": False, "assumed_unit": False})
    if not ings:
        return {"ok": False, "error": "your weekly meal plan has no ingredient quantities yet"}
    r = cost_ingredients(ings, None, "your weekly meal plan")
    out = render(r)
    gb = _grocery_budget()
    if gb:
        weeks = D("4.345")
        out += f"\nFor scale: your recorded grocery budget is {money(gb[0], r['currency'])} per month, about {money(gb[0] / weeks, r['currency'])} per week (assumption: 4.345 weeks in a month)."
    return {"ok": r["counts"]["recorded"] + r["counts"]["estimated"] > 0, "output": out, "error": "none of the planned ingredients has a recorded price", "verified": r["selfcheck"]}


def install(registry):
    registry.register("cost_recipe", tool_cost_recipe, risk="safe", desc="cost a recipe from recorded prices (recorded / estimated / unpriced kept separate)", post={"nonempty": True}, timeout=20.0, agent="finance")
    registry.register("compare_costs", tool_compare_costs, risk="safe", desc="compare recipes or stores on recorded prices", post={"nonempty": True}, timeout=20.0, agent="finance")
    registry.register("budget_check", tool_budget_check, risk="safe", desc="compare a cost with the recorded grocery budget", post={"nonempty": True}, timeout=10.0, agent="finance")
    registry.register("finance_snapshot", tool_finance_snapshot, risk="safe", desc="exact recorded income, expenses, surplus and grocery budget", post={"nonempty": True}, timeout=10.0, agent="finance")


# ------------------------------------------------------------------ chat
_PRICE_TAIL = re.compile(
    r"^(?P<item>[a-z][a-z' \-]*?)\s*(?:is|costs?|=|:|at|for|now)?\s*(?P<c1>rs\.?|lkr|usd|inr|eur|gbp|[$£€₹])?\s*(?P<price>\d[\d,]*(?:\.\d+)?)\s*(?P<c2>rupees?|rs|lkr|usd|dollars?|eur|euros?|gbp|pounds?|inr)?"
    r"\s*(?:(?:per|a|an|/|for)\s*(?:(?P<qty>\d+(?:\.\d+)?)\s*)?(?P<unit>[a-z]+)|(?P<each>each|apiece))?\s*(?:(?:at|from|in)\s+(?P<store>[a-z][a-z' \-]*?))?\s*(?P<est>\(?\b(?:estimate|estimated|approx\w*|about|roughly)\b\)?)?$", re.I)


def parse_price_statement(text: str) -> Optional[Dict]:
    t = K.strip_wake(text).strip(" .!?")
    t = re.sub(r"^(?:please\s+)?(?:add|record|log|set|save|note|update)\s+(?:the\s+)?(?:new\s+)?price(?:\s+of|\s+for)?[:\s]+", "", t, flags=re.I)
    t = re.sub(r"^(?:please\s+)?(?:the\s+)?price of\s+", "", t, flags=re.I)
    t = re.sub(r"^(?:i (?:paid|bought)|it costs)\s+", "", t, flags=re.I)
    m = _PRICE_TAIL.match(t)
    if not m:
        return None
    unit = (m.group("unit") or ("each" if m.group("each") else "each")).lower()
    if unit not in UNITS:
        if unit in ("kilo",):
            unit = "kg"
        else:
            return None
    est = bool(m.group("est")) or bool(re.search(r"\b(?:estimate|estimated|approx\w*|roughly)\b", text, re.I))
    cur = (m.group("c1") or m.group("c2") or "").lower()
    return {"item": m.group("item").strip(), "price": m.group("price"), "qty": m.group("qty") or "1", "unit": unit, "store": (m.group("store") or "").strip(), "currency": cur, "estimate": est}


_RX_RECORD = re.compile(r"^(?:please\s+)?(?:add|record|log|set|save|note|update)\s+(?:the\s+)?(?:new\s+)?price\b|^(?:please\s+)?(?:the\s+)?price of .+? (?:is|are|now|=)\s*(?:[^\s\d]{1,5}\s*)?\d|^(?:i paid|i bought)\b.*\d.*\b(?:per|for|a|each)\b", re.I)
_RX_COST = re.compile(r"\b(?:cost|costs|price|how much)\b", re.I)


def can_answer(text: str) -> bool:
    t = K.norm_cmd(text)
    return bool(_RX_RECORD.match(t) or re.match(r"^(?:cost|price)\s+(?:this|the|my)\b|^how much (?:does|would|will) (?:this|the|my)\b.*\b(?:recipe|meal|dish|plan)\b|^compare (?:the )?(?:recipes?|costs?|alternatives)\b|^price (?:history|book)\b|^show (?:my )?price book\b", t))


def handle(command: str) -> Optional[str]:
    raw = K.strip_wake(command).strip()
    t = raw.lower().strip(" .!?")
    if not t:
        return None
    if _RX_RECORD.match(t):
        p = parse_price_statement(raw)
        if not p:
            return "I couldn't read that price. Say it like 'price of rice is 60 per kg at Keells'."
        r = record_price(p["item"], p["price"], p["qty"], p["unit"], p["store"], p["currency"], p["estimate"])
        if not r["ok"]:
            return r["error"].capitalize() + "."
        per = r["per"]
        per = "each" if per in ("1 each", "1 piece", "1 pcs") else "per " + (per[2:] if per.startswith("1 ") else per)
        return (f"Recorded: {r['item']} at {money(r['price'], r['currency'])} {per}"
                + (f" at {r['store']}" if r["store"] else "") + (" (marked as an estimate)" if r["kind"] == "estimate" else "") + ".")
    m = re.match(r"^(?:what(?:'s| is) )?(?:the )?(?:recorded )?price of (.+?)(?: (?:now|today|currently))?$", t) or re.match(r"^how much (?:is|are|does|do) (.+?) (?:cost|costing)?(?: right now)?$", t)
    if m and not re.search(r"\b(?:recipe|meal|dish|plan)\b", m.group(1)):
        es = latest_per_store(m.group(1))
        if not es:
            # only claim the question when the user clearly means their own price book; otherwise leave it to the live price / shopping lanes (bitcoin, gold, a product ...)
            if re.search(r"\brecorded\b|\bmy\b|\bprice book\b", t):
                return f"I have no recorded price for {m.group(1)}. Say 'price of {m.group(1)} is 100 per kg' to record one."
            return None
        es.sort(key=lambda e: e["ppb"])
        return f"{m.group(1).capitalize()}: " + "; ".join(f"{_per_text(e)}" + (f" at {e['store']}" if e["store"] else "") + f" ({_age_text(e['age_days'])}{', estimate' if e['kind'] == 'estimate' else ''})" for e in es[:4]) + "."
    m = re.match(r"^(?:price history|history of the price|how has the price)(?: of| for)?\s*(.+?)(?: changed)?$", t) or re.match(r"^has (.+?) (?:got|become|gotten) (?:more )?expensive$", t)
    if m:
        h = history(m.group(1))
        if not h["ok"]:
            return (h["error"] + ".") if re.search(r"\brecorded\b|\bmy\b|\bprice book\b", t) else None
        cur = h["last"]["currency"]
        parts = [f"{h['count']} recorded price(s) for {m.group(1)}", f"latest {_per_text(h['last'])}"]
        if h["count"] >= 2:
            parts.append(f"lowest {_per_text(h['low'])}, highest {_per_text(h['high'])}")
            if h["change_pct"] is not None:
                parts.append(f"{'up' if h['change_pct'] > 0 else 'down' if h['change_pct'] < 0 else 'unchanged'} {abs(h['change_pct'])} percent since the first record (same unit)")
        else:
            parts.append("one record isn't enough to show a trend")
        return ", ".join(parts) + "."
    m = re.match(r"^(?:forget|delete|remove|clear)\s+(?:the\s+)?(?:recorded\s+)?prices?\s+(?:of|for)\s+(.+)$", t)
    if m:
        n = forget_price(m.group(1))
        return f"Removed {n} recorded price(s) for {m.group(1)}." if n else f"I had no recorded price for {m.group(1)}."
    if re.match(r"^(?:show|list|what(?:'s| is) in) (?:my |the )?price book$|^what prices do you have$", t):
        rows = C.q("SELECT norm, COUNT(*) c, MAX(ts) t FROM prices7 GROUP BY norm ORDER BY t DESC LIMIT 12")
        if not rows:
            return "The price book is empty. Tell me prices like 'price of rice is 60 per kg' and I'll use them for costing."
        return "Price book: " + ", ".join(f"{r['norm']} ({r['c']})" for r in rows) + "."
    m = re.match(r"^(?:save|add|remember) (?:the |my )?recipe\s+(.+?)\s*[:\-]\s*(.+)$", raw, re.I)
    if m:
        r = save_recipe(m.group(1), m.group(2))
        return f"Saved the recipe {m.group(1)} with {r['count']} ingredients" + (f" for {r['servings']} servings" if r.get("servings") else "") + "." if r["ok"] else r["error"].capitalize() + "."
    if re.match(r"^(?:what does|how much (?:does|will|would)) (?:my |the )?(?:weekly |week's )?(?:meal plan|weekly plan|meals)(?: for the week)? cost\??$|^cost (?:my |the )?(?:weekly )?meal plan$", t):
        r = cost_weekly_plan()
        return r["output"].replace("\n", " ") if r.get("output") and r.get("ok") else (r.get("error") or r.get("output") or "I couldn't cost the plan").capitalize() + "."
    m = re.match(r"^(?:cost|price)\s+(?:this |the |my )?(?:recipe|meal|dish|ingredients?)?\s*[:,\-]?\s*(.+)$", raw, re.I) or re.match(r"^how much (?:does|would|will) (?:this|the|my)\s+(?:(.+?)\s+)?(?:recipe|meal|dish)\s*[:,\-]?\s*(.*?)\s*cost\??$", raw, re.I) \
        or re.match(r"^what does (?:my |the )?(.+?) (?:recipe |dish )?cost\??$", raw, re.I)
    if m and not re.match(r"^(?:cost|price)\s+(?:history|book)\b", t):
        body = " ".join(g for g in m.groups() if g) if m.re.pattern.startswith("^how much") else (m.group(1) or "")
        r = tool_cost_recipe({"text": body, "name": body if len(body) < 40 and not parse_ingredients(body) else ""})
        return (r["output"].replace("\n", " ") if r.get("ok") or r.get("output") else r["error"]) if r.get("output") or r.get("error") else "I couldn't cost that."
    m = re.match(r"^compare (?:the )?(?:recipes?|costs?|alternatives)\s*[:,\-]?\s*(.+)$", raw, re.I)
    if m:
        r = tool_compare_costs({"text": "compare: " + m.group(1)})
        return r["output"].replace("\n", " ") if r.get("ok") else r["error"]
    if re.match(r"^(?:check|compare)\s+(?:this|that|it)\s+(?:with|against|to)\s+(?:my\s+)?(?:grocery )?budget$|^is (?:this|that|it) within (?:my\s+)?(?:grocery )?budget$", t):
        return None            # needs the previous result: handled inside a mission (budget_check step)
    return None


def ui_snapshot() -> Dict:
    rows = C.q("SELECT * FROM prices7 ORDER BY ts DESC LIMIT 60")
    return {"prices": [{"id": r["id"], "item": r["norm"], "price": r["price"], "per": f"{r['qty']} {r['unit']}", "currency": r["currency"], "store": r["store"], "kind": r["kind"], "when": C.iso(r["ts"])} for r in rows],
            "recipes": [{"name": r["name"], "servings": r["servings"]} for r in C.q("SELECT name,servings FROM recipes7 ORDER BY ts DESC LIMIT 20")]}


def handle_ui(req: Dict) -> Optional[Dict]:
    a = req.get("action")
    if a == "price_add":
        return record_price(str(req.get("item", "")), req.get("price", ""), req.get("qty", "1"), str(req.get("unit", "each")), str(req.get("store", "")), str(req.get("currency", "")), bool(req.get("estimate")))
    if a == "price_delete":
        C.x("DELETE FROM prices7 WHERE id=?", (int(req.get("id", 0)),))
        return {"ok": True}
    if a == "cost_recipe":
        r = tool_cost_recipe({"text": str(req.get("text", "")), "name": str(req.get("name", ""))})
        return {"ok": r["ok"], "output": r.get("output", ""), "error": r.get("error", "")}
    return None
