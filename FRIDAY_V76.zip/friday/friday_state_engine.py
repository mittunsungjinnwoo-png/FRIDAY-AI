"""
FRIDAY UNIFIED STATE ENGINE
---------------------------
Implements the "One unified state engine" recommendation from the
V3086 architecture research (FRIDAY STATE: user / conversation /
environment / screen / applications / memory / goals / tasks /
agents / permissions / system_health).

This module is 100% ADDITIVE. It does not import, modify, or depend
on any existing friday_*.py file, so it cannot break anything that
already works. It gives every other new module (executive, verifier,
supervisor, perception, memory layers, proactive monitor) a single
shared place to read and write context instead of each one keeping
its own private, disconnected copy of "what's going on right now".

Design goals (matching the rest of this codebase's conventions):
- pure stdlib, no new dependencies
- thread-safe
- crash-safe atomic JSON persistence (write to .tmp then os.replace)
- every public function is defensive: it never raises on bad input
  and never lets a persistence failure break the caller
"""

from __future__ import annotations

import copy
import json
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

STATE_FILE = Path(__file__).with_name("friday_unified_state.json")

# The canonical sections described in the research doc's
# "13. One unified state engine" section.
_DEFAULT_STATE: dict[str, Any] = {
    "user": {},           # preferences / habits / who is talking to Friday
    "conversation": {},   # current turn, last command, last response
    "environment": {},    # active_application, active_window, time, etc.
    "screen": {},         # last screen observation summary
    "applications": {},   # known-open apps / windows
    "memory": {},         # pointers/summary, not the memory content itself
    "goals": {},          # goal_id -> goal record
    "tasks": {},          # task_id -> task record (mirrors friday_task_graph)
    "agents": {},         # agent_name -> {status, last_used, health}
    "permissions": {      # proactive permission boundaries (see doc section 8/10)
        "default_tier": "ask",
        "overrides": {},   # action_name -> "safe" | "low_risk" | "high_impact"
    },
    "system_health": {
        "last_error": None,
        "last_error_ts": None,
        "started_at": time.time(),
    },
    "updated_at": 0.0,
}

_lock = threading.RLock()
_state: dict[str, Any] = copy.deepcopy(_DEFAULT_STATE)
_subscribers: list[Callable[[str, dict[str, Any]], None]] = []


def _load() -> None:
    global _state
    try:
        if STATE_FILE.exists():
            raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                with _lock:
                    merged = copy.deepcopy(_DEFAULT_STATE)
                    for key, value in raw.items():
                        merged[key] = value
                    _state = merged
    except Exception:
        # Corrupt or missing state file: start clean rather than crash.
        pass


def _save() -> None:
    try:
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_state, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        os.replace(tmp, STATE_FILE)
    except Exception:
        pass


_load()


def subscribe(callback: Callable[[str, dict[str, Any]], None]) -> None:
    """Register a best-effort listener called as (section, new_value) on every update.

    Listener exceptions are swallowed so one broken subscriber can never
    take down the state engine or any other subscriber.
    """
    with _lock:
        _subscribers.append(callback)


def _notify(section: str, value: dict[str, Any]) -> None:
    for cb in list(_subscribers):
        try:
            cb(section, value)
        except Exception:
            pass


def get(section: Optional[str] = None) -> Any:
    """Read a section (deep copy) or, with no argument, the whole state."""
    with _lock:
        if section is None:
            return copy.deepcopy(_state)
        return copy.deepcopy(_state.get(section))


def update(section: str, **fields: Any) -> dict[str, Any]:
    """Shallow-merge `fields` into `section` (creating it if needed).

    Returns the resulting section (deep copy). Unknown top-level
    sections are created on the fly so new modules can carve out their
    own namespace without editing this file.
    """
    with _lock:
        current = _state.get(section)
        if not isinstance(current, dict):
            current = {}
        current.update(fields)
        _state[section] = current
        _state["updated_at"] = time.time()
        _save()
        snapshot = copy.deepcopy(current)
    _notify(section, snapshot)
    return snapshot


def replace(section: str, value: Any) -> Any:
    """Overwrite a whole section with `value` (any JSON-serialisable type)."""
    with _lock:
        _state[section] = value
        _state["updated_at"] = time.time()
        _save()
        snapshot = copy.deepcopy(value)
    _notify(section, snapshot if isinstance(snapshot, dict) else {"value": snapshot})
    return snapshot


def upsert_item(section: str, item_id: str, **fields: Any) -> dict[str, Any]:
    """Merge `fields` into `state[section][item_id]`, e.g. tasks/goals/agents maps."""
    with _lock:
        table = _state.get(section)
        if not isinstance(table, dict):
            table = {}
        entry = table.get(item_id)
        if not isinstance(entry, dict):
            entry = {}
        entry.update(fields)
        entry["updated_at"] = time.time()
        table[item_id] = entry
        _state[section] = table
        _state["updated_at"] = time.time()
        _save()
        snapshot = copy.deepcopy(entry)
    _notify(f"{section}.{item_id}", snapshot)
    return snapshot


def get_item(section: str, item_id: str) -> Optional[dict[str, Any]]:
    with _lock:
        table = _state.get(section)
        if isinstance(table, dict):
            item = table.get(item_id)
            return copy.deepcopy(item) if item is not None else None
    return None


def permission_tier_for(action_name: str) -> str:
    """Look up a proactive permission override, defaulting to 'ask'.

    Valid tiers: 'safe' (auto), 'low_risk' (auto + notify),
    'high_impact' (ask first). See friday_supervisor.classify_risk for
    the heuristic that fills these in automatically when no explicit
    override has been set by the user.
    """
    with _lock:
        perms = _state.get("permissions", {})
        overrides = perms.get("overrides", {}) if isinstance(perms, dict) else {}
        return overrides.get(action_name) or perms.get("default_tier", "ask")


def set_permission_tier(action_name: str, tier: str) -> None:
    if tier not in ("safe", "low_risk", "high_impact", "ask"):
        return
    with _lock:
        perms = _state.get("permissions")
        if not isinstance(perms, dict):
            perms = {"default_tier": "ask", "overrides": {}}
        overrides = perms.setdefault("overrides", {})
        overrides[action_name] = tier
        _state["permissions"] = perms
        _save()


def record_error(message: str) -> None:
    with _lock:
        health = _state.get("system_health", {})
        if not isinstance(health, dict):
            health = {}
        health["last_error"] = str(message)[:2000]
        health["last_error_ts"] = time.time()
        _state["system_health"] = health
        _save()


def snapshot() -> dict[str, Any]:
    """Full deep-copied state, safe to serialise/log/inspect."""
    with _lock:
        return copy.deepcopy(_state)


def reset(section: Optional[str] = None) -> None:
    """Testing/recovery helper: reset one section or the entire state to defaults."""
    global _state
    with _lock:
        if section is None:
            _state = copy.deepcopy(_DEFAULT_STATE)
        else:
            _state[section] = copy.deepcopy(_DEFAULT_STATE.get(section, {}))
        _save()
