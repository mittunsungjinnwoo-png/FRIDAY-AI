# FRIDAY V7.3 - adaptive strategy, one mission front door, memory freshness, wider benchmark

Built on V7.2 as a thin layer over the modules you already have (router7, planner7, orchestrator7, verify7, policy7, memory7, critic7, bench7).
No planner was rewritten. Listening, speaking, wake word, vision, UI and finance/food features are untouched.
Only two existing files changed: `friday_core7.py` (3 modules registered, one memory-caution line in the prompt) and `friday_bench7.py` (new areas and baseline compare).

## New files
| File | What it does |
|---|---|
| `friday_strategy73.py` | **Upgrade 01.** `select()` picks handler (local / model / research / mission / computer / approval), route, model order and verification strategy per request. `call()` runs a model with a per-request and per-day token budget, fallback across models, latency log, an output-quality score, and one bounded escalation to the next model when the answer scores badly. `compare()` runs a fixed task set against every available model; `reorder()` then uses MEASURED quality (after 5 samples) to order the models router7 already approved - it can never add a model router7 rejected, so private requests stay local-only. `feedback()` teaches router7's small classifier (no retraining). |
| `friday_mission73.py` | **Upgrade 02 + the timing split in 4.** `run(request, context)` (and `ahandle`, `FridayMissionEngine`) = classify -> local answer / approval gate / model answer / planned mission -> verify -> store only verified outcomes -> return `{status, verified, answer, limitations, timings}`. Reuses `planner7.make_plan` and `orchestrator7.submit` (parallel layers, per-step policy approvals, retries, alternatives, checkpoints). Keeps **first response, first audio, completion, verified success** as separate numbers (`metrics()`). |
| `friday_memory73.py` | **Upgrade 03 (the missing part).** memory7 already had source, timestamp, confidence, supersession, correct and forget. This adds fresh / aging / stale / flagged per item (age vs the half-life of its kind; prices, deadlines and schedules go stale faster), a dated phrase ("As of 12 Mar 2026 (may be out of date): ..."), a stale-items list, and a one-line caution added to the model prompt. Nothing is changed or deleted automatically. |
| `FRIDAY_TEST_V73.py` | Runs the new benchmark areas and the full suite. |

## Benchmark (friday_bench7.py): 36 -> 54 checks, 7 -> 11 areas
New areas: `strategy` (7), `mission` (6), `safety` (3), `eval` (2).
- request kinds go to the right handler; informational questions ("what does format mean") are not mistaken for actions; "in order to" / "pay attention" do not trigger approval
- a bad first answer escalates once; a crashing model falls back; oversize requests and an exhausted daily budget call no model
- measured quality reorders models without adding any; model comparison ranks a good model above a weak one
- local answers need no model/job; consequential requests stop at the gate and **no tool runs**; a tool that lies is a failed, NOT-verified mission; unexecuted code and uncited research are never "verified"
- private request with no local model is blocked, not sent to the cloud
- baseline comparison: `python friday_bench7.py --pin-baseline` (or say "pin the benchmark baseline") fixes a passing run; every later full run reports regressions, new failures, fixes and slowdowns against it
The new cases were mutation-checked: breaking the approval gate, the reordering or the verified flag makes them fail.

## New spoken/typed commands
"what strategy would you use for <request>", "token usage", "speed report" / "how fast are you", "what do you remember that might be outdated", "pin the benchmark baseline".

## New settings (Settings store, defaults shown)
`token_budget_request` 6000, `token_budget_day` 400000 (estimated tokens), `quality_escalate_below` 0.45, `strategy_min_samples` 5.

## Honest limits
- Token counts are estimates (characters / 3.6), not provider-billed usage.
- Quality scores are cheap deterministic checks (empty, error text, short reasoning answer, code that does not parse, wrong arithmetic). They catch obvious failures; they cannot prove an answer correct.
- `mark_first_audio()` exists, but I did not hook it into the voice engine (you asked that the speaking code stay untouched), so "first audio" shows as not measured until you call it from the point where audio actually starts.
- Comparing against external assistants needs your API keys: `compare(models=[...])` uses whichever providers are registered; none are called in tests (fake models only).
- Vision / computer-use / sandboxed-test strategies are routed and gated here; the doing is still computer7, policy7 and the existing agents.

## Verified
`python friday_bench7.py` 54/54, `FRIDAY_TEST_V73.py` pass, `FRIDAY_TEST_V70.py` 63/63, `FRIDAY_SMOKE_TEST.py` pass, `friday_ci7.py gate` pass.
(`FRIDAY_TEST_V72_FAST_HUMAN.py` imports the full backend and needs `speech_recognition` installed - it could not run in my sandbox; backend is unchanged.)
