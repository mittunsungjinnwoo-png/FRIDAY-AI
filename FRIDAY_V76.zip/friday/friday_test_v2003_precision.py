import importlib, platform

def main():
    print("V2003 precision integration test")
    import friday_desktop_agent as d
    import friday_v96_runtime as r
    print("Windows:", platform.system()=="Windows")
    print("UIA module:", importlib.import_module("friday_uia") is not None)
    print("UIA available:", d.uia_available())
    print("Playwright import:", d.playwright_available())
    r._register_defaults()
    names=[x["name"] for x in r.tool_catalog()]
    required=["vision.screen","windows.uia","windows.uia.inspect","browser.playwright","desktop.control","filesystem.control"]
    for n in required: print(n, "PASS" if n in names else "SKIP/FAIL")
    print("Tool count:",len(names))
if __name__=="__main__": main()
