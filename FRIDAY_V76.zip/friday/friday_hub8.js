/* FRIDAY 7.0 - Settings & Features hub (new HUD).
   Cards -> pages. Every old page (Finance, Calendar, Files, Web, Tools, Command Centre, Intelligence ...) now lives
   behind a card here, together with the customisation tabs from friday_settings.js. Needs friday_ui8.js first. */
(function () {
  'use strict';
  const F8 = window.F8, T = window.Theme, B = window.fridayBridge || null;
  if (!F8) { console.error('friday_hub8.js needs friday_ui8.js'); return; }
  const $ = s => document.querySelector(s), $$ = (s, r) => Array.prototype.slice.call((r || document).querySelectorAll(s));
  const E = F8.E, svg = F8.svg, p2 = F8.p2, PG = F8.PG;
  const SET = () => window.FridaySet;

  /* ------------------------------------------------------------ card art (bottom right of each card) */
  const ART = {
    voice: () => { let b = ''; for (let i = 0; i < 24; i++) { const h = 6 + (i / 23) * 54 * (.35 + .65 * Math.abs(Math.sin(i * 2.3 + 1))); b += '<rect x="' + (i * 7) + '" y="' + (76 - h).toFixed(1) + '" width="2.6" height="' + h.toFixed(1) + '" rx="1.3"/>'; } return '<svg viewBox="0 0 168 80" fill="currentColor" opacity=".85">' + b + '</svg>'; },
    ai: () => '<svg viewBox="0 0 120 100" fill="none" stroke="currentColor" stroke-width="1" opacity=".55"><circle cx="70" cy="56" r="30"/><circle cx="70" cy="56" r="19" stroke-dasharray="3 4"/><circle cx="70" cy="56" r="4" fill="currentColor"/><path d="M70 26v12M70 74v12M40 56h12M88 56h12M49 35l8 8M91 77l8 8M91 35l-8 8M49 77l8-8"/><circle cx="70" cy="22" r="2.4" fill="currentColor"/><circle cx="102" cy="56" r="2.4" fill="currentColor"/><circle cx="38" cy="56" r="2.4" fill="currentColor"/><circle cx="70" cy="90" r="2.4" fill="currentColor"/></svg>',
    vision: () => '<svg viewBox="0 0 120 100" fill="none" stroke="currentColor" opacity=".6"><circle cx="72" cy="58" r="30" stroke-width="3"/><circle cx="72" cy="58" r="20" stroke-width="2"/><circle cx="72" cy="58" r="10" stroke-width="2" fill="currentColor" fill-opacity=".25"/><path d="M72 20v8M72 88v8M34 58h8M102 58h8" stroke-width="1.5"/><path d="M22 96l14-20h20" stroke-width="1"/><circle cx="22" cy="96" r="2" fill="currentColor"/></svg>',
    tasks: () => '<svg viewBox="0 0 130 100" fill="none" stroke="currentColor" stroke-width="1.6" opacity=".85"><rect x="6" y="8" width="44" height="40" rx="4"/><path d="M6 20h44M16 8V2M40 8V2M14 29h6M24 29h6M34 29h6M14 38h6M24 38h6"/><rect x="62" y="8" width="44" height="40" rx="4" opacity=".4"/><path d="M62 20h44" opacity=".4"/><rect x="6" y="56" width="44" height="40" rx="4"/><path d="M6 68h44M16 56v-6M40 56v-6M14 78h6M24 78h6M34 78h6"/><rect x="62" y="56" width="44" height="40" rx="4"/><path d="M73 77l7 7 14-15" stroke-width="2.4"/></svg>',
    memory: () => '<svg viewBox="0 0 90 110" fill="none" stroke="currentColor" stroke-width="1.6" opacity=".85"><ellipse cx="45" cy="18" rx="30" ry="10" fill="currentColor" fill-opacity=".18"/><path d="M15 18v22c0 5.5 13.4 10 30 10s30-4.5 30-10V18"/><path d="M15 40v22c0 5.5 13.4 10 30 10s30-4.5 30-10V40"/><path d="M15 62v22c0 5.5 13.4 10 30 10s30-4.5 30-10V62"/></svg>',
    appearance: () => '<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" opacity=".9"><circle cx="52" cy="54" r="30" stroke-width="5" stroke-dasharray="120 70" stroke-linecap="round"/><circle cx="52" cy="54" r="30" stroke-width="1.2" opacity=".5"/><circle cx="52" cy="54" r="21" stroke-width="1" stroke-dasharray="2 5" opacity=".6"/></svg>'
  };

  /* ------------------------------------------------------------ pages */
  const set = (tab) => (e) => { window.V = 'Settings'; SET().render(e, tab); };
  const legacy = (name, fn) => (e) => { window.V = name; const f = window[fn]; if (typeof f === 'function') f(e); else e.innerHTML = '<p class="note">This page is not available in this build.</p>'; };
  const CARDS = [
    { id: 'voice', t: 'Voice & Audio', d: 'Wake word, voice settings, listening & speaking behaviour.', cl: '', ic: 'mic', main: 1, kw: 'microphone wake word sensitivity speak listen talk sound volume',
      tabs: [{ id: 'voice', l: 'Voice', draw: set('Voice'), kw: 'wake word sensitivity conversation window interrupt barge in' }, { id: 'sounds', l: 'Sounds', draw: set('Sounds'), kw: 'interface sounds clicks chime test' }] },
    { id: 'ai', t: 'AI & Model', d: 'API keys, model selection, reasoning and fallback settings.', cl: 'violet', ic: 'brain', main: 1, kw: 'gemini api key model assistant name greeting address profile',
      tabs: [{ id: 'conn', l: 'AI Connection', draw: set('AI'), kw: 'api key gemini model test connection uninstall' }, { id: 'asst', l: 'Assistant', draw: set('Assistant'), kw: 'address sir madam greeting name tagline' }, { id: 'prof', l: 'Profile', draw: set('Profile'), kw: 'name badge greeting hashik' }] },
    { id: 'vision', t: 'Vision & Camera', d: 'Camera controls, vision features, object detection and more.', cl: 'teal', ic: 'camera', main: 1, kw: 'camera screen vision object detection live feed',
      tabs: [{ id: 'live', l: 'Vision Hub', draw: legacy('Vision', 'visionV'), kw: 'live agent evaluation camera' }, { id: 'vset', l: 'Vision Settings', draw: set('Vision'), kw: 'camera device resolution privacy detect' }] },
    { id: 'tasks', t: 'Tasks & Automation', d: 'Automate tasks, schedules, shortcuts and workflows.', cl: 'orange', ic: 'bolt', main: 1, kw: 'tasks agents schedule planner routine todo workflow automation classes',
      tabs: [{ id: 'day', l: 'My Day', draw: (e) => dayView(e), kw: 'today tasks schedule classes tuition planner' }, { id: 'agents', l: 'Tasks & Agents', draw: legacy('Tasks', 'tasksV'), kw: 'run task agent research action log' }] },
    { id: 'memory', t: 'Memory', d: 'Save, manage and recall important information.', cl: 'purple', ic: 'db', main: 1, kw: 'remember forget memories knowledge',
      tabs: [{ id: 'mem', l: 'Memory', draw: legacy('Memory', 'memV'), kw: 'remember forget temporary long-term' }] },
    { id: 'appearance', t: 'Appearance', d: 'Theme, UI style, animations and display settings.', cl: 'pink', ic: 'brush', main: 1, kw: 'theme colour color reactor effects layout widget customization customisation look font',
      tabs: [{ id: 'themes', l: 'Themes', ic: 'brush', draw: set('Appearance'), kw: 'colour accent background preset font neon glass' }, { id: 'lab', l: 'Reactor Lab', ic: 'reactor', draw: set('Reactor'), kw: 'arc reactor rings emblem orbit beam platform core' }, { id: 'fx', l: 'Effects', ic: 'sparkle', draw: set('Effects'), kw: 'neon scanlines parallax grid boot icons animation' }, { id: 'home', l: 'Home Screen', ic: 'home', draw: set('Home'), kw: 'tasks schedule tiles chips quote right column conversation' }, { id: 'widget', l: 'Widget', ic: 'layers', draw: set('Widget'), kw: 'floating widget orb command bar' }, { id: 'layout', l: 'Layout', ic: 'grid', draw: set('Layout'), kw: 'sidebar cards size zoom hidden' }] },
    /* more features */
    { id: 'finance', t: 'Finance', d: 'Money, food, plans and savings.', cl: 'green', ic: 'wallet', kw: 'money budget savings meal plan income expense reports currency',
      tabs: [{ id: 'fin', l: 'Finance', draw: legacy('Finance', 'finV'), kw: 'income expense goals food' }, { id: 'plans', l: 'Meal Plan', draw: legacy('Plans', 'plans'), kw: 'weekly meals ingredients' }, { id: 'rep', l: 'Reports', draw: legacy('Reports', 'reports'), kw: 'savings weekly report' }] },
    { id: 'calendar', t: 'Calendar', d: 'Events, reminders and dates.', cl: 'orange', ic: 'calendar', kw: 'events reminders dates appointment',
      tabs: [{ id: 'cal', l: 'Calendar', draw: legacy('Calendar', 'calV'), kw: 'event add date time' }] },
    { id: 'files', t: 'Files & Media', d: 'Files, tables and images.', cl: '', ic: 'folder', kw: 'files upload csv pdf images multimedia analyse',
      tabs: [{ id: 'files', l: 'Files', draw: legacy('Files', 'filesV'), kw: 'upload analyse csv' }, { id: 'media', l: 'Multimedia', draw: legacy('Multimedia', 'mediaV'), kw: 'images pictures' }] },
    { id: 'web', t: 'Web & Research', d: 'Search, compare and write reports.', cl: 'teal', ic: 'globe', kw: 'internet research search report',
      tabs: [{ id: 'web', l: 'Research', draw: legacy('Web', 'webV'), kw: 'search compare report' }] },
    { id: 'tools', t: 'Tools & Metrics', d: 'Tool use, speed and success rates.', cl: 'violet', ic: 'sliders', kw: 'metrics latency success rate audit tools',
      tabs: [{ id: 'tools', l: 'Tools', draw: legacy('Tools', 'toolsV'), kw: 'metrics latency permissions' }] },
    { id: 'centre', t: 'Command Centre', d: 'Live panels, agents and automation.', cl: 'purple', ic: 'cpu', kw: 'command centre center v6 snapshot panels',
      tabs: [{ id: 'centre', l: 'Command Centre', draw: legacy('Centre', 'centre6V'), kw: 'panels agents' }] },
    { id: 'intel', t: 'Intelligence', d: 'Goals, evidence, savings and insight.', cl: 'pink', ic: 'target', kw: 'goals evidence savings graph v7 intelligence',
      tabs: [{ id: 'intel', l: 'Intelligence', draw: legacy('Intel', 'intel7V'), kw: 'goals evidence savings graph' }] },
    { id: 'general', t: 'General & Privacy', d: 'Currency, permissions, backup and reset.', cl: 'red', ic: 'shield', kw: 'currency permissions erase data backup export import reset privacy security',
      tabs: [{ id: 'gen', l: 'General', draw: set('General'), kw: 'currency permissions erase data backup export import reset look' }] }
  ];
  const CARD = {}; CARDS.forEach(c => CARD[c.id] = c);
  const hidden = () => (T.cfg.layout.hiddenNav || []);
  const visible = () => CARDS.filter(c => hidden().indexOf(c.id) < 0);

  const MODES = {
    productivity: ['Productivity Mode', 'bolt', 'Ideas today, results tomorrow.', 'FRIDAY is ready. Your assistant, your rules.'],
    study: ['Study Mode', 'book', 'Small steps, every day.', 'Study mode is on. FRIDAY keeps revision short and clear.'],
    focus: ['Focus Mode', 'focus', 'Discipline today. Freedom tomorrow.', 'Focus mode is on. One task at a time.'],
    creative: ['Creative Mode', 'sparkle', 'Make something only you could make.', 'Creative mode is on. Bring the wild ideas.'],
    relax: ['Relax Mode', 'moon', 'Rest is part of the plan.', 'Relax mode is on. Slow down, FRIDAY has it.']
  };
  const mode = () => MODES[X.mode] ? X.mode : 'productivity';

  F8.hub = { cardList: () => CARDS.map(c => [c.id, c.t]) };

  /* ------------------------------------------------------------ rendering */
  function artFor(c) { return ART[c.id] ? '<div class="art">' + ART[c.id]() + '</div>' : ''; }
  function cardHTML(c) {
    const tone = { green: '#27e0a1', red: '#ff5c8a' }[c.cl];
    return '<button class="hud clk card8 ' + (c.main ? '' : 'mini ') + c.cl + '" data-h="card:' + c.id + '" title="Open ' + E(c.t) + '"><span class="ri">' + F8.ring('var(--c1)') + svg(c.ic, 'ic') + '</span><span class="ct"><b>' + E(c.t) + '</b><span>' + E(c.d) + '</span></span>' + svg('chev', 'chv') + (c.main ? artFor(c) : '') + '</button>';
  }
  function renderHubMain() {
    const v = visible(), main = v.filter(c => c.main), more = v.filter(c => !c.main);
    $('#hubscroll').innerHTML = '<div class="cards">' + main.map(cardHTML).join('') + '</div>' + (more.length ? '<div class="moreh">More features</div><div class="cards">' + more.map(cardHTML).join('') + '</div>' : '') + (hidden().length ? '<p class="note" style="text-align:center;margin:1rem 0 .4rem">' + hidden().length + ' card(s) hidden. Use search (Ctrl + K) or Appearance › Layout to show them again.</p>' : '');
  }
  function infoBar() {
    const el = $('#infobar'); if (!el) return;
    const m = MODES[mode()], cam = (() => { try { const s = window.FridayVision.state.session; return !!(s && s.running && s.kind === 'camera'); } catch (e) { return false; } })();
    const vmodeV = (typeof vmode !== 'undefined') ? vmode : 'active';
    const voice = !B ? 'Preview' : (typeof micOk !== 'undefined' && micOk === false) ? 'Unavailable' : vmodeV === 'standby' ? 'Standby' : 'Active';
    const mems = X.mem.length, mini = [
      ['mic', 'Voice', voice, voice === 'Active' ? 'on' : 'no', 'go:voice'],
      ['camera', 'Camera', cam ? 'On' : 'Off', cam ? 'on' : 'no', 'cam'],
      ['db', 'Memory', 'Enabled', 'on', 'go:memory'],
      ['layers', 'Model', modelShort(), 'on', 'go:ai']
    ];
    const html = '<div class="ib1"><span class="brn">' + F8.ring('var(--a)') + svg('brain', 'ic') + '</span><div class="mt"><h5>Current Mode &amp; Quick Info <button class="modep" data-h="modemenu">' + svg(m[1]) + m[0] + '</button></h5><p>' + E(m[3]) + '</p></div></div>' +
      '<div class="qt8"><q>' + E(m[2]) + '</q><small>— ' + E(T.cfg.assistant.name || 'FRIDAY') + '</small></div>' +
      '<div class="mini8">' + mini.map(b => '<button class="hud clk mb8" data-h="' + b[4] + '"><span class="mi">' + svg(b[0]) + '</span><div><b>' + b[1] + '</b><span class="' + b[3] + '">' + E(b[2]) + '</span></div>' + svg('chev', 'chv') + '</button>').join('') + '</div>' +
      '<div class="modemenu" id="modemenu">' + Object.keys(MODES).map(k => '<button class="' + (k === mode() ? 'on' : '') + '" data-h="mode:' + k + '">' + svg(MODES[k][1]) + MODES[k][0] + '</button>').join('') + '</div>';
    if (el.__h !== html) { const open = $('#modemenu') && $('#modemenu').classList.contains('on'); el.__h = html; el.innerHTML = html; if (open) $('#modemenu').classList.add('on'); }
  }
  function modelShort() { let m = (window.__fridayModel || 'gemini-3.1-flash-lite'); m = String(m).replace(/^models\//, '').replace(/[-_]+/g, ' ').replace(/\b([a-z])/g, c => c.toUpperCase()).replace(/(\d) (\d)/g, '$1.$2'); return m; }

  function headHTML() {
    const sub = !!PG.cat, c = CARD[PG.cat];
    return '<button class="hud clk backb" data-h="back">' + svg('back') + 'Back</button><div class="ht"><h2>' + (sub ? E(c.t) : 'Settings &amp; Features') + '</h2><p>' + (sub ? E(c.d) : 'Configure FRIDAY to work the way you want.') + '</p></div>' +
      '<div class="sbox" id="sbox">' + svg('search') + '<input id="hs" placeholder="Search settings..." autocomplete="off" spellcheck="false"><kbd>Ctrl + K</kbd><div id="sres"></div></div>';
  }
  function renderHead() {
    const el = $('#hubhead'), h = headHTML(); const q = $('#hs') ? $('#hs').value : '', had = document.activeElement && document.activeElement.id === 'hs';
    if (el.__h === h) return; el.__h = h; el.innerHTML = h; wireSearch(); if ($('#hs')) { $('#hs').value = q; if (had) $('#hs').focus(); }
  }

  /* ------------------------------------------------------------ pages inside a card */
  function showMain() {
    PG.cat = null; PG.tab = null; window.V = 'Settings';
    $('#hubscroll').style.display = ''; $('#infobar').style.display = ''; $('#subw').style.display = 'none';
    renderHead(); renderHubMain(); infoBar(); F8.setNav(); $('#hubscroll').scrollTop = 0;
  }
  function showCard(id, tabId) {
    const c = CARD[id]; if (!c) return showMain();
    PG.cat = id; PG.tab = tabId && c.tabs.some(t => t.id === tabId) ? tabId : c.tabs[0].id;
    $('#hubscroll').style.display = 'none'; $('#infobar').style.display = 'none'; $('#subw').style.display = 'flex';
    renderHead(); drawTab(); F8.setNav();
  }
  function drawTab() {
    const c = CARD[PG.cat]; if (!c) return;
    const tb = $('#tabs8'); tb.style.display = c.tabs.length > 1 ? '' : 'none';
    const th = c.tabs.map(t => '<button class="t8 ' + (t.id === PG.tab ? 'on' : '') + '" data-h="tab:' + t.id + '">' + (t.ic ? svg(t.ic) : '') + E(t.l) + '</button>').join('');
    if (tb.__h !== th) { tb.__h = th; tb.innerHTML = th; }
    const t = c.tabs.find(x => x.id === PG.tab) || c.tabs[0], e = $('#view');
    e.onclick = e.oninput = e.onchange = null;
    const keep = e.scrollTop;
    try { t.draw(e); } catch (x) { console.error('[hub8]', t.id, x); e.innerHTML = '<p class="note">This page could not be drawn: ' + E(x.message) + '</p>'; }
    const h2 = e.querySelector(':scope > h2'); if (h2) h2.remove();
    e.scrollTop = keep;
  }

  /* ------------------------------------------------------------ My Day (tasks + weekly schedule) */
  const DN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], ALL = [0, 1, 2, 3, 4, 5, 6];
  const repLabel = k => { const d = k.days || []; if (!d.length) return 'Once · ' + (k.d || ''); if (d.length === 7) return 'Every day'; if (d.join() === '1,2,3,4,5') return 'Weekdays'; if (d.join() === '0,6') return 'Weekends'; return d.map(i => DN[i]).join(', '); };
  const REPS = [['all', 'Every day', ALL], ['wk', 'Weekdays', [1, 2, 3, 4, 5]], ['we', 'Weekends', [0, 6]], ['once', 'Today only', []]].concat([1, 2, 3, 4, 5, 6, 0].map(i => ['d' + i, 'Every ' + DN[i], [i]]));
  function dayView(e) {
    const key = F8.ymd(), todo = (X.todo || []).slice().sort((a, b) => (a.t || '').localeCompare(b.t || ''));
    const on = k => k.days && k.days.length ? k.days.indexOf(new Date().getDay()) >= 0 : k.d === key;
    e.innerHTML = '<div class="p"><h4>Tasks</h4><p class="note">These appear in <b>Today’s Tasks</b> on Home. Tick a task to mark it done for today.</p>' +
      (todo.length ? todo.map(k => '<div class="li md"><span class="md1"><button class="cbx ' + (k.done && k.done[key] ? 'on' : '') + (on(k) ? '' : ' off') + '" data-h="mdTog:' + k.id + '" title="' + (on(k) ? 'Mark done / not done' : 'Not planned for today') + '">' + svg('check') + '</button><span><b>' + E(k.n) + '</b><small>' + (k.t ? F8.fmt12(k.t) + ' · ' : '') + repLabel(k) + '</small></span></span><span><button class="btn s g" data-h="mdEdit:' + k.id + '">Edit</button> <button class="x" data-h="mdDel:' + k.id + '" title="Delete">✕</button></span></div>').join('') : '<p class="note">No tasks yet.</p>') +
      '<div class="row addr"><input id="mdN" placeholder="New task, e.g. Revise Chemistry" onkeydown="if(event.key===\'Enter\')document.querySelector(\'[data-h=mdAdd]\').click()"><input type="time" id="mdT" value="09:00" style="flex:none;width:8.5rem"><select id="mdR" style="flex:none">' + REPS.map(r => '<option value="' + r[0] + '">' + r[1] + '</option>').join('') + '</select><button class="btn" data-h="mdAdd">Add task</button></div></div>' +
      '<div class="p"><h4>Weekly schedule</h4><p class="note">Classes and regular events. The next three show in <b>Upcoming Schedule</b> on Home.</p>' +
      ((X.sched || []).length ? X.sched.slice().sort((a, b) => (a.days[0] + 6) % 7 - (b.days[0] + 6) % 7 || a.s.localeCompare(b.s)).map(s => '<div class="li md"><span class="md1"><span class="ci">' + svg(s.ic || 'calendar') + '</span><span><b>' + E(s.n) + '</b><small>' + s.days.map(i => DN[i]).join(', ') + ' · ' + F8.fmt12(s.s) + (s.e ? ' - ' + F8.fmt12(s.e) : '') + '</small></span></span><span><button class="btn s g" data-h="msEdit:' + s.id + '">Edit</button> <button class="x" data-h="msDel:' + s.id + '" title="Delete">✕</button></span></div>').join('') : '<p class="note">Nothing scheduled.</p>') +
      '<div class="row addr"><input id="msN" placeholder="Class or event name" onkeydown="if(event.key===\'Enter\')document.querySelector(\'[data-h=msAdd]\').click()"><select id="msD" style="flex:none">' + [1, 2, 3, 4, 5, 6, 0].map(i => '<option value="' + i + '">' + DN[i] + '</option>').join('') + '</select><input type="time" id="msS" value="15:00" style="flex:none;width:8.5rem"><input type="time" id="msE" value="17:00" style="flex:none;width:8.5rem"><button class="btn" data-h="msAdd">Add</button></div></div>' +
      '<div class="row"><button class="btn g" data-h="go:calendar">' + svg('calendar') + ' Open calendar (dated events)</button></div>';
  }

  /* ------------------------------------------------------------ search */
  function index() {
    const out = [];
    CARDS.forEach(c => { out.push({ c: c.id, t: null, label: c.t, sub: c.d, ic: c.ic, kw: (c.t + ' ' + c.d + ' ' + c.kw).toLowerCase() }); if (c.tabs.length > 1) c.tabs.forEach(t => out.push({ c: c.id, t: t.id, label: c.t + ' › ' + t.l, sub: '', ic: t.ic || c.ic, kw: (c.t + ' ' + t.l + ' ' + (t.kw || '') + ' ' + c.kw).toLowerCase() })); else if (c.tabs[0].kw) out[out.length - 1].kw += ' ' + c.tabs[0].kw.toLowerCase(); });
    return out;
  }
  let SEL = 0, RES = [];
  function runSearch() {
    const q = ($('#hs').value || '').trim().toLowerCase(), box = $('#sres');
    if (!q) { box.classList.remove('on'); RES = []; return; }
    const words = q.split(/\s+/); RES = index().filter(r => words.every(w => r.kw.indexOf(w) >= 0)).sort((a, b) => (a.label.toLowerCase().indexOf(q) < 0) - (b.label.toLowerCase().indexOf(q) < 0)).slice(0, 8);
    SEL = 0; box.classList.add('on');
    box.innerHTML = RES.length ? RES.map((r, i) => '<button class="' + (i === SEL ? 'sel' : '') + '" data-h="res:' + i + '">' + svg(r.ic) + '<span>' + E(r.label) + (r.sub ? '<small>' + E(r.sub) + '</small>' : '') + '</span></button>').join('') : '<div class="none">No settings match “' + E(q) + '”.</div>';
  }
  function pick(i) { const r = RES[i]; if (!r) return; $('#hs').value = ''; $('#sres').classList.remove('on'); $('#hs').blur(); showCard(r.c, r.t || undefined); }
  function wireSearch() {
    const hs = $('#hs'); if (!hs) return;
    hs.addEventListener('input', runSearch);
    hs.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (!RES.length) return; SEL = (SEL + (e.key === 'ArrowDown' ? 1 : -1) + RES.length) % RES.length; $$('#sres button').forEach((b, i) => b.classList.toggle('sel', i === SEL)); }
      else if (e.key === 'Enter') { e.preventDefault(); pick(SEL); }
      else if (e.key === 'Escape') { e.stopPropagation(); hs.value = ''; $('#sres').classList.remove('on'); hs.blur(); }
    });
    hs.addEventListener('blur', () => setTimeout(() => $('#sres') && $('#sres').classList.remove('on'), 180));
    hs.addEventListener('focus', () => { if (hs.value) runSearch(); });
  }

  /* ------------------------------------------------------------ actions */
  const H = {};
  H.back = () => { if (PG.cat) showMain(); else view('Home'); };
  H.card = el => showCard(el.dataset.h.split(':')[1]);
  H.tab = el => { PG.tab = el.dataset.h.split(':')[1]; drawTab(); };
  H.go = el => { const id = el.dataset.h.split(':')[1]; showCard(id); };
  H.res = el => pick(+el.dataset.h.split(':')[1]);
  H.modemenu = el => { const m = $('#modemenu'); m.classList.toggle('on'); };
  H.mode = el => {
    const k = el.dataset.h.split(':')[1]; X.mode = k; sx(); $('#modemenu').classList.remove('on'); infoBar(); F8.act(MODES[k][0] + ' on', MODES[k][1], 'b'); toast(MODES[k][0] + ' on');
    if (k === 'focus' && !F8.FOCUS.on) F8.A.qaFocus();
  };
  H.cam = () => camToggle();
  function camToggle() {
    if (!B || !window.FridayVision) { toast('The camera is available in the FRIDAY desktop app'); showCard('vision'); return; }
    const s = window.FridayVision.state && window.FridayVision.state.session, on = !!(s && s.running && s.kind === 'camera');
    window.FridayVision.call(on ? 'camera_stop' : 'camera_start', on ? {} : { preview: true, speak: false }).then(r => { if (r && r.ok === false) toast(r.error || 'Camera action failed'); else F8.act(on ? 'Camera closed' : 'Camera opened', 'camera', 'b'); F8.renderAll(); infoBar(); });
    toast(on ? 'Closing the camera...' : 'Opening the camera...');
  }
  const newId = () => Date.now() + Math.floor(Math.random() * 1000);
  H.mdTog = el => { const k = X.todo.find(x => x.id == el.dataset.h.split(':')[1]); if (!k) return; const key = F8.ymd(); k.done = k.done || {}; if (k.done[key]) delete k.done[key]; else k.done[key] = 1; sx(); drawTab(); };
  H.mdDel = el => { const id = el.dataset.h.split(':')[1]; approve('Delete this task?').then(ok => { if (ok) { X.todo = X.todo.filter(x => x.id != id); sx(); drawTab(); } }); };
  H.mdAdd = () => {
    const n = $('#mdN').value.trim(), t = $('#mdT').value, r = REPS.find(x => x[0] === $('#mdR').value) || REPS[0];
    if (!n) { toast('Type the task name first'); $('#mdN').focus(); return; }
    X.todo.push({ id: newId(), n, t, days: r[2].slice(), d: r[0] === 'once' ? F8.ymd() : '', done: {} }); sx(); drawTab(); toast('Task added');
  };
  H.mdEdit = el => {
    const k = X.todo.find(x => x.id == el.dataset.h.split(':')[1]); if (!k) return;
    mod('Edit task', '<div class="row"><input id="etN" value="' + E(k.n) + '"><input type="time" id="etT" value="' + E(k.t || '') + '" style="flex:none;width:8.5rem"></div><div class="row" style="margin-top:.6rem"><select id="etR">' + REPS.map(r => '<option value="' + r[0] + '"' + (repLabel({ days: r[2], d: F8.ymd() }) === repLabel(k) || (r[0] === 'once' && !(k.days || []).length) ? ' selected' : '') + '>' + r[1] + '</option>').join('') + '</select></div><div class="row" style="margin-top:1rem;justify-content:flex-end"><button class="btn g" onclick="closeM()">Cancel</button><button class="btn" data-h="etSave:' + k.id + '">Save</button></div>');
  };
  H.etSave = el => { const k = X.todo.find(x => x.id == el.dataset.h.split(':')[1]); if (!k) return; const n = $('#etN').value.trim(); if (!n) return toast('The task needs a name'); const r = REPS.find(x => x[0] === $('#etR').value) || REPS[0]; k.n = n; k.t = $('#etT').value; k.days = r[2].slice(); k.d = r[0] === 'once' ? F8.ymd() : ''; closeM(); sx(); drawTab(); toast('Task updated'); };
  H.msDel = el => { const id = el.dataset.h.split(':')[1]; approve('Delete this scheduled item?').then(ok => { if (ok) { X.sched = X.sched.filter(x => x.id != id); sx(); drawTab(); } }); };
  H.msAdd = () => {
    const n = $('#msN').value.trim(), s = $('#msS').value, e = $('#msE').value;
    if (!n) { toast('Type the class or event name first'); $('#msN').focus(); return; }
    if (e && s && e <= s) { toast('The end time must be after the start time'); return; }
    X.sched.push({ id: newId(), n, days: [+$('#msD').value], s: s || '09:00', e: e || '', ic: ['users', 'stopwatch', 'face', 'book', 'cpu', 'calendar'][X.sched.length % 6] }); sx(); drawTab(); toast('Added to your schedule');
  };
  H.msEdit = el => {
    const s = X.sched.find(x => x.id == el.dataset.h.split(':')[1]); if (!s) return;
    mod('Edit schedule item', '<div class="row"><input id="esN" value="' + E(s.n) + '"></div><div class="row" style="margin-top:.6rem"><select id="esD" style="flex:none">' + [1, 2, 3, 4, 5, 6, 0].map(i => '<option value="' + i + '"' + (s.days[0] === i ? ' selected' : '') + '>' + DN[i] + '</option>').join('') + '</select><input type="time" id="esS" value="' + E(s.s) + '" style="flex:none;width:8.5rem"><input type="time" id="esE" value="' + E(s.e || '') + '" style="flex:none;width:8.5rem"></div><div class="row" style="margin-top:1rem;justify-content:flex-end"><button class="btn g" onclick="closeM()">Cancel</button><button class="btn" data-h="esSave:' + s.id + '">Save</button></div>');
  };
  H.esSave = el => { const s = X.sched.find(x => x.id == el.dataset.h.split(':')[1]); if (!s) return; const n = $('#esN').value.trim(); if (!n) return toast('It needs a name'); const a = $('#esS').value, b = $('#esE').value; if (a && b && b <= a) return toast('The end time must be after the start time'); s.n = n; s.days = [+$('#esD').value]; s.s = a || s.s; s.e = b; closeM(); sx(); drawTab(); toast('Schedule updated'); };

  document.addEventListener('click', e => {
    const el = e.target.closest('[data-h]'); if (!el) { const mm = $('#modemenu'); if (mm && mm.classList.contains('on') && !e.target.closest('#modemenu')) mm.classList.remove('on'); return; }
    const k = el.dataset.h.split(':')[0], fn = H[k]; if (!fn) return;
    e.stopPropagation(); if (k === 'res') e.preventDefault();
    try { fn(el, e); } catch (x) { console.error('[hub8]', k, x); }
  }, true);
  /* results list: act on mousedown so the input blur does not swallow the click */
  document.addEventListener('mousedown', e => { const b = e.target.closest('#sres button'); if (b) { e.preventDefault(); pick(+b.dataset.h.split(':')[1]); } }, true);

  /* ------------------------------------------------------------ public api used by friday_ui8.js */
  const ALIAS = { Plans: ['finance', 'plans'], Reports: ['finance', 'rep'], Finance: ['finance', 'fin'], Calendar: ['calendar'], Files: ['files', 'files'], Multimedia: ['files', 'media'], Web: ['web'], Tools: ['tools'], Centre: ['centre'], Intel: ['intel'], Memory: ['memory'], Vision: ['vision', 'live'], Tasks: ['tasks', 'day'] };
  F8.hub.openPage = function (v, tab) {
    PG.page = 'settings'; document.body.dataset.page = 'settings'; F8.setNav();
    $('#bell').style.display = 'none';
    if (v === 'Tasks' && tab === 'agents') { showCard('tasks', 'agents'); }
    else if (ALIAS[v]) showCard(ALIAS[v][0], ALIAS[v][1]);
    else if (v === 'Settings' && tab) {
      const q = String(tab).toLowerCase(); let hit = null;
      CARDS.forEach(c => c.tabs.forEach(t => { if (!hit && (t.id === q || t.l.toLowerCase() === q)) hit = [c.id, t.id]; }));
      if (hit) showCard(hit[0], hit[1]); else showMain();
    } else showMain();
    F8.renderRight();
  };
  F8.hub.render = function () { if (PG.cat) drawTab(); else { renderHubMain(); infoBar(); } };
  F8.hub.refresh = function () { if (PG.cat) return; infoBar(); };
  F8.hub.back = H.back;
  F8.hub.focusSearch = function () { if (PG.page !== 'settings') return; if (PG.cat) showMain(); const i = $('#hs'); if (i) { i.focus(); i.select(); } };
  Theme.subscribe(() => { if (PG.page === 'settings') { if (!PG.cat) { renderHubMain(); infoBar(); } renderHead(); } });

  /* first draw (hidden until the user opens Settings) */
  renderHead();
  if (window.fridayBridge && window.fridayBridge.onBackendReady) window.fridayBridge.onBackendReady(() => { if (PG.page === 'settings' && !PG.cat) infoBar(); });
})();
