# FRIDAY V2.3.0 - OpenCV 5 vision + verifying agent (everything else unchanged)

SEE -> THINK -> ACT -> CHECK -> ADAPT, added around the existing FRIDAY. Voice, listening, recognition, TTS, finance, notes,
WhatsApp, study mode, widget and the existing screen/AI routes were NOT modified.

## What was added (new files)
| File | Role |
|---|---|
| friday_vision_engine.py | OpenCV 5 vision engine: detection (ONNX on the new DNN engine / built-in / model-free), tracking (Kalman), OCR, motion, visual change (SSIM), spatial relations, scene summary, confidence, screen / camera / image / video |
| friday_vision_agent.py | Agent loop: look -> plan (Gemini or built-in rules) -> act -> verify with vision -> recover / replan -> ask if unsure. Also the simulated desktop used by the benchmark |
| friday_action_safety.py | Green / Yellow / Red action levels, confirmation broker (spoken + on-screen buttons), audit log |
| friday_eval_metrics.py | Live metrics + benchmark suite + report export |
| friday_vision_hub.py | Voice/typed command router + UI request router (the single door into all of the above) |
| friday_vision_config.py | Settings store (JSON) + in-memory secrets |
| friday_vision_cloud.py / friday_vision_server.py | Optional AWS Graviton / COOL offload (client + deployable server) |
| friday_vision_ui.js | Vision page, Settings > Vision tab, confirmation cards, camera/agent indicators |
| cloud/deploy_graviton.md | Step-by-step AWS setup |

## What was edited (additive only, nothing removed)
- friday_backend.py: +1 lazy-module line, +1 guarded call at the top of process_command (answers a pending yes/no, claims only explicit
  vision/agent phrases, otherwise returns at once), +2 stdin branches (`__FRIDAY_VISION__::`, `__FRIDAY_VISION_SECRET__::`).
- main.js / preload.js: secure storage for the optional cloud token, file pickers, vision data folder env (FRIDAY_VISION_DATA).
- index.html: Vision nav item + page hook + script tag.  friday_settings.js: new "Vision" tab.
- requirements.txt: opencv-python-headless>=5.0.  package.json: 2.3.0.

## Voice commands
turn on / off the camera - what do you see through the camera - turn on screen vision - what changed (on my screen / camera) -
is there an error on my screen - find the Save button on my screen - is anything moving - analyse this image / video (attached or a path) -
agent: open my chemistry notes - open X and make sure it opened - stop the agent - run the vision benchmark - export the evaluation report -
how well are you performing - vision status.  While FRIDAY is asking for permission, say yes / no (red actions: "confirm" / "cancel").
