from pathlib import Path

p = Path(__file__).with_name("friday_backend.py")
s = p.read_text(encoding="utf-8")

# This test previously asserted the *buggy* mechanism (bare recognizer.listen()
# with SpeechRecognition's own energy-based pause detector), which is exactly
# what caused FRIDAY to sit on "Listening..." and never reach recognition.
# It now asserts the fixed mechanism: same behaviour spec (wait indefinitely
# for speech, end after VAD_PAUSE_THRESHOLD seconds of silence), implemented
# by the reliable _capture_until_silence() capture loop instead.
assert 'VAD_PAUSE_THRESHOLD = float(os.getenv("FRIDAY_VAD_PAUSE", "1.15"))' in s, "10-second default missing"
assert 'def _capture_until_silence(source):' in s, "Reliable capture loop missing"
listen_body = s[s.index('def listen():'):s.index('def listen():') + 4000]
assert 'audio = _capture_until_silence(source)' in listen_body, "listen() must use _capture_until_silence(), not recognizer.listen()"
assert 'audio = recognizer.listen(' not in listen_body, \
    "listen() must not use SpeechRecognition's own energy-based pause detector -- that is the bug this fixes"
print("PASS: listen() uses the reliable _capture_until_silence() capture loop with a 1.25s silence threshold")
