"""V3095 9.5+ regression / architecture test suite.
Focuses on code-level guarantees; Windows-only GUI/audio behaviour must be run on the target laptop.
"""
from __future__ import annotations

import importlib
import os
import tempfile
from pathlib import Path


def ok(label, condition, detail=""):
    if not condition:
        raise AssertionError(f"FAIL: {label} {detail}")
    print(f"PASS: {label}")


def main():
    modules = [
        "friday_action_contracts", "friday_unified_gateway", "friday_unified_loop",
        "friday_supervisor", "friday_executive", "friday_verifier_layer",
        "friday_perception", "friday_proactive_monitor"
    ]
    for name in modules:
        mod = importlib.import_module(name)
        ok(f"import {name}", mod is not None)

    import friday_action_contracts as contracts
    ok("unknown result is not success", contracts.result_is_successful("open Chrome", {"ok": True})[0] is False)
    ok("explicit verification is success", contracts.result_is_successful("open Chrome", {
        "ok": True, "verified": True, "verification": {"method": "window"}
    })[0] is True)

    import friday_supervisor as sup
    agents = sup.list_agents()
    # Registration is performed lazily by the gateway.
    import friday_unified_gateway as gateway
    agents = gateway.register_default_agents()
    ok("unified agent registration", all(x in agents.get(g, []) for g, x in [
        ("action", "desktop"), ("action", "app_launcher"), ("knowledge", "web_research"),
        ("knowledge", "youtube_research"), ("creation", "documents")
    ]), str(agents))

    import friday_perception as perception
    fast = perception.snapshot_all(include_screen=False, include_system=False)
    ok("fast perception skips heavy capture", fast["screen"].get("skipped") is True and fast["system"].get("skipped") is True)

    import friday_proactive_monitor as proactive
    proactive_test_agents = importlib.import_module("friday_unified_gateway").register_default_agents()
    ok("proactive agent registration", "desktop" in proactive_test_agents.get("action", []))
    score, reason = proactive.relevance_score({"type": "download_complete", "description": "Important document", "important": True})
    ok("proactive scoring", score >= 0.65 and reason)

    import friday_executive as executive
    import friday_task_graph as graph
    # Stub dispatch proves UNKNOWN does not become success.
    goal = executive.plan("verification regression", plan_override=[{
        "action": "open test target", "verification_level": "mechanical_action", "agent_group": "action", "agent_name": "desktop"
    }])
    result = executive.execute_goal(goal["id"], dispatch=lambda task: {"ok": True, "verified": False})
    ok("executive rejects unknown verification", result.get("status") == "FAILED")

    print("ALL V3095 9.5+ ARCHITECTURE TESTS PASSED")


if __name__ == "__main__":
    main()
