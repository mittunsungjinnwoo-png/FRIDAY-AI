"""FRIDAY 6.0 multi-agent intelligence (blueprint section 14).

FRIDAY is the central coordinator: it understands the request, selects specialists (not all of them for every request),
runs independent ones in parallel under a time budget, compares their outputs, detects conflicts, asks the verification
agent to review important results, escalates to a stronger model when confidence is low, and records what the coordination
cost so "more agents" is measured instead of assumed to be better.
"""
from __future__ import annotations

import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait
from typing import Callable, Dict, List, Optional

import friday_common6 as C

C.register_schema("""
CREATE TABLE IF NOT EXISTS agent_runs(id INTEGER PRIMARY KEY, ts REAL, request TEXT, agents TEXT, n INTEGER, ms INTEGER, conflicts INTEGER, confidence REAL, escalated INTEGER, verified INTEGER);
""")

AGENTS: Dict[str, Dict] = {
    "code": {"role": "Software development: write, debug, review and explain code", "tools": ["code_map", "code_review", "run_tests", "run_python"],
             "kw": r"\b(code|bug|debug|function|class|python|javascript|script|api|compile|error|exception|stack ?trace|refactor|test(?:s|ing)?|git|repo|build|install|dependency|regex|sql)\b", "model": "fast"},
    "research": {"role": "Sources and evidence: find, compare and cite sources; separate fact, estimate and speculation", "tools": ["web_research", "research_note"],
                 "kw": r"\b(research|source|sources|evidence|study|studies|paper|papers|latest|news|compare|literature|cite|citation|claim|review of|look up|find out)\b", "model": "deep"},
    "study": {"role": "Tutoring and practice: explain step by step, check understanding, set practice questions", "tools": ["study_quiz", "study_explain"],
              "kw": r"\b(syllabus|revise|revision|exam|past paper|mark scheme|flashcards?|quiz me|teach me|explain .* (?:simply|step)|homework|cambridge|igcse|a[- ]level|topic|chapter)\b", "model": "fast"},
    "vision": {"role": "Images and screenshots: describe, OCR, compare, find UI elements", "tools": ["vision_describe", "vision_compare"],
               "kw": r"\b(image|photo|picture|screenshot|screen|camera|diagram|chart|graph|ocr|video|see)\b", "model": "fast"},
    "planning": {"role": "Goals and dependencies: break goals into steps, milestones and success criteria", "tools": ["make_plan"],
                 "kw": r"\b(plan|schedule|roadmap|milestone|steps?|timeline|organi[sz]e|prioriti[sz]e|strategy|goal|deadline|prepare)\b", "model": "fast"},
    "analysis": {"role": "Mathematics and data: exact calculation, statistics, units, uncertainty", "tools": ["calc", "stats", "solve"],
                 "kw": r"\b(calculate|compute|solve|equation|integral|derivative|probability|statistic|average|mean|median|variance|units?|convert|error|uncertainty|percent|data|dataset|csv|regression)\b", "model": "deep"},
    "memory": {"role": "Relevant personal context from long-term memory", "tools": ["memory_search"],
               "kw": r"\b(remember|recall|earlier|before|last time|previous(?:ly)?|we decided|my (?:project|goal|preference|notes)|did i|did we)\b", "model": "fast"},
    "verification": {"role": "Independent review: tests, fact-checking, arithmetic checks, contradiction hunting", "tools": ["verify"],
                     "kw": r"\b(verify|double[- ]check|fact[- ]check|is (?:it|this|that) (?:true|correct|right)|prove|validate|are you sure)\b", "model": "deep"},
}
_local: Dict[str, Callable[[str], Optional[str]]] = {}      # agent -> local (no model) function; registered by core6
_lock = threading.Lock()


def register_local(agent: str, fn: Callable[[str], Optional[str]]):
    _local[agent] = fn


def select(request: str, max_agents: int = 3) -> List[str]:
    """Automatic agent selection: score each specialist, keep only the ones that clearly fit."""
    scores = {}
    for name, a in AGENTS.items():
        n = len(re.findall(a["kw"], request, re.I))
        if n:
            scores[name] = n
    ranked = [k for k, _ in sorted(scores.items(), key=lambda kv: -kv[1])]
    return ranked[:max_agents]


def _numbers(text: str) -> List[float]:
    out = []
    for m in re.findall(r"-?\d[\d,]*\.?\d*", text or ""):
        try:
            out.append(float(m.replace(",", "")))
        except Exception:
            pass
    return out


def find_conflicts(outputs: Dict[str, str]) -> List[str]:
    """Conflict detection between agent outputs: different final numbers, or opposite yes/no verdicts."""
    names = [n for n, o in outputs.items() if o]
    out = []
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = outputs[names[i]], outputs[names[j]]
            na, nb = _numbers(a)[-2:], _numbers(b)[-2:]
            if na and nb and not any(abs(x - y) <= max(1e-6, abs(y) * 1e-3) for x in na for y in nb) and len(a) < 400 and len(b) < 400:
                out.append(f"{names[i]} and {names[j]} give different numbers ({na[-1]:g} vs {nb[-1]:g})")
            ya = bool(re.match(r"^\W*(yes|correct|true)\b", a, re.I)); yb = bool(re.match(r"^\W*(yes|correct|true)\b", b, re.I))
            za = bool(re.match(r"^\W*(no|incorrect|false)\b", a, re.I)); zb = bool(re.match(r"^\W*(no|incorrect|false)\b", b, re.I))
            if (ya and zb) or (za and yb):
                out.append(f"{names[i]} and {names[j]} disagree on the verdict")
    return out


def _run_agent(name: str, request: str, shared: Dict, deadline: float, strong: bool = False) -> str:
    a = AGENTS[name]
    t0 = time.time()
    loc = None
    fn = _local.get(name)
    if fn:
        try:
            loc = fn(request)
        except Exception as exc:
            loc = None
            C.log(f"local agent {name} failed: {exc}", "recovery")
    ctx = "\n".join(f"{k}: {C.clip(v, 300)}" for k, v in shared.items() if k != name)
    prompt = (f"You are FRIDAY's {name} agent. Role: {a['role']}.\n"
              + (f"Shared task context from other agents:\n{ctx}\n" if ctx else "")
              + (f"Local tool result you must use as ground truth:\n{loc}\n" if loc else "")
              + "Answer only your part, briefly, in plain spoken sentences. If you are unsure, say exactly what you are unsure about.\n\nRequest: " + request)
    out = ""
    if time.time() < deadline and C._cfg.get("llm"):
        out = C.llm(prompt, model="deep" if (strong or a["model"] == "deep") else "fast")
    out = (out or loc or "").strip()
    with _lock:
        shared[name] = out
    return out


def coordinate(request: str, important: bool = False, budget_s: float = 40.0, agents: Optional[List[str]] = None) -> Dict:
    t0 = time.time()
    chosen = [a for a in (agents or select(request)) if a in AGENTS]
    trace: List[str] = []
    if not chosen:
        return {"answer": "", "agents": [], "conflicts": [], "confidence": 0.0, "trace": ["no specialist needed"], "escalated": False, "verified": False}
    shared: Dict[str, str] = {}
    deadline = t0 + budget_s
    if "memory" in chosen:                       # memory service first: its result is shared context for the rest
        _run_agent("memory", request, shared, deadline)
        trace.append("memory service supplied personal context")
    work = [a for a in chosen if a != "memory" and a != "verification"]
    if len(work) > 1:
        with ThreadPoolExecutor(max_workers=len(work)) as ex:
            futs = [ex.submit(_run_agent, a, request, shared, deadline) for a in work]
            wait(futs, timeout=max(1.0, deadline - time.time()))
        trace.append("ran in parallel: " + ", ".join(work))
    elif work:
        _run_agent(work[0], request, shared, deadline)
        trace.append("ran: " + work[0])
    outputs = {k: v for k, v in shared.items() if k not in ("memory",) and v}
    conflicts = find_conflicts(outputs)
    escalated = verified = False
    conf = 0.7 if outputs else 0.0
    if conflicts:
        conf = 0.45
        trace.append("conflict: " + "; ".join(conflicts))
        # evidence-based resolution: stronger model adjudicates between the specialists' claims
        if C._cfg.get("llm") and time.time() < deadline:
            adj = C.llm("Two specialists disagree. Decide which is right, showing the check you did, or say it cannot be decided.\n" +
                        "\n".join(f"[{k}] {C.clip(v, 500)}" for k, v in outputs.items()) + "\n\nQuestion: " + request, model="deep")
            if adj:
                shared["adjudicator"] = adj.strip()
                escalated = True
                conf = 0.65
                trace.append("escalated to the stronger model to adjudicate")
    if (important or "verification" in chosen) and outputs and C._cfg.get("llm") and time.time() < deadline:
        main = max(outputs.values(), key=len)
        rv = C.llm("You are an independent reviewer. Reply OK if the answer is correct and complete, otherwise 'FIX:' and the corrected answer.\n\nQuestion: " + request + "\n\nAnswer: " + main, model="deep")
        verified = True
        if rv.strip().upper().startswith("FIX"):
            shared["verification"] = rv.split(":", 1)[-1].strip()
            conf = min(conf, 0.5)
            trace.append("independent review corrected the answer")
        else:
            conf = min(0.95, conf + 0.15)
            trace.append("independent review agreed")
    # final answer: adjudicated > verified fix > the longest specialist answer; weak -> escalate once
    answer = shared.get("adjudicator") or shared.get("verification") or (max(outputs.values(), key=len) if outputs else "")
    if outputs and conf < 0.5 and not escalated and C._cfg.get("llm") and time.time() < deadline:
        better = C.llm("Answer this carefully and say what you are unsure about:\n" + request, model="deep")
        if better:
            answer, escalated, conf = better.strip(), True, 0.6
            trace.append("low confidence: escalated to the stronger model")
    ms = int((time.time() - t0) * 1000)
    try:
        C.x("INSERT INTO agent_runs(ts,request,agents,n,ms,conflicts,confidence,escalated,verified) VALUES(?,?,?,?,?,?,?,?,?)",
            (C.now(), C.clip(request, 120), ",".join(chosen), len(chosen), ms, len(conflicts), conf, int(escalated), int(verified)))
    except Exception:
        pass
    return {"answer": answer, "agents": chosen, "outputs": outputs, "conflicts": conflicts, "confidence": round(conf, 2), "trace": trace, "escalated": escalated, "verified": verified, "ms": ms}


def stats() -> Dict:
    """Measure what coordination costs: average latency, conflict rate and confidence by number of agents used."""
    rows = C.q("SELECT n, COUNT(*) c, AVG(ms) ms, AVG(conflicts) cf, AVG(confidence) conf, AVG(escalated) esc FROM agent_runs GROUP BY n ORDER BY n")
    return {"by_agent_count": [{"agents": r["n"], "runs": r["c"], "avg_ms": int(r["ms"] or 0), "conflict_rate": round(r["cf"] or 0, 2), "avg_confidence": round(r["conf"] or 0, 2), "escalation_rate": round(r["esc"] or 0, 2)} for r in rows]}


def roster() -> List[Dict]:
    return [{"agent": k, "role": v["role"], "tools": v["tools"], "model": v["model"]} for k, v in AGENTS.items()]


def handle(command: str) -> Optional[str]:
    t = re.sub(r"^(?:hey |ok |okay )?friday[, ]*", "", (command or "").strip(), flags=re.I)
    low = t.lower().strip(" .!?")
    if re.match(r"^(?:which|what|list|show) (?:agents|specialists|team)(?: do you have| are there| are available)?$|^who is on your team$", low):
        return "My team: " + "; ".join(f"{a['agent']} agent for {a['role'].split(':')[0].lower()}" for a in roster()) + ". I pick only the ones a request needs."
    m = re.match(r"^(?:ask|use|get) (?:the )?(?:(\w+) )?(?:agents?|specialists?|team)(?: to| on| about| for)?:?\s+(.+)$", t, re.I)
    if m:
        names = [m.group(1).lower()] if m.group(1) and m.group(1).lower() in AGENTS else None
        r = coordinate(m.group(2), agents=names)
        if not r["answer"]:
            return "None of my specialists could add anything to that."
        extra = (" Note: " + r["conflicts"][0] + ".") if r["conflicts"] else ""
        return r["answer"] + extra
    if re.match(r"^(?:agent|team|coordination) (?:stats|statistics|performance|report)$", low):
        s = stats()["by_agent_count"]
        return "No coordinated runs yet." if not s else "Coordination so far: " + "; ".join(f"{r['agents']} agent(s): {r['runs']} runs, {r['avg_ms']} ms, confidence {r['avg_confidence']}" for r in s) + "."
    return None
