"""
FRIDAY BEHAVIOURAL INTELLIGENCE CORE
------------------------------------
A lightweight state/observation/response-planning layer that sits
around the existing Friday backend. It does NOT replace Gemini,
intent handlers, memory, Study Mode, or the Electron UI.

It implements the research recommendations:
- continuous conversational state
- situational awareness
- event stream
- action -> observation -> state update
- deterministic response planning
- concise/proactive delivery rules
- current task/reference continuity

No screenshots or invasive app inspection are performed. On Windows
the observer reads only the foreground window title.
"""

from __future__ import annotations
import json
import os
import re
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Optional

STATE_FILE = Path(os.environ.get("FRIDAY_DATA") or (Path(__file__).parent / "friday_data")) / "friday_agent_state.json"
MAX_RECENT = 16
MAX_EVENTS = 120

_state_lock = threading.RLock()
_state: dict[str, Any] = {
    "mode": "normal",
    "subject": None,
    "topic": None,
    "task": None,
    "last_command": None,
    "last_action": None,
    "last_result": None,
    "last_intent": None,
    "last_confidence": None,
    "pending_reference": None,
    "active_window": None,
    "previous_window": None,
    "turn_id": 0,
    "recent_turns": [],
    "updated_at": 0,
}
_events = deque(maxlen=MAX_EVENTS)


def _load():
    global _state
    try:
        if STATE_FILE.exists():
            raw = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                with _state_lock:
                    _state.update(raw)
    except Exception:
        pass


def _save():
    try:
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(_state, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, STATE_FILE)
    except Exception:
        pass


_load()


def _emit(text: str, kind: str = "state"):
    event = {"ts": time.strftime("%H:%M:%S"), "text": text, "kind": kind}
    _events.append(event)
    try:
        print("FRIDAY_EVENT::" + json.dumps(event, ensure_ascii=False), flush=True)
    except Exception:
        pass


def observe(command: str, mode: Optional[str] = None,
            subject: Optional[str] = None, task: Optional[str] = None):
    """Begin a turn and snapshot the conversational state."""
    command = (command or "").strip()
    with _state_lock:
        _state["turn_id"] = int(_state.get("turn_id", 0)) + 1
        _state["last_command"] = command
        if mode:
            _state["mode"] = mode
        if subject:
            _state["subject"] = subject
        if task:
            _state["task"] = task
        _state["updated_at"] = time.time()
        _state.setdefault("recent_turns", []).append({
            "id": _state["turn_id"], "role": "user", "content": command,
            "ts": time.time()
        })
        _state["recent_turns"] = _state["recent_turns"][-MAX_RECENT:]
        _save()


def update_context(**values):
    changed = False
    with _state_lock:
        for key, value in values.items():
            if key in _state and value is not None and _state.get(key) != value:
                _state[key] = value
                changed = True
        if changed:
            _state["updated_at"] = time.time()
            _save()
    return changed


def record_action(action: str, result: Any = None, topic: Optional[str] = None):
    result_text = str(result)[:500] if result is not None else None
    with _state_lock:
        _state["last_action"] = action
        _state["last_result"] = result_text
        if topic:
            _state["topic"] = topic
        _state["updated_at"] = time.time()
        _save()
    _emit(f"{action}" + (f" — {result_text}" if result_text else ""), "action")


def record_response(answer: str):
    with _state_lock:
        _state.setdefault("recent_turns", []).append({
            "id": _state["turn_id"], "role": "assistant",
            "content": (answer or "")[:3000], "ts": time.time()
        })
        _state["recent_turns"] = _state["recent_turns"][-MAX_RECENT:]
        _state["updated_at"] = time.time()
        _save()
    _emit("Response delivered", "response")


def set_topic(topic: Optional[str]):
    update_context(topic=(topic or "").strip() or None)


def snapshot() -> dict[str, Any]:
    with _state_lock:
        return json.loads(json.dumps(_state))


def context_block() -> str:
    """Compact context for Gemini; never expose raw internal JSON."""
    s = snapshot()
    recent = s.get("recent_turns", [])[-8:]
    lines = [
        f"Mode: {s.get('mode') or 'normal'}",
        f"Subject: {s.get('subject') or 'unknown'}",
        f"Current topic: {s.get('topic') or 'unknown'}",
        f"Current task: {s.get('task') or 'none'}",
        f"Last action: {s.get('last_action') or 'none'}",
        f"Last intent: {s.get('last_intent') or 'none'}",
        f"Pending reference: {s.get('pending_reference') or 'none'}",
        f"Active window: {s.get('active_window') or 'unknown'}",
    ]
    if recent:
        lines.append("Recent interaction:")
        for t in recent:
            role = "User" if t.get("role") == "user" else "Friday"
            lines.append(f"- {role}: {t.get('content','')[:600]}")
    return "\n".join(lines)


def resolve_reference(text: str) -> Optional[str]:
    """Return the best current referent for vague words, if one exists."""
    low = (text or "").lower()
    if not re.search(r"\b(it|this|that|these|those|the results|the research|the file|the topic)\b", low):
        return None
    s = snapshot()
    return s.get("topic") or s.get("task") or s.get("last_action")


def plan_delivery(text: str, kind: str = "answer") -> dict[str, Any]:
    """
    Deterministic response planner. It decides delivery shape, not
    content, so it cannot hallucinate actions or override handlers.
    """
    text = (text or "").strip()
    sentences = [x for x in re.split(r"(?<=[.!?])\s+", text) if x]
    words = len(text.split())

    if kind in {"ack", "simple_command"}:
        max_sentences = 1
    elif kind in {"error"}:
        max_sentences = 2
    elif words > 180:
        max_sentences = min(8, max(3, len(sentences)))
    else:
        max_sentences = min(5, max(1, len(sentences)))

    return {
        "max_sentences": max_sentences,
        "pause_ms": 190 if max_sentences <= 2 else 230,
        "delivery": "calm_professional",
        "speak_full_text": True,
    }


def observer_tick(active_window: Optional[str]):
    if not active_window:
        return
    with _state_lock:
        previous = _state.get("active_window")
        if previous == active_window:
            return
        _state["previous_window"] = previous
        _state["active_window"] = active_window
        _state["updated_at"] = time.time()
        _save()
    _emit(f"Active window: {active_window}", "awareness")


def record_intent(intent: str, confidence: float = 0.0):
    with _state_lock:
        _state["last_intent"] = intent or None
        _state["last_confidence"] = float(confidence or 0.0)
        _state["updated_at"] = time.time()
        _save()
    _emit(f"Intent: {intent} ({float(confidence or 0.0):.2f})", "intent")


def set_pending_reference(reference: Optional[str]):
    update_context(pending_reference=(reference or "").strip() or None)


def decide_followup(action_succeeded: bool, consequential: bool = False) -> str:
    """Small deterministic observe -> decide policy used by the backend.

    Returns one of: silent, acknowledge, explain. It never invents an action.
    """
    if not action_succeeded:
        return "explain"
    if consequential:
        return "explain"
    return "acknowledge"


def recent_events():
    return list(_events)
