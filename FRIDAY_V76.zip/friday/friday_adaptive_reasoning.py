"""FRIDAY Adaptive Reasoning Layer v4010.2

A bounded, fast planner used as a pre-router and planning aid. It does not
replace the existing ASR, VAD, TTS, handlers, Gemini brain, or permission gates.
It improves understanding by separating explicit facts from inferred intent,
resolving common references, decomposing multi-step requests, and selecting
when deterministic routing is safe.
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any

_FILLER_PATTERNS = [
    r"\b(?:hey\s+)?friday\b", r"\bcan\s+you\b", r"\bcan\s+u\b",
    r"\bcould\s+you\b", r"\bwould\s+you\b", r"\bwill\s+you\b",
    r"\bplease\b", r"\bkindly\b", r"\bfor\s+me\b", r"\bright\s+now\b",
    r"\bif\s+you\s+can\b", r"\bif\s+u\s+can\b", r"\bsir\b",
]
_ACTIONS = ("open","launch","start","close","quit","exit","stop","search","find","look up","research","create","make","write","send","call","play","download","read","summarize","explain","compare","check","verify")
_CONNECTORS = re.compile(r"\b(?:and then|then|after that|followed by|once|after|and|also|plus)\b", re.I)
_REF = re.compile(r"\b(it|this|that|these|those|the file|the results|the research|the topic|the app|there)\b", re.I)

@dataclass(frozen=True)
class Analysis:
    cleaned: str
    actions: tuple[str, ...]
    objects: tuple[str, ...]
    references: tuple[str, ...]
    steps: tuple[str, ...]
    confidence: float
    ambiguity: float
    complexity: float
    route: str


def clean(text: str) -> str:
    s = str(text or "").strip()
    s = re.sub(r"[\u2018\u2019]", "'", s)
    for p in _FILLER_PATTERNS:
        s = re.sub(p, " ", s, flags=re.I)
    return re.sub(r"\s+", " ", s).strip(" .,!?:;")


def _similar(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def analyze(text: str, context: dict[str, Any] | None = None) -> Analysis:
    raw = str(text or "").strip()
    c = clean(raw)
    low = c.lower()
    actions = []
    for a in sorted(_ACTIONS, key=len, reverse=True):
        if re.search(r"(?<!\w)" + re.escape(a) + r"(?!\w)", low):
            actions.append(a)
    actions = list(dict.fromkeys(actions))
    refs = tuple(dict.fromkeys(m.group(1).lower() for m in _REF.finditer(low)))

    # Objects are conservative: capture text after an action until a connector.
    objects = []
    for m in re.finditer(r"\b(?:open|launch|start|close|quit|exit|stop|search|find|research|create|make|write|send|call|play|download|read|summarize|explain|compare|check|verify)\s+(.+?)(?=\s+(?:and then|then|after that|followed by|once|after|and|also|plus)\b|$)", low):
        obj = m.group(1).strip(" .,!?:;")
        if obj: objects.append(obj)

    parts = [p.strip(" .,!?:;") for p in _CONNECTORS.split(c) if p.strip(" .,!?:;")]
    steps = tuple(parts if len(parts) > 1 else ([c] if c else []))
    complexity = min(1.0, .08 + .12 * max(0, len(actions)-1) + .10 * max(0, len(steps)-1) + min(.45, len(c.split())/80))
    ambiguity = 0.0
    if refs: ambiguity += .20
    if not actions: ambiguity += .15
    if len(objects) < len(actions): ambiguity += .18
    if len(c.split()) < 3 and not objects: ambiguity += .20
    # Context resolves references, but never invents a missing explicit target.
    ctx = context or {}
    if refs and any(ctx.get(k) for k in ("topic","task","last_action","pending_reference")):
        ambiguity -= .10
    ambiguity = max(0.0, min(1.0, ambiguity))
    confidence = max(0.0, min(1.0, .97 - ambiguity - .04 * max(0, len(actions)-2)))
    route = "deterministic" if confidence >= .90 and len(actions) == 1 and len(steps) == 1 else ("planned" if confidence >= .65 else "generative")
    return Analysis(c, tuple(actions), tuple(objects), refs, steps, round(confidence,3), round(ambiguity,3), round(complexity,3), route)


def plan(text: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
    a = analyze(text, context)
    gates = ["understand"]
    if a.route != "deterministic": gates += ["resolve_references", "plan_steps"]
    if any(x in a.actions for x in ("research","search","find","compare","check","verify")): gates += ["evidence_check"]
    if any(x in a.actions for x in ("create","make","write","download")): gates += ["output_check"]
    if any(x in a.actions for x in ("send","call")): gates += ["permission_check"]
    gates += ["execute", "verify", "respond"]
    return {"version":"4010.2-adaptive","analysis":a.__dict__,"gates":list(dict.fromkeys(gates)),
            "principles":["explicit-before-inferred","deterministic-before-generative","verify-before-claim","fail-closed-on-ambiguity"]}


def canonical_app_command(text: str) -> str | None:
    """Return only a high-confidence open/close command for existing handlers."""
    a = analyze(text)
    if a.route != "deterministic" or not a.objects:
        return None
    action = a.actions[0]
    if action not in {"open","launch","start","close","quit","exit","stop"}:
        return None
    obj = a.objects[0]
    aliases = {
        "whatsapp": ("whatsapp","whats app","what's app","whatsap"),
        "chrome": ("chrome","google chrome"), "edge": ("edge","microsoft edge"),
        "spotify": ("spotify","spottyfy","spotifi"), "discord": ("discord","discrod"),
        "word": ("word","microsoft word","ms word"), "excel": ("excel","microsoft excel","ms excel"),
        "powerpoint": ("powerpoint","power point","microsoft powerpoint"), "vscode": ("vscode","vs code","visual studio code"),
        "notepad": ("notepad","note pad"), "calculator": ("calculator","calc","calcuator"),
    }
    for name, vals in aliases.items():
        if any(_similar(obj, v) >= .82 or v in obj for v in vals):
            return ("open " if action in {"open","launch","start"} else "close ") + name
    return None
