# FRIDAY 6.2 targeted fixes

- Made the left navigation/sidebar vertically scrollable so all feature items remain reachable.
- Hardened live vision motion processing against webcam resolution changes and grayscale/BGRA frames, the common cause of OpenCV array-size/channel mismatch errors.
- Hardened frame comparison against empty or unusual-format frames.
- Improved the direct “what can you see?” camera query matcher, including common speech-to-text transcription “u”.
- Changed the creative document pipeline default to Word (.docx); explicitly requested PDF or PowerPoint formats remain supported.

No features were intentionally removed. These are targeted fixes; hardware-specific camera and full UI behavior still need to be confirmed on the target Windows machine.
