"""
FRIDAY ADVANCED AGENT ORCHESTRATOR
----------------------------------
Additive orchestration layer for the existing single-file FRIDAY backend.

Implements the roadmap from the supplied research document:
- task objects + planner
- tool selection/router
- parallel execution for independent research/video work
- verification and bounded self-recovery
- permission levels for consequential actions
- diagnostics/self-test
- screen capture + optional Gemini vision
- structured event stream
- semantic-ish persistent memory index (local fallback; optional Gemini embeddings)
- observation snapshots
- document/research/study orchestration hooks

This module deliberately imports friday_backend lazily inside calls. That prevents
circular-import crashes and lets the existing backend remain the source of truth for
legacy commands, Study Mode, WhatsApp, TTS and UI IPC.
"""

from __future__ import annotations

import concurrent.futures
import dataclasses
import datetime as _dt
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time
import traceback

try:
    import friday_nlu as _nlu
except Exception:
    _nlu = None
from pathlib import Path
from typing import Any, Callable, Optional

import friday_feature_hardening as jfh
import friday_cognitive_architecture as _cognitive
import friday_proactive_reasoning as _proactive
from urllib.parse import quote_plus

# General intelligence layer (domain-neutral; never handles voice/listening/recognition).
import friday_intelligence_hub as _intelligence_hub

ROOT = Path(__file__).resolve().parent
STATE_FILE = ROOT / "friday_advanced_state.json"
TASKS_FILE = ROOT / "friday_tasks.json"
MEMORY_FILE = ROOT / "friday_semantic_memory.json"
SCREEN_DIR = ROOT / "screen_captures"
SCREEN_DIR.mkdir(exist_ok=True)

_LOCK = threading.RLock()
_TASKS: dict[str, dict[str, Any]] = {}
_MEMORY: list[dict[str, Any]] = []

PERMISSION_NAMES = {
    0: "read_information",
    1: "open_applications",
    2: "modify_files",
    3: "send_messages",
    4: "destructive_or_consequential",
}

# Explicitly consequential operations. Level 3 is the requested confirmation
# level for sending messages; level 4 covers deletion/shutdown.
_CONSEQUENTIAL = {
    "send_message": 3,
    "delete_file": 4,
    "shutdown": 4,
    "restart": 4,
    "close_application": 4,
    "execute_shell": 4,
}


@dataclasses.dataclass
class TaskStep:
    name: str
    tool: str
    status: str = "pending"
    dependencies: list[str] = dataclasses.field(default_factory=list)
    result: Any = None
    error: Optional[str] = None
    verification: list[dict[str, Any]] = dataclasses.field(default_factory=list)


@dataclasses.dataclass
class AgentTask:
    task_id: str
    objective: str
    priority: int = 5
    status: str = "planned"
    steps: list[TaskStep] = dataclasses.field(default_factory=list)
    current_step: int = 0
    dependencies: list[str] = dataclasses.field(default_factory=list)
    tools_used: list[str] = dataclasses.field(default_factory=list)
    errors: list[str] = dataclasses.field(default_factory=list)
    verification: list[dict[str, Any]] = dataclasses.field(default_factory=list)
    final_result: Any = None
    created_at: str = dataclasses.field(default_factory=lambda: _dt.datetime.now().isoformat(timespec="seconds"))
    updated_at: str = dataclasses.field(default_factory=lambda: _dt.datetime.now().isoformat(timespec="seconds"))

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


def _load_json(path: Path, default):
    try:
        if path.exists():
            value = json.loads(path.read_text(encoding="utf-8"))
            return value
    except Exception:
        pass
    return default


def _save_json(path: Path, value):
    try:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
    except Exception:
        pass


def _load():
    global _TASKS, _MEMORY
    raw = _load_json(TASKS_FILE, {})
    if isinstance(raw, dict):
        _TASKS = raw
    mem = _load_json(MEMORY_FILE, [])
    if isinstance(mem, list):
        _MEMORY = mem


_load()


def _backend():
    import friday_backend
    return friday_backend


def _emit(text: str, kind: str = "agent"):
    payload = {
        "ts": _dt.datetime.now().strftime("%H:%M:%S"),
        "text": str(text),
        "kind": kind,
    }
    try:
        print("FRIDAY_EVENT::" + json.dumps(payload, ensure_ascii=False), flush=True)
    except Exception:
        pass
    try:
        _backend().log_event(str(text), kind=kind)
    except Exception:
        pass


def _new_task_id() -> str:
    stamp = int(time.time() * 1000)
    return f"T-{stamp:x}"


def create_task(objective: str, steps: list[TaskStep], priority: int = 5) -> AgentTask:
    task = AgentTask(
        task_id=_new_task_id(),
        objective=objective.strip(),
        priority=max(1, min(10, int(priority))),
        steps=steps,
    )
    with _LOCK:
        _TASKS[task.task_id] = task.to_dict()
        _save_json(TASKS_FILE, _TASKS)
    _emit(f"Task {task.task_id} created: {task.objective}", "task")
    return task


def update_task(task: AgentTask, **values):
    for key, value in values.items():
        if hasattr(task, key):
            setattr(task, key, value)
    task.updated_at = _dt.datetime.now().isoformat(timespec="seconds")
    with _LOCK:
        _TASKS[task.task_id] = task.to_dict()
        _save_json(TASKS_FILE, _TASKS)


def verify_path(path: str | Path, expected_text: Optional[str] = None) -> dict[str, Any]:
    """Verify an output file exists, is non-empty and is readable.

    For PDFs/DOCX/XLSX/PPTX we also perform a light structural check when the
    corresponding library is installed. This is deliberately independent of
    the generation function, so success is never assumed from an API return.
    """
    p = Path(path)
    result: dict[str, Any] = {
        "path": str(p),
        "exists": p.exists(),
        "size": p.stat().st_size if p.exists() and p.is_file() else 0,
        "readable": False,
        "valid": False,
        "expected_text_found": None,
    }
    if not result["exists"] or not p.is_file() or result["size"] <= 0:
        return result

    try:
        with p.open("rb") as f:
            f.read(32)
        result["readable"] = True
    except Exception:
        return result

    suffix = p.suffix.lower()
    try:
        if suffix == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(str(p))
            result["valid"] = len(reader.pages) > 0
            if expected_text:
                text = "\n".join((page.extract_text() or "") for page in reader.pages)
                result["expected_text_found"] = expected_text.lower() in text.lower()
        elif suffix == ".docx":
            from docx import Document
            doc = Document(str(p))
            result["valid"] = bool(doc.paragraphs or doc.tables)
            if expected_text:
                text = "\n".join(x.text for x in doc.paragraphs)
                result["expected_text_found"] = expected_text.lower() in text.lower()
        elif suffix == ".xlsx":
            from openpyxl import load_workbook
            wb = load_workbook(str(p), read_only=True)
            result["valid"] = bool(wb.sheetnames)
            wb.close()
        elif suffix == ".pptx":
            from pptx import Presentation
            prs = Presentation(str(p))
            result["valid"] = len(prs.slides) > 0
        else:
            result["valid"] = result["readable"]
    except Exception as exc:
        result["validation_error"] = str(exc)
        return result

    return result


def verify_outputs(paths: list[str | Path], expected_text: Optional[str] = None) -> tuple[bool, list[dict[str, Any]]]:
    checks = [verify_path(p, expected_text) for p in paths]
    ok = all(bool(c.get("exists") and c.get("size", 0) > 0 and c.get("readable") and c.get("valid")) for c in checks)
    return ok, checks


def _tool_candidates(command: str) -> list[str]:
    c = command.lower()
    tools: list[str] = []
    if any(x in c for x in (
        "research", "research this", "find sources", "compare sources", "according to",
        "latest", "current", "today", "this week", "recent", "up to date", "live information",
        "current price", "latest price", "news about",
    )):
        tools.append("web_research")
    if any(x in c for x in ("youtube", "videos", "video")):
        tools.append("youtube_research")
    if any(x in c for x in ("pdf", "document", "docx", "word", "spreadsheet", "xlsx", "slides", "presentation", "pptx", "create notes")):
        tools.append("document_creation")
    if any(x in c for x in ("screen", "screenshot", "what is on my screen", "look at this")):
        tools.append("vision")
    if any(x in c for x in (
        "open ", "launch ", "start ", "click ", "double-click", "right-click",
        "middle-click", "move cursor", "type ", "write ", "select all",
        "copy", "cut", "paste", "scroll ", "new tab", "close tab",
        "next tab", "previous tab", "switch tab", "volume up", "volume down",
        "mute", "play", "pause", "skip", "switch window", "minimize",
        "maximize", "restore",
    )):
        tools.append("computer_control")
    if any(x in c for x in ("send ", "message", "whatsapp", "email")):
        tools.append("communication")
    if "diagnostic" in c or "self test" in c or "self-test" in c:
        tools.append("diagnostics")
    if any(x in c for x in ("test me", "quiz me", "active recall", "study plan", "study mode")):
        tools.append("study")
    return list(dict.fromkeys(tools))


def _is_complex_agent_request(command: str) -> bool:
    c = command.lower()
    if any(x in c for x in (
        "run a full diagnostic", "run full diagnostic", "self test", "self-test",
        "what is on my screen", "what's on my screen", "look at my screen",
        "look at this screen", "take a screenshot",
    )):
        return True
    # Multi-objective language is the main trigger for the agent loop.
    connectors = sum(c.count(x) for x in (" and ", " then ", " also ", " as well as ", " after that "))
    advanced_words = sum(bool(re.search(p, c)) for p in (
        r"\bresearch\b", r"\bcreate\b", r"\bmake\b", r"\bsources?\b",
        r"\bcurrent\b", r"\blatest\b", r"\bcompare\b", r"\bfind\b", r"\bopen\b",
        r"\bverify\b", r"\bcompare\b", r"\bthree videos?\b", r"\bslides?\b",
        r"\bpdf\b", r"\bdocx\b", r"\bspreadsheet\b",
    ))
    return connectors >= 1 and advanced_words >= 1


def plan_request(command: str) -> AgentTask:
    """Create a deterministic plan. Gemini is not required to build the plan."""
    c = command.strip()
    tools = _tool_candidates(c)
    steps: list[TaskStep] = []

    # Research + YouTube are independent and therefore explicitly parallel.
    if "web_research" in tools:
        steps.append(TaskStep("Research reliable web sources", "web_research"))
    if "youtube_research" in tools:
        steps.append(TaskStep("Find useful YouTube sources", "youtube_research"))
    if "document_creation" in tools:
        deps = [s.name for s in steps if s.tool in {"web_research", "youtube_research"}]
        steps.append(TaskStep("Create requested document(s)", "document_creation", dependencies=deps))
    if "vision" in tools:
        steps.append(TaskStep("Inspect screen/image", "vision"))
    if "study" in tools and not any(s.tool == "document_creation" for s in steps):
        steps.append(TaskStep("Run adaptive Study Mode workflow", "study"))
    # BUGFIX (v104): _tool_candidates() has detected "computer_control" and
    # "communication" since this module was written, and _execute_step()
    # has always had real handlers for both (_execute_computer_control,
    # _execute_communication) -- but plan_request() never turned either
    # one into an actual TaskStep. That meant a compound request like
    # "open Chrome and research X" silently DROPPED the "open Chrome"
    # half: the plan only ever contained a research step, and nothing
    # ever reported the open as skipped. Same "the pieces exist but
    # were never wired together" bug class as the close-app/close-tab
    # issue fixed in friday_system_control.py -- fixed here the same
    # way: make the planner actually use the handlers that already exist.
    if "computer_control" in tools:
        steps.append(TaskStep("Perform verified desktop action", "computer_control"))
    if "communication" in tools:
        steps.append(TaskStep("Send message", "communication"))
    if not steps:
        steps.append(TaskStep("Use Friday reasoning engine", "reasoning"))

    return create_task(c, steps)


def _topic_from_command(command: str) -> str:
    c = re.sub(r"^\s*(friday[\s,:-]*)", "", command, flags=re.I).strip()
    c = re.sub(r"\b(please|can you|could you)\b", "", c, flags=re.I)
    patterns = [
        r"(?:research|research on|research about|find sources on|study)\s+(.+?)(?=\s+(?:and|then|also|as well as)\s+|$)",
        r"(?:create|make|write)\s+(?:a|an|some)?\s*(?:pdf|docx|document|slides|presentation|notes)\s+(?:about|on|for)?\s*(.+?)(?=\s+(?:and|then|also)\s+|$)",
    ]
    for p in patterns:
        m = re.search(p, c, re.I)
        if m:
            return m.group(1).strip(" .,:;")
    # V2037: "can u create a word documetn on orbitals make sure to the research" used to be
    # researched as that whole sentence. Reuse the creation engine's topic extractor.
    try:
        import friday_creation_engine as _ce
        cleaned = _ce._display_topic(command)
        if cleaned and len(cleaned) < len(c) + 1:
            return cleaned
    except Exception:
        pass
    return c


def _research(topic: str):
    jb = _backend()
    _emit(f"Research: gathering and verifying sources for {topic}", "research")
    result = jb.friday_web_research.run_web_research(topic, use_cache=True)
    # AI fallback is a valid completion path, but it is deliberately labeled
    # as non-live-verified by the research module.
    if not result.get("ok"):
        raise RuntimeError(result.get("answer") or "Research could not be completed.")
    try:
        jb.friday_context.remember_research(topic, result)
    except Exception:
        pass
    result["topic"] = topic
    # Upgrade the research output with independent quality metadata without
    # changing the established research API or source payload.
    try:
        result["intelligence_audit"] = _intelligence_hub.audit_research(result)
        result["verification_plan"] = _intelligence_hub.verification_plan(topic)
    except Exception as exc:
        _emit(f"Research audit skipped: {exc}", "verification")
    return result
    return {"topic": topic, "sources": sources}


def _youtube(topic: str):
    jb = _backend()
    _emit(f"YouTube research: {topic}", "research")
    data = jb.friday_youtube_research.gather_youtube_sources(topic, depth=5)
    out = {"topic": topic, "videos": data or []}
    try:
        out["intelligence_audit"] = _intelligence_hub.audit_research({"sources": out["videos"]})
    except Exception as exc:
        _emit(f"Video research audit skipped: {exc}", "verification")
    return out


def _spoken_issue(errors) -> str:
    """One short, speakable sentence describing the first failed step (never raw JSON)."""
    if not errors:
        return "one of the steps could not be verified"
    tool, _, detail = str(errors[0]).partition(": ")
    names = {"web_research": "the research step", "document_creation": "the document step",
             "computer_control": "the computer-control step", "youtube_research": "the YouTube research",
             "vision": "the screen inspection", "communication": "the messaging step", "study": "the study step"}
    what = names.get(tool, "one step")
    if detail.startswith("Verification failed"):
        why = "I couldn't verify that it produced its result"
    else:
        why = re.sub(r"\s+", " ", detail or "no detail was reported")[:120].strip(" .")
    return f"{what} failed - {why}"


def _create_documents(command: str, research: Optional[dict[str, Any]] = None):
    jb = _backend()
    reuse_sources = research.get("_raw_sources") if research else None
    topic = research.get("topic") if research else _topic_from_command(command)
    _emit(f"Document intelligence: building output for {topic}", "creation")
    # Existing creation engine remains the actual file generator.
    result = jb.friday_creation_engine.create_project_command(
        command,
        reuse_sources=reuse_sources,
        reuse_topic=topic,
    )
    files = []
    try:
        proj = jb.friday_creation_engine.LAST_PROJECT
        if proj.get("ok") and time.time() - float(proj.get("time") or 0) < 3600:
            files = list(proj.get("files") or [])
    except Exception:
        files = []
    artifact_audit = _intelligence_hub.audit_artifacts(files)
    return {"topic": topic, "handler_result": result, "files": files,
            "artifact_audit": artifact_audit,
            "verification_plan": _intelligence_hub.verification_plan(command)}


def _vision():
    jb = _backend()
    title = jb.get_active_window_title()
    timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    output = SCREEN_DIR / f"screen_{timestamp}.png"

    # mss is preferred because it is fast and works without GUI automation.
    try:
        import mss
        with mss.mss() as sct:
            sct.shot(output=str(output))
    except Exception:
        try:
            from PIL import ImageGrab
            image = ImageGrab.grab()
            image.save(output, "PNG")
        except Exception as exc:
            raise RuntimeError(f"Screen capture is unavailable: {exc}") from exc

    _emit(f"Screen captured: {output.name}", "vision")

    # Ask Gemini to inspect the image when the configured client is available.
    try:
        jb._ensure_gemini_client()
        client = getattr(jb, "client", None)
        if client is None:
            return {"path": str(output), "window": title, "analysis": None}

        try:
            from friday_screen_intelligence import _visible_windows
            visible = _visible_windows(limit=12)
        except Exception:
            visible = []
        visible_context = "; ".join(f"{a}: {t}" for a, t in visible[:12])
        prompt = (
            "You are Friday's visual observation engine. Inspect this screenshot. "
            "Describe only visible, relevant UI/content. Do not infer private facts "
            "that cannot be seen. If text is readable, summarize it accurately. "
            "IMPORTANT: the FRIDAY widget may be a small always-on-top overlay. "
            "Do not mistake the FRIDAY widget itself for the application the user is working in. "
            "If the screenshot or visible-window list shows ChatGPT, Chrome, WhatsApp, or another "
            "underlying application, identify that actual application instead. Distinguish the overlay "
            "from the underlying active task. Visible windows reported by Windows are: " + visible_context + ". "
            "Keep the answer concise and useful for a desktop assistant."
        )
        image_bytes = output.read_bytes()
        try:
            from google.genai import types
            image_part = types.Part.from_bytes(data=image_bytes, mime_type="image/png")
            contents = [prompt, image_part]
        except Exception:
            # Some installed google-genai versions accept raw bytes as a part.
            contents = [prompt, image_bytes]
        response = client.models.generate_content(
            model=jb.GEMINI_MODEL,
            contents=contents,
        )
        analysis = (getattr(response, "text", None) or "").strip()
    except Exception as exc:
        _emit(f"Vision model unavailable; screenshot retained ({exc})", "warning")
        analysis = None

    return {"path": str(output), "window": title, "analysis": analysis}


def _diagnostics() -> dict[str, Any]:
    jb = _backend()
    checks: dict[str, Any] = {}

    def check(name: str, fn: Callable[[], Any]):
        try:
            value = fn()
            checks[name] = {"ok": bool(value), "detail": str(value)[:500]}
        except Exception as exc:
            checks[name] = {"ok": False, "detail": f"{type(exc).__name__}: {exc}"}

    check("Python runtime", lambda: f"{os.sys.version_info.major}.{os.sys.version_info.minor}.{os.sys.version_info.micro}")
    check("File system", lambda: ROOT.exists() and os.access(ROOT, os.W_OK))
    check("Memory file", lambda: isinstance(getattr(jb, "memory", None), list))
    check("Study Mode", lambda: hasattr(jb, "study_state") and isinstance(jb.study_state, dict))
    check("Event stream", lambda: hasattr(jb, "log_event"))
    check("UI communication", lambda: hasattr(jb, "emit_progress"))
    check("System monitoring", lambda: "cpu_percent" in system_snapshot())
    check("TTS", lambda: callable(getattr(jb, "speak", None)))
    check("Microphone", lambda: callable(getattr(jb, "listen", None)))
    check("Web research", lambda: callable(getattr(jb.friday_web_research, "gather_sources", None)))
    check("Creation engine", lambda: callable(getattr(jb.friday_creation_engine, "create_project_command", None)))
    check("YouTube research", lambda: callable(getattr(jb.friday_youtube_research, "gather_youtube_sources", None)))
    check("WhatsApp confirmation", lambda: hasattr(jb, "_wa_begin_confirm"))
    try:
        jb._ensure_gemini_client()
        checks["Gemini connection"] = {"ok": getattr(jb, "client", None) is not None, "detail": "configured" if getattr(jb, "client", None) else "API key/client unavailable"}
    except Exception as exc:
        checks["Gemini connection"] = {"ok": False, "detail": str(exc)}

    overall = all(v.get("ok") for v in checks.values())
    return {"overall": overall, "checks": checks}


def _permission_for(command: str) -> int:
    c = command.lower()
    if any(x in c for x in ("send whatsapp", "send a message", "send message", "send an email")):
        return 3
    if any(x in c for x in ("delete ", "remove file", "shutdown", "shut down", "restart", "power off")):
        return 4
    if any(x in c for x in ("create ", "make ", "write ", "save ", "edit ", "modify ")):
        return 2
    if any(x in c for x in ("open ", "launch ", "start ")):
        return 1
    return 0


def permission_required(command: str) -> tuple[int, str]:
    level = _permission_for(command)
    return level, PERMISSION_NAMES[level]


def _run_parallel(task: AgentTask, command: str, selected: list[TaskStep]) -> dict[str, Any]:
    topic = _topic_from_command(command)
    results: dict[str, Any] = {}

    def run_step(step: TaskStep):
        step.status = "running"
        if step.tool == "web_research":
            return _research(topic)
        if step.tool == "youtube_research":
            return _youtube(topic)
        if step.tool == "vision":
            return _vision()
        raise RuntimeError(f"Unsupported parallel tool: {step.tool}")

    with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(selected))) as pool:
        future_map = {pool.submit(run_step, s): s for s in selected}
        for future in concurrent.futures.as_completed(future_map):
            step = future_map[future]
            try:
                results[step.tool] = future.result()
                step.status = "verified"
                task.tools_used.append(step.tool)
            except Exception as exc:
                step.status = "failed"
                step.error = str(exc)
                task.errors.append(f"{step.tool}: {exc}")
                results[step.tool] = None
    return results


def _execute(task: AgentTask, command: str) -> bool:
    jb = _backend()
    update_task(task, status="running")
    # Build a deterministic execution contract before any consequential work.
    # This is planning/verification only and does not touch the voice pipeline.
    try:
        task.verification.append({"type":"intelligence_contract", **_intelligence_hub.analyze_request(command)})
        task.verification.append({"type":"verification_plan", "steps":_intelligence_hub.verification_plan(command)})
    except Exception as exc:
        task.errors.append(f"intelligence_contract: {exc}")
    try:
        # Give one composed acknowledgement for complex work. The detailed
        # execution stream stays in the HUD, while success remains contingent
        # on the verification below.
        jb.speak(jb.friday_persona.line("task_ack", objective=task.objective))
    except Exception:
        pass
    jb.emit_progress(5, "Request understood — building an agent plan", task=task.objective)

    # Permission is enforced before consequential work.
    level, label = permission_required(command)
    if level >= 3:
        # WhatsApp has its own dedicated confirmation UI/state machine. The
        # agent must NOT return early here: doing so reports the task as failed
        # before the existing WhatsApp handler gets a chance to execute it.
        # Let the dedicated communication handler own confirmation and sending.
        if "whatsapp" in command.lower() or "message" in command.lower():
            pass
    if level >= 4:
        try:
            jb.speak(jb.friday_persona.line("confirmation_required"))
        except Exception:
            jb.speak(f"This action requires explicit confirmation: {label}. Please use the existing confirmation controls.")
        update_task(task, status="awaiting_confirmation")
        return True

    # Independent research/video work runs concurrently.
    parallel_steps = [s for s in task.steps if s.tool in {"web_research", "youtube_research"}]
    results = _run_parallel(task, command, parallel_steps) if parallel_steps else {}

    if "vision" in [s.tool for s in task.steps]:
        try:
            results["vision"] = _vision()
        except Exception as exc:
            task.errors.append(str(exc))

    research = results.get("web_research")
    yt = results.get("youtube_research")

    if any(s.tool == "document_creation" for s in task.steps):
        # If both research streams exist, the existing creation engine uses the
        # validated web sources; YouTube results are reported as supplementary
        # evidence rather than silently merged into citations.
        try:
            result = _create_documents(command, research=research)
            results["document_creation"] = result
        except Exception as exc:
            task.errors.append(f"document_creation: {exc}")
            # Bounded recovery: retry once using the normal creation handler
            # without reused sources. Never loop indefinitely.
            _emit("Creation step failed; attempting one recovery path.", "recovery")
            try:
                jb.speak(jb.friday_persona.line("task_recovery", objective=task.objective))
            except Exception:
                pass
            try:
                results["document_creation"] = _create_documents(command, research=None)
            except Exception as retry_exc:
                task.errors.append(f"document_recovery: {retry_exc}")

    if "study" in [s.tool for s in task.steps]:
        try:
            results["study"] = jb.handle_study_command(command)
        except Exception as exc:
            task.errors.append(f"study: {exc}")

    if "reasoning" in [s.tool for s in task.steps]:
        return False

    # Verify generated artifacts if the creation engine exposed them through
    # the task directory. Search only recently modified project files.
    verified = []
    projects = ROOT / "study_files" / "projects"
    if projects.exists():
        cutoff = time.time() - 300
        for p in projects.rglob("*"):
            try:
                if p.is_file() and p.stat().st_mtime >= cutoff and p.suffix.lower() in {".pdf", ".docx", ".xlsx", ".pptx"}:
                    verified.append(verify_path(p))
            except Exception:
                pass

    if verified:
        ok = all(v["exists"] and v["size"] > 0 and v["readable"] and v["valid"] for v in verified)
        task.verification.extend(verified)
        if not ok:
            task.errors.append("One or more generated files failed verification.")
    else:
        ok = not task.errors

    task.final_result = {
        "research_sources": len((research or {}).get("sources", [])),
        "youtube_videos": len((yt or {}).get("videos", [])),
        "verification": verified,
        "errors": task.errors,
    }
    update_task(task, status="completed" if not task.errors else "completed_with_errors")
    try:
        jb.emit_progress(100, "Agent task completed and verified" if not task.errors else "Agent task completed with reported errors", task=task.objective)
    except Exception:
        pass

    # Give the user one concise final report. Existing creation engine already
    # speaks its own detailed progress, so this is intentionally short.
    if not task.errors:
        try:
            jb.speak(jb.friday_persona.line("task_verified", objective=task.objective))
        except Exception:
            jb.speak("The agent task is complete, sir. I verified the available outputs.")
    else:
        jb.speak("The agent task finished with a few reported issues. I did not claim success where verification failed.")
    return True


def _handle_diagnostic(command: str) -> bool:
    jb = _backend()
    report = _diagnostics()
    passed = sum(1 for v in report["checks"].values() if v["ok"])
    total = len(report["checks"])
    for name, value in report["checks"].items():
        _emit(f"Diagnostic — {name}: {'PASS' if value['ok'] else 'FAIL'}", "diagnostic")
    if report["overall"]:
        jb.speak(f"Full diagnostic complete, sir. All {total} core checks passed.")
    else:
        failed = [name for name, value in report["checks"].items() if not value["ok"]]
        jb.speak(f"Diagnostic complete, sir. {passed} of {total} checks passed. Failed: {', '.join(failed[:5])}.")
    return True


def _handle_screen(command: str) -> bool:
    jb = _backend()
    try:
        result = _vision()
    except Exception as exc:
        jb.speak(f"I couldn't inspect the screen, sir. {exc}")
        return True
    if result.get("analysis"):
        jb.speak(result["analysis"])
    else:
        window = result.get("window") or "the current application"
        jb.speak(f"I captured the screen, sir. The active window appears to be {window}.")
    return True


def try_handle(command: str) -> Optional[bool]:
    """Return True when this layer handled the command, None otherwise.

    Returning None is intentional: the existing backend then handles the command
    exactly as it did before this update.
    """
    if not command or not command.strip():
        return None
    c = command.strip()

    if "diagnostic" in c.lower() or "self test" in c.lower() or "self-test" in c.lower():
        return _handle_diagnostic(c)

    low = c.lower()
    if (
        re.search(r"\b(can you|could you|do you|are you able to)\s+(see|view|look at)\s+(my\s+)?screen\b", low)
        or re.search(r"\b(what('?s| is)\s+(on|happening on)\s+(my\s+)?screen)\b", low)
        or re.search(r"\b(what am i (doing|looking at|working on))\b", low)
        or re.search(r"\b(look at (my|this) screen|read (my|the) screen|scan (my|the) screen|take a screenshot)\b", low)
        or re.search(r"\b(?:give|tell|show)\s+(?:me\s+)?(?:the\s+)?(?:info|information|details|description)\s+(?:on|about)\s+(?:the\s+)?(?:image|picture|photo)\b", low)
        or re.search(r"\b(?:what|whats|what's)\s+(?:is\s+)?(?:in|on)\s+(?:the\s+)?(?:image|picture|photo)\s+(?:i\s+am|im|i'm)\s+(?:seeing|looking at)\b", low)
        or re.search(r"\b(?:describe|analyze|inspect|read)\s+(?:the\s+)?(?:image|picture|photo)\s+(?:i\s+am|im|i'm)\s+(?:seeing|looking at)\b", low)
    ):
        return _handle_screen(c)

    if not _is_complex_agent_request(c):
        return None

    try:
        task = plan_request(c)
        _emit(f"Plan created with {len(task.steps)} steps.", "planner")
        return _execute(task, c)
    except Exception as exc:
        _emit(f"Agent layer failed safely; legacy pipeline retained: {exc}", "recovery")
        try:
            _backend().log_event(f"Advanced agent fallback: {exc}", kind="recovery")
        except Exception:
            pass
        return None


def list_tasks(limit: int = 10) -> list[dict[str, Any]]:
    with _LOCK:
        values = list(_TASKS.values())
    values.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
    return values[:limit]


def _local_vector(text: str, dims: int = 384) -> list[float]:
    """Dependency-free hashed n-gram vector used when an embedding service is absent."""
    tokens = re.findall(r"[a-z0-9]{2,}", text.lower())
    grams = tokens[:]
    grams += [f"{tokens[i]}_{tokens[i+1]}" for i in range(len(tokens)-1)]
    vec = [0.0] * dims
    for token in grams:
        h = int(hashlib.sha256(token.encode()).hexdigest()[:12], 16)
        idx = h % dims
        sign = -1.0 if (h >> 8) & 1 else 1.0
        vec[idx] += sign
    norm = math.sqrt(sum(x*x for x in vec)) or 1.0
    return [x / norm for x in vec]


def remember_semantic(text: str, metadata: Optional[dict[str, Any]] = None):
    text = (text or "").strip()
    if not text:
        return
    entry = {
        "text": text[:3000],
        "metadata": metadata or {},
        "vector": _local_vector(text),
        "ts": time.time(),
    }
    with _LOCK:
        _MEMORY.append(entry)
        del _MEMORY[:-500]
        _save_json(MEMORY_FILE, _MEMORY)


def retrieve_semantic(query: str, top_k: int = 5) -> list[dict[str, Any]]:
    q = _local_vector(query)
    scored = []
    with _LOCK:
        for entry in _MEMORY:
            v = entry.get("vector") or []
            if len(v) != len(q):
                continue
            vector_score = sum(a*b for a,b in zip(q,v))
            score = jfh.hybrid_memory_score(query, entry.get("text", ""), vector_score, entry.get("ts", 0))
            scored.append((score, vector_score, entry))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [{"score": round(s, 4), "semantic_score": round(vs, 4), **e}
            for s,vs,e in scored[:max(1, int(top_k))]]



_LAST_SYSTEM_EVENT = 0.0


def system_snapshot() -> dict[str, Any]:
    """Return CPU/RAM/disk/network/application awareness when psutil is available."""
    data: dict[str, Any] = {
        "timestamp": _dt.datetime.now().isoformat(timespec="seconds"),
        "platform": os.name,
    }
    try:
        import psutil
        vm = psutil.virtual_memory()
        disk = psutil.disk_usage(str(ROOT))
        net = psutil.net_io_counters()
        data.update({
            "cpu_percent": psutil.cpu_percent(interval=None),
            "ram_percent": vm.percent,
            "ram_available_gb": round(vm.available / (1024**3), 2),
            "disk_percent": disk.percent,
            "disk_free_gb": round(disk.free / (1024**3), 2),
            "network_sent_mb": round(net.bytes_sent / (1024**2), 1),
            "network_recv_mb": round(net.bytes_recv / (1024**2), 1),
        })
    except Exception as exc:
        data["error"] = str(exc)
    try:
        data["active_window"] = _backend().get_active_window_title()
    except Exception:
        data["active_window"] = None
    return data


def observation_tick() -> dict[str, Any]:
    """Periodically emit lightweight system awareness to the HUD."""
    global _LAST_SYSTEM_EVENT
    snap = system_snapshot()
    now = time.time()
    if now - _LAST_SYSTEM_EVENT >= 15:
        _LAST_SYSTEM_EVENT = now
        if "cpu_percent" in snap:
            _emit(
                f"System: CPU {snap['cpu_percent']:.0f}% | RAM {snap['ram_percent']:.0f}% | "
                f"Disk {snap['disk_percent']:.0f}%",
                "system",
            )
    return snap

def capture_screen() -> Optional[str]:
    try:
        return str(_vision().get("path"))
    except Exception:
        return None


# ============================================================================
# FRIDAY V87 AGENT FOUNDATION
# ============================================================================
# Additive extension. The legacy handlers above remain intact and are still
# the source of truth for existing commands. This section upgrades the agent
# layer only, so old commands continue to fall through exactly as before.
#
# Research-roadmap coverage:
#   intent -> context -> plan -> tool router -> execute -> observe
#   -> verify -> bounded recovery -> response
# plus permission gates, parallel execution, semantic memory, vision,
# diagnostics/self-test, event stream, plugins, and richer observation.
# ============================================================================

import uuid as _uuid

V87_VERSION = "2040.0-agent-max"
MAX_RECOVERY_ATTEMPTS = 3
_PLUGIN_REGISTRY: dict[str, dict[str, Any]] = {}
_OBSERVATION_FILE = ROOT / "friday_observations.json"
_OBSERVATION_HISTORY: list[dict[str, Any]] = _load_json(_OBSERVATION_FILE, [])
if not isinstance(_OBSERVATION_HISTORY, list):
    _OBSERVATION_HISTORY = []


def register_tool(name: str, handler: Callable[..., Any], *,
                  permission: int = 0, description: str = "",
                  verifier: Optional[Callable[..., Any]] = None) -> bool:
    """Register an additive FRIDAY tool.

    Plugins are deliberately data-driven and isolated from the legacy command
    dispatcher. A malformed plugin can therefore be rejected without changing
    existing features.
    """
    clean = re.sub(r"[^a-zA-Z0-9_.-]", "_", str(name or "").strip())
    if not clean or not callable(handler):
        return False
    if not isinstance(permission, int) or permission < 0 or permission > 4:
        return False
    _PLUGIN_REGISTRY[clean] = {
        "handler": handler,
        "permission": permission,
        "description": description or clean,
        "verifier": verifier,
    }
    return True


def unregister_tool(name: str) -> bool:
    return _PLUGIN_REGISTRY.pop(str(name), None) is not None


def list_tools() -> list[dict[str, Any]]:
    return [
        {"name": n, "permission": v["permission"], "description": v["description"]}
        for n, v in sorted(_PLUGIN_REGISTRY.items())
    ]


def _safe_text(value: Any, limit: int = 1200) -> str:
    try:
        return str(value)[:limit]
    except Exception:
        return "<unprintable>"


def observation_snapshot(command: Optional[str] = None) -> dict[str, Any]:
    """Capture the permitted contextual state described by the research doc."""
    try:
        jb = _backend()
        state = getattr(jb, "study_state", {}) or {}
        snap = {
            "timestamp": _dt.datetime.now().isoformat(timespec="seconds"),
            "current_application": jb.get_active_window_title(),
            "current_mode": "study" if state.get("active") else "normal",
            "active_task": state.get("topic"),
            "recent_commands": [
                x.get("command") for x in list(_load_json(
                    getattr(jb, "friday_agent_core", None).STATE_FILE
                    if hasattr(getattr(jb, "friday_agent_core", None), "STATE_FILE")
                    else ROOT / "friday_agent_state.json", {}
                ).get("recent_turns", []))[-8:]
                if isinstance(x, dict)
            ],
            "last_command": command or _load_json(ROOT / "friday_agent_state.json", {}).get("last_command"),
            "last_tool_result": _load_json(ROOT / "friday_agent_state.json", {}).get("last_result"),
            "system": system_snapshot(),
        }
    except Exception as exc:
        snap = {
            "timestamp": _dt.datetime.now().isoformat(timespec="seconds"),
            "current_application": None,
            "current_mode": "unknown",
            "active_task": None,
            "recent_commands": [],
            "last_command": command,
            "last_tool_result": None,
            "system": {},
            "error": _safe_text(exc),
        }
    with _LOCK:
        _OBSERVATION_HISTORY.append(snap)
        del _OBSERVATION_HISTORY[:-100]
        _save_json(_OBSERVATION_FILE, _OBSERVATION_HISTORY)
    return snap


def _register_builtin_tools() -> None:
    # These wrappers are intentionally tiny. The actual implementations remain
    # in the existing modules, preventing duplicate logic.
    register_tool("web_research", _research, permission=0,
                  description="Multi-source web research with source extraction.")
    register_tool("youtube_research", _youtube, permission=0,
                  description="YouTube discovery and transcript-grounded research.")
    register_tool("vision", lambda: _vision(), permission=0,
                  description="Screen capture and optional Gemini visual analysis.")
    register_tool("document_creation", _create_documents, permission=2,
                  description="Create PDF/DOCX/XLSX/PPTX using the existing creation engine.")
    register_tool("study", lambda command: _backend().handle_study_command(command),
                  permission=0, description="Existing adaptive Study Mode engine.")
    register_tool("system_snapshot", system_snapshot, permission=0,
                  description="CPU/RAM/disk/network/application snapshot.")
_register_builtin_tools()


def _intent_features(command: str) -> dict[str, Any]:
    """Cheap structured intent extraction before an optional LLM planner."""
    c = command.strip()
    low = c.lower()
    features = {
        "raw": c,
        "is_research": bool(re.search(r"\b(research|sources?|investigate|according to)\b", low)),
        "is_youtube": bool(re.search(r"\b(youtube|videos?|watch)\b", low)),
        "is_document": bool(re.search(
            r"\b(create|make|write|generate|turn .* into)\b.*\b(pdf|docx|word|spreadsheet|xlsx|slides?|presentation|notes)\b",
            low,
        )),
        "is_vision": bool(re.search(
            r"\b(what('?s| is) on my screen|look at (this|my) screen|screenshot|look at this)\b", low)),
        "is_study": bool(re.search(r"\b(test me|quiz me|active recall|study mode|study plan|flashcards?)\b", low)),
        "is_open": bool(re.search(r"\b(open|launch|start)\b", low)),
        "is_message": bool(re.search(r"\b(send|message|whatsapp|email)\b", low)),
        "is_destructive": bool(re.search(r"\b(delete|remove|shutdown|shut down|restart|power off)\b", low)),
        "has_multiple_objectives": sum(low.count(x) for x in
                                      (" and ", " then ", " also ", " as well as ")) >= 1,
    }
    return features


def _extract_open_target(command: str) -> Optional[str]:
    # Compound browser request: "open a new tab in Google and type ..."
    # should target Chrome/Google, not an application literally named
    # "a new tab in Google".
    if re.search(
        r"\b(?:open|launch|start)\s+(?:a\s+)?new\s+tab\s+(?:in|on|using)\s+(?:google(?:\s+chrome)?|chrome|the\s+browser)\b",
        command, re.I
    ):
        return "Google Chrome"
    m = re.search(r"\b(?:open|launch|start)\s+(.+?)(?=\s+(?:and|then|also)\s+|$)", command, re.I)
    return m.group(1).strip(" .,:;") if m else None


def _extract_research_topic(command: str) -> str:
    return _topic_from_command(command)


def _llm_plan(command: str) -> Optional[list[TaskStep]]:
    """Optional structured planner. Disabled unless explicitly enabled.

    Deterministic planning is the default because it is safer and preserves
    existing behaviour. Setting FRIDAY_LLM_PLANNER=1 enables a strict JSON
    planning pass when Gemini is configured.
    """
    if os.getenv("FRIDAY_LLM_PLANNER", "").strip().lower() not in {"1", "true", "yes", "on"}:
        return None
    try:
        jb = _backend()
        jb._ensure_gemini_client()
        client = getattr(jb, "client", None)
        if client is None:
            return None
        prompt = """Return ONLY JSON: {"steps":[{"name":"...","tool":"...","dependencies":[]}]}.
Choose only these tools: web_research,youtube_research,document_creation,vision,study,
computer_control,communication. Do not invent tools. Make independent research/video
steps dependency-free; documents depend on research if research is requested.
User request: """ + command
        response = client.models.generate_content(model=jb.GEMINI_MODEL, contents=prompt)
        raw = (getattr(response, "text", None) or "").strip()
        match = re.search(r"\{.*\}", raw, re.S)
        if not match:
            return None
        data = json.loads(match.group(0))
        result = []
        allowed = {
            "web_research", "youtube_research", "document_creation", "vision",
            "study", "computer_control", "communication"
        }
        for item in data.get("steps", []):
            if not isinstance(item, dict) or item.get("tool") not in allowed:
                return None
            result.append(TaskStep(
                str(item.get("name") or item["tool"]),
                item["tool"],
                dependencies=[str(x) for x in item.get("dependencies", [])],
            ))
        ok, reason = jfh.validate_plan(result)
        if not ok:
            _emit(f"LLM planner rejected unsafe/malformed plan: {reason}", "planner")
            return None
        return result or None
    except Exception as exc:
        _emit(f"LLM planner skipped safely: {_safe_text(exc)}", "planner")
        return None


def plan_request_v87(command: str) -> AgentTask:
    """Build a dependency-aware plan and attach intent/context metadata."""
    features = _intent_features(command)
    steps = _llm_plan(command)

    if not steps:
        steps = []
        if features["is_research"]:
            steps.append(TaskStep("Research reliable web sources", "web_research"))
        if features["is_youtube"]:
            steps.append(TaskStep("Research relevant YouTube sources", "youtube_research"))
        if features["is_vision"]:
            steps.append(TaskStep("Inspect the current screen", "vision"))
        if features["is_open"]:
            steps.append(TaskStep("Open the requested application/site", "computer_control"))
        if features["is_message"]:
            steps.append(TaskStep("Handle the requested communication", "communication"))
        if features["is_study"]:
            steps.append(TaskStep("Run the Study Mode workflow", "study"))
        if features["is_document"]:
            deps = [s.name for s in steps if s.tool in {"web_research", "youtube_research"}]
            steps.append(TaskStep("Create the requested document", "document_creation", dependencies=deps))
        if not steps:
            steps.append(TaskStep("Use the existing FRIDAY reasoning engine", "reasoning"))

    ok, reason = jfh.validate_plan(steps)
    if not ok:
        # Deterministic fallback: strip dependencies rather than executing a malformed graph.
        _emit(f"Plan validation fallback: {reason}", "planner")
        steps = [TaskStep(s.name, s.tool) for s in steps]
    task = create_task(command, steps)
    task.dependencies = [s.name for s in steps for _ in [0] if s.dependencies]
    # V2041 cognitive contract: deeper goal state, adaptive policy, resource
    # limits and long-term learning metadata. This is agent-layer only.
    try:
        contract = _cognitive.build_cognitive_contract(command, {"steps":[s.tool for s in steps]})
        _cognitive.start_goal(command, contract)
        task.final_result = {**(task.final_result or {}), "cognitive_contract": contract,
                             "adaptive_policy": _cognitive.adaptive_recommendation(command, contract["profile"]),
                             "resource_policy": _cognitive.resource_policy(contract["profile"])}
    except Exception:
        pass
    # MAX intelligence contract: every complex task carries an explicit
    # execution blueprint, risk model and verification gates. This is metadata
    # only; it does not alter the voice/listening/recognition path.
    try:
        blueprint = _intelligence_hub.build_execution_blueprint(command)
        request_analysis = blueprint.get("analysis", {})
    except Exception:
        blueprint = {}
        request_analysis = {}
    task.final_result = {"intent_confidence": jfh.intent_confidence(features, command),
                         "plan_validated": True,
                         "intelligence_version": _intelligence_hub.VERSION,
                         "blueprint": blueprint,
                         "risk": request_analysis.get("risk", "normal"),
                         "ambiguity": request_analysis.get("ambiguity", 0.0)}
    context_reference = None
    try:
        import friday_agent_core
        ref = friday_agent_core.resolve_reference(command)
        context_reference = jfh.normalize(ref) if ref else None
    except Exception:
        context_reference = None
    task.final_result = {
        "intent": features,
        "intent_confidence": jfh.intent_confidence(features, command),
        "context_reference": context_reference,
        "observation": observation_snapshot(command),
        "intelligence": _intelligence_hub.quality_summary(command),
    }
    try:
        contract = _cognitive.build_cognitive_contract(command, {"steps":[s.tool for s in steps]})
        _cognitive.start_goal(command, contract)
        task.final_result.update({"cognitive_contract": contract,
                                  "adaptive_policy": _cognitive.adaptive_recommendation(command, contract["profile"]),
                                  "resource_policy": _cognitive.resource_policy(contract["profile"])})
    except Exception:
        pass
    # V2042 proactive reasoning: anticipate prerequisites, ambiguity, useful
    # follow-ups and verification opportunities without changing execution or
    # taking consequential actions autonomously.
    try:
        proactive = _proactive.analyze(
            command,
            task_steps=[s.tool for s in steps],
            recent_errors=task.errors,
        )
        task.final_result.update({"proactive_reasoning": proactive})
    except Exception:
        pass
    update_task(task, final_result=task.final_result)
    return task


# Keep the public API name used by the original module.
plan_request = plan_request_v87


def _verify_step(tool: str, result: Any) -> dict[str, Any]:
    """Independent verification; never treats a returned value as proof alone."""
    check: dict[str, Any] = {
        "tool": tool, "checked_at": _dt.datetime.now().isoformat(timespec="seconds"),
        "ok": False, "detail": ""
    }
    try:
        if tool in {"web_research", "youtube_research"}:
            count_key = "sources" if tool == "web_research" else "videos"
            count = len(result.get(count_key, [])) if isinstance(result, dict) else 0
            fallback = bool(result.get("fallback")) if isinstance(result, dict) else False
            if isinstance(result, dict):
                audit = _intelligence_hub.audit_research(result)
                result["intelligence_audit"] = audit
            else:
                audit = {}
            usable = count > 0 or fallback
            diversity_ok = (audit.get("unique_domains", 0) >= 2) if tool == "web_research" else count >= 1
            check.update(ok=bool(usable), detail=f"{count} usable {count_key}; diversity={'ok' if diversity_ok else 'limited'}; source-signal={audit.get('mean_source_signal', 0)}" + ("; AI fallback" if fallback else ""))
        elif tool == "vision":
            path = result.get("path") if isinstance(result, dict) else None
            v = verify_path(path) if path else {"valid": False}
            check.update(ok=bool(v.get("valid")), detail=_safe_text(v))
        elif tool == "document_creation":
            candidates = []
            # V2037: the creation engine records exactly what it wrote (and where).
            if isinstance(result, dict):
                candidates.extend(str(f) for f in (result.get("files") or []))
            if isinstance(result, dict):
                handler = result.get("handler_result")
                if isinstance(handler, (str, Path)):
                    candidates.append(handler)
                elif isinstance(handler, dict):
                    for v in handler.values():
                        if isinstance(v, str) and Path(v).suffix.lower() in {".pdf",".docx",".xlsx",".pptx"}:
                            candidates.append(v)
            if not candidates:
                # Creation engine may not return a path; recent-output scan is
                # the independent fallback verifier.
                # The creation engine saves to ~/Documents/FRIDAY Projects (older builds used
                # study_files/projects). Research + planning can take minutes, so look back 20 min.
                cutoff = time.time() - 1200
                roots = [ROOT / "study_files" / "projects"]
                try:
                    roots.append(Path(_backend().friday_creation_engine.PROJECTS_ROOT))
                except Exception:
                    roots.append(Path.home() / "Documents" / "FRIDAY Projects")
                for projects in roots:
                    if projects.exists():
                        candidates += [str(p) for p in projects.rglob("*")
                                       if p.is_file() and p.stat().st_mtime >= cutoff]
            checks = [verify_path(p) for p in candidates
                      if Path(p).suffix.lower() in {".pdf",".docx",".xlsx",".pptx"}]
            check.update(ok=bool(checks) and all(
                x.get("exists") and x.get("size",0)>0 and x.get("readable") and x.get("valid")
                for x in checks), detail=_safe_text(checks))
        elif tool == "computer_control":
            target = result.get("target") if isinstance(result, dict) else None
            active = _backend().get_active_window_title()
            explicit_verified = bool(result.get("verified")) if isinstance(result, dict) else False
            verification = result.get("verification") if isinstance(result, dict) else None
            nested = result.get("result") if isinstance(result, dict) else None
            if isinstance(nested, dict):
                explicit_verified = explicit_verified or bool(nested.get("verified"))
                verification = verification or nested.get("evidence")
            # A browser-control result is valid only when the action itself
            # reports independent verification. For simple app opens, the
            # active-window check remains the compatibility fallback.
            if isinstance(result, dict) and result.get("search_query"):
                ok = explicit_verified and bool(verification and verification.get("ok"))
                detail = f"active_window={active!r}, target={target!r}, search={result.get('search_query')!r}, verified={ok}"
            else:
                ok = explicit_verified and bool(active)
                detail = f"active_window={active!r}, target={target!r}, verified={ok}"
            check.update(ok=ok, detail=detail)
        elif tool in {"study", "communication"}:
            check.update(ok=result is True or bool(result), detail=_safe_text(result))
        elif tool == "system_snapshot":
            check.update(ok=isinstance(result, dict) and "timestamp" in result, detail=_safe_text(result))
        else:
            check.update(ok=result is not None, detail=_safe_text(result))
    except Exception as exc:
        check["detail"] = f"{type(exc).__name__}: {exc}"
    return check


def _extract_browser_search(command: str) -> Optional[str]:
    """Extract a second-stage browser search from a compound request.

    This intentionally runs after open/launch parsing so a request such as
    ``open Google and show me search results for Gojo cat`` becomes a single
    computer task with two dependent actions instead of being reported as
    complete after the first action.
    """
    text = re.sub(r"\s+", " ", str(command or "")).strip(" .,:;!?\t")
    # "type X in the search bar" is a typing action, not a search-query
    # extraction request. Prevent "bar" from being mistaken for the query.
    if _extract_browser_typing(text):
        return None

    patterns = [
        r"\b(?:show|display) (?:me )?(?:the )?(?:search )?results? (?:for|on)\s+(.+)$",
        r"\bsearch (?:for )?(.+)$",
        r"\blook up\s+(.+)$",
        r"\bfind (?:the )?(?:search )?results? (?:for|on)\s+(.+)$",
    ]
    for pattern in patterns:
        m = re.search(pattern, text, re.I)
        if m:
            query = m.group(1).strip(" .,:;!?\t")
            if query:
                # V2044 FIX: strip a trailing engine mention ("... orbitals in google") that the
                # patterns above don't account for, using the same trailing-cleanup friday_nlu
                # applies elsewhere, so the two extractors never drift back out of sync.
                if _nlu is not None:
                    try:
                        cleaned = _nlu.extract_search("search for " + query)
                        if cleaned is not None and cleaned.query:
                            return cleaned.query
                    except Exception:
                        pass
                return query
    return None



def _extract_browser_typing(command: str) -> Optional[str]:
    """Extract text explicitly requested for a browser search/address bar."""
    text = re.sub(r"\s+", " ", str(command or "")).strip(" .,:;!?\t")
    patterns = [
        r"\b(?:type|enter|write)\s+[\"']?(.+?)[\"']?\s+in(?:to)?\s+(?:the\s+)?(?:google\s+)?(?:search|address|omnibox)\s*(?:bar)?\b",
        r"\b(?:type|enter|write)\s+[\"']?(.+?)[\"']?\s+(?:in|into)\s+(?:the\s+)?(?:search|address|omnibox)\s*(?:bar)?\b",
    ]
    for pattern in patterns:
        m = re.search(pattern, text, re.I)
        if m:
            value = m.group(1).strip(" .,:;!?\"'")
            if value:
                return value
    return None

def _is_chrome_google_target(target: str) -> bool:
    t = str(target or "").lower()
    return any(x in t for x in ("chrome", "google chrome", "google", "browser"))

def _browser_search_url(target: str, query: str) -> Optional[str]:
    """Return a deterministic search URL for common browser destinations."""
    from urllib.parse import quote_plus
    site = str(target or "").lower()
    q = quote_plus(query.strip())
    if "youtube" in site:
        return f"https://www.youtube.com/results?search_query={q}"
    if "bing" in site:
        return f"https://www.bing.com/search?q={q}"
    if "duckduckgo" in site or "duck duck go" in site:
        return f"https://duckduckgo.com/?q={q}"
    if "google" in site or site in {"chrome", "google chrome", "browser", "web browser"}:
        return f"https://www.google.com/search?q={q}"
    return None


def _verify_browser_search(query: str, target: str) -> dict[str, Any]:
    """Verify the visible browser reached the requested search state.

    Verification uses independent evidence: active-window title plus OCR of a
    fresh screenshot. A successful call to webbrowser.open() is never treated
    as proof that the requested search results are actually visible.
    """
    jb = _backend()
    expected_tokens = [t.lower() for t in re.findall(r"[a-z0-9]+", query.lower()) if len(t) > 1]
    last = {"ok": False, "detail": "Search state not yet verified"}
    for attempt in range(3):
        if attempt:
            time.sleep(1.0)
        try:
            active = (jb.get_active_window_title() or "").lower()
        except Exception:
            active = ""
        try:
            import mss
            from PIL import Image
            import pytesseract
            verification_path = SCREEN_DIR / "agent_verification_latest.png"
            with mss.mss() as sct:
                monitor = sct.monitors[0]
                shot = sct.grab(monitor)
                Image.frombytes("RGB", shot.size, shot.rgb).save(verification_path)
            ocr = pytesseract.image_to_string(str(verification_path), config="--psm 6")[:16000].lower()
        except Exception as exc:
            ocr = ""
            last = {"ok": False, "detail": f"OCR verification unavailable: {exc}"}
        combined = f"{active}\n{ocr}"
        # Google may legitimately stop an automated-looking request with a
        # CAPTCHA/unusual-traffic page. Never treat that page as a successful
        # search state.
        if any(marker in combined for marker in (
            "unusual traffic", "i'm not a robot", "im not a robot",
            "recaptcha", "automated queries"
        )):
            return {
                "ok": False,
                "query": query,
                "target": target,
                "active_window": active,
                "evidence": {"captcha": True},
                "detail": "Google requested human verification before showing the search results.",
            }
        token_hits = sum(1 for token in expected_tokens if token in combined)
        query_hit = bool(expected_tokens) and token_hits >= max(1, min(2, len(expected_tokens)))
        if _is_chrome_google_target(target):
            browser_hit = "google chrome" in combined or "chrome" in combined
        else:
            browser_hit = any(name in combined for name in ("google", "bing", "youtube", "duckduckgo", "chrome"))
        if query_hit and browser_hit:
            return {
                "ok": True,
                "query": query,
                "target": target,
                "active_window": active,
                "evidence": {"token_hits": token_hits, "token_count": len(expected_tokens)},
                "attempt": attempt + 1,
            }
        last = {
            "ok": False,
            "query": query,
            "target": target,
            "active_window": active,
            "evidence": {"token_hits": token_hits, "token_count": len(expected_tokens)},
            "detail": "Browser opened, but the requested search state was not independently verified.",
        }
    return last


def _execute_computer_control(command: str) -> dict[str, Any]:
    # First give the dedicated desktop adapter a chance for direct, explicit
    # mouse/keyboard/window/media/file/browser operations. This closes the old
    # routing gap where the advanced agent only recognized "open/launch/start"
    # and therefore sent natural commands such as "click the Save button" or
    # "scroll down" to the general AI instead of operating Windows.
    low = str(command or "").lower().strip()

    # Explicit packaged-app opens are routed through the dedicated desktop
    # adapter. This keeps WhatsApp/WPS out of the generative response path.
    if re.search(r"\\b(?:open|launch|start)\\s+(?:the\\s+)?(?:wps(?:\\s+office)?|kingsoft\\s+wps|wps\\s+(?:writer|spreadsheet|presentation))\\b", low):
        try:
            from friday_desktop_agent import handle as desktop_handle
            direct = desktop_handle(command)
            result = direct.get("result") if isinstance(direct, dict) else None
            if isinstance(direct, dict) and direct.get("handled") and isinstance(result, dict) and result.get("ok") and result.get("verified"):
                return {"target": "WPS Office", "handler_result": result, "verified": True,
                        "active_window": _backend().get_active_window_title(),
                        "verification": {"ok": True, "method": "Windows Search + foreground-window verification"}}
            raise RuntimeError("WPS Office was not verified in the foreground.")
        except Exception as exc:
            raise RuntimeError(f"WPS Office could not be opened and verified: {exc}") from exc

    # Explicit WhatsApp-open requests must open the installed Windows app rather
    # than entering the message-confirmation flow. Use the same Windows Search
    # path already used by the existing WhatsApp sender, then verify the window.
    if re.search(r"\b(?:open|launch|start)\s+(?:the\s+)?whats(?:app|s app)\s*(?:app)?\b", low):
        try:
            import pyautogui
            pyautogui.hotkey("win", "s")
            time.sleep(0.45)
            pyautogui.write("WhatsApp", interval=0.02)
            time.sleep(0.75)
            pyautogui.press("enter")
            deadline = time.time() + 6.0
            while time.time() < deadline:
                title = str(_backend().get_active_window_title() or "")
                if "whatsapp" in title.lower():
                    return {"target":"WhatsApp", "verified":True, "active_window":title,
                            "verification":{"ok":True,"method":"Windows Search + foreground-window verification"}}
                time.sleep(0.25)
            raise RuntimeError("WhatsApp opened, but its foreground window could not be verified.")
        except Exception as exc:
            raise RuntimeError(f"WhatsApp could not be opened and verified: {exc}") from exc

    direct_patterns = (
        r"\bclick\b", r"\bdouble[- ]click\b", r"\bright[- ]click\b",
        r"\bmiddle[- ]click\b", r"\bmove cursor\b", r"\btype\b", r"\bwrite\b",
        r"\bselect all\b", r"\bcopy\b", r"\bcut\b", r"\bpaste\b", r"\bscroll\b",
        r"\bnew tab\b", r"\bclose (?:the )?tab\b", r"\bnext tab\b",
        r"\bprevious tab\b", r"\bswitch tab\b", r"\bvolume (?:up|down)\b",
        r"\b(?:increase|decrease) volume\b", r"\bmute\b", r"\bpause\b", r"^(?:please\s+)?play(?:\s+(?:the\s+)?(?:music|song|video|it|playback))?\s*$",
        r"\b(?:skip|next song|next track|previous song|previous track)\b",
        r"\b(?:minimi[sz]e|maximi[sz]e|restore|switch) (?:the )?(?:window|windows)\b",
    )
    if any(re.search(p, low) for p in direct_patterns):
        try:
            from friday_desktop_agent import handle as desktop_handle
            direct = desktop_handle(command)
            if isinstance(direct, dict) and direct.get("handled"):
                result = direct.get("result")
                if isinstance(result, dict) and (result.get("ok") or result.get("verified")):
                    return {"target": "desktop", "handler_result": result, "active_window": _backend().get_active_window_title(),
                            "verified": True, "verification": {"ok": True, "method": "dedicated Windows desktop adapter"}}
                # A direct adapter failure should be surfaced rather than
                # silently pretending that an action happened.
                return {"target": "desktop", "handler_result": result, "active_window": _backend().get_active_window_title(),
                        "verified": False, "verification": {"ok": False, "method": "dedicated Windows desktop adapter"}}
        except Exception as exc:
            _emit(f"Direct desktop adapter failed: {_safe_text(exc)}", "recovery")

    target = _extract_open_target(command)
    if not target:
        raise RuntimeError("No application or site was identified for the open/launch request.")
    jb = _backend()

    # Browser automation gets a dedicated Chrome controller. This avoids
    # Windows' default-browser association (which may be Edge) and keeps the
    # visible UI as the source of truth.
    browser_target = _is_chrome_google_target(target)
    browser_typing = _extract_browser_typing(command)
    if browser_target and browser_typing:
        from friday_desktop_agent import chrome_type_in_search_bar
        _emit(f"Computer agent: opening Google Chrome and entering {browser_typing}", "computer")
        result = chrome_type_in_search_bar(browser_typing, open_google=True)
        if not result.get("ok"):
            raise RuntimeError(result.get("error") or "Chrome could not be controlled.")
        return {
            "target": target,
            "handler_result": result,
            "active_window": jb.get_active_window_title(),
            "search_query": browser_typing,
            "search_url": "https://www.google.com/search?q=" + quote_plus(browser_typing),
            "verified": bool(result.get("verified")),
            "verification": {
                "ok": bool(result.get("verified")),
                "method": "visible Chrome UI",
            },
        }

    # Delegate ordinary app/site opens to the existing parser.
    result = jb.handle_command("open " + target)

    query = _extract_browser_search(command)
    search_url = _browser_search_url(target, query) if query else None
    if query and search_url:
        _emit(f"Computer agent: continuing to the search results for {query}", "computer")
        from friday_desktop_agent import chrome_search
        opened = chrome_search(query, new_tab=True)
        if not opened.get("ok"):
            raise RuntimeError(opened.get("error") or "Chrome search could not be opened.")
        verification = _verify_browser_search(query, target)
        if not verification.get("ok"):
            _emit("Search results were not verified; attempting one Chrome recovery.", "recovery")
            chrome_search(query, new_tab=True)
            verification = _verify_browser_search(query, target)
        if not verification.get("ok"):
            raise RuntimeError(verification.get("detail") or "Search results could not be verified.")
        return {
            "target": target,
            "handler_result": result,
            "active_window": jb.get_active_window_title(),
            "search_query": query,
            "search_url": search_url,
            "verified": True,
            "verification": verification,
        }

    if not isinstance(result, dict) or not result.get("handled"):
        raise RuntimeError("Desktop open request was not handled by the primary controller.")
    handler_result=result.get("result")
    verified=bool(isinstance(handler_result, dict) and handler_result.get("ok") and handler_result.get("verified"))
    if not verified:
        raise RuntimeError("Desktop open was executed but its final state was not independently verified.")
    return {"target": target, "handler_result": handler_result, "active_window": jb.get_active_window_title(), "verified": True,
            "verification": {"ok": True, "method": "primary desktop controller post-state evidence"}}


def _execute_communication(command: str) -> Any:
    # Do not bypass the existing WhatsApp confirmation machinery.  The legacy
    # backend returns True for both "preview/confirmation requested" and
    # "message actually sent", so a bare boolean is unsafe for the advanced
    # agent: it can otherwise turn a prepared message into a false "sent"
    # announcement.  Inspect the session state after the call and return an
    # explicit status.
    jb = _backend()
    before = getattr(jb, "_wa_session", None)
    result = jb.handle_command(command)
    after = getattr(jb, "_wa_session", None)

    if isinstance(after, dict) and after.get("stage") == "confirm":
        return {
            "handled": True,
            "status": "confirmation_required",
            "verified": False,
            "contact": after.get("contact"),
            "message": after.get("message"),
            "backend_result": result,
        }
    # A direct send/cancel continuation resets the session.  The backend's
    # continuation only returns True after send_whatsapp_message() itself
    # returned success, so this is the only point at which a sent result can
    # be reported.
    if before and isinstance(before, dict) and before.get("stage") == "confirm" and after is None:
        return {
            "handled": True,
            "status": "completed_or_cancelled",
            "verified": bool(result),
            "backend_result": result,
        }
    return {
        "handled": bool(result is not None),
        "status": "handled",
        "verified": False,
        "backend_result": result,
    }


def _execute_step(tool: str, command: str, research: Optional[dict[str, Any]] = None) -> Any:
    # Voice capture/listening is deliberately NOT routed through this layer.
    # This hardening applies only after recognition, so the established
    # microphone/listening mechanism remains unchanged.
    def _run():
        if tool == "web_research":
            return _research(_extract_research_topic(command))
        if tool == "youtube_research":
            return _youtube(_extract_research_topic(command))
        if tool == "vision":
            return _vision()
        if tool == "document_creation":
            return _create_documents(command, research=research)
        if tool == "study":
            return _backend().handle_study_command(command)
        if tool == "computer_control":
            return _execute_computer_control(command)
        if tool == "communication":
            return _execute_communication(command)
        if tool == "system_snapshot":
            return system_snapshot()
        if tool in _PLUGIN_REGISTRY:
            return _PLUGIN_REGISTRY[tool]["handler"](command)
        if tool == "reasoning":
            return None
        raise RuntimeError(f"Unknown agent tool: {tool}")

    # Never automatically repeat external communication: duplicate messages
    # are worse than a recoverable transient error. All other agent tools are
    # idempotent/read-only or already have their own verification/recovery.
    if tool == "communication":
        return _run()
    try:
        from friday_quality import run as _quality_run, result_ok as _quality_ok
        # Do not repeat potentially non-idempotent operations such as document
        # creation. The agent's explicit recovery path handles those safely.
        attempts = 1 if tool in {"document_creation", "computer_control"} else 2
        return _quality_run(f"agent.{tool}", _run, attempts=attempts, verify=_quality_ok)
    except ImportError:
        return _run()


def _recover(tool: str, command: str, error: Exception, research: Optional[dict[str, Any]] = None) -> Any:
    """Bounded, tool-specific recovery; never loops indefinitely."""
    _emit(f"Recovery for {tool}: {type(error).__name__}: {_safe_text(error)}", "recovery")
    if tool == "web_research":
        # Re-enter the complete multi-backend research pipeline so search,
        # fetching, source validation and AI fallback all get another chance.
        return _backend().friday_web_research.run_web_research(
            _extract_research_topic(command), use_cache=False)
    if tool == "youtube_research":
        return _backend().friday_youtube_research.gather_youtube_sources(
            _extract_research_topic(command), depth=2)
    if tool == "document_creation":
        # Never write a second copy if the first one was actually produced.
        try:
            proj = _backend().friday_creation_engine.LAST_PROJECT
            if proj.get("ok") and time.time() - float(proj.get("time") or 0) < 1200:
                return {"topic": proj.get("topic"), "handler_result": True, "files": list(proj.get("files") or [])}
        except Exception:
            pass
        return _create_documents(command, research=None)
    raise error


def _execute_v87(task: AgentTask, command: str) -> bool:
    jb = _backend()
    update_task(task, status="running")
    jb.emit_progress(5, "Request understood — building a verified agent plan", task=task.objective)

    level, label = permission_required(command)
    if level >= 4:
        jb.speak(f"This action requires explicit confirmation: {label}. Please use the existing confirmation controls.")
        update_task(task, status="awaiting_confirmation")
        return True
    if level >= 3 and ("whatsapp" in command.lower() or "message" in command.lower() or "email" in command.lower()):
        # Existing communication confirmation remains authoritative. Returning
        # None is essential: process_command() treats False as an exit request.
        return None

    completed: dict[str, Any] = {}
    failed = False
    remaining = list(task.steps)

    while remaining:
        # V2037: a document step only *prefers* research. If the research step failed (offline,
        # blocked, rate-limited) the creation engine still has its own research + reference-library
        # fallbacks, so the document is attempted instead of being silently skipped.
        ready = [s for s in remaining if all(
            any(done.name == dep and (done.status == "verified" or (done.status == "failed" and s.tool == "document_creation"))
                for done in task.steps)
            for dep in s.dependencies
        )]
        # Avoid deadlocks caused by a malformed dependency graph.
        if not ready:
            for s in remaining:
                if s.dependencies:
                    task.errors.append(f"Unresolvable dependencies for step: {s.name}")
            failed = True
            break

        # Independent read-only work is genuinely parallel.
        parallel = [s for s in ready if s.tool in {"web_research", "youtube_research", "vision"}]
        serial = [s for s in ready if s not in parallel]
        batch = parallel if len(parallel) > 1 else serial[:1] or parallel[:1]

        def run_one(step: TaskStep):
            step.status = "running"
            task.current_step = task.steps.index(step)
            update_task(task)
            try:
                res = _execute_step(step.tool, command, completed.get("web_research"))
                verification = _verify_step(step.tool, res)
                if not verification["ok"]:
                    raise RuntimeError(f"Verification failed: {verification['detail']}")
                step.result = res
                step.verification.append(verification)
                step.status = "verified"
                task.tools_used.append(step.tool)
                try:
                    jfh.checkpoint(task.task_id, {
                        "status": "step_verified",
                        "current_step": task.current_step,
                        "tool": step.tool,
                        "verified": True,
                    })
                except Exception:
                    pass
                return step, res, None
            except Exception as first_exc:
                # At most one alternate attempt for most tools; creation has
                # its own existing recovery plus this bounded layer.
                for attempt in range(1, MAX_RECOVERY_ATTEMPTS):
                    try:
                        res = _recover(step.tool, command, first_exc, completed.get("web_research"))
                        verification = _verify_step(step.tool, res)
                        if verification["ok"]:
                            step.result = res
                            step.verification.append({"attempt": attempt, **verification})
                            step.status = "verified"
                            task.tools_used.append(step.tool)
                            return step, res, None
                    except Exception as retry_exc:
                        first_exc = retry_exc
                step.status = "failed"
                step.error = _safe_text(first_exc)
                return step, None, first_exc

        if len(batch) > 1:
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(batch))) as pool:
                outcomes = list(pool.map(run_one, batch))
        else:
            outcomes = [run_one(batch[0])]

        for step, result, error in outcomes:
            remaining.remove(step)
            if error is not None:
                failed = True
                task.errors.append(f"{step.tool}: {_safe_text(error)}")
            else:
                completed[step.tool] = result
                task.verification.extend(step.verification)

    task.final_result = {
        "tools_used": list(dict.fromkeys(task.tools_used)),
        "results": {
            k: (_safe_text(v, 4000) if k not in {"web_research","youtube_research"} else
                {"count": len(v.get("sources", [])) if k=="web_research" else len(v.get("videos", []))})
            for k, v in completed.items()
        },
        "observation": observation_snapshot(command),
        "verification": task.verification,
        "errors": task.errors,
    }
    try:
        cognitive_audit = _cognitive.audit_result(command, "completed_with_errors" if failed else "completed", task.verification)
        task.final_result["cognitive_audit"] = cognitive_audit
        _cognitive.finish_goal(command, "completed_with_errors" if failed else "completed", cognitive_audit)
        _cognitive.remember_episode(command, "success" if not failed else "partial_failure", list(dict.fromkeys(task.tools_used)), cognitive_audit)
        _cognitive.learn_relationships(command, list(dict.fromkeys(task.tools_used)), "success" if not failed else "partial_failure")
    except Exception:
        pass
    try:
        # Feed only the compact outcome back into the proactive layer. The
        # engine learns patterns for future planning; it does not auto-act.
        _proactive.record_outcome(
            command,
            "partial_failure" if failed else "success",
            followup_taken=None,
        )
        proactive = _proactive.analyze(
            command,
            task_steps=[s.tool for s in task.steps],
            recent_errors=task.errors,
        )
        task.final_result["proactive_reasoning"] = proactive
        task.final_result["proactive_health"] = _proactive.health()
    except Exception:
        pass
    update_task(task, status="completed_with_errors" if failed else "completed")

    try:
        jb.emit_progress(100, "Agent task completed with verification" if not failed
                         else "Agent task completed with reported errors",
                         task=task.objective)
    except Exception:
        pass

    # Persist a compact semantic memory record without storing credentials or
    # raw screen contents.
    try:
        memory_text = (
            f"Request: {command}\nTools: {', '.join(task.tools_used)}\n"
            f"Outcome: {'success' if not failed else 'partial/failure'}"
        )
        remember_semantic(
            memory_text,
            metadata={"task_id": task.task_id, "status": task.status,
                      "importance": _intelligence_hub.memory_importance(memory_text, {"task_id": task.task_id, "status": task.status}),
                      "intelligence_version": _intelligence_hub.VERSION},
        )
    except Exception:
        pass

    if not failed:
        computer_result = completed.get("computer_control")
        if isinstance(computer_result, dict) and computer_result.get("search_query"):
            jb.speak(
                f"The search results for {computer_result['search_query']} are now displayed, sir. "
                "I verified the browser reached the requested results page."
            )
        else:
            jb.speak("The agent task is complete, sir. I verified the requested end state.")
    else:
        issue = _spoken_issue(task.errors)
        print("Agent task issues:", task.errors)
        doc_done = any(st.tool == "document_creation" and st.status == "verified" for st in task.steps)
        if doc_done:
            jb.speak(f"The document itself is complete and verified, sir, but {issue}.")
        else:
            jb.speak(f"The task ran into a problem, sir: {issue}. I did not claim success where verification failed.")
    return True


# Replace only the agent-layer implementation. Legacy backend handlers remain
# untouched and are still reached whenever this function returns None.
def try_handle_v87(command: str) -> Optional[bool]:
    if not command or not command.strip():
        return None
    c = command.strip()
    low = c.lower()

    # Prevent accidental duplicate execution when the same recognized command
    # is emitted twice by an upstream event loop. Voice recognition itself is untouched.
    if jfh.recently_started(c):
        try:
            _backend().speak("I have already started that request, sir.")
        except Exception:
            pass
        return True

    if "diagnostic" in low or "self test" in low or "self-test" in low:
        return _handle_diagnostic(c)
    kb_result = _handle_knowledge_command(c)
    if kb_result is not None:
        return kb_result

    if any(x in low for x in (
        "what is on my screen", "what's on my screen", "look at my screen",
        "look at this screen", "take a screenshot",
    )):
        return _handle_screen(c)

    # Explicit system-observation command.
    if re.search(r"\b(system status|system health|computer status)\b", low):
        snap = system_snapshot()
        jb = _backend()
        jb.speak(
            f"System status, sir. CPU {snap.get('cpu_percent','unknown')} percent, "
            f"RAM {snap.get('ram_percent','unknown')} percent, "
            f"disk {snap.get('disk_percent','unknown')} percent."
        )
        return True

    # Explicit agent-management commands.
    if re.fullmatch(r"(friday\s+)?(list|show)\s+(agent\s+)?tasks?", low):
        tasks = list_tasks(10)
        _backend().speak(f"There are {len(tasks)} recent agent tasks, sir.")
        return True

    if re.fullmatch(r"(friday\s+)?(list|show)\s+(plugins?|tools?)", low):
        names = [x["name"] for x in list_tools()]
        _backend().speak(
            "Registered tools: " + (", ".join(names) if names else "none") + "."
        )
        return True

    features = _intent_features(c)
    if not _is_complex_agent_request(c):
        # Some roadmap capabilities are single-objective but explicit.
        if not any(features.values()):
            return None
        # Don't steal ordinary "open calculator", "study mode", etc.
        if sum(bool(v) for k, v in features.items()
               if k not in {"raw","has_multiple_objectives"}) <= 1 and not features["is_vision"]:
            return None

    try:
        task = plan_request_v87(c)
        _emit(f"V87 plan created with {len(task.steps)} steps.", "planner")
        if any(s.tool == "reasoning" for s in task.steps):
            return None
        return _execute_v87(task, c)
    except Exception as exc:
        _emit(f"V87 agent failed safely; legacy pipeline retained: {_safe_text(exc)}", "recovery")
        try:
            _backend().log_event(f"V87 agent fallback: {_safe_text(exc)}", kind="recovery")
        except Exception:
            pass
        return None


try_handle = try_handle_v87



# ---------------------------------------------------------------------------
# Personal knowledge base
# ---------------------------------------------------------------------------

KB_INDEX_FILE = ROOT / "friday_knowledge_index.json"
_KB_INDEX: list[dict[str, Any]] = _load_json(KB_INDEX_FILE, [])
if not isinstance(_KB_INDEX, list):
    _KB_INDEX = []


def _extract_file_text(path: Path) -> str:
    suffix = path.suffix.lower()
    try:
        if suffix == ".txt" or suffix == ".md" or suffix == ".py" or suffix == ".json":
            return path.read_text(encoding="utf-8", errors="ignore")
        if suffix == ".pdf":
            from pypdf import PdfReader
            return "\n".join((p.extract_text() or "") for p in PdfReader(str(path)).pages)
        if suffix == ".docx":
            from docx import Document
            d = Document(str(path))
            return "\n".join([p.text for p in d.paragraphs] +
                             [c.text for t in d.tables for r in t.rows for c in r.cells])
        if suffix == ".xlsx":
            from openpyxl import load_workbook
            wb = load_workbook(str(path), read_only=True, data_only=True)
            out = []
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True):
                    out.append(" ".join(str(x) for x in row if x is not None))
            wb.close()
            return "\n".join(out)
        if suffix == ".pptx":
            from pptx import Presentation
            prs = Presentation(str(path))
            return "\n".join(shape.text for slide in prs.slides
                             for shape in slide.shapes if hasattr(shape, "text"))
    except Exception:
        return ""
    return ""


def index_knowledge_base(roots: Optional[list[str | Path]] = None) -> dict[str, Any]:
    roots = roots or [
        Path.home() / "Documents",
        Path.home() / "Downloads",
        ROOT / "study_files",
    ]
    allowed = {".txt",".md",".py",".json",".pdf",".docx",".xlsx",".pptx"}
    rows = []
    seen = set()
    for root in roots:
        p0 = Path(root)
        if not p0.exists():
            continue
        try:
            iterator = p0.rglob("*") if p0.is_dir() else [p0]
            for p in iterator:
                if not p.is_file() or p.suffix.lower() not in allowed:
                    continue
                try:
                    key = str(p.resolve())
                    if key in seen or p.stat().st_size > 30_000_000:
                        continue
                    seen.add(key)
                    text = _extract_file_text(p).strip()
                    if text:
                        rows.append({
                            "path": key,
                            "name": p.name,
                            "text": text[:10000],
                            "mtime": p.stat().st_mtime,
                        })
                except Exception:
                    continue
        except Exception:
            continue
    with _LOCK:
        _KB_INDEX[:] = rows[-2000:]
        _save_json(KB_INDEX_FILE, _KB_INDEX)
    _emit(f"Knowledge base indexed: {len(_KB_INDEX)} files", "memory")
    return {"files": len(_KB_INDEX), "index": str(KB_INDEX_FILE)}


def search_knowledge_base(query: str, top_k: int = 8) -> list[dict[str, Any]]:
    """Hybrid lexical + hashed-semantic retrieval over local documents."""
    q = (query or "").strip()
    if not q:
        return []
    if not _KB_INDEX:
        index_knowledge_base()
    qv = _local_vector(q)
    terms = set(re.findall(r"[a-z0-9]{2,}", q.lower()))
    scored = []
    for item in _KB_INDEX:
        text = item.get("text", "")
        tv = _local_vector(text[:10000])
        cosine = sum(a*b for a,b in zip(qv, tv))
        low = text.lower()
        lexical = sum(low.count(t) for t in terms)
        score = cosine + min(0.25, lexical * 0.01)
        scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [
        {"score": round(s, 4), "path": x["path"], "name": x["name"],
         "snippet": re.sub(r"\s+", " ", x["text"])[:900]}
        for s, x in scored[:top_k]
    ]


def _semantic_embedding(text: str) -> Optional[list[float]]:
    """Use Gemini embeddings only when explicitly enabled; otherwise local vectors."""
    if os.getenv("FRIDAY_USE_EMBEDDINGS", "").lower() not in {"1","true","yes","on"}:
        return None
    try:
        jb = _backend()
        jb._ensure_gemini_client()
        client = getattr(jb, "client", None)
        if client is None:
            return None
        model = os.getenv("FRIDAY_EMBEDDING_MODEL", "text-embedding-004")
        response = client.models.embed_content(model=model, contents=text)
        emb = getattr(response, "embeddings", None) or []
        values = getattr(emb[0], "values", None) if emb else None
        if values:
            return [float(x) for x in values]
    except Exception as exc:
        _emit(f"Embedding service unavailable; local semantic memory retained: {_safe_text(exc)}", "memory")
    return None


# Upgrade semantic memory without changing its public API.
_old_remember_semantic = remember_semantic
_old_retrieve_semantic = retrieve_semantic


def remember_semantic_v87(text: str, metadata: Optional[dict[str, Any]] = None):
    text = (text or "").strip()
    if not text:
        return
    embedding = _semantic_embedding(text)
    if embedding is not None:
        entry = {
            "text": text[:3000], "metadata": metadata or {},
            "vector": embedding, "vector_type": "gemini_embedding", "ts": time.time(),
        }
        with _LOCK:
            _MEMORY.append(entry)
            del _MEMORY[:-500]
            _save_json(MEMORY_FILE, _MEMORY)
    else:
        _old_remember_semantic(text, metadata)


def retrieve_semantic_v87(query: str, top_k: int = 5):
    q_embedding = _semantic_embedding(query)
    if q_embedding is None:
        return _old_retrieve_semantic(query, top_k)
    scored = []
    with _LOCK:
        for entry in _MEMORY:
            v = entry.get("vector") or []
            if entry.get("vector_type") != "gemini_embedding" or len(v) != len(q_embedding):
                continue
            score = sum(a*b for a,b in zip(q_embedding, v))
            scored.append((score, entry))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [{"score": round(s,4), **e} for s,e in scored[:top_k]]


remember_semantic = remember_semantic_v87
retrieve_semantic = retrieve_semantic_v87


# Register knowledge-base capability as a plugin-style tool.
register_tool("knowledge_base", lambda command: search_knowledge_base(command),
              permission=0,
              description="Search locally indexed PDFs, notes, projects and documents.")


def _handle_knowledge_command(command: str) -> Optional[bool]:
    low = command.lower().strip()
    if low in {"index my files", "index my knowledge base", "refresh my knowledge base"}:
        result = index_knowledge_base()
        _backend().speak(f"Knowledge base refreshed, sir. I indexed {result['files']} files.")
        return True
    m = re.match(r"(?:search|find)\s+(?:my\s+)?(?:files|notes|knowledge base)\s+(?:for|about)\s+(.+)", command, re.I)
    if m:
        hits = search_knowledge_base(m.group(1))
        if not hits:
            _backend().speak("I found no matching local documents, sir.")
        else:
            _backend().speak("I found " + str(len(hits)) + " relevant local documents. " +
                             "; ".join(h["name"] for h in hits[:4]) + ".")
        return True
    return None


# Public aliases useful to the Electron/HUD layer or future plugins.
run_agent = try_handle_v87
get_observation = observation_snapshot
get_registered_tools = list_tools


# Expanded diagnostic suite. It is additive to the original checks and does not
# modify any legacy subsystem.
_legacy_diagnostics = _diagnostics

def _diagnostics_v87() -> dict[str, Any]:
    report = _legacy_diagnostics()
    checks = report.setdefault("checks", {})

    def add(name: str, fn: Callable[[], Any]):
        try:
            value = fn()
            checks[name] = {"ok": bool(value), "detail": _safe_text(value)[:500]}
        except Exception as exc:
            checks[name] = {"ok": False, "detail": f"{type(exc).__name__}: {exc}"}

    add("Agent planner", lambda: callable(plan_request_v87))
    add("Tool router", lambda: bool(_PLUGIN_REGISTRY))
    add("Permission system", lambda: permission_required("delete file x")[0] == 4)
    add("Verification engine", lambda: verify_path(ROOT / "__friday_nonexistent__").get("exists") is False)
    add("Recovery engine", lambda: MAX_RECOVERY_ATTEMPTS >= 1)
    add("Plan validator", lambda: jfh.quality_self_test().get("overall") is True)
    add("Duplicate request guard", lambda: callable(jfh.recently_started))
    try:
        from friday_quality import health as _quality_health
        add("Feature quality layer", lambda: callable(_quality_health))
    except Exception:
        add("Feature quality layer", lambda: False)
    add("Observation engine", lambda: isinstance(observation_snapshot(), dict))
    add("Knowledge base engine", lambda: callable(search_knowledge_base))
    add("Semantic memory", lambda: callable(retrieve_semantic))
    add("Parallel executor", lambda: callable(concurrent.futures.ThreadPoolExecutor))
    add("Plugin framework", lambda: callable(register_tool) and callable(list_tools))
    report["overall"] = all(bool(v.get("ok")) for v in checks.values())
    report["version"] = V87_VERSION
    return report

_diagnostics = _diagnostics_v87

def self_test() -> dict[str, Any]:
    """Programmatic self-test entry point for scripts/CI and the voice command."""
    report = _diagnostics_v87()
    return {
        "version": V87_VERSION,
        "passed": sum(1 for v in report["checks"].values() if v["ok"]),
        "total": len(report["checks"]),
        "overall": report["overall"],
        "checks": report["checks"],
    }

# Harden permission matching for natural-language variants.
_legacy_permission_for = _permission_for

def _permission_for_v87(command: str) -> int:
    c = (command or "").lower()
    if re.search(r"\b(send|message|whatsapp|email)\b", c) and (
        "send" in c or "message" in c or "whatsapp" in c or "email" in c
    ):
        return 3
    if re.search(r"\b(delete|remove|shutdown|shut down|restart|power off|format)\b", c):
        return 4
    if re.search(r"\b(create|make|write|generate|save|edit|modify)\b", c):
        return 2
    if re.search(r"\b(open|launch|start)\b", c):
        return 1
    return _legacy_permission_for(command)

_permission_for = _permission_for_v87
