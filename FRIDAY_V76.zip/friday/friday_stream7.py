"""FRIDAY 7.0 streaming conversation engine (roadmap #19) - the non-invasive part.

FRIDAY 6.x already streams a model answer and speaks it sentence by sentence through the locked voice path (`_stream_tts_sentences`).  That path,
the speech recogniser and the voice settings are NOT replaced.  What 7.0 adds around it:

  Segmenter        a careful sentence/segment splitter for streamed text (abbreviations, decimals, URLs, "Rs. 120", lists, code fences, long run-ons)
  speakable()      what is fit to be spoken: markdown, [E1]/[2] citation ids, URLs, tables and code are removed (they stay on screen)
  SegmentSpeaker   speaks segments one at a time, strictly in order, on one worker thread, through the SAME speak function the rest of FRIDAY uses;
                   interrupt() / the speech engine's abort flag drops everything still queued, so barge-in and "stop" behave exactly as before
  speak_report()   long mission reports are spoken segment by segment (the first few, most important sentences) instead of one long block
  tap()            a pass-through wrapper around a chunk stream that measures time-to-first-chunk and time-to-first-segment (no change to the text)

Nothing here records, recognises or synthesises audio.
"""
from __future__ import annotations

import queue
import re
import threading
import time
from collections import deque
from typing import Callable, Deque, Dict, Iterable, Iterator, List, Optional

import friday_common6 as C
import friday_common7 as K

MIN_SEGMENT = 14
MAX_SEGMENT = 240
SPOKEN_REPORT_MAX_SEGMENTS = 6
SPOKEN_REPORT_MAX_CHARS = 560

_ABBR = {"mr", "mrs", "ms", "dr", "prof", "sr", "jr", "st", "vs", "etc", "e.g", "i.e", "approx", "inc", "ltd", "co", "no", "fig", "eq", "rs", "usd", "gbp", "eur", "lkr", "min", "max", "avg", "est", "dept", "gov", "u.s", "u.k"}
_END = re.compile(r"([.!?…]+[\"'”’)\]]*)(\s+|$)")
_NL = re.compile(r"\n\s*\n|\n(?=\s*(?:[-*•]|\d+[.)]|#{1,6})\s)")
_HEAD = re.compile(r"(?m)^[ \t]{0,3}#{1,6}[ \t][^\n]*(?=\n)")


class Segmenter:
    """feed(chunk) -> list of completed segments. flush() -> whatever is left. Safe to call with arbitrary chunk boundaries."""

    def __init__(self, first_fast: bool = False, first_chars: int = 70, drop_headings: bool = False):
        self._carry = ""
        self.drop_headings = drop_headings
        self.buf = ""
        self.in_code = False
        self.emitted = 0
        self.first_fast = first_fast
        self.first_chars = first_chars

    # -- boundary detection
    def _is_boundary(self, text: str, m: "re.Match") -> bool:
        end = m.end(1)
        before = text[:m.start(1) + 1]
        if m.end() >= len(text):
            return False                          # need one character of look-ahead: "3." may be "3.5", "approx." may continue in lower case
        word = re.search(r"([A-Za-z.]+)\.$", text[:m.start(1) + 1])
        if word and text[m.start(1)] == "." and len(m.group(1)) == 1:
            w = word.group(1).lower().strip(".")
            if w in _ABBR or len(w) == 1:         # "Dr.", "e.g.", initials "J."
                return False
            if re.fullmatch(r"(?:[a-z]\.){1,3}[a-z]", w):
                return False
        rest = text[m.end():]
        if re.match(r"\s*\d", rest) and re.search(r"\b(?:no|rs|fig|eq)\.$", before, re.I):
            return False                          # "No. 5", "Rs. 120"
        if rest and rest[:1].islower() and len(m.group(1)) == 1 and m.group(1) == ".":
            return False                          # "approx. five" - a lowercase continuation
        if re.search(r"https?://\S*$", before):
            return False
        return True

    def feed(self, chunk: str) -> List[str]:
        out: List[str] = []
        if not chunk:
            return out
        self.buf += chunk
        while True:
            if self.in_code:                      # drop code blocks - they are shown, not spoken
                i = self.buf.find("```")
                if i < 0:
                    self.buf = re.search(r"`{0,2}$", self.buf).group(0)      # keep a half-received closing fence
                    break
                self.buf = self.buf[i + 3:]
                self.in_code = False
                continue
            cands = []
            f = self.buf.find("```")
            if f != -1:
                cands.append((f, 0, "fence"))
            nl = _NL.search(self.buf)
            if nl:
                cands.append((nl.start(), 2, "nl"))
            hd = _HEAD.search(self.buf)
            if hd:
                cands.append((hd.end(), 1, "head"))
            for m in _END.finditer(self.buf):
                if f != -1 and m.start() > f:
                    break
                if self._is_boundary(self.buf, m):
                    cands.append((m.end(1), 3, "end"))
                    break
            pos, _, kind = min(cands) if cands else (None, 0, "")
            if (pos is None or pos > MAX_SEGMENT) and len(self.buf) > MAX_SEGMENT:      # a run-on: break at the last comma / semicolon / " and "
                window = self.buf[:MAX_SEGMENT]
                k = max(window.rfind(", "), window.rfind("; "), window.rfind(" \u2014 "), window.rfind(" and "))
                k = k if k > 60 else window.rfind(" ")
                if k > 40:
                    seg, self.buf = self.buf[:k + 1], self.buf[k + 1:].lstrip()
                    self._emit(seg, out)
                    continue
            if pos is None:
                if self.first_fast and self.emitted == 0 and not self._carry and len(self.buf) >= self.first_chars:
                    k = max(self.buf.rfind(", ", 0, self.first_chars + 25), self.buf.rfind(" ", 0, self.first_chars + 25))
                    if k >= 40:
                        seg, self.buf = self.buf[:k + 1], self.buf[k + 1:].lstrip()
                        self._emit(seg, out)
                        continue
                break
            if kind == "nl":
                seg, self.buf = self.buf[:pos], self.buf[nl.end():]
                self._emit(seg, out)
            elif kind == "fence":
                seg, self.buf = self.buf[:pos], self.buf[pos + 3:]
                self.in_code = True
                self._emit(seg, out)
            elif kind == "head":
                seg, self.buf = self.buf[:pos], self.buf[pos:].lstrip()
                if self.drop_headings:
                    seg = ""
                self._emit(seg, out)
            else:
                seg, self.buf = self.buf[:pos], self.buf[pos:].lstrip()
                self._emit(seg, out)
        return out

    def _emit(self, seg: str, out: List[str]):
        seg = seg.strip()
        if not seg:
            return
        if self._carry:
            seg = (self._carry + " " + seg).strip()
            self._carry = ""
        if len(seg) < MIN_SEGMENT:                # too short to be its own utterance: it is joined to the next segment (same result for any chunking)
            self._carry = seg
            return
        out.append(seg)
        self.emitted += 1

    def flush(self) -> List[str]:
        tail = "" if self.in_code else self.buf
        if self.drop_headings and re.match(r"^[ \t]{0,3}#{1,6}[ \t]", tail):
            tail = ""
        rest = (self._carry + " " + tail).strip()
        self.buf, self._carry, self.in_code = "", "", False
        return [rest] if rest else []


def segments(text: str, drop_headings: bool = False) -> List[str]:
    s = Segmenter(drop_headings=drop_headings)
    return s.feed(text + "\n\n") + s.flush()


# ------------------------------------------------------------------ what is fit to be said aloud
_RX_CITE = re.compile(r"\s*\[(?:E?\d+|M\d+)\](?:\[(?:E?\d+|M\d+)\])*")
_RX_URL = re.compile(r"https?://\S+|www\.\S+")
_RX_STATUS = re.compile(r"\s*\((?:CONFIRMED[^)]*|SOURCES DISAGREE|one source only[^)]*|seen on more than one site[^)]*|unverified[^)]*)\)", re.I)


def speakable(text: str) -> str:
    t = text or ""
    t = re.sub(r"```.*?```", " ", t, flags=re.S)
    t = _RX_URL.sub("", t)
    t = _RX_STATUS.sub("", t)
    t = _RX_CITE.sub("", t)
    t = re.sub(r"^\s{0,3}#{1,6}\s*", "", t, flags=re.M)
    t = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s+", "", t, flags=re.M)
    t = re.sub(r"[*_`~|]+", "", t)
    t = re.sub(r"\s*[✓✗~⚠]\s*", " ", t)
    t = re.sub(r"\s{2,}", " ", t).strip()
    return t


def _boilerplate(seg: str) -> bool:
    return bool(re.search(r"^Prepared \d{4}-\d\d-\d\d|^Every statement carries|^Evidence index|^Sources:", seg, re.I))


# ------------------------------------------------------------------ ordered speaking with interruption
class SegmentSpeaker:
    def __init__(self, say: Optional[Callable[[str], None]] = None, say_piece: Optional[Callable[[str], None]] = None, aborted: Optional[Callable[[], bool]] = None, name: str = "Friday-Segments"):
        self._say = say
        self._piece = say_piece
        self._aborted = aborted
        self._q: "queue.Queue" = queue.Queue()
        self._epoch = 0
        self._count = 0
        self._spoken: List[str] = []
        self._dropped = 0
        self._t: Optional[threading.Thread] = None
        self._name = name
        self._lock = threading.Lock()

    def _is_aborted(self) -> bool:
        if self._aborted is not None:
            try:
                return bool(self._aborted())
            except Exception:
                return False
        try:
            import friday_speech5 as SP
            return bool(SP.is_aborted())
        except Exception:
            return False

    def _speak(self, text: str, first: bool):
        fn = (self._say or (K._cfg.get("speak") if hasattr(K, "_cfg") else None))
        if not first:
            fn = self._piece or (K._cfg.get("speak_piece") if hasattr(K, "_cfg") else None) or fn
        if fn:
            fn(text)

    def _run(self):
        first = True
        while True:
            item = self._q.get()
            if item is None:
                return
            epoch, seg = item
            if epoch != self._epoch or self._is_aborted():
                self._dropped += 1
                continue
            try:
                self._speak(seg, first)
                self._spoken.append(seg)
                first = False
            except Exception as exc:
                C.log(f"segment speech failed safely: {exc}", "recovery")

    def start(self):
        with self._lock:
            if self._t is None or not self._t.is_alive():
                self._t = threading.Thread(target=self._run, name=self._name, daemon=True)
                self._t.start()
        return self

    def put(self, seg: str):
        seg = (seg or "").strip()
        if seg:
            self._count += 1
            self._q.put((self._epoch, seg))

    def interrupt(self):
        """Drop everything still queued (the utterance already playing is stopped by the speech engine's own interrupt)."""
        self._epoch += 1
        try:
            while True:
                self._q.get_nowait()
        except queue.Empty:
            pass

    def close(self, timeout: Optional[float] = None) -> bool:
        self._q.put(None)
        t = self._t
        if t is not None:
            t.join(timeout)
            return not t.is_alive()
        return True

    @property
    def spoken(self) -> List[str]:
        return list(self._spoken)

    @property
    def dropped(self) -> int:
        return self._dropped


def spoken_summary(text: str, max_segments: int = SPOKEN_REPORT_MAX_SEGMENTS, max_chars: int = SPOKEN_REPORT_MAX_CHARS) -> Dict:
    """-> {segments: [...], truncated: bool}. The first segments are kept whole - a sentence is never cut in half."""
    segs = [speakable(s) for s in segments(text, drop_headings=True)]
    segs = [s for s in segs if len(s) >= 3 and not _boilerplate(s)]
    out: List[str] = []
    used = 0
    for s in segs:
        if len(out) >= max_segments or (out and used + len(s) > max_chars):
            return {"segments": out, "truncated": True}
        out.append(s)
        used += len(s)
    return {"segments": out, "truncated": False}


def speak_report(text: str, rep: Optional[Dict] = None) -> bool:
    """Speak a long mission report sentence by sentence: the head line, the first important sentences of the answer, then the closing line.
    Returns True when it was spoken here; False when stream_segments is off or there is nothing to segment (the caller then speaks one block as before)."""
    if not (text or "").strip():
        return True
    if not K.cfg_flag("stream_segments"):
        return False
    head: List[str] = []
    body: List[str] = []
    tail: List[str] = []
    truncated = False
    if rep and rep.get("answer"):
        head = [x for x in segments(rep.get("spoken_head", "")) if x.strip()]
        sm = spoken_summary(rep["answer"])
        body, truncated = sm["segments"], sm["truncated"]
        tail = [x for x in segments(rep.get("spoken_tail", "")) if x.strip()]
    else:
        sm = spoken_summary(text)
        body, truncated = sm["segments"], sm["truncated"]
    parts = head + body + (["The full details are on screen."] if truncated else []) + tail
    if not parts:
        return False
    sp = SegmentSpeaker().start()
    for x in parts:
        sp.put(x)
    sp.close(timeout=240)
    return True


# ------------------------------------------------------------------ latency tap (pass-through)
_STATS: Deque[Dict] = deque(maxlen=60)


def tap(chunks: Iterable[str], label: str = "reply") -> Iterator[str]:
    """Yields exactly the chunks it receives. Measures time to first chunk and to first speakable segment."""
    t0 = time.time()
    seg = Segmenter(first_fast=True)
    first_chunk = first_seg = None
    n = chars = 0
    src = iter(chunks)
    try:
        for piece in src:
            now = time.time()
            if first_chunk is None and piece:
                first_chunk = now - t0
            n += 1
            chars += len(piece or "")
            if first_seg is None and piece:
                try:
                    if seg.feed(piece):
                        first_seg = now - t0
                except Exception:
                    first_seg = first_seg
            yield piece
    finally:
        try:
            close = getattr(src, "close", None)
            if close:
                close()
        except Exception:
            pass
        rec = {"label": label, "ts": time.time(), "first_chunk_s": None if first_chunk is None else round(first_chunk, 3), "first_segment_s": None if first_seg is None else round(first_seg, 3),
               "total_s": round(time.time() - t0, 3), "chunks": n, "chars": chars}
        _STATS.append(rec)
        try:
            K.emit("stream.done", rec)
        except Exception:
            pass


def stats() -> Dict:
    rows = list(_STATS)
    fc = [r["first_chunk_s"] for r in rows if r["first_chunk_s"] is not None]
    fs = [r["first_segment_s"] for r in rows if r["first_segment_s"] is not None]
    avg = lambda v: round(sum(v) / len(v), 3) if v else None  # noqa: E731
    return {"streams": len(rows), "avg_first_chunk_s": avg(fc), "avg_first_segment_s": avg(fs), "worst_first_segment_s": max(fs) if fs else None, "last": rows[-1] if rows else None}


def install_events():
    pass


def ui_snapshot() -> Dict:
    return {"stream": stats()}
