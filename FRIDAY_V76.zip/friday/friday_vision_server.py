#!/usr/bin/env python3
"""
FRIDAY VISION SERVER  -  run this on an AWS Graviton (ARM64) instance, ideally with COOL
=========================================================================================
A small HTTP service that runs FRIDAY's OpenCV vision engine in the cloud:

    GET  /health              -> versions, CPU, whether the Cloud-Optimized OpenCV Library (COOL) is active
    POST /analyze?kind=..     -> body = JPEG, returns the VisionState JSON
    POST /benchmark           -> runs the OpenCV micro-benchmarks on THIS machine (compare with your PC)
    GET  /metrics             -> request counts and latencies

Security (read this):
  * An access token is REQUIRED:  export FRIDAY_CLOUD_TOKEN='a-long-random-string'
    (the server refuses to start without one, unless you pass --insecure-dev for local testing).
  * Use TLS.  Either pass --certfile/--keyfile, or (recommended on AWS) put the server behind an
    Application Load Balancer / nginx / CloudFront that terminates HTTPS, and keep this port closed to the world
    in the security group (allow only the load balancer, or only your own IP address).
  * Frames are processed in memory and never written to disk or logged.

Run:
    pip install opencv-python-headless numpy pillow pytesseract        # skip opencv-python-headless on a COOL AMI
    export FRIDAY_CLOUD_TOKEN=...   # and  export FRIDAY_COOL=1  when OpenCV comes from /opt/cool
    python3 friday_vision_server.py --port 8443 --certfile cert.pem --keyfile key.pem
"""
from __future__ import annotations

import argparse
import hmac
import json
import os
import ssl
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("FRIDAY_VISION_DATA", os.path.join(os.path.expanduser("~"), ".friday_vision_server"))

import friday_vision_config as cfg  # noqa: E402
import friday_vision_engine as ve  # noqa: E402

TOKEN = os.environ.get("FRIDAY_CLOUD_TOKEN", "")
MAX_BODY = 12 * 1024 * 1024
STATS = {"started": time.time(), "analyze": 0, "errors": 0, "ms": [], "benchmarks": 0}
LOCK = threading.Lock()
BENCH_LOCK = threading.Lock()


def _authorised(handler: BaseHTTPRequestHandler) -> bool:
    if not TOKEN:
        return True
    got = handler.headers.get("Authorization", "")
    return got.startswith("Bearer ") and hmac.compare_digest(got[7:].encode(), TOKEN.encode())


class Handler(BaseHTTPRequestHandler):
    server_version = "FridayVision/2.3"

    def log_message(self, fmt, *args):  # no request logging (no frame metadata leaves memory)
        pass

    def _send(self, code: int, obj) -> None:
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/health":
            if not _authorised(self):
                return self._send(401, {"error": "unauthorised"})
            return self._send(200, {"ok": True, "service": "friday-vision", "environment": ve.environment(), "detector": ve.detector_status(),
                                    "uptime_s": round(time.time() - STATS["started"], 1)})
        if path == "/metrics":
            if not _authorised(self):
                return self._send(401, {"error": "unauthorised"})
            with LOCK:
                ms = sorted(STATS["ms"])
                return self._send(200, {"analyze_requests": STATS["analyze"], "errors": STATS["errors"], "benchmarks": STATS["benchmarks"],
                                        "avg_ms": round(sum(ms) / len(ms), 1) if ms else None, "p95_ms": ms[int(len(ms) * 0.95) - 1] if len(ms) > 1 else None})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not _authorised(self):
            return self._send(401, {"error": "unauthorised"})
        url = urlparse(self.path)
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            return self._send(413, {"error": "frame too large"})
        body = self.rfile.read(n) if n else b""
        try:
            if url.path == "/analyze":
                q = {k: v[0] for k, v in parse_qs(url.query).items()}
                frame = ve.decode_image(body)
                if frame is None:
                    return self._send(400, {"error": "could not decode the image"})
                if q.get("conf"):
                    cfg.update({"conf_threshold": float(q["conf"])})
                t0 = time.perf_counter()
                state = ve.analyze_frame(frame, q.get("kind", "image"), do_ocr=q.get("ocr") == "1", do_ui=q.get("kind") == "screen",
                                         mode=q.get("mode") or None, publish_state=False)
                state.pop("source", None)
                state["server"] = {"opencv": ve.cv_version(), "machine": ve.environment().get("machine"), "cool": ve.cool_detected()["active"]}
                ms = (time.perf_counter() - t0) * 1000
                with LOCK:
                    STATS["analyze"] += 1
                    STATS["ms"] = (STATS["ms"] + [round(ms, 1)])[-500:]
                return self._send(200, state)
            if url.path == "/benchmark":
                with BENCH_LOCK:
                    res = ve.micro_benchmark(12)
                with LOCK:
                    STATS["benchmarks"] += 1
                return self._send(200, res)
            return self._send(404, {"error": "not found"})
        except Exception as exc:
            with LOCK:
                STATS["errors"] += 1
            return self._send(500, {"error": f"{type(exc).__name__}: {exc}"})


def main() -> int:
    ap = argparse.ArgumentParser(description="FRIDAY Vision Server (OpenCV on AWS Graviton / COOL)")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8443)
    ap.add_argument("--certfile")
    ap.add_argument("--keyfile")
    ap.add_argument("--insecure-dev", action="store_true", help="allow running without a token (local testing only)")
    a = ap.parse_args()
    if not TOKEN and not a.insecure_dev:
        print("Refusing to start: set FRIDAY_CLOUD_TOKEN to a long random string (or use --insecure-dev for local testing).", file=sys.stderr)
        return 2
    if not ve.available():
        print("OpenCV is not installed:", ve._CV_ERROR, file=sys.stderr)
        return 2
    httpd = ThreadingHTTPServer((a.host, a.port), Handler)
    scheme = "http"
    if a.certfile and a.keyfile:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(a.certfile, a.keyfile)
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        scheme = "https"
    elif not a.insecure_dev:
        print("NOTE: no --certfile/--keyfile given. Put this behind an HTTPS load balancer / reverse proxy, never expose plain HTTP to the internet.")
    env = ve.environment()
    print(f"FRIDAY Vision Server on {scheme}://{a.host}:{a.port}  |  OpenCV {env.get('opencv_version')} on {env.get('machine')}  |  COOL active: {env.get('cool', {}).get('active')}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
