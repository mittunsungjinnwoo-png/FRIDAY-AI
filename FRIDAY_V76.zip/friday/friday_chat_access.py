"""
FRIDAY CHAT ACCESS  -  gives the chat (typed or spoken) real access to every page of the left-hand menu
=========================================================================================================
Added in V2.3.1.  Purely additive: it never touches listening, recognition or speech code.

What it does
------------
* capability_block(question)  : a compact, truthful "what I can do right now" text that is added to FRIDAY's
                                 Gemini prompt, so she stops saying she has no access to the camera / screen /
                                 calendar / memory / files / tasks.  It also carries the live state (camera on or
                                 off, what she last saw, today's agenda, memories, tasks, files).
* handle(text)                : claims only explicit "look / see / describe" camera requests, screen-vision on/off,
                                 live-preview on/off, calendar adds and "open the X page" requests.  Everything else
                                 returns None, so every existing route keeps working exactly as before.
* describe_camera(question)   : looks through the camera and describes what is there the way a person would
                                 (the same style FRIDAY already uses when she describes the screen).
* camera_part_for(question)   : while the camera is on, the newest camera picture is attached to the Gemini call for
                                 any visual question, so even phrasings the router does not know are answered by sight.
* set_app_state(obj)          : the app keeps this module up to date with Calendar / Memory / Tasks / Files / Tools data.
"""
from __future__ import annotations

import base64
import datetime as _dt
import json
import re
import sys
import threading
import time
from typing import Any, Optional

import friday_vision_config as cfg

_LOCK = threading.RLock()
_APP_STATE: dict[str, Any] = {}
_APP_STATE_AT = 0.0
_LAST_SCENE: dict[str, Any] = {"text": "", "at": 0.0, "source": ""}

# page name used by index.html view() for each thing a person may say
_PAGES = {
    "home": "Home", "chat": "Home", "tasks": "Tasks", "tasks and agents": "Tasks", "tasks & agents": "Tasks", "agents": "Tasks",
    "tools": "Tools", "memory": "Memory", "memories": "Memory", "finance": "Finance", "finances": "Finance",
    "calendar": "Calendar", "files": "Files", "web": "Web", "web and research": "Web", "web & research": "Web", "research": "Web",
    "multimedia": "Multimedia", "vision": "Vision", "settings": "Settings",
}
_PAGE_SPOKEN = {"Home": "the home page", "Tasks": "Tasks and Agents", "Tools": "Tools", "Memory": "Memory", "Finance": "Finance",
                "Calendar": "the calendar", "Files": "Files", "Web": "Web and Research", "Multimedia": "Multimedia",
                "Vision": "Vision", "Settings": "Settings"}


# ----------------------------------------------------------------------------
# plumbing (all lazy so importing this module is always safe)
# ----------------------------------------------------------------------------
def _backend():
    import friday_backend
    return friday_backend


def _hub():
    import friday_vision_hub
    return friday_vision_hub


def _ve():
    import friday_vision_engine as ve
    return ve


def _speak(text: str) -> None:
    try:
        if text:
            _backend().speak(text)
    except Exception:
        pass


def _log(text: str, kind: str = "info") -> None:
    try:
        _backend().log_event(text, kind=kind)
    except Exception:
        pass


def _ui_line(line: str) -> None:
    try:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
    except Exception:
        pass


def _camera_session_running() -> bool:
    try:
        if "friday_vision_engine" not in sys.modules:
            return False
        s = sys.modules["friday_vision_engine"].SESSION
        return bool(s.running and s.kind == "camera")
    except Exception:
        return False


def _screen_session_running() -> bool:
    try:
        if "friday_vision_engine" not in sys.modules:
            return False
        s = sys.modules["friday_vision_engine"].SESSION
        return bool(s.running and s.kind == "screen")
    except Exception:
        return False


# ----------------------------------------------------------------------------
# live data from the app pages
# ----------------------------------------------------------------------------
def set_app_state(obj: Any) -> None:
    global _APP_STATE, _APP_STATE_AT
    if isinstance(obj, dict):
        with _LOCK:
            _APP_STATE = obj
            _APP_STATE_AT = time.time()


def _app_summary(question: str) -> str:
    """Only the pages the question is about, so a normal chat reply stays fast."""
    with _LOCK:
        st = dict(_APP_STATE)
    if not st:
        return ""
    low = (question or "").lower()
    parts: list[str] = []
    if re.search(r"calendar|event|schedule|agenda|appointment|meeting|today|tomorrow|this week|plan|busy|free|remind", low):
        cal = [c for c in (st.get("cal") or []) if isinstance(c, dict)]
        today = st.get("today") or _dt.date.today().isoformat()
        upcoming = sorted([c for c in cal if str(c.get("d", "")) >= today], key=lambda c: (str(c.get("d", "")), str(c.get("t", ""))))[:12]
        if upcoming:
            parts.append("Calendar (today is %s): " % today + "; ".join(f"{c.get('d')} {c.get('t')} {c.get('n')}{' (done)' if c.get('done') else ''}" for c in upcoming))
        else:
            parts.append(f"Calendar (today is {today}): no upcoming events.")
    if re.search(r"memor|remember|forget|know about me|preference|recall", low):
        mem = [m for m in (st.get("mem") or []) if isinstance(m, dict)][:20]
        parts.append("Memory centre: " + ("; ".join(f"{m.get('t')} [{m.get('k')}]" for m in mem) if mem else "nothing stored yet."))
    if re.search(r"task|agent|research|report|running|progress|finished|failed", low):
        tasks = [k for k in (st.get("tasks") or []) if isinstance(k, dict)][:6]
        parts.append("Tasks and Agents: " + ("; ".join(f"'{k.get('q')}' is {k.get('st')}" for k in tasks) if tasks else "no tasks yet."))
    if re.search(r"file|upload|attach|document|csv|pdf|image|picture|multimedia|photo", low):
        files = [f for f in (st.get("files") or []) if isinstance(f, dict)][:15]
        parts.append("Files and Multimedia: " + ("; ".join(f"{f.get('name')} ({f.get('size')} KB{', ' + str(f.get('note')) if f.get('note') else ''})" for f in files) if files else "no files added yet."))
    if re.search(r"tool|permission|allowed|log|audit|activity|performance|success|latency|stat", low):
        m = st.get("metrics") or {}
        parts.append(f"Tools page: tasks completed {m.get('ok', 0)}, tools used {m.get('tools', 0)}, tool successes {m.get('toolOk', 0)}, commands {m.get('cmds', 0)}; permissions {json.dumps(st.get('perm') or {})}. "
                     "Recent activity: " + "; ".join(str(a) for a in (st.get("audit") or [])[:8]))
    return ("\nLive data from the FRIDAY app pages (use it to answer; it is accurate right now):\n" + "\n".join(parts)) if parts else ""


# ----------------------------------------------------------------------------
# the prompt block that stops "I have no access to the camera" answers
# ----------------------------------------------------------------------------
def capability_block(question: str = "") -> str:
    cam = _camera_session_running()
    scr = _screen_session_running()
    age = time.time() - float(_LAST_SCENE.get("at") or 0)
    seen = ""
    if _LAST_SCENE.get("text") and age < 600:
        seen = f" What you last saw through the {_LAST_SCENE.get('source') or 'camera'} {int(age)} seconds ago: \"{str(_LAST_SCENE['text'])[:400]}\"."
    state = (f"Right now the camera is {'ON' if cam else 'OFF'} and screen vision is {'ON' if scr else 'OFF'}." + seen)
    return (
        "\n\nFRIDAY'S REAL ACCESS (true right now; never contradict it):\n"
        "You are the assistant inside the FRIDAY desktop app and you have working access to every page in its left menu: "
        "Home/Chat, Tasks & Agents, Tools, Memory, Finance, Calendar, Files, Web & Research, Multimedia, Vision and Settings.\n"
        "- Vision: you CAN see. You can look through the user's camera and at their screen, describe what you see, notice movement and "
        "changes, find things on screen and analyse attached pictures or videos. " + state + " "
        "If the user asks what you see, describe it like a person would: natural spoken sentences, what is happening, who or what is there, "
        "colours, setting. Never say you cannot see, have no camera, or are a text-only AI.\n"
        "- Treat chat as the main control surface for the app: for requests involving Tasks & Agents, Tools, Memory, Finance, Calendar, Files, Web & Research, Multimedia, Vision or Settings, use the existing FRIDAY command/tool routes and live app data where available. "
        "Do the requested supported action instead of merely explaining how, and report a limitation only when the action actually fails or is not implemented.\n"
        "- Calendar, Memory, Tasks & Agents, Files, Multimedia, Tools, Finance and Web & Research: use the matching existing feature handlers/tools when the user asks to create, change, retrieve, research or operate something; do not claim an action succeeded unless its handler confirms it.\n"
        "- Camera and screen vision on/off, opening pages and calendar changes must invoke FRIDAY's actual commands. Never claim a toggle or action happened unless the command was executed successfully.\n"
        "- Never answer with 'I don't have access', 'I am only a language model' or 'I cannot see'. If something genuinely failed (camera busy, no key), "
        "say exactly what failed and the next step. Never invent what is in a picture you were not given."
        + _app_summary(question)
    )


# ----------------------------------------------------------------------------
# camera -> human description
# ----------------------------------------------------------------------------
_VISUAL_Q = re.compile(
    r"\b(?:see|seeing|look|looking|watch|show|showing|holding|wearing|behind|beside|front of|room|desk|face|hand|hands|finger|fingers|colou?r|"
    r"who(?:'s| is)?|how many (?:people|persons|fingers|objects)|anyone|somebody|someone|what(?:'s| is) (?:this|that|in my)|read this|describe)\b", re.I)


def _cloud_ok() -> bool:
    """One camera picture may go to Gemini for a description when the user asks in chat, unless switched off in Settings > Vision."""
    try:
        return bool(cfg.get("chat_camera_describe")) or bool(cfg.get("camera_allow_cloud"))
    except Exception:
        return True


def _jpeg_part(frame):
    ve = _ve()
    from google.genai import types
    small, _ = ve._limit(frame, 1280)
    ok, buf = ve.cv2.imencode(".jpg", small, [int(ve.cv2.IMWRITE_JPEG_QUALITY), 82])
    return types.Part.from_bytes(data=bytes(buf), mime_type="image/jpeg")


def camera_part_for(question: str):
    """The newest camera picture as a Gemini part, only while the camera is on and the question is visual."""
    try:
        if not _camera_session_running() or not _cloud_ok() or not _VISUAL_Q.search(question or ""):
            return None
        frame = sys.modules["friday_vision_engine"].SESSION.last_frame
        if frame is None:
            return None
        return _jpeg_part(frame.copy())
    except Exception:
        return None


def _human_prompt(question: str, state: dict) -> str:
    hints = ""
    try:
        objs = state.get("objects", [])[:10]
        people = sum(1 for o in objs if str(o.get("label", "")).lower() in ("person", "face"))
        hints = f"Sensor hints (use only to stay accurate, never recite them): about {people} person(s) detected; motion={bool((state.get('motion') or {}).get('motion'))}."
    except Exception:
        pass
    ask = (question or "").strip()
    task = (f"The user asked: \"{ask}\". Answer that first, directly, then add one short line of useful context."
            if ask and not re.fullmatch(r"(?:friday[, ]*)?(?:what (?:do|can) you see[a-z ]*|describe what you see[a-z ]*)[?.! ]*", ask, re.I)
            else "Describe what you see.")
    return (
        "You are FRIDAY, a calm, observant personal assistant. You are looking through the user's webcam at this very moment. " + task + "\n"
        "Speak the way a person describes what is in front of them to someone they are helping: natural, flowing spoken English, 3 to 5 sentences, "
        "no lists, no headings. Start with what matters most (usually a person and what they are doing, their expression and clothing), then the notable objects "
        "and where they are, then the setting (room, lighting, background). If a person is looking at the camera they are probably the user, so speak to them "
        "directly ('I can see you, sir...'). Mention colours and details only when they are really visible. Say 'I can see', never 'the image' or 'the frame'. "
        "Do not mention OpenCV, detectors, confidence scores, IDs, boxes or coordinates. Never guess anyone's name or identity from their face. "
        "If the picture is dark, blurry or empty, say so plainly instead of guessing. " + hints
    )


def _gemini_human(frame, state: dict, question: str, timeout: float = 25.0) -> Optional[str]:
    try:
        jb = _backend()
        jb._ensure_gemini_client()
        if getattr(jb, "client", None) is None:
            return None
        part = _jpeg_part(frame)
        import concurrent.futures
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        fut = pool.submit(lambda: jb._gemini_generate([_human_prompt(question, state), part]))
        try:
            resp = fut.result(timeout=timeout)
        finally:
            pool.shutdown(wait=False)
        text = (jb._response_text(resp) or "").strip()
        return text[:1200] or None
    except Exception as exc:
        _log(f"Camera description by Gemini failed: {type(exc).__name__}: {str(exc)[:160]}", "recovery")
        return None


def _grab_camera_frame():
    """(frame, was_live). Uses the running camera session, otherwise opens the camera for one picture and closes it again."""
    ve = _ve()
    if _camera_session_running() and ve.SESSION.last_frame is not None:
        return ve.SESSION.last_frame.copy(), True
    cap = ve._open_camera(int(cfg.get("camera_index")))
    if cap is None:
        raise RuntimeError("I could not open the camera. Check that it is connected, not used by another app, and allowed in Windows privacy settings.")
    frame = None
    try:
        for _ in range(5):                       # let auto-exposure settle
            ok, f = cap.read()
            if ok and f is not None:
                frame = f
    finally:
        cap.release()
    if frame is None:
        raise RuntimeError("The camera opened but gave no picture.")
    return frame, False


def describe_camera(question: str = "", speak: bool = True) -> dict[str, Any]:
    try:
        ve = _ve()
        if not ve.available():
            raise RuntimeError("OpenCV is not installed yet. Open Settings, then Vision, and press Install OpenCV.")
        hub = _hub()
        hub._wire()
        frame, live = _grab_camera_frame()
        state = ve.analyze_frame(frame, "camera", label="camera", publish_state=False, do_ocr=False)
        text = _gemini_human(frame, state, question) if _cloud_ok() else None
        source = "gemini" if text else "opencv"
        if text:
            state["scene"] = {"narrative": text, "source": "gemini"}
        state["summary"] = text or ve.describe(state)
        state = ve.publish(state)
        said = text or state["summary"]
        _LAST_SCENE.update({"text": said, "at": time.time(), "source": "camera"})
        hub.emit("snapshot", ve.compact_state(state))
        if speak:
            _speak(said)
        return {"ok": True, "text": said, "source": source, "live": live}
    except Exception as exc:
        msg = str(exc).split("\n")[0][:220]
        if speak:
            _speak(msg)
        return {"ok": False, "error": msg}


def _describe_screen() -> None:
    """Same spoken screen report FRIDAY already gives for 'check my screen'."""
    try:
        from friday_screen_intelligence import inspect_screen, spoken_screen_report
        _speak(spoken_screen_report(inspect_screen(use_semantic_vision=True)))
    except Exception:
        _speak("I can't get a clear view of the screen at the moment, sir.")


# ----------------------------------------------------------------------------
# intent patterns
# ----------------------------------------------------------------------------
_SCREENISH = re.compile(r"\b(?:screen|desktop|display|monitor|window|tab|page|website|browser)\b", re.I)
_CAM_WORD = re.compile(r"\b(?:camera|webcam|web cam|cam)\b", re.I)
_LOOK_VERB = re.compile(r"\b(?:see|seeing|look|looking|show|describe|tell|check|watch|view|what|who|how many|anyone|anybody|someone|anything|is there|are there)\b", re.I)
_CAM_SWITCH = re.compile(r"\b(?:turn|switch|power|start|stop|enable|disable|activate|deactivate)\b.{0,12}\b(?:on|off)?\b.{0,15}\b(?:camera|webcam|cam)\b|\bcamera\s+(?:on|off)\b", re.I)
_PERSON_OR_ROOM = [
    re.compile(r"\bcan you (?:actually |really |even )?see (?:me|us|my\b|anyone|anything|somebody|someone)", re.I),
    re.compile(r"\bdo you (?:actually |really )?see (?:me|us|anyone|anybody|anything|somebody|someone)", re.I),
    re.compile(r"\b(?:look at|look over at|check) (?:me|my face|my hands?|what i(?:'m| am) (?:holding|wearing|showing))\b", re.I),
    re.compile(r"\bwhat (?:am i|i am|i'm) (?:holding|wearing|showing|pointing at|doing with)\b", re.I),
    re.compile(r"\bhow many fingers\b", re.I),
    re.compile(r"\bwhat colou?r (?:is|are) (?:my|the) (?:shirt|top|hair|eyes|jacket|hoodie|t-?shirt|dress|wall|room)\b", re.I),
    re.compile(r"\b(?:who(?:'s| is)|is anyone|is anybody|is someone|are there (?:any )?people) (?:there|here|in the room|behind me|in front of you|in view)\b", re.I),
    re.compile(r"\bwhat(?:'s| is) (?:behind|beside|next to|around|in front of) (?:me|you)\b", re.I),
    re.compile(r"\bdescribe (?:the|my|this) (?:room|surroundings|place|scene|desk|background)\b", re.I),
    re.compile(r"\bwhat(?:'s| is) (?:in )?(?:the )?room\b", re.I),
]
_BARE_SEE = re.compile(r"^\s*(?:friday[, ]+)?(?:hey[, ]+)?(?:so[, ]+)?(?:can you |could you |please )?(?:tell me |just )?(?:what (?:do|can|are) you (?:see|seeing)(?: now| right now| there| around| here)?|what(?:'s| is) (?:in front of you|around you|there)|describe what you (?:see|can see)|what (?:do|can) you see (?:around|here|there)|look around|have a look(?: around)?|take a look(?: around)?)\s*[?.!]*\s*$", re.I)

_SCREEN_VIS_ON = re.compile(r"\b(?:turn on|switch on|start|enable|activate)\b.{0,15}\bscreen vision\b|\bscreen vision\s+on\b", re.I)
_SCREEN_VIS_OFF = re.compile(r"\b(?:turn off|switch off|stop|disable|deactivate)\b.{0,15}\bscreen vision\b|\bscreen vision\s+off\b", re.I)
_PREVIEW_ON = re.compile(r"\b(?:show|turn on|switch on|enable|start|open)\b.{0,15}\b(?:live )?(?:camera )?preview\b|\blive preview on\b", re.I)
_PREVIEW_OFF = re.compile(r"\b(?:hide|turn off|switch off|disable|stop|close)\b.{0,15}\b(?:live )?(?:camera )?preview\b|\blive preview off\b", re.I)

_NAV = re.compile(
    r"\b(?:open|show|go to|take me to|switch to|bring up|display|navigate to)\b\s+(?:me\s+)?(?:the\s+|my\s+)?"
    r"(home|chat|tasks\s*(?:&|and)\s*agents|tasks|agents|tools|memory|memories|finance|finances|calendar|files|web\s*(?:&|and)\s*research|web|research|multimedia|vision|settings)"
    r"\s+(?:page|tab|section|view|screen|panel|menu)\b|"
    r"^\s*(?:please\s+)?(?:show|open|display)\s+(?:me\s+)?my\s+(calendar|tasks|memories|memory|files|finances|multimedia|agenda)\s*[.!?]*\s*$", re.I)

_CAL_WORD = re.compile(r"\b(?:calendar|agenda)\b", re.I)
_CAL_ADD = re.compile(r"^\s*(?:please\s+|friday[, ]+)?(?:add|put|create|schedule|set up|save|book|enter|log)\b", re.I)
_WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def _parse_when(text: str):
    """(date_iso, time_hhmm, text_without_when). Understands today/tomorrow, weekday names, ISO dates, 3pm, 15:30."""
    low = text
    today = _dt.date.today()
    date = None
    m = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", low)
    if m:
        try:
            date = _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            low = low.replace(m.group(0), " ")
        except ValueError:
            pass
    if date is None:
        for word, add in (("day after tomorrow", 2), ("tomorrow", 1), ("today", 0), ("tonight", 0)):
            if re.search(r"\b" + word + r"\b", low, re.I):
                date = today + _dt.timedelta(days=add)
                low = re.sub(r"\b" + word + r"\b", " ", low, flags=re.I)
                break
    if date is None:
        m = re.search(r"\b(?:on |next |this )?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", low, re.I)
        if m:
            target = _WEEKDAYS.index(m.group(1).lower())
            delta = (target - today.weekday()) % 7
            if delta == 0 or re.search(r"\bnext\b", m.group(0), re.I):
                delta = delta or 7
            date = today + _dt.timedelta(days=delta)
            low = low.replace(m.group(0), " ")
    tm = None
    m = re.search(r"\b(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b", low, re.I)
    if m:
        h, mi = int(m.group(1)), int(m.group(2) or 0)
        ap = m.group(3).lower().replace(".", "")
        if ap == "pm" and h < 12:
            h += 12
        if ap == "am" and h == 12:
            h = 0
        if 0 <= h < 24 and 0 <= mi < 60:
            tm = f"{h:02d}:{mi:02d}"
            low = low.replace(m.group(0), " ")
    if tm is None:
        m = re.search(r"\bat\s+(\d{1,2}):(\d{2})\b", low, re.I)
        if m and int(m.group(1)) < 24 and int(m.group(2)) < 60:
            tm = f"{int(m.group(1)):02d}:{m.group(2)}"
            low = low.replace(m.group(0), " ")
    return (date.isoformat() if date else today.isoformat()), (tm or "09:00"), low


def _calendar_add(text: str) -> bool:
    date, tm, rest = _parse_when(text)
    rest = re.sub(r"\b(?:to|on|in|into|onto|from)\s+(?:my\s+|the\s+)?(?:friday\s+)?calendar\b", " ", rest, flags=re.I)
    rest = re.sub(r"\b(?:my|the)\s+calendar\b", " ", rest, flags=re.I)
    rest = _CAL_ADD.sub(" ", rest, count=1)
    rest = re.sub(r"\b(?:an?|the)\s+(?:event|reminder|entry|appointment)\b(?:\s+(?:called|named|titled|for|about|saying))?", " ", rest, flags=re.I)
    rest = re.sub(r"\b(?:event|reminder|entry)\s*[:\-]", " ", rest, flags=re.I)
    rest = re.sub(r"\b(?:on|at|for|by)\s*$", " ", rest.strip(), flags=re.I)
    title = re.sub(r"\s{2,}", " ", rest).strip(" ,.;:-")
    title = re.sub(r"^(?:on|at|for|called|named|titled)\s+", "", title, flags=re.I).strip(" ,.;:-")
    title = re.sub(r"^(?:an?|the)\s+", "", title, flags=re.I).strip(" ,.;:-")
    if len(title) < 2:
        _speak("What should I call the event, sir?")
        return True
    title = title[:1].upper() + title[1:]
    payload = {"d": date, "t": tm, "n": title[:120]}
    _ui_line("FRIDAY_UI::CAL_ADD::" + base64.b64encode(json.dumps(payload).encode("utf-8")).decode("ascii"))
    nice = _dt.date.fromisoformat(date).strftime("%A %d %B")
    _speak(f"Added to your calendar, sir: {title}, {nice} at {tm}.")
    return True


# ----------------------------------------------------------------------------
# V3.1: the rest of the left-hand menu from chat (typed or spoken)
# ----------------------------------------------------------------------------
_NAV_VERB = r"(?:open|show|go to|take me to|switch to|bring up|display|navigate to|go back to)"
# page names that cannot be mistaken for a Windows app / folder, so "open memory" or "show finance" work without the word "page"
_NAV_BARE = re.compile(
    r"^\s*(?:please\s+|friday[, ]+|hey friday[, ]+)?(?:can you |could you )?" + _NAV_VERB +
    r"\s+(?:me\s+)?(?:the\s+|my\s+|friday'?s?\s+)?(home|chat|tasks\s*(?:&|and)\s*agents|tasks|agents|memory|memories|finance|finances|multimedia|vision|web\s*(?:&|and)\s*research|research)"
    r"(?:\s+(?:page|tab|section|view|screen|panel|menu))?(?:\s+(?:in|inside|within|on)\s+friday)?(?:\s+please)?\s*[.!?]*\s*$", re.I)
# names that ARE also Windows apps / folders: only when the user says it is FRIDAY's own page
_NAV_FRIDAY = re.compile(
    r"^\s*(?:please\s+|friday[, ]+)?(?:can you |could you )?" + _NAV_VERB +
    r"\s+(?:(?:the\s+|my\s+)?(calendar|files|settings|tools|web)\s+(?:in|inside|within|on|of)\s+friday|friday'?s?\s+(calendar|files|settings|tools|web))\s*[.!?]*\s*$", re.I)

_Q_CAL = re.compile(r"\bwhat(?:'s| is| do i have| have i got|'s on)?\b.{0,25}\b(?:calendar|agenda|schedule)\b|\b(?:what do i have|what have i got|am i busy|anything planned|what(?:'s| is) planned)\b.{0,25}\b(?:today|tomorrow|this week|tonight|on)\b|\b(?:read|tell me|list) (?:me )?(?:my |the )?(?:calendar|agenda|schedule|events)\b", re.I)
_Q_MEM = re.compile(r"^\s*(?:friday[, ]+)?(?:what|which)(?: do| did| have)? you (?:remember|know|have (?:saved|stored)|saved|stored)(?: (?:about|of) me)?\s*[?.!]*\s*$|^\s*(?:friday[, ]+)?(?:list|read|tell me) (?:my |your )?memor(?:y|ies)\s*[.!]*\s*$", re.I)
_Q_TASK = re.compile(r"\b(?:what|which|how many)\b.{0,20}\b(?:tasks?|agents?)\b.{0,25}\b(?:running|active|done|finished|completed|failed|have i|do i have|are there)\b|\b(?:task|agent) (?:status|list|progress)\b|\bmy tasks\b.{0,10}\?|\bany tasks\b", re.I)
_Q_FILES = re.compile(r"\bwhat files\b|\b(?:list|read|tell me) (?:me )?(?:my |the )?(?:files|uploads|attachments)\b|\bwhich files\b|\bhow many files\b|\bfiles (?:have )?i (?:added|uploaded|attached)\b", re.I)
_Q_TOOLS = re.compile(r"\b(?:tool|tools) (?:stats|statistics|performance|success|rate|permissions|usage)\b|\bhow (?:are|is) (?:your |the )?tools? (?:doing|performing|working)\b|\baction log\b|\brecent activity\b", re.I)

_MEM_ADD = re.compile(r"^\s*(?:friday[, ]+)?(?:please\s+)?remember\s+(?:that\s+|this[:,]?\s+)?(?!(?:everything|all\b|our\b|what\b|when\b|how\b|who\b|where\b|why\b|if\b|me\b|you\b|do you\b|the (?:previous|last|whole)\b))(.{3,300}?)\s*[.!]*\s*$", re.I)
_MEM_DEL = re.compile(r"^\s*(?:friday[, ]+)?(?:please\s+)?forget\s+(?:that\s+|about\s+)?(?!it\b|that\b|this\b|everything\b|all\b)(.{3,200}?)\s*[.!]*\s*$", re.I)
_CAL_DONE = re.compile(r"^\s*(?:friday[, ]+)?(?:please\s+)?(?:mark|tick|check off|complete)\s+(.{2,120}?)\s+(?:as\s+)?(?:done|complete|completed|finished)(?:\s+(?:in|on|from)\s+(?:my\s+|the\s+)?calendar)?\s*[.!]*\s*$", re.I)
_CAL_DEL = re.compile(r"^\s*(?:friday[, ]+)?(?:please\s+)?(?:delete|remove|cancel|clear)\s+(?:the\s+|my\s+)?(.{2,120}?)\s+(?:from|off|on|in)\s+(?:my\s+|the\s+)?calendar\s*[.!]*\s*$", re.I)
_THEME = re.compile(r"\b(?:switch|change|turn|go|set)\b.{0,15}\b(light|dark)\s*(?:mode|theme)\b|\b(light|dark)\s*(?:mode|theme)\s+(?:on|please)\b|\btoggle\b.{0,12}\b(?:theme|light|dark)\b", re.I)


def _state_snapshot() -> dict:
    with _LOCK:
        return dict(_APP_STATE)


def _ui_action(op: str, **kw) -> None:
    payload = {"op": op}
    payload.update(kw)
    _ui_line("FRIDAY_UI::ACT::" + base64.b64encode(json.dumps(payload).encode("utf-8")).decode("ascii"))


def _words(n: int, one: str, many: str) -> str:
    return f"{n} {one if n == 1 else many}"


def _read_calendar(text: str) -> bool:
    st = _state_snapshot()
    if not st:
        return False
    low = text.lower()
    today = st.get("today") or _dt.date.today().isoformat()
    cal = [c for c in (st.get("cal") or []) if isinstance(c, dict)]
    if "tomorrow" in low:
        day = (_dt.date.fromisoformat(today) + _dt.timedelta(days=1)).isoformat()
        sel = [c for c in cal if c.get("d") == day]
        label = "tomorrow"
    elif "week" in low:
        end = (_dt.date.fromisoformat(today) + _dt.timedelta(days=7)).isoformat()
        sel = [c for c in cal if today <= str(c.get("d", "")) <= end]
        label = "in the next seven days"
    elif re.search(r"\btoday|tonight\b", low):
        sel = [c for c in cal if c.get("d") == today]
        label = "today"
    else:
        sel = [c for c in cal if str(c.get("d", "")) >= today]
        label = "coming up"
    sel = sorted(sel, key=lambda c: (str(c.get("d", "")), str(c.get("t", ""))))
    sel = [c for c in sel if not c.get("done")] or sel
    if not sel:
        _speak(f"Nothing is on your calendar {label}, sir.")
        return True
    shown = sel[:6]
    parts = []
    for c in shown:
        when = c.get("t", "")
        if label in ("in the next seven days", "coming up"):
            try:
                when = _dt.date.fromisoformat(str(c.get("d"))).strftime("%A") + " at " + str(c.get("t", ""))
            except Exception:
                when = f"{c.get('d')} at {c.get('t')}"
        else:
            when = "at " + str(when)
        parts.append(f"{c.get('n')} {when}")
    more = f", and {len(sel) - len(shown)} more" if len(sel) > len(shown) else ""
    _speak(f"You have {_words(len(sel), 'event', 'events')} {label}, sir: " + "; ".join(parts) + more + ".")
    return True


def _read_memory() -> bool:
    st = _state_snapshot()
    if not st:
        return False
    mem = [m for m in (st.get("mem") or []) if isinstance(m, dict)]
    if not mem:
        _speak("Your memory centre is empty at the moment, sir. Say remember that, followed by anything you want me to keep.")
        return True
    top = [str(m.get("t", "")).strip() for m in mem[:6] if m.get("t")]
    _speak(f"I have {_words(len(mem), 'memory', 'memories')} saved, sir. " + "; ".join(top) + ("." if top else ""))
    return True


def _read_tasks() -> bool:
    st = _state_snapshot()
    if not st:
        return False
    tasks = [k for k in (st.get("tasks") or []) if isinstance(k, dict)]
    if not tasks:
        _speak("There are no tasks or agents yet, sir. Ask me to research something and create a report and I will start one.")
        return True
    names = {"run": "running", "done": "finished", "failed": "failed", "paused": "paused", "cancelled": "cancelled", "pen": "waiting"}
    parts = [f"{str(k.get('q', ''))[:70]} is {names.get(str(k.get('st')), k.get('st'))}" for k in tasks[:4]]
    _speak(f"You have {_words(len(tasks), 'task', 'tasks')}, sir. " + "; ".join(parts) + ".")
    return True


def _read_files() -> bool:
    st = _state_snapshot()
    if not st:
        return False
    files = [f for f in (st.get("files") or []) if isinstance(f, dict)]
    if not files:
        _speak("No files have been added yet, sir. Use the paperclip to attach some.")
        return True
    names = [str(f.get("name", "")) for f in files[:6]]
    _speak(f"You have {_words(len(files), 'file', 'files')} added, sir: " + ", ".join(names) + (", and more." if len(files) > 6 else "."))
    return True


def _read_tools() -> bool:
    st = _state_snapshot()
    if not st:
        return False
    m = st.get("metrics") or {}
    ok, tools, tool_ok = int(m.get("ok", 0) or 0), int(m.get("tools", 0) or 0), int(m.get("toolOk", 0) or 0)
    rate = f"{round(tool_ok / tools * 100)} percent" if tools else "not measured yet"
    _speak(f"{_words(ok, 'task', 'tasks')} completed, {_words(tools, 'tool use', 'tool uses')}, with a tool success rate of {rate}, sir.")
    return True


def _best_match(name: str, rows: list, key: str):
    n = re.sub(r"[^a-z0-9 ]+", " ", name.lower()).strip()
    if not n:
        return None
    best = None
    for r in rows:
        t = re.sub(r"[^a-z0-9 ]+", " ", str(r.get(key, "")).lower()).strip()
        if t and (n == t or n in t or t in n):
            if best is None or abs(len(t) - len(n)) < abs(len(re.sub(r"[^a-z0-9 ]+", " ", str(best.get(key, "")).lower())) - len(n)):
                best = r
    return best


def _extra_menu(t: str, low: str) -> Optional[bool]:
    """Everything beyond the original routes. Returns True when handled, None to carry on."""
    m = _NAV_BARE.match(t) or _NAV_FRIDAY.match(t)
    if m:
        key = re.sub(r"\s+", " ", next(g for g in m.groups() if g).lower()).replace(" & ", " and ")
        page = _PAGES.get(key) or _PAGES.get(key.replace("and", "&"))
        if page:
            _ui_line("FRIDAY_UI::VIEW::" + page)
            _speak(f"Opening {_PAGE_SPOKEN.get(page, page)}, sir.")
            return True
    if _THEME.search(t):
        want = (_THEME.search(t).group(1) or _THEME.search(t).group(2) or "").lower()
        _ui_action("theme", mode=want)
        _speak(f"Switching to {want} mode, sir." if want else "Switching the theme, sir.")
        return True
    if _CAL_WORD.search(t) or re.search(r"\b(?:schedule|today|tomorrow|this week|tonight)\b", low):
        if _Q_CAL.search(t) and not _CAL_ADD.search(t) and _read_calendar(t):
            return True
    if _Q_MEM.match(t) and _read_memory():
        return True
    if _Q_TASK.search(t) and not re.search(r"\b(?:research|compare|create a report|analy[sz]e)\b", low) and _read_tasks():
        return True
    if _Q_FILES.search(t) and _read_files():
        return True
    if _Q_TOOLS.search(t) and _read_tools():
        return True
    m = _CAL_DONE.match(t)
    if m:
        cal = [c for c in (_state_snapshot().get("cal") or []) if isinstance(c, dict)]
        hit = _best_match(m.group(1), cal, "n")
        if hit:
            _ui_action("cal_done", name=str(hit.get("n")), d=str(hit.get("d")), t=str(hit.get("t")))
            _speak(f"Marked {hit.get('n')} as done, sir.")
            return True
    m = _CAL_DEL.match(t)
    if m:
        cal = [c for c in (_state_snapshot().get("cal") or []) if isinstance(c, dict)]
        hit = _best_match(m.group(1), cal, "n")
        if hit:
            _ui_action("cal_del", name=str(hit.get("n")), d=str(hit.get("d")), t=str(hit.get("t")))
            _speak(f"Removed {hit.get('n')} from your calendar, sir.")
            return True
    m = _MEM_ADD.match(t)
    if m and _state_snapshot():
        fact = m.group(1).strip()
        _ui_action("mem_add", text=fact[:300])
        _speak(f"Noted, sir. I will remember that {fact}.")
        return True
    m = _MEM_DEL.match(t)
    if m:
        mem = [x for x in (_state_snapshot().get("mem") or []) if isinstance(x, dict)]
        key = m.group(1).lower()
        if any(key in str(x.get("t", "")).lower() for x in mem):
            _ui_action("mem_del", text=m.group(1).strip())
            _speak("Done, sir. That memory is deleted.")
            return True
    return None


# ----------------------------------------------------------------------------
# command router
# ----------------------------------------------------------------------------
def handle(text: str) -> Optional[bool]:
    """True when handled, None to let FRIDAY carry on exactly as before."""
    t = (text or "").strip()
    if not t or len(t) > 320:
        return None
    low = t.lower()
    try:
        # pending safety question (yes / no / confirm) is always the vision hub's business
        try:
            import friday_action_safety as safety
            if safety.pending():
                return None
        except Exception:
            pass

        # --- V3.1: reading / acting on every page of the left-hand menu -------------
        _done = _extra_menu(t, low)
        if _done:
            return True

        # --- open a page of the app -------------------------------------------------
        m = _NAV.search(t)
        if m:
            key = re.sub(r"\s+", " ", (m.group(1) or m.group(2) or "").lower()).replace(" & ", " and ")
            key = {"agenda": "calendar"}.get(key, key)
            page = _PAGES.get(key) or _PAGES.get(key.replace("and", "&"))
            if page:
                _ui_line("FRIDAY_UI::VIEW::" + page)
                _speak(f"Opening {_PAGE_SPOKEN.get(page, page)}, sir.")
                return True

        # --- calendar add --------------------------------------------------------------
        if _CAL_WORD.search(t) and _CAL_ADD.search(t) and not re.search(r"\b(?:open|launch|start)\s+(?:the\s+)?(?:windows\s+)?calendar\s*(?:app)?\s*$", low):
            return _calendar_add(t)

        # --- vision switches that had no chat phrase before ----------------------------
        if _SCREEN_VIS_OFF.search(t):
            threading.Thread(target=_hub().screen_watch, args=(False,), name="FridayChatScreenOff", daemon=True).start()
            return True
        if _SCREEN_VIS_ON.search(t):
            threading.Thread(target=_hub().screen_watch, args=(True,), name="FridayChatScreenOn", daemon=True).start()
            return True
        if _PREVIEW_ON.search(t) or _PREVIEW_OFF.search(t):
            on = bool(_PREVIEW_ON.search(t)) and not _PREVIEW_OFF.search(t)
            _hub().handle_ui({"op": "preview", "on": on})
            _speak("Live preview is on." if on else "Live preview is off.")
            return True

        # --- camera: look and describe ---------------------------------------------------
        if _SCREENISH.search(t):
            return None                                   # screen requests keep their existing routes
        if _CAM_SWITCH.search(t) and not re.search(r"\b(?:see|look|describe|show me|tell me|what)\b", low):
            return None                                   # plain on/off stays with the vision hub
        if re.search(r"\b(?:what(?:'s| has| have)? changed|is (?:there )?(?:anything|anyone) moving|any motion|detect motion|analy[sz]e|benchmark|agent)\b", low):
            return None                                   # change / motion / file analysis stay with the vision hub
        wants_camera = False
        if _CAM_WORD.search(t) and _LOOK_VERB.search(t) and not re.search(r"\b(?:turn|switch|power)\s+(?:on|off)\b", low):
            wants_camera = True
        elif any(p.search(t) for p in _PERSON_OR_ROOM):
            wants_camera = True
        elif _BARE_SEE.match(t):
            if _screen_session_running() and not _camera_session_running():
                threading.Thread(target=_describe_screen, name="FridayChatScreenLook", daemon=True).start()
                return True
            wants_camera = True
        if wants_camera:
            threading.Thread(target=describe_camera, args=(t,), name="FridayChatCameraLook", daemon=True).start()
            return True
    except Exception as exc:
        _log(f"Chat access fell through safely: {exc}", "recovery")
    return None
