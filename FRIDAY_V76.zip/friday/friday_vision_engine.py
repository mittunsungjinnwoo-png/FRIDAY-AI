"""
FRIDAY OPENCV 5 VISION ENGINE
=============================
The "OPENCV 5 VISION ENGINE" box of the competition architecture:

    Camera / Screen / Image / Video  ->  OpenCV 5  ->  VISION STATE ("what is happening?")

Everything here is plain OpenCV + NumPy (works on OpenCV 5.x and, for development, 4.x):

  * object detection   - a user ONNX model on OpenCV 5's new DNN engine (YOLO-style outputs),
                         built-in OpenCV detectors (faces / people when the build has them) and a
                         model-free contour "object proposal" detector that needs no download
  * tracking           - multi-object tracker (IoU + distance matching, Kalman smoothing)
  * OCR / text         - Tesseract through OpenCV pre-processing, plus OpenCV-only text localisation
  * motion detection   - running-average background model + connected regions + direction
  * visual change      - structural-similarity change map between two frames (action verification)
  * spatial relations  - "the phone is to the left of the laptop"
  * scene understanding- OpenCV facts composed into a VisionState; optional Gemini narrative on top
  * confidence scores  - on every object, on frame quality and on the whole state
  * image / video      - analyse a file; video is sampled, tracked and summarised

Nothing here is imported at FRIDAY start-up; importing this module has no side effects and never
opens a camera.  The camera only turns on when the user asks (voice command, or the Vision page).
"""
from __future__ import annotations

import base64
import collections
import io
import json
import math
import os
import platform
import re
import statistics
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

import friday_vision_config as cfg

try:  # the whole module degrades to "unavailable" instead of raising
    import cv2
    import numpy as np
except Exception as _cv_error:  # pragma: no cover - depends on the machine
    cv2 = None  # type: ignore
    np = None  # type: ignore
    _CV_ERROR = str(_cv_error)
else:
    _CV_ERROR = ""

COCO_LABELS = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat", "traffic light",
    "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
    "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard",
    "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple",
    "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard",
    "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase",
    "scissors", "teddy bear", "hair drier", "toothbrush",
]

ERROR_PATTERNS = [
    r"\berror\b", r"\bfailed\b", r"\bfailure\b", r"\bexception\b", r"\btraceback\b", r"not responding",
    r"\bfatal\b", r"\bcrash(?:ed)?\b", r"can(?:'|no)t (?:be )?(?:found|open|connect|load)", r"\bunable to\b",
    r"\b404\b", r"\b500\b", r"access denied", r"permission denied", r"\bwarning\b", r"has stopped working",
    r"no internet", r"connection (?:lost|refused|timed out)", r"file not found", r"not found",
]

LOCK = threading.RLock()
_LAST_STATE: dict[str, Any] = {}
_HISTORY: collections.deque = collections.deque(maxlen=60)
_LISTENERS: list[Callable[[str, dict], None]] = []


# ============================================================================
# availability / environment
# ============================================================================
def available() -> bool:
    return cv2 is not None and np is not None


def cv_version() -> str:
    return getattr(cv2, "__version__", "") if cv2 is not None else ""


def is_opencv5() -> bool:
    v = cv_version()
    try:
        return int(v.split(".")[0]) >= 5
    except Exception:
        return False


def _engine_constant(pref: str) -> Optional[int]:
    """Map a setting (auto/new/classic) to the DNN engine constant of this OpenCV build."""
    dnn = getattr(cv2, "dnn", None)
    if dnn is None:
        return None
    names = {"new": ("ENGINE_NEW", "ENGINE_OPENCV"), "classic": ("ENGINE_CLASSIC",), "auto": ("ENGINE_AUTO",)}
    for n in names.get(pref, ()):
        if hasattr(dnn, n):
            return int(getattr(dnn, n))
    return None


def environment() -> dict[str, Any]:
    """Everything the evaluation report needs to say about the machine / OpenCV build."""
    info: dict[str, Any] = {
        "available": available(),
        "error": _CV_ERROR,
        "opencv_version": cv_version(),
        "opencv5": is_opencv5(),
        "python": platform.python_version(),
        "platform": platform.system(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
    }
    if not available():
        return info
    try:
        info["optimized"] = bool(cv2.useOptimized())
        info["threads"] = int(cv2.getNumThreads())
    except Exception:
        pass
    try:
        build = cv2.getBuildInformation()
        info["build_flags"] = {
            "kleidicv": bool(re.search(r"kleidicv\s*:\s*YES", build, re.I)) or "KleidiCV" in build and "YES" in build.split("KleidiCV", 1)[1][:40],
            "neon": bool(re.search(r"NEON", build)),
            "avx2": bool(re.search(r"AVX2", build)),
            "opencl": bool(re.search(r"OpenCL:\s+YES", build)),
        }
    except Exception:
        info["build_flags"] = {}
    info["dnn_engines"] = [n for n in ("ENGINE_AUTO", "ENGINE_CLASSIC", "ENGINE_NEW", "ENGINE_OPENCV") if hasattr(getattr(cv2, "dnn", None), n)]
    info["cool"] = cool_detected()
    return info


def cool_detected() -> dict[str, Any]:
    """Best-effort check for the Cloud-Optimized OpenCV Library (AWS Graviton AMI keeps it under /opt/cool)."""
    arm = platform.machine().lower() in {"aarch64", "arm64", "armv8l"}
    path_hit = any(Path(p).exists() for p in ("/opt/cool", "/opt/cool/lib", "/opt/cool/python"))
    flag = os.environ.get("FRIDAY_COOL", "").strip().lower() in {"1", "true", "yes"}
    return {"arm64": arm, "cool_path_present": path_hit, "declared": flag, "active": bool(arm and (path_hit or flag))}


def _need_cv() -> None:
    if not available():
        raise RuntimeError("OpenCV is not installed. Install it with:  pip install -U opencv-python-headless  (" + _CV_ERROR + ")")


# ============================================================================
# small geometry / colour helpers
# ============================================================================
REGIONS = [["top-left", "top", "top-right"], ["left", "center", "right"], ["bottom-left", "bottom", "bottom-right"]]


def region_name(cx: float, cy: float, w: int, h: int) -> str:
    col = min(2, max(0, int(cx / max(1, w) * 3)))
    row = min(2, max(0, int(cy / max(1, h) * 3)))
    return REGIONS[row][col]


def iou(a: list, b: list) -> float:
    ax1, ay1, ax2, ay2 = a[0], a[1], a[0] + a[2], a[1] + a[3]
    bx1, by1, bx2, by2 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    iw, ih = max(0, min(ax2, bx2) - max(ax1, bx1)), max(0, min(ay2, by2) - max(ay1, by1))
    inter = iw * ih
    union = a[2] * a[3] + b[2] * b[3] - inter
    return inter / union if union > 0 else 0.0


def color_name(bgr_mean) -> str:
    b, g, r = [float(x) for x in bgr_mean[:3]]
    px = np.uint8([[[b, g, r]]])
    h, s, v = [int(x) for x in cv2.cvtColor(px, cv2.COLOR_BGR2HSV)[0][0]]
    if v < 50:
        return "black"
    if s < 40:
        return "white" if v > 200 else "gray"
    hue = h * 2
    if hue < 15 or hue >= 345:
        return "red" if v > 90 else "brown"
    if hue < 40:
        return "orange" if v > 120 else "brown"
    if hue < 70:
        return "yellow"
    if hue < 160:
        return "green"
    if hue < 200:
        return "cyan"
    if hue < 260:
        return "blue"
    if hue < 300:
        return "purple"
    return "pink"


def _limit(frame, max_side: int):
    h, w = frame.shape[:2]
    m = max(h, w)
    if max_side and m > max_side:
        s = max_side / float(m)
        return cv2.resize(frame, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA), s
    return frame, 1.0


_LAST_ANALYSED: dict[str, Any] = {"frame": None, "ts": 0.0}


def annotate_frame(frame, state: Optional[dict], max_side: int = 640, regions=None):
    """V7.6: the picture exactly as analysed, with the detections drawn on it. Boxes are scaled from the size the
    detector worked on (state["size"]) to this frame, so they always sit on the right pixels."""
    _need_cv()
    prev, ps = _limit(frame, max_side)
    prev = prev.copy()
    fh, fw = frame.shape[:2]
    sw, sh = (state or {}).get("size") or [fw, fh]
    kx, ky = ps * fw / float(max(1, sw)), ps * fh / float(max(1, sh))
    for o in ((state or {}).get("objects") or [])[:12]:
        try:
            x, y, bw, bh = o["bbox"]
            p1, p2 = (int(x * kx), int(y * ky)), (int((x + bw) * kx), int((y + bh) * ky))
            cv2.rectangle(prev, p1, p2, (255, 170, 40), 2)
            lab = f"{str(o.get('label', ''))[:18]} {int(round(float(o.get('conf', 0)) * 100))}%"
            cv2.putText(prev, lab, (p1[0], max(12, p1[1] - 4)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 200, 80), 1, cv2.LINE_AA)
        except Exception:
            continue
    for (x, y, bw, bh) in (regions or [])[:6]:
        cv2.rectangle(prev, (int(x * ps), int(y * ps)), (int((x + bw) * ps), int((y + bh) * ps)), (60, 220, 90), 1)
    return prev


def encode_jpeg(frame, max_side: int = 0, quality: int = 70) -> bytes:
    _need_cv()
    img = _limit(frame, max_side)[0] if max_side else frame
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
    return bytes(buf) if ok else b""


def decode_image(data: bytes):
    _need_cv()
    arr = np.frombuffer(data, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)


def frame_quality(frame) -> dict[str, Any]:
    """Blur / brightness / contrast -> a 0..1 'how much can I trust this frame' score."""
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    g = _limit(g, 480)[0]
    sharp = float(cv2.Laplacian(g, cv2.CV_64F).var())
    bright = float(g.mean())
    contrast = float(g.std())
    s_sharp = min(1.0, sharp / 120.0)
    s_bright = 1.0 - min(1.0, abs(bright - 128.0) / 128.0) * 0.8
    s_contrast = min(1.0, contrast / 45.0)
    score = round(0.4 * s_sharp + 0.25 * s_bright + 0.35 * s_contrast, 3)
    notes = []
    if bright < 45:
        notes.append("very dark")
    if bright > 215:
        notes.append("overexposed")
    if sharp < 15:
        notes.append("blurry or flat")
    return {"score": score, "sharpness": round(sharp, 1), "brightness": round(bright, 1), "contrast": round(contrast, 1), "notes": notes}


# ============================================================================
# detectors
# ============================================================================
class ContourDetector:
    """Model-free 'object proposal' detector: finds things that stand out from the dominant background."""

    name = "contours"

    @staticmethod
    def _foreground_mask(small):
        lab = cv2.cvtColor(cv2.GaussianBlur(small, (5, 5), 0), cv2.COLOR_BGR2LAB)
        h, w = lab.shape[:2]
        q = (lab // 24).astype(np.int32)
        key = q[..., 0] * 100 + q[..., 1] * 10 + q[..., 2]
        vals, counts = np.unique(key, return_counts=True)
        modal = vals[int(np.argmax(counts))]
        bg_pixels = lab[key == modal]
        bg_share = float(len(bg_pixels)) / float(h * w)
        bg = bg_pixels.reshape(-1, 3).mean(axis=0)
        dist = np.linalg.norm(lab.astype(np.float32) - bg.astype(np.float32), axis=2)
        dist8 = np.clip(dist * 3.0, 0, 255).astype(np.uint8)
        _, mask = cv2.threshold(dist8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        floor = 14 * 3
        if float(dist8.max()) < floor:
            mask[:] = 0
        else:
            mask[dist8 < floor] = 0
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        if bg_share < 0.30:                       # cluttered / textured scene: lean on edges instead
            edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 0), 40, 120)
            mask = cv2.bitwise_or(mask, cv2.dilate(edges, np.ones((3, 3), np.uint8), iterations=1))
        return mask, dist8, bg_share

    def detect(self, frame, conf_threshold: float = 0.0) -> list[dict]:
        small, s = _limit(frame, 480)
        h, w = small.shape[:2]
        mask, dist8, bg_share = self._foreground_mask(small)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        total = float(h * w)
        out: list[dict] = []
        for c in cnts:
            area = cv2.contourArea(c)
            frac = area / total
            if frac < 0.004 or frac > 0.65:
                continue
            x, y, bw, bh = cv2.boundingRect(c)
            if bw < 8 or bh < 8:
                continue
            hull_area = max(1.0, cv2.contourArea(cv2.convexHull(c)))
            solidity = area / hull_area
            peri = cv2.arcLength(c, True)
            poly = cv2.approxPolyDP(c, 0.03 * peri, True)
            circ = 4 * math.pi * area / (peri * peri) if peri > 0 else 0.0
            nv = len(poly)
            if nv == 3:
                shape = "triangle"
            elif nv == 4:
                ar = bw / float(bh)
                shape = "square" if 0.88 <= ar <= 1.12 else "rectangle"
            elif circ > 0.78:
                shape = "circle"
            else:
                shape = "object"
            m = np.zeros((h, w), np.uint8)
            cv2.drawContours(m, [c], -1, 255, -1)
            core = cv2.erode(m, kernel, iterations=1)
            col = color_name(cv2.mean(small, mask=core if cv2.countNonZero(core) > 20 else m))
            contrast = float(cv2.mean(dist8, mask=m)[0]) / 255.0
            conf = max(0.2, min(0.95, 0.30 + 0.35 * solidity + 0.9 * contrast + 0.1 * min(1.0, frac * 25) - 0.2 + (0.05 if bg_share > 0.5 else -0.05)))
            if conf < conf_threshold:
                continue
            inv = 1.0 / s
            out.append({"label": f"{col} {shape}", "kind": "proposal", "conf": round(conf, 3),
                        "bbox": [int(x * inv), int(y * inv), int(bw * inv), int(bh * inv)], "color": col, "shape": shape, "area_frac": round(frac, 4)})
        out.sort(key=lambda o: -o["conf"] * math.sqrt(o["area_frac"]))
        return out[:20]


class BuiltinDetector:
    """OpenCV's own classic detectors, used only when this OpenCV build ships them."""

    name = "builtin"

    def __init__(self) -> None:
        self.face = None
        self.hog = None
        try:
            data = getattr(cv2, "data", None)
            if data is not None and hasattr(cv2, "CascadeClassifier"):
                path = os.path.join(data.haarcascades, "haarcascade_frontalface_default.xml")
                if os.path.exists(path):
                    cc = cv2.CascadeClassifier(path)
                    if not cc.empty():
                        self.face = cc
        except Exception:
            self.face = None
        try:
            if hasattr(cv2, "HOGDescriptor") and hasattr(cv2, "HOGDescriptor_getDefaultPeopleDetector"):
                hog = cv2.HOGDescriptor()
                hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
                self.hog = hog
        except Exception:
            self.hog = None

    @property
    def usable(self) -> bool:
        return self.face is not None or self.hog is not None

    def detect(self, frame, conf_threshold: float = 0.0) -> list[dict]:
        out: list[dict] = []
        small, s = _limit(frame, 480)
        inv = 1.0 / s
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        if self.face is not None:
            try:
                for (x, y, w, h) in self.face.detectMultiScale(gray, 1.15, 5, minSize=(30, 30)):
                    out.append({"label": "face", "kind": "builtin", "conf": 0.7, "bbox": [int(x * inv), int(y * inv), int(w * inv), int(h * inv)]})
            except Exception:
                pass
        if self.hog is not None:
            try:
                rects, weights = self.hog.detectMultiScale(small, hitThreshold=0.6, winStride=(8, 8), padding=(8, 8), scale=1.05)
                for (x, y, w, h), wt in zip(rects, np.ravel(weights)):
                    conf = float(min(0.95, max(0.3, 0.45 + 0.2 * float(wt))))
                    if conf >= conf_threshold:
                        out.append({"label": "person", "kind": "builtin", "conf": round(conf, 3),
                                    "bbox": [int(x * inv), int(y * inv), int(w * inv), int(h * inv)]})
            except Exception:
                pass
        return out


class OnnxDetector:
    """YOLO-style ONNX detector running on OpenCV's DNN module (OpenCV 5's new engine when available)."""

    name = "onnx"

    def __init__(self, path: str, labels: list[str], size: int, engine_pref: str, fmt: str) -> None:
        _need_cv()
        self.path = path
        self.labels = labels or COCO_LABELS
        self.size = int(size or 640)
        self.fmt = fmt or "auto"
        engine = _engine_constant(engine_pref)
        t0 = time.perf_counter()
        net = None
        last: Optional[Exception] = None
        if engine is not None:
            try:
                net = cv2.dnn.readNetFromONNX(path, engine)
            except Exception as exc:
                last = exc
        if net is None:
            try:
                net = cv2.dnn.readNetFromONNX(path)
            except Exception as exc:
                raise RuntimeError(f"could not load ONNX model: {exc or last}")
        self.net = net
        self.engine_requested = engine_pref
        self.load_ms = round((time.perf_counter() - t0) * 1000, 1)

    def _letterbox(self, img):
        h, w = img.shape[:2]
        r = self.size / max(h, w)
        nh, nw = int(round(h * r)), int(round(w * r))
        resized = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
        canvas = np.full((self.size, self.size, 3), 114, np.uint8)
        top, left = (self.size - nh) // 2, (self.size - nw) // 2
        canvas[top:top + nh, left:left + nw] = resized
        return canvas, r, left, top

    def detect(self, frame, conf_threshold: float = 0.35, nms_threshold: float = 0.45) -> list[dict]:
        canvas, r, left, top = self._letterbox(frame)
        blob = cv2.dnn.blobFromImage(canvas, 1 / 255.0, (self.size, self.size), swapRB=True, crop=False)
        self.net.setInput(blob)
        out = self.net.forward()
        arr = np.array(out[0] if isinstance(out, (list, tuple)) else out)
        arr = np.squeeze(arr)
        if arr.ndim != 2:
            return []
        transposed = False
        if arr.shape[0] < arr.shape[1] and arr.shape[0] <= 4 + max(len(self.labels), 1) + 8:
            arr = arr.T                                  # [4+nc, N] -> [N, 4+nc]
            transposed = True
        rows, cols = arr.shape
        fmt = self.fmt
        if fmt == "auto":
            if cols == 6 and rows <= 1000 and not transposed:
                fmt = "end2end"
            elif cols - 5 == len(self.labels):
                fmt = "yolov5"
            elif cols - 4 == len(self.labels):
                fmt = "yolov8"
            else:
                fmt = "yolov8" if transposed else "yolov5"
        boxes, scores, classes = [], [], []
        H, W = frame.shape[:2]
        for row in arr:
            if fmt == "end2end":
                x1, y1, x2, y2, sc, cl = [float(v) for v in row[:6]]
                if sc < conf_threshold:
                    continue
                bx, by, bw, bh = x1, y1, x2 - x1, y2 - y1
            else:
                if fmt == "yolov5":
                    obj = float(row[4])
                    cls_scores = row[5:]
                    cl = int(np.argmax(cls_scores))
                    sc = obj * float(cls_scores[cl])
                else:
                    cls_scores = row[4:]
                    cl = int(np.argmax(cls_scores))
                    sc = float(cls_scores[cl])
                if sc < conf_threshold:
                    continue
                cx, cy, bw, bh = [float(v) for v in row[:4]]
                bx, by = cx - bw / 2, cy - bh / 2
            x = (bx - left) / r
            y = (by - top) / r
            boxes.append([int(max(0, x)), int(max(0, y)), int(min(W, bw / r)), int(min(H, bh / r))])
            scores.append(float(sc))
            classes.append(int(cl))
        if fmt == "end2end":
            keep = list(range(len(boxes)))
        else:
            keep = [int(i) for i in np.array(cv2.dnn.NMSBoxes(boxes, scores, conf_threshold, nms_threshold)).flatten()] if boxes else []
        res = []
        for i in keep:
            lab = self.labels[classes[i]] if 0 <= classes[i] < len(self.labels) else f"class {classes[i]}"
            res.append({"label": lab, "kind": "dnn", "conf": round(scores[i], 3), "bbox": boxes[i]})
        return res


_DET_LOCK = threading.RLock()
_DET_CACHE: dict[str, Any] = {"key": None, "onnx": None, "builtin": None, "onnx_error": ""}


def _labels_from_file(path: str) -> list[str]:
    try:
        if path and Path(path).exists():
            return [ln.strip() for ln in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if ln.strip()]
    except Exception:
        pass
    return []


def _detectors() -> dict[str, Any]:
    with _DET_LOCK:
        key = (cfg.get("onnx_model_path"), cfg.get("onnx_labels_path"), cfg.get("onnx_input_size"), cfg.get("dnn_engine"), cfg.get("onnx_output_format"))
        if _DET_CACHE["key"] != key:
            _DET_CACHE.update({"key": key, "onnx": None, "onnx_error": ""})
            path = cfg.get("onnx_model_path")
            if path:
                try:
                    if not Path(path).exists():
                        raise FileNotFoundError(path)
                    _DET_CACHE["onnx"] = OnnxDetector(path, _labels_from_file(cfg.get("onnx_labels_path")), cfg.get("onnx_input_size"),
                                                      cfg.get("dnn_engine"), cfg.get("onnx_output_format"))
                except Exception as exc:
                    _DET_CACHE["onnx_error"] = str(exc)
        if _DET_CACHE.get("builtin") is None:
            _DET_CACHE["builtin"] = BuiltinDetector()
        return _DET_CACHE


def detector_status() -> dict[str, Any]:
    d = _detectors() if available() else {}
    onnx = d.get("onnx") if d else None
    b = d.get("builtin") if d else None
    return {
        "mode": cfg.get("detector"),
        "onnx_loaded": bool(onnx), "onnx_path": cfg.get("onnx_model_path"), "onnx_error": d.get("onnx_error", "") if d else "",
        "onnx_load_ms": getattr(onnx, "load_ms", None),
        "builtin_faces": bool(b and b.face is not None), "builtin_people": bool(b and b.hog is not None),
        "contours": True,
    }


def detect_objects(frame, mode: Optional[str] = None, source_kind: str = "image") -> tuple[list[dict], list[str]]:
    """Run the detector(s) chosen in Settings. Returns (objects, names_of_detectors_used)."""
    _need_cv()
    mode = (mode or cfg.get("detector") or "auto").lower()
    conf, nms = float(cfg.get("conf_threshold")), float(cfg.get("nms_threshold"))
    d = _detectors()
    used: list[str] = []
    objects: list[dict] = []
    if mode in ("auto", "onnx") and d.get("onnx") is not None:
        try:
            objects += d["onnx"].detect(frame, conf, nms)
            used.append("onnx-dnn")
        except Exception as exc:
            d["onnx_error"] = str(exc)
    if mode in ("auto", "builtin") and d["builtin"].usable and source_kind != "screen" and not (mode == "auto" and "onnx-dnn" in used):
        objects += d["builtin"].detect(frame, conf)
        used.append("builtin")
    if mode in ("auto", "contours") or not objects:
        proposals = ContourDetector().detect(frame, 0.0)
        # keep proposals that do not overlap a named object
        for p in proposals:
            if all(iou(p["bbox"], o["bbox"]) < 0.4 for o in objects):
                objects.append(p)
        used.append("contours")
    return objects, used


# ============================================================================
# tracking
# ============================================================================
class _Track:
    _next = 1

    def __init__(self, det: dict, t: float) -> None:
        self.id = _Track._next
        _Track._next += 1
        self.label = det["label"]
        self.bbox = list(det["bbox"])
        self.conf = det.get("conf", 0.5)
        self.missed = 0
        self.hits = 1
        self.born = t
        self.trail: collections.deque = collections.deque(maxlen=40)
        cx, cy = self.bbox[0] + self.bbox[2] / 2, self.bbox[1] + self.bbox[3] / 2
        self.trail.append((t, cx, cy))
        self.kf = None
        try:
            kf = cv2.KalmanFilter(4, 2)
            kf.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
            kf.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
            kf.processNoiseCov = np.eye(4, dtype=np.float32) * 0.03
            kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * 0.5
            kf.statePost = np.array([[cx], [cy], [0], [0]], np.float32)
            self.kf = kf
        except Exception:
            self.kf = None

    def predict(self) -> tuple[float, float]:
        if self.kf is not None:
            p = self.kf.predict()
            return float(p[0][0]), float(p[1][0])
        return self.center

    @property
    def center(self) -> tuple[float, float]:
        return self.bbox[0] + self.bbox[2] / 2, self.bbox[1] + self.bbox[3] / 2

    def update(self, det: dict, t: float) -> None:
        self.bbox = list(det["bbox"])
        self.conf = 0.7 * self.conf + 0.3 * det.get("conf", 0.5)
        if det["label"] and not det["label"].endswith(("object",)):
            self.label = det["label"]
        self.missed = 0
        self.hits += 1
        cx, cy = self.center
        if self.kf is not None:
            self.kf.correct(np.array([[cx], [cy]], np.float32))
        self.trail.append((t, cx, cy))

    def velocity(self) -> tuple[float, float]:
        if len(self.trail) < 2:
            return 0.0, 0.0
        t0, x0, y0 = self.trail[max(0, len(self.trail) - 6)]
        t1, x1, y1 = self.trail[-1]
        dt = max(1e-3, t1 - t0)
        return (x1 - x0) / dt, (y1 - y0) / dt


class ObjectTracker:
    def __init__(self, max_missed: int = 8, frame_size: tuple[int, int] = (640, 480)) -> None:
        self.tracks: list[_Track] = []
        self.max_missed = max_missed
        self.frame_size = frame_size
        self.retired: list[dict] = []

    def reset(self) -> None:
        self.tracks.clear()
        self.retired.clear()

    def update(self, dets: list[dict], frame_size: tuple[int, int], t: Optional[float] = None) -> list[dict]:
        t = time.time() if t is None else t
        self.frame_size = frame_size
        diag = math.hypot(*frame_size) or 1.0
        for tr in self.tracks:
            tr.predict()
        pairs = []
        for ti, tr in enumerate(self.tracks):
            for di, d in enumerate(dets):
                same = tr.label == d["label"] or tr.label.endswith("object") or d["label"].endswith("object")
                ov = iou(tr.bbox, d["bbox"])
                cx, cy = d["bbox"][0] + d["bbox"][2] / 2, d["bbox"][1] + d["bbox"][3] / 2
                dist = math.hypot(cx - tr.center[0], cy - tr.center[1]) / diag
                if (ov > 0.05 or dist < 0.12) and (same or ov > 0.5):
                    pairs.append((1.0 - ov + dist * 2.0 + (0.0 if same else 0.5), ti, di))
        pairs.sort()
        used_t, used_d = set(), set()
        for cost, ti, di in pairs:
            if ti in used_t or di in used_d:
                continue
            used_t.add(ti)
            used_d.add(di)
            self.tracks[ti].update(dets[di], t)
        for ti, tr in enumerate(self.tracks):
            if ti not in used_t:
                tr.missed += 1
        for di, d in enumerate(dets):
            if di not in used_d:
                self.tracks.append(_Track(d, t))
        alive = []
        for tr in self.tracks:
            if tr.missed > self.max_missed:
                self.retired.append(self._summary(tr, frame_size))
            else:
                alive.append(tr)
        self.tracks = alive
        return [self._summary(tr, frame_size) for tr in self.tracks if tr.hits >= 2 and tr.missed == 0]

    def _summary(self, tr: _Track, size: tuple[int, int]) -> dict:
        w, h = size
        (t0, x0, y0), (t1, x1, y1) = tr.trail[0], tr.trail[-1]
        moved = math.hypot(x1 - x0, y1 - y0) / (math.hypot(w, h) or 1.0)
        vx, vy = tr.velocity()
        return {"id": tr.id, "label": tr.label, "conf": round(tr.conf, 3), "bbox": [int(v) for v in tr.bbox],
                "hits": tr.hits, "age_s": round(t1 - tr.born, 2), "moved_frac": round(moved, 3),
                "velocity": [round(vx, 1), round(vy, 1)],
                "from": region_name(x0, y0, w, h), "to": region_name(x1, y1, w, h),
                "moving": moved > 0.06 and math.hypot(vx, vy) > 4}


# ============================================================================
# motion + change detection
# ============================================================================
class MotionDetector:
    """Running-average background model. Sensitivity 1..100 comes from Settings."""

    def __init__(self) -> None:
        self.bg = None
        self.frames = 0
        self.prev_centroid: Optional[tuple[float, float]] = None

    def reset(self) -> None:
        self.bg = None
        self.frames = 0
        self.prev_centroid = None

    def update(self, frame, sensitivity: Optional[int] = None, min_area: Optional[int] = None) -> dict[str, Any]:
        sens = int(sensitivity if sensitivity is not None else cfg.get("motion_sensitivity"))
        sens = max(1, min(100, sens))
        # Some webcams renegotiate their capture resolution mid-session. Keep the
        # background model in lockstep with the current frame to avoid OpenCV
        # arithm_op size/channel mismatch exceptions.
        if frame is None or getattr(frame, "size", 0) == 0:
            return {"motion": False, "level": 0.0, "regions": [], "direction": "none", "warming_up": True}
        if len(frame.shape) == 2:
            frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
        elif len(frame.shape) == 3 and frame.shape[2] == 4:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        elif len(frame.shape) != 3 or frame.shape[2] != 3:
            raise ValueError(f"Unsupported camera frame shape: {getattr(frame, 'shape', None)}")
        small, s = _limit(frame, 320)
        gray = cv2.GaussianBlur(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), (7, 7), 0)
        h, w = gray.shape
        if self.bg is None or self.bg.shape != gray.shape:
            self.bg = gray.astype("float32")
            self.frames = 0
            self.prev_centroid = None
        self.frames += 1
        diff = cv2.absdiff(gray, cv2.convertScaleAbs(self.bg))
        cv2.accumulateWeighted(gray, self.bg, 0.05)
        if self.frames < 3:
            return {"motion": False, "level": 0.0, "regions": [], "direction": "none", "warming_up": True}
        thr = int(52 - 0.42 * sens)                       # sens 1 -> 52, sens 100 -> 10
        _, mask = cv2.threshold(diff, thr, 255, cv2.THRESH_BINARY)
        mask = cv2.dilate(mask, np.ones((5, 5), np.uint8), iterations=2)
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        ma = float(min_area if min_area is not None else cfg.get("motion_min_area")) * (s * s)
        regions, tot, cx_sum, cy_sum = [], 0.0, 0.0, 0.0
        inv = 1.0 / s
        for c in cnts:
            a = cv2.contourArea(c)
            if a < max(30.0, ma):
                continue
            x, y, bw, bh = cv2.boundingRect(c)
            regions.append([int(x * inv), int(y * inv), int(bw * inv), int(bh * inv)])
            tot += a
            cx_sum += (x + bw / 2) * a
            cy_sum += (y + bh / 2) * a
        level = round(100.0 * tot / float(h * w), 2)
        direction = "none"
        if regions and tot > 0:
            cx, cy = cx_sum / tot, cy_sum / tot
            if self.prev_centroid is not None:
                dx, dy = cx - self.prev_centroid[0], cy - self.prev_centroid[1]
                if math.hypot(dx, dy) > 2.0:
                    direction = ("right" if dx > 0 else "left") if abs(dx) >= abs(dy) else ("down" if dy > 0 else "up")
            self.prev_centroid = (cx, cy)
        else:
            self.prev_centroid = None
        return {"motion": bool(regions), "level": level, "regions": regions[:12], "direction": direction, "warming_up": False}


def compare_frames(before, after, threshold: Optional[float] = None) -> dict[str, Any]:
    """Visual change between two frames: structural similarity map + changed regions."""
    _need_cv()
    thr = float(threshold if threshold is not None else cfg.get("change_threshold"))
    if before is None or after is None or getattr(before, "size", 0) == 0 or getattr(after, "size", 0) == 0:
        raise ValueError("Cannot compare empty camera/screen frames.")
    def _bgr(frame):
        if len(frame.shape) == 2:
            return cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
        if len(frame.shape) == 3 and frame.shape[2] == 4:
            return cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        if len(frame.shape) == 3 and frame.shape[2] == 3:
            return frame
        raise ValueError(f"Unsupported frame shape: {getattr(frame, 'shape', None)}")
    # Camera drivers may change resolution or pixel format mid-session. Normalize
    # both frames to contiguous uint8 BGR arrays and force the exact same dimensions
    # before any arithmetic; this prevents OpenCV (-209) arithm_op failures.
    before, after = _bgr(before), _bgr(after)
    before = np.ascontiguousarray(before, dtype=np.uint8)
    after = np.ascontiguousarray(after, dtype=np.uint8)
    a, sa = _limit(before, 640)
    target_size = (int(a.shape[1]), int(a.shape[0]))
    b = cv2.resize(after, target_size, interpolation=cv2.INTER_AREA)
    if a.shape != b.shape or a.dtype != b.dtype:
        b = cv2.resize(b, target_size, interpolation=cv2.INTER_AREA).astype(a.dtype, copy=False)
    a = np.ascontiguousarray(a)
    b = np.ascontiguousarray(b)
    ga = cv2.GaussianBlur(cv2.cvtColor(a, cv2.COLOR_BGR2GRAY), (3, 3), 0).astype("float32")
    gb = cv2.GaussianBlur(cv2.cvtColor(b, cv2.COLOR_BGR2GRAY), (3, 3), 0).astype("float32")
    c1, c2 = (0.01 * 255) ** 2, (0.03 * 255) ** 2
    k = (7, 7)
    mu_a, mu_b = cv2.GaussianBlur(ga, k, 1.5), cv2.GaussianBlur(gb, k, 1.5)
    saa = cv2.GaussianBlur(ga * ga, k, 1.5) - mu_a * mu_a
    sbb = cv2.GaussianBlur(gb * gb, k, 1.5) - mu_b * mu_b
    sab = cv2.GaussianBlur(ga * gb, k, 1.5) - mu_a * mu_b
    ssim = ((2 * mu_a * mu_b + c1) * (2 * sab + c2)) / ((mu_a ** 2 + mu_b ** 2 + c1) * (saa + sbb + c2))
    similarity = float(ssim.mean())
    ca = cv2.GaussianBlur(a, (5, 5), 0)
    cb = cv2.GaussianBlur(b, (5, 5), 0)
    cdiff = cv2.absdiff(ca, cb).max(axis=2)             # largest per-channel colour change at each pixel
    mask = (((cdiff > 30) | ((ssim < 0.75) & (cdiff > 14)))).astype("uint8") * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w = mask.shape
    inv = 1.0 / sa
    regions = []
    for c in sorted(cnts, key=cv2.contourArea, reverse=True)[:12]:
        if cv2.contourArea(c) < 0.0004 * h * w:
            continue
        x, y, bw, bh = cv2.boundingRect(c)
        regions.append({"bbox": [int(x * inv), int(y * inv), int(bw * inv), int(bh * inv)], "where": region_name(x + bw / 2, y + bh / 2, w, h)})
    frac = float((mask > 0).sum()) / float(h * w)
    if frac < thr * 0.5:
        verdict = "no_change"
    elif frac < thr * 4:
        verdict = "minor_change"
    elif frac < 0.25:
        verdict = "significant_change"
    else:
        verdict = "major_change"
    changed = frac >= thr
    return {"similarity": round(similarity, 4), "changed_frac": round(frac, 4), "changed": bool(changed), "verdict": verdict,
            "regions": regions, "confidence": round(min(1.0, 0.55 + abs(frac - thr) * 6 + (0.2 if verdict in ("no_change", "major_change") else 0)), 3)}


# ============================================================================
# OCR and text
# ============================================================================
_TESS_STATE: dict[str, Any] = {"checked": False, "ok": False, "path": "", "error": ""}


def _tesseract_ready() -> bool:
    if _TESS_STATE["checked"] and _TESS_STATE["path"] == cfg.get("tesseract_path"):
        return bool(_TESS_STATE["ok"])
    _TESS_STATE.update({"checked": True, "ok": False, "path": cfg.get("tesseract_path"), "error": ""})
    try:
        import pytesseract
        custom = cfg.get("tesseract_path")
        candidates = [custom] if custom else []
        candidates += [r"C:\Program Files\Tesseract-OCR\tesseract.exe", r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                       os.path.expandvars(r"%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe")]
        if custom and Path(custom).exists():
            pytesseract.pytesseract.tesseract_cmd = custom
        else:
            import shutil
            if not shutil.which("tesseract"):
                for c in candidates:
                    if c and Path(c).exists():
                        pytesseract.pytesseract.tesseract_cmd = c
                        break
        pytesseract.get_tesseract_version()
        _TESS_STATE["ok"] = True
    except Exception as exc:
        _TESS_STATE["error"] = str(exc)[:200]
    return bool(_TESS_STATE["ok"])


def text_regions(frame, max_regions: int = 40) -> list[list[int]]:
    """OpenCV-only text localisation (no OCR engine needed): morphological gradient + horizontal closing."""
    small, s = _limit(frame, 960)
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    grad = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    _, bw = cv2.threshold(grad, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (15, 1)))
    cnts, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    out = []
    inv = 1.0 / s
    for c in cnts:
        x, y, w, h = cv2.boundingRect(c)
        if w < 24 or h < 8 or h > 60 or w / float(h) < 2.0:
            continue
        roi = bw[y:y + h, x:x + w]
        if cv2.countNonZero(roi) / float(w * h) < 0.30:
            continue
        out.append([int(x * inv), int(y * inv), int(w * inv), int(h * inv)])
    out.sort(key=lambda b: (b[1] // 12, b[0]))
    return out[:max_regions]


def ocr(frame, region: Optional[list[int]] = None, min_conf: int = 45, max_side: int = 1800) -> dict[str, Any]:
    """OCR through Tesseract with OpenCV pre-processing. Returns text, words with boxes and a mean confidence."""
    _need_cv()
    t0 = time.perf_counter()
    result: dict[str, Any] = {"engine": "none", "text": "", "words": [], "confidence": 0.0, "ms": 0.0}
    if not _tesseract_ready():
        result["error"] = _TESS_STATE.get("error") or "Tesseract is not installed"
        result["text_regions"] = len(text_regions(frame))
        return result
    import pytesseract
    img = frame
    ox = oy = 0
    if region:
        x, y, w, h = region
        img = frame[max(0, y):y + h, max(0, x):x + w]
        ox, oy = max(0, x), max(0, y)
    small, s = _limit(img, max_side)
    if img.shape[1] < 400:                              # small crops read better when enlarged
        up = 2.0
        small = cv2.resize(small, None, fx=up, fy=up, interpolation=cv2.INTER_CUBIC)
        s *= up
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    if gray.mean() < 110:                               # light text on dark UI -> invert for Tesseract
        gray = cv2.bitwise_not(gray)
    gray = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray)
    try:
        data = pytesseract.image_to_data(gray, lang=cfg.get("ocr_language") or "eng", output_type=pytesseract.Output.DICT, config="--psm 6")
    except Exception as exc:
        result["error"] = str(exc)[:200]
        return result
    words, confs, lines = [], [], collections.OrderedDict()
    inv = 1.0 / s
    for i, txt in enumerate(data.get("text", [])):
        txt = (txt or "").strip()
        try:
            conf = float(data["conf"][i])
        except Exception:
            conf = -1
        if not txt or conf < min_conf:
            continue
        x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
        bb = [int(x * inv) + ox, int(y * inv) + oy, int(w * inv), int(h * inv)]
        words.append({"text": txt, "conf": round(conf / 100.0, 3), "bbox": bb})
        confs.append(conf / 100.0)
        key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        lines.setdefault(key, []).append(txt)
    result.update({"engine": "tesseract", "words": words[:400], "text": "\n".join(" ".join(v) for v in lines.values()),
                   "confidence": round(sum(confs) / len(confs), 3) if confs else 0.0, "ms": round((time.perf_counter() - t0) * 1000, 1)})
    return result


def find_text(frame, query: str, ocr_result: Optional[dict] = None) -> Optional[dict]:
    """Locate a word / short phrase on screen. Returns {bbox, center, conf} or None."""
    res = ocr_result or ocr(frame)
    words = res.get("words", [])
    q = [w for w in re.split(r"\s+", query.strip().lower()) if w]
    if not q or not words:
        return None
    norm = [re.sub(r"[^\w]+", "", w["text"].lower()) for w in words]
    qn = [re.sub(r"[^\w]+", "", w) for w in q]
    best = None
    for i in range(len(words) - len(qn) + 1):
        if all(norm[i + j] == qn[j] or (len(qn[j]) > 4 and qn[j] in norm[i + j]) for j in range(len(qn))):
            xs = [words[i + j]["bbox"] for j in range(len(qn))]
            x1, y1 = min(b[0] for b in xs), min(b[1] for b in xs)
            x2, y2 = max(b[0] + b[2] for b in xs), max(b[1] + b[3] for b in xs)
            conf = sum(words[i + j]["conf"] for j in range(len(qn))) / len(qn)
            cand = {"bbox": [x1, y1, x2 - x1, y2 - y1], "center": [int((x1 + x2) / 2), int((y1 + y2) / 2)], "conf": round(conf, 3), "text": query}
            if best is None or cand["conf"] > best["conf"]:
                best = cand
    return best


def detect_errors(text: str) -> dict[str, Any]:
    low = (text or "").lower()
    hits = []
    for pat in ERROR_PATTERNS:
        m = re.search(pat, low)
        if m:
            start = max(0, m.start() - 40)
            snippet = low[start:m.end() + 60].replace("\n", " ").strip()
            if snippet not in hits:
                hits.append(snippet)
    return {"has_error": bool(hits), "matches": hits[:5]}


# ============================================================================
# UI elements on screen (buttons / panels / windows)
# ============================================================================
def ui_elements(frame, max_items: int = 40) -> list[dict]:
    """Rectangular widgets (buttons, fields, panels) found by edge geometry, in screen coordinates."""
    small, s = _limit(frame, 960)
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(cv2.GaussianBlur(gray, (3, 3), 0), 30, 110)
    edges = cv2.dilate(edges, np.ones((2, 2), np.uint8))
    cnts, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    H, W = gray.shape
    inv = 1.0 / s
    out = []
    for c in cnts:
        x, y, w, h = cv2.boundingRect(c)
        if w < 28 or h < 14 or w > W * 0.95 or h > H * 0.9:
            continue
        area = cv2.contourArea(c)
        if area / float(w * h) < 0.6 and cv2.arcLength(c, True) < 2 * (w + h) * 0.8:
            continue
        peri = cv2.arcLength(c, True)
        poly = cv2.approxPolyDP(c, 0.04 * peri, True)
        if len(poly) != 4:
            continue
        kind = "button" if (h < 70 and w < 360 and w / float(h) < 9) else ("field" if h < 70 else "panel")
        out.append({"kind": kind, "bbox": [int(x * inv), int(y * inv), int(w * inv), int(h * inv)]})
    out.sort(key=lambda e: e["bbox"][2] * e["bbox"][3])
    dedup: list[dict] = []
    for e in out:
        if all(iou(e["bbox"], d["bbox"]) < 0.8 for d in dedup):
            dedup.append(e)
    return dedup[:max_items]


# ============================================================================
# spatial relationships
# ============================================================================
def relations(objects: list[dict], limit: int = 8) -> list[dict]:
    named = [o for o in objects if o.get("kind") != "proposal"] or objects
    named = named[:10]
    out = []
    for i, a in enumerate(named):
        for b in named[i + 1:]:
            ax, ay, aw, ah = a["bbox"]
            bx, by, bw, bh = b["bbox"]
            acx, acy, bcx, bcy = ax + aw / 2, ay + ah / 2, bx + bw / 2, by + bh / 2
            ov = iou(a["bbox"], b["bbox"])
            inside = (ax >= bx and ay >= by and ax + aw <= bx + bw and ay + ah <= by + bh)
            inside_r = (bx >= ax and by >= ay and bx + bw <= ax + aw and by + bh <= ay + ah)
            dx, dy = bcx - acx, bcy - acy
            if inside:
                rel = "inside"
            elif inside_r:
                rel = "contains"
            elif ov > 0.15:
                rel = "overlapping"
            elif abs(dx) >= abs(dy):
                rel = "left of" if dx > 0 else "right of"          # a is left of b if b is further right
            else:
                rel = "above" if dy > 0 else "below"
            gap = math.hypot(dx, dy) / (math.hypot(aw + bw, ah + bh) / 2 or 1.0)
            out.append({"a": a["label"], "b": b["label"], "relation": rel, "near": gap < 1.6,
                        "text": f"The {a['label']} is {rel} the {b['label']}" if rel not in ("contains",) else f"The {a['label']} contains the {b['label']}"})
    out.sort(key=lambda r: (not r["near"], r["relation"] == "overlapping"))
    return out[:limit]


# ============================================================================
# scene understanding + VisionState
# ============================================================================
def _count_phrase(objects: list[dict]) -> str:
    named = collections.Counter(o["label"] for o in objects if o.get("kind") != "proposal")
    props = [o for o in objects if o.get("kind") == "proposal"]
    parts = [f"{n} {lab}{'s' if n > 1 and not lab.endswith('s') else ''}" for lab, n in named.most_common(6)]
    if props and not named:
        word = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five"}.get(len(props), str(len(props)))
        return f"{word} object{'s' if len(props) != 1 else ''}"
    if props:
        parts.append(f"{len(props)} other object{'s' if len(props) != 1 else ''}")
    return ", ".join(parts)


def describe(state: dict) -> str:
    """Natural sentences for speaking: 'There are three objects on the desk.' style."""
    if not state or state.get("error"):
        return state.get("error", "I could not see anything.") if state else "I could not see anything."
    src = state.get("source", {}).get("kind", "image")
    where = {"camera": "in the camera view", "screen": "on the screen", "image": "in the image", "video": "in the video"}.get(src, "in view")
    objs = state.get("objects", [])
    s: list[str] = []
    if objs:
        s.append(f"I can see {_count_phrase(objs)} {where}.")
    else:
        s.append(f"I don't see any distinct objects {where}.")
    for t in (state.get("tracks") or [])[:2]:
        if t.get("moving"):
            s.append(f"The {t['label']} moved from the {t['from']} to the {t['to']}.")
    m = state.get("motion") or {}
    if m.get("motion"):
        s.append(f"There is movement {('toward the ' + m['direction']) if m.get('direction') not in (None, 'none') else 'in view'}.")
    rel = [r for r in state.get("relations", []) if r["near"]][:2]
    if rel:
        s.append(" ".join(r["text"] + "." for r in rel))
    txt = state.get("text") or {}
    err = (state.get("errors") or {}).get("has_error")
    if err:
        s.append("The screen contains what looks like an error message.")
    elif txt.get("text"):
        s.append("There is readable text here.")
    q = state.get("quality", {})
    if q.get("score", 1) < 0.3:
        s.append("The image quality is low (" + ", ".join(q.get("notes") or ["low contrast"]) + "), so I am less certain.")
    narrative = (state.get("scene") or {}).get("narrative")
    if narrative:
        s.append(narrative)
    return " ".join(s)


def make_state(frame, source: dict, *, objects=None, used=None, tracks=None, motion=None, text=None, relations_=None,
               timings=None, extra=None) -> dict[str, Any]:
    h, w = frame.shape[:2]
    quality = frame_quality(frame)
    objects = objects or []
    for o in objects:
        x, y, bw, bh = o["bbox"]
        o["center"] = [int(x + bw / 2), int(y + bh / 2)]
        o["region"] = region_name(x + bw / 2, y + bh / 2, w, h)
    confs = [o.get("conf", 0.5) for o in objects]
    overall = round(0.5 * quality["score"] + 0.5 * (sum(confs) / len(confs) if confs else 0.5), 3)
    state = {"ts": time.time(), "source": source, "size": [w, h], "objects": objects, "detectors": used or [],
             "tracks": tracks or [], "motion": motion or {}, "text": text or {}, "relations": relations_ if relations_ is not None else relations(objects),
             "quality": quality, "confidence": overall, "timings_ms": timings or {}, "changes": [], "scene": {}}
    if text and text.get("text"):
        state["errors"] = detect_errors(text["text"])
    if extra:
        state.update(extra)
    state["summary"] = describe(state)
    return state


def _diff_states(prev: Optional[dict], cur: dict) -> list[str]:
    if not prev:
        return []
    out = []
    pc = collections.Counter(o["label"] for o in prev.get("objects", []))
    cc = collections.Counter(o["label"] for o in cur.get("objects", []))
    for lab in cc:
        if cc[lab] > pc.get(lab, 0):
            out.append(f"{cc[lab] - pc.get(lab, 0)} {lab} appeared")
    for lab in pc:
        if pc[lab] > cc.get(lab, 0):
            out.append(f"{pc[lab] - cc.get(lab, 0)} {lab} disappeared")
    if cur.get("motion", {}).get("motion") and not prev.get("motion", {}).get("motion"):
        out.append("movement started")
    if prev.get("motion", {}).get("motion") and not cur.get("motion", {}).get("motion"):
        out.append("movement stopped")
    return out[:6]


def publish(state: dict) -> dict:
    """Make this the current VisionState, record what changed, and tell listeners (UI)."""
    with LOCK:
        global _LAST_STATE
        state["changes"] = _diff_states(_LAST_STATE if _LAST_STATE.get("source", {}).get("kind") == state.get("source", {}).get("kind") else None, state)
        _LAST_STATE = state
        _HISTORY.append({"ts": state["ts"], "source": state["source"].get("kind"), "summary": state.get("summary", ""), "changes": state["changes"],
                         "objects": len(state.get("objects", []))})
    for cb in list(_LISTENERS):
        try:
            cb("state", state)
        except Exception:
            pass
    return state


def last_state() -> dict:
    with LOCK:
        return dict(_LAST_STATE)


def history(n: int = 20) -> list[dict]:
    with LOCK:
        return list(_HISTORY)[-n:]


def subscribe(cb: Callable[[str, dict], None]) -> None:
    if cb not in _LISTENERS:
        _LISTENERS.append(cb)


def compact_state(state: dict) -> dict:
    """Small JSON for the UI (no big arrays)."""
    return {"ts": state.get("ts"), "source": state.get("source"), "size": state.get("size"),
            "objects": [{k: o.get(k) for k in ("label", "conf", "bbox", "region", "kind", "id")} for o in state.get("objects", [])[:25]],
            "tracks": state.get("tracks", [])[:12], "motion": {k: v for k, v in (state.get("motion") or {}).items() if k != "regions"} | {"regions": (state.get("motion") or {}).get("regions", [])[:6]},
            "relations": [r["text"] for r in state.get("relations", [])[:5]], "quality": state.get("quality"), "confidence": state.get("confidence"),
            "detectors": state.get("detectors"), "timings_ms": state.get("timings_ms"), "changes": state.get("changes", []),
            "text": {"excerpt": (state.get("text") or {}).get("text", "")[:400], "confidence": (state.get("text") or {}).get("confidence"),
                     "engine": (state.get("text") or {}).get("engine")},
            "errors": state.get("errors"), "summary": state.get("summary", ""), "scene": state.get("scene", {}), "remote": state.get("remote", False)}


# ============================================================================
# sources: screen / camera / image / video
# ============================================================================
def grab_screen(monitor: Optional[int] = None):
    """Screenshot as BGR ndarray (mss, Pillow fallback)."""
    _need_cv()
    mon = int(cfg.get("monitor_index") if monitor is None else monitor)
    try:
        import mss
        with mss.mss() as sct:
            mons = sct.monitors
            m = mons[mon] if 0 <= mon < len(mons) else mons[0]
            shot = sct.grab(m)
            img = np.frombuffer(shot.bgra, dtype=np.uint8).reshape(shot.height, shot.width, 4)
            return cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
    except Exception:
        from PIL import ImageGrab
        im = ImageGrab.grab(all_screens=(mon == 0)).convert("RGB")
        return cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)


def read_image(path: str):
    _need_cv()
    data = np.fromfile(str(path), dtype=np.uint8)          # works with non-ASCII Windows paths
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Could not read the image: {path}")
    return img


def _open_camera(index: int):
    _need_cv()
    backends = []
    if platform.system() == "Windows":
        backends = [getattr(cv2, "CAP_DSHOW", 0), getattr(cv2, "CAP_MSMF", 0), 0]
    else:
        backends = [0]
    for be in backends:
        try:
            cap = cv2.VideoCapture(int(index), be) if be else cv2.VideoCapture(int(index))
            if cap is not None and cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                ok, _ = cap.read()
                if ok:
                    return cap
                cap.release()
        except Exception:
            continue
    return None


def _cloud_allowed(kind: str) -> bool:
    return bool(cfg.get("camera_allow_cloud")) if kind == "camera" else bool(cfg.get("screen_allow_cloud")) if kind == "screen" else True


# ----------------------------------------------------------------------------
# analysis of one frame
# ----------------------------------------------------------------------------
def _scale_box(b: list, inv: float) -> list:
    return [int(round(v * inv)) for v in b]


def analyze_frame(frame, source_kind: str = "image", *, label: str = "", motion: Optional[dict] = None, tracker: Optional[ObjectTracker] = None,
                  do_ocr: Optional[bool] = None, do_ui: bool = False, do_detect: bool = True, mode: Optional[str] = None,
                  publish_state: bool = True) -> dict[str, Any]:
    """The core: one frame in, one VisionState out. All coordinates are in the ORIGINAL frame's pixels.
    Uses the cloud endpoint instead when it is enabled in Settings (and falls back to local if it fails)."""
    _need_cv()
    t_all = time.perf_counter()
    H, W = frame.shape[:2]
    cloud = None
    try:
        import friday_vision_cloud as vc
        if vc.enabled() and _cloud_allowed(source_kind):
            cloud = vc.analyze_remote(frame, source_kind, do_ocr=bool(do_ocr))
    except Exception:
        cloud = None
    if cloud is not None:
        cloud["source"] = {"kind": source_kind, "label": label}
        cloud["remote"] = True
        if motion:
            cloud["motion"] = motion
        cloud["summary"] = describe(cloud)
        return publish(cloud) if publish_state else cloud
    small, scale = _limit(frame, int(cfg.get("analysis_max_side")))
    inv = 1.0 / scale
    timings: dict[str, float] = {}
    t = time.perf_counter()
    objects, used = ([], [])
    if do_detect:
        objects, used = detect_objects(small, mode, source_kind)
        for o in objects:
            o["bbox"] = _scale_box(o["bbox"], inv)
    timings["detect"] = round((time.perf_counter() - t) * 1000, 1)
    tracks = []
    if tracker is not None:
        t = time.perf_counter()
        tracks = tracker.update(objects, (W, H))
        for tr in tracks:
            for o in objects:
                if iou(o["bbox"], tr["bbox"]) > 0.6:
                    o["id"] = tr["id"]
        timings["track"] = round((time.perf_counter() - t) * 1000, 1)
    text = None
    if do_ocr:
        t = time.perf_counter()
        text = ocr(frame)
        timings["ocr"] = round((time.perf_counter() - t) * 1000, 1)
    extra = {}
    if do_ui:
        extra["ui_elements"] = ui_elements(frame)
    state = make_state(frame, {"kind": source_kind, "label": label}, objects=objects, used=used, tracks=tracks, motion=motion, text=text,
                       timings=timings, extra=extra)
    state["timings_ms"]["total"] = round((time.perf_counter() - t_all) * 1000, 1)
    if source_kind in ("image", "screen", "camera"):
        _LAST_ANALYSED["frame"], _LAST_ANALYSED["ts"] = frame, state["ts"]
    try:
        import friday_eval_metrics as em
        em.record_vision_latency(state["timings_ms"]["total"])
    except Exception:
        pass
    return publish(state) if publish_state else state


# ----------------------------------------------------------------------------
# Gemini scene narrative (optional; reasons over the OpenCV facts)
# ----------------------------------------------------------------------------
def _backend():
    import friday_backend
    return friday_backend


def gemini_describe(frame, state: Optional[dict] = None, question: str = "", source_kind: str = "image", timeout: float = 25.0) -> dict[str, Any]:
    """Ask Gemini about a frame, giving it the OpenCV facts as grounding. Returns {ok, text, error, ms}."""
    if not _cloud_allowed(source_kind):
        return {"ok": False, "error": f"Sending {source_kind} frames to Gemini is switched off in Settings > Vision.", "blocked": True}
    t0 = time.perf_counter()
    try:
        jb = _backend()
        jb._ensure_gemini_client()
        if getattr(jb, "client", None) is None:
            return {"ok": False, "error": "Gemini is not connected (add your key in Settings > AI)."}
        from google.genai import types
        small, _ = _limit(frame, 1280)
        ok, buf = cv2.imencode(".jpg", small, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
        part = types.Part.from_bytes(data=bytes(buf), mime_type="image/jpeg")
        facts = ""
        if state:
            facts = (f"OpenCV measured: {state.get('summary', '')} Objects: " + json.dumps([{k: o.get(k) for k in ('label', 'conf', 'region')} for o in state.get('objects', [])[:12]])
                     + f". Motion: {json.dumps({k: v for k, v in (state.get('motion') or {}).items() if k != 'regions'})}.")
            if (state.get("text") or {}).get("text"):
                facts += " Text read from the image: " + state["text"]["text"][:500].replace("\n", " | ")
        prompt = ("You are FRIDAY's visual reasoning layer. " + (question.strip() or "Describe what is happening in this image in 1-3 plain sentences.") +
                  " Use the OpenCV measurements as ground truth for counts, positions and text; only add what you can actually see. "
                  "Be concise, no preamble.\n" + facts)
        import concurrent.futures
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        fut = pool.submit(lambda: jb._gemini_generate([prompt, part]))
        try:
            resp = fut.result(timeout=timeout)
        finally:
            pool.shutdown(wait=False)
        text = (jb._response_text(resp) or "").strip()
        ms = round((time.perf_counter() - t0) * 1000, 1)
        return {"ok": bool(text), "text": text[:1500], "ms": ms, **({} if text else {"error": "empty answer"})}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:200]}", "ms": round((time.perf_counter() - t0) * 1000, 1)}


def gemini_detect_named(frame, source_kind: str = "image") -> dict[str, Any]:
    """Ask Gemini for NAMED objects with boxes (semantic detector), merged by the caller."""
    if not _cloud_allowed(source_kind):
        return {"ok": False, "objects": [], "error": "blocked by privacy setting"}
    r = gemini_describe(frame, None, "List the distinct physical objects you can see as strict JSON only: "
                        '[{"label":"phone","box":[ymin,xmin,ymax,xmax]}] with box values 0-1000. At most 12 objects. No other text.', source_kind)
    if not r.get("ok"):
        return {"ok": False, "objects": [], "error": r.get("error")}
    m = re.search(r"\[.*\]", r["text"], re.S)
    objs = []
    try:
        H, W = frame.shape[:2]
        for it in json.loads(m.group(0)) if m else []:
            y1, x1, y2, x2 = [float(v) for v in it["box"]]
            objs.append({"label": str(it["label"])[:40].lower(), "kind": "semantic", "conf": 0.6,
                         "bbox": [int(x1 / 1000 * W), int(y1 / 1000 * H), int((x2 - x1) / 1000 * W), int((y2 - y1) / 1000 * H)]})
    except Exception as exc:
        return {"ok": False, "objects": [], "error": f"could not parse: {exc}"}
    return {"ok": True, "objects": objs}


# ============================================================================
# high-level entry points (screen / image / video / camera snapshot)
# ============================================================================
def see_screen(ask_gemini: bool = False, question: str = "", do_ocr: bool = True) -> dict[str, Any]:
    frame = grab_screen()
    state = analyze_frame(frame, "screen", label="screen", do_ocr=do_ocr, do_ui=True, publish_state=False)
    try:
        import friday_truth_verifier as tv
        state["context"] = {"active_window": tv.active_window_title()}
    except Exception:
        state["context"] = {}
    if ask_gemini:
        g = gemini_describe(frame, state, question, "screen")
        if g.get("ok"):
            state["scene"] = {"narrative": g["text"], "source": "gemini"}
    state["summary"] = describe(state)
    return publish(state)


def analyze_image(path: str, ask_gemini: bool = False, question: str = "", do_ocr: bool = True, named_objects: bool = False) -> dict[str, Any]:
    frame = read_image(path)
    state = analyze_frame(frame, "image", label=Path(path).name, do_ocr=do_ocr, publish_state=False)
    if named_objects:
        g = gemini_detect_named(frame, "image")
        if g.get("ok"):
            for o in g["objects"]:
                state["objects"] = [x for x in state["objects"] if not (x.get("kind") == "proposal" and iou(x["bbox"], o["bbox"]) > 0.4)]
                state["objects"].append(o)
            for o in state["objects"]:
                x, y, bw, bh = o["bbox"]
                o["center"] = [int(x + bw / 2), int(y + bh / 2)]
                o["region"] = region_name(x + bw / 2, y + bh / 2, frame.shape[1], frame.shape[0])
            state["relations"] = relations(state["objects"])
    if ask_gemini:
        g = gemini_describe(frame, state, question, "image")
        if g.get("ok"):
            state["scene"] = {"narrative": g["text"], "source": "gemini"}
    state["summary"] = describe(state)
    return publish(state)


def analyze_video(path: str, sample_fps: float = 2.0, max_frames: int = 240, ask_gemini: bool = False, progress: Optional[Callable[[float], None]] = None) -> dict[str, Any]:
    _need_cv()
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError(f"Could not open the video: {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width, height = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    duration = total / fps if total else 0.0
    step = max(1, int(round(fps / max(0.2, sample_fps))))
    tracker = ObjectTracker(max_missed=6)
    motion = MotionDetector()
    timeline, cuts, counts = [], [], collections.Counter()
    key_frames: list = []
    prev_small = None
    sampled = 0
    idx = 0
    t0 = time.perf_counter()
    last_state = None
    ocr_done = 0
    all_text: list[str] = []
    while sampled < max_frames:
        ok = cap.grab()
        if not ok:
            break
        if idx % step == 0:
            ok, frame = cap.retrieve()
            if not ok:
                break
            ts = idx / fps
            small, _ = _limit(frame, 640)
            m = motion.update(small)
            st = analyze_frame(small, "video", label=Path(path).name, motion=m, tracker=tracker, publish_state=False)
            for o in st["objects"]:
                if o.get("kind") != "proposal":
                    counts[o["label"]] += 1
            timeline.append({"t": round(ts, 2), "motion": m.get("level", 0.0), "objects": len(st["objects"])})
            if prev_small is not None:
                ch = compare_frames(prev_small, small)
                if ch["verdict"] == "major_change":
                    cuts.append(round(ts, 2))
            prev_small = small
            if ocr_done < 3 and sampled % max(1, max_frames // 6) == 0:
                o = ocr(small)
                if o.get("text"):
                    all_text.append(o["text"][:300])
                ocr_done += 1
            if len(key_frames) < 4 and (sampled % max(1, min(max_frames, (total // step) or 1) // 4 or 1) == 0):
                key_frames.append(small.copy())
            last_state = st
            sampled += 1
            if progress and total:
                progress(min(1.0, idx / float(total)))
        idx += 1
    cap.release()
    tracks = tracker.retired + [tracker._summary(t, (width, height)) for t in tracker.tracks]
    tracks = [t for t in tracks if t["hits"] >= 3]
    moving = [t for t in tracks if t["moving"]]
    peak = max(timeline, key=lambda x: x["motion"], default=None)
    parts = [f"The video is {duration:.0f} seconds long ({width}x{height})."]
    if counts:
        parts.append("Most common things seen: " + ", ".join(f"{k} ({v} frames)" for k, v in counts.most_common(4)) + ".")
    elif tracks:
        parts.append(f"I tracked {len(tracks)} distinct object{'s' if len(tracks) != 1 else ''}.")
    if moving:
        t = max(moving, key=lambda x: x["moved_frac"])
        parts.append(f"The {t['label']} moved from the {t['from']} to the {t['to']}.")
    if peak and peak["motion"] > 1.0:
        parts.append(f"The most movement is around {peak['t']:.0f} seconds.")
    if cuts:
        parts.append(f"{len(cuts)} scene change{'s' if len(cuts) != 1 else ''}, first at {cuts[0]:.0f} seconds.")
    if all_text:
        parts.append("Text appears in the video.")
    state = last_state or make_state(np.zeros((height or 480, width or 640, 3), np.uint8), {"kind": "video", "label": Path(path).name})
    state["source"] = {"kind": "video", "label": Path(path).name}
    state["video"] = {"duration_s": round(duration, 1), "fps": round(fps, 1), "frames_analyzed": sampled, "tracks": tracks[:20], "timeline": timeline[-200:],
                      "scene_changes": cuts[:30], "text": all_text[:3], "object_frames": dict(counts.most_common(12)),
                      "analysis_seconds": round(time.perf_counter() - t0, 2)}
    state["summary"] = " ".join(parts)
    if ask_gemini and key_frames and _cloud_allowed("video"):
        try:
            sheet = np.hstack([cv2.resize(f, (320, 240)) for f in key_frames[:3]])
            g = gemini_describe(sheet, state, "These are sample frames from one video, left to right. Say in 1-2 sentences what the video shows.", "video")
            if g.get("ok"):
                state["scene"] = {"narrative": g["text"], "source": "gemini"}
                state["summary"] += " " + g["text"]
        except Exception:
            pass
    return publish(state)


def camera_snapshot(ask_gemini: bool = False, question: str = "") -> dict[str, Any]:
    """One still from the camera (opens it, grabs a frame, closes it). Only called on an explicit user request."""
    cap = _open_camera(int(cfg.get("camera_index")))
    if cap is None:
        raise RuntimeError("I could not open the camera. Check that it is connected and not used by another app, and that Windows allows desktop apps to use it.")
    try:
        frame = None
        for _ in range(4):                  # let auto-exposure settle
            ok, frame = cap.read()
        if frame is None:
            raise RuntimeError("The camera opened but gave no picture.")
    finally:
        cap.release()
    state = analyze_frame(frame, "camera", label="camera", publish_state=False, do_ocr=False)
    if ask_gemini:
        g = gemini_describe(frame, state, question, "camera")
        if g.get("ok"):
            state["scene"] = {"narrative": g["text"], "source": "gemini"}
    state["summary"] = describe(state)
    return publish(state)


# ============================================================================
# live session (camera / screen watching with motion + tracking)
# ============================================================================
class VisionSession:
    """Continuous watcher. Runs in its own daemon thread; never touches microphone code."""

    def __init__(self) -> None:
        self.thread: Optional[threading.Thread] = None
        self.stop_flag = threading.Event()
        self.kind = ""
        self.started = 0.0
        self.frames = 0
        self.fps = 0.0
        self.error = ""
        self.preview = True            # V7.6: the live picture is on by default (untick it on the Vision page to hide it)
        self.cur_state: Optional[dict] = None
        self.tracker = ObjectTracker()
        self.motion = MotionDetector()
        self.emit: Optional[Callable[[str, dict], None]] = None
        self.last_frame = None
        self._motion_on = False
        self._cap = None            # V3.1: the open camera handle, so stop() can always release it

    @property
    def running(self) -> bool:
        return bool(self.thread and self.thread.is_alive())

    def status(self) -> dict[str, Any]:
        return {"running": self.running, "kind": self.kind if self.running else "", "since": self.started if self.running else 0, "frames": self.frames,
                "fps": round(self.fps, 1), "error": self.error, "preview": self.preview}

    def start(self, kind: str = "camera", emit: Optional[Callable[[str, dict], None]] = None) -> dict[str, Any]:
        _need_cv()
        if self.running:
            if self.kind == kind:
                return self.status()
            self.stop()
        self.kind, self.emit, self.error = kind, emit, ""
        self.stop_flag.clear()
        self.tracker.reset()
        self.motion.reset()
        self.cur_state = None
        self.frames = 0
        self.started = time.time()
        if kind == "camera":
            cap = _open_camera(int(cfg.get("camera_index")))
            if cap is None:
                self.error = "Could not open the camera."
                raise RuntimeError("I could not open the camera. Check that it is connected, not used by another app, and allowed in Windows privacy settings.")
        else:
            cap = None
        self._cap = cap
        self.thread = threading.Thread(target=self._run, args=(cap,), name=f"FridayVision-{kind}", daemon=True)
        self.thread.start()
        return self.status()

    def stop(self) -> bool:
        """V3.1: really stop the watcher and let go of the camera. Returns True only when the camera is released.
        Before, stop() gave up after 3 s and still reported "off" while the camera could be held; now it waits for the
        worker to finish and, if the worker is stuck inside a read, releases the camera handle itself."""
        self.stop_flag.set()
        th = self.thread
        if th and th.is_alive() and th is not threading.current_thread():
            th.join(timeout=5.0)
            if th.is_alive():                       # worker stuck (blocked read / slow analysis): release the device from here
                cap = self._cap
                if cap is not None:
                    try:
                        cap.release()
                    except Exception:
                        pass
                th.join(timeout=3.0)
        alive = bool(th and th.is_alive() and th is not threading.current_thread())
        if not alive:
            cap = self._cap
            self._cap = None
            if cap is not None:                      # worker already released it; a second release is harmless
                try:
                    cap.release()
                except Exception:
                    pass
            self.thread = None
            self.last_frame = None
        return not alive

    def _run(self, cap) -> None:
        last_detect = last_publish = last_preview = 0.0
        fps_t, fps_n = time.time(), 0
        auto_off = float(cfg.get("camera_auto_off_minutes")) * 60 if self.kind == "camera" else 0
        try:
            while not self.stop_flag.is_set():
                loop_start = time.time()
                if auto_off and loop_start - self.started > auto_off:
                    if self.emit:
                        self.emit("notice", {"text": "Camera switched itself off after the idle limit.", "kind": "camera_auto_off"})
                    break
                if cap is not None:
                    ok, frame = cap.read()
                    if self.stop_flag.is_set():
                        break
                    if not ok:
                        self.error = "The camera stopped sending pictures."
                        break
                else:
                    frame = grab_screen()
                self.last_frame = frame
                small, _ = _limit(frame, 640)
                m = self.motion.update(small)
                k = frame.shape[1] / float(small.shape[1])
                m["regions"] = [[int(v * k) for v in r] for r in m.get("regions", [])]
                if m.get("motion") != self._motion_on and not m.get("warming_up"):
                    self._motion_on = bool(m.get("motion"))
                    if self.emit:
                        self.emit("motion", {"motion": self._motion_on, "level": m.get("level"), "direction": m.get("direction")})
                now = time.time()
                if now - last_detect >= 0.5:
                    last_detect = now
                    st = analyze_frame(frame, self.kind, label=self.kind, motion=m, tracker=self.tracker, do_ocr=False, publish_state=False)
                    st = publish(st)
                    self.cur_state = st
                    if self.emit and now - last_publish >= 0.45:
                        last_publish = now
                        self.emit("state", st)
                if self.preview and self.emit and now - last_preview >= 1.0 / max(1, int(cfg.get("preview_fps"))):
                    last_preview = now
                    cs = self.cur_state
                    age = (now - cs["ts"]) if cs else None
                    # boxes only from THIS session's own recent analysis of THIS source (never a stale or foreign result)
                    use = cs if (cs and age is not None and age < 1.5 and (cs.get("source") or {}).get("kind") == self.kind) else None
                    prev = annotate_frame(frame, use, 640, m.get("regions", []))
                    self.emit("frame", {"jpeg": base64.b64encode(encode_jpeg(prev, 640, 70)).decode("ascii"), "w": prev.shape[1], "h": prev.shape[0],
                                        "kind": self.kind, "ts": now, "state_age_ms": int(age * 1000) if age is not None else None,
                                        "boxes": len(use.get("objects") or []) if use else 0, "src_w": frame.shape[1], "src_h": frame.shape[0]})
                fps_n += 1
                self.frames += 1
                if now - fps_t >= 1.0:
                    self.fps, fps_t, fps_n = fps_n / (now - fps_t), now, 0
                time.sleep(max(0.0, (1.0 / 15.0) - (time.time() - loop_start)))
        except Exception as exc:
            self.error = f"{type(exc).__name__}: {exc}"
        finally:
            try:
                if cap is not None:
                    cap.release()
                    if self._cap is cap:
                        self._cap = None
            except Exception:
                pass
            if self.emit:
                try:
                    self.emit("stopped", {"error": self.error, "kind": self.kind})
                except Exception:
                    pass


SESSION = VisionSession()


# ============================================================================
# micro-benchmarks (the operations the COOL / Graviton build accelerates)
# ============================================================================
def _stats(ms: list[float]) -> dict[str, float]:
    ms = sorted(ms)
    return {"median_ms": round(statistics.median(ms), 3), "p95_ms": round(ms[min(len(ms) - 1, int(len(ms) * 0.95))], 3),
            "mean_ms": round(sum(ms) / len(ms), 3), "n": len(ms)}


def synthetic_scene(w: int = 1280, h: int = 720, n: int = 5, seed: int = 7):
    """Reproducible test scene with known ground truth: coloured shapes on a dark desk."""
    rng = np.random.RandomState(seed)
    img = np.full((h, w, 3), (38, 40, 44), np.uint8)
    noise = rng.normal(0, 3, img.shape).astype(np.int16)
    img = np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)
    palette = [((40, 40, 220), "red"), ((60, 200, 60), "green"), ((220, 90, 40), "blue"), ((40, 210, 230), "yellow"), ((230, 230, 230), "white")]
    truth, placed, tries = [], [], 0
    while len(truth) < n and tries < 200:
        tries += 1
        bw, bh = int(rng.randint(w // 14, w // 7)), int(rng.randint(h // 10, h // 5))
        x, y = int(rng.randint(20, w - bw - 20)), int(rng.randint(20, h - bh - 20))
        if any(iou([x, y, bw, bh], [p[0] - 20, p[1] - 20, p[2] + 40, p[3] + 40]) > 0 for p in placed):
            continue
        col, name = palette[len(truth) % len(palette)]
        kind = ["rectangle", "circle"][len(truth) % 2]
        if kind == "circle":
            bh = bw = min(bw, bh + 40)
            y = min(y, h - bh - 20)
            if any(iou([x, y, bw, bh], [p[0] - 20, p[1] - 20, p[2] + 40, p[3] + 40]) > 0 for p in placed):
                continue
            cv2.ellipse(img, (x + bw // 2, y + bh // 2), (bw // 2, bh // 2), 0, 0, 360, col, -1)
        else:
            cv2.rectangle(img, (x, y), (x + bw, y + bh), col, -1)
        placed.append([x, y, bw, bh])
        truth.append({"bbox": [x, y, bw, bh], "label": f"{name} {kind}"})
    return img, truth


def micro_benchmark(iterations: int = 12, size: tuple[int, int] = (1280, 720)) -> dict[str, Any]:
    _need_cv()
    w, h = size
    img, _ = synthetic_scene(w, h, 6)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ops: dict[str, Callable[[], Any]] = {
        "resize (to 50%)": lambda: cv2.resize(img, (w // 2, h // 2), interpolation=cv2.INTER_LINEAR),
        "gaussian_blur 5x5": lambda: cv2.GaussianBlur(img, (5, 5), 0),
        "adaptive_threshold (gaussian)": lambda: cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2),
        "canny edges": lambda: cv2.Canny(gray, 60, 160),
        "find_contours": lambda: cv2.findContours(cv2.Canny(gray, 60, 160), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE),
        "color_convert (BGR->HSV)": lambda: cv2.cvtColor(img, cv2.COLOR_BGR2HSV),
        "ssim_change_compare": lambda: compare_frames(img, img),
        "full_vision_pipeline": lambda: analyze_frame(img, "image", do_ocr=False, publish_state=False),
    }
    out = {}
    for name, fn in ops.items():
        fn()                                                   # warm-up
        times = []
        for _ in range(iterations):
            t = time.perf_counter()
            fn()
            times.append((time.perf_counter() - t) * 1000)
        out[name] = _stats(times)
    d = _detectors().get("onnx")
    if d is not None:
        try:
            d.detect(img)
            times = []
            for _ in range(max(3, iterations // 2)):
                t = time.perf_counter()
                d.detect(img)
                times.append((time.perf_counter() - t) * 1000)
            out["dnn_inference (your ONNX model)"] = _stats(times)
        except Exception as exc:
            out["dnn_inference (your ONNX model)"] = {"error": str(exc)[:120]}
    return {"frame": f"{w}x{h}", "iterations": iterations, "operations": out, "environment": environment()}


# ============================================================================
# model download helper (optional: user supplies the URL in Settings)
# ============================================================================
def download_model(url: str, progress: Optional[Callable[[float], None]] = None) -> dict[str, Any]:
    import urllib.request
    if not re.match(r"^https://", url or "", re.I):
        return {"ok": False, "error": "Please use an https:// link to a .onnx file."}
    dest_dir = cfg.DATA_DIR / "models"
    dest_dir.mkdir(parents=True, exist_ok=True)
    name = re.sub(r"[^A-Za-z0-9._-]", "_", url.split("?")[0].rsplit("/", 1)[-1]) or "model.onnx"
    if not name.lower().endswith(".onnx"):
        name += ".onnx"
    dest = dest_dir / name
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "FRIDAY-Vision/2.3"})
        with urllib.request.urlopen(req, timeout=60) as r, open(dest.with_suffix(".part"), "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            got = 0
            while True:
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if progress and total:
                    progress(got / float(total))
                if got > 600 * 1024 * 1024:
                    raise RuntimeError("model file is larger than 600 MB")
        os.replace(dest.with_suffix(".part"), dest)
        cfg.update({"onnx_model_path": str(dest)})
        return {"ok": True, "path": str(dest), "size_mb": round(dest.stat().st_size / 1e6, 1), "status": detector_status()}
    except Exception as exc:
        try:
            dest.with_suffix(".part").unlink()
        except Exception:
            pass
        return {"ok": False, "error": f"Download failed: {exc}"}
