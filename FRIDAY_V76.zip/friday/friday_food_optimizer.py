"""
FRIDAY MEAL QUANTITY PLANNER
============================
Deterministic "how much of every item do I need?" maths for FRIDAY's weekly
meal plan.

FRIDAY does NOT estimate grocery cost. The user records the real grocery
budget themselves (for example "monthly plan groceries 30000"). This module
only works out the QUANTITY of each ingredient the planned meals will use.

How the numbers are produced (identical to the on-screen Plans tab):
- For each day, every breakfast x lunch x dinner combination the user ticked
  is enumerated (with a safety cap).
- The expected (average) quantity of each ingredient is averaged over ALL of
  those combinations; min / max across combinations are also reported.
- Coffee, tea and milk entered for a day are added as fixed quantities.
- The week total is the sum of the seven daily averages.

Completely independent of FRIDAY's voice, listening, recognition and TTS code.
"""
from __future__ import annotations
import itertools, math, re

MAX_COMBINATIONS = 100_000
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
FULL = {"Mon": "Monday", "Tue": "Tuesday", "Wed": "Wednesday", "Thu": "Thursday",
        "Fri": "Friday", "Sat": "Saturday", "Sun": "Sunday"}

UNIT_TO_BASE = {
    "kg": ("g", 1000.0), "g": ("g", 1.0), "gram": ("g", 1.0), "grams": ("g", 1.0),
    "l": ("ml", 1000.0), "ml": ("ml", 1.0),
    "pcs": ("pcs", 1.0), "pc": ("pcs", 1.0), "piece": ("pcs", 1.0), "pieces": ("pcs", 1.0),
    "cup": ("cup", 1.0), "cups": ("cup", 1.0), "tbsp": ("tbsp", 1.0), "tsp": ("tsp", 1.0),
}

ALIASES = {
    "chicken breast": "chicken", "chicken breasts": "chicken", "chicken meat": "chicken",
    "red lentils": "dhal", "lentils": "dhal", "onions": "onion", "tomatoes": "tomato",
    "potatoes": "potato", "eggs": "egg", "vegetable oil": "oil", "cooking oil": "oil",
    "sunflower oil": "oil",
}


def norm_name(name):
    s = re.sub(r"[^a-z0-9 ]+", " ", str(name).lower())
    s = re.sub(r"\s+", " ", s).strip()
    return ALIASES.get(s, s)


def base_qty(q, u):
    u = str(u or "pcs").lower()
    b, m = UNIT_TO_BASE.get(u, (u, 1.0))
    return float(q) * m, b


def _state():
    try:
        from friday_finance_engine import STATE
        return STATE
    except Exception:
        return {}


def _foods():
    return [f for f in _state().get("foods", []) if isinstance(f, dict) and isinstance(f.get("ing"), list)]


def _slots(day):
    plan = _state().get("plan", {})
    p = plan.get(day, {}) if isinstance(plan, dict) else {}
    foods = _foods()
    out = []
    for slot in ("b", "l", "d"):
        ids = p.get(slot, []) if isinstance(p, dict) else []
        fs = [f for f in foods if f.get("id") in ids]
        if fs:
            out.append(fs)
    snacks = _state().get("snacks", [])
    snack_ids = p.get("s", []) if isinstance(p, dict) else []
    ss = [x for x in snacks if isinstance(x, dict) and x.get("mode") == "homemade" and x.get("id") in snack_ids]
    if ss:
        out.append(ss)
    return out


def _drinks(day):
    b = _state().get("bev", {})
    b = b.get(day, {}) if isinstance(b, dict) else {}
    out = []
    for key, name, unit in (("coffee", "Coffee", "cup"), ("tea", "Tea", "cup"), ("milk", "Milk", "ml")):
        try:
            q = float(b.get(key) or 0)
        except Exception:
            q = 0
        if q > 0:
            out.append((name, unit, q))
    return out


def analyze(day=None):
    """Average / min / max quantity of every ingredient for one day."""
    if day is None:
        import datetime
        day = DAYS[datetime.datetime.now().weekday()]
    slots = _slots(day)
    drinks = _drinks(day)
    if not slots and not drinks:
        return {"day": day, "combination_count": 0, "ingredients": [],
                "message": f"No meal options are recorded for {FULL.get(day, day)}."}
    count = math.prod(len(fs) for fs in slots) if slots else 0
    if count > MAX_COMBINATIONS:
        raise ValueError(f"{count:,} combinations exceeds the safety limit of {MAX_COMBINATIONS:,}. "
                         "Narrow one meal slot.")
    combos = list(itertools.product(*slots)) if slots else [()]
    n = len(combos)
    per_key = {}  # (name key, base unit) -> {"name", "unit", "qtys": [one value per combination]}
    for i, chosen in enumerate(combos):
        totals = {}
        for food in chosen:
            for raw in food.get("ing", []):
                try:
                    bq, bu = base_qty(raw.get("q") or 0, raw.get("u"))
                except Exception:
                    continue
                k = (norm_name(raw.get("n", "")), bu)
                t = totals.setdefault(k, {"name": str(raw.get("n", "")).strip(), "unit": bu, "q": 0.0})
                t["q"] += bq
        for name, unit, q in drinks:
            t = totals.setdefault((norm_name(name), unit), {"name": name, "unit": unit, "q": 0.0})
            t["q"] += q
        for k, t in totals.items():
            e = per_key.setdefault(k, {"name": t["name"], "unit": t["unit"], "qtys": [0.0] * n})
            e["qtys"][i] = t["q"]
    rows = []
    for e in per_key.values():
        qs = e["qtys"]
        rows.append({"name": e["name"], "unit": e["unit"], "average_qty": sum(qs) / n,
                     "min_qty": min(qs), "max_qty": max(qs)})
    rows.sort(key=lambda r: r["name"].lower())
    return {"day": day, "combination_count": count if slots else 1, "ingredients": rows}


def week_totals():
    """Sum of the seven daily average quantities, per ingredient."""
    tot = {}
    daily = []
    for d in DAYS:
        try:
            r = analyze(d)
        except ValueError as e:
            daily.append({"day": d, "error": str(e)})
            continue
        daily.append(r)
        for row in r.get("ingredients", []):
            k = (norm_name(row["name"]), row["unit"])
            t = tot.setdefault(k, {"name": row["name"], "unit": row["unit"], "qty": 0.0})
            t["qty"] += row["average_qty"]
    rows = sorted(tot.values(), key=lambda r: r["name"].lower())
    return {"days": daily, "ingredients": rows,
            "total_combinations": sum(r.get("combination_count", 0) for r in daily)}


def _fmt_qty(q, u):
    if u == "g" and q >= 1000:
        return f"{q / 1000:.2f} kilograms"
    if u == "ml" and q >= 1000:
        return f"{q / 1000:.2f} litres"
    q = round(q, 2)
    q = int(q) if q == int(q) else q
    unit = {"g": "grams", "ml": "millilitres", "pcs": "pieces", "cup": "cups"}.get(u, u)
    if q == 1 and unit.endswith("s"):
        unit = unit[:-1]
    return f"{q} {unit}"


def report(day=None, limit=12):
    try:
        r = analyze(day)
    except ValueError as e:
        return str(e)
    if not r.get("ingredients"):
        return r.get("message", "No meal combinations recorded.")
    head = (f"For {FULL.get(r['day'], r['day'])} I averaged all {r['combination_count']:,} possible "
            f"meal combination{'s' if r['combination_count'] != 1 else ''}. You will need about: ")
    items = [f"{e['name']}, {_fmt_qty(e['average_qty'], e['unit'])}" for e in r["ingredients"][:limit]]
    more = len(r["ingredients"]) - limit
    tail = f" And {more} more items on screen." if more > 0 else ""
    return head + "; ".join(items) + "." + tail


def week_report(limit=14):
    w = week_totals()
    if not w["ingredients"]:
        return "No meals are planned for this week yet. Tick some foods in the Plans tab first."
    items = [f"{e['name']}, {_fmt_qty(e['qty'], e['unit'])}" for e in w["ingredients"][:limit]]
    more = len(w["ingredients"]) - limit
    tail = f" And {more} more items on screen." if more > 0 else ""
    return "For the week you will need about: " + "; ".join(items) + "." + tail


def handle(command):
    """Answer quantity questions ("how much rice do I need this week?"), else None."""
    q = (command or "").strip()
    l = q.lower().strip(" .?!")
    if not l:
        return None
    # "monthly plan groceries 30000" etc. are money entries for the finance engine, not questions.
    if re.match(r"^(?:add\s+|record\s+|log\s+)?(?:income|expenses?|spending|monthly plan|plan item|budget|goals?|savings?|saving goal|savings goal)\b", l):
        return None
    food_words = r"\b(?:food|foods|meal|meals|ingredient|ingredients|grocery|groceries|shopping list)\b"
    if not re.search(food_words, l):
        return None
    # Cost questions are intentionally not answered: the user records grocery cost themselves.
    if re.search(r"\b(?:cost|price|prices|expensive|cheap|cheapest|how much money)\b", l):
        return ("I don't estimate grocery cost. You enter that in your monthly plan, "
                "and I work out how much of each ingredient you need.")
    day_m = re.search(r"\b(mon|tue|wed|thu|fri|sat|sun)(?:day|sday|nesday|rsday|urday)?\b", l)
    if not re.search(r"\b(?:how much|how many|quantity|quantities|amount|amounts|average|need|needed|ingredients?|groceries|grocery|shopping list)\b", l):
        return None
    if re.search(r"\b(?:week|weekly)\b", l):
        return week_report()
    if day_m:
        return report(day_m.group(1).title()[:3])
    if re.search(r"\b(?:groceries|grocery|shopping list)\b", l):
        return week_report()
    return report()


def context():
    try:
        r = analyze()
    except Exception:
        return ""
    if not r.get("ingredients"):
        return ""
    return ("FRIDAY MEAL PLAN QUANTITIES (no costs are estimated; the user records grocery cost): "
            f"day={r['day']}; combinations={r['combination_count']}; ingredients={r['ingredients'][:12]}")
