"""FRIDAY 7.0 evidence-based research engine (roadmap #14).

    investigate(question)   search several sources, open the ORIGINAL documents the secondary sources point to, grade every source,
                            read its publication date, extract claims verbatim, cross-check them across independent sites,
                            and say plainly what is corroborated, what rests on one source, what conflicts and what could not be checked.

Nothing is "true because a search returned it".  Claims are copied from the source text (never paraphrased into new facts), every claim keeps its
source number, and the confidence statement is derived from counts (independent domains, source grades, freshness, conflicts) - not asserted.
The network step is replaceable (`set_gatherer`) so the engine is testable offline.
"""
from __future__ import annotations

import re
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import friday_common6 as C
import friday_common7 as K

C.register_schema("""
CREATE TABLE IF NOT EXISTS investigations7(id INTEGER PRIMARY KEY, ts REAL, question TEXT, sources TEXT, claims TEXT, clusters TEXT, confidence TEXT, summary TEXT);
""")

MAX_SOURCES = 6
MAX_ORIGINALS = 3
ORIGINAL_BUDGET_S = 14.0
_STOP = set("the a an of to in on for and or is are was were be been it its this that with as by at from has have had not but which who what when where how why about into over than then there their they them his her you your".split())
_PRIMARY_GRADES = ("primary", "official", "academic")

_gatherer: Optional[Callable[[str], List[Tuple[str, str]]]] = None
_original_fetcher: Optional[Callable[[str], str]] = None
_link_finder: Optional[Callable[[str, set], List[str]]] = None


def set_gatherer(fn: Optional[Callable[[str], List[Tuple[str, str]]]]):
    global _gatherer
    _gatherer = fn


def set_original_fetcher(fn: Optional[Callable[[str], str]]):
    global _original_fetcher
    _original_fetcher = fn


def set_link_finder(fn: Optional[Callable[[str, set], List[str]]]):
    global _link_finder
    _link_finder = fn


# ------------------------------------------------------------------ helpers
def _domain(url: str) -> str:
    host = (urlparse(url).netloc or url).lower().replace("www.", "")
    parts = host.split(".")
    if len(parts) >= 3 and parts[-2] in ("co", "com", "gov", "ac", "org", "edu") and len(parts[-1]) == 2:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def _content_tokens(text: str) -> List[str]:
    return [t for t in re.findall(r"[a-z0-9]+", (text or "").lower()) if t not in _STOP and len(t) > 2]


def _sentences(text: str) -> List[str]:
    text = re.sub(r"\s+", " ", text or "")
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(])", text) if 35 <= len(s.strip()) <= 320]


def _numbers(s: str) -> List[float]:
    out = []
    for m in re.finditer(r"(?<![\w.])(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)(?:\s*(%|percent|million|billion|thousand|k|m|bn))?", s):
        try:
            v = float(m.group(1).replace(",", ""))
            mult = {"million": 1e6, "m": 1e6, "billion": 1e9, "bn": 1e9, "thousand": 1e3, "k": 1e3}.get((m.group(2) or "").lower(), 1)
            out.append(v * mult)
        except ValueError:
            pass
    return out


def _is_year(v: float) -> bool:
    return 1900 <= v <= 2100 and float(v).is_integer()


def _age_days(pub: str) -> Optional[int]:
    m = re.search(r"(\d{4})(?:-(\d{1,2}))?(?:-(\d{1,2}))?", pub or "")
    if not m:
        return None
    try:
        y, mo, d = int(m.group(1)), int(m.group(2) or 6), int(m.group(3) or 15)
        t = time.mktime((y, max(1, min(12, mo)), max(1, min(28, d)), 12, 0, 0, 0, 0, -1))
        return max(0, int((time.time() - t) / 86400))
    except Exception:
        return None


def _grade(url: str, text: str) -> Dict:
    try:
        import friday_research6 as RES
        g = RES.grade_source(url, text)
        pub = RES.find_pub_date(text)
        return {"grade": g["grade"], "score": g["score"], "pub": pub}
    except Exception:
        return {"grade": "unknown", "score": 0.4, "pub": ""}


# ------------------------------------------------------------------ gathering
def _default_gather(question: str) -> List[Tuple[str, str]]:
    import friday_web_research as W
    return list(W.gather_sources(question, depth=MAX_SOURCES, search_pool=8) or [])


def _fetch_html(url: str, timeout: float = 6.0) -> str:
    import requests
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140 Safari/537.36"})
    r.raise_for_status()
    return r.text if "html" in r.headers.get("Content-Type", "").lower() else ""


def _fetch_document(url: str) -> str:
    """Text of an original document (HTML page or PDF). '' when it can't be read."""
    if _original_fetcher is not None:
        return _original_fetcher(url) or ""
    try:
        import requests
        r = requests.get(url, timeout=8, headers={"User-Agent": "Mozilla/5.0 FRIDAY"})
        r.raise_for_status()
        ct = r.headers.get("Content-Type", "").lower()
        if "pdf" in ct or url.lower().split("?")[0].endswith(".pdf"):
            import io
            from pypdf import PdfReader
            rd = PdfReader(io.BytesIO(r.content[:6_000_000]))
            return re.sub(r"\s+", " ", " ".join((p.extract_text() or "") for p in rd.pages[:12]))[:20000]
        if "html" in ct:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(r.text, "html.parser")
            for t in soup(["script", "style", "noscript", "nav", "footer", "header", "form"]):
                t.decompose()
            return re.sub(r"\s+", " ", soup.get_text(" ", strip=True))[:20000]
    except Exception:
        return ""
    return ""


def _original_links(url: str, question_tokens: set) -> List[str]:
    """Links on a secondary source that lead to original documents (PDF, government, university, DOI, arXiv ...)."""
    if _link_finder is not None:
        return list(_link_finder(url, question_tokens) or [])
    try:
        html = _fetch_html(url)
        if not html:
            return []
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, "html.parser")
    except Exception:
        return []
    own = _domain(url)
    out: List[Tuple[int, str]] = []
    for a in soup.find_all("a", href=True):
        href = urljoin(url, a["href"])
        if not href.startswith("http") or _domain(href) == own:
            continue
        low = href.lower()
        host = urlparse(href).netloc.lower()
        pri = 0
        if low.split("?")[0].endswith(".pdf"):
            pri += 2
        if re.search(r"\.(gov|edu|ac\.[a-z]{2})(?:\.|/|$)|\b(doi\.org|arxiv\.org|nih\.gov|who\.int|worldbank\.org|un\.org|oecd\.org|imf\.org)\b", host):
            pri += 3
        if pri == 0:
            continue
        anchor = set(_content_tokens(a.get_text(" ", strip=True) + " " + href))
        pri += min(3, len(anchor & question_tokens))
        out.append((pri, href))
    out.sort(key=lambda x: -x[0])
    seen, links = set(), []
    for _, h in out:
        if h not in seen:
            seen.add(h)
            links.append(h)
    return links[:2]


# ------------------------------------------------------------------ claims and cross-checking
def extract_claims(text: str, question: str, k: int = 3) -> List[str]:
    qt = set(_content_tokens(question))
    scored = []
    for s in _sentences(text):
        st = set(_content_tokens(s))
        overlap = len(st & qt)
        if overlap < max(1, min(2, len(qt))):
            continue
        has_fact = bool(re.search(r"\d", s)) or bool(re.search(r"\b(?:is|are|was|were|has|have|will|can|costs?|increased|decreased|according|found|reported|shows?)\b", s, re.I))
        if not has_fact:
            continue
        score = overlap / (len(qt) or 1) + (0.25 if re.search(r"\d", s) else 0) + (0.1 if re.search(r"\baccording to\b|\bsays?\b|\breport", s, re.I) else 0)
        scored.append((score, s))
    scored.sort(key=lambda x: -x[0])
    out, seen = [], []
    for _, s in scored:
        if any(C.similarity(s, o) > 0.7 for o in seen):
            continue
        out.append(s)
        seen.append(s)
        if len(out) >= k:
            break
    return out


def _conflict(a: str, b: str) -> Optional[str]:
    na = [v for v in _numbers(a) if not _is_year(v)]
    nb = [v for v in _numbers(b) if not _is_year(v)]
    for x in na:
        for y in nb:
            hi, lo = max(x, y), min(x, y)
            if hi > 0 and 0.05 < (hi - lo) / hi and lo / hi > 0.2:      # different, but plausibly the same quantity
                return f"{x:g} versus {y:g}"
    neg = lambda s: bool(re.search(r"\b(?:not|no|never|false|denied|refuted|fails?|cannot)\b", s, re.I))
    if neg(a) != neg(b) and C.similarity(a, b) > 0.6:
        return "one source denies what the other states"
    return None


def cross_check(claims: List[Dict]) -> List[Dict]:
    """Cluster claims that talk about the same thing, then judge each cluster."""
    clusters: List[List[Dict]] = []
    for c in claims:
        for cl in clusters:
            if any(C.similarity(c["text"], o["text"]) >= 0.38 for o in cl):
                cl.append(c)
                break
        else:
            clusters.append([c])
    out = []
    for cl in clusters:
        doms = {c["domain"] for c in cl}
        best = max(cl, key=lambda c: c["score"])
        conflicts = []
        for i in range(len(cl)):
            for j in range(i + 1, len(cl)):
                if cl[i]["domain"] != cl[j]["domain"]:
                    d = _conflict(cl[i]["text"], cl[j]["text"])
                    if d:
                        conflicts.append({"a": cl[i]["src"], "b": cl[j]["src"], "detail": d})
        grades = {c["grade"] for c in cl}
        if conflicts:
            status = "conflicting"
        elif len(doms) >= 2 and (grades & set(_PRIMARY_GRADES) or len(doms) >= 3 or {"news"} & grades):
            status = "corroborated"
        elif len(doms) >= 2:
            status = "weakly corroborated"
        else:
            status = "single source"
        out.append({"status": status, "text": best["text"], "sources": sorted({c["src"] for c in cl}), "domains": sorted(doms), "conflicts": conflicts, "best_grade": best["grade"], "best_src": best["src"]})
    rank = {"corroborated": 0, "weakly corroborated": 1, "conflicting": 2, "single source": 3}
    out.sort(key=lambda c: (rank[c["status"]], -len(c["sources"])))
    return out


def confidence(sources: List[Dict], clusters: List[Dict]) -> Dict:
    n = len(sources)
    prim = sum(1 for s in sources if s["grade"] in _PRIMARY_GRADES)
    doms = len({s["domain"] for s in sources})
    corr = sum(1 for c in clusters if c["status"] == "corroborated")
    conf = sum(1 for c in clusters if c["status"] == "conflicting")
    ages = [s["age_days"] for s in sources if s["age_days"] is not None]
    stale = sum(1 for a in ages if a > 730)
    points = 0
    points += 2 if prim >= 1 else 0
    points += 1 if doms >= 3 else 0
    points += 1 if corr >= 1 else 0
    points -= 1 if conf else 0
    points -= 1 if n < 2 else 0
    points -= 1 if ages and stale == len(ages) else 0
    level = "high" if points >= 4 else "moderate" if points >= 2 else "low"
    why = [f"{n} source(s) from {doms} independent site(s)", f"{prim} primary/official/academic" if prim else "no primary, official or academic source found"]
    if corr:
        why.append(f"{corr} point(s) confirmed by independent sites")
    if conf:
        why.append(f"{conf} point(s) where sources disagree")
    if not ages:
        why.append("no publication dates could be read")
    elif stale:
        why.append(f"{stale} source(s) older than two years")
    return {"level": level, "points": points, "why": why}


# ------------------------------------------------------------------ the engine
def investigate(question: str, depth: int = MAX_SOURCES) -> Dict:
    t0 = time.time()
    q = re.sub(r"\s+", " ", question or "").strip()
    if not q:
        return {"ok": False, "output": "", "error": "no question given"}
    try:
        raw = (_gatherer or _default_gather)(q)
    except Exception as exc:
        raw = []
        err = f"{type(exc).__name__}: {exc}"[:120]
    else:
        err = ""
    sources: List[Dict] = []
    seen = set()
    for url, text in raw:
        if url in seen or not text:
            continue
        seen.add(url)
        g = _grade(url, text)
        sources.append({"n": len(sources) + 1, "url": url, "domain": _domain(url), "grade": g["grade"], "score": g["score"], "pub": g["pub"], "age_days": _age_days(g["pub"]), "text": text[:20000], "original": False})
        if len(sources) >= depth:
            break
    if not sources:
        return {"ok": False, "output": "", "error": "I couldn't retrieve any readable sources" + (f" ({err})" if err else ", so I can't say anything evidence-based about that"), "sources": []}

    # original documents behind the secondary sources (bounded in time and number)
    qt = set(_content_tokens(q))
    originals: List[Dict] = []
    for s in [s for s in sources if s["grade"] not in _PRIMARY_GRADES][:4]:
        if len(originals) >= MAX_ORIGINALS or time.time() - t0 > ORIGINAL_BUDGET_S:
            break
        for link in _original_links(s["url"], qt)[:1]:
            if link in seen:
                continue
            txt = _fetch_document(link)
            if len(txt) < 300:
                continue
            seen.add(link)
            g = _grade(link, txt)
            originals.append({"n": len(sources) + len(originals) + 1, "url": link, "domain": _domain(link), "grade": g["grade"] if g["grade"] != "unknown" else "primary", "score": max(g["score"], 0.7), "pub": g["pub"],
                              "age_days": _age_days(g["pub"]), "text": txt, "original": True, "linked_from": s["n"]})
            break
    sources.extend(originals)

    claims: List[Dict] = []
    for s in sources:
        for t in extract_claims(s["text"], q, 3):
            claims.append({"text": t, "src": s["n"], "domain": s["domain"], "grade": s["grade"], "score": s["score"], "pub": s["pub"]})
    clusters = cross_check(claims)
    conf = confidence(sources, clusters)
    unverified = [c for c in clusters if c["status"] == "single source"]
    out = [f"Evidence for: {q}", f"Confidence: {conf['level']} ({'; '.join(conf['why'])})."]
    shown = 0
    for c in clusters[:7]:
        cites = "".join(f"[{n}]" for n in c["sources"])
        tag = {"corroborated": "CONFIRMED by independent sources", "weakly corroborated": "seen on more than one site, none authoritative", "conflicting": "SOURCES DISAGREE", "single source": "one source only - unverified"}[c["status"]]
        out.append(f"- {c['text']} {cites} ({tag})")
        for cf in c["conflicts"][:1]:
            out.append(f"    Disagreement: sources [{cf['a']}] and [{cf['b']}] differ - {cf['detail']}.")
            out.append(f"    The statement shown comes from the highest-graded source, [{c['best_src']}] ({c['best_grade']}); treat the other figure with caution until it is confirmed.")
        shown += 1
    if not clusters:
        out.append("- The sources I could read contained no statements that clearly answer the question.")
    if unverified and len(unverified) == len(clusters):
        out.append("None of these points was confirmed by a second independent site.")
    out.append("Sources:")
    for s in sources:
        date = s["pub"] or "date not found"
        age = f", {s['age_days']} days old" if s["age_days"] is not None else ""
        tag = " (original document" + (f" linked from [{s['linked_from']}]" if s.get("linked_from") else "") + ")" if s["original"] else ""
        out.append(f"[{s['n']}] {s['url']} - {s['grade']}, {date}{age}{tag}")
    limits = []
    if not any(s["grade"] in _PRIMARY_GRADES for s in sources):
        limits.append("I found no primary, official or academic source")
    if not originals:
        limits.append("I could not open an original document behind the articles")
    if any(s["age_days"] is None for s in sources):
        limits.append("some pages show no readable publication date")
    if limits:
        out.append("What I could not verify: " + "; ".join(limits) + ".")
    text_out = "\n".join(out)

    pub_sources = [{k: v for k, v in s.items() if k != "text"} for s in sources]
    iid = C.x("INSERT INTO investigations7(ts,question,sources,claims,clusters,confidence,summary) VALUES(?,?,?,?,?,?,?)",
              (C.now(), q, K.jd(pub_sources), K.jd(claims), K.jd(clusters), K.jd(conf), text_out[:3000]))
    try:                                            # keep the 6.0 research notebook in step
        import friday_research6 as RES
        for s in sources[:8]:
            RES.add_source(q, s["url"], text=s["text"][:3000])
        for c in clusters[:6]:
            RES.add_claim(q, c["text"], next((s["url"] for s in sources if s["n"] == c["sources"][0]), ""))
    except Exception:
        pass
    K.emit("investigation.done", {"id": iid, "question": q, "confidence": conf["level"]})
    return {"ok": True, "output": text_out, "id": iid, "sources": pub_sources, "clusters": clusters, "claims": claims, "confidence": conf, "originals": len(originals),
            "verified": True, "evidence": f"{len(sources)} sources graded, {len(clusters)} point(s) cross-checked"}


def get(iid: int) -> Optional[Dict]:
    r = C.q("SELECT * FROM investigations7 WHERE id=?", (iid,))
    if not r:
        return None
    d = dict(r[0])
    for k in ("sources", "claims", "clusters", "confidence"):
        d[k] = K.jl(d[k], [] if k != "confidence" else {})
    return d


def latest(question: str = "", max_age_s: float = 6 * 3600) -> Optional[Dict]:
    rows = C.q("SELECT * FROM investigations7 WHERE ts>? ORDER BY id DESC LIMIT 20", (C.now() - max_age_s,))
    best, bs = None, 0.0
    for r in rows:
        s = C.similarity(question, r["question"]) if question else 1.0
        if s > bs:
            best, bs = r, s
    if best is None or (question and bs < 0.3):
        return None
    return get(best["id"])


def tool_investigate(a: Dict) -> Dict:
    r = investigate(str(a.get("question") or a.get("query") or a.get("goal") or ""))
    return {"ok": r["ok"], "output": r.get("output", ""), "error": r.get("error", ""), "id": r.get("id"), "confidence": (r.get("confidence") or {}).get("level"), "verified": r.get("verified"), "evidence": r.get("evidence", "")}


def install(registry):
    registry.register("investigate", tool_investigate, risk="safe", desc="multi-source research with graded sources, original documents, cross-checking and stated uncertainty", post={"nonempty": True},
                      timeout=120.0, agent="research", permission="web_research")


# ------------------------------------------------------------------ chat
def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    m = re.match(r"^(?:investigate|fact[- ]check|verify the claim|check the evidence (?:for|on|about)|find (?:the )?evidence (?:for|on|about))\s+(.+)$", t)
    if m:
        raw = re.sub(r"^(?:investigate|fact[- ]check|verify the claim|check the evidence (?:for|on|about)|find (?:the )?evidence (?:for|on|about))\s+", "", K.strip_wake(command).strip(), flags=re.I)
        try:
            import friday_orchestrator7 as O
            jid = O.submit("investigate: " + raw, plan={"steps": [{"id": 0, "desc": "Investigate with graded, cross-checked sources", "tool": "investigate", "args": {"question": raw}, "depends": [],
                                                                  "post": {"nonempty": True}, "expect": {"min_len": 40}, "optional": False, "alternatives": [{"tool": "web_research", "args": {"query": raw}, "desc": "Plain web research"}],
                                                                  "risk": "safe", "status": "pending", "attempts": 0}], "template": "evidence"}, intent="research")
            return "On it. I'll check several sources, open the originals where I can, and tell you what's confirmed and what isn't."
        except Exception as exc:
            return f"I couldn't start that: {exc}"
    return None


def ui_snapshot() -> Dict:
    return {"investigations": [{"id": r["id"], "question": r["question"], "when": C.iso(r["ts"]), "confidence": (K.jl(r["confidence"], {}) or {}).get("level", "")} for r in C.q("SELECT * FROM investigations7 ORDER BY id DESC LIMIT 8")]}
