import types
import friday_feature_hardening as jfh

assert jfh.quality_self_test()["overall"] is True
assert jfh.validate_plan([
    types.SimpleNamespace(name="a", dependencies=[]),
    types.SimpleNamespace(name="b", dependencies=["a"]),
])[0]
assert not jfh.validate_plan([
    types.SimpleNamespace(name="a", dependencies=["missing"]),
])[0]
assert not jfh.validate_plan([
    types.SimpleNamespace(name="a", dependencies=["b"]),
    types.SimpleNamespace(name="b", dependencies=["a"]),
])[0]
assert jfh.recently_started("unique v2026 dedup test") is False
assert jfh.recently_started("unique v2026 dedup test") is True
assert 0.0 <= jfh.source_quality("https://example.com", "Title", "snippet") <= 1.0
print("V2026 quality hardening tests: PASS")
