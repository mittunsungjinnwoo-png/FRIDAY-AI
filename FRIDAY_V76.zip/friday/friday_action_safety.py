"""
FRIDAY ACTION SAFETY  (human control for the vision agent)
==========================================================
The competition plan's "Safety + human control" slide, implemented:

    GREEN  / SAFE        runs automatically            open an app, search, read a document
    YELLOW / CONFIRM     FRIDAY asks first             "Sir, this will modify the file. Proceed?"
    RED    / RESTRICTED  blocked, or explicit confirm  delete, send, pay, shell, shutdown ...

* Every action the agent wants to take is classified from its tool name AND its text/arguments.
* What the screen currently shows can raise the level (e.g. clicking while a payment or password
  page is open is never silent).
* Questions go to the user three ways at once: spoken by FRIDAY, shown as a card in the app (with
  Approve / Deny buttons), and answerable by typing or saying yes / no (red actions need the word
  "confirm").
* Every decision is written to friday_data/vision_audit.jsonl and counted in the evaluation metrics.

Nothing in this file touches the microphone, recognition or speech code.
"""
from __future__ import annotations

import json
import re
import threading
import time
import uuid
from typing import Any, Callable, Optional

import friday_vision_config as cfg

SAFE, CONFIRM, RESTRICTED = "safe", "confirm", "restricted"
COLOR = {SAFE: "green", CONFIRM: "yellow", RESTRICTED: "red"}
_ORDER = {SAFE: 0, CONFIRM: 1, RESTRICTED: 2}

SAFE_TOOLS = {"open_app", "open_file", "find_file", "find_and_open_file", "open_url", "web_search", "observe", "read_screen", "wait", "scroll",
              "focus_window", "start_menu_open", "take_screenshot", "move_mouse", "look_camera", "analyze_image", "find_text", "friday_tool_readonly"}
CONFIRM_TOOLS = {"click_text", "click_xy", "type_text", "press_key", "hotkey", "close_app", "computer_use", "write_file", "rename_file",
                 "move_file", "copy_file", "create_file", "download", "drag", "friday_tool"}
RESTRICTED_TOOLS = {"delete_file", "run_command", "shell", "send_message", "send_email", "post_content", "purchase", "pay", "uninstall",
                    "shutdown", "restart", "format_drive", "edit_registry", "kill_process", "change_password", "install_software"}

_RED_PATTERNS = [
    r"\bdelet(?:e|ing)\b", r"\bremov(?:e|ing)\b", r"\berase\b", r"\bformat\b", r"\buninstall\b", r"\bshut ?down\b", r"\brestart\b",
    r"\breboot\b", r"\bpurchase\b", r"\bbuy\b", r"\bpay(?:ment)?\b", r"\bcheck ?out\b", r"\btransfer (?:money|funds)\b", r"\bwire\b",
    r"\bsend (?:a |the )?(?:message|email|e-mail|text|whatsapp|dm)\b", r"\bpublish\b", r"\bpost (?:it|this|online)\b", r"\bpassword\b",
    r"\bcredit card\b", r"\bcvv\b", r"\bfactory reset\b", r"\bempty (?:the )?recycle\b", r"rm -rf", r"\bdel /", r"\bregistry\b",
    r"\bpowershell\b", r"\bcmd\.exe\b", r"\bsudo\b", r"\bpermanently\b", r"\bsign out of all\b", r"\bdisable (?:antivirus|firewall|defender)\b",
]
_YELLOW_PATTERNS = [
    r"\bmodif(?:y|ies)\b", r"\boverwrit(?:e|ing)\b", r"\bsave\b", r"\bedit\b", r"\brename\b", r"\bmove\b", r"\binstall\b", r"\bdownload\b",
    r"\btype\b", r"\benter\b", r"\bclick\b", r"\bsubmit\b", r"\bclose\b", r"\bwrite\b", r"\bcreate\b", r"\bpaste\b", r"\bdrag\b",
]
_SENSITIVE_SCREEN = re.compile(r"(are you sure|permanently|password|card number|cvv|payment|checkout|confirm (?:purchase|order)|delete (?:account|all)|"
                               r"sign in|log ?in|bank|transfer)", re.I)

_LOCK = threading.RLock()
_PENDING: dict[str, dict[str, Any]] = {}
_EMIT: Optional[Callable[[str, dict], None]] = None
_SPEAK: Optional[Callable[[str], None]] = None
_AUDIT = cfg.DATA_DIR / "vision_audit.jsonl"


def set_hooks(emit: Optional[Callable[[str, dict], None]] = None, speak: Optional[Callable[[str], None]] = None) -> None:
    global _EMIT, _SPEAK
    if emit is not None:
        _EMIT = emit
    if speak is not None:
        _SPEAK = speak


def _emit(kind: str, payload: dict) -> None:
    try:
        if _EMIT:
            _EMIT(kind, payload)
    except Exception:
        pass


def _bump(level: str, to: str) -> str:
    return to if _ORDER[to] > _ORDER[level] else level


def classify(action: dict[str, Any], screen_text: str = "") -> dict[str, Any]:
    """action = {"tool": str, "args": {...}, "text": "human description"} -> {"level","color","reason"}."""
    tool = str(action.get("tool", "")).strip().lower()
    args = action.get("args") or {}
    blob = " ".join([str(action.get("text", "")), " ".join(str(v) for v in args.values() if isinstance(v, (str, int, float)))]).lower()
    if tool in RESTRICTED_TOOLS:
        level, why = RESTRICTED, f"'{tool}' is a restricted kind of action"
    elif tool in SAFE_TOOLS:
        level, why = SAFE, f"'{tool}' only opens or reads things"
    elif tool in CONFIRM_TOOLS:
        level, why = CONFIRM, f"'{tool}' changes something on the computer"
    else:
        level, why = CONFIRM, "unknown action type, so FRIDAY asks first"
    for pat in _RED_PATTERNS:
        m = re.search(pat, blob)
        if m and tool not in ("open_app", "web_search", "open_url", "wait", "observe", "read_screen"):
            level, why = RESTRICTED, f"the request mentions '{m.group(0).strip()}'"
            break
    if level == SAFE:
        for pat in _YELLOW_PATTERNS:
            m = re.search(pat, blob)
            if m and tool not in ("open_app", "web_search", "open_url", "wait", "observe", "read_screen", "open_file", "find_file", "find_and_open_file", "scroll"):
                level, why = CONFIRM, f"the request mentions '{m.group(0).strip()}'"
                break
    if tool in {"click_text", "click_xy", "type_text", "press_key", "hotkey", "drag"} and screen_text and _SENSITIVE_SCREEN.search(screen_text):
        m = _SENSITIVE_SCREEN.search(screen_text)
        if _ORDER[level] < _ORDER[CONFIRM]:
            level, why = CONFIRM, f"the screen shows '{m.group(0)}'"
        elif level == CONFIRM and re.search(r"(delete|permanently|payment|card number|cvv|checkout|transfer)", m.group(0), re.I):
            level, why = RESTRICTED, f"the screen shows '{m.group(0)}', which makes this high-risk"
    return {"level": level, "color": COLOR[level], "reason": why, "tool": tool}


def _audit(entry: dict, quiet: bool = False) -> None:
    if quiet:
        return
    try:
        cfg.DATA_DIR.mkdir(parents=True, exist_ok=True)
        if _AUDIT.exists() and _AUDIT.stat().st_size > 1_000_000:
            _AUDIT.replace(_AUDIT.with_suffix(".old"))
        with open(_AUDIT, "a", encoding="utf-8") as f:
            f.write(json.dumps({"ts": time.strftime("%Y-%m-%d %H:%M:%S"), **entry}, ensure_ascii=False) + "\n")
    except Exception:
        pass
    try:
        import friday_eval_metrics as em
        em.record_safety(entry.get("level", ""), entry.get("decision", ""))
    except Exception:
        pass


def audit_tail(n: int = 30) -> list[dict]:
    try:
        lines = _AUDIT.read_text(encoding="utf-8").splitlines()[-n:]
        return [json.loads(x) for x in lines]
    except Exception:
        return []


# ---------------------------------------------------------------------------
# confirmation broker
# ---------------------------------------------------------------------------
def pending() -> list[dict]:
    with _LOCK:
        return [{k: v for k, v in p.items() if k != "event"} for p in _PENDING.values() if p["approved"] is None]


def ask(prompt: str, level: str, action: dict, timeout: Optional[float] = None) -> tuple[bool, str]:
    """Block until the user answers. Returns (approved, how) with how in approved|denied|timeout|stopped."""
    rid = uuid.uuid4().hex[:8]
    typed = level == RESTRICTED
    rec = {"id": rid, "level": level, "color": COLOR[level], "prompt": prompt, "action": action, "typed_required": typed,
           "event": threading.Event(), "approved": None, "how": "", "ts": time.time()}
    with _LOCK:
        _PENDING[rid] = rec
    _emit("confirm", {k: v for k, v in rec.items() if k != "event"})
    spoken = prompt + (" This is a restricted action. Say or type 'confirm' to proceed, or 'cancel'." if typed else " Say yes or no.")
    try:
        if _SPEAK:
            _SPEAK(spoken)
    except Exception:
        pass
    wait = float(timeout if timeout is not None else cfg.get("safety_confirm_timeout"))
    rec["event"].wait(wait)
    with _LOCK:
        if rec["approved"] is None:
            rec["approved"], rec["how"] = False, "timeout"
        _PENDING.pop(rid, None)
    _emit("confirm_done", {"id": rid, "approved": rec["approved"], "how": rec["how"]})
    return bool(rec["approved"]), rec["how"]


def resolve(approve: bool, rid: Optional[str] = None, typed_text: str = "", source: str = "ui") -> dict[str, Any]:
    with _LOCK:
        rec = _PENDING.get(rid) if rid else None
        if rec is None and not rid:
            live = [p for p in _PENDING.values() if p["approved"] is None]
            rec = live[-1] if live else None
        if rec is None or rec["approved"] is not None:
            return {"ok": False, "error": "nothing is waiting for an answer"}
        if approve and rec["typed_required"] and cfg.get("safety_restricted_policy") == "typed_confirm" and "confirm" not in (typed_text or "").lower():
            return {"ok": False, "need_typed": True, "error": "This is a restricted action. Type or say 'confirm' to proceed."}
        rec["approved"] = bool(approve)
        rec["how"] = "approved" if approve else "denied"
        rec["event"].set()
        return {"ok": True, "id": rec["id"], "approved": bool(approve), "source": source}


_YES = re.compile(r"^\s*(?:yes|yeah|yep|yup|sure|ok(?:ay)?|proceed|go ahead|do it|approved?|confirm(?:ed)?|please do|affirmative|continue)\b", re.I)
_NO = re.compile(r"^\s*(?:no|nope|nah|cancel|stop|don'?t|do not|abort|deny|denied|negative|never ?mind|halt)\b", re.I)


def resolve_from_text(text: str) -> Optional[str]:
    """Called for every spoken/typed command while something is pending.
    Returns None if the text is not an answer (so normal processing continues), else a short reply to speak ('' = say nothing)."""
    live = pending()
    if not live:
        return None
    t = (text or "").strip()
    if _NO.match(t):
        resolve(False, live[-1]["id"], t, "voice")
        return "Understood. I have cancelled that."
    if _YES.match(t):
        r = resolve(True, live[-1]["id"], t, "voice")
        if r.get("need_typed"):
            return "That action is restricted. Please say or type the word confirm to proceed, or say cancel."
        return ""
    return None


def decide(action: dict[str, Any], *, screen_text: str = "", describe: Optional[str] = None,
           asker: Optional[Callable[[str, str, dict], tuple[bool, str]]] = None, simulate: bool = False,
           restricted_policy: Optional[str] = None) -> dict[str, Any]:
    """The one call the agent makes before every action. Returns {allowed, level, color, reason, how}.
    `asker` and `simulate` exist for the benchmark suite (no real prompts, nothing written to the audit log / live metrics)."""
    c = classify(action, screen_text)
    level, reason = c["level"], c["reason"]
    text = describe or action.get("text") or f"{action.get('tool')} {json.dumps(action.get('args') or {})}"
    entry = {"action": text[:300], "tool": c["tool"], "level": level, "reason": reason}
    ask_fn = asker or ask
    policy = restricted_policy or cfg.get("safety_restricted_policy")
    if level == SAFE:
        _audit({**entry, "decision": "auto_allowed"}, simulate)
        return {"allowed": True, **c, "how": "auto"}
    if level == CONFIRM:
        if not cfg.get("safety_confirm_yellow") and not simulate:
            _audit({**entry, "decision": "auto_allowed_by_setting"})
            return {"allowed": True, **c, "how": "setting"}
        ok, how = ask_fn(f"This will {text.rstrip('.')}. Proceed?", level, action)
        _audit({**entry, "decision": "approved" if ok else ("timeout" if how == "timeout" else "denied")}, simulate)
        return {"allowed": ok, **c, "how": how}
    # RESTRICTED
    if policy != "typed_confirm":
        _audit({**entry, "decision": "blocked"}, simulate)
        if not simulate:
            _emit("blocked", {"action": text, "reason": reason})
        return {"allowed": False, **c, "how": "blocked",
                "message": f"I won't do that on my own: {reason}. You can allow restricted actions with confirmation in Settings > Vision."}
    ok, how = ask_fn(f"Warning: this will {text.rstrip('.')}. {reason.capitalize()}. Do you really want me to proceed?", level, action)
    _audit({**entry, "decision": "approved_typed" if ok else ("timeout" if how == "timeout" else "denied")}, simulate)
    return {"allowed": ok, **c, "how": how}
