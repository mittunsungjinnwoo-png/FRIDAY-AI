"""FRIDAY V2032 peak architecture audit. Static/read-only; no microphone or apps."""
from pathlib import Path
import ast, re
ROOT=Path(__file__).resolve().parent
required=[
 "friday_backend.py","friday_voice_engine.py","friday_peak_engine.py",
 "friday_advanced_agent.py","friday_agent_core.py","friday_context.py",
 "friday_screen_intelligence.py","friday_desktop_agent.py","friday_gemini_computer_use.py",
 "friday_web_research.py","friday_youtube_research.py","friday_creation_engine.py",
 "friday_notes_engine.py","friday_zoom_notes.py","friday_system_control.py",
 "friday_omni_engine.py","friday_v96_runtime.py","friday_feature_hardening.py",
 "friday_quality.py","friday_reliability.py","friday_persona.py",
]
missing=[x for x in required if not (ROOT/x).is_file()]
assert not missing, missing
for path in ROOT.glob("*.py"):
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
backend=(ROOT/"friday_backend.py").read_text(encoding="utf-8")
voice=(ROOT/"friday_voice_engine.py").read_text(encoding="utf-8")
peak=(ROOT/"friday_peak_engine.py").read_text(encoding="utf-8")
assert "_recognize_hybrid" in backend
assert "fast_lane_eligible" in backend
assert "FRIDAY_LOCAL_ASR_TIMEOUT" in backend
assert "Faster-Whisper" in voice or "faster_whisper" in voice
assert "def health_snapshot" in peak
assert "def begin_turn" in peak
print("FRIDAY V2032 peak all-features architecture audit: PASS")
print(f"  required feature modules: {len(required)}")
print(f"  python files parsed: {len(list(ROOT.glob('*.py')))}")
print("  Google-first low-latency hybrid ASR: PASS")
print("  exact-command fast lane: PASS")
print("  existing feature modules retained: PASS")
