# FRIDAY V7.4 - widget commands in the conversation, faster replies, ring glitch fixed

Built on V7.3. Voice, listening, wake word, vision, finance/food and every other feature are untouched.

## 1. Video problem (friday_small_error.mp4)
The spinning ring around the brain icon in "Current Mode & Quick Info" reused the small loading-spinner CSS rule `.sp`
(1 s spin, rotating about the top-left corner), so its arcs swung across the icon. Now it turns slowly about its own centre.
Same block also can no longer clip its text / mode button / quick buttons in a narrow window (friday_hud.css, end of file).

## 2. Widget commands appear in the conversation
Anything typed or tapped in the widget panel is now written into the main window's conversation as your message (main.js + index.html),
and her reply already appeared there. Voice commands (Heard) and typed ones in the main window behave as before.

## 3. Replies in about 1-2 seconds (friday_backend.py)
- Her words reach the conversation 0.35 s after the reply is ready (or at first sound) instead of waiting for the voice service
  (was up to 8 s when the voice was slow). `FRIDAY_TEXT_LEAD_SECONDS`.
- The slower "smart" model is used only for long (40+ word) questions or deep reasoning; ordinary why/how/explain questions use the fast model. `FRIDAY_SMART_FOR_HARD=1` restores the old behaviour.
- Intent check time-box 1.6 -> 0.9 s, action router 3.0 -> 1.6 s.
- First spoken piece is released earlier (20 characters / a word boundary at ~44 characters, not only at a comma or full stop).
- A missing optional zoom-notes module no longer costs a failed import on every command.

Measured with a simulated 0.5 s Gemini call and a 2 s slow voice service: words in the chat at ~1.1 s. Real timings depend on Gemini and your network;
check the FRIDAY_LATENCY:: lines.
