"""FRIDAY 7.0 runtime: speculative work, resource governance, conversation state and recovery (roadmap #18, #20, #21).

Everything here sits BESIDE the existing voice path.  It reads the same state the voice engines already expose (listening health, speech playing /
aborted flags, the HUD core state) and never records, recognises or synthesises audio.

  Speculator          cheap, independent look-ups (intent classification, memory recall) start the moment a command arrives, in a bounded pool,
                      and only when the machine is not busy or in light mode.  Results are cached for a few seconds and used by whoever needs them next.
  ResultCache         a small TTL + LRU cache for reusable results (repeat research within minutes, repeated look-ups).
  Governor            one bounded worker pool for 7.0's background work (2 workers, 1 in light mode), idle-component unloaders (file index, caches, memory),
                      and `should_use_model(kind)` so expensive model reasoning is skipped when a deterministic answer or light mode says it isn't worth it.
  ConversationState   one consistent view - idle / listening / thinking / speaking / interrupted / recovering / degraded - derived from the engines'
                      own signals; stale HUD states are corrected; a dead listener is restarted (rate-limited) and a failing provider is reported honestly.
"""
from __future__ import annotations

import gc
import re
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict, List, Optional, Tuple

import friday_common6 as C
import friday_common7 as K

SPEC_TTL_S = 20.0
CACHE_MAX = 160
HUD_STALE_SPEAKING_S = 20.0
HUD_STALE_THINKING_S = 240.0
RESTART_MIN_GAP_S = 120.0
RESTART_MAX_PER_HOUR = 3
UNLOAD_IDLE_S = 20 * 60
UNLOAD_RAM_PCT = 82.0


def _light() -> bool:
    try:
        import friday_health7 as H
        return H.light_mode()
    except Exception:
        return False


# ------------------------------------------------------------------ cache
class ResultCache:
    def __init__(self, maxsize: int = CACHE_MAX):
        self._d: "OrderedDict[str, Tuple[float, Any]]" = OrderedDict()
        self._lock = threading.Lock()
        self.max = maxsize
        self.hits = 0
        self.misses = 0

    def get(self, key: str, ttl: float = 300.0) -> Any:
        with self._lock:
            v = self._d.get(key)
            if v is None or time.time() - v[0] > ttl:
                self.misses += 1
                if v is not None:
                    self._d.pop(key, None)
                return None
            self._d.move_to_end(key)
            self.hits += 1
            return v[1]

    def put(self, key: str, value: Any):
        with self._lock:
            self._d[key] = (time.time(), value)
            self._d.move_to_end(key)
            while len(self._d) > self.max:
                self._d.popitem(last=False)

    def cached(self, key: str, ttl: float, fn: Callable[[], Any]) -> Any:
        v = self.get(key, ttl)
        if v is not None:
            return v
        v = fn()
        if v is not None:
            self.put(key, v)
        return v

    def clear(self) -> int:
        with self._lock:
            n = len(self._d)
            self._d.clear()
            return n

    def stats(self) -> Dict:
        return {"entries": len(self._d), "hits": self.hits, "misses": self.misses}


cache = ResultCache()


# ------------------------------------------------------------------ governor
_pool_lock = threading.Lock()
_pool: Dict[str, Any] = {"ex": None, "size": 0}


def pool_size() -> int:
    return 1 if _light() else 2


def submit_background(fn: Callable, *a, **kw):
    """Run a short background job in the shared bounded pool (never more than 2 at once, 1 in light mode)."""
    with _pool_lock:
        want = pool_size()
        if _pool["ex"] is None or _pool["size"] != want:
            old = _pool["ex"]
            _pool["ex"], _pool["size"] = ThreadPoolExecutor(max_workers=want, thread_name_prefix="Friday7bg"), want
            if old is not None:
                old.shutdown(wait=False)
        return _pool["ex"].submit(fn, *a, **kw)


def should_use_model(kind: str = "reasoning") -> bool:
    """False when a model call is not worth its cost right now (light mode for optional work, or the setting says never)."""
    if kind in ("critic", "proactive", "summary", "speculation") and _light():
        return False
    if kind == "critic" and K.cfg_get("critic_budget") == "never":
        return False
    return True


_unloaders: Dict[str, Dict] = {}
_last_unload = {"ts": 0.0, "freed_mb": 0.0, "what": []}


def register_unloader(name: str, fn: Callable[[], Any], idle_s: float = UNLOAD_IDLE_S, idle_of: Optional[Callable[[], float]] = None):
    """fn() releases memory held by an idle component and may return a number (items freed). idle_of() -> seconds since last use."""
    _unloaders[name] = {"fn": fn, "idle_s": idle_s, "idle_of": idle_of}


def _rss_mb() -> Optional[float]:
    try:
        import psutil
        return psutil.Process().memory_info().rss / 1e6
    except Exception:
        return None


def unload_idle(force: bool = False) -> Dict:
    """Release idle components. Without force: only when RAM is high (or the component has been idle a long time AND light mode is on)."""
    try:
        import friday_perf6 as P
        r = P.resources()
    except Exception:
        r = {}
    ram = r.get("ram")
    pressure = force or (ram is not None and ram >= UNLOAD_RAM_PCT) or _light()
    before = _rss_mb()
    done: List[str] = []
    for name, u in list(_unloaders.items()):
        try:
            idle = u["idle_of"]() if u.get("idle_of") else float("inf")
            if not force and (not pressure or idle < u["idle_s"]):
                continue
            n = u["fn"]()
            done.append(f"{name}" + (f" ({n})" if isinstance(n, (int, float)) and n else ""))
        except Exception as exc:
            C.log(f"unloader {name} failed safely: {exc}", "recovery")
    if done:
        gc.collect()
    after = _rss_mb()
    freed = round(max(0.0, (before or 0) - (after or 0)), 1) if before and after else 0.0
    if done:
        _last_unload.update(ts=time.time(), freed_mb=freed, what=done)
        K.emit("runtime.unloaded", {"what": done, "freed_mb": freed})
    return {"released": done, "freed_mb": freed, "ram_pct": ram, "pressure": bool(pressure)}


def install_default_unloaders():
    register_unloader("result cache", lambda: cache.clear(), idle_s=0)
    register_unloader("speculation cache", _spec_clear, idle_s=0)
    try:
        import friday_filesearch7 as FS
        register_unloader("file index", FS.unload, idle_s=UNLOAD_IDLE_S, idle_of=FS.idle_seconds)
    except Exception:
        pass

    def _shrink():
        try:
            with C._lock:
                C.db().execute("PRAGMA shrink_memory")
        except Exception:
            pass
        return 0
    register_unloader("database page cache", _shrink, idle_s=0)


# ------------------------------------------------------------------ speculation
_spec: Dict[str, Dict] = {}
_spec_lock = threading.Lock()


def _spec_clear() -> int:
    with _spec_lock:
        n = len(_spec)
        _spec.clear()
        return n


def _key(command: str) -> str:
    return re.sub(r"\s+", " ", K.strip_wake(command).lower()).strip(" .!?")[:200]


def _compute(command: str, key: str):
    out: Dict[str, Any] = {"ts": time.time(), "done": False}
    t0 = time.time()
    try:
        import friday_orchestrator7 as O
        out["intent"] = O.classify_intent(command)
    except Exception:
        pass
    try:
        import friday_memory7 as M
        out["memory_block"] = M.prompt_block(command, k=3)
    except Exception:
        pass
    out["ms"] = round((time.time() - t0) * 1000, 1)
    out["done"] = True
    with _spec_lock:
        _spec[key] = out
        for k in [k for k, v in _spec.items() if time.time() - v["ts"] > SPEC_TTL_S * 3]:
            _spec.pop(k, None)


def speculate(command: str) -> bool:
    """Start the cheap look-ups for a command that just arrived. Returns True if work was started. Never blocks, never raises."""
    try:
        if not K.cfg_flag("speculate") or _light() or len((command or "").strip()) < 4:
            return False
        key = _key(command)
        with _spec_lock:
            cur = _spec.get(key)
            if cur and time.time() - cur["ts"] < SPEC_TTL_S:
                return False
            _spec[key] = {"ts": time.time(), "done": False}
        submit_background(_compute, command, key)
        return True
    except Exception:
        return False


def speculated(command: str, field: str, wait: float = 0.0) -> Any:
    """A speculative result if it is ready (waits at most `wait` seconds), else None - callers then compute it themselves."""
    key = _key(command)
    end = time.time() + max(0.0, wait)
    while True:
        with _spec_lock:
            v = _spec.get(key)
        if v and v.get("done") and time.time() - v["ts"] <= SPEC_TTL_S * 3:
            return v.get(field)
        if time.time() >= end:
            return None
        time.sleep(0.01)


# ------------------------------------------------------------------ conversation state
_state_log: List[Dict] = []
_restarts: List[float] = []
_hud_seen: Dict[str, float] = {}
_cfg: Dict[str, Optional[Callable]] = {"restart_listener": None, "set_hud": None, "get_hud": None}


def configure(**kw):
    _cfg.update({k: v for k, v in kw.items() if v is not None})


def _hud() -> Dict:
    fn = _cfg.get("get_hud")
    if fn:
        try:
            return dict(fn() or {})
        except Exception:
            return {}
    try:
        import friday_core5 as c5
        return c5.hud_state()
    except Exception:
        return {}


def _set_hud(**f):
    fn = _cfg.get("set_hud")
    try:
        if fn:
            fn(**f)
        else:
            import friday_core5 as c5
            c5.hud(**f)
    except Exception:
        pass


def _signals() -> Dict:
    s: Dict[str, Any] = {"playing": False, "aborted": False, "listening": None, "listen_error": "", "tts_busy": K.busy(), "hud": _hud().get("core", "")}
    try:
        import friday_speech5 as S5
        s["playing"], s["aborted"] = bool(S5.is_playing()), bool(S5.is_aborted())
    except Exception:
        pass
    try:
        import friday_voice5 as V5
        h = V5.health()
        s["listening"] = bool(h.get("running"))
        s["listen_error"] = str(h.get("disabled_reason") or "")
    except Exception:
        pass
    return s


def conversation_state() -> Dict:
    """One consistent answer to 'what are you doing right now?' from the engines' own signals."""
    s = _signals()
    now = time.time()
    hud = s["hud"]
    if s["listen_error"]:
        state, why = "degraded", f"listening is disabled: {s['listen_error'][:100]}"
    elif _restarts and now - _restarts[-1] < 15:
        state, why = "recovering", "restarting listening"
    elif s["aborted"] and (s["playing"] or s["tts_busy"] or hud == "Speaking"):
        state, why = "interrupted", "speech was interrupted"
    elif s["playing"] or s["tts_busy"]:
        state, why = "speaking", "audio is playing"
    elif hud in ("Thinking", "Acting", "Benchmarking"):
        state, why = "thinking", f"working ({hud.lower()})"
    elif s["listening"]:
        state, why = "listening", "waiting for you"
    elif s["listening"] is False:
        state, why = "idle", "the listening engine is not running"
    else:
        state, why = "idle", "no voice engine loaded"
    prev = _state_log[-1]["state"] if _state_log else None
    if state != prev:
        _state_log.append({"ts": now, "state": state, "why": why})
        del _state_log[:-40]
        K.emit("conversation.state", {"state": state, "why": why})
    return {"state": state, "why": why, "signals": s, "since": _state_log[-1]["ts"] if _state_log else now}


def reconcile() -> Optional[str]:
    """Correct a HUD that disagrees with reality for too long (e.g. 'Speaking' while nothing is playing). Returns what was corrected."""
    s = _signals()
    hud = s["hud"]
    now = time.time()
    if not hud:
        return None
    first = _hud_seen.setdefault(hud, now)
    for k in [k for k in _hud_seen if k != hud]:
        _hud_seen.pop(k, None)
    if hud == "Speaking" and not s["playing"] and not s["tts_busy"] and now - first > HUD_STALE_SPEAKING_S:
        _set_hud(core="Ready", tool="")
        _hud_seen.clear()
        return "the display said I was speaking but nothing was playing"
    if hud in ("Thinking", "Acting") and now - first > HUD_STALE_THINKING_S and not s["tts_busy"]:
        running = 0
        try:
            running = len(__import__("friday_orchestrator7").jobs(5, ("running", "planning", "waiting_approval")))
        except Exception:
            pass
        if not running:
            _set_hud(core="Ready", tool="")
            _hud_seen.clear()
            return "the display said I was thinking with nothing running"
    return None


def recover_listening(reason: str = "") -> str:
    """Restart the listening engine if it has stopped (rate-limited: at most 3 a hour, 2 minutes apart)."""
    now = time.time()
    _restarts[:] = [t for t in _restarts if now - t < 3600]
    if _restarts and now - _restarts[-1] < RESTART_MIN_GAP_S:
        return "a restart was already attempted a moment ago"
    if len(_restarts) >= RESTART_MAX_PER_HOUR:
        return "listening has been restarted three times this hour; not trying again automatically"
    fn = _cfg.get("restart_listener")
    if not fn:
        return "no restart hook is available"
    _restarts.append(now)
    try:
        fn()
        try:
            import friday_health7 as H
            H.incident("listening", f"restarted listening{(': ' + reason) if reason else ''}", "warn")
        except Exception:
            pass
        K.emit("runtime.recovered", {"what": "listening", "reason": reason})
        return "restarted the listening engine"
    except Exception as exc:
        return f"the restart failed: {type(exc).__name__}: {exc}"[:160]


_last_listen_ok = {"ts": time.time()}


def watchdog() -> List[str]:
    """Called every few seconds from the 7.0 tick. Fixes only what is clearly broken and says so in the incident log."""
    acts: List[str] = []
    s = _signals()
    if s["listening"]:
        _last_listen_ok["ts"] = time.time()
    elif s["listening"] is False and not s["listen_error"] and time.time() - _last_listen_ok["ts"] > 45 and _voice_session_expected():
        res = recover_listening("the listening engine stopped")
        acts.append(res)
    fixed = reconcile()
    if fixed:
        acts.append("corrected a stale display state: " + fixed)
    return acts


def _voice_session_expected() -> bool:
    fn = _cfg.get("voice_expected")
    try:
        return bool(fn()) if fn else False
    except Exception:
        return False


_tick_n = {"n": 0}


def tick():
    """Periodic housekeeping (called by core7's loop every ~10 s)."""
    _tick_n["n"] += 1
    acts = watchdog()
    if _tick_n["n"] % 6 == 0:
        unload_idle()
    return acts


# ------------------------------------------------------------------ chat
def handle(command: str) -> Optional[str]:
    t = K.norm_cmd(command)
    if re.match(r"^(?:free up|release|reclaim|clear)\s+(?:some\s+|the\s+)?(?:memory|ram)$|^unload (?:idle|unused) (?:components|things|stuff)$", t):
        r = unload_idle(force=True)
        if not r["released"]:
            return "There was nothing idle to release."
        return "Released " + ", ".join(r["released"]) + (f", about {r['freed_mb']:.0f} megabytes." if r["freed_mb"] else ". Memory use was already low.") + " Everything reloads on demand."
    if re.match(r"^(?:what are you doing|what(?:'s| is) your (?:current )?state|are you listening|are you (?:awake|there))\??$", t):
        st = conversation_state()
        return {"listening": "Yes, I'm listening.", "thinking": "I'm working on something right now.", "speaking": "I'm speaking at the moment.", "idle": "I'm idle.",
                "interrupted": "I was interrupted and am ready for you.", "recovering": "I'm restarting my listening, one moment.", "degraded": "Not entirely: " + st["why"] + "."}.get(st["state"], st["why"])
    return None


def snapshot() -> Dict:
    st = conversation_state()
    return {"state": st["state"], "why": st["why"], "light": _light(), "pool": pool_size(), "cache": cache.stats(), "speculations": len(_spec), "unloaders": sorted(_unloaders),
            "last_unload": dict(_last_unload), "restarts_last_hour": len([t for t in _restarts if time.time() - t < 3600]), "transitions": _state_log[-8:]}


def ui_snapshot() -> Dict:
    return {"runtime": snapshot()}
