"""
FRIDAY 9.5+ UNIFIED GATEWAY
----------------------------
This is the integration bridge that V3086 was missing: existing voice,
listening and recognition stay exactly where they are in friday_backend.py,
while complex commands enter the new Executive -> Supervisor -> Agent ->
Observe -> Verify -> Recover architecture.

The gateway deliberately does NOT claim simple commands that already have
fast, deterministic routes. That preserves low latency and reduces regressions.
"""
from __future__ import annotations

import re
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

# V3095.95+ quality governor: additive orchestration only. It never imports
# or changes the microphone, VAD, ASR, recognition, or TTS paths.
try:
    import friday_95plus_governor as quality_governor
except Exception:
    quality_governor = None

import friday_supervisor as supervisor
import friday_unified_loop as unified_loop
import friday_action_contracts as contracts

_REGISTER_LOCK = threading.RLock()
_REGISTERED = False


def _backend():
    import friday_backend
    return friday_backend


def _safe_bool(value: Any) -> bool:
    return bool(value) if isinstance(value, bool) else bool(value)


def _agent_desktop(task: dict[str, Any]) -> dict[str, Any]:
    from friday_desktop_agent import handle
    result = handle(task.get("action", ""))
    if isinstance(result, dict):
        payload = result.get("result") if result.get("handled") and isinstance(result.get("result"), dict) else result
        return contracts.normalize_agent_result(task.get("action", ""), payload)
    return contracts.normalize_agent_result(task.get("action", ""), result)


def _agent_app_launcher(task: dict[str, Any]) -> dict[str, Any]:
    from friday_app_launcher import launch
    action = task.get("action", "")
    m = re.search(r"\b(?:open|launch|start)\s+(?:the\s+)?(.+?)(?:\s+please)?$", action, re.I)
    target = (m.group(1) if m else action).strip(" .,!?")
    result = launch(target)
    return contracts.normalize_agent_result(action, result)


def _agent_browser(task: dict[str, Any]) -> dict[str, Any]:
    from friday_desktop_agent import browser
    result = browser(task.get("action", ""))
    return contracts.normalize_agent_result(task.get("action", ""), result)


def _agent_system(task: dict[str, Any]) -> dict[str, Any]:
    from friday_desktop_agent import system_info
    return {"summary": system_info(), "verified": True, "verification": {"method": "local system query"}}


def _agent_web_research(task: dict[str, Any]) -> dict[str, Any]:
    import friday_web_research
    query = task.get("inputs", {}).get("query") or task.get("inputs", {}).get("goal_text") or task.get("action", "")
    result = dict(friday_web_research.run_web_research(str(query), use_cache=True) or {})
    sources = result.get("_raw_sources") or result.get("sources") or []
    # Preserve the raw evidence for downstream document creation while exposing
    # a compact verification envelope. Independent-domain counting is used when
    # possible; a single-source result is still returned honestly, but is not
    # upgraded to high-confidence verification.
    domains = set()
    for src in sources:
        url = str(src.get("url", "")) if isinstance(src, dict) else ""
        m = re.search(r"https?://(?:www\.)?([^/]+)", url, re.I)
        if m:
            domains.add(m.group(1).lower())
    result["sources"] = sources
    result["summary"] = result.get("answer") or f"Research gathered {len(sources)} source(s)."
    result["verified"] = bool(sources)
    result["verification"] = {
        "method": "live multi-source research",
        "source_count": len(sources),
        "independent_domains": len(domains),
        "evidence_quality": "strong" if len(domains) >= 3 else ("moderate" if len(domains) >= 2 else "limited"),
    }
    return result


def _agent_youtube(task: dict[str, Any]) -> dict[str, Any]:
    import friday_youtube_research
    query = task.get("inputs", {}).get("query") or task.get("inputs", {}).get("goal_text") or task.get("action", "")
    result = friday_youtube_research.gather_youtube_sources(str(query), depth=2)
    result = dict(result or {})
    videos = result.get("videos") or []
    result["summary"] = f"Found {len(videos)} relevant YouTube source(s)."
    result["verified"] = bool(videos)
    result["verification"] = {"method": "YouTube source collection", "video_count": len(videos)}
    return result


def _agent_study(task: dict[str, Any]) -> dict[str, Any]:
    jb = _backend()
    result = jb.handle_study_command(task.get("action", ""))
    return {"summary": "Study workflow completed.", "result": result, "verified": bool(result is not False)}


def _agent_documents(task: dict[str, Any]) -> dict[str, Any]:
    """Use the existing creation engine but suppress duplicate progress speech.

    The engine remains the source of truth; this adapter only translates its
    result into the Supervisor's verification envelope.
    """
    import friday_creation_engine
    command = task.get("inputs", {}).get("goal_text") or task.get("action", "")
    reuse_sources = None
    reuse_topic = None
    # If the user just asked FRIDAY to research something and immediately
    # create a file, reuse the context engine's fresh raw evidence rather than
    # performing a second web crawl. This improves speed and keeps the artifact
    # tied to the exact evidence that produced the spoken research answer.
    try:
        import friday_context
        ctx = friday_context.resolve(str(command))
        if isinstance(ctx, dict) and ctx.get("reuse_research"):
            reuse_sources = ctx.get("reuse_sources")
            reuse_topic = ctx.get("topic")
    except Exception:
        pass
    result = friday_creation_engine.create_project_command(
        str(command), reuse_sources=reuse_sources, reuse_topic=reuse_topic, speak_progress=False
    )
    project = getattr(friday_creation_engine, "LAST_PROJECT", {}) or {}
    files = list(project.get("files") or [])
    good = [str(p) for p in files if Path(str(p)).exists() and Path(str(p)).is_file() and Path(str(p)).stat().st_size > 0]
    all_valid = bool(files) and len(good) == len(files)
    out = {
        "handler_result": result, "files": files, "topic": project.get("topic") or reuse_topic,
        "summary": f"Created {len(files)} document file(s).",
        "verified": all_valid,
        "verification": {"method": "filesystem validation", "files": good, "all_outputs_valid": all_valid,
                         "reused_research": bool(reuse_sources)},
    }
    if files and not all_valid:
        out["error"] = f"Only {len(good)} of {len(files)} generated files passed validation."
    return contracts.normalize_agent_result(command, out)


def _agent_notes(task: dict[str, Any]) -> dict[str, Any]:
    import friday_notes_engine
    # Notes generation is usually orchestrated through the existing creation
    # engine. Keep this adapter for explicit future use and return a safe record.
    return {"summary": "Notes agent available through the existing notes engine.", "verified": True,
            "verification": {"method": "registered capability"}, "module": friday_notes_engine.__name__}


def _agent_knowledge_base(task: dict[str, Any]) -> dict[str, Any]:
    try:
        import friday_advanced_agent
        rows = friday_advanced_agent.search_knowledge_base(task.get("action", ""), top_k=8)
        return {"summary": f"Found {len(rows)} local knowledge-base match(es).", "matches": rows,
                "verified": True, "verification": {"method": "local indexed retrieval"}}
    except Exception as exc:
        return {"error": str(exc), "verified": False}


def register_default_agents() -> dict[str, list[str]]:
    global _REGISTERED
    if _REGISTERED:
        return supervisor.list_agents()
    with _REGISTER_LOCK:
        if _REGISTERED:
            return supervisor.list_agents()
        registrations = [
            ("knowledge", "web_research", _agent_web_research),
            ("knowledge", "youtube_research", _agent_youtube),
            ("knowledge", "study", _agent_study),
            ("knowledge", "knowledge_base", _agent_knowledge_base),
            ("action", "desktop", _agent_desktop),
            ("action", "app_launcher", _agent_app_launcher),
            ("action", "browser", _agent_browser),
            ("action", "system", _agent_system),
            ("creation", "documents", _agent_documents),
            ("creation", "notes", _agent_notes),
        ]
        for group, name, fn in registrations:
            try:
                supervisor.register_agent(group, name, fn)
            except Exception:
                pass
        _REGISTERED = True
    return supervisor.list_agents()


def _normalized(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "")).strip()


def _looks_like_high_impact_direct(text: str) -> bool:
    return bool(re.search(r"\b(delete|remove|shutdown|restart|format|uninstall|send (?:a )?(?:message|email|text))\b", text.lower()))


def should_handle(command: str) -> bool:
    """Only intercept requests that benefit from true orchestration.

    The 9.5+ gateway is deliberately selective: simple commands remain on
    their existing fast deterministic routes, while compound knowledge/action
    goals get the full plan -> execute -> verify -> recover loop.
    """
    c = _normalized(command)
    low = c.lower()
    if not c or _looks_like_high_impact_direct(c):
        return False
    # Existing deterministic lanes should stay in charge of these.
    if re.search(r"\bopen\s+whats?app\b", low):
        return False
    if re.search(r"\b(?:send|write|text|message)\b.*\bto\b", low) and "whatsapp" in low:
        return False
    # High-value compound goals.
    if re.search(r"\b(research|investigate|find sources|according to)\b", low) and re.search(r"\b(create|make|generate|turn .* into)\b.*\b(pdf|docx|word|slides?|presentation|spreadsheet|notes?)\b", low):
        return True
    if re.search(r"\b(research|investigate|analy[sz]e|compare|verify)\b", low) and ("youtube" in low or "videos" in low or "sources" in low):
        return True
    if re.search(r"\b(research|investigate|analy[sz]e|compare|verify)\b", low) and re.search(r"\b(create|make|generate|build|turn)\b", low):
        return True
    if re.search(r"\b(study|revise|exam|syllabus|weak|practice)\b", low) and re.search(r"\b(create|make|generate|quiz|questions|notes|plan)\b", low):
        return True
    if len(re.findall(r"\b(?:and|then|also|after that)\b", low)) >= 2 and len(c.split()) >= 9:
        return True
    return False


def build_plan(command: str) -> list[dict[str, Any]]:
    """Fast deterministic planner; optional LLM planning remains in the older
    advanced agent and is not needed on the latency-critical route."""
    c = _normalized(command)
    low = c.lower()
    steps: list[dict[str, Any]] = []
    research = bool(re.search(r"\b(research|investigate|find sources|according to)\b", low))
    youtube = "youtube" in low or re.search(r"\bvideos?\b", low) is not None
    document = bool(re.search(r"\b(create|make|generate|turn .* into|build)\b.*\b(pdf|docx|word|slides?|presentation|spreadsheet|notes?|diagram)\b", low))
    study = bool(re.search(r"\b(study|revise|exam|syllabus|weak|practice)\b", low))

    # Topic cleanup: strip broad request scaffolding but keep the content query.
    topic = re.sub(r"\b(research|investigate|find sources)\b", "", c, flags=re.I)
    topic = re.sub(r"\b(?:and|then|also)\s+(?:find|show|watch|search).*(?:youtube|videos?)\b", "", topic, flags=re.I)
    topic = re.sub(r"\b(and|then|also)\s+(create|make|generate|turn .* into)\b.*$", "", topic, flags=re.I)
    topic = re.sub(r"\b(create|make|generate|turn .* into)\b.*\b(pdf|docx|word|slides?|presentation|spreadsheet|notes?)\b.*$", "", topic, flags=re.I)
    topic = re.sub(r"\b(on|about)\s+", "", topic, count=1, flags=re.I).strip(" .,!?") or c

    if research:
        steps.append({"name": "research", "tool": "web_research", "agent_group": "knowledge", "agent_name": "web_research",
                      "inputs": {"goal_text": topic, "query": topic}, "verification_level": "knowledge",
                      "verification_criteria": {"claim": topic}})
    if youtube:
        steps.append({"name": "youtube", "tool": "youtube_research", "agent_group": "knowledge", "agent_name": "youtube_research",
                      "inputs": {"goal_text": topic, "query": topic}, "verification_level": "semantic"})
    if document:
        deps = [s["name"] for s in steps]
        steps.append({"name": "document", "tool": "document_creation", "agent_group": "creation", "agent_name": "documents",
                      "inputs": {"goal_text": c, "reuse_research": bool(research), "reuse_youtube": bool(youtube)},
                      "dependencies": deps, "verification_level": "mechanical_file"})
    elif study and not steps:
        steps.append({"name": "study", "tool": "study", "agent_group": "knowledge", "agent_name": "study",
                      "inputs": {"goal_text": c}, "verification_level": "semantic",
                      "verification_criteria": {"requested": c}})

    # Generic compound action fallback: sequentially route each clause through
    # the existing desktop adapter. This is only used when there is no more
    # specific document/research plan.
    if not steps:
        clauses = [x.strip(" .,!?") for x in re.split(r"\s+(?:and then|then|and)\s+", c, flags=re.I) if x.strip()]
        prev = None
        for i, clause in enumerate(clauses):
            current = {"name": f"action_{i+1}", "tool": "desktop", "agent_group": "action", "agent_name": "desktop",
                       "inputs": {"goal_text": c}, "verification_level": "mechanical_action"}
            if prev:
                current["dependencies"] = [prev]
            steps.append(current)
            prev = current["name"]
    return steps


def _summary_for_result(command: str, result: dict[str, Any]) -> str:
    status = result.get("status")
    if status == "COMPLETED":
        confidence = result.get("confidence", 0.0)
        return f"Done, sir. I completed and verified that request. Confidence {round(float(confidence)*100)} percent."
    return result.get("explanation") or "Sir, the request did not reach a verified end state. I have not claimed success."


def try_handle(command: str, *, ask_user: Optional[Callable[[str], bool]] = None) -> Optional[bool]:
    if not should_handle(command):
        return None
    register_default_agents()
    started = time.perf_counter()
    plan = build_plan(command)
    # Quality governor can annotate the plan with deterministic evidence
    # requirements. It is intentionally skipped if unavailable.
    if quality_governor is not None:
        try:
            plan = quality_governor.harden_plan(command, plan)
        except Exception:
            pass
    try:
        result = unified_loop.run_cycle(command=command, plan_override=plan, ask_user=ask_user, fast=True)
    except Exception as exc:
        try:
            _backend().log_event(f"Unified gateway failed safely: {exc}", kind="recovery")
        except Exception:
            pass
        return None

    jb = _backend()
    summary = _summary_for_result(command, result)
    try:
        jb.log_event(f"Unified 9.5+ execution finished in {time.perf_counter()-started:.2f}s", kind="result")
        jb.speak(summary)
    except Exception:
        pass
    return True


def health() -> dict[str, Any]:
    register_default_agents()
    return {
        "registered_agents": supervisor.list_agents(),
        "unified_loop": unified_loop.health(),
        "gateway": {"registered": _REGISTERED, "pid": threading.get_ident()},
    }
