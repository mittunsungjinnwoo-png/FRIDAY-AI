"""
FRIDAY 9.5+ ACTION CONTRACTS
-----------------------------
A small, deterministic contract layer shared by the Unified Supervisor and
advanced agent.  A tool returning without an exception is NOT enough to call
an action successful.  Every consequential action gets explicit success
criteria and an evidence requirement.

This module does not touch voice, listening or recognition.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def _has_truthy_verified(value: Any) -> bool:
    if not isinstance(value, dict):
        return False
    if bool(value.get("verified")):
        return True
    nested = value.get("result")
    if isinstance(nested, dict) and bool(nested.get("verified")):
        return True
    return False


def infer_contract(action: str, task: dict[str, Any] | None = None) -> dict[str, Any]:
    text = (action or "").strip().lower()
    task = task or {}
    explicit = task.get("verification_contract")
    if isinstance(explicit, dict):
        return dict(explicit)

    if re.search(r"\b(send|message|text)\b", text):
        return {"name": "communication", "requires_explicit_delivery_proof": True}
    if re.search(r"\b(search|look up|show .* results|google|youtube)\b", text):
        return {"name": "browser_search", "requires_independent_evidence": True}
    if re.search(r"\b(create|make|generate|build).*(pdf|docx|word|xlsx|spreadsheet|pptx|presentation|notes?)\b", text):
        return {"name": "document_creation", "requires_file_validation": True}
    if re.search(r"\b(open|launch|start)\b", text):
        return {"name": "application_launch", "requires_window_or_process_proof": True}
    if re.search(r"\b(delete|remove|shutdown|restart|format|uninstall)\b", text):
        return {"name": "consequential_system_action", "requires_explicit_confirmation": True}
    if re.search(r"\b(click|type|write|paste|scroll|move cursor)\b", text):
        return {"name": "desktop_interaction", "requires_ui_change_or_agent_verification": True}
    return {"name": "general", "requires_agent_or_semantic_verification": True}


def normalize_agent_result(action: str, result: Any) -> dict[str, Any]:
    """Turn any adapter return value into a structured, auditable envelope."""
    if isinstance(result, dict):
        out = dict(result)
    elif isinstance(result, bool):
        out = {"ok": result, "summary": "completed" if result else "failed"}
    else:
        out = {"summary": str(result)}

    out.setdefault("action", action)
    out.setdefault("verified", _has_truthy_verified(out))
    out.setdefault("evidence", [])
    out.setdefault("contract", infer_contract(action))
    return out


def result_is_successful(action: str, result: dict[str, Any]) -> tuple[bool, str]:
    """Return (success, reason). Never equates 'no exception' with success."""
    contract = result.get("contract") or infer_contract(action)
    if result.get("error"):
        return False, str(result.get("error"))

    if result.get("verified") is True:
        return True, "agent supplied explicit independent verification"

    if result.get("ok") is True and contract.get("name") == "general":
        return True, "adapter explicitly returned ok for a non-consequential operation"

    if contract.get("name") == "document_creation":
        files = [str(x) for x in (result.get("files") or []) if x]
        good = []
        for f in files:
            p = Path(f)
            if p.exists() and p.is_file() and p.stat().st_size > 0:
                good.append(str(p))
        if good:
            result.setdefault("verified", True)
            result.setdefault("verification", {"files": good, "method": "filesystem validation"})
            return True, "created file exists and is non-empty"
        return False, "document output was not independently verified"

    if contract.get("name") == "application_launch":
        return False, "application launch lacks independent verification"

    if contract.get("name") == "browser_search":
        return False, "browser search lacks independent verification"

    if contract.get("name") == "communication":
        return False, "message delivery lacks explicit delivery proof"

    if contract.get("name") == "desktop_interaction":
        return False, "desktop interaction lacks UI/effect evidence"

    return False, "result was not verified"
